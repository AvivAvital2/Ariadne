---
id: b460b003-8892-5125-9194-1576144f128d
type: diagram
title: "Logger Diagram"
created_at: 2026-06-06T19:03:50.572033+00:00
updated_at: 2026-06-20T22:55:21.378142+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  mermaid_code: "classDiagram"
  logging_Logger <|-- CustomLogger: "extends"
  logging_Filter <|-- SkipHealthFilter: "extends"
  Logger ..> CustomLogger: "configures"
  Logger ..> SkipHealthFilter: "applies filter"
  source_name: "mps"
---
# Logger Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# Logger Diagram




```mermaid
classDiagram
    class logging_Logger {
        <<external>>
        +makeRecord()
    }

    class logging_Filter {
        <<external>>
        +filter()
    }

    class CustomLogger {
        +makeRecord()
    }

    class SkipHealthFilter {
        +filter(record) bool
    }

    class Logger {
        <<facade>>
    }

    logging_Logger <|-- CustomLogger : extends
    logging_Filter <|-- SkipHealthFilter : extends

    Logger ..> CustomLogger : configures
    Logger ..> SkipHealthFilter : applies filter

    note for SkipHealthFilter "Excludes health-check\nlog records"
    note for CustomLogger "Overrides record\ncreation logic"

```