---
id: 43962771-7b11-5e4e-8a99-c93575fca984
type: diagram
title: "Image Manager Diagram"
created_at: 2026-06-06T19:03:44.415800+00:00
updated_at: 2026-06-20T22:55:21.378485+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  mermaid_code: "classDiagram"
  ImageManager ..> DockerRegistry: "authenticates & pushes"
  ImageManager ..> LocalDockerEngine: "builds & queries images"
  source_name: "mps"
---
# Image Manager Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# Image Manager Diagram




```mermaid
classDiagram
    class ImageManager {
        +login()
        +build_and_push()
        +push_image()
        +list_local_images()
        +get_if_image_exists()
        +... 11 more methods
    }

    class DockerRegistry {
        <<external>>
    }

    class LocalDockerEngine {
        <<external>>
    }

    ImageManager ..> DockerRegistry : authenticates & pushes
    ImageManager ..> LocalDockerEngine : builds & queries images

    note for ImageManager "mps.api.image_manager\nManages image build,\npush, and registry operations"

```