---
id: b6c7167d-68ff-568b-b724-668fe753a5f4
type: diagram
title: "Update Version Diagram"
created_at: 2026-06-06T19:04:54.198924+00:00
updated_at: 2026-06-20T22:55:21.384657+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  mermaid_code: "flowchart TD"
  style Call fill: "#cde4ff,stroke:#3366cc,stroke-width:2px"
  style Module fill: "#f9f9f9,stroke:#999,stroke-dasharray:5 5"
  source_name: "mps"
---
# Update Version Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# Update Version Diagram




```mermaid
flowchart TD
    Start([Start]) --> Call["update_version()"]

    subgraph Module["update_version module"]
        Call --> ReadVer["Read current version"]
        ReadVer --> Compute["Compute new version"]
        Compute --> WriteVer["Write updated version"]
        WriteVer --> Done(["Version updated"])
    end

    Done --> End([End])

    style Call fill:#cde4ff,stroke:#3366cc,stroke-width:2px
    style Module fill:#f9f9f9,stroke:#999,stroke-dasharray:5 5

```