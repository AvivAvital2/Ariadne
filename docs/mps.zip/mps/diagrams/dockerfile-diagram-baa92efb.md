---
id: baa92efb-176d-5426-a566-3491a5a19df7
type: diagram
title: "Dockerfile Diagram"
created_at: 2026-07-03T05:58:32.777912+00:00
updated_at: 2026-07-03T05:58:32.777924+00:00
source_files:
  - /Users/spark/git/service-model-promotion/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  dot_code: "digraph stage0_Dockerfile {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Multi-stage build representation
    base       [label="Base Image\n(FROM <base>)", fillcolor="#d5e8d4"];
    stage0     [label="stage0\n(build stage)", fillcolor="#dae8fc"];
    workdir    [label="WORKDIR\n(working directory)", shape=folder, fillcolor="#fff2cc"];
    copy       [label="COPY / ADD\n(source files)", shape=note, fillcolor="#fff2cc"];
    run        [label="RUN\n(build commands)", shape=component, fillcolor="#f8cecc"];
    env        [label="ENV / ARG\n(build variables)", shape=parallelogram, fillcolor="#e1d5e7"];
    entrypoint [label="ENTRYPOINT / CMD\n(runtime command)", fillcolor="#d5e8d4"];
    image      [label="Output Image\n(stage0 artifact)", shape=cylinder, fillcolor="#d5e8d4"];

    // Build flow
    base    -> stage0     [label="derives from"];
    env     -> stage0     [label="configures"];
    stage0  -> workdir    [label="sets"];
    workdir -> copy       [label="context"];
    copy    -> run        [label="provides input"];
    run     -> entrypoint [label="produces layers"];
    entrypoint -> image   [label="finalizes"];

    // Data flow hints
    env -> run  [label="variables", style=dashed];
    copy -> image [label="artifacts", style=dashed];
}"
  source_name: "mps"
---
# Dockerfile Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/builder/Dockerfile`



```dot
digraph stage0_Dockerfile {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Multi-stage build representation
    base       [label="Base Image\n(FROM <base>)", fillcolor="#d5e8d4"];
    stage0     [label="stage0\n(build stage)", fillcolor="#dae8fc"];
    workdir    [label="WORKDIR\n(working directory)", shape=folder, fillcolor="#fff2cc"];
    copy       [label="COPY / ADD\n(source files)", shape=note, fillcolor="#fff2cc"];
    run        [label="RUN\n(build commands)", shape=component, fillcolor="#f8cecc"];
    env        [label="ENV / ARG\n(build variables)", shape=parallelogram, fillcolor="#e1d5e7"];
    entrypoint [label="ENTRYPOINT / CMD\n(runtime command)", fillcolor="#d5e8d4"];
    image      [label="Output Image\n(stage0 artifact)", shape=cylinder, fillcolor="#d5e8d4"];

    // Build flow
    base    -> stage0     [label="derives from"];
    env     -> stage0     [label="configures"];
    stage0  -> workdir    [label="sets"];
    workdir -> copy       [label="context"];
    copy    -> run        [label="provides input"];
    run     -> entrypoint [label="produces layers"];
    entrypoint -> image   [label="finalizes"];

    // Data flow hints
    env -> run  [label="variables", style=dashed];
    copy -> image [label="artifacts", style=dashed];
}
```