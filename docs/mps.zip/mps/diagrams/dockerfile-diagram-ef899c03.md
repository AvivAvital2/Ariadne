---
id: ef899c03-29e5-53dc-aaf9-dc7433fcfe8d
type: diagram
title: "Dockerfile Diagram"
created_at: 2026-07-03T05:57:44.813149+00:00
updated_at: 2026-07-03T05:57:44.813160+00:00
source_files:
  - /Users/spark/git/service-model-promotion/Dockerfile
metadata:
  module_name: "builder.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  dot_code: "digraph DockerfileBuild {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    Dockerfile [label="builder.Dockerfile", shape=note, fillcolor="#fff2cc"];

    // Typical Dockerfile build stages / instructions
    BaseImage   [label="FROM (base image)"];
    Args        [label="ARG / ENV\n(build variables)"];
    Workdir     [label="WORKDIR\n(context setup)"];
    Copy        [label="COPY / ADD\n(source files)"];
    Deps        [label="RUN\n(install deps)"];
    Build       [label="RUN\n(build step)"];
    Expose      [label="EXPOSE\n(ports)"];
    Entrypoint  [label="ENTRYPOINT / CMD\n(runtime)"];
    FinalImage  [label="Final Image", shape=box3d, fillcolor="#d9ead3"];

    // Build flow
    Dockerfile -> BaseImage   [label="defines"];
    BaseImage  -> Args        [label="sets"];
    Args       -> Workdir     [label="configures"];
    Workdir    -> Copy        [label="prepares"];
    Copy       -> Deps        [label="provides files"];
    Deps       -> Build       [label="enables"];
    Build      -> Expose      [label="produces"];
    Expose     -> Entrypoint  [label="declares"];
    Entrypoint -> FinalImage  [label="produces"];

    // Data flow feedback
    Args -> Deps  [label="parameterizes", style=dashed, constraint=false];
    Args -> Build [label="parameterizes", style=dashed, constraint=false];
}"
  source_name: "mps"
---
# Dockerfile Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/Dockerfile`

Note: No classes or functions were found in the provided information, so this diagram represents the conventional build-stage flow of a Dockerfile-based builder module. If you can share the actual Dockerfile contents or instruction list, I can produce a more precise diagram.

```dot
digraph DockerfileBuild {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    Dockerfile [label="builder.Dockerfile", shape=note, fillcolor="#fff2cc"];

    // Typical Dockerfile build stages / instructions
    BaseImage   [label="FROM (base image)"];
    Args        [label="ARG / ENV\n(build variables)"];
    Workdir     [label="WORKDIR\n(context setup)"];
    Copy        [label="COPY / ADD\n(source files)"];
    Deps        [label="RUN\n(install deps)"];
    Build       [label="RUN\n(build step)"];
    Expose      [label="EXPOSE\n(ports)"];
    Entrypoint  [label="ENTRYPOINT / CMD\n(runtime)"];
    FinalImage  [label="Final Image", shape=box3d, fillcolor="#d9ead3"];

    // Build flow
    Dockerfile -> BaseImage   [label="defines"];
    BaseImage  -> Args        [label="sets"];
    Args       -> Workdir     [label="configures"];
    Workdir    -> Copy        [label="prepares"];
    Copy       -> Deps        [label="provides files"];
    Deps       -> Build       [label="enables"];
    Build      -> Expose      [label="produces"];
    Expose     -> Entrypoint  [label="declares"];
    Entrypoint -> FinalImage  [label="produces"];

    // Data flow feedback
    Args -> Deps  [label="parameterizes", style=dashed, constraint=false];
    Args -> Build [label="parameterizes", style=dashed, constraint=false];
}
```