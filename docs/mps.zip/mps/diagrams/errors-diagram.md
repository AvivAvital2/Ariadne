---
id: 9438de82-8992-5fc7-8a6c-f37ccdfb8ee2
type: diagram
title: "Errors Diagram"
created_at: 2026-06-06T19:03:31.308258+00:00
updated_at: 2026-06-20T22:55:21.376377+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  mermaid_code: "classDiagram"
  source_name: "mps"
---
# Errors Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# Errors Diagram




```mermaid
classDiagram
    class Exception {
        <<builtin>>
    }

    class ExceptionHandler {
        +exception_handler()
    }

    Exception <|-- ExceptionHandler

    ExceptionHandler <|-- NoConfigurationFoundError
    ExceptionHandler <|-- NoConfigurationFileFoundError
    ExceptionHandler <|-- InvalidConfigurationFile
    ExceptionHandler <|-- UnableToGetAuthToken
    ExceptionHandler <|-- InvalidRegistryProvider
    ExceptionHandler <|-- InvalidAWSRegion
    ExceptionHandler <|-- UnableToUploadOneOrMoreImages
    ExceptionHandler <|-- MissingConfigValues
    ExceptionHandler <|-- UnreachableContainerRegistry
    ExceptionHandler <|-- UnavailableImage
    ExceptionHandler <|-- SelfSignedCertificate
    ExceptionHandler <|-- UnableToStoreCredentialsFile
    ExceptionHandler <|-- UnableToObtainPushedImagesFromContainerRegistry

```