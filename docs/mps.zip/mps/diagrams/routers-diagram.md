---
id: 2ac842f4-f828-5976-b6f9-20ea43a9d598
type: diagram
title: "Routers Diagram"
created_at: 2026-06-06T19:04:17.284666+00:00
updated_at: 2026-06-20T22:55:21.374960+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/__init__.py
metadata:
  mermaid_code: "flowchart TB"
  style routers fill: "#e1f5ff,stroke:#0277bd,stroke-width:2px"
  style note fill: "#fff3e0,stroke:#ef6c00,stroke-width:1px,stroke-dasharray: 5 5"
  style mps fill: "#f5f5f5,stroke:#9e9e9e,stroke-width:1px"
  source_name: "mps"
---
# Routers Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/__init__.py`

# Routers Diagram




```mermaid
flowchart TB
    subgraph mps["mps package"]
        routers["mps.routers<br/>(module)"]
    end

    note["No classes or functions<br/>defined in this module"]

    routers -.-> note

    style routers fill:#e1f5ff,stroke:#0277bd,stroke-width:2px
    style note fill:#fff3e0,stroke:#ef6c00,stroke-width:1px,stroke-dasharray: 5 5
    style mps fill:#f5f5f5,stroke:#9e9e9e,stroke-width:1px

```