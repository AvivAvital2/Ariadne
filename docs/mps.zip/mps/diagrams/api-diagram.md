---
id: 14f4878d-57b8-5ba6-97a8-b208dee7f5bd
type: diagram
title: "Api Diagram"
created_at: 2026-06-06T19:03:18.393852+00:00
updated_at: 2026-06-20T22:55:21.354154+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/__init__.py
metadata:
  mermaid_code: "flowchart TD"
  style api fill: "#e1f5ff,stroke:#0288d1,stroke-width:2px"
  style mps fill: "#f5f5f5,stroke:#9e9e9e,stroke-width:1px"
  style note fill: "#fff3e0,stroke:#fb8c00,stroke-width:1px,stroke-dasharray: 5 5"
  source_name: "mps"
---
# Api Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/__init__.py`

# Api Diagram




```mermaid
flowchart TD
    subgraph mps["mps package"]
        api["mps.api module"]
    end

    note["No classes or functions
    defined in this module"]

    api -.-> note

    style api fill:#e1f5ff,stroke:#0288d1,stroke-width:2px
    style mps fill:#f5f5f5,stroke:#9e9e9e,stroke-width:1px
    style note fill:#fff3e0,stroke:#fb8c00,stroke-width:1px,stroke-dasharray: 5 5

```