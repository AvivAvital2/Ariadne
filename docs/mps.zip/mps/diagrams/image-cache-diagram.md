---
id: 26b6854b-3ba3-5eb9-b940-8768de2a3e17
type: diagram
title: "Image Cache Diagram"
created_at: 2026-06-06T19:03:37.992064+00:00
updated_at: 2026-06-20T22:55:21.371456+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  mermaid_code: "classDiagram"
  AsyncPersistentImageCache ..> PersistentStore: "persists to"
  source_name: "mps"
---
# Image Cache Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# Image Cache Diagram




```mermaid
classDiagram
    class AsyncPersistentImageCache {
        +get(key) Image
        +list() List
        +set(key, image) None
        +update(key, image) None
        +delete(key) None
        +clear() None
    }

    class PersistentStore {
        <<storage backend>>
    }

    AsyncPersistentImageCache ..> PersistentStore : persists to

    note for AsyncPersistentImageCache "Async CRUD operations\nfor cached images"

```