---
id: 32649c0e-858c-59cf-8658-5bf7249e7bdc
type: diagram
title: "Promote Diagram"
created_at: 2026-06-06T19:04:35.483922+00:00
updated_at: 2026-06-20T22:55:21.322557+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  mermaid_code: "flowchart TD"
  source_name: "mps"
---
# Promote Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# Promote Diagram




```mermaid
flowchart TD
    Client([Client Request])

    subgraph promote_router["mps.routers.promote"]
        promote["promote(project_id, revision, request_obj)"]
        is_image_exists["is_image_exists(params)"]
        get_status["get_promotion_status()"]
    end

    Client -->|"POST /promote"| promote
    Client -->|"GET /status"| get_status

    promote -->|"validate image"| is_image_exists
    is_image_exists -->|"image found / not found"| promote

    promote -->|"triggers promotion"| PromotionTask[(Promotion Process)]
    PromotionTask -->|"updates state"| StatusStore[(Status Store)]

    get_status -->|"read state"| StatusStore
    get_status -->|"promotion status"| Client

    promote -->|"response"| Client

```