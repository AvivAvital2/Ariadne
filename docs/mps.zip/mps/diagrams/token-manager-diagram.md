---
id: 4733486e-0e39-5fe4-b6f1-cf1f1f2730bb
type: diagram
title: "Token Manager Diagram"
created_at: 2026-06-06T19:04:02.598126+00:00
updated_at: 2026-06-20T22:55:21.325755+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  mermaid_code: "classDiagram"
  TokenManager <|-- AWSTokenManager: "inherits"
  source_name: "mps"
---
# Token Manager Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# Token Manager Diagram




```mermaid
classDiagram
    class TokenManager {
        +get_credentials()
        +get_username_and_password()
        +login()
    }

    class AWSTokenManager {
        +get_username_and_password()
        +login()
    }

    TokenManager <|-- AWSTokenManager : inherits

    note for TokenManager "Base token manager.\nget_credentials() uses\nget_username_and_password()\nand login()"
    note for AWSTokenManager "Overrides credential\nretrieval and login\nfor AWS"

```