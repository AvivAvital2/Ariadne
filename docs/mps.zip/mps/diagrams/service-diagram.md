---
id: e5d6ee62-143f-5830-89a1-f70e3526b6b9
type: diagram
title: "Service Diagram"
created_at: 2026-06-06T19:04:41.361170+00:00
updated_at: 2026-06-20T22:55:21.335420+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  mermaid_code: "classDiagram"
  source_name: "mps"
---
# Service Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# Service Diagram




```mermaid
classDiagram
    class MPS {
        +get_token_manager()
    }

    namespace mps_service {
        class MPS
    }

```