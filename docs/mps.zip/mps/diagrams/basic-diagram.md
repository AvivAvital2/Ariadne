---
id: 94e454a3-8e72-5ead-84a4-d5b9ccc76569
type: diagram
title: "Basic Diagram"
created_at: 2026-06-06T19:04:23.079960+00:00
updated_at: 2026-06-20T22:55:21.355391+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  mermaid_code: "flowchart TD"
  classDef endpoint fill: "#e1f5ff,stroke:#0288d1,color:#01579b;"
  classDef external fill: "#f5f5f5,stroke:#9e9e9e,color:#424242;"
  source_name: "mps"
---
# Basic Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# Basic Diagram




```mermaid
flowchart TD
    subgraph Module["mps.routers.basic"]
        direction TB
        Ping["ping()"]
        BuildInfo["build_info()"]
    end

    Client(["Client / Consumer"])

    Client -->|"GET /ping"| Ping
    Client -->|"GET /build_info"| BuildInfo

    Ping -->|"health status response"| Client
    BuildInfo -->|"version & build metadata"| Client

    classDef endpoint fill:#e1f5ff,stroke:#0288d1,color:#01579b;
    classDef external fill:#f5f5f5,stroke:#9e9e9e,color:#424242;

    class Ping,BuildInfo endpoint;
    class Client external;

```