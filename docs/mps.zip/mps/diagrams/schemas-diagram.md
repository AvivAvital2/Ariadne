---
id: 25ad9851-a175-53bc-a345-f8cd6dfb0d87
type: diagram
title: "Schemas Diagram"
created_at: 2026-06-06T19:03:55.948580+00:00
updated_at: 2026-06-20T22:55:21.343597+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  mermaid_code: "classDiagram"
  AuxiliaryImages "1" *-- "many" AuxiliaryImage: "contains"
  ImageParams ..> BaseImages: "references"
  ImageParams ..> AuxiliaryImages: "references"
  ImageParams ..> Flavours: "references"
  PromoteParams ..> BaseImages: "promotes"
  BaseImages ..> Flavours: "maps versions"
  source_name: "mps"
---
# Schemas Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# Schemas Diagram




```mermaid
classDiagram
    class Flavours {
        <<schema>>
    }

    class BaseImages {
        <<schema>>
        +make_versions_dict()
    }

    class PromoteParams {
        <<schema>>
    }

    class AuxiliaryImage {
        <<schema>>
    }

    class AuxiliaryImages {
        <<schema>>
    }

    class ImageParams {
        <<schema>>
    }

    %% Composition relationships
    AuxiliaryImages "1" *-- "many" AuxiliaryImage : contains

    %% Data flow associations
    ImageParams ..> BaseImages : references
    ImageParams ..> AuxiliaryImages : references
    ImageParams ..> Flavours : references

    PromoteParams ..> BaseImages : promotes
    BaseImages ..> Flavours : maps versions

```