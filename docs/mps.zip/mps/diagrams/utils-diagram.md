---
id: 8ef13324-c747-549b-be3d-e52fa8eecb93
type: diagram
title: "Utils Diagram"
created_at: 2026-06-06T19:04:09.055762+00:00
updated_at: 2026-06-20T22:55:21.332391+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  mermaid_code: "classDiagram"
  requests_Session <|-- MPSSession: "inherits"
  mps_api_utils ..> MPSSession: "uses for HTTP"
  mps_api_utils ..> requests_Session: "depends on"
  source_name: "mps"
---
# Utils Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# Utils Diagram




```mermaid
classDiagram
    class requests_Session {
        <<external>>
        +request()
    }

    class MPSSession {
        +request()
    }

    requests_Session <|-- MPSSession : inherits

    class mps_api_utils {
        <<module>>
        +run_command(command, supress_errors)
        +stream_reader()
        +construct_model_id(project_id, revision)
        +parse_version_number(version_string, as_config_key)
        +resolve_base_image_id(base_images, release_version, ...)
        +extract_model(zip_file_path, destination)
        +verify_connection_to_container_registry(schema, registry, auth, verify, provider)
        +docker_image_to_file_name(tag)
    }

    mps_api_utils ..> MPSSession : uses for HTTP
    mps_api_utils ..> requests_Session : depends on

```