---
id: c27651ee-8902-5226-9a0c-7fce23bd5229
type: diagram
title: "Maintenance Diagram"
created_at: 2026-06-06T19:04:29.370737+00:00
updated_at: 2026-06-20T22:55:21.358854+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  mermaid_code: "flowchart TD"
  source_name: "mps"
---
# Maintenance Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# Maintenance Diagram




```mermaid
flowchart TD
    subgraph Maintenance["mps.routers.maintenance"]
        LI["list_images()"]
        DLI["delete_local_images()"]
        GTIS["get_total_images_size()"]
        RI["remote_images()"]
    end

    Client(["API Client"])
    LocalStore[("Local Image Store")]
    RemoteRegistry[("Remote Registry")]

    Client -->|GET /images| LI
    Client -->|DELETE /images| DLI
    Client -->|GET /images/size| GTIS
    Client -->|GET /images/remote| RI

    LI -->|read| LocalStore
    DLI -->|remove| LocalStore
    GTIS -->|aggregate sizes| LocalStore
    RI -->|query| RemoteRegistry

    LI -.->|returns image list| Client
    DLI -.->|returns delete status| Client
    GTIS -.->|returns total size| Client
    RI -.->|returns remote list| Client

```