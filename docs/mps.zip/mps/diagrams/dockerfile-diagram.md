---
id: 9ca3e372-470c-5053-89a4-7e131a48bcd4
type: diagram
title: "Dockerfile Diagram"
created_at: 2026-07-03T05:57:44.949969+00:00
updated_at: 2026-07-03T05:57:44.949981+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  dot_code: "digraph stage0_Dockerfile {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Dockerfile build stage: stage0
    label="stage0.Dockerfile - Multi-stage Build";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Base image
    base_image [label="Base Image\n(FROM ...)", shape=cylinder, fillcolor="#fce8e6"];

    // Build stage
    stage0 [label="stage0\n(build stage)", fillcolor="#e6f4ea", shape=box3d];

    // Typical Dockerfile instruction nodes
    workdir  [label="WORKDIR\n(set working dir)"];
    copy     [label="COPY / ADD\n(source files)"];
    run      [label="RUN\n(build commands)"];
    env      [label="ENV / ARG\n(config vars)"];
    entry    [label="ENTRYPOINT / CMD\n(runtime)"];

    // Output artifact
    artifact [label="Build Artifact\n(image layers)", shape=note, fillcolor="#fef7e0"];

    // Relationships / build flow
    base_image -> stage0   [label="derives from"];
    stage0 -> env          [label="defines"];
    env -> workdir         [label="then"];
    workdir -> copy        [label="then"];
    copy -> run            [label="feeds"];
    run -> entry           [label="then"];
    entry -> artifact      [label="produces"];
}"
  source_name: "mps"
---
# Dockerfile Diagram

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/builder/Dockerfile`



```dot
digraph stage0_Dockerfile {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Dockerfile build stage: stage0
    label="stage0.Dockerfile - Multi-stage Build";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Base image
    base_image [label="Base Image\n(FROM ...)", shape=cylinder, fillcolor="#fce8e6"];

    // Build stage
    stage0 [label="stage0\n(build stage)", fillcolor="#e6f4ea", shape=box3d];

    // Typical Dockerfile instruction nodes
    workdir  [label="WORKDIR\n(set working dir)"];
    copy     [label="COPY / ADD\n(source files)"];
    run      [label="RUN\n(build commands)"];
    env      [label="ENV / ARG\n(config vars)"];
    entry    [label="ENTRYPOINT / CMD\n(runtime)"];

    // Output artifact
    artifact [label="Build Artifact\n(image layers)", shape=note, fillcolor="#fef7e0"];

    // Relationships / build flow
    base_image -> stage0   [label="derives from"];
    stage0 -> env          [label="defines"];
    env -> workdir         [label="then"];
    workdir -> copy        [label="then"];
    copy -> run            [label="feeds"];
    run -> entry           [label="then"];
    entry -> artifact      [label="produces"];
}
```