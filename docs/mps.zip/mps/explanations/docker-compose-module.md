---
id: da3b4a79-0119-5190-b8b9-e9cef78d3d1f
type: explanation
title: "Docker-Compose Module"
created_at: 2026-06-06T19:03:02.719876+00:00
updated_at: 2026-07-03T05:58:24.647306+00:00
source_files:
  - /Users/spark/git/service-model-promotion/docker-compose.yml
metadata:
  module_name: "docker-compose.docker-compose"
  language: "yaml"
  provenance: "code-derived"
  source_name: "mps"
---
# Docker-Compose Module

**Related files:**
- `/Users/spark/git/service-model-promotion/docker-compose.yml`

# Docker Compose Configuration: MPS and Secure Registry

## Overview

This module is a Docker Compose configuration file (`docker-compose.yml`) that defines a multi-container application stack consisting of two services:

1. **`mps`** — The main application service (labeled as "MPS", associated with a "promotion" service based on its file paths), running the SparkBeyond promotion service.
2. **`registry`** — A private, TLS-secured Docker image registry that the MPS service can interact with.

The configuration uses Compose file format **version `3.9`** and is designed to run both services together, wiring them with persistent storage, environment-driven configuration, and health monitoring. Its primary purpose is to deploy the MPS application alongside a secure container registry, enabling the application to push and pull container images in an isolated, self-contained environment.

## Key Concepts

### Environment Variable Interpolation

The file relies heavily on Docker Compose's variable substitution syntax. Three distinct patterns appear throughout:

- **Required variables** — `${VAR:?error message}` forces the variable to be defined at runtime, failing with the given message if it is absent. For example:
  ```yaml
  image: ${DOCKER_REPOSITORY_PREFIX:?Please specify DOCKER_REPOSITORY_PREFIX env var}/...
  ```
  This ensures deployments cannot proceed without the necessary image coordinates.

- **Variables with defaults** — `${VAR:-default}` supplies a fallback when the variable is unset. For example, `REGISTRY_ADDR` defaults to `localhost:5000`, and `LOG_LEVEL` defaults to `INFO`.

- **Optional variables** — `${VAR}` simply passes through whatever value is set (or an empty string). This applies to credentials like `REGISTRY_USER` and `REGISTRY_PASS`.

This pattern makes the same compose file reusable across different environments (development, staging, production) by changing only the environment, not the file itself.

### Named Volumes for Persistence

Two named volumes are declared at the bottom of the file:

- `mps-image-storage` — backs the container storage directory used by the MPS service.
- `registry_data` — backs the registry's image storage.

Named volumes persist data across container restarts and recreations, which is essential for a registry that must retain pushed images and for a service that manages local container images.

### Custom Extension Field

The top-level key `x-deployment` uses the Compose `x-` extension prefix, which Docker Compose ignores during processing:

```yaml
x-deployment:
  appVersion: 1.3.5
```

This is a convention for embedding metadata (here, an application version of `1.3.5`) that external tooling or humans can read without affecting Compose's behavior.

## How It Works

### The MPS Service

The `mps` service is the core application. Several aspects define its behavior:

- **Image reference** — The image name is fully parameterized: `${DOCKER_REPOSITORY_PREFIX}/${MPS_IMAGE}`. Both parts are mandatory, so the operator must specify where the image lives and its name.

- **Privileged mode** — `privileged: true` grants the container elevated host access. This is typically required when a container needs to manage its own container storage or run container tooling internally, consistent with the `mps-image-storage` volume mounted at `/var/lib/containers/`.

- **Port mapping** — Port `8010` is exposed to the host, matching the port referenced in the health check and, presumably, the service's HTTP API.

- **Configuration through environment** — The service is configured entirely through environment variables covering registry connectivity (`REGISTRY_ADDR`, `REGISTRY_USER`, `REGISTRY_PASS`), the registry provider selection (`REGISTRY_PROVIDER`, which the comment notes can be `azure` or `aws`), AWS-specific settings (`AWS_REGISTRY_REGION`), TLS verification (`REGISTRY_VERIFY_CERTIFICATE_SIGNING`), logging (`LOG_LEVEL`), and an operational toggle (`MAINTENANCE_MODE`).

- **Health checking** — Compose periodically probes the service:
  ```yaml
  healthcheck:
    test: ["CMD", "curl", ..., "http://localhost:8010/healthcheck"]
    interval: 60s
    timeout: 10s
    retries: 10
    start_period: 10s
  ```
  Every 60 seconds, `curl` hits the `/healthcheck` endpoint. The container is considered unhealthy only after 10 consecutive failures, and the first 10 seconds after startup are treated as a grace period.

- **Volume mounts** — Three mounts connect the container to host resources and persistent storage:
  - `./promotion.toml` provides application configuration at a fixed in-container path.
  - `./image_archives/` supplies image archive files.
  - The `mps-image-storage` named volume persists container storage under `/var/lib/containers/`.

### The Registry Service

The `registry` service runs the standard `registry:2` image as a TLS-secured private registry:

- **Fixed container name** — `container_name: secure-registry` gives the container a predictable name for reference.

- **HTTPS on port 443** — The registry listens on `443` (`REGISTRY_HTTP_ADDR: :443`) with TLS enabled via `REGISTRY_HTTP_TLS_CERTIFICATE` and `REGISTRY_HTTP_TLS_KEY`, both pointing to certificate files inside the container.

- **Certificate provisioning** — The local `./certs` directory is mounted read-only (`:ro`) at `/certs`, supplying the `server.crt` and `server.key` files the TLS configuration expects.

- **Persistent image storage** — The `registry_data` volume retains pushed images at `/var/lib/registry`.

## Usage Examples

Because this configuration depends on required environment variables, you must define them before starting the stack. A typical `.env` file or exported environment might look like:

```bash
export DOCKER_REPOSITORY_PREFIX=myregistry.example.com/team
export MPS_IMAGE=mps-service:1.3.5
export REGISTRY_PROVIDER=aws
export AWS_REGISTRY_REGION=us-east-1
```

Starting the full stack:

```bash
docker compose up -d
```

If a required variable is missing, Compose halts immediately with the specified message, for example:

```
Please specify MPS_IMAGE env var
```

Before starting, ensure the supporting files exist in the working directory:

- `promotion.toml` — MPS configuration file
- `image_archives/` — directory of image archives
- `certs/server.crt` and `certs/server.key` — TLS materials for the registry

Checking service health:

```bash
docker compose ps
```

The `mps` service will report a health status derived from its `/healthcheck` endpoint.

## Integration

Although no related Python modules were identified, this configuration reveals several integration points within the broader system:

- **MPS ↔ Registry** — The MPS service is configured to talk to a registry through the `REGISTRY_*` environment variables. While `REGISTRY_ADDR` defaults to `localhost:5000`, the bundled `registry` service listens on `443`, so operators wiring MPS to the local secure registry would point `REGISTRY_ADDR` at it explicitly. The `REGISTRY_PROVIDER` variable indicates MPS can alternatively target cloud registries on Azure or AWS.

- **Host filesystem** — The stack integrates with the deploying host through bind mounts for configuration (`promotion.toml`), image archives, and TLS certificates. These must be present on the host for the services to start correctly.

- **SparkBeyond promotion service** — The in-container paths under `/opt/sparkbeyond/service/promotion/` indicate the MPS service is part of the SparkBeyond platform's promotion subsystem, responsible for handling and archiving container images.

- **External tooling and versioning** — The `x-deployment.appVersion` field (`1.3.5`) provides a version marker that deployment pipelines or operators can use to track which application version this configuration corresponds to.