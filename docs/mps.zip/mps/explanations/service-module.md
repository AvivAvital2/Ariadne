---
id: 30d54653-98aa-5277-b1ea-1496620815c0
type: explanation
title: "Service Module"
created_at: 2026-06-06T19:04:35.842359+00:00
updated_at: 2026-06-20T22:55:21.319712+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  module_name: "mps.service"
  language: "python"
  source_name: "mps"
---
# Service Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# Service Module


# `mps.service` Module Documentation

## Overview

The `mps.service` module serves as the central configuration and initialization point for the MPS (Multi-Provider Service) system. Its primary responsibility is to read registry configuration from environment variables and wire together the two core components that the rest of the application depends on:

- A **token manager**, responsible for handling authentication credentials against a container registry.
- An **image manager**, responsible for working with container images using those credentials.

The module exposes a single class, `MPS`, and—importantly—creates a ready-to-use instance of it (`mps`) at import time. This makes the module function as a configured singleton entry point: importing it gives you a fully initialized service object built from the current environment.

## Key Concepts

### Registry Providers

The module is built around the concept of pluggable **registry providers**. A registry provider identifies which container registry backend the service should communicate with. The supported values, read from the `REGISTRY_PROVIDER` environment variable, are:

| Provider | Meaning |
|----------|---------|
| `aws`    | Amazon Elastic Container Registry (uses AWS-specific authentication) |
| `azure`  | Azure container registry |
| `gcp`    | Google Cloud container registry |
| `local`  | A local/self-hosted registry, with configurable TLS certificate verification |
| `export` | A special mode where images are exported to files rather than pushed to a registry |

Each provider selects a different token manager configuration, and an unrecognized value raises an error.

### Token Managers

Two token manager classes are used:

- `TokenManager` — the general-purpose authentication handler, used for `azure`, `gcp`, `local`, and `export`.
- `AWSTokenManager` — a specialized subclass for AWS, which additionally requires a region name.

The return type annotation `TokenManager | AWSTokenManager` reflects this distinction. Because `AWSTokenManager` is presumably a specialization, the module keeps AWS handling separate due to its differing parameter requirements (notably `region_name`).

### Configuration via Environment Variables

All configuration is sourced from environment variables, with `os.getenv` providing defaults of `None`. This keeps the service stateless with respect to configuration files and makes it well-suited to containerized deployments where configuration is injected through the environment.

The relevant variables are:

- `REGISTRY_PROVIDER`
- `REGISTRY_ADDR`
- `REGISTRY_USER`
- `REGISTRY_PASS`
- `AWS_REGISTRY_REGION`
- `REGISTRY_VERIFY_CERTIFICATE_SIGNING`

### Pattern Matching for Dispatch

The module uses Python's structural `match`/`case` statement (Python 3.10+) to dispatch on the provider value. This produces a clean, readable branch-per-provider structure and a clear fallthrough case (`case _:`) for handling invalid input.

## How It Works

### Step 1: Reading Configuration

When an `MPS` instance is constructed, `__init__` reads all configuration from the environment. Note one subtle default: `verify_certificate_signing` defaults to the boolean `True` rather than `None`. This means that if the environment variable is unset, certificate verification is enabled by default.

### Step 2: Selecting and Building a Token Manager

`__init__` calls `get_token_manager()`, which matches on `self.registry_provider`:

- **`aws`** — Constructs an `AWSTokenManager`, passing the registry address, region, and credentials.
- **`azure` / `gcp`** — These share identical handling and construct a standard `TokenManager` with the provider name passed through.
- **`local`** — Requires extra handling for the `verify_certificate_signing` value (see below) before constructing a `TokenManager`.
- **`export`** — Constructs a `TokenManager` pointed at `localhost` with empty credentials, since no real registry authentication is needed when exporting to files.
- **Anything else** — Raises `InvalidRegistryProvider` with a descriptive message listing the valid options.

### Step 3: Normalizing the Certificate Verification Flag

The `local` branch contains an inner `match` to normalize `verify_certificate_signing` into a proper boolean. This is necessary because environment variables always arrive as strings, but the default value is a boolean.

The logic handles three cases:

- A **string** equal to `"true"` or `"false"` (case-insensitive) is converted to a boolean using `json.loads`. A code comment explicitly notes this is safer than using `eval`, since `json.loads` cannot execute arbitrary code.
- An existing **boolean** is passed through unchanged (this covers the default `True`).
- **Anything else** raises a `ValueError` describing the expected values.

This normalization ensures that downstream code always receives a real boolean.

### Step 4: Building the Image Manager

Finally, `__init__` constructs an `ImageManager`, handing it the token manager so it can authenticate, and setting `export_image_as_file=True` only when the provider is `export`. This single flag connects the provider choice to the image manager's behavior, switching it between registry-push mode and file-export mode.

### Step 5: Module-Level Instantiation

The last line of the module:

```python
mps = MPS()
```

creates a configured instance as soon as the module is imported. Consumers import this object rather than constructing their own.

## Usage Examples

Typical usage involves importing the pre-built instance and accessing its managers:

```python
from mps.service import mps

# Use the image manager that was configured from the environment
mps.image_manager.do_something(...)
```

Because configuration is environment-driven, the deployment environment controls behavior. For example, to run in AWS mode:

```bash
export REGISTRY_PROVIDER=aws
export REGISTRY_ADDR=123456789.dkr.ecr.us-east-1.amazonaws.com
export REGISTRY_USER=AWS
export REGISTRY_PASS=...
export AWS_REGISTRY_REGION=us-east-1
```

Or to run in local mode with certificate verification disabled:

```bash
export REGISTRY_PROVIDER=local
export REGISTRY_ADDR=localhost:5000
export REGISTRY_USER=user
export REGISTRY_PASS=secret
export REGISTRY_VERIFY_CERTIFICATE_SIGNING=false
```

## Integration

This module sits at the boundary between configuration and the rest of the MPS system. Its relationships are:

- **`mps.api.token_manager`** — Supplies `TokenManager` and `AWSTokenManager`, the authentication components that `MPS` selects and configures.
- **`mps.api.image_manager`** — Supplies `ImageManager`, which receives the configured token manager and the export flag.
- **`mps.api.errors`** — Supplies `InvalidRegistryProvider`, raised when an unsupported provider is configured.
- **`os`** — Reads all configuration from environment variables.
- **`json`** — Safely parses string boolean values for the certificate verification flag.

By centralizing provider selection and credential setup in one place and exposing a single configured `mps` object, this module gives the rest of the codebase a uniform way to obtain a working image manager without needing to know which registry provider is active or how authentication is set up.

### A Note on Import-Time Side Effects

Because `MPS()` is instantiated at module import time, any configuration error—an invalid `REGISTRY_PROVIDER` or an unparseable `REGISTRY_VERIFY_CERTIFICATE_SIGNING`—will raise an exception during import rather than at first use. This causes misconfiguration to surface early, but it also means the module cannot be imported successfully unless the environment is correctly configured.