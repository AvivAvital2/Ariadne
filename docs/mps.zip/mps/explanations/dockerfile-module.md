---
id: cebf48a1-62eb-5c49-b599-73d68721e845
type: explanation
title: "Dockerfile Module"
created_at: 2026-07-03T05:57:45.193121+00:00
updated_at: 2026-07-03T05:57:45.193130+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Module

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/builder/Dockerfile`

# stage0.Dockerfile — Builder Image Documentation

## Overview

This Dockerfile defines a **builder image** for SparkBeyond's service-promotion pipeline. Its purpose is to produce a self-contained environment capable of compiling, packaging, and deploying Scala/JVM-based prediction services. The image bundles together a broad set of build and deployment tooling:

- A JVM runtime (Amazon Corretto 8)
- The Scala Build Tool (SBT)
- Language runtimes required by SparkBeyond services (R, Python 2, Python 3)
- Container tooling (Docker CLI, Docker Compose)
- Kubernetes tooling (`kubectl`, `helm`)
- AWS CLI and Git

Because it packages everything needed to build and ship a service in one layer, this image is typically used in CI/CD pipelines rather than at runtime. The `stage0` naming convention suggests it is the first stage in a multi-stage build chain: it establishes the toolchain that later stages depend on.

## Key Concepts

### Base Image and Provenance

The image builds `FROM` a previously published SparkBeyond builder image hosted in a private AWS ECR registry:

```dockerfile
FROM 551806661322.dkr.ecr.eu-west-1.amazonaws.com/prediction-server/builder:20200615-2
```

This layering means the current file only adds *incremental* tooling on top of an already-provisioned CentOS 7-based environment. Understanding the base image's contents is important, because much of the OS-level setup (users, groups like `sparkbeyond`, package managers) is assumed to already exist.

The `LABEL` directives record metadata — including the intended published name/tag for this image and its maintainer — which aids traceability in the registry.

### Build Arguments as Version Pins

The `ARG` block centralizes all tool versions at the top of the file:

```dockerfile
ARG SBT_VERSION=1.2.8
ARG DOCKER_VERSION=18.06.2-ce
ARG DOCKER_COMPOSE_VERSION=1.23.1
ARG EMBEDDED_PYTHON3_VERSION=1.0.4
ARG HELM_VERSION=3.2.1
ARG KUBECTL_VERSION=1.18.0
```

This is a deliberate design choice: pinning versions makes builds **reproducible** and makes upgrades a single-line change. The values are interpolated later using `${VAR}` syntax when downloading or installing each tool.

### Private Nexus Repositories

Many packages are pulled not from public mirrors but from SparkBeyond's internal Nexus artifact server (`nexus.dev.sparkbeyond.ai`). This includes custom-built RPMs (embedded JDK, R, NLP tooling) that are specific to the company's platform. This centralization ensures the build only depends on artifacts the organization controls and has vetted.

## How It Works

The Dockerfile executes as a sequence of `RUN` layers, each adding a category of tooling.

### 1. Timezone Normalization

```dockerfile
RUN rm -fr /etc/localtime && ln -s /usr/share/zoneinfo/UTC /etc/localtime
```

The system clock is forced to UTC. This avoids timezone-dependent behavior in builds and logs, a common practice for containers running across regions.

### 2. Package Trust and Repository Setup

The next layer imports GPG keys for CentOS and EPEL and refreshes the CA trust store, then disables the Bintray SBT repository (Bintray was later shut down, and SBT is instead installed from Nexus). Two subsequent layers add the SparkBeyond Nexus repositories.

### 3. Core SparkBeyond RPMs

A single `yum install` pulls in the platform's foundational native packages directly by URL:

- `sparkbeyond-embedded-corretto-jdk` — the pinned Java 8 runtime
- `sparkbeyond-embedded-r` — the embedded R distribution
- `sparkbeyond-shared-tools-mllibdriver`, `wekawrapper`, `local-nlp4j` — machine learning and NLP support libraries
- `libgomp`, `deltarpm` — OS-level dependencies

Each `RUN` that installs packages ends with a cleanup step:

```dockerfile
&& yum -q clean all && rm -rf /var/cache/yum && rm -rf /var/tmp/yum-root-*
```

This is an image-size optimization. Because Docker layers are immutable, deleting caches in the *same* `RUN` command prevents them from being baked into the layer.

### 4. WordNet Data Extraction

One layer performs a targeted extraction rather than a full package install:

```dockerfile
RUN [ ! -d /opt/sparkbeyond/shared/WordNet-3.0/ ] \
    && mkdir /tmp/wordnet-fix && pushd /tmp/wordnet-fix ... \
    && rpm2cpio gdata.rpm | cpio -id ./opt/sparkbeyond/shared/WordNet-3.0/* \
    ... || :
```

Here the WordNet 3.0 lexical database is pulled *out* of a larger `gdata` RPM without installing the whole package. The `rpm2cpio | cpio` pipeline unpacks only the needed subtree, which is then moved into place and reassigned to the `sparkbeyond` group. The leading guard `[ ! -d ... ]` skips the work if WordNet already exists, and the trailing `|| :` ensures the layer does not fail the build if the guard is false — a defensive way to make the step idempotent.

### 5. Python Runtimes

Both an embedded Python 2 and Python 3 (version-pinned via `${EMBEDDED_PYTHON3_VERSION}`) are installed from Nexus. SparkBeyond services rely on these embedded interpreters rather than the system Python.

### 6. Java Alternatives and Developer Tooling

```dockerfile
RUN alternatives --install /usr/bin/java java /opt/sparkbeyond/embedded/amazon-corretto-.../bin/java 1
```

This registers the embedded Corretto JDK with the system `alternatives` mechanism so that `java` on the `PATH` resolves to it.

The following layer installs the remaining developer tooling in one pass:

- **SBT** (pinned) for Scala builds
- **AWS CLI** for interacting with AWS services
- **Git** (from the WANdisco repository, which provides a newer Git than CentOS 7's default)
- **Docker CLI** — downloaded as a static binary tarball and extracted into `/usr/bin`
- **Docker Compose** — downloaded as a single binary and made executable

The Docker CLI is installed *without* a daemon; it is expected to talk to a Docker socket mounted from the host, a standard "Docker-in-CI" pattern.

### 7. Kubernetes Tooling

Two layers install `helm` (pinned) and `kubectl` (pinned) by downloading official release binaries. These enable the image to deploy services to Kubernetes clusters as part of a promotion pipeline.

### 8. SBT Repository Configuration

The final configuration layers create `~/.sbt` and write a `repositories` file:

```dockerfile
RUN echo $'[repositories]\n  local\n  sparkbeyond-ivy-proxy-releases: ...' > ~/.sbt/repositories
```

This redirects SBT's dependency resolution away from the public Maven Central and toward SparkBeyond's Nexus proxies. Doing so gives the organization control over dependency provenance and improves build reliability by avoiding direct dependence on public repositories.

### 9. Default Command

```dockerfile
CMD ["/bin/bash"]
```

The image defaults to an interactive shell. This reflects its role as a general-purpose build environment: CI systems typically override this to run specific build commands, while developers can drop into a shell for debugging.

## Usage Examples

Building the image with the default pinned versions:

```bash
docker build -f stage0.Dockerfile -t service-promotion/builder:local .
```

Overriding a version at build time (using the `ARG` values):

```bash
docker build -f stage0.Dockerfile \
  --build-arg SBT_VERSION=1.3.13 \
  -t service-promotion/builder:sbt-1.3.13 .
```

Running the image to build a Scala project, mounting the host Docker socket so the bundled Docker CLI can operate:

```bash
docker run --rm -it \
  -v "$PWD:/workspace" -w /workspace \
  -v /var/run/docker.sock:/var/run/docker.sock \
  service-promotion/builder:local \
  sbt compile
```

## Integration

This module sits at the base of a build-and-promotion toolchain:

- **Upstream dependency:** It extends the `prediction-server/builder` ECR image, inheriting its OS setup and base configuration.
- **Artifact source:** It is tightly coupled to SparkBeyond's Nexus (`nexus.dev.sparkbeyond.ai` and `nexus.sparkbeyond.com`), which supplies both the custom RPMs and the SBT dependency proxies. The image will not build successfully without network access to these internal servers.
- **Downstream use:** As a `stage0` image, it is intended to be referenced by later build stages or CI jobs that compile SparkBeyond services and deploy them to Kubernetes via `helm`/`kubectl`.
- **Runtime expectations:** The Docker CLI included here expects an external Docker daemon (host socket), and the Kubernetes tools expect valid cluster credentials/context to be supplied at run time.

In short, this Dockerfile is the foundation that assembles every tool a SparkBeyond service needs to go from source code to a deployed container, standardizing versions and artifact sources across the pipeline.