---
id: 5a034010-a839-5777-81b8-5595890cffe0
type: explanation
title: "Defaults Module"
created_at: 2026-06-06T19:04:10.736441+00:00
updated_at: 2026-06-06T19:04:10.736456+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/defaults.json
metadata:
  module_name: "mps.defaults.defaults"
  language: "json"
  source_name: "mps"
---
# Defaults Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/defaults.json`

# `mps.defaults.defaults` — Configuration Defaults

## Overview

The `mps.defaults.defaults` module is a JSON configuration file that defines default values for the MPS (likely a "Microservice/Promotion Service") subsystem. Rather than containing executable logic, this module serves as a centralized declaration of filesystem paths and naming conventions used throughout the promotion service.

Its purpose is to provide a single source of truth for environment-specific settings—particularly directory locations and repository prefixes—so that these values are not hardcoded across the codebase. By isolating defaults into a dedicated configuration file, the system can be reconfigured without changing application code.

## Key Concepts

The configuration is organized as a JSON object with three top-level sections, each representing a distinct concern:

- **`local_image_cache`** — Defines where the service caches images locally.
- **`exported_images`** — Defines where the service writes images that have been exported.
- **`general`** — Holds general-purpose settings that do not belong to a more specific category.

A consistent pattern is used: settings that represent filesystem locations are grouped under a named key and expose their value through a `path` property. This nesting (`section → path`) creates a predictable, namespaced structure that is easy to extend with additional properties later without breaking existing consumers.

## How It Works

Because this is a declarative configuration file, there is no runtime control flow within the module itself. Instead, it works through the following relationships:

### 1. Local Image Cache

```json
"local_image_cache": {
    "path": "/opt/sparkbeyond/service/promotion/cache/"
}
```

This section identifies the directory where the promotion service stores cached images locally. The path points to a `cache/` subdirectory under the promotion service's working area. Code that reads or writes cached images would look up this value rather than referencing the literal path.

### 2. Exported Images

```json
"exported_images": {
    "path": "/opt/sparkbeyond/service/promotion/exported_images/"
}
```

This section defines the output location for exported images. The separation between the cache directory and the export directory reflects two different lifecycle stages: transient cached artifacts versus deliberately exported deliverables.

### 3. General Settings

```json
"general": {
    "repo_prefix": "sparkbeyond/predbox"
}
```

The `general` section currently holds a single `repo_prefix` value, `sparkbeyond/predbox`. This is the kind of value typically prepended to image or repository names (for example, when constructing a fully qualified container image reference such as `sparkbeyond/predbox/<image-name>`). Grouping it under `general` signals that it is a broadly applicable default rather than one tied to caching or exporting.

## Usage Examples

This module is consumed by reading the JSON structure and accessing the nested keys. A typical access pattern in Python would look like:

```python
import json

with open("mps/defaults/defaults.json") as f:
    defaults = json.load(f)

cache_dir = defaults["local_image_cache"]["path"]
export_dir = defaults["exported_images"]["path"]
repo_prefix = defaults["general"]["repo_prefix"]
```

In practice, applications often layer user-provided or environment-specific configuration on top of these defaults, so that the values here act as fallbacks when no override is supplied.

## Integration

No directly related modules were identified, but the structure of the configuration indicates how it fits into the broader system:

- The paths all share the `/opt/sparkbeyond/service/promotion/` base, indicating this configuration belongs to a **promotion service** deployed under a standard service layout.
- The `repo_prefix` value (`sparkbeyond/predbox`) suggests integration with a **container image registry or repository**, where the prefix namespaces images produced or consumed by the service.
- Components responsible for **image caching**, **image export**, and **image naming/publishing** are the likely consumers of these defaults.

Because the values are externalized here, any module that needs to know where images live or how repositories are named should resolve those answers through this configuration rather than embedding the paths or prefixes directly.

---

> **Note:** This documentation is based solely on the contents of the configuration file. The exact consumers and the runtime behavior that uses these defaults are defined elsewhere in the codebase and are not visible from this module alone.