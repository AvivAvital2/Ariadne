---
id: 2e49bf8d-ab45-5f6c-99d9-19fb1be09627
type: explanation
title: "Promotion Module"
created_at: 2026-06-06T19:04:41.752506+00:00
updated_at: 2026-06-20T22:55:21.270627+00:00
source_files:
  - /Users/spark/git/service-model-promotion/promotion.conf
metadata:
  module_name: "promotion"
  language: "hocon"
  source_name: "mps"
---
# Promotion Module

**Related files:**
- `/Users/spark/git/service-model-promotion/promotion.conf`

# Promotion Module


# Promotion Module Configuration

## Overview

This document describes the configuration for the `promotion` module, defined using [HOCON](https://github.com/lightbend/config/blob/main/HOCON.md) (Human-Optimized Config Object Notation). HOCON is a superset of JSON commonly used for application configuration, valued for its flexibility with nested keys, dotted-path notation, and human-friendly syntax.

The configuration in this module governs two distinct concerns:

1. **Outbound HTTP connectivity** — proxy settings used when the module needs to reach external services (for example, pulling container images from a registry).
2. **Model promotion behavior** — the set of base container images available for prediction servers and the authentication policy for the model promotion workflow.

The "promotion" concept here refers to the process of moving a trained model into a runnable, deployable form by associating it with a base image of the prediction server.

## Key Concepts

The configuration is organized into three logical groups, each rooted at a top-level key.

### 1. HTTP Client Proxy (`httpClient.proxy`)

This group controls how the module routes outbound HTTP traffic through a proxy server. It is further subdivided:

- **`httpClient.proxy.config`** — the network location of the proxy (host and port).
- **`httpClient.proxy.authentication`** — credentials for proxies that require a login.

A notable design pattern here is the separation of *enablement flags* from *configuration values*. The proxy can be configured (host/port set) independently of whether it is actually turned on. This allows operators to leave default configuration in place while toggling behavior with a single boolean.

### 2. Base Images (`baseImage`)

This group maps named build variants to fully-qualified container image references. The structure is hierarchical:

```
baseImage.<version>.<variant> = <image-reference>
```

Here the version is `3-0-0` and there are four variants. The dotted notation produces a nested structure equivalent to:

```json
{
  "baseImage": {
    "3-0-0": {
      "aio":     "...prediction-server:prod-3.0.0-aio",
      "osm":     "...prediction-server:prod-3.0.0-osm",
      "gdata":   "...prediction-server:prod-3.0.0-gdata",
      "minimal": "...prediction-server:prod-3.0.0"
    }
  }
}
```

The version key uses dashes (`3-0-0`) rather than dots, because in HOCON a dot is a path separator. Using `3.0.0` would create three levels of nesting (`3` → `0` → `0`) instead of a single version key.

### 3. Model Promotion Authentication (`modelpromotion.auth`)

A single toggle that determines whether the model promotion workflow requires authentication.

## How It Works

### Proxy resolution

When the module makes an outbound HTTP request, it consults the `httpClient.proxy` configuration:

```hocon
httpClient.proxy.enabled = false
httpClient.proxy.config.host = ""
httpClient.proxy.config.port = 3128
```

- If `httpClient.proxy.enabled` is `false` (the default shown here), requests go directly to their destination and the host/port values are ignored.
- If enabled, traffic is routed through the proxy at `config.host:config.port`. The default port `3128` is the conventional port for the Squid proxy server.

Proxy authentication is handled as a second, independent layer:

```hocon
httpClient.proxy.authentication.enabled = false
httpClient.proxy.authentication.username = ""
httpClient.proxy.authentication.password = ""
```

Even when a proxy is enabled, credentials are only applied if `authentication.enabled` is `true`. This nested toggling supports proxies that allow anonymous access as well as those requiring login.

### Base image selection

The `baseImage` entries define the catalog of prediction server images the promotion process can build upon. Each variant targets a different deployment scenario:

| Variant | Image tag suffix | Intended use |
|-----------|------------------|--------------|
| `aio` | `prod-3.0.0-aio` | "All-in-one" — a fully-featured image bundling all components |
| `osm` | `prod-3.0.0-osm` | A build oriented around OSM-specific functionality |
| `gdata` | `prod-3.0.0-gdata` | A build oriented around geographic/general data support |
| `minimal` | `prod-3.0.0` | A lean image with only core functionality |

All images are pulled from the private registry `reg.sparkbeyond.com` under the `sparkbeyond/prediction-server` repository. During promotion, the system selects the appropriate variant and uses the resolved image reference as the foundation for the deployable model artifact.

> **Note:** The variant naming maps human-readable keys (`aio`, `minimal`) to the underlying image tags. The `minimal` variant maps to the *untagged* base (`prod-3.0.0`), while the others append a descriptive suffix.

### Authentication toggle

```hocon
modelpromotion.auth.enabled = off
```

HOCON treats `off` as a boolean equivalent to `false` (likewise, `on` equals `true`). As configured, authentication for the model promotion workflow is disabled. This is consistent with the proxy flags, which use the more conventional `true`/`false` form — HOCON accepts both styles interchangeably.

## Usage Examples

These values are not invoked directly; they are read by the application at startup. The typical access pattern, regardless of the consuming language, follows the dotted path:

- To check whether to use a proxy: read `httpClient.proxy.enabled`.
- To retrieve the all-in-one image for version 3.0.0: read `baseImage.3-0-0.aio`.
- To determine if promotion auth is active: read `modelpromotion.auth.enabled`.

To enable a proxy with authentication, an operator would override the relevant flags and supply values:

```hocon
httpClient.proxy.enabled = true
httpClient.proxy.config.host = "proxy.internal.example.com"
httpClient.proxy.authentication.enabled = true
httpClient.proxy.authentication.username = "svc-account"
httpClient.proxy.authentication.password = "..."
```

Because HOCON supports layered overrides, these changes are typically placed in an environment-specific file that takes precedence over these defaults rather than editing this file directly.

## Integration

This module sits between the prediction-server image catalog and the deployment process:

- **Container registry (`reg.sparkbeyond.com`)** — the `baseImage` references point at a private registry. The proxy settings exist in part to support environments where outbound access to this registry must traverse a corporate proxy.
- **Prediction server** — the images referenced are tagged builds of the prediction server (`prod-3.0.0`), tying this configuration to a specific server release. Promoting a model to a new version would involve adding a new `baseImage.<version>` block.
- **Authentication layer** — the `modelpromotion.auth.enabled` flag integrates with whatever security mechanism guards the promotion workflow, allowing it to be disabled in trusted environments (such as local development or isolated networks).

No other modules were identified as directly related to this configuration. Its scope is self-contained: it provides the connectivity and image-catalog inputs that the promotion process consumes at runtime.