---
id: ee0cdd22-447f-5c77-b64a-449d48c1dc71
type: explanation
title: "Promote Module"
created_at: 2026-06-06T19:04:29.604882+00:00
updated_at: 2026-06-20T22:55:21.265588+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  module_name: "mps.routers.promote"
  language: "python"
  source_name: "mps"
---
# Promote Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# Promote Module


# `mps.routers.promote` — Model Promotion Router

## Overview

The `mps.routers.promote` module defines a FastAPI router that exposes HTTP endpoints for **model promotion** — the process of packaging a machine learning model into a container image, pushing it to a registry, and making it available for deployment.

Within the larger MPS (Model Promotion Service) system, this module serves as the **HTTP interface layer**. It is responsible for:

- Receiving model artifacts and metadata from clients over HTTP
- Translating request data (query parameters, headers, request body) into structured parameters
- Delegating the actual build, push, and registry operations to the `mps.service.mps` service object
- Returning appropriate HTTP responses based on the outcome

The module deliberately keeps its own logic thin: it parses and validates input, then hands work off to lower-level managers (`image_manager`, `token_manager`) accessed through the shared `mps` service instance.

## Key Concepts

### The `router` object

```python
router = APIRouter()
```

All endpoints are attached to an `APIRouter`, FastAPI's mechanism for grouping related routes. This router is presumably mounted into a parent application elsewhere in the codebase, which is the standard way to organize endpoints across multiple modules.

### The shared `mps` service

The module relies on a single imported service object, `mps`, which acts as a façade over several subsystems:

- `mps.image_manager` — builds, pushes, and checks for the existence of container images
- `mps.token_manager` — provides registry connection details (e.g. `mps.token_manager.registry`)
- `mps.registry_provider` — a string indicating the deployment mode (notably the `'export'` mode)

This centralizes infrastructure concerns so that the router only orchestrates them.

### Schema-based parameter parsing

The module uses two complementary approaches to validate input:

1. **FastAPI's native model binding** — for `ImageParams` in `is_image_exists`, FastAPI automatically parses and validates the request body against the schema.
2. **`marshmallow_dataclass` schema loading** — for `PromoteParams` in `promote`, parameters are parsed manually from the URL query string and loaded through a generated Marshmallow schema:

```python
schema = class_schema(PromoteParams)()
params: PromoteParams = schema.load(params_dict)
```

This second approach is necessary because the `promote` endpoint reserves its request body for the binary model file, leaving configuration to be passed as query parameters and headers.

### `PlainTextResponse` as a uniform return type

Nearly every code path returns a `PlainTextResponse` with an explicit status code. This gives the endpoints predictable, simple HTTP semantics — image paths, error messages, and success indicators are all returned as plain text rather than JSON.

## How It Works

### `get_promotion_status` — endpoint stub

```python
@router.get("/modelpromotion/promotion")
async def get_promotion_status():
    # Todo
    pass
```

This `GET` endpoint is a placeholder. It is registered but not yet implemented, indicating planned functionality for querying promotion status.

### `is_image_exists` — checking for an existing image

This `POST` endpoint determines whether a model has already been promoted as an image. It receives an `ImageParams` body (containing `project_id` and `revision`) and checks two export variants:

```python
for export_type in ['compose', 'standalone']:
    tag = await construct_model_id(
        project_id=f'{params.project_id}_{export_type}',
        revision=params.revision
    )
    full_image_path = f'{mps.token_manager.registry}/{repo_prefix}/{tag}'
    image_path = await mps.image_manager.get_if_image_exists(full_image_path)
    if image_path is not None:
        return PlainTextResponse(content=f'{image_path}', status_code=200)
```

The logic:

1. For each export type (`compose` and `standalone`), it constructs a unique model identifier (tag) by combining the project ID, the export type suffix, and the revision.
2. It assembles the full image path from the registry host, a configured repository prefix, and the tag.
3. It asks the image manager whether that image exists.
4. The **first** match short-circuits the loop and returns the image path with a `200` status.
5. If neither variant exists, the endpoint returns a `404`.

This dual-check reflects that a project may be promoted in either a Docker Compose or standalone form.

### `promote` — building and pushing a model image

This is the core endpoint. It accepts the project ID and revision as path parameters, with configuration in the query string and headers, and the model artifact as the raw request body.

**Step 1 — Parse query parameters.**
Because FastAPI's automatic binding isn't used here, the query string is parsed manually:

```python
params_dict = parse_qs(str(request_obj.url).split("?")[-1])
params_dict = {key: value[0] if len(value) == 1 else value for key, value in params_dict.items()}
```

`parse_qs` returns each value as a list; the dictionary comprehension flattens single-element lists into scalar values. The result is then validated by loading it into a `PromoteParams` schema.

**Step 2 — Resolve the base image.**
Based on the requested release version and several feature flags (`linkedDataCore`, `openStreetMap`, `dockerCompose`), the module selects an appropriate base image:

```python
base_image_id = await resolve_base_image_id(
    base_images=base_images,
    release_version=params.epsReleaseNumber,
    use_linked_data_core=params.linkedDataCore,
    use_open_street_map=params.openStreetMap,
    use_docker_compose=params.dockerCompose
)
```

If no matching configuration exists, a `NoConfigurationFoundError` is caught and surfaced as a `500` response. This is an explicit decision to return a server-error status for unsupported configuration combinations.

**Step 3 — Extract supplementary metadata from headers.**
Three custom headers carry optional metadata:

- `auxImages` — a comma-separated list of auxiliary images, split into a list.
- `X-Algorithm-Whitelist` — read and logged, but currently unused (the parsing line is commented out).
- `X-ANNOTATIONS` — a JSON object that is transformed into a list of `key=value` strings:

```python
annotations_list = None \
    if annotations_string is None \
    else [f"{k}={v}" for k, v in json.loads(annotations_string).items()]
```

**Step 4 — Persist the model artifact to a temporary file.**
The model is uploaded as the raw request body and written asynchronously to a temporary directory:

```python
with TemporaryDirectory() as dir_name:
    file_path = os.path.join(dir_name, 'model.zip')
    async with aiofiles.open(file_path, 'wb') as out_file:
        await out_file.write(await request_obj.body())
```

Using `TemporaryDirectory` ensures the file is automatically cleaned up after the build completes, and `aiofiles` keeps the write non-blocking within the async event loop.

**Step 5 — Build and push the image.**
While the temporary directory still exists, the image manager performs the build and push:

```python
image = await mps.image_manager.build_and_push(
    base_image=base_image_id,
    project_id=project_id,
    revision=revision,
    temp_directory=dir_name,
    model_filename=model_filename,
    use_docker_compose=params.dockerCompose,
    auxiliary_image_list=auxiliary_image_list,
    annotations_list=annotations_list
)
```

All previously gathered inputs — the resolved base image, identifiers, the temp directory, and the auxiliary/annotation lists — are passed through.

**Step 6 — Return a response based on registry provider mode.**

```python
match mps.registry_provider:
    case 'export':
        match isinstance(image, PlainTextResponse):
            case True: return image
            case False: return PlainTextResponse(content=os.path.basename(image), status_code=200)
    case _:
        return PlainTextResponse(content=f"{image}")
```

The response handling branches on the registry provider:

- In **`'export'` mode**, `build_and_push` may itself return a `PlainTextResponse` (for example, an error already formatted for the client). If so, it is passed through unchanged. Otherwise, `image` is treated as a file path and only its base filename is returned with a `200` status.
- In **all other modes**, the result is returned as plain text directly.

The nested `match` on `isinstance(...)` is an idiomatic-if-unusual way of expressing a boolean branch using Python's structural pattern matching.

## Usage Examples

### Checking whether an image already exists

```http
POST /modelpromotion/promotion/image/exists
Content-Type: application/json

{
  "project_id": "weather-forecast",
  "revision": "v3"
}
```

A `200` response with the image path means the image exists; a `404` means it does not.

### Promoting a model

```http
POST /modelpromotion/promotion/weather-forecast/v3?epsReleaseNumber=2024.1&dockerCompose=true&linkedDataCore=false&openStreetMap=true
auxImages: helper/sidecar:1.0,helper/proxy:2.1
X-ANNOTATIONS: {"owner": "team-a", "tier": "gold"}

<binary contents of model.zip as the request body>
```

The endpoint resolves the base image, packages the uploaded model, builds and pushes the resulting image, and returns either the resulting image reference or the base filename of the exported artifact.

## Integration

This module sits at the boundary between external clients and the MPS service internals:

- **`mps.api.utils`** provides `resolve_base_image_id` (base image selection logic) and `construct_model_id` (tag construction).
- **`mps.api.schemas`** defines the `PromoteParams` and `ImageParams` data structures that validate incoming requests.
- **`mps.api.errors`** supplies `NoConfigurationFoundError`, the domain-specific exception handled in `promote`.
- **`mps.api.config`** supplies `base_images` (the catalog of selectable base images) and `repo_prefix` (the repository namespace used when constructing image paths).
- **`mps.service.mps`** is the central service object through which all build, push, existence-check, and registry operations are performed.
- **`mps.api.logger`** provides structured debug logging throughout the promotion flow.

Externally, the router depends on **FastAPI** for routing and responses, **`aiofiles`** for non-blocking file writes, **`marshmallow_dataclass`** for query-parameter validation, and the standard library's **`json`**, **`os`**, **`tempfile`**, and **`urllib.parse`** modules for data handling.

In summary, `mps.routers.promote` is the request-handling entry point for model promotion. It validates and normalizes client input, prepares model artifacts on disk, and orchestrates the build-and-push workflow, while leaving the heavy lifting to the shared `mps` service.