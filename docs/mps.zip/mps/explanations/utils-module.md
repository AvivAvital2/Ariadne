---
id: e138e1e4-6b6c-5f98-8652-4cc66cd008ca
type: explanation
title: "Utils Module"
created_at: 2026-06-06T19:04:03.001635+00:00
updated_at: 2026-06-20T22:55:21.303265+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  module_name: "mps.api.utils"
  language: "python"
  source_name: "mps"
---
# Utils Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# Utils Module


# `mps.api.utils` Module Documentation

## Overview

The `mps.api.utils` module provides a collection of utility helpers that support an asynchronous API service responsible for building and deploying containerized models. The functions here cover several distinct concerns that recur throughout the larger system:

- Executing external shell commands asynchronously (notably for interacting with tooling like Docker)
- Communicating with HTTP services through a customized `requests.Session`
- Validating and parsing version strings
- Resolving the correct base Docker image for a given configuration
- Extracting uploaded model archives from disk
- Verifying connectivity to a container registry

Most functions in this module are `async`, which signals that the module is designed to run within an asynchronous (likely FastAPI-based) application. The presence of `HTTPException` and the FastAPI import confirm that some of these utilities are meant to be called directly inside request handlers, where raising an `HTTPException` produces a structured error response.

---

## Key Concepts

### Custom HTTP Session: `MPSSession`

`MPSSession` subclasses `requests.Session` to add a convenience behavior: every request is resolved against a configured `base_url`. This is a common pattern when an application repeatedly talks to a single host but wants to issue requests with relative paths.

```python
def request(self, method, uri, *args, **kwargs):
    return super().request(method, urljoin(self.base_url, uri), *args, **kwargs)
```

By overriding `request`, the class affects all HTTP verbs (`get`, `post`, etc.), since those methods internally delegate to `request`. The session also stores `auth` and `verify` defaults, which is useful when interacting with registries that may use self-signed certificates or require credentials.

### Asynchronous Subprocess Execution

The module relies on `asyncio.create_subprocess_exec` to spawn child processes without blocking the event loop. The `stream_reader` coroutine reads stdout and stderr line-by-line, and `asyncio.gather` lets both streams be consumed concurrently. This concurrency prevents a deadlock that can occur when one stream fills its buffer while the program is only reading the other.

### Configuration-Driven Image Resolution

The `resolve_base_image_id` function encodes a small decision table that maps feature flags to a named "flavour" of base image. This is a data-driven design: rather than nesting `if/else` branches, the combinations are stored in a dictionary keyed by a tuple of booleans.

### Error Handling via Domain-Specific Exceptions

The module imports custom exceptions from `mps.api.errors` (`SelfSignedCertificate`, `UnreachableContainerRegistry`, `NoConfigurationFoundError`). Raising these specific types allows callers to distinguish failure modes and respond accordingly, rather than catching generic exceptions. The repeated use of `from None` suppresses the original traceback chaining, producing cleaner error messages for the caller.

---

## How It Works

### Running Commands — `run_command`

This is one of the most heavily used helpers. Its workflow is:

1. If the command is provided as a string, it is split on spaces into a list of arguments.
2. A subprocess is launched with both stdout and stderr piped.
3. A nested `stream_reader` coroutine reads each stream fully, decoding bytes and stripping whitespace into a list of lines.
4. Both streams are read concurrently with `asyncio.gather`.
5. The process is awaited to completion and its exit code captured.
6. If the exit code is non-zero and `supress_errors` is `False`, a `RuntimeError` is raised including the command, stderr, and exit code for debugging.

The return value is a tuple of `(stdout_lines, stderr_lines, exit_code)`.

> **Note:** A module-level `stream_reader` is listed among the module's functions, but in the source shown it is defined as a nested function inside `run_command`. Splitting commands on plain spaces means arguments containing spaces (such as quoted paths) are not handled — callers needing that should pass a pre-split list.

### Constructing Model IDs — `construct_model_id`

This function joins a `project_id` and `revision` into a Docker-style identifier of the form `project:revision`. Because it is intended for use inside an API handler, failures are surfaced as a `400` `HTTPException` rather than a generic exception.

### Parsing Versions — `parse_version_number`

A regular expression (`\d\.\d{1,2}\.\d`) enforces a `major.minor.patch` format. The function uses Python's structural pattern matching (`match`/`case`) to branch on whether the string matched:

- If it did not match, an exception is raised describing the expected format.
- If it matched, the return depends on `as_config_key`:
  - When `True`, the dots are replaced with hyphens to produce a configuration key (e.g., `1.20.3` → `1-20-3`).
  - When `False`, a tuple of integers is returned (e.g., `(1, 20, 3)`), which is convenient for version comparisons.

### Resolving Base Images — `resolve_base_image_id`

This function selects a base image from a nested `base_images` dictionary:

1. The release version is converted into a config key (e.g., `1-20-3`).
2. A flavour is chosen from the decision table based on `use_linked_data_core` and `use_open_street_map`. If `use_docker_compose` is set, the flavour is forced to `"minimal"`.
3. If both the release key and the flavour exist in the dictionary, the corresponding image ID is returned.
4. Otherwise a `NoConfigurationFoundError` is raised.

The flavour mapping is:

| linked_data_core | open_street_map | flavour |
|------------------|-----------------|---------|
| True             | True            | `aio`     |
| False            | True            | `osm`     |
| True             | False           | `gdata`   |
| False            | False           | `minimal` |

### Extracting Models — `extract_model`

This function unpacks an uploaded model archive:

1. It extracts the outer ZIP file into the destination directory.
2. In a `finally` block, the original ZIP file is deleted regardless of success — ensuring temporary uploads do not accumulate.
3. It then attempts to extract a nested `model.ser` file (treated as a second ZIP). If `model.ser` is not actually a valid ZIP archive, a `BadZipFile` exception is caught and logged at debug level rather than failing the whole operation.

### Verifying Registry Connectivity — `verify_connection_to_container_registry`

This is a resilient connectivity check designed to wait for a registry to become available, retrying up to 30 times with a 10-second sleep between attempts:

1. Insecure-request warnings are disabled up front.
2. On each attempt, it issues a `GET` to the registry's `/v2/` endpoint (the Docker Registry v2 API root).
3. Error handling distinguishes several cases:
   - **SSL error from a local provider with verification enabled:** raises `SelfSignedCertificate` with guidance to disable certificate verification.
   - **Other SSL errors:** falls back to attempting plain HTTP; if that succeeds, the HTTP base URL is returned, otherwise it sleeps and retries.
   - **Connection error:** sleeps and retries.
   - **Success (no exception):** returns the HTTPS base URL.
4. If all attempts are exhausted, an `UnreachableContainerRegistry` exception is raised.

This logic reflects a real-world scenario where a registry may still be starting up or may be reachable only over HTTP.

### Deriving File Names — `docker_image_to_file_name`

A small helper that converts a Docker image tag into a filesystem-friendly name. It strips the registry/path prefix using `rpartition("/")`, then replaces the `:` separating image and tag with an underscore. For example, `registry.local/myimage:1.0` becomes `myimage_1.0`.

---

## Usage Examples

### Running a command

```python
stdout, stderr, code = await run_command("docker images")
if code == 0:
    print("\n".join(stdout))
```

### Selecting a base image

```python
image_id = await resolve_base_image_id(
    base_images=config,
    release_version="1.20.3",
    use_linked_data_core=True,
    use_open_street_map=False,
    use_docker_compose=False,
)
# Resolves the "gdata" flavour for release key "1-20-3"
```

### Using the custom session

```python
session = MPSSession(base_url="https://registry.local", verify=False)
response = session.get("/v2/")  # Requests https://registry.local/v2/
```

---

## Integration

This module sits at the support layer of the `mps.api` package and connects to several parts of the broader system:

- **`mps.api.errors`** supplies the domain-specific exceptions raised here, allowing higher-level handlers to react to specific failure conditions.
- **`fastapi`** integration appears through `HTTPException`, indicating these utilities are called within API endpoints where HTTP-aware error responses are appropriate.
- **`.logger`** provides a shared `logger` instance, so output from these helpers is consistent with the rest of the application's logging.
- **`asyncio`** is foundational: nearly every function is a coroutine, reinforcing that this module is part of an async application that must avoid blocking the event loop, especially around subprocess execution and network retries.
- **Container tooling and registries** are central themes — the command runner, image-name helpers, base-image resolution, and registry verification together support a workflow that builds Docker images and pushes/pulls them from a registry.

In summary, `mps.api.utils` is the glue between the API's request handlers and the external systems (subprocesses, container registries, and the filesystem) that the service depends on, packaged into reusable, async-friendly helpers.