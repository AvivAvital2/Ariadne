---
id: cc7fe755-2859-5768-832c-4cbb2ca5b220
type: explanation
title: "Image Manager Module"
created_at: 2026-06-06T19:03:38.361268+00:00
updated_at: 2026-06-20T22:55:21.300322+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  module_name: "mps.api.image_manager"
  language: "python"
  source_name: "mps"
---
# Image Manager Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# Image Manager Module


# `mps.api.image_manager` — Module Documentation

## Overview

The `image_manager` module provides the `ImageManager` class, which is responsible for the full lifecycle of container images within the MPS (Model Pipeline Service) API. Its primary responsibility is to **build container images that package machine-learning models, and then make those images available** either by pushing them to a remote container registry or by exporting them as compressed archive files on local storage.

In practice, the module bridges the gap between a model artifact (delivered as a zip file) and a deployable container image. It wraps several command-line container tools — `buildah` (image building), `skopeo` (image copying/inspection), and `pigz` (parallel gzip compression) — and orchestrates them asynchronously.

The class is designed to operate in two distinct modes that fundamentally change its behavior:

- **Registry mode** (the default): images are pushed to a remote container registry (AWS ECR, Azure, GCP, or a local registry).
- **File export mode** (`export_image_as_file=True`): images are serialized to `.tar.gz` archives on the local filesystem instead of being pushed anywhere.

This dual-mode design is a recurring theme throughout the module, and nearly every method branches on `self.export_image_as_file`.

---

## Key Concepts

### Dual operating modes

The `export_image_as_file` flag, set at construction time, determines whether the manager interacts with a remote registry or writes archive files. Many methods use Python's `match` statement to switch between the two code paths:

```python
match self.export_image_as_file:
    case True:
        ...  # archive/file logic
    case _:
        ...  # registry logic
```

This is the most important concept to internalize: almost every behavior has two implementations.

### Token managers

The constructor accepts a `token_manager` that is either a `TokenManager` or an `AWSTokenManager`. The token manager abstracts away registry authentication and supplies registry-related properties:

- `registry` — the registry hostname/address
- `verify_certificate_signing` — whether TLS verification should be enabled
- `session` — used for registry catalog/tag queries and (for AWS) repository creation
- `login()` — refreshes credentials

`AWSTokenManager` is treated specially in `push_image`, where the code refreshes credentials and creates the ECR repository on demand before pushing.

### The image cache as a fast-path / Bloom filter

The class uses an `AsyncPersistentImageCache` (`self.local_image_cache`) to record which images are known to exist, mapping a tag (or archive path) to a timestamp. The cache is used as an optimization to avoid expensive remote registry lookups.

A notable design detail is described in `check_if_image_archive_exists_on_local_storage`: in registry mode the cache behaves as an authoritative record, but in **file export mode the cache is treated like a Bloom filter** — a cache hit is verified against the actual filesystem because the local filesystem is more accessible and may be modified outside MPS's control.

### Command execution

All external tooling is invoked through the `run_command` helper, which returns a `(stdout, stderr, exit_code)` tuple. The `supress_errors` parameter controls whether failures are tolerated (useful for "does this exist?" probes where a non-zero exit code is an expected outcome).

---

## How It Works

### Building and publishing an image (`build_and_push`)

This is the central method of the module. It orchestrates the entire flow from model artifact to published image:

1. **Validate mode compatibility.** If the caller requests Docker Compose export while the manager is in file-export mode, the operation is rejected with an HTTP 500 `PlainTextResponse`, because Compose bundles require a real registry.

2. **Construct the image tag.** A model ID is derived from `project_id` and `revision` via `construct_model_id`, and the full image path is assembled as `{registry}/{repo_prefix}/{tag}`.

3. **Check the cache first.** `get_if_image_exists` is called. If the image already exists, it is returned immediately and no build happens — a key optimization.

4. **Prepare the build context.** The model zip is extracted into a `models` directory, and a `Dockerfile` is generated dynamically. The Dockerfile starts `FROM base_image` and copies the extracted model into a path keyed by `model_name`:

   ```
   FROM {base_image}
   COPY --chown=predict:sparkbeyond models ./models/{model_name}
   ```

5. **Handle annotations.** A list of annotations is folded into a string of `--annotation` flags. A comment in the code notes deliberately omitting a trailing space to avoid shell-parsing problems.

6. **Build the image.** The Dockerfile is written to a temporary file and `buildah bud` is invoked with `--layers` (layer caching) and the assembled flags. If the build fails, the captured stderr is wrapped in an `UnavailableImage` exception.

7. **Publish the image.** Depending on the mode, `push_image` either pushes to the registry or exports an archive. In file-export mode the returned archive path replaces `docker_image_path`.

8. **Handle Docker Compose (optional).** If requested, auxiliary images are uploaded and an environment file is generated via `generate_env_file`.

9. **Cache the result** and return the image path.

### Publishing (`push_image`)

This method has two completely separate code paths:

- **File export:** Uses `skopeo copy` to convert the locally stored image (`containers-storage:`) into a `docker-archive:` tarball, then compresses it with `pigz`, returning the `.gz` path.

- **Registry push:** Uses `skopeo copy` from container storage to the `docker://` destination. TLS verification flags are conditionally added. When using `AWSTokenManager`, it re-authenticates and proactively creates the ECR repository (catching `RepositoryAlreadyExistsException` if it already exists), since ECR requires repositories to exist before pushing.

### Existence checks (`get_if_image_exists` and helpers)

`get_if_image_exists` runs two checks concurrently with `asyncio.gather`:

- whether the image is recorded in the local cache, and
- whether the image actually exists (on remote registry, or as an archive on disk).

It then reconciles the two results using a truth table:

| In cache | Actually exists | Action |
|----------|----------------|--------|
| True | True | Return the image path (cache valid) |
| True | False | Remove the stale entry from cache |
| False | True | Add to cache, return path |
| False | False | Return `None` (must build) |

This self-healing reconciliation keeps the cache consistent with reality.

The supporting probes are:

- `check_if_image_tag_exists_in_cache` — looks up the tag in the listing of locally known images.
- `check_if_image_exists_on_remote_registry` — runs `skopeo inspect docker://...` and treats exit code 0 as "exists".
- `check_if_image_archive_exists_on_local_storage` — confirms the archive file exists *and* contains the expected tag (the Bloom-filter behavior described earlier).

### Listing and maintenance

- `list_local_images` parses `buildah images` output into a name→ID mapping, skipping `<none>:<none>` entries, optionally translating tags into archive paths in export mode, and refreshes the cache timestamps for everything it finds.
- `delete_local_images` removes non-release and dangling images via `buildah rmi`, then clears the cache.
- `get_size_of_images` sums the sizes reported by `buildah`, using `humanfriendly.parse_size` to convert human-readable sizes (e.g. `"1.2 GB"`) into bytes.

### Registry catalog queries (`list_pushed_images`)

Queries the registry's `/v2/_catalog` endpoint, filters repositories by `repo_prefix`, and fetches each repository's tag list from `/v2/{repo}/tags/list`. Connection failures raise `UnreachableContainerRegistry`, and a missing `repositories` key raises `UnableToObtainPushedImagesFromContainerRegistry`.

### Auxiliary images and env file generation

- `upload_missing_auxiliary_images` determines which auxiliary images are not already present in the registry and pushes them concurrently. If any push fails, it raises `UnableToUploadOneOrMoreImages`.
- `generate_env_file` reads `template/template.env` and substitutes `DOCKER_REPOSITORY_PREFIX=` and `EPS_IMAGE=` placeholders with concrete values using a compiled regex. This produces the environment configuration for a Docker Compose deployment.

---

## Usage Examples

### Constructing and building an image

```python
from mps.api.token_manager import AWSTokenManager
from mps.api.image_manager import ImageManager

manager = ImageManager(token_manager=AWSTokenManager(...), export_image_as_file=False)
await manager.login()

result = await manager.build_and_push(
    base_image="my-base:latest",
    project_id="myproject_team",
    revision="v3",
    temp_directory="/tmp/build123",
    model_filename="model.zip",
    use_docker_compose=False,
    auxiliary_image_list=None,
    annotations_list=["org.opencontainers.image.source=https://example.com"],
)
# result is either an image path (str) or a PlainTextResponse on error
```

### File export mode

```python
manager = ImageManager(token_manager=local_token_manager, export_image_as_file=True)
# build_and_push now returns a path like /exports/myproject_v3.tar.gz
```

> **Note:** The return type of `build_and_push` can be either a `str` (the image path) or a `PlainTextResponse`. Callers must account for both, since the method returns an HTTP response directly in certain error conditions.

---

## Integration

This module sits at the heart of the MPS API's image pipeline and integrates with several other components:

- **`mps.api.token_manager`** — supplies authentication and registry metadata. The polymorphic acceptance of `TokenManager | AWSTokenManager` lets the same `ImageManager` work across cloud providers, with AWS-specific repository creation handled inline.
- **`mps.api.image_cache`** — the `AsyncPersistentImageCache` provides a persistent, async-context-managed store used for fast existence checks and self-healing reconciliation.
- **`mps.api.utils`** — provides the command runner (`run_command`), model-handling helpers (`extract_model`, `construct_model_id`), and the tag-to-filename converter (`docker_image_to_file_name`).
- **`mps.api.errors`** — the module raises a set of domain-specific exceptions (`UnavailableImage`, `UnableToUploadOneOrMoreImages`, `UnreachableContainerRegistry`, `UnableToObtainPushedImagesFromContainerRegistry`) that callers (typically FastAPI route handlers) translate into HTTP responses.
- **`mps.api.config`** — supplies `repo_prefix` and `exported_image_path`, the configuration values that define naming and export locations.
- **FastAPI** — the method's ability to return a `PlainTextResponse` indicates that `ImageManager` is invoked directly from API route handlers, blending business logic with HTTP responses for certain error and Compose-generation cases.
- **External CLI tools** — `buildah`, `skopeo`, and `pigz` are hard dependencies invoked through subprocess execution; the host environment must have these installed at the expected paths.

The heavy use of `asyncio` (gathering concurrent existence checks, parallel image pushes, and async context-managed cache access) means `ImageManager` is built to run efficiently within an asynchronous web service, overlapping slow I/O operations such as registry inspections and command execution.