---
id: d60b8bba-fbce-505a-a408-52f92c7e4e29
type: explanation
title: "  Main   Module"
created_at: 2026-06-06T19:03:07.581837+00:00
updated_at: 2026-06-20T22:55:21.280739+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  module_name: "mps.__main__"
  language: "python"
  source_name: "mps"
---
#   Main   Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

#   Main   Module


# `mps.__main__` — Application Entry Point

## Overview

The `mps.__main__` module is the executable entry point for the **SparkBeyond Model Promotion Service (MPS)**, a FastAPI-based web application. When the `mps` package is run as a script (for example, via `python -m mps`), this module is responsible for:

1. Loading the service's version metadata.
2. Constructing and configuring the FastAPI application instance.
3. Registering the application's HTTP route handlers (routers).
4. Authenticating the service before it begins serving requests.
5. Starting the ASGI web server (Uvicorn) to handle incoming traffic.

In short, this module wires together the application's component pieces and launches the server. It contains relatively little business logic itself; instead, it orchestrates configuration and startup.

## Key Concepts

### The `__main__` Module Convention

In Python packages, a `__main__.py` file makes a package directly runnable. Executing `python -m mps` causes Python to run this module's top-level code, with `__name__` set to `"__main__"`. The `if __name__ == '__main__':` guard at the bottom ensures the server only starts when the package is invoked directly, not when its `app` object is merely imported (for example, by an external ASGI server).

### FastAPI Application and Routers

The application is built on **FastAPI**. Rather than defining all endpoints in one place, the module follows the common pattern of splitting route definitions across multiple **router** modules:

- `basic` — likely core/general endpoints
- `promote` — model promotion functionality
- `maintenance` — maintenance-related endpoints

Each router is attached to the central `app` via `include_router`. This separation keeps related endpoints grouped together and keeps the entry point itself focused on assembly rather than endpoint logic.

### Configuration Through the Environment

The module reads several settings from environment variables, a common approach for containerized or deployment-flexible services. These include the network binding (`SERVICE_HOST`, `SERVICE_PORT`) and a `MAINTENANCE_MODE` toggle that alters documentation URLs.

### Build-Time Version Metadata

The service version is read from an external file (`conf/build.info`) rather than being hardcoded. This decouples the application code from version information, allowing the version to be injected during the build process.

## How It Works

### 1. Loading the Version Tag

At import time, the module opens `conf/build.info`, parses it as JSON, and extracts the `version_tag` field:

```python
with open('conf/build.info', 'r') as f:
    version = json.load(f)['version_tag']
```

This value is later passed to FastAPI so the version appears in the application's metadata and auto-generated API documentation. Note that this file must exist relative to the working directory at startup, or the module will fail to import.

### 2. Building the FastAPI Configuration

A `params` dictionary holds the FastAPI constructor arguments, starting with a title and the loaded version. If `MAINTENANCE_MODE` is enabled, the module overrides the default documentation endpoints to live under a `/modelpromotion/` path prefix:

```python
if os.environ.get('MAINTENANCE_MODE', 'False').lower() == 'true':
    params['docs_url'] = '/modelpromotion/docs'
    params['redoc_url'] = '/modelpromotion/redoc'
    params['openapi_url'] = '/modelpromotion/openapi.json'
```

The environment value is read defensively: it defaults to `'False'` if unset and is lowercased before comparison, so values like `True`, `true`, or `TRUE` are all accepted.

### 3. Creating the App and Registering Routers

The configured parameters are unpacked into the FastAPI constructor, and the three routers are registered:

```python
app = FastAPI(**params)
app.include_router(basic.router, include_in_schema=False)
app.include_router(promote.router, include_in_schema=False)
app.include_router(maintenance.router)
```

A notable detail is `include_in_schema=False` on the `basic` and `promote` routers. This hides those endpoints from the generated OpenAPI schema and interactive documentation. Only the `maintenance` router's endpoints appear in the published schema. This suggests the maintenance endpoints are the documented, externally-facing surface, while the others remain functional but undocumented.

### 4. Authentication Before Startup

The `main` coroutine performs a single task — logging in via a token manager:

```python
async def main():
    await mps.token_manager.login()
```

This establishes authentication credentials (an access token) before the service begins handling requests. Because login is an asynchronous operation, it is defined as a coroutine and executed with `asyncio.run`.

### 5. Launching the Server

Within the `__main__` guard, the startup sequence runs:

```python
if __name__ == '__main__':
    asyncio.run(main())
    service_port = os.environ.get("SERVICE_PORT", 8010)
    service_host = os.environ.get("SERVICE_HOST", "0.0.0.0")
    uvicorn.run(app, host=service_host, port=service_port)
```

The order is significant: `asyncio.run(main())` completes the login *before* the server starts accepting connections. The host and port are read from the environment, defaulting to `0.0.0.0:8010`. Binding to `0.0.0.0` makes the server reachable on all network interfaces, which is typical for services running inside containers.

Finally, `uvicorn.run` starts the ASGI server with the assembled `app`, beginning the request-handling loop.

> **Note on the port type:** When `SERVICE_PORT` is set, `os.environ.get` returns a string, whereas the default `8010` is an integer. Uvicorn generally accepts a numeric string, but this is a mixed-type default worth being aware of.

## Usage Examples

### Running the Service

Because the package defines `__main__`, it is launched as a module:

```bash
python -m mps
```

### Configuring via Environment Variables

```bash
# Bind to a specific port and enable maintenance documentation paths
SERVICE_HOST=0.0.0.0 \
SERVICE_PORT=9000 \
MAINTENANCE_MODE=true \
python -m mps
```

### Required Files

Before running, ensure `conf/build.info` exists relative to the working directory and contains a `version_tag`:

```json
{ "version_tag": "1.4.2" }
```

## Integration

This module sits at the top of the MPS application's dependency graph and ties together several subsystems:

- **`mps.routers` (`basic`, `promote`, `maintenance`)** — Provide the actual HTTP endpoint implementations. The entry point simply registers their `router` objects.
- **`mps.service.mps`** — Supplies the `token_manager`, used here for authentication. The login step indicates the service depends on an external authenticated system (presumably a SparkBeyond platform API).
- **FastAPI** — Provides the application framework and OpenAPI documentation generation.
- **Uvicorn** — Acts as the ASGI server that runs the FastAPI app in production.
- **`os` / `json`** — Used for environment-based configuration and reading build metadata, respectively.

The design centralizes startup concerns (configuration, authentication, server launch) in one place while delegating endpoint logic to dedicated router modules and authentication state to the `mps.service` layer. This keeps the entry point readable and makes the application's startup behavior easy to trace.