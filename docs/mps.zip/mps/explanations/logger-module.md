---
id: fff418b1-b8fb-5168-acf4-f90a38455be9
type: explanation
title: "Logger Module"
created_at: 2026-06-06T19:03:44.608911+00:00
updated_at: 2026-06-20T22:55:21.274362+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  module_name: "mps.api.logger"
  language: "python"
  source_name: "mps"
---
# Logger Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# Logger Module


# `mps.api.logger` Module Documentation

## Overview

The `mps.api.logger` module provides centralized logging configuration for the **Model Promotion Service (MPS)**. It establishes a consistent logging setup that writes log output to both a rotating file and the console, while customizing the format of log messages and filtering out noise from health-check endpoints.

The module's primary deliverable is a ready-to-use, module-level `logger` object that other parts of the application can import and use directly. Configuration is driven by an environment variable (`LOG_LEVEL`), making the logging verbosity adjustable without code changes.

## Key Concepts

The module is built around three classes, each addressing a distinct logging concern.

### `CustomLogger` — Aligned Message Formatting

`CustomLogger` subclasses Python's built-in `logging.Logger`. Its sole job is to inject an extra field called `delimiter` into every log record. This delimiter is a calculated amount of whitespace used to align log messages regardless of the length of the log level name.

The calculation lives in the overridden `makeRecord` method:

```python
extra['delimiter'] = ' ' * (8 - len(logging.getLevelName(log_level)) + 1)
```

Because level names vary in length (`INFO` is 4 characters, `WARNING` is 7), this logic pads the space after the level name so that messages start at the same column. For example, output appears as:

```
INFO:     Service started
WARNING:  Disk space low
```

The number `8` serves as a fixed alignment width, and the `delimiter` field is later referenced in the log format string.

### `SkipHealthFilter` — Suppressing Health-Check Noise

`SkipHealthFilter` subclasses `logging.Filter` and is used to reduce log clutter caused by frequent, uninteresting requests. Health checks, ping endpoints, and favicon requests typically flood access logs without providing useful diagnostic information.

The filter defines a list of endpoints to exclude:

```python
filtered_endpoints = [
    "/healthcheck",
    "/modelpromotion/ping"
    "/favicon.ico"
]
```

> **Note:** Two of the strings above are missing a separating comma, so Python concatenates them into a single element (`"/modelpromotion/ping/favicon.ico"`). As written, the list contains two entries rather than three.

The `filter` method returns a boolean indicating whether a record should be passed through. It evaluates each endpoint against the record's message and combines the results, returning `False` to suppress matching records.

### `Logger` — The Configuration Assembler

`Logger` is the orchestrating class. It does not subclass anything; instead, it wires together handlers, formatters, and filters into a fully configured logger instance, which it exposes through `self.logger`.

## How It Works

### Step 1: Register the Custom Logger Class

When a `Logger` is constructed, the first action is:

```python
logging.setLoggerClass(CustomLogger)
```

This tells the `logging` framework to instantiate `CustomLogger` (rather than the default `logging.Logger`) for loggers created afterward. This is what enables the `delimiter` field to be populated on every record.

### Step 2: Configure the File Handler

A `RotatingFileHandler` is created with sensible defaults:

- **Destination:** `log/mps.log`
- **Rotation size:** 5 MB (`5 * 1024 * 1024`)
- **Backups kept:** 2

When the active log file reaches 5 MB, it is rotated and a new file is started, keeping up to two older copies. This prevents unbounded log growth on disk.

The handler uses the format string `'%(levelname)s:%(delimiter)s%(message)s'`, which combines the level name, the alignment delimiter from `CustomLogger`, and the message.

### Step 3: Configure the Console Handler

A `StreamHandler` is created with the same level and the same format string, so console output mirrors the file output. This dual-handler approach is common: the console aids live development and container log capture, while the file provides durable history.

### Step 4: Attach the Health Filter

The filter is applied specifically to the `uvicorn.access` logger:

```python
logging.getLogger("uvicorn.access").addFilter(SkipHealthFilter())
```

This targets the access logs produced by Uvicorn (the ASGI server commonly used to run FastAPI applications), suppressing health-related request entries at their source rather than on the MPS logger itself.

### Step 5: Build the Named Logger

Finally, a logger is retrieved by `component_name`, the two handlers are attached, and the log level is set:

```python
_logger = logging.getLogger(component_name)
_logger.addHandler(file_handler)
_logger.addHandler(console_handler)
_logger.setLevel(log_level)
self.logger = _logger
```

The resulting logger is stored on `self.logger` for retrieval by callers.

### Step 6: Module-Level Initialization

At import time, the module reads the `LOG_LEVEL` environment variable (defaulting to `'INFO'`) and validates it with a `match` statement:

```python
level = os.environ.get('LOG_LEVEL', 'INFO')
match level:
    case 'INFO' | 'WARN' | 'ERROR' | 'FATAL' | 'DEBUG':
        logger = Logger('model_promotion', log_level=level).logger
    case _:
        raise RuntimeWarning(...)
```

If the value is one of the recognized levels, a `Logger` is instantiated with the component name `'model_promotion'`, and its configured logger is exposed as the module-level `logger`. Any unrecognized value raises a `RuntimeWarning`, causing import to fail loudly rather than silently using an invalid configuration.

> **Note:** The level read from the environment is a string. While the standard library accepts level names as strings in some contexts, the type hint on `Logger.__init__` (`log_level: logging`) suggests a logging-level value was originally intended. Be aware of this when reasoning about how the level is applied.

## Usage Examples

In most cases, other modules should simply import the pre-configured logger:

```python
from mps.api.logger import logger

logger.info("Model promotion started")
logger.warning("Promotion candidate missing metadata")
logger.error("Failed to promote model", exc_info=True)
```

To adjust verbosity, set the environment variable before the application starts:

```bash
export LOG_LEVEL=DEBUG
```

If a separate component needs its own configured logger, the `Logger` class can be instantiated directly:

```python
from mps.api.logger import Logger
import logging

my_logger = Logger('my_component', log_level=logging.DEBUG).logger
my_logger.debug("Component-specific message")
```

## Integration

This module sits at the foundation of the MPS application's observability layer and connects to several parts of the system:

- **Application code:** Any module within MPS imports the shared `logger` object to emit consistent, well-formatted log messages.
- **Uvicorn / ASGI server:** By attaching `SkipHealthFilter` to the `uvicorn.access` logger, this module integrates with the web server's request-logging pipeline to suppress health-check noise. This strongly implies MPS runs as a web service behind Uvicorn.
- **Environment configuration:** Through `os.environ`, the module ties into deployment configuration, allowing operators to control log verbosity per environment (e.g., `DEBUG` in development, `INFO` in production).
- **Filesystem:** The `RotatingFileHandler` writes to `log/mps.log`, so deployments must ensure the `log/` directory exists and is writable.

### Design Considerations

- **Single source of truth:** Centralizing configuration in one module ensures every component logs with identical formatting and behavior.
- **Dual output:** Logging to both console and file supports both containerized log aggregation and persistent on-disk history.
- **Fail-fast validation:** Rejecting unknown `LOG_LEVEL` values at import time surfaces misconfiguration early rather than producing unexpected logging behavior at runtime.