---
id: fc56af89-0a51-54c9-a670-ef6689749097
type: explanation
title: "Dockerfile Module"
created_at: 2026-07-03T05:58:33.140632+00:00
updated_at: 2026-07-03T05:58:33.140644+00:00
source_files:
  - /Users/spark/git/service-model-promotion/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Module

**Related files:**
- `/Users/spark/git/service-model-promotion/builder/Dockerfile`

# `stage0.Dockerfile` — Build Environment Documentation

## Overview

`stage0.Dockerfile` defines a container image that serves as a foundational build and tooling environment. As suggested by the name "stage0," this image is intended to be a base layer — the initial stage from which subsequent build steps or images can be derived.

The resulting image bundles together a specific set of tools:

- A **Python 3.12.7** runtime with the Poetry dependency manager
- **AWS CLI** for interacting with Amazon Web Services
- **Podman**, **git**, **curl**, **pigz**, and other system utilities
- A pinned **Node.js 18.14.0** runtime installed via `nvm`
- The **typora-parser** npm package for processing Typora-flavored Markdown

In short, this Dockerfile produces a polyglot environment capable of running Python projects, executing AWS operations, building containers, and parsing Markdown documents.

## Key Concepts

### Base Image Selection

```dockerfile
FROM python:3.12.7-bookworm
```

The image is built on the official `python:3.12.7-bookworm` image. This means:

- A specific Python version (3.12.7) is guaranteed, avoiding drift across builds.
- The `bookworm` tag ties the underlying OS to **Debian 12 (Bookworm)**, so `apt` is the package manager and Debian package conventions apply.

Pinning both the Python patch version and the Debian release is a deliberate choice for reproducibility — builds will behave consistently regardless of when or where they run.

### Version Pinning

Version pinning appears throughout the file:

- `python:3.12.7-bookworm` (base image)
- `poetry==1.8.3` (exact Poetry version)
- `NODE_VERSION="18.14.0"` (exact Node.js version)

Pinning reduces the risk of unexpected behavior when upstream releases change. The trade-off is that these versions must be updated manually to receive security patches or new features.

### Environment Variables as Configuration

Two `ENV` directives shape the build:

```dockerfile
ENV NODE_VERSION="18.14.0"
ENV PATH="${PATH}:/root/.nvm/versions/node/v18.14.0/bin/"
```

`NODE_VERSION` is used later to construct paths dynamically, keeping the version defined in a single place. The `PATH` modification ensures the `nvm`-installed Node.js binaries are discoverable both during subsequent build steps and at container runtime.

## How It Works

The Dockerfile executes in a sequence of layered steps.

### Step 1: Establish the Base

The build starts from the pinned Python/Debian image, giving us Python 3.12.7 and Debian's `apt` tooling out of the box.

### Step 2: Install Python and System Tooling

```dockerfile
RUN apt update \
    && pip3 install poetry==1.8.3 awscli \
    && apt update --allow-unauthenticated \
    && apt install --reinstall debian-archive-keyring \
    && apt install -y podman git curl pigz \
    && curl -LsS https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh | bash -s --
```

This single `RUN` command chains several operations together. Combining them into one layer is a common Docker optimization: each `RUN` creates a new image layer, so grouping related commands keeps the image smaller and the layer history cleaner.

The sequence does the following:

1. **`apt update`** — Refreshes the package index.
2. **`pip3 install poetry==1.8.3 awscli`** — Installs the Poetry dependency manager (pinned) and the AWS CLI via Python's package installer.
3. **`apt update --allow-unauthenticated`** and **`apt install --reinstall debian-archive-keyring`** — These two steps address APT repository signing keys. Reinstalling `debian-archive-keyring` restores or refreshes the trusted keys used to verify Debian packages. The `--allow-unauthenticated` flag is a workaround that permits the index refresh to proceed even when key verification would otherwise fail — a step that becomes necessary precisely because the keyring is being repaired.
4. **`apt install -y podman git curl pigz`** — Installs system utilities: `podman` (a container engine), `git` (version control), `curl` (HTTP client), and `pigz` (a parallel gzip implementation, often used to speed up compression).
5. **`curl ... | bash -s --`** — Downloads and runs the `nvm` (Node Version Manager) installer script directly from GitHub, setting up `nvm` under the root user's home directory.

### Step 3: Install Node.js and typora-parser

```dockerfile
ENV PATH="${PATH}:/root/.nvm/versions/node/v18.14.0/bin/"
RUN cd /root/.nvm/versions/node/v$NODE_VERSION/bin \
    && . ~/.bashrc \
    && npm install -g typora-parser
```

First, the `PATH` is extended so the Node.js binaries installed by `nvm` are on the executable search path.

The subsequent `RUN` command:

1. Changes into the directory where the pinned Node.js version's binaries live, using the `$NODE_VERSION` variable to build the path.
2. Sources `~/.bashrc` (`. ~/.bashrc`) so that `nvm`'s shell functions and environment are loaded — `nvm` normally configures itself through shell initialization files.
3. Runs `npm install -g typora-parser` to install the `typora-parser` package globally, making it available system-wide within the container.

Because `nvm` installs Node.js versions into `/root/.nvm/versions/node/`, the explicit path referencing `v$NODE_VERSION` ties directly back to the `NODE_VERSION` environment variable defined earlier.

## Usage Examples

### Building the Image

From the directory containing the Dockerfile:

```bash
docker build -f stage0.Dockerfile -t stage0 .
```

### Running the Image Interactively

```bash
docker run -it --rm stage0 bash
```

Inside the running container, the bundled tools are available:

```bash
python3 --version      # Python 3.12.7
poetry --version       # 1.8.3
aws --version          # AWS CLI
node --version         # v18.14.0
typora-parser          # Markdown parsing tool
```

### Using as a Base for Another Image

Since this is a "stage0" image, another Dockerfile can build on top of it:

```dockerfile
FROM stage0
COPY . /app
WORKDIR /app
RUN poetry install
```

## Integration

Although no directly related modules were identified, the file name and toolset suggest how it fits into a larger system:

- **Base image role**: The `stage0` naming convention indicates this image is meant to be referenced by later build stages or downstream Dockerfiles, providing them a consistent, pre-provisioned toolchain.
- **Python project support**: The presence of Poetry implies the broader system contains Python projects managed with Poetry-based dependency resolution.
- **Cloud and container operations**: The inclusion of the AWS CLI and Podman suggests workflows that deploy to AWS and/or build container images from within this environment.
- **Documentation tooling**: `typora-parser` points to a workflow that processes Typora Markdown files, likely as part of documentation generation or content processing.

By packaging all of these tools into a single reproducible image, `stage0.Dockerfile` gives every downstream consumer a uniform environment, eliminating "works on my machine" discrepancies across development, CI, and deployment.