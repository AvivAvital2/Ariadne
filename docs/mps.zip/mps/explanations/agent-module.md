---
id: db4332ad-701f-5ec8-bf6b-757f2f613d1d
type: explanation
title: "Agent Module"
created_at: 2026-06-06T19:02:58.278705+00:00
updated_at: 2026-07-03T05:57:28.980593+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent.yaml
metadata:
  module_name: ".ci.agent.agent"
  language: "yaml"
  provenance: "code-derived"
  source_name: "mps"
---
# Agent Module

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent.yaml`

# CI Agent Pod Definition (`.ci.agent.agent`)

## Overview

This module defines a **Kubernetes Pod** used as a Jenkins CI build agent. Despite being labeled as a `.yaml` module, it is a standard Kubernetes manifest (`apiVersion: v1`, `kind: Pod`) that describes a single, multi-container pod. This pod acts as an ephemeral build environment: when a CI job runs, Jenkins schedules this pod, executes build steps inside its containers, and tears the pod down afterward.

The design follows the common Jenkins Kubernetes plugin pattern, where each container in the pod provides a specialized tool (compilation, image building, package building, cloud CLI access, etc.), and the pipeline selects the appropriate container for each stage of the build.

## Key Concepts

### Multi-Container Build Agent

Rather than baking every tool into a single image, this pod dedicates one container per concern. This is a deliberate separation-of-concerns pattern:

| Container | Purpose |
|-----------|---------|
| `builder` | Primary build container (Scala/SBT and Java compilation, Docker client access) |
| `kaniko` | Builds container images without a Docker daemon |
| `jenkins-trigger-decision-maker` | Custom logic to decide whether downstream jobs should be triggered |
| `rpmbuild` | Builds RPM packages |
| `dind` | Docker-in-Docker daemon providing a Docker engine |
| `aws` | AWS CLI operations |

All containers share the pod's lifecycle, network namespace, and any shared volumes.

### The "sleep container" idiom

Most containers use:

```yaml
command:
  - cat
tty: true
```

This is a well-known Jenkins-Kubernetes trick. The `cat` command (with a TTY attached) blocks indefinitely without consuming resources, keeping the container alive and idle. Jenkins then uses `kubectl exec`-style commands to run build steps inside the container on demand. Without this, the containers would exit immediately since their images have no long-running default process.

The `kaniko` container uses `/busybox/cat` instead of `cat` because the distroless Kaniko image only ships a busybox shell at that path.

### Shared Data Between Containers

Two volumes coordinate work across containers:

- **`shared-data`** — an `emptyDir` (ephemeral scratch space) mounted at `/artifacts` in both `builder` and `kaniko`. This is how the `builder` hands off build outputs to `kaniko` for image construction.
- **`docker-config`** — a `configMap` (`dp-ecr-docker-config`) mounted into `kaniko` at `/kaniko/.docker/config.json`. This supplies registry credentials so Kaniko can push images to ECR.

## How It Works

### 1. Pod Scheduling

The pod carries the label `application: "mps"`, which allows other tooling to identify or select these agent pods. When a Jenkins pipeline requests an agent using this template, Kubernetes schedules the pod on a node with enough capacity.

### 2. Container Startup

Each container starts and immediately enters an idle state:

- The `cat`/`/busybox/cat` containers block, waiting for exec commands.
- The `dind` container starts a real Docker daemon (its default entrypoint), which is *not* overridden.

### 3. The Docker-in-Docker Relationship

The `builder` container is configured to talk to a Docker daemon over TCP:

```yaml
- name: DOCKER_HOST
  value: tcp://localhost:2375
```

The `dind` container provides that daemon. Because all containers in a pod share the same network namespace, `localhost:2375` inside `builder` reaches the daemon running in `dind`. TLS is explicitly disabled to simplify this local connection:

```yaml
- name: DOCKER_TLS_CERTDIR
  value: ""
```

The `dind` container runs with `privileged: true`, which is required for Docker-in-Docker to manage cgroups, mount filesystems, and run nested containers.

### 4. Build Execution and Artifact Handoff

A typical flow the pod enables:

1. The `builder` container compiles the project (using SBT/Java) and writes outputs to `/artifacts`.
2. The `kaniko` container reads those same artifacts from `/artifacts` (shared via `shared-data`) and builds a container image, pushing it to ECR using credentials from the mounted `docker-config`.
3. The `jenkins-trigger-decision-maker` container evaluates whether downstream jobs should run.
4. The `rpmbuild` and `aws` containers handle packaging and cloud operations as needed.

### JVM and Resource Tuning

The `builder` container receives explicit JVM tuning through environment variables:

- **`SBT_OPTS`** and **`JAVA_OPTS`** set heap limits (`-Xmx12G`), stack size, and code cache. The `-XX:+UseCGroupMemoryLimitForHeap` flag makes the JVM respect the container's cgroup memory limit rather than the host's total memory — an important setting for JVM workloads inside containers.

Resource requests and limits reflect the relative weight of each container:

- `builder`: requests 2 CPU / 13Gi memory, limits 8 CPU / 15Gi — the heaviest consumer.
- `jenkins-trigger-decision-maker`: modest requests (0.5 CPU / 2Gi).
- Others (`kaniko`, `rpmbuild`, `dind`, `aws`) declare no explicit resources and rely on cluster defaults.

The `builder`'s JVM heap ceiling (12G) sits below its memory limit (15Gi), leaving headroom for non-heap memory (thread stacks, metaspace, off-heap buffers) to avoid OOM kills.

### Image Sourcing and Pull Policies

Most images come from a private ECR registry (`551806661322.dkr.ecr.eu-west-1.amazonaws.com`), while `dind` uses the public Docker Hub image and `aws` uses an internal Nexus mirror.

Pull policies differ intentionally:

- `builder`: `imagePullPolicy: Always` — always fetches the latest image for its date-tagged version, ensuring build environment freshness.
- `kaniko`, `jenkins-trigger-decision-maker`, `rpmbuild`: `IfNotPresent` — reuse cached images when available, reducing pull overhead for pinned versions.

### Security Contexts

Two containers set explicit security contexts:

- `jenkins-trigger-decision-maker` runs as a non-root user (`runAsUser: 1000`), following least-privilege practices.
- `dind` runs `privileged: true` out of necessity for the Docker daemon.

## Usage

This manifest is not applied manually in typical use. Instead, it is referenced by a Jenkins pipeline as a pod template. A `Jenkinsfile` would select containers by name for each build stage, for example:

```groovy
container('builder') {
    sh 'sbt clean assembly'
}
container('kaniko') {
    sh '/kaniko/executor --context /artifacts --destination <ecr-repo>:<tag>'
}
```

Jenkins provisions the pod from this template, runs the stages, and deletes the pod when the job finishes.

## Integration

- **Jenkins Kubernetes plugin**: Consumes this pod template to provision ephemeral build agents.
- **AWS ECR**: The source registry for most container images and the push target for images built by Kaniko.
- **`dp-ecr-docker-config` ConfigMap**: An external cluster resource that must exist in the same namespace; it provides the Docker credentials Kaniko needs.
- **Kubernetes cluster**: Must permit privileged containers (for `dind`) and provide nodes with sufficient capacity for the `builder`'s substantial memory request.

No directly related modules were identified, but this pod is functionally coupled to the CI pipeline definitions that reference it and to the ConfigMap and registries listed above.