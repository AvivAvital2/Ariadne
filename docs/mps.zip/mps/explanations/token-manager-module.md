---
id: f70c46ea-8dbc-5f92-9bdd-e21352677ef4
type: explanation
title: "Token Manager Module"
created_at: 2026-06-06T19:03:56.278785+00:00
updated_at: 2026-06-20T22:55:21.283607+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  module_name: "mps.api.token_manager"
  language: "python"
  source_name: "mps"
---
# Token Manager Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# Token Manager Module


# `mps.api.token_manager` Module Documentation

## Overview

The `mps.api.token_manager` module handles **authentication and credential management for container registries**. Its core responsibility is to authenticate against a registry (such as a local registry, Azure Container Registry, or AWS Elastic Container Registry), persist the resulting credentials to Docker's standard configuration file, and establish an authenticated session object (`MPSSession`) for subsequent API calls.

The module defines two classes:

- **`TokenManager`** — the base class supporting `local` and `azure` registry providers (with placeholders for `gcp`).
- **`AWSTokenManager`** — a subclass specializing the login flow for AWS ECR, where authentication tokens are dynamically retrieved and expire periodically.

This separation reflects an important design distinction: most registries accept static username/password credentials, while AWS ECR requires exchanging long-lived AWS credentials for short-lived registry authorization tokens.

---

## Key Concepts

### Provider-Based Behavior

The `provider` attribute (`"local"`, `"azure"`, `"aws"`, `"export"`, etc.) drives nearly all conditional logic in the module. It determines:

- Whether HTTP or HTTPS is used (`self.schema`)
- Whether authentication is required (`self.use_auth`)
- Which required configuration parameters must be present
- How credentials are obtained and refreshed

### Docker Config File as Credential Store

Rather than inventing a custom credential format, the module writes to the standard Docker config location:

```
~/.docker/config.json
```

Credentials are stored under the `auths` key, with the username and password base64-encoded into a single `auth` string — exactly the format the Docker CLI itself uses. This means credentials managed by this module are interoperable with standard Docker tooling.

### Required Parameter Validation

The constructor validates configuration up front using a small but notable pattern. It builds dictionaries mapping environment-variable-style names to actual values, then merges them depending on the provider:

```python
match self.provider:
    case 'local': required_params = local_required_params
    case _: required_params = dict(sorted((local_required_params | authenticated_required_params).items()))
```

For `local` providers, only registry-level parameters are required. For all other providers, username and password are also mandatory. Any `None` values trigger a `MissingConfigValues` error before the object can be used, ensuring misconfiguration is caught early.

### Async Concurrency and Locking

`AWSTokenManager` uses an `asyncio.Lock` to guard token retrieval. Because ECR tokens are fetched from a shared `boto3` client and written to a shared config file, the lock prevents concurrent coroutines from interleaving and corrupting the credential file or making redundant token requests.

---

## How It Works

### Initialization (`TokenManager.__init__`)

When a `TokenManager` is created, it:

1. Stores connection details (`registry`, `username`, `password`, `provider`, etc.).
2. Computes the Docker config file path from the user's home directory.
3. Determines the URL scheme:
   ```python
   self.schema = 'http' if ':' in self.registry and self.provider == 'local' else 'https'
   ```
   The inline comment explains the reasoning: a production local registry binds port 443 externally (`443:5000`), so HTTP is only used when the registry address explicitly includes a port (e.g. `localhost:5000`).
4. Decides whether authentication is needed. For `local` registries with no credentials, `use_auth` is `False`; otherwise it is `True`.
5. Validates required parameters and raises `MissingConfigValues` if anything is missing.

### Credential Encoding (`get_credentials`)

This method produces the Docker-compatible credential dictionary. It base64-encodes the `username:password` pair and nests it under the registry URL:

```python
{
    'auths': {
        '<registry>': { 'auth': '<base64 of user:pass>' }
    }
}
```

### Reading Credentials Back (`get_username_and_password`)

The base implementation reverses the process: it reads the config file, extracts the encoded `auth` string for the current registry, decodes it, and splits it back into a `(username, password)` tuple. If the config file is missing, it raises `UnableToStoreCredentialsFile`.

### Login Flow (`TokenManager.login`)

The base login process:

1. Skips entirely if the provider is `"export"`.
2. Calls `verify_connection_to_container_registry` to confirm reachability and obtain a `base_url`.
3. Based on provider:
   - For `"azure"` or `"local"`, it generates and writes credentials to the Docker config file.
   - For anything else, it raises `InvalidRegistryProvider`.
4. If a valid `base_url` was returned, it constructs an authenticated `MPSSession`.

Note that the `from None` clause on the raised `InvalidRegistryProvider` suppresses chained exception context, producing a cleaner error message.

### AWS-Specific Token Retrieval

`AWSTokenManager` overrides the credential and login behavior because ECR requires a different mechanism.

**Initialization** additionally:
- Creates an `asyncio.Lock`.
- Extracts the 12-digit registry ID from the registry address (`self.registry[:12]`), per AWS naming conventions.
- Builds a `boto3` ECR client using the AWS access key (`username`) and secret key (`password`).

**`get_username_and_password`** (overridden):
1. Acquires the lock.
2. Calls ECR's `get_authorization_token` API.
3. Decodes the returned base64 token into a `username:password` pair.
4. Writes those credentials to the Docker config file.
5. Wraps AWS errors (`BotoCoreError`, `NoCredentialsError`) in a domain-specific `UnableToGetAuthToken` error.

**`login`** (overridden):
1. Requires `region_name`; raises `InvalidAWSRegion` if missing.
2. Verifies registry connectivity.
3. Establishes an `MPSSession` with freshly retrieved credentials.

A subtle behavior worth noting: in `AWSTokenManager.login`, `get_username_and_password` is awaited **twice** — once for the connection verification and again for session creation. Each call independently fetches a new ECR token, which is acceptable since tokens are short-lived but does result in two ECR API calls per login.

---

## Usage Examples

### Standard (Azure / Local) Registry

```python
manager = TokenManager(
    registry="myregistry.azurecr.io",
    username="user",
    password="secret",
    provider="azure",
)

await manager.login()
# manager.session is now an authenticated MPSSession
```

### Local Registry Without Authentication

```python
manager = TokenManager(
    registry="localhost:5000",
    username=None,
    password=None,
    provider="local",
)

await manager.login()
# Uses http://, no auth required
```

### AWS ECR

```python
aws_manager = AWSTokenManager(
    registry="123456789012.dkr.ecr.us-east-1.amazonaws.com",
    region_name="us-east-1",
    username="<AWS_ACCESS_KEY_ID>",
    password="<AWS_SECRET_ACCESS_KEY>",
)

await aws_manager.login()
# Fetches a temporary ECR token, writes it to ~/.docker/config.json
```

---

## Integration

This module sits between configuration/credentials and the broader MPS API layer:

- **`mps.api.utils`** provides:
  - `verify_connection_to_container_registry` — performs the connectivity check and returns the registry's base URL.
  - `MPSSession` — the authenticated HTTP session object that the rest of the system uses to communicate with the registry.

- **`mps.api.errors`** supplies the domain-specific exceptions raised throughout the module (`MissingConfigValues`, `InvalidRegistryProvider`, `UnableToGetAuthToken`, `InvalidAWSRegion`, `UnableToStoreCredentialsFile`). These give callers structured, meaningful failure modes instead of raw library exceptions.

- **`mps.api.logger`** provides logging used to record login attempts.

- **External libraries**:
  - `boto3` / `botocore` — for AWS ECR authorization and error handling.
  - `base64` and `json` — for encoding credentials and reading/writing the Docker config file.
  - `asyncio.Lock` — for safe concurrent token refresh.

The end product of using either class is a populated `self.session` attribute — an `MPSSession` — which downstream components rely on to interact with the registry. The Docker config file written as a side effect also enables standard Docker tooling to authenticate against the same registry.