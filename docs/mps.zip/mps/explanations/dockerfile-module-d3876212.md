---
id: d3876212-5a88-5ce6-9582-1ca5bb06d5d9
type: explanation
title: "Dockerfile Module"
created_at: 2026-07-03T05:57:45.072814+00:00
updated_at: 2026-07-03T05:57:45.072826+00:00
source_files:
  - /Users/spark/git/service-model-promotion/Dockerfile
metadata:
  module_name: "builder.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Module

**Related files:**
- `/Users/spark/git/service-model-promotion/Dockerfile`

# `builder.Dockerfile` — Build Configuration for the Model Promotion Service

## Overview

This Dockerfile defines the container image for the **Model Promotion Service (MPS)**, a Python application responsible for promoting/publishing model images. The file uses a **multi-stage build** to produce a lean, production-ready image that contains only the runtime artifacts needed to run the service — excluding build tools, compilers, and intermediate files.

The design centers on two goals:

1. **Small, secure runtime images** — heavy build dependencies (compilers, dev headers) are isolated in a throwaway build stage and never ship in the final image.
2. **Container-management capabilities** — because MPS deals with model *images*, the final stage installs container tooling like `buildah`, `skopeo`, and `fuse-overlayfs`, allowing the service to build and move container images itself.

## Key Concepts

### Multi-Stage Builds

The Dockerfile is split into two `FROM` blocks:

- **`builder` stage** — installs Poetry, compiles Python dependencies, and builds the `mps` package into a wheel.
- **Final stage** — starts fresh from the same base image and copies only the compiled site-packages, binaries, and configuration from the builder.

Only the artifacts explicitly copied with `COPY --from=builder` survive into the final image. This is the core mechanism for keeping the runtime image small.

### Build Arguments and Parameterization

Two `ARG` values make the build configurable:

- `BASE_IMAGE` (default `python:3.13.12-alpine3.23`) — the base Python image, pulled from an internal Nexus registry (`nexus.dev.sparkbeyond.ai`).
- `VERSION` — the release version, promoted to an environment variable and used to locate the built wheel.

A notable detail is the **parameter expansion** `${VERSION//v/}`, which strips the leading `v` from a tag like `v1.2.8` to match the wheel's filename convention (`mps-1.2.8-py3-none-any.whl`).

### Alpine and Virtual Package Groups

The image is Alpine-based, which uses `apk` for package management. The builder stage installs build tools into a **virtual package group** named `.build-deps`:

```dockerfile
apk add --no-cache --virtual .build-deps gcc musl-dev libffi-dev openssl-dev make
```

Grouping them under `.build-deps` allows a single clean removal later with `apk del .build-deps`, ensuring compilers don't linger in the layer.

## How It Works

### Stage 1: The Builder

1. **Base setup** — starts from the parameterized Python/Alpine image and records `VERSION`.
2. **Install build dependencies** — updates/upgrades packages and adds the compiler toolchain (`gcc`, `musl-dev`, `libffi-dev`, `openssl-dev`, `make`) needed to build native Python extensions.
3. **Copy dependency manifests** — `pyproject.toml`, `poetry.lock`, and the `mps/` source are copied in. Copying manifests before the full source is a common caching technique, though here the source is copied immediately after.
4. **Install and build in one layer**:
   - Upgrades `pip`, `setuptools`, `wheel`, and installs `poetry` plus `pip-autoremove`.
   - Configures Poetry to install directly into the system environment (`virtualenvs.create false`) rather than a virtualenv — appropriate inside a container where isolation is already provided.
   - Runs `poetry install --no-root --only main` to install runtime dependencies.
   - Builds the `mps` package as a wheel and installs it via `pip`.
   - **Cleans up aggressively**: removes `pip` with `pip-autoremove`, deletes the `.build-deps` group, and drops the `mps/routes/` and `mps/api/` directories (likely development or generation-time code not needed once the wheel is installed).

All of this happens in a single `RUN` command so intermediate files never persist across layers.

### Stage 2: The Runtime Image

1. **Metadata and Python behavior** — sets a description label and standard Python container settings:
   - `PYTHONUNBUFFERED=1` for immediate log flushing.
   - `PYTHONDONTWRITEBYTECODE=1` to avoid writing `.pyc` files.

2. **Service user creation** — defines a dedicated, non-root service account:
   - Group `sparkbeyond` (GID `1001`).
   - User `predict` (UID `998`) with no login shell (`/sbin/nologin`) and no home directory (`-H`).

   The comments note the UID/GID are chosen deliberately to avoid `chown` conflicts when copying files and to handle cases where the Docker socket is mounted.

3. **Directory structure and localization** — creates the service's working directory tree (`bin/`, `conf/`, `log/`, `cache/`, `template/`, `utils/`, `image_archives/`, `exported_images`), clears caches, and pins the timezone and locale to UTC.

4. **Copying artifacts from the builder** — this is where the multi-stage build pays off:
   - The complete installed `site-packages` and `/usr/local/bin` (so the app and its dependencies are available).
   - The application entrypoint (`__main__.py`).
   - Configuration files (`promotion.toml`, `build.info`, `defaults.json`) into `conf/`.
   - An environment template into `template/`.
   - Local helper files (`load_images.sh`, `get-pip.py`) copied directly from the build context (not the builder stage).

5. **Container tooling and pip reinstall** — the final `RUN`:
   - Installs container-management utilities: `buildah`, `fuse-overlayfs`, `skopeo`, plus supporting tools (`curl`, `jq`, `tzdata`, `tar`, `netavark`, `pigz`).
   - Removes any copied-over `pip` remnants and reinstalls a clean `pip` via `get-pip.py` — the comment explains this avoids "old version residue" from the copied site-packages.
   - Symlinks `load_images.sh` to `/usr/local/bin/load_images` and makes it executable, exposing it as a convenient command.

6. **Runtime configuration**:
   - `EXPOSE 8010` documents the service port.
   - `CMD` launches the app: `python ${SERVICE_HOME}/bin/__main__.py`.
   - A `HEALTHCHECK` polls `http://localhost:8010/healthcheck` every 10 seconds (after a 60-second grace period), considering the container healthy only when it receives HTTP `200`.

## Usage Examples

### Building the image

```bash
docker build \
  -f builder.Dockerfile \
  --build-arg VERSION=v1.2.8 \
  -t model-promotion-service:1.2.8 \
  .
```

Overriding the base image:

```bash
docker build \
  -f builder.Dockerfile \
  --build-arg BASE_IMAGE=python:3.13.12-alpine3.23 \
  --build-arg VERSION=v1.2.8 \
  -t model-promotion-service:1.2.8 \
  .
```

### Running the container

```bash
docker run -p 8010:8010 model-promotion-service:1.2.8
```

The service starts on port 8010, and Docker will begin monitoring the `/healthcheck` endpoint after the 60-second start period.

## Integration

This Dockerfile is the packaging layer for the MPS Python application and connects to several other parts of the system:

- **Internal registry** — the base image is pulled from `nexus.dev.sparkbeyond.ai`, tying the build to SparkBeyond's internal infrastructure.
- **The `mps` package** — the application source (including `__main__.py`, route/API modules, and resources) is built from the project's `pyproject.toml`/`poetry.lock`. Configuration files (`promotion.toml`, `defaults.json`, `build.info`) are shipped alongside the code.
- **Container-management operations** — by installing `buildah`, `skopeo`, and `fuse-overlayfs`, the runtime image is equipped to build and transfer container images. The comment about mounting the Docker socket and the `load_images` helper indicate the service participates in image promotion workflows involving image archives and exports (reflected in the `image_archives/` and `exported_images/` directories).
- **Health monitoring** — the exposed `/healthcheck` endpoint integrates with orchestrators (e.g., Docker, Kubernetes) that rely on health status for readiness and liveness decisions.

Together, these choices produce a minimal, non-root, UTC-normalized runtime image that runs the Model Promotion Service and carries the tooling it needs to manage model container images.