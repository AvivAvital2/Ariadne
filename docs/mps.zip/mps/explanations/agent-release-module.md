---
id: 5fc0de8c-994a-52df-b7a6-d756b5eb1e2b
type: explanation
title: "Agent-Release Module"
created_at: 2026-06-06T19:02:56.770202+00:00
updated_at: 2026-06-20T22:55:21.321661+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent-release.yaml
metadata:
  module_name: ".ci.agent-release.agent-release"
  language: "yaml"
  source_name: "mps"
---
# Agent-Release Module

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent-release.yaml`

# Agent-Release Module


# Agent Release Pod Definition

**Module**: `.ci.agent-release.agent-release`

## Overview

This module defines a Kubernetes Pod specification used as a CI build agent for the "mps-release" job. Rather than describing application Python code, this YAML file is a declarative configuration that tells Kubernetes how to provision a containerized environment in which release builds are executed.

The Pod is purpose-built as an ephemeral build agent. It spins up a single container (`mps-builder`) preloaded with the tooling needed to perform release operations, runs idle until the CI system dispatches work into it, and is intended to be torn down once the job completes. Its location within the `.ci/` directory reinforces that this is part of the continuous integration pipeline rather than the runtime application.

## Key Concepts

Several Kubernetes concepts are central to understanding this definition.

### Pod and Labels

The file declares a single object of `kind: Pod` using `apiVersion: v1`. The `metadata.labels` block tags the Pod with `pod: "mps-release"` and `jobName: "mps-release"`. These labels are how CI tooling and Kubernetes selectors identify and target this specific agent.

### Eviction Protection

The annotation `cluster-autoscaler.kubernetes.io/safe-to-evict: "false"` is a directive to the cluster autoscaler. It instructs the autoscaler not to remove the node hosting this Pod when it considers scaling down. This is significant for a release job: an in-progress build should not be interrupted mid-flight by the autoscaler reclaiming the node.

### Node Affinity

The `affinity.nodeAffinity` section expresses *preferences* for where the Pod should be scheduled, using `preferredDuringSchedulingIgnoredDuringExecution`. This is a soft constraint—the scheduler tries to honor it but will still place the Pod elsewhere if no preferred node is available.

The preferences are weighted across three availability zones in the `eu-west-1` region:

| Availability Zone | Weight |
|-------------------|--------|
| `eu-west-1c`      | 3      |
| `eu-west-1a`      | 2      |
| `eu-west-1b`      | 1      |

Higher weights are more strongly preferred. Despite the inline comment labeling `eu-west-1b` as the "Preferred AZ", the actual weighting favors `eu-west-1c` (weight 3) most strongly, then `eu-west-1a`, then `eu-west-1b`. The comment appears to be out of sync with the weights, which is worth noting when reasoning about scheduling behavior.

### Privileged Container

The container runs with elevated permissions via its `securityContext`:

- `privileged: true` grants the container near-host-level capabilities.
- `runAsUser: 0` runs processes as root.

These settings are typical for build agents that need to perform Docker-in-Docker operations or otherwise interact with low-level system facilities.

## How It Works

The lifecycle of this build agent proceeds roughly as follows.

### 1. Image Sourcing

The container uses the image:

```
551806661322.dkr.ecr.eu-west-1.amazonaws.com/discovery-platform/mps-builder:1.3
```

This is pulled from a private AWS Elastic Container Registry (ECR) in `eu-west-1`. The `alwaysPullImage: true` setting forces a fresh pull of the image on each run, ensuring the agent always uses the published `1.3` tag rather than a stale cached copy.

### 2. Keeping the Container Alive

The container's startup configuration is deliberately minimal:

```yaml
command:
  - cat
tty: true
```

Running `cat` with a TTY attached is a common idiom for keeping a CI agent container alive without doing any work on its own. The `cat` process blocks waiting for input that never arrives, so the container stays running. The CI orchestrator then *execs* actual build commands into the running container, rather than relying on the container's entrypoint to perform the build.

### 3. Scheduling

When the Pod is created, the Kubernetes scheduler evaluates the node affinity weights and attempts to place it on a node in the most-preferred available zone. Because the constraints are soft, scheduling will not fail if those zones are unavailable.

### 4. Volume Mounting

A `configMap` volume named `docker-config` exposes the contents of the `dp-ecr-docker-config` ConfigMap to the Pod:

```yaml
volumes:
  - name: docker-config
    configMap:
      name: dp-ecr-docker-config
```

This typically supplies Docker authentication or daemon configuration the build needs—for example, credentials for pushing images back to ECR. Note that this file declares the *volume* but does not include a corresponding `volumeMounts` entry inside the container spec, so the mount path is not specified here.

## Usage Examples

This Pod definition is not invoked directly by a developer. Instead, a CI system (such as a Jenkins Kubernetes plugin or similar agent provisioner) references it to instantiate a build environment. A typical interaction pattern is:

1. The CI job requests an agent matching the `jobName: "mps-release"` label.
2. Kubernetes creates the Pod from this template and pulls the `mps-builder:1.3` image.
3. The container starts and idles on `cat`.
4. The CI system executes release build and publish steps inside the live container.
5. Once the job finishes, the Pod is destroyed.

Because the container is privileged and runs as root, it can perform operations such as building and pushing Docker images during these steps.

## Integration

While no other modules are directly linked to this file, it integrates with several external systems:

- **AWS ECR**: The build image is sourced from a private ECR repository, and the `dp-ecr-docker-config` ConfigMap likely provides the credentials needed to authenticate against it.
- **Kubernetes Cluster Autoscaler**: The eviction annotation coordinates with the autoscaler to protect running release jobs from disruption.
- **AWS Availability Zones**: The node affinity preferences tie scheduling decisions to specific `eu-west-1` zones, reflecting infrastructure-level placement strategy.
- **CI Orchestrator**: The `pod` and `jobName` labels serve as the contract between this template and the CI tooling that provisions and targets the agent.

In summary, this module is the infrastructure definition for a self-contained, privileged, ephemeral release build agent, designed to run reliably within an AWS-hosted Kubernetes cluster.