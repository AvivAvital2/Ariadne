---
id: 6ed662ec-515d-577e-9b88-ba74ea07f4df
type: explanation
title: "Manifest Module"
created_at: 2026-06-06T19:02:55.133350+00:00
updated_at: 2026-06-06T19:02:55.133363+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  module_name: ".ariadne.manifest.manifest"
  language: "json"
  source_name: "mps"
---
# Manifest Module

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

# Ariadne Manifest Documentation

## Overview

This document describes the Ariadne manifest file located at `.ariadne.manifest.manifest`. The manifest is a JSON configuration and record-keeping file that orchestrates the code indexing process for a project named **`mps`**.

The manifest serves two primary functions:

1. **Configuration** — It declares which parts of the codebase should be indexed and how (the `indexers` section).
2. **Provenance** — It records when each indexing operation occurred and where the resulting output artifacts were written.

The indexing it describes produces [SCIP](https://github.com/sourcegraph/scip) (SCIP Code Intelligence Protocol) index files. These index files capture code intelligence data—symbol definitions, references, and relationships—that downstream tools can consume to power features such as cross-repository navigation, "go to definition," and "find references."

## Key Concepts

### The Manifest as a Record of Work

Unlike a pure configuration file that only declares *what should happen*, this manifest also captures *what did happen*. Fields such as `indexed_at` and `merged_at` contain ISO 8601 timestamps recorded after the corresponding operations completed. This makes the manifest both an input to the indexing pipeline and an audit record of its execution.

### Versioning

The top-level `ariadne_version` field (`"1"`) declares the schema version of the manifest itself. This allows tooling to evolve the manifest format over time while remaining able to interpret older manifests correctly. Note that this is distinct from `indexer_version`, which records the version of the SCIP indexer tool.

### Indexers

The core of the manifest is the `indexers` array. Each entry describes a single, self-contained indexing job. Multiple indexers exist because a single repository often contains distinct code units that need to be indexed separately—for example, an application package versus loose utility scripts. Each indexer is processed independently and produces its own intermediate SCIP file.

### The Merge Step

After each individual indexer runs, the manifest records a final **merge** operation. The separate intermediate SCIP files are combined into a single unified index. This two-phase approach (index-then-merge) keeps each indexing job focused and isolated while still producing one consolidated artifact for consumption.

## How It Works

The manifest describes a pipeline that proceeds in the following stages.

### 1. Source Identification

The `source_name` field (`"mps"`) names the source being indexed. This label identifies the project across the indexing system.

### 2. Per-Indexer Processing

Each object in the `indexers` array drives one indexing run. The fields of an indexer entry work together as follows:

| Field | Purpose |
|-------|---------|
| `kind` | The language or technology of the code being indexed (here, `"python"`). |
| `cwd` | The working directory the indexer runs from, relative to the project root. |
| `markers` | Files whose presence identifies the code unit to index. |
| `entry_kind` | The structural nature of the indexed unit (e.g., `package` or `scripts`). |
| `scip_path` | The output path for this indexer's intermediate SCIP file. |
| `indexed_at` | Timestamp recorded when this indexing run completed. |
| `indexer_version` | The version string of the indexer tool used. |

In this manifest, two distinct Python indexing jobs are defined.

**Indexer 1 — The `mps` package**

This indexer runs from the `mps` directory and treats the code as a Python **package** (`"entry_kind": "package"`). Its markers point to package initializer files:

```
mps/api/__init__.py
mps/routers/__init__.py
```

The presence of these `__init__.py` files confirms the existence of the `api` and `routers` subpackages, anchoring the indexer to the correct package structure. Its output is written to `intermediate/index-mps-python.scip`.

**Indexer 2 — Top-level scripts**

This indexer runs from the project root (`"cwd": "."`) and treats the target as standalone **scripts** (`"entry_kind": "scripts"`) rather than a package. Its single marker is `update_version.py`, a loose script that lives outside the `mps` package. Its output is written to `intermediate/index-python.scip`.

The distinction between the two `entry_kind` values is meaningful: a `package` is indexed with awareness of its import hierarchy and module structure, while `scripts` are treated as independent files. Separating them ensures each is analyzed with the appropriate assumptions.

### 3. Merging

Once both indexers have produced their intermediate `.scip` files, the merge step runs. The manifest records:

- `merged_at` — the timestamp when the merge completed.
- `merged_scip` — the path of the final, unified index (`index.scip`).

Comparing the timestamps in this manifest shows the expected ordering: both indexers complete (`18:48:45` and `18:48:47`) before the merge finalizes (`18:48:47.55`). The merged `index.scip` is the primary deliverable—the single file other tools will load.

## Usage Examples

This manifest is not invoked directly as code; it is consumed by the Ariadne indexing tooling. Conceptually, the workflow a tool would follow is:

1. **Read** the manifest and validate `ariadne_version`.
2. **Iterate** over the `indexers` array.
3. For each indexer, change into the directory given by `cwd`, locate the code identified by `markers`, run the appropriate `kind` indexer, and write the result to `scip_path`.
4. **Merge** all intermediate `scip_path` files into the single file named by `merged_scip`.
5. **Update** the manifest with the relevant `indexed_at` and `merged_at` timestamps.

When extending the project to index an additional code unit, you would add a new object to the `indexers` array specifying its `kind`, `cwd`, `markers`, `entry_kind`, and `scip_path`.

## Integration

The intermediate and merged SCIP files referenced here are the integration points between this manifest and the rest of the system:

- **Intermediate files** (`intermediate/index-mps-python.scip`, `intermediate/index-python.scip`) are private artifacts of the indexing pipeline. They exist only to be combined during the merge step.
- **The merged file** (`index.scip`) is the public output. Any code intelligence consumer—such as a code navigation service or an analysis tool—loads this single file to obtain complete symbol information for the `mps` source.

Because no other modules are directly related to this manifest, its role in the system is intentionally narrow: it is a leaf configuration that defines and records the indexing of a specific source. Its output (`index.scip`) is where its influence reaches the broader system.