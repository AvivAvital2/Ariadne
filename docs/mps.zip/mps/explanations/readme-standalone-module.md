---
id: ffeddcb5-7f5d-5407-a4dc-b49a9b0785d7
type: explanation
title: "Readme Standalone Module"
created_at: 2026-06-06T19:03:05.996825+00:00
updated_at: 2026-06-20T22:55:21.293087+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  module_name: "documentation.README_standalone.README_standalone"
  language: "markdown"
  source_name: "mps"
---
# Readme Standalone Module

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# Readme Standalone Module


# Model Promotion Service (MPS) — Standalone Deployment Documentation

## Overview

This module is not executable Python code — it is a **Markdown deployment guide** packaged within the documentation namespace (`documentation.README_standalone.README_standalone`). Its purpose is to walk operators and customers through deploying the **Model Promotion Service (MPS)** alongside the SparkBeyond Discovery Platform.

The Model Promotion Service is the component responsible for turning a trained model into a deployable **Prediction Server Docker image** and pushing that image to a container registry. In effect, MPS bridges two worlds:

- The **Discovery Platform**, where models are trained and exported.
- A **container registry** (Azure ACR, AWS ECR, a local registry, or a tar archive), where the resulting Prediction Server images are stored and made available for deployment.

This particular guide covers the **standalone procedure**, i.e., a manual, step-by-step installation rather than an automated one. The intended audience is explicitly stated: prospective customers, SparkBeyond Operations, and SparkBeyond Developers.

---

## Key Concepts

Several recurring abstractions appear throughout the guide. Understanding them clarifies why the steps are ordered as they are.

### Discovery Platform ↔ MPS communication

MPS does not operate in isolation. It must talk back and forth with the Discovery Platform to receive model artifacts and to report export status. The guide strongly recommends co-locating the two services on the same host to minimize artifact transfer latency, while noting the trade-off: co-location requires extra disk space for building and storing Docker images.

### Base images vs. promoted images

A central distinction in the system:

- **Base images** — pre-built Prediction Server images (variants like `aio`, `osm`, `gdata`, `minimal`) that MPS loads into its own storage. These act as the foundation layer.
- **Promoted images** — model-specific images that MPS *builds* by layering a trained model on top of a base image, then pushes to the configured registry.

The `promotion.toml` file maps a release version to its base image addresses, and the `repoPrefix` setting controls where promoted images are stored.

### Registry providers

MPS abstracts the destination registry behind a `REGISTRY_PROVIDER` value, supporting four modes:

| Provider value | Destination |
|----------------|-------------|
| `azure` | Azure Container Registry (ACR) |
| `aws` | AWS Elastic Container Registry (ECR) |
| `local` | A local registry instance |
| `export` | Compressed tar archives written to a volume |

This pluggable design means the same MPS deployment logic works across cloud providers, with provider-specific behavior driven entirely by configuration rather than separate code paths.

### Configuration layering

Configuration is spread across distinct files, each with a clear responsibility:

- `.compose.backend.production.env` — Discovery Platform side; tells Discovery where MPS lives.
- `promotion.toml` — MPS base image definitions and the repository prefix.
- `.env` — MPS runtime settings: registry address, credentials, provider, logging.
- `docker-compose.yaml` — service orchestration, volumes, and maintenance flags.

---

## How It Works

The deployment flow proceeds through several logical phases. The placeholders such as `MPSRELEASEVER` and `EPSRELEASEVER` are substituted with actual version numbers at deployment time.

### 1. Prerequisites and Docker setup

Before anything else, the host needs a working Docker Engine and Docker Compose, plus a `bash` shell with `aws-cli` and `jq` available. The guide adds the current user to the `docker` group so subsequent commands run without `sudo`, and verifies the install with `docker run hello-world`.

### 2. Wiring Discovery Platform to MPS

The Discovery Platform must know how to reach MPS. The guide retrieves the Docker bridge gateway IP (expected to start with `172`) so the containers can communicate:

```bash
docker inspect <discovery_master_container_name> | jq -r '.[].NetworkSettings.Gateway'
```

A fallback using `ifconfig docker0` is provided in case `jq` is unavailable. Four `CONFIG_FORCE_*` environment variables are then added to enable the Docker-export feature and point Discovery at the MPS endpoint (`http://<gateway_ip>:8010/modelpromotion`). Discovery is restarted to apply these.

### 3. Obtaining and importing MPS artifacts

MPS itself ships as exported Docker images and a docker-compose bundle, delivered via AWS pre-signed URLs. The operator downloads both with `wget`, loads the image with `docker load`, and extracts the compose bundle into an `MPS-compose` directory.

### 4. Configuring MPS

This is where the bulk of the operator's decisions are made:

- In `promotion.toml`, the four base image variants are pointed at the operator's registry.
- In `.env`, the registry address, image path, credentials, and provider are specified.

The guide highlights two important **credential constraints**: dedicated, non-expiring credentials should be used. This matters because MPS pushes images continuously over its lifetime, and short-lived tokens (such as AWS's 12-hour credentials) would silently break the service.

An optional `export` mode lets images be written to a host-mounted volume rather than pushed to a registry, configured by adding a volume mount under the `mps` service in `docker-compose.yaml`.

### 5. Running the service

After creating a `cache_db` directory, the service is launched:

```shell
docker-compose up -d
```

A healthy startup shows Uvicorn (the ASGI server underlying MPS) listening on `http://0.0.0.0:8010`, confirming MPS exposes an HTTP API on that port — the same port Discovery was configured to call.

### 6. Loading base images

With MPS running, the Prediction Server base images are loaded into MPS storage via the `load_images` command:

```bash
docker-compose exec -it mps load_images ${CONTAINER_REGISTRY_NAME} --push-images
```

The `--push-images` flag is significant. The guide explains its three benefits in concrete terms:

- It pre-verifies that **auxiliary images** (nginx, PostgreSQL, MongoDB) exist on the remote registry, enabling air-gapped Docker Compose exports.
- It provides a recovery path if the local MPS volume is lost or corrupted.
- It enables **automatic recovery** — if a base image is missing locally during an export, MPS can fetch it from the registry instead of failing.

A noteworthy provider-specific caveat: **AWS ECR does not auto-create repository hierarchies**, so operators must manually run `aws ecr create-repository` for each prefix before pushing.

### 7. Validating the deployment

The guide prescribes an end-to-end smoke test: train a Titanic model in Discovery, trigger **Export as Docker Compose** from the Learn node's Exports tab, and watch the MPS logs for a success line such as:

```
mps_1  | INFO:    Image .../predbox/<uuid>_standalone:8 was pushed successfully
```

This confirms the full pipeline — Discovery → MPS → registry — is functioning.

---

## Usage Examples

While there are no Python classes to invoke, the operationally meaningful "API surface" consists of CLI commands and the maintenance HTTP routes.

### Importing base images

```bash
export CONTAINER_REGISTRY_NAME="reg.azurecr.io"
docker-compose exec -it mps load_images ${CONTAINER_REGISTRY_NAME} --push-images
```

### Maintenance mode endpoints

Setting `MAINTENANCE_MODE: "true"` in `docker-compose.yaml` exposes additional administrative HTTP routes intended for operators during a maintenance window only:

| Method | Route | Purpose |
|--------|-------|---------|
| `GET` | `/modelpromotion/maintenance/local_images` | List images in local storage |
| `DELETE` | `/modelpromotion/maintenance/local_images` | Delete images from local storage |
| `GET` | `/modelpromotion/maintenance/total_image_size` | Report total image size on disk |

These routes are gated behind the maintenance flag so that destructive operations (like deleting local images) are not available during normal operation.

---

## Integration

This module sits at the intersection of several systems:

- **SparkBeyond Discovery Platform** — the upstream producer of trained models. Integration is achieved through the `CONFIG_FORCE_web_modelAsDockerExport_*` settings, which point Discovery at the MPS endpoint on port `8010`. Discovery initiates exports; MPS responds by building and pushing images.

- **Container registries (ACR / ECR / local / export)** — the downstream consumer. MPS authenticates with the registry using `REGISTRY_USER`/`REGISTRY_PASS` and pushes promoted images. The behavior here is fully configuration-driven via `REGISTRY_PROVIDER`.

- **Prediction Server** — the artifact MPS ultimately produces. The base images referenced in `promotion.toml` are Prediction Server release images; MPS layers model artifacts onto them to create deployable Prediction Servers.

The metadata lists no directly related Python modules, which is consistent with this being a standalone operations document rather than part of an importable code package. Its role in the broader system is procedural: it codifies the manual deployment workflow that connects model training, image promotion, and registry storage into a single reproducible process.