---
id: 50d088df-cff3-510e-8e17-41b67754fd8a
type: explanation
title: "Basic Module"
created_at: 2026-06-06T19:04:17.673799+00:00
updated_at: 2026-06-20T22:55:21.317740+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  module_name: "mps.routers.basic"
  language: "python"
  source_name: "mps"
---
# Basic Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# Basic Module


# `mps.routers.basic` Module Documentation

## Overview

The `mps.routers.basic` module defines a set of lightweight HTTP endpoints used for basic operational and informational tasks within the application. It is built on top of [FastAPI](https://fastapi.tiangolo.com/) and provides three routes:

- A **health check** endpoint for monitoring service availability.
- A **build info** endpoint for exposing build metadata.
- A **ping** endpoint scoped under the model promotion path.

This module is typically registered with a parent FastAPI application and serves as the foundation for service monitoring, load balancer health probes, and deployment verification. Endpoints like these are commonly used by orchestration systems (e.g., Kubernetes liveness/readiness probes) and CI/CD pipelines.

## Key Concepts

### The `APIRouter`

The module creates a single `APIRouter` instance:

```python
router = APIRouter()
```

`APIRouter` is FastAPI's mechanism for grouping related routes into a modular unit. Instead of attaching endpoints directly to the main application, routes are defined on a router that can later be included in the application with a single call (`app.include_router(router)`). This pattern keeps route definitions organized by concern and makes the codebase easier to scale as more route groups are added.

### Asynchronous Request Handlers

All three endpoint functions are defined with `async def`. FastAPI supports asynchronous handlers natively, which allows the event loop to handle other requests while a coroutine awaits I/O operations. This is especially relevant for the `build_info` endpoint, which performs file I/O.

### Specialized Response Types

The module uses two distinct response classes from FastAPI:

- **`PlainTextResponse`** — returns raw text with a `text/plain` content type. Used for simple string replies.
- **`JSONResponse`** — returns serialized JSON with an `application/json` content type. Used for structured data.

Choosing the appropriate response type ensures correct `Content-Type` headers are sent to clients.

### Non-blocking File Access with `aiofiles`

The `build_info` endpoint reads from a file using `aiofiles`, an asynchronous file I/O library. Standard Python file operations are blocking and would stall the event loop during disk access. By using `aiofiles`, the read operation can be awaited without halting other concurrent requests.

## How It Works

### 1. Health Check (`/healthcheck`)

```python
@router.get("/healthcheck")
async def ping():
    return PlainTextResponse("OK")
```

This is the simplest endpoint. When a `GET` request hits `/healthcheck`, it immediately returns the plain text string `"OK"`. There is no logic, no I/O, and no dependency — making it ideal as a fast, reliable signal that the service process is running and able to respond.

### 2. Build Info (`/modelpromotion/buildInfo`)

```python
@router.get("/modelpromotion/buildInfo")
async def build_info():
    async with aiofiles.open("conf/build.info", mode="r") as f:
        data = await f.read()
        return JSONResponse(content=json.loads(data), status_code=HTTP_200_OK)
```

This endpoint exposes build metadata stored in a file. The process is:

1. The file `conf/build.info` is opened asynchronously in read mode using `aiofiles.open`, wrapped in an `async with` context manager so the file is properly closed afterward.
2. The full file contents are read into the `data` variable via `await f.read()`.
3. The string is parsed from JSON into a Python object using `json.loads`.
4. The parsed data is returned as a `JSONResponse` with an explicit `HTTP_200_OK` status code.

The file path `conf/build.info` is **relative**, meaning it is resolved against the working directory from which the application is launched. The file is expected to contain valid JSON; otherwise `json.loads` will raise an error.

### 3. Ping (`/modelpromotion/ping`)

```python
@router.get("/modelpromotion/ping")
async def ping():
    return PlainTextResponse("Pong")
```

This endpoint returns the plain text `"Pong"` in response to a `GET` request. It follows the classic ping/pong convention and is grouped under the `/modelpromotion` path prefix.

### Note on Function Naming

Both the health check handler and the model promotion ping handler are named `ping`. Within a single Python module, the second `def ping` definition shadows the first at the module level. However, because FastAPI captures each function as a route handler when the `@router.get(...)` decorator is applied, both endpoints remain fully functional and independently routable. The shadowing only affects direct module-level references to the name `ping`, not the registered routes.

## Usage Examples

### Registering the Router

To activate these endpoints, the router must be included in a FastAPI application:

```python
from fastapi import FastAPI
from mps.routers import basic

app = FastAPI()
app.include_router(basic.router)
```

### Calling the Endpoints

Once the application is running, the endpoints can be invoked over HTTP:

```bash
# Health check
curl http://localhost:8000/healthcheck
# -> OK

# Ping
curl http://localhost:8000/modelpromotion/ping
# -> Pong

# Build info
curl http://localhost:8000/modelpromotion/buildInfo
# -> {"version": "1.0.0", "commit": "...", ...}
```

The exact contents of the build info response depend on what is stored in `conf/build.info`.

## Integration

This module fits into the broader system as a **router component** within a FastAPI-based service:

- **FastAPI / Starlette**: The module relies on FastAPI's `APIRouter` and response classes, which are built on the underlying Starlette framework. The `HTTP_200_OK` constant is imported directly from Starlette's status module.
- **Parent application**: The `router` object is designed to be imported and mounted onto a main application instance. It does not run standalone.
- **Configuration files**: The `build_info` endpoint depends on a `conf/build.info` file being present and containing valid JSON at runtime. This couples the endpoint to the deployment environment's file layout, and the file is typically generated during the build or packaging process.
- **Operational tooling**: The `/healthcheck` and ping endpoints are intended for consumption by external monitoring, load balancers, or container orchestration health probes rather than by application end users.

By isolating these basic operational endpoints into their own module, the codebase keeps monitoring and metadata concerns separate from core business logic.