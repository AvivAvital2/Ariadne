---
id: d979d834-790c-55cd-b7ed-58391d482418
type: explanation
title: "Readme Module"
created_at: 2026-06-06T19:03:01.321708+00:00
updated_at: 2026-07-03T05:58:21.028416+00:00
source_files:
  - /Users/spark/git/service-model-promotion/README.md
metadata:
  module_name: "README.README"
  language: "markdown"
  provenance: "human-doc"
  source_name: "mps"
---
# Readme Module

**Related files:**
- `/Users/spark/git/service-model-promotion/README.md`

# Model Promotion Service (MPS) — Documentation Guide Explanation

> **Note on scope:** The module `README.README` is a Markdown documentation file, not executable Python code. This explanation therefore describes the *deployment procedure* the document defines, the concepts a developer must understand to follow it, and how the Model Promotion Service (MPS) integrates with the surrounding SparkBeyond system. Where the original guide describes commands or configuration, those are treated as the "operations" this document orchestrates.

---

## 1. Overview

The **Model Promotion Service (MPS)** is a component of the SparkBeyond platform whose job is to take trained models produced by the **Discovery Platform** and package them into **deployable Docker images** for a **Prediction Server (EPS)**. Those images are then pushed to a container registry from which they can be run in production.

This README serves as the **production deployment guide** for the integrated deployment mode — that is, running MPS *on the same Docker Compose stack* as the Discovery Platform rather than as a standalone service.

The document targets three audiences:

- Customers who want to deploy a Prediction Server,
- SparkBeyond Operations staff who maintain running deployments,
- SparkBeyond Developers.

At a high level, the guide walks the reader through:

1. Verifying prerequisites,
2. Configuring the Discovery Platform to enable Docker export,
3. Configuring MPS (base images, registry credentials, export options),
4. Starting the service,
5. Loading Prediction Server base images into MPS storage,
6. Validating the deployment end-to-end,
7. Operating MPS in maintenance mode.

---

## 2. Key Concepts

Understanding the deployment requires familiarity with several abstractions referenced throughout the guide.

### Discovery Platform vs. Model Promotion Service vs. Prediction Server

- **Discovery Platform** — Where models are *trained*. It initiates export requests.
- **Model Promotion Service (MPS)** — The intermediary that *builds and pushes* Docker images from trained models. Since version `3.0.0`, MPS ships as part of the Discovery Platform compose bundle and starts automatically alongside it.
- **Prediction Server (EPS)** — The runtime that *serves predictions*. Its images are what MPS builds on top of the **base images**.

### Base Images

A **base image** is a pre-built Prediction Server Docker image that MPS layers a trained model onto. The guide defines these per EPS release in `promotion.toml`, keyed by variant:

- `aio` — "all in one"
- `osm` — includes OSM (geospatial) data
- `gdata` — includes additional data
- `minimal` — the smallest footprint

These base images must be present in MPS's local storage (and, ideally, in the remote registry) before any model export can succeed.

### Registry Providers

MPS is registry-agnostic. The `REGISTRY_PROVIDER` setting determines where output images go:

| Provider value | Meaning |
|----------------|---------|
| `azure` | Azure Container Registry (ACR) |
| `aws` | AWS Elastic Container Registry (ECR) |
| `local` | A local registry |
| `export` | Write images to compressed tar archives instead of a registry |

This abstraction lets the same service target different infrastructures by changing environment variables rather than code.

### Configuration Layers

The deployment separates configuration into distinct files, each with a clear responsibility:

- **Discovery Platform System Administration UI** — enables the export feature flags.
- **`promotion.toml`** — defines base images and the output repository prefix.
- **`.env`** — supplies registry connection details and runtime toggles (image name, credentials, log level, maintenance mode).
- **`docker-compose.yaml`** — declares volumes (e.g., for exported archives) and orchestrates the `mps` service.

---

## 3. How It Works

The following is the end-to-end flow the guide constructs, step by step.

### Step 1 — Enable export in the Discovery Platform

Two feature flags must be turned on via **System Administration → Configuration**:

- `web.modelAsDockerExport.enable = true` — enables the Docker export capability.
- `web.connectionHealth.display.modelPromotionService = true` — surfaces MPS connection health in the UI.

A **Restart** applies these changes. Without these flags, the Discovery Platform will not offer the export action or communicate with MPS.

### Step 2 — Configure base images

In `promotion.toml`, each EPS release version defines its four image variants. The example uses an ACR address, but the same structure applies to ECR or a local registry:

```toml
[baseImage.EPSRELEASEVERDASHES]
aio     = "my_azure_repo.azurecr.io/sparkbeyond/prediction-server:release-EPSRELEASEVER-aio"
minimal = "my_azure_repo.azurecr.io/sparkbeyond/prediction-server:release-EPSRELEASEVER"
```

Optionally, `[general].repoPrefix` sets where newly built images are placed (default `/sparkbeyond/predbox`).

### Step 3 — Supply registry connection details

The `.env` file wires MPS to the target registry:

- `MPS_IMAGE` — which MPS image to run.
- `REGISTRY_ADDR` — the destination registry host.
- `REGISTRY_USER` / `REGISTRY_PASS` — push credentials. **A design caveat is called out here:** credentials must be non-expiring, because some AWS credentials expire after 12 hours, which would silently break pushes.
- `REGISTRY_PROVIDER` — the provider abstraction described above.
- `AWS_REGISTRY_REGION` — required *only* when the provider is `aws`.
- `LOG_LEVEL`, `MAINTENANCE_MODE` — optional runtime toggles.

### Step 4 — (Optional) Configure archive export

If `REGISTRY_PROVIDER=export`, a host volume is mounted into the `mps` service so tar archives land on the host filesystem:

```yaml
mps:
  volumes:
    - ./exported_images/:/opt/sparkbeyond/service/promotion/exported_images/
```

### Step 5 — Start MPS

A `cache_db` directory is created, then the service is launched and its logs monitored:

```shell
mkdir cache_db
docker-compose up -d mps
docker-compose logs -f mps
```

A healthy startup shows Uvicorn (an ASGI server) listening on port `8010`, indicating MPS exposes an HTTP API.

### Step 6 — Load base images into MPS storage

This is the most nuanced step. Base images are downloaded (via pre-signed URLs) into an `image_archives` directory, then imported:

```shell
docker-compose exec -it mps load_images ${CONTAINER_REGISTRY_NAME} --push-images
```

The `--push-images` flag does more than load locally — it uploads base and auxiliary images to the remote registry. The guide explains **why** this matters:

- It verifies auxiliary images (nginx, PostgreSQL, MongoDB) exist remotely, so exported Compose bundles run without internet access.
- It provides recovery: if MPS's local volume is lost or corrupted, MPS can re-fetch base images from the registry instead of failing outright.

An **AWS-specific constraint** is documented: ECR does not auto-create repository hierarchies, so repositories must be created manually with `aws ecr create-repository` before pushing.

### Step 7 — Validate

The guide prescribes a concrete smoke test: train a **Titanic model**, export it as a Docker Compose bundle from the **Learn node → Exports tab**, and watch the MPS logs for a successful push confirmation.

### Step 8 — Maintenance mode

Setting `MAINTENANCE_MODE: "true"` exposes additional HTTP routes for operators:

- `GET /modelpromotion/maintenance/local_images` — list locally stored images.
- `DELETE /modelpromotion/maintenance/local_images` — delete local images.
- `GET /modelpromotion/maintenance/total_image_size` — report disk usage.

These are intended to be enabled only during a maintenance window, then turned off.

---

## 4. Usage Examples

Since this is a deployment guide, "usage" means executing the operational sequence. A minimal integrated deployment looks like this:

```shell
# 1. Prepare storage
mkdir cache_db
mkdir image_archives   # then download base image archives here

# 2. (AWS only) pre-create registry repositories
aws ecr create-repository --repository-name sparkbeyond/base/

# 3. Point at the target registry
export CONTAINER_REGISTRY_NAME="12345.dkr.ecr.eu-west-1.amazonaws.com"

# 4. Start MPS
docker-compose up -d mps

# 5. Load and push base images
docker-compose exec -it mps load_images ${CONTAINER_REGISTRY_NAME} --push-images

# 6. Watch logs during a test export
docker-compose logs -f mps
```

Configuration is spread across `.env` and `promotion.toml` as described above rather than passed on the command line.

---

## 5. Integration

MPS sits at the center of the model-to-production pipeline and integrates with several parts of the system:

- **With the Discovery Platform** — MPS receives export requests triggered from the Platform UI. Communication depends on the two feature flags being enabled. The guide notes that co-locating MPS and the Discovery Platform on the same machine is a **best practice**, because it minimizes artifact transfer latency between the two services and improves user experience. This is why the integrated Compose deployment exists at all.

- **With the container registry** — MPS authenticates using `.env` credentials and pushes both freshly built model images and required base/auxiliary images. The registry becomes the source of truth from which Prediction Servers are ultimately deployed, and also a recovery source if MPS's local volume is lost.

- **With the Prediction Server (EPS)** — MPS builds on top of EPS base images defined in `promotion.toml`. The final images MPS produces are what run as Prediction Servers.

- **With host infrastructure** — MPS requires storage for the `cache_db` and image caches, and optionally a mounted `exported_images` volume when exporting to tar archives. The guide notes that co-located deployments need **additional disk capacity** for building new images.

- **Operationally** — Maintenance-mode HTTP endpoints integrate MPS with Ops workflows, allowing remote inspection and cleanup of image storage without direct container access.

### The document's guidance on trade-offs

The guide is explicit about several operational decisions:

- **Co-location vs. separate machines** — separate deployment is supported, but co-location is recommended for latency reasons at the cost of extra storage.
- **Pushing base images vs. local-only** — pushing (`--push-images`) is preferred despite the extra registry work, because it enables air-gapped Compose exports and automatic recovery.
- **Non-expiring credentials** — chosen deliberately to avoid silent push failures.

These notes are the "why" behind the procedure and are worth preserving when adapting the deployment to a new environment.