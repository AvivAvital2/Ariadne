---
id: ee968ae8-acce-5ef4-a6a9-cdbecb1b8f83
type: explanation
title: "Image Cache Module"
created_at: 2026-06-06T19:03:31.842599+00:00
updated_at: 2026-06-20T22:55:21.299352+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  module_name: "mps.api.image_cache"
  language: "python"
  source_name: "mps"
---
# Image Cache Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# Image Cache Module


# `mps.api.image_cache`

## Overview

The `mps.api.image_cache` module provides a persistent, asynchronous key–value store for caching binary image data. Its single class, `AsyncPersistentImageCache`, wraps a SQLite database and exposes an `async`/`await` interface for storing, retrieving, and managing cached images.

The cache is **persistent** because it is backed by an on-disk SQLite file rather than in-memory storage, so cached data survives across process restarts. It is **asynchronous** because it is built on `aiosqlite`, allowing it to integrate cleanly into an `asyncio`-based application without blocking the event loop on database I/O.

The core data is stored as binary blobs, making the cache well-suited for image bytes or any other arbitrary binary payload keyed by a string identifier.

## Key Concepts

### SQLite as a key–value store

Rather than maintaining a custom file layout, the module uses a single SQLite table named `cache` with two columns:

- `key` — a `TEXT` column that serves as the primary key.
- `value` — a `BLOB` column holding the raw bytes.

Using `key` as the primary key gives the cache fast lookups and enforces uniqueness, which is important for the `set` operation's upsert behavior (described below).

### Asynchronous context manager

The class implements the asynchronous context manager protocol (`__aenter__` and `__aexit__`). This ensures that:

- The database connection is opened and the schema is created before the cache is used.
- The connection is reliably closed when the cache block exits, even if an exception occurs.

This pattern ties the connection lifecycle directly to the `async with` block, reducing the chance of leaked connections.

### Concurrency control with `asyncio.Lock`

The class holds an `asyncio.Lock` to serialize write operations. All mutating queries route through the internal `_execute` helper, which acquires the lock before running the query and committing. This protects against concurrent writes from multiple coroutines that share the same connection, which could otherwise interleave in unsafe ways.

Notably, read operations (`get`, `list`) do **not** acquire the lock—they execute directly against the connection.

## How It Works

### Initialization

When an instance is created, `__init__` computes the database file path by joining `image_cache_path` (imported from `mps.api.config`) with the filename `image_cache.sqlite`. It also initializes `self.conn` to `None` and creates the `asyncio.Lock`. No I/O happens at this stage—the connection is established later.

```python
self.db_path = os.path.join(image_cache_path, 'image_cache.sqlite')
self.conn = None
self.lock = asyncio.Lock()
```

### Entering the context

`__aenter__` performs the actual setup:

1. Opens an `aiosqlite` connection to `self.db_path`.
2. Executes a `CREATE TABLE IF NOT EXISTS` statement to ensure the `cache` table exists.
3. Commits the schema change.
4. Returns `self` so the cache instance is bound to the `as` target of the `async with` block.

Because the table creation uses `IF NOT EXISTS`, entering the context is idempotent and safe whether the database file is new or already populated.

### Exiting the context

`__aexit__` simply closes the connection. The exception arguments are accepted but not used, meaning any exception raised inside the block propagates normally after the connection is closed.

### Reading data

- **`get(key)`** runs a parameterized `SELECT` for a single key, fetches one row, and returns the blob value if found or `None` otherwise.
- **`list()`** selects all rows and returns them as a dictionary mapping each key to its value, providing a snapshot of the entire cache.

Both methods use parameterized queries (or no parameters) and rely on `aiosqlite` cursors managed via `async with` to ensure cursors are cleaned up.

### Writing data

All write paths funnel through the private `_execute` helper:

```python
async def _execute(self, query, parameters=None):
    async with self.lock:
        async with self.conn.cursor() as cursor:
            await cursor.execute(query, parameters)
        await self.conn.commit()
```

This centralizes locking and committing, so each public write method only needs to supply the appropriate SQL and parameters:

- **`set(key, value)`** uses `INSERT OR REPLACE`, an upsert that creates a new row or overwrites an existing one with the same key. This is the typical way to add or refresh a cached image.
- **`update(key, value)`** uses a plain `UPDATE`, which only modifies an existing row. If the key does not exist, no row is changed.
- **`delete(key)`** removes the row matching the key.
- **`clear()`** removes all rows, emptying the cache while leaving the table structure intact.

The distinction between `set` and `update` is worth noting: `set` guarantees the value will be present afterward, whereas `update` is a no-op if the key is absent.

## Usage Examples

Because the cache is an asynchronous context manager, it is used inside an `async with` block within a coroutine:

```python
from mps.api.image_cache import AsyncPersistentImageCache

async def cache_workflow(image_bytes):
    async with AsyncPersistentImageCache() as cache:
        # Store an image
        await cache.set("avatar_42", image_bytes)

        # Retrieve it later
        data = await cache.get("avatar_42")
        if data is not None:
            process(data)

        # Update only if it already exists
        await cache.update("avatar_42", new_bytes)

        # Inspect everything in the cache
        all_entries = await cache.list()

        # Remove a single entry
        await cache.delete("avatar_42")

        # Or wipe the entire cache
        await cache.clear()
```

The connection is opened on entry and closed automatically on exit, so each `async with` block represents one cache session.

## Integration

This module connects to the rest of the system through a few clear dependencies:

- **`mps.api.config`** supplies `image_cache_path`, the directory where the SQLite file lives. Centralizing this in the config module means the storage location is configured in one place and shared across the application.
- **`aiosqlite`** provides the asynchronous SQLite driver that backs all database operations.
- **`asyncio`** supplies the `Lock` used to serialize writes and reflects the module's intended use within an event-loop-driven application.
- **`os`** is used only to construct the database file path.

Within the broader `mps.api` package, this module acts as a storage layer that other components can use to persist and reuse image data across requests or sessions without re-fetching or re-computing it. Any consumer running in an `asyncio` context can instantiate the cache and interact with it through the simple `get`/`set`/`update`/`delete`/`list`/`clear` interface.