---
id: 5ad7072d-78b9-56b2-825d-1ba594bcc2e1
type: explanation
title: "Schemas Module"
created_at: 2026-06-06T19:03:50.832867+00:00
updated_at: 2026-06-20T22:55:21.252373+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  module_name: "mps.api.schemas"
  language: "python"
  source_name: "mps"
---
# Schemas Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# Schemas Module


# `mps.api.schemas` Module Documentation

## Overview

The `mps.api.schemas` module defines the data validation and serialization schemas used throughout the MPS API layer. Its primary purpose is to describe the *shape* of structured data—such as image definitions, promotion parameters, and configuration flavours—and to validate and transform incoming data (for example, request payloads) into well-typed Python objects.

The module leans heavily on the `marshmallow_dataclass` library, which combines the ergonomics of Python dataclasses with the validation and (de)serialization capabilities of `marshmallow`. Rather than hand-writing `marshmallow.Schema` subclasses, each class here is declared as a dataclass and automatically gains an associated schema.

## Key Concepts

### `marshmallow_dataclass` Integration

Every class in this module is decorated with `@dataclass` imported from `marshmallow_dataclass` (not the standard library's `dataclasses`). This decorator does two things:

1. It turns the class into a regular Python dataclass with typed fields.
2. It generates a `marshmallow` schema based on those field annotations.

This means each class can be used both as a plain data container *and* as a validation/deserialization target. Field type annotations (`str`, `bool`, etc.) drive the validation rules automatically.

### Schema Lifecycle Hooks

The module makes use of two distinct hook mechanisms:

- **`@post_load`** (from `marshmallow`): A schema-level hook that runs after marshmallow has loaded and validated the raw data. It allows post-processing of the deserialized result.
- **`__post_init__`** (standard dataclass hook): Runs immediately after the dataclass `__init__` completes, allowing derived fields to be computed from constructor arguments.

These two hooks serve different layers—one operates within the marshmallow load pipeline, the other within dataclass instantiation.

### Default Values

Several schemas use default values (`= False`, `= 'latest'`) to mark optional fields. When data is deserialized, any field with a default may be omitted from the input.

## How It Works

### `Flavours`

```python
@dataclass
class Flavours:
    minimal: str
    gdata: str
    osm: str
    aio: str
```

`Flavours` is the simplest schema in the module. It represents four named string fields, each presumably corresponding to a distinct image or configuration "flavour." All four fields are required—there are no defaults. This class acts as a nested structure inside `BaseImages`.

### `BaseImages`

`BaseImages` wraps a single `Flavours` instance under the `images` field. It also defines a `@post_load` hook, `make_versions_dict`:

```python
@post_load
def make_versions_dict(self, data, **kwargs):
    data['versions'] = {version.replace('-', '_'): version_data
                        for version, version_data in data['versions']}
    return data
```

This hook runs after marshmallow has loaded the raw input. It transforms a `versions` entry by normalizing version keys—replacing hyphens with underscores—and rebuilding it as a dictionary. Note that this hook references a `versions` key that is not declared as a dataclass field; it operates on the raw `data` dictionary passed through the load pipeline, which means the actual loaded payload is expected to carry a `versions` collection of `(version, version_data)` pairs.

### `PromoteParams`

```python
@dataclass
class PromoteParams:
    epsReleaseNumber: str
    dockerCompose: bool = False
    linkedDataCore: bool = False
    knowledgeServer: bool = False
    openStreetMap: bool = False
```

`PromoteParams` captures the parameters for a "promote" operation. Only `epsReleaseNumber` is required; the remaining four boolean flags default to `False`. This pattern allows callers to enable specific components selectively while keeping the common case (all flags off) concise. The field names use camelCase, suggesting the input data originates from a JSON API where camelCase is conventional.

### `AuxiliaryImage`

```python
@dataclass
class AuxiliaryImage:
    image: str
    tag: str = 'latest'
```

`AuxiliaryImage` models a container image reference with an `image` name and an optional `tag` defaulting to `'latest'`. This mirrors standard Docker image conventions, where an untagged reference implies `latest`.

### `AuxiliaryImages`

`AuxiliaryImages` parses a collection of image strings into `AuxiliaryImage` instances. Its work happens in `__post_init__`:

```python
def __post_init__(self):
    self.images = []
    for item in self.images_str:
        parts = item.split(':')
        match len(parts):
            case 1: self.images.append(AuxiliaryImage(parts))
            case 2: self.images.append(AuxiliaryImage(*parts))
            case _: raise ValidationError('Invalid format. Expected "key:value"') from None
```

After construction, the class iterates over `images_str`, splitting each entry on the colon character. Using Python's structural pattern matching (`match`/`case`):

- **One part** (`case 1`): No tag was provided, so an `AuxiliaryImage` is created from the image name alone (relying on the default `tag`).
- **Two parts** (`case 2`): Both image and tag are present, and the parts are unpacked positionally into `AuxiliaryImage`.
- **Any other count** (`case _`): The input does not match the expected `image:tag` form, and a `ValidationError` is raised.

The parsed results are stored in a new `self.images` attribute. This is a derived field computed from the raw input rather than a declared schema field.

> **Note on behavior:** In `case 1`, the code passes the entire `parts` list (`AuxiliaryImage(parts)`) rather than `parts[0]`. This means the `image` field receives a list rather than a string in that branch.

### `ImageParams`

```python
@dataclass
class ImageParams:
    project_id: str
    revision: str
```

`ImageParams` is a straightforward schema with two required string fields, `project_id` and `revision`. It identifies an image by its project and a specific revision.

## Usage Examples

Because these are `marshmallow_dataclass` dataclasses, each has an associated schema accessible via `.Schema`, and instances can be created either directly or by loading raw data.

### Direct instantiation

```python
params = PromoteParams(epsReleaseNumber="2024.1", dockerCompose=True)
# linkedDataCore, knowledgeServer, openStreetMap all default to False
```

### Loading from raw input

```python
schema = ImageParams.Schema()
image = schema.load({"project_id": "abc", "revision": "v3"})
# image is an ImageParams instance, validated against the field types
```

### Parsing auxiliary images

```python
aux = AuxiliaryImages(images_str=["redis:7", "nginx"])
# aux.images -> [AuxiliaryImage(image="redis", tag="7"),
#                AuxiliaryImage(image=[...], tag="latest")]
```

## Integration

This module sits at the API boundary of the MPS system, as indicated by its location under `mps.api`. Its role is to:

- **Validate incoming requests:** API endpoints can use the generated marshmallow schemas to deserialize and validate request bodies before passing them into business logic.
- **Normalize data:** Hooks like `make_versions_dict` and the parsing logic in `AuxiliaryImages.__post_init__` transform raw external representations (hyphenated version keys, colon-delimited image strings) into clean internal structures.
- **Provide typed contracts:** By expressing parameters as typed dataclasses, downstream code receives well-defined objects (`PromoteParams`, `ImageParams`, etc.) rather than raw dictionaries.

The two external dependencies, `marshmallow` and `marshmallow_dataclass`, supply the validation framework. `marshmallow` provides the `post_load` hook and `ValidationError` for raising validation failures, while `marshmallow_dataclass` provides the `dataclass` decorator that unifies dataclass declarations with schema generation. Together they allow this module to define concise, declarative schemas that integrate cleanly with the rest of the API layer.