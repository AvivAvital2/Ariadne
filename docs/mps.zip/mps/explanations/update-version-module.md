---
id: 8e58463c-e5bf-5bf8-a894-d41ea3091f63
type: explanation
title: "Update Version Module"
created_at: 2026-06-06T19:04:47.722429+00:00
updated_at: 2026-06-20T22:55:21.293739+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  module_name: "update_version"
  language: "python"
  source_name: "mps"
---
# Update Version Module

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# Update Version Module


# `update_version` Module

## Overview

The `update_version` module is a small utility script designed to programmatically update the version number declared in a project's `pyproject.toml` file. It reads a target version from an environment variable and writes that value into the Poetry configuration section of the TOML file.

This kind of script is typically used in automated release pipelines—such as CI/CD workflows—where the version number is determined externally (for example, from a Git tag or a build parameter) and needs to be injected into the project metadata without manual editing.

## Key Concepts

### `pyproject.toml` and Poetry

[Poetry](https://python-poetry.org/) is a dependency management and packaging tool for Python. It stores project metadata, including the package version, inside the `pyproject.toml` file under the `[tool.poetry]` table. In TOML's nested structure, this corresponds to the following path:

```
tool → poetry → version
```

This module targets exactly that nested key when applying the update.

### TOML Read/Write with `tomli` and `tomli_w`

The module uses two complementary libraries to handle TOML data:

- **`tomli`** — A read-only TOML parser. It loads a TOML document into a standard Python dictionary.
- **`tomli_w`** — A TOML writer. It serializes a Python dictionary back into TOML format.

These two libraries are deliberately separated by design: `tomli` focuses solely on parsing, while `tomli_w` handles output. Both operate on files opened in **binary mode** (`"rb"` and `"wb"`), which is a requirement of these libraries rather than an optional choice.

### Configuration via Environment Variables

The desired version is not passed as a function argument or command-line flag. Instead, it is read from the `VERSION` environment variable. This pattern is common in deployment and build environments, where configuration is injected through the process environment rather than hardcoded.

## How It Works

The module exposes a single function, `update_version`, which performs the update in four sequential steps:

### 1. Read the Target Version

```python
version = os.getenv("VERSION")
if not version:
    raise ValueError("VERSION environment variable is not set")
```

The function retrieves the `VERSION` environment variable. If it is unset (or empty), the function raises a `ValueError` immediately. This fail-fast behavior prevents the script from silently writing an empty or invalid version into the file.

### 2. Parse the Existing Configuration

```python
with open("pyproject.toml", "rb") as f:
    pyproject = tomli.load(f)
```

The `pyproject.toml` file is opened in binary read mode and parsed into a Python dictionary named `pyproject`. The file path is relative, so the script expects to be run from the project's root directory.

### 3. Update the Version Key

```python
pyproject["tool"]["poetry"]["version"] = version
```

The function navigates the nested dictionary structure to the `version` key under `tool.poetry` and overwrites it with the new value. Only this single key is modified; the rest of the document remains untouched in memory.

### 4. Write the Updated Configuration

```python
with open("pyproject.toml", "wb") as f:
    tomli_w.dump(pyproject, f)
```

The modified dictionary is serialized back to TOML and written over the original `pyproject.toml` file in binary write mode. This step rewrites the entire file from the in-memory representation.

### Script Entry Point

```python
if __name__ == "__main__":
    update_version()
```

When the module is executed directly (rather than imported), it calls `update_version` automatically. This makes the script convenient to run as a standalone command.

## Usage Examples

### Running from the Command Line

Set the `VERSION` environment variable and run the script from the project root:

```bash
VERSION=1.2.3 python update_version.py
```

After execution, the `[tool.poetry]` section of `pyproject.toml` will contain:

```toml
[tool.poetry]
version = "1.2.3"
```

### Importing the Function

The function can also be imported and called from other Python code, though it still relies on the `VERSION` environment variable being set:

```python
from update_version import update_version

update_version()
```

## Integration

This module fits naturally into a release or build process for a Poetry-managed Python project. A typical integration looks like this:

1. A CI/CD pipeline determines the version (for example, from a Git tag).
2. The pipeline sets the `VERSION` environment variable.
3. The pipeline runs `update_version.py` to synchronize `pyproject.toml` with that version.
4. Poetry then uses the updated `pyproject.toml` for building and publishing the package.

### Operational Considerations

A few characteristics are worth noting for anyone integrating this script:

- **Working directory dependency**: The script uses a relative path (`pyproject.toml`), so it must be invoked from the directory containing that file.
- **Assumed structure**: The script assumes that `tool.poetry` already exists in the file. If those keys are missing, accessing `pyproject["tool"]["poetry"]` would raise a `KeyError`.
- **Formatting**: Because the file is fully rewritten via `tomli_w.dump`, comments and certain stylistic details in the original `pyproject.toml` may not be preserved, as `tomli` parses only the data, not formatting.

These trade-offs keep the script simple and predictable, which is well suited to its narrow role as an automation helper.