---
id: 8bf86c1e-d09c-5bf7-a079-180e754e985c
type: explanation
title: "Maintenance Module"
created_at: 2026-06-06T19:04:23.345567+00:00
updated_at: 2026-06-20T22:55:21.304575+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  module_name: "mps.routers.maintenance"
  language: "python"
  source_name: "mps"
---
# Maintenance Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# Maintenance Module


# `mps.routers.maintenance` Module Documentation

## Overview

The `mps.routers.maintenance` module defines a set of optional HTTP endpoints used for operational and troubleshooting tasks within the Model Promotion Service (MPS). These endpoints expose maintenance capabilities related to container image management, such as listing locally exported images, deleting them from local storage, calculating their total size on disk, and listing images that have been pushed to a remote container registry.

A defining characteristic of this module is that **its routes are conditionally registered**. They are only added to the application when the service is explicitly started in a maintenance mode. This keeps these potentially sensitive or disruptive operations (like deleting images) out of the standard API surface during normal operation.

## Key Concepts

### Conditional Route Registration

The most important pattern in this module is the gating of all route definitions behind an environment variable check:

```python
troubleshoot = os.environ.get('MAINTENANCE_MODE')
if troubleshoot and troubleshoot.lower() == 'true':
    # routes are defined here
```

The route handlers are declared *inside* this `if` block. This is a deliberate design choice: when `MAINTENANCE_MODE` is not set to `"true"`, the functions are never defined and the `router` is left empty. As a result, the maintenance endpoints simply do not exist in the running application, rather than being defined and returning an error.

The check is case-insensitive (`troubleshoot.lower() == 'true'`) and also guards against `None` by first confirming `troubleshoot` is truthy.

### The `APIRouter` and Tagging

The module uses FastAPI's `APIRouter` to group its endpoints. All routes are tagged with `"Maintenance"`:

```python
router = APIRouter(tags=["Maintenance"])
```

Tags are used by FastAPI to organize endpoints in the generated OpenAPI/Swagger documentation. Grouping all maintenance endpoints under a single tag makes them easy to find together in the docs (available under `/modelpromotion/docs`, as noted in the debug log message).

### Delegation to the Service Layer

None of the route handlers contain business logic. Instead, each delegates to the shared `mps.image_manager` object:

| Handler | Service call |
|---------|--------------|
| `list_images` | `mps.image_manager.list_local_images()` |
| `delete_local_images` | `mps.image_manager.delete_local_images()` |
| `get_total_images_size` | `mps.image_manager.get_size_of_images()` |
| `remote_images` | `mps.image_manager.list_pushed_images()` |

This keeps the router thin: its responsibility is HTTP concerns (paths, methods, response formatting, documentation), while the actual image operations live in the service layer. The `mps.registry_provider` attribute is also referenced to construct human-readable summaries that name the relevant container registry.

### Response Formatting

Different endpoints use different FastAPI response types depending on the shape of their output:

- **`list[str]`** — declared as the `response_model` for the listing and deletion endpoints, so FastAPI serializes returned lists directly as JSON.
- **`PlainTextResponse`** — used for the total image size, which returns a single human-friendly string.
- **`JSONResponse`** — used to explicitly wrap the remote image listing in a JSON response.

## How It Works

### Startup Behavior

1. When the application imports this module, the top-level code runs.
2. `os.environ.get('MAINTENANCE_MODE')` reads the environment variable.
3. If the value is `"true"` (case-insensitive), a debug log message is emitted indicating maintenance routes are being added, and the four route handlers are defined and attached to `router`.
4. If the value is anything else (or unset), the `if` block is skipped, leaving `router` with no routes.

The `router` is presumably included into the main FastAPI application elsewhere in the codebase. Because of the conditional definition, including this router is harmless in non-maintenance mode—it simply contributes nothing.

### Endpoint Walkthrough

**`GET /modelpromotion/maintenance/local_images` — `list_images`**

Returns a list of image identifiers that have already been exported to local storage. The handler awaits `mps.image_manager.list_local_images()` and returns the resulting list, which FastAPI serializes according to the `list[str]` response model.

**`DELETE /modelpromotion/maintenance/local_images` — `delete_local_images`**

Deletes images from local storage by awaiting `mps.image_manager.delete_local_images()`. The summary clarifies an important operational detail: images that were already successfully pushed to the container registry remain available there—only the *local* copies are removed. The return value (also `list[str]`) presumably reflects the affected images.

**`GET /modelpromotion/maintenance/total_image_size` — `get_total_images_size`**

Computes the combined on-disk size of exported images. It awaits `mps.image_manager.get_size_of_images()` (which returns a numeric byte count) and passes the result to `humanfriendly.format_size()`, converting it into a readable string such as `"1.5 GB"`. This string is returned wrapped in a `PlainTextResponse`.

**`GET /modelpromotion/maintenance/list_pushed_images` — `remote_images`**

Lists the images that have been pushed to the remote container registry by awaiting `mps.image_manager.list_pushed_images()`. The result is returned inside a `JSONResponse`.

## Usage Examples

### Enabling the Maintenance Endpoints

The endpoints are activated by setting the environment variable before starting the service:

```bash
export MAINTENANCE_MODE=true
# start the application
```

With this set, the routes become available and appear in the API documentation under `/modelpromotion/docs`.

### Calling the Endpoints

Once enabled, the endpoints can be exercised with standard HTTP requests:

```bash
# List locally exported images
curl http://localhost:8000/modelpromotion/maintenance/local_images

# Get the total size of exported images on disk
curl http://localhost:8000/modelpromotion/maintenance/total_image_size

# List images pushed to the registry
curl http://localhost:8000/modelpromotion/maintenance/list_pushed_images

# Delete local images
curl -X DELETE http://localhost:8000/modelpromotion/maintenance/local_images
```

## Integration

This module sits in the routing layer of the MPS application and connects several other parts of the system:

- **FastAPI** provides the `APIRouter` used to declare endpoints and the `JSONResponse` / `PlainTextResponse` types used to shape outputs. The `router` object is the integration point with the broader application, which includes it into the main app.
- **`mps.service.mps`** is the central service object. The router relies on `mps.image_manager` for all image operations and on `mps.registry_provider` to label the container registry in endpoint summaries. This keeps all image-related logic in the service layer and makes the router a thin HTTP adapter.
- **`mps.api.logger`** supplies the `logger` used to emit a debug message when the maintenance routes are registered, aiding observability during startup.
- **`humanfriendly`** is used purely for presentation, converting raw byte counts into readable size strings.
- **`os`** is used to read the `MAINTENANCE_MODE` environment variable that controls whether these routes exist at all.

In summary, this module provides an environment-gated, documentation-friendly group of maintenance endpoints that defer their actual work to the shared image manager, making image inspection and cleanup available to operators only when explicitly enabled.