---
id: b00ea531-98f7-56c8-aa29-0b38f6b7c9b5
type: explanation
title: "Errors Module"
created_at: 2026-06-06T19:03:25.017373+00:00
updated_at: 2026-06-20T22:55:21.310187+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  module_name: "mps.api.errors"
  language: "python"
  source_name: "mps"
---
# Errors Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# Errors Module


# `mps.api.errors` — Custom Exception Hierarchy

## Overview

The `mps.api.errors` module defines the custom exception hierarchy used throughout the MPS API. Its purpose is twofold:

1. **Provide domain-specific error types** that describe failure conditions in business terms (for example, "the container registry is unreachable" or "the configuration file is invalid") rather than relying on generic Python exceptions.
2. **Centralize error logging** so that every raised exception is automatically written to the application log at the moment it is constructed.

By giving each failure mode its own named exception class, calling code can catch and handle specific problems precisely, and the resulting log output and error messages become self-documenting.

## Key Concepts

### A single base class with many specializations

All exceptions in this module derive from a common base class, `ExceptionHandler`, which itself extends Python's built-in `Exception`. The concrete exception types (such as `NoConfigurationFoundError` or `UnreachableContainerRegistry`) are thin subclasses that add a descriptive docstring but otherwise delegate their behavior to the base class.

This is a classic **base-class-with-leaf-subclasses** pattern. The shared logic — logging, message storage, and string formatting — lives in one place, while the subclasses exist primarily to give each error a distinct *type* that can be matched in `except` clauses.

### Logging on construction

A notable design choice is that logging happens in the constructor, not at the point where the exception is caught. As soon as one of these exceptions is instantiated, the message is recorded via the module's `Logger`. This guarantees that the error is captured even if the exception is later swallowed or re-raised in a different form.

### Optional status codes

The base class accepts an optional `status_code` argument. This is useful in an API context, where an error may correspond to an HTTP status code or an upstream service's response code. Most exception types do not use it, but those tied to remote calls — notably `UnableToGetAuthToken` — explicitly require a status code.

## How It Works

### The `ExceptionHandler` base class

```python
class ExceptionHandler(Exception):
    def __init__(self, message, status_code=None):
        self.Logger = Logger(__name__).logger
        self.detail = message
        self.Logger.error(message)
        self.status_code = status_code
```

When any exception in this module is created, the following happens:

1. A logger is obtained from the `logger` module, scoped to `__name__`.
2. The provided `message` is stored on the instance as `self.detail`.
3. The message is immediately logged at the `error` level.
4. An optional `status_code` is stored on the instance.

The base class also overrides `__repr__` and `__str__` so that the exception renders cleanly using its class name and message. Note that `__init__` does **not** call `super().__init__(message)`, so `self.args` is not populated through the normal `Exception` machinery. Because `__str__` and `__repr__` reference `self.args[0]`, these methods rely on the message being present in `args`. (These display methods are marked `# pragma: no cover`, indicating they are excluded from test coverage measurement.)

### The concrete exception types

Each subclass follows the same minimal template. For example:

```python
class UnreachableContainerRegistry(ExceptionHandler):
    """Raised if specified container registry is unreachable"""
    def __init__(self, message: str):
        super(UnreachableContainerRegistry, self).__init__(message)
```

The docstring documents the precise condition under which the error should be raised, and the constructor simply forwards the message to the base class. The one exception to this uniform shape is `UnableToGetAuthToken`, which additionally requires a `status_code`:

```python
class UnableToGetAuthToken(ExceptionHandler):
    """Raised if MPS was unable to fetch an AWS ECR token"""
    def __init__(self, message: str, status_code: int):
        super(UnableToGetAuthToken, self).__init__(message, status_code)
```

This reflects that authentication failures against AWS ECR carry a meaningful response code worth preserving.

### The full set of error conditions

The exception types map directly onto the operational concerns of the system. Grouped by area, they cover:

**Configuration**
- `NoConfigurationFoundError` — a required value (such as a version) was missing from the configuration file.
- `NoConfigurationFileFoundError` — the configuration file itself could not be located.
- `InvalidConfigurationFile` — the configuration file was present but malformed.
- `MissingConfigValues` — one or more required configuration values were absent.

**Registry and image handling**
- `InvalidRegistryProvider` — the specified registry provider is not supported.
- `InvalidAWSRegion` — no AWS registry region was specified.
- `UnableToUploadOneOrMoreImages` — pushing auxiliary images to the registry failed.
- `UnreachableContainerRegistry` — the registry could not be contacted.
- `UnavailableImage` — a configured base image is missing both locally and remotely.
- `UnableToObtainPushedImagesFromContainerRegistry` — repositories could not be fetched from the registry.

**Authentication and credentials**
- `UnableToGetAuthToken` — an AWS ECR token could not be fetched.
- `UnableToStoreCredentialsFile` — credentials could not be written during login.
- `SelfSignedCertificate` — certificate verification was enabled but a self-signed certificate was encountered.

## Usage Examples

### Raising an exception

Within the codebase, these exceptions are raised when a corresponding failure is detected:

```python
from mps.api.errors import NoConfigurationFileFoundError

if not config_path.exists():
    raise NoConfigurationFileFoundError(
        f"Configuration file not found at {config_path}"
    )
```

Simply constructing and raising the exception logs the message automatically — no separate logging call is needed at the raise site.

### Raising an exception with a status code

```python
from mps.api.errors import UnableToGetAuthToken

response = request_ecr_token()
if response.status_code != 200:
    raise UnableToGetAuthToken(
        "Failed to fetch ECR auth token",
        status_code=response.status_code,
    )
```

### Catching specific failures

Because each condition has its own type, callers can handle them individually or group them by their shared base class:

```python
from mps.api.errors import (
    ExceptionHandler,
    UnreachableContainerRegistry,
    UnavailableImage,
)

try:
    push_images()
except UnreachableContainerRegistry as exc:
    # network-level problem — perhaps retry
    notify(exc.detail, exc.status_code)
except ExceptionHandler as exc:
    # any other MPS-defined error
    abort(exc.detail)
```

Catching `ExceptionHandler` provides a convenient way to handle *any* application-defined error while still allowing built-in Python exceptions to propagate normally.

## Integration

This module sits at the boundary between MPS's operational logic and its observability and error-reporting layers.

- **`logger`**: The base class depends on the `Logger` class from the sibling `logger` module to emit error-level log entries. Every exception construction routes through this logger, which means error logging is consistent across the entire API without each call site needing to remember to log.
- **`sys`**: Imported for use in the display methods, where `sys.excepthook` is referenced in `__repr__`.

In the broader system, modules responsible for reading configuration, authenticating against AWS ECR, contacting container registries, and uploading or querying images all raise these exceptions. Higher-level API handlers can then catch them — using either the specific types or the shared `ExceptionHandler` base — to translate internal failures into appropriate responses, optionally using the `status_code` attribute where it is set.