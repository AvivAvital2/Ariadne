---
id: d4001b9b-c2c3-59fc-8d38-7e875e932988
type: explanation
title: "Config Module"
created_at: 2026-06-06T19:03:18.745592+00:00
updated_at: 2026-06-20T22:55:21.321005+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  module_name: "mps.api.config"
  language: "python"
  source_name: "mps"
---
# Config Module

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# Config Module


# `mps.api.config` Module Documentation

## Overview

The `mps.api.config` module is responsible for loading, validating, and merging application configuration at import time. It reads two configuration sources—a JSON file containing default values and a TOML file containing deployment-specific (or "promotion") settings—and combines them into a single configuration object.

A key characteristic of this module is that **all of its logic runs at import time**. There are no functions or classes to call; simply importing the module triggers configuration validation and loading. If the configuration files are missing or invalid, the import itself will fail with a descriptive error. This "fail fast" approach ensures that the application cannot start in a misconfigured state.

The module also exposes several commonly used configuration values as top-level module attributes for convenient access elsewhere in the codebase.

## Key Concepts

### Two-Tier Configuration

The module uses a layered configuration strategy:

- **`conf/defaults.json`** — Provides baseline default values for configuration sections and keys.
- **`conf/promotion.toml`** — Provides environment- or deployment-specific overrides.

Values from the TOML file take precedence, while the JSON defaults fill in any gaps. This pattern allows operators to specify only the settings that differ from the defaults, keeping deployment configuration minimal.

### Validation Through Structural Pattern Matching

The module validates each configuration file using Python's `match`/`case` statement (structural pattern matching, available in Python 3.10+). Each `case` includes a guard condition (`if ...`) that checks a specific failure mode. This produces a clean, ordered series of validation checks where the first matching failure raises an appropriate exception.

### Custom Exceptions

Two domain-specific exceptions are imported from `mps.api.errors`:

- `NoConfigurationFileFoundError` — raised when a required file does not exist.
- `InvalidConfigurationFile` — raised when a file exists but is unusable (not a regular file, empty, or unreadable).

These exceptions make configuration failures explicit and distinguishable from generic I/O errors.

## How It Works

### Step 1: Define the Files to Validate

The module lists the configuration files it depends on:

```python
file_paths = [
    'conf/defaults.json',
    'conf/promotion.toml'
]
```

These paths are relative to the current working directory, meaning the application must be started from a directory containing a `conf/` folder.

### Step 2: Validate Each File

The module iterates over the file paths and runs a sequence of checks for each one using pattern matching:

1. **Existence** — If the file does not exist, raise `NoConfigurationFileFoundError`.
2. **Regular file check** — If the path exists but is not a regular file (for example, a directory or an incorrectly mounted volume), raise `InvalidConfigurationFile`.
3. **Non-empty check** — If the file size is `0`, raise `InvalidConfigurationFile`. The error message hints at a likely cause: an incorrectly mounted volume or permission issue.
4. **Readability check** — If the process lacks read permission (`os.R_OK`), raise `InvalidConfigurationFile`.
5. **Default case** — If all checks pass, `continue` to the next file.

The error messages are notably oriented toward containerized deployments, repeatedly suggesting that problems may stem from volumes being "mounted incorrectly." This indicates the module is designed to run in an environment where configuration is injected via mounted files.

The use of `from None` on each `raise` suppresses any chained exception context, producing cleaner error output focused on the configuration problem itself.

### Step 3: Load the Configuration Files

After validation, the files are loaded:

```python
with open('conf/defaults.json') as defaults_fh:
    defaults = json.load(defaults_fh)

with open('conf/promotion.toml', 'rb') as f:
    config = tomllib.load(f)
```

Note that `tomllib` requires the file to be opened in binary mode (`'rb'`), which is why the two files are opened differently.

### Step 4: Merge Defaults Into the Configuration

The module fills in missing values using a two-level merge:

```python
for section, section_defaults in defaults.items():
    section_dict = config.setdefault(section, {})
    for key, default in section_defaults.items():
        section_dict.setdefault(key, default)
```

This walks through each section and key in the defaults. The `setdefault` calls ensure that:

- If a section is absent from the TOML config, it is created from defaults.
- If a key already exists in the TOML config, its value is preserved (TOML wins).
- If a key is missing, the default value is applied.

This is a shallow, two-level merge—it merges sections and their immediate keys but does not recursively merge deeply nested structures.

### Step 5: Expose Convenience Attributes

Finally, several frequently used values are extracted into module-level variables:

```python
base_images = config['baseImage']
image_cache_path = config['local_image_cache']['path']
repo_prefix = config['general']['repo_prefix']
exported_image_path = config['exported_images']['path']
```

Because these use direct indexing (`[...]`) rather than `.get()`, a missing key will raise a `KeyError` at import time. This means the merged configuration is expected to always contain these keys—either from the TOML file or from the JSON defaults.

## Usage Examples

This module has no functions or classes to invoke. Instead, you consume its results by importing it:

```python
from mps.api import config

# Access the full merged configuration
print(config.config)

# Access convenience attributes
print(config.repo_prefix)
print(config.image_cache_path)
print(config.base_images)
```

Because the validation and loading occur during import, any configuration problem surfaces the moment another module imports `mps.api.config`. For example, attempting to start the application without a `conf/promotion.toml` file would raise:

```
NoConfigurationFileFoundError: The promotion.toml config file was not found
```

## Integration

This module sits at the foundation of the `mps.api` package and is intended to be imported by other components that need configuration values.

- **`mps.api.errors`** — Supplies the custom exception types used to signal configuration problems, allowing callers (or a top-level error handler) to distinguish configuration failures from other runtime errors.
- **Standard library dependencies** — `json` and `tomllib` parse the two file formats; `pathlib` and `os` perform filesystem inspection and permission checks.

The exposed attributes (`base_images`, `image_cache_path`, `repo_prefix`, `exported_image_path`) suggest this module supports a system that manages container or machine images—handling base images, a local image cache, repository naming, and exported image storage. Other modules in the `mps` package likely rely on these values to locate and organize image artifacts.

### Operational Notes

- **Working directory matters.** Because the file paths are relative, the application must be launched from a directory containing the `conf/` folder, or the import will fail.
- **Import-time side effects.** Importing this module performs file I/O and may raise exceptions. Callers should be aware that the import is not free of side effects and should ensure configuration files are present before import.