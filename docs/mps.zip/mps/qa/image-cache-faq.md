---
id: 3d72dd92-110f-53f0-9e76-1f23d275b89c
type: qa
title: "Image Cache FAQ"
created_at: 2026-06-06T19:03:35.102570+00:00
updated_at: 2026-06-20T22:55:26.729455+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  module_name: "mps.api.image_cache"
  language: "python"
  source_name: "mps"
---
# Image Cache FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# Image Cache FAQ


# AsyncPersistentImageCache — FAQ

A SQLite-backed, asyncio-friendly key/value cache for storing image data (or any binary blobs) persistently across runs.

---

## Question
How do I get started using `AsyncPersistentImageCache`?

## Answer
The class is an **async context manager**, so use it with `async with`. The context manager handles opening the SQLite connection and creating the table on entry, and closing the connection on exit.

```python
import asyncio
from mps.api.image_cache import AsyncPersistentImageCache

async def main():
    async with AsyncPersistentImageCache() as cache:
        await cache.set("logo.png", b"\x89PNG\r\n...")  # store bytes
        data = await cache.get("logo.png")              # retrieve bytes
        print(data)

asyncio.run(main())
```

Because all methods are coroutines, you must `await` every call.

---

## Question
Where is the cache stored, and can I change the location?

## Answer
The database file is created at:

```python
self.db_path = os.path.join(image_cache_path, 'image_cache.sqlite')
```

The directory comes from `image_cache_path` in `mps.api.config`. The class does **not** accept a custom path argument, so to change where data is stored you configure `image_cache_path` in the config module.

**Pitfall:** The directory referenced by `image_cache_path` must already exist. The code does not create it — `aiosqlite.connect` will fail if the parent directory is missing. Ensure the path exists before entering the context:

```python
import os
from mps.api.config import image_cache_path
os.makedirs(image_cache_path, exist_ok=True)
```

---

## Question
What's the difference between `set` and `update`?

## Answer
- **`set(key, value)`** uses `INSERT OR REPLACE`. It will create a new entry **or** overwrite an existing one. This is the safe, general-purpose write.
- **`update(key, value)`** uses a plain `UPDATE`. It only modifies a row that **already exists**. If the key isn't present, nothing happens (no error, no insert).

```python
await cache.set("a", b"hello")     # inserts or overwrites
await cache.update("a", b"world")  # updates existing 'a'
await cache.update("missing", b"x")  # silently does nothing
```

**Recommendation:** Prefer `set` unless you specifically want to avoid creating new keys.

---

## Question
How do I retrieve all cached entries at once?

## Answer
Use `list()`, which returns a dictionary mapping every key to its stored value:

```python
async with AsyncPersistentImageCache() as cache:
    all_items = await cache.list()
    for key, value in all_items.items():
        print(key, len(value))
```

**Pitfall:** `list()` loads the **entire cache into memory**. If you store many large images, this can be expensive. For single lookups, use `get(key)` instead.

---

## Question
How do I handle a cache miss?

## Answer
`get()` returns `None` when the key isn't found, rather than raising an exception:

```python
data = await cache.get("not-there")
if data is None:
    print("cache miss — fetch and store it")
    data = await fetch_image()
    await cache.set("not-there", data)
```

Always check for `None` before using the result.

---

## Question
Is this cache safe to use with concurrent tasks?

## Answer
Yes, for **writes**. All write operations (`set`, `update`, `delete`, `clear`) go through `_execute`, which serializes them with an `asyncio.Lock`:

```python
async def _execute(self, query, parameters=None):
    async with self.lock:
        async with self.conn.cursor() as cursor:
            await cursor.execute(query, parameters)
        await self.conn.commit()
```

This prevents concurrent writes from interleaving on the same connection.

**Caveats:**
- Reads (`get`, `list`) do **not** take the lock, so they can run concurrently with writes — generally fine for SQLite reads, but be aware of it.
- The lock only protects a **single instance**. Multiple `AsyncPersistentImageCache` instances (or processes) pointing at the same file are not coordinated by this lock — they rely on SQLite's own file-level locking.

---

## Question
Can I share one cache instance across many operations instead of reopening it constantly?

## Answer
Yes, and you should. Opening the connection on every operation is wasteful. Keep the context open for the duration of your work:

```python
async with AsyncPersistentImageCache() as cache:
    await cache.set("a", b"1")
    await cache.set("b", b"2")
    await asyncio.gather(
        cache.get("a"),
        cache.get("b"),
    )
```

**Pitfall:** Calling methods like `get` or `set` **outside** the `async with` block (or before `__aenter__` runs) will fail because `self.conn` is still `None`. The connection only exists between `__aenter__` and `__aexit__`.

---

## Question
How do I delete a single entry or wipe the whole cache?

## Answer
Use `delete(key)` for one entry, and `clear()` to remove everything:

```python
async with AsyncPersistentImageCache() as cache:
    await cache.delete("logo.png")  # remove one key
    await cache.clear()             # remove all entries
```

Both are committed immediately. Note `delete` on a non-existent key is a no-op (no error).

---

## Question
What data types can I store as values?

## Answer
The `value` column is declared as `BLOB`, and the column is intended for binary image data. Store **bytes**:

```python
with open("image.png", "rb") as f:
    await cache.set("image.png", f.read())
```

If you pass a `str`, SQLite will store it as text rather than a blob, which can lead to type inconsistencies on retrieval. Encode strings explicitly if needed (`my_str.encode()`). Keys are stored as `TEXT` and act as the primary key, so each key is unique.

---

## Question
What happens if an error occurs during a write?

## Answer
`_execute` commits only after a successful `cursor.execute`. If `execute` raises (e.g., a constraint or SQL error), the exception propagates up and the `commit()` is skipped, so the change isn't persisted. However, there is **no explicit rollback** in the code.

Wrap calls in try/except to handle failures gracefully:

```python
try:
    await cache.set(key, value)
except Exception as e:
    logger.error("Failed to cache %s: %s", key, e)
```

Also note: exceptions raised inside the `async with` block still trigger `__aexit__`, which closes the connection cleanly.