---
id: 800845e1-ed57-55d1-8173-f3ca4fe4be72
type: qa
title: "Dockerfile FAQ"
created_at: 2026-07-03T05:57:47.292314+00:00
updated_at: 2026-07-03T05:57:47.292325+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/builder/Dockerfile`

# stage0.Dockerfile — Q&A Documentation

## Question
What is this Dockerfile for, and what does it build?

## Answer
This is a **builder image** for SparkBeyond's service-promotion project. It extends an existing prediction-server builder image and layers on a full toolchain needed to build and deploy JVM/Scala-based services. Specifically, it installs:

- **JDK 8** (Amazon Corretto 8.212) and **SBT** (Scala build tool)
- **R**, **embedded Python 2 and Python 3**, and various SparkBeyond shared tools (MLlib driver, Weka wrapper, NLP4J, WordNet)
- **Docker CLI**, **docker-compose**, **Helm**, and **kubectl** for container and Kubernetes operations
- **AWS CLI** and **git**

The final `CMD ["/bin/bash"]` means the container drops you into a shell by default — it's meant to be used as a build/CI environment rather than a long-running service.

---

## Question
How do I build and run this image locally?

## Answer
Because the base image lives in a private AWS ECR registry, you must authenticate to ECR before building.

```bash
# Authenticate Docker to the ECR registry (eu-west-1)
aws ecr get-login-password --region eu-west-1 \
  | docker login --username AWS \
    --password-stdin 551806661322.dkr.ecr.eu-west-1.amazonaws.com

# Build the image
docker build -f stage0.Dockerfile -t service-promotion-builder:local .

# Run an interactive shell (default CMD is /bin/bash)
docker run -it --rm service-promotion-builder:local
```

If you plan to run Docker commands *inside* the container, mount the host Docker socket:

```bash
docker run -it --rm -v /var/run/docker.sock:/var/run/docker.sock \
  service-promotion-builder:local
```

---

## Question
How do I override the tool versions (SBT, Helm, kubectl, etc.)?

## Answer
The versions are declared as `ARG` values, so you can override them at build time with `--build-arg` without editing the Dockerfile:

```bash
docker build -f stage0.Dockerfile \
  --build-arg SBT_VERSION=1.3.13 \
  --build-arg HELM_VERSION=3.5.0 \
  --build-arg KUBECTL_VERSION=1.20.0 \
  -t service-promotion-builder:custom .
```

Available build args and their defaults:

| ARG | Default |
|-----|---------|
| `SBT_VERSION` | `1.2.8` |
| `DOCKER_VERSION` | `18.06.2-ce` |
| `DOCKER_COMPOSE_VERSION` | `1.23.1` |
| `EMBEDDED_PYTHON3_VERSION` | `1.0.4` |
| `HELM_VERSION` | `3.2.1` |
| `KUBECTL_VERSION` | `1.18.0` |

**Pitfall:** The JDK, R, and SparkBeyond tool RPM versions are *hard-coded* URLs, not ARGs. To change those you must edit the `yum install` URLs directly.

---

## Question
Why is the timezone set to UTC, and how would I change it?

## Answer
The first `RUN` removes the existing `/etc/localtime` and symlinks it to UTC:

```dockerfile
RUN /bin/sh -c "rm -fr /etc/localtime" \
    && ln -s /usr/share/zoneinfo/UTC /etc/localtime
```

This ensures reproducible, timezone-independent builds and logs — important in CI so timestamps are consistent regardless of the host. To use a different zone, replace `UTC` with a valid tz identifier, e.g. `Europe/London`. Generally you should **keep UTC** for build environments to avoid subtle time-based test failures.

---

## Question
Why does the WordNet installation step end with `|| :` and use `pushd`/`popd`?

## Answer
Look at the structure of that `RUN`:

```dockerfile
RUN /bin/sh -c "[ ! -d /opt/sparkbeyond/shared/WordNet-3.0/ ]" \
    && mkdir /tmp/wordnet-fix \
    ...
    && popd > /dev/null   || :
```

- The `[ ! -d ... ]` test makes the step **idempotent**: if WordNet is already present (e.g., baked into the base image), the test fails and the whole chain short-circuits.
- The trailing **`|| :`** is a no-op (`:` is the shell "true" builtin). It guarantees the `RUN` exits with status `0` even when the directory-exists check fails, so the build doesn't error out just because WordNet was already installed.

**Gotcha:** This pattern also swallows *real* failures in the download/extract steps. If WordNet is missing at runtime, check the build log for the curl/rpm2cpio output rather than relying on the exit code.

---

## Question
How is Java selected when multiple JDKs might exist?

## Answer
The Corretto JDK is registered via the `alternatives` system so it becomes the default `java`:

```dockerfile
RUN /bin/sh -c "alternatives --install /usr/bin/java java \
    /opt/sparkbeyond/embedded/amazon-corretto-8.212.04.2-linux-x64/bin/java 1"
```

To verify inside the container:

```bash
java -version          # should report Corretto 1.8.0_212
which java             # /usr/bin/java -> alternatives symlink
```

If you install another JDK and Java resolution breaks, use `alternatives --config java` to pick the correct one, or check `alternatives --display java`.

---

## Question
What is the `~/.sbt/repositories` file doing, and why does it matter?

## Answer
This step forces SBT to resolve all dependencies through SparkBeyond's internal Nexus proxies instead of hitting public Maven/Ivy repos directly:

```dockerfile
RUN /bin/sh -c "mkdir -p ~/.sbt"
RUN /bin/sh -c "echo $'[repositories]\n  local\n  \
                sparkbeyond-ivy-proxy-releases: https://nexus.dev.sparkbeyond.ai/...\n  \
                sparkbeyond-mvn-proxy-releases: https://nexus.sparkbeyond.com/...' \
                > ~/.sbt/repositories"
```

Why it matters:
- **Reproducibility & speed** — internal proxies cache artifacts and are reachable from the build network.
- **Reliability** — avoids dependence on external repo availability.

**Pitfalls:**
- The file is written to **root's** `~/.sbt`. If you run SBT as a different user, it won't pick up these repositories.
- SBT only honors this file when launched with `-Dsbt.override.build.repos=true`. Make sure your build invocation sets that flag, otherwise project-level resolver definitions may still reach public repos.

---

## Question
The image installs many `yum` packages — how does it keep the image size down?

## Answer
Almost every `yum` step ends with a cleanup chain to remove package caches:

```dockerfile
    && yum -q clean all \
    && rm -rf /var/cache/yum \
    && rm -rf /var/tmp/yum-root-*
```

Because these commands are chained with `&&` **inside the same `RUN`**, the cache is deleted in the *same layer* it was created — so it never bloats the final image. If you add new packages, follow the same pattern: install and clean in a single `RUN`. Splitting them across separate `RUN` instructions would leave the cache permanently in an earlier layer.

---

## Question
Why is the Docker CLI installed as a static binary instead of via a package manager?

## Answer
It downloads the official static tarball and extracts binaries straight into `/usr/bin`:

```dockerfile
&& curl -fsSL "https://download.docker.com/linux/static/stable/x86_64/docker-${DOCKER_VERSION}.tgz" \
   | tar xzf - --strip-components=1 -C /usr/bin
```

This is the **client only** — it does not run a Docker daemon inside the image. Use it in a Docker-in-Docker or socket-mounted setup. Advantages of the static binary approach:
- Pin an **exact** Docker version (`${DOCKER_VERSION}`) independent of the OS repos.
- No daemon/systemd dependencies pulled in.

To use it at runtime, mount the host daemon socket (see the "run locally" answer) or point `DOCKER_HOST` at a remote daemon.

---

## Question
Why are two GPG keys imported before installing packages, and what happens if I skip it?

## Answer
```dockerfile
RUN rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7 \
    && rpm --import http://dl.fedoraproject.org/pub/epel/RPM-GPG-KEY-EPEL-7 \
    && update-ca-trust \
    && yum-config-manager --disable bintray--sbt-rpm
```

- Importing the **CentOS-7** and **EPEL-7** GPG keys lets `yum` verify package signatures. Without them, signed-package installs would fail with GPG verification errors (or require `--nogpgcheck`, which is insecure).
- `update-ca-trust` refreshes the system CA bundle so the subsequent HTTPS downloads from Nexus succeed.
- Disabling the `bintray--sbt-rpm` repo is important because **Bintray was shut down** — leaving it enabled causes `yum` failures on 404s. SBT is instead installed from the internal Nexus repos added in the next step.

**Pitfall:** If you fork this and remove the `yum-config-manager --disable` line, expect intermittent build failures from the dead Bintray endpoint.