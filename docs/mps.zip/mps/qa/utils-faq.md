---
id: e4c3b8ff-becd-5b8e-ad1c-29e82b98a2ad
type: qa
title: "Utils FAQ"
created_at: 2026-06-06T19:04:06.466642+00:00
updated_at: 2026-06-20T22:55:26.749747+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  module_name: "mps.api.utils"
  language: "python"
  source_name: "mps"
---
# Utils FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# Utils FAQ


# `mps.api.utils` — Developer FAQ

## Question
How do I use `MPSSession` to make requests against a fixed base URL?

## Answer
`MPSSession` is a subclass of `requests.Session` that automatically prepends a `base_url` to every request, so you only need to pass relative paths.

```python
from mps.api.utils import MPSSession

session = MPSSession(
    base_url="https://registry.example.com",
    auth=("user", "password"),
    verify=True,
)

# The URI is joined with the base_url internally
response = session.get("/v2/_catalog")
print(response.status_code)
```

**Gotcha:** Because it uses `urllib.parse.urljoin`, be careful with leading slashes. `urljoin("https://host/api/", "v2/")` yields `https://host/api/v2/`, but `urljoin("https://host/api/", "/v2/")` yields `https://host/v2/` (the leading slash resets the path). Keep your base URL and relative paths consistent.

---

## Question
How do I run a shell command asynchronously and capture its output?

## Answer
Use `run_command`, which wraps `asyncio.create_subprocess_exec` and returns a tuple of `(stdout_lines, stderr_lines, exit_code)`. Both stdout and stderr are returned as lists of stripped strings.

```python
import asyncio
from mps.api.utils import run_command

async def main():
    stdout, stderr, code = await run_command("docker ps -a")
    for line in stdout:
        print(line)

asyncio.run(main())
```

You can pass a command either as a string (which is naively split on spaces) or as a pre-split list:

```python
# Preferred for arguments containing spaces
await run_command(["docker", "tag", "my image", "repo/img:1.0"])
```

**Pitfall:** String splitting uses `command.split(" ")`, so arguments containing spaces (paths, labels) will break. Pass a list in those cases.

---

## Question
How does error handling work in `run_command`, and how do I ignore failures?

## Answer
By default, if the process exits with a non-zero code, `run_command` raises a `RuntimeError` containing the command, stderr, and exit code:

```python
RuntimeError: Process failed
command=['false'] stderr=[] exit_code=1
```

If you expect a command to fail (or want to inspect the exit code yourself), set `supress_errors=True`:

```python
stdout, stderr, code = await run_command("docker inspect missing", supress_errors=True)
if code != 0:
    print("Command failed but no exception was raised")
```

---

## Question
What format does `parse_version_number` expect, and what does it return?

## Answer
It validates a version string against the regex `\d\.\d{1,2}\.\d` — i.e. `<major>.<minor>.<patch>` where major and patch are single digits and minor is 1–2 digits (e.g. `1.12.3`). Invalid strings raise an `Exception`.

The return type depends on `as_config_key`:

```python
# Returns a tuple of ints (default)
await parse_version_number("1.12.3")        # -> (1, 12, 3)

# Returns a dash-joined config key string
await parse_version_number("1.12.3", as_config_key=True)  # -> "1-12-3"
```

**Gotcha:** The pattern is strict. Versions like `10.2.1` (two-digit major), `1.2.10` (two-digit patch), or pre-release suffixes like `1.2.3-rc1` will **not** match and will raise.

---

## Question
How does `resolve_base_image_id` choose which base image to return?

## Answer
It looks up a base image in a nested `base_images` dict keyed by `release_key` (the dash-formatted version) and a *flavour* derived from feature flags:

| `use_linked_data_core` | `use_open_street_map` | flavour |
|---|---|---|
| True | True | `aio` |
| False | True | `osm` |
| True | False | `gdata` |
| False | False | `minimal` |

If `use_docker_compose=True`, the flavour is forced to `minimal` regardless of the other flags.

```python
base_images = {
    "1-12-3": {"aio": "img-aio-id", "minimal": "img-min-id"}
}

image_id = await resolve_base_image_id(
    base_images,
    release_version="1.12.3",
    use_linked_data_core=True,
    use_open_street_map=True,
    use_docker_compose=False,
)
# -> "img-aio-id"
```

If no matching `release_key`/`flavour` exists, it raises `NoConfigurationFoundError`.

---

## Question
What does `extract_model` do, and what happens to the source zip?

## Answer
It extracts a model archive into `destination`, then **always deletes the source zip** (the `os.remove` is in a `finally` block, so it runs even if extraction fails). It then attempts a second extraction of a nested `model.ser` archive.

```python
await extract_model("/tmp/model.zip", "/data/models/project1")
```

**Important pitfalls:**
- The source zip is deleted unconditionally — make sure you have a backup if you need it.
- The nested `model.ser` step is best-effort: if it isn't a valid zip, a `BadZipFile` is caught and logged at debug level rather than raised. So a "failed" inner extraction won't surface as an error.

---

## Question
How does `verify_connection_to_container_registry` handle SSL and retries?

## Answer
It polls the registry's `/v2/` endpoint up to **30 times** with a **10-second sleep** between failed attempts, and returns the working base URL.

- On success it returns `https://<registry>`.
- On a `ConnectionError`, it waits and retries.
- On an `SSLError`:
  - If the cert verification failed **and** `provider == 'local'` **and** `verify is True`, it raises `SelfSignedCertificate`, prompting you to set `REGISTRY_VERIFY_CERTIFICATE_SIGNING=False`.
  - Otherwise it falls back to checking plain HTTP, returning `http://<registry>` if that responds `200`.
- After exhausting all attempts, it raises `UnreachableContainerRegistry`.

```python
url = await verify_connection_to_container_registry(
    schema="https",
    registry="registry.local:5000",
    auth=("user", "pass"),
    verify=False,         # disable for self-signed certs
    provider="local",
)
```

**Note:** This function calls `urllib3.disable_warnings(InsecureRequestWarning)`, so insecure-request warnings are silenced globally for the process after it runs.

---

## Question
How do I convert a Docker image tag into a safe filename?

## Answer
`docker_image_to_file_name` strips any registry/repository prefix (everything up to the last `/`) and replaces the `:` separator with `_`:

```python
docker_image_to_file_name("registry.example.com/team/myapp:1.2.3")
# -> "myapp_1.2.3"

docker_image_to_file_name("myapp:latest")
# -> "myapp_latest"
```

This is useful for naming exported tarballs or cache files derived from an image tag.

---

## Question
Why do most of these functions raise exceptions with `from None`?

## Answer
The `raise ... from None` syntax suppresses the original exception's traceback chain in the "During handling of the above exception..." section. The intent is to surface a clean, domain-specific error (like `NoConfigurationFoundError` or `SelfSignedCertificate`) without exposing low-level internals to callers.

**Best practice when debugging:** Since the original cause is suppressed, add temporary logging or remove `from None` locally if you need the underlying traceback to diagnose an unexpected failure.

---

## Question
Can I reuse the `construct_model_id` helper, and what format does it produce?

## Answer
`construct_model_id` simply joins a project ID and revision with a colon to form an image-style identifier:

```python
await construct_model_id("project1", "abc123")
# -> "project1:abc123"
```

It wraps the formatting in a `try/except` that raises an `HTTPException` (status 400) on failure, making it convenient to call directly inside FastAPI route handlers. In practice the f-string almost never fails, but the guard ensures a clean HTTP error response if either argument is unexpectedly invalid.