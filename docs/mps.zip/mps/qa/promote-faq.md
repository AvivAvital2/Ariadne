---
id: b5c4c806-5454-55de-b7fa-e1888240ec95
type: qa
title: "Promote FAQ"
created_at: 2026-06-06T19:04:32.716921+00:00
updated_at: 2026-06-20T22:55:26.734175+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  module_name: "mps.routers.promote"
  language: "python"
  source_name: "mps"
---
# Promote FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# Promote FAQ


# Model Promotion API — FAQ

This document answers common questions about the `mps.routers.promote` module, which exposes FastAPI endpoints for promoting models into container images and checking image existence.

---

## Question
What endpoints does this module provide, and what does each one do?

## Answer
The module defines a FastAPI `APIRouter` with three routes:

| Method | Path | Function | Purpose |
|--------|------|----------|---------|
| `GET` | `/modelpromotion/promotion` | `get_promotion_status` | Placeholder (not yet implemented) |
| `POST` | `/modelpromotion/promotion/image/exists` | `is_image_exists` | Checks whether an image already exists in the registry |
| `POST` | `/modelpromotion/promotion/{project_id}/{revision}` | `promote` | Builds and pushes a model image |

The `promote` endpoint is the core of the module: it accepts a model archive in the request body, resolves the appropriate base image, builds an image, and pushes it to the registry.

---

## Question
How do I promote a model? What does a request look like?

## Answer
Send a `POST` to `/modelpromotion/promotion/{project_id}/{revision}` with the **model archive as the raw request body**, and pass promotion options as **query parameters** (mapped to `PromoteParams`).

```bash
curl -X POST \
  "https://host/modelpromotion/promotion/myproject/v1?dockerCompose=true&epsReleaseNumber=2024.1&linkedDataCore=false&openStreetMap=false" \
  --data-binary @model.zip \
  -H "Content-Type: application/octet-stream"
```

The body is streamed into a temporary `model.zip` file before being built into the image:

```python
file_path = os.path.join(dir_name, 'model.zip')
async with aiofiles.open(file_path, 'wb') as out_file:
    await out_file.write(await request_obj.body())
```

> **Note:** Parameters are parsed from the raw URL query string via `parse_qs`, not from FastAPI's automatic query-parameter binding. This means you must supply them in the URL, not the body.

---

## Question
What headers does the `promote` endpoint support, and what do they do?

## Answer
Three optional headers customize the build:

| Header | Format | Effect |
|--------|--------|--------|
| `auxImages` | comma-separated string | Split into a list of auxiliary images to include |
| `X-Algorithm-Whitelist` | comma-separated string | Currently logged only (parsing is commented out) |
| `X-ANNOTATIONS` | JSON object | Converted to `key=value` strings for image annotations |

Example:

```bash
curl -X POST "https://host/modelpromotion/promotion/myproject/v1?dockerCompose=false" \
  --data-binary @model.zip \
  -H "auxImages: helper:1.0,sidecar:2.1" \
  -H 'X-ANNOTATIONS: {"owner":"team-a","env":"prod"}'
```

The annotations header is transformed like so:

```python
annotations_list = None \
    if annotations_string is None \
    else [f"{k}={v}" for k, v in json.loads(annotations_string).items()]
# -> ["owner=team-a", "env=prod"]
```

> **Pitfall:** `X-Algorithm-Whitelist` is accepted and logged but **not currently applied** — the line that would split it into a list is commented out. Don't rely on it having an effect yet.

---

## Question
How does `is_image_exists` decide whether an image is present?

## Answer
It tries **both** export types — `compose` and `standalone` — constructing a model ID/tag for each and checking the registry:

```python
for export_type in ['compose', 'standalone']:
    tag = await construct_model_id(
        project_id=f'{params.project_id}_{export_type}',
        revision=params.revision
    )
    full_image_path = f'{mps.token_manager.registry}/{repo_prefix}/{tag}'
    image_path = await mps.image_manager.get_if_image_exists(full_image_path)
    if image_path is not None:
        return PlainTextResponse(content=f'{image_path}', status_code=200)

return PlainTextResponse(status_code=404)
```

- Returns **200** with the image path as plain text if *either* variant exists.
- Returns **404** (empty body) if neither exists.

Request example:

```bash
curl -X POST "https://host/modelpromotion/promotion/image/exists" \
  -H "Content-Type: application/json" \
  -d '{"project_id": "myproject", "revision": "v1"}'
```

---

## Question
How is the base image selected during promotion?

## Answer
The base image is resolved by `resolve_base_image_id`, which matches a configuration based on several promotion parameters:

```python
base_image_id = await resolve_base_image_id(
    base_images=base_images,
    release_version=params.epsReleaseNumber,
    use_linked_data_core=params.linkedDataCore,
    use_open_street_map=params.openStreetMap,
    use_docker_compose=params.dockerCompose
)
```

If no matching configuration exists, it raises `NoConfigurationFoundError`, which is caught and returned as an HTTP **500** with the error detail:

```python
except NoConfigurationFoundError as e:
    return PlainTextResponse(content=f"{e.detail}", status_code=500)
```

> **Tip:** If you get a 500 from promotion, check that your combination of `epsReleaseNumber`, `linkedDataCore`, `openStreetMap`, and `dockerCompose` corresponds to an entry in the `base_images` config.

---

## Question
What does the response from `promote` look like, and why does it differ?

## Answer
The response depends on `mps.registry_provider`:

```python
match mps.registry_provider:
    case 'export':
        match isinstance(image, PlainTextResponse):
            case True: return image                                    # pass through error/response
            case False: return PlainTextResponse(content=os.path.basename(image), status_code=200)
    case _:
        return PlainTextResponse(content=f"{image}")
```

- **`export` provider:** If the build returns a `PlainTextResponse` (typically an error), it's passed through directly. Otherwise, only the **base filename** of the image path is returned (200).
- **Any other provider:** The full image reference is returned as plain text.

So clients should not assume a fixed response shape — inspect the status code, and be aware the body may be a filename, a full image reference, or an error message.

---

## Question
Why is the model archive written to a temporary directory instead of kept in memory?

## Answer
The build process needs a file on disk to package into the image. The code uses `TemporaryDirectory`, which guarantees cleanup once the build completes (even on errors), avoiding leftover files:

```python
with TemporaryDirectory() as dir_name:
    file_path = os.path.join(dir_name, 'model.zip')
    async with aiofiles.open(file_path, 'wb') as out_file:
        await out_file.write(await request_obj.body())
    image = await mps.image_manager.build_and_push(...)
```

Using `aiofiles` keeps the write asynchronous so the event loop isn't blocked while persisting potentially large payloads.

> **Pitfall:** The entire body is read with `await request_obj.body()`, which buffers the full request in memory before writing. For very large model archives, be mindful of memory usage.

---

## Question
Why are parameters parsed manually with `parse_qs` instead of FastAPI's dependency injection?

## Answer
The handler reads and parses the raw query string itself:

```python
params_dict = parse_qs(str(request_obj.url).split("?")[-1])
params_dict = {key: value[0] if len(value) == 1 else value for key, value in params_dict.items()}

schema = class_schema(PromoteParams)()
params: PromoteParams = schema.load(params_dict)
```

This is because validation/deserialization is delegated to **marshmallow_dataclass** (`PromoteParams`) rather than FastAPI/Pydantic. The dict comprehension flattens single-value lists (`parse_qs` always returns lists) so `?dockerCompose=true` becomes `"true"` instead of `["true"]`.

> **Gotcha:** Because parameters bypass FastAPI's signature, they won't appear in the auto-generated OpenAPI docs for this endpoint. Refer to `PromoteParams` for the authoritative parameter list.

---

## Question
The `get_promotion_status` endpoint returns nothing — is that intentional?

## Answer
Yes, currently. It is a stub:

```python
@router.get("/modelpromotion/promotion")
async def get_promotion_status():
    # Todo
    pass
```

It is registered as a route but has no implementation (`pass` returns `None`). Don't depend on it yet — it's a placeholder for future status-tracking functionality. Calling it will return an empty/`null` response.

---

## Question
How can I debug a failed promotion?

## Answer
The handler logs key state at `debug` level via `mps.api.logger`:

```python
logger.debug(f'{project_id=} {revision=} {params=}')
logger.debug(f'Auxiliary images: {auxiliary_image_string=}')
logger.debug(f'Algorithm whitelist: {algorithm_string=}')
logger.debug(f'Annotations: {annotations_list=}')
logger.debug(f'Selected {base_image_id=}')
```

To troubleshoot:
1. **Enable debug logging** to see parsed params, headers, and the selected base image.
2. **Check for a 500 response** — this usually means `NoConfigurationFoundError` (no matching base image config).
3. **Verify the `X-ANNOTATIONS` header is valid JSON** — `json.loads` will raise if malformed.
4. **Inspect the response body** — for the `export` provider, errors are returned as a passed-through `PlainTextResponse`.

---

*Related concepts:* `PromoteParams` / `ImageParams` schemas, `resolve_base_image_id` (base image resolution), `mps.image_manager.build_and_push` (image build pipeline), and `mps.registry_provider` (response format selection).