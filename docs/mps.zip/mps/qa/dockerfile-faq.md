---
id: 48ed9125-0166-54ee-9f7d-c6d530344c19
type: qa
title: "Dockerfile FAQ"
created_at: 2026-07-03T05:57:46.926573+00:00
updated_at: 2026-07-03T05:57:46.926583+00:00
source_files:
  - /Users/spark/git/service-model-promotion/Dockerfile
metadata:
  module_name: "builder.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/Dockerfile`

# Model Promotion Service — `builder.Dockerfile` Q&A

## Question
What is this Dockerfile building, and why does it use a multi-stage build?

## Answer
This Dockerfile builds the **Model Promotion Service (MPS)**, a Python 3.13 application packaged as a wheel and served on port `8010`.

It uses a **multi-stage build** with two stages:

1. **`builder` stage** — installs build tooling (gcc, Poetry, etc.), resolves dependencies, and compiles the `mps` package into a wheel.
2. **Final stage** — a clean base image that copies only the installed `site-packages` and runtime artifacts from the builder, plus runtime tools (buildah, skopeo, etc.).

The benefit is a **smaller, cleaner final image**: build dependencies (gcc, musl-dev, Poetry, pip caches) never end up in the shipped image, reducing size and attack surface.

```dockerfile
FROM .../${BASE_IMAGE} AS builder   # stage 1: build the wheel
...
FROM .../${BASE_IMAGE}              # stage 2: runtime image
COPY --from=builder ...            # copy only what's needed
```

---

## Question
How do I build the image, and what build arguments do I need to pass?

## Answer
There are two important build args:

- `BASE_IMAGE` — defaults to `python:3.13.12-alpine3.23`.
- `VERSION` — **required** (no default). It’s used to locate the built wheel file.

```bash
docker build \
  --build-arg VERSION=v1.2.8 \
  -f builder.Dockerfile \
  -t mps:1.2.8 .
```

**Gotcha:** If you omit `VERSION`, the `pip install dist/mps-...` step will fail because the wheel filename won't match. The Dockerfile uses parameter expansion `${VERSION//v/}` to strip the `v` prefix (so `v1.2.8` → `1.2.8`) to match Poetry's wheel naming.

---

## Question
Why is `${VERSION//v/}` used, and what's the pitfall with it?

## Answer
`${VERSION//v/}` is Bash **parameter expansion** that removes *every* occurrence of the letter `v` from the version string. Poetry names wheels without the `v` prefix (`mps-1.2.8-py3-none-any.whl`), so this converts the tag `v1.2.8` into `1.2.8`.

```dockerfile
&& pip install dist/mps-${VERSION//v/}-py3-none-any.whl \
```

**Pitfall:** This removes *all* `v` characters, not just a leading one. If your version were something like `v1.2.8-preview`, the `v` in `preview` would also be stripped, producing an incorrect filename. Keep version strings simple (`vX.Y.Z`) to avoid this.

---

## Question
Why is Poetry configured with `virtualenvs.create false`?

## Answer
Inside a container, you don't need the isolation a virtualenv provides — the container *is* the isolation boundary. Setting:

```dockerfile
&& poetry config virtualenvs.create false \
```

tells Poetry to install dependencies **directly into the system Python** (`/usr/local/lib/python3.13/site-packages`). This makes the `COPY --from=builder` step straightforward, since packages live in a predictable location that gets copied into the final image.

`installer.max-workers 8` simply parallelizes dependency installation to speed up the build.

---

## Question
How does the service run, and how is health monitored?

## Answer
The service starts via the `CMD`, launching the app's entrypoint:

```dockerfile
CMD ["sh", "-c", "python ${SERVICE_HOME}/bin/__main__.py"]
```

`sh -c` is used so `${SERVICE_HOME}` is expanded at runtime.

Health is checked against an HTTP `/healthcheck` endpoint:

```dockerfile
HEALTHCHECK --interval=10s --timeout=10s --start-period=60s --retries=5 \
    CMD ["bash", "-c", "[[ $(curl -I http://localhost:8010/healthcheck --write-out %{http_code} --silent --output /dev/null) == \"200\" ]]"]
```

- **start-period 60s** — grace period before failures count, giving the app time to boot.
- **retries 5** — 5 consecutive failures mark the container `unhealthy`.

To view status: `docker inspect --format='{{.State.Health.Status}}' <container>`.

---

## Question
What non-Python tools are installed in the final image and why?

## Answer
The final stage installs container-image tooling and utilities:

```dockerfile
&& apk --no-cache add buildah fuse-overlayfs curl jq tzdata skopeo tar netavark pigz \
```

| Tool | Purpose |
|------|---------|
| `buildah` / `fuse-overlayfs` / `netavark` | Building container images without a Docker daemon |
| `skopeo` | Copying/inspecting container images between registries |
| `curl` | Used by the healthcheck and general HTTP calls |
| `jq` | JSON parsing in shell scripts |
| `tzdata` | Timezone data (image sets timezone to UTC) |
| `tar` / `pigz` | Archiving and parallel gzip compression for image archives |

This tells you MPS itself manipulates and promotes container images (hence the `image_archives/` and `exported_images/` directories it creates).

---

## Question
Why does the Dockerfile remove pip and reinstall it with `get-pip.py`?

## Answer
```dockerfile
&& rm -fr /usr/local/lib/python3.13/site-packages/pip* \
&& /usr/local/bin/python /tmp/get-pip.py \
```

The builder stage uses `pip-autoremove pip -y` to strip pip out of the wheel-installed packages, avoiding old/stale pip residue being carried into the final image. The final stage then does a **clean reinstall** of pip via `get-pip.py` to guarantee a fresh, current version.

**Pitfall:** If `get-pip.py` isn't present in your build context, the build fails at `COPY get-pip.py /tmp`. Make sure to download it (`curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py`) into the build directory beforehand.

---

## Question
A non-root user (`predict`) is created — is the container actually running as that user?

## Answer
**No.** The Dockerfile *creates* the `predict` user (UID 998) and `sparkbeyond` group (GID 1001):

```dockerfile
RUN addgroup -S -g ${SERVICE_GID} ${SERVICE_GROUP} \
    && adduser -S -D -G ${SERVICE_GROUP} -s /sbin/nologin -u ${EPS_UID} -H ${EPS_USER}
```

But there is **no `USER predict` directive**, so the container runs as **root** by default.

The comment explains the intent: the user is created to avoid `chown` issues when files are copied/mounted (e.g., the Docker socket) and to align UIDs with the External Prediction Service (EPS). If you require least-privilege execution, add `USER predict` (or run with `--user 998:1001`), but note that buildah/skopeo operations may need specific privileges to function.

---

## Question
Why are `mps/routes/` and `mps/api/` deleted in the builder stage?

## Answer
```dockerfile
&& rm -fr mps/routes/ mps/api/
```

After the wheel is built and installed into `site-packages`, the raw source copies of these directories are no longer needed. Removing them:

- Prevents duplicate/stale source from being accidentally copied into the final image.
- Keeps the final image lean, since only the installed package (in `site-packages`) plus a few selected runtime files (`__main__.py`, config files, templates) are copied over.

Only specific artifacts are explicitly copied to the final stage:

```dockerfile
COPY --from=builder mps/__main__.py ${SERVICE_HOME}/bin/__main__.py
COPY --from=builder mps/promotion.toml mps/build.info mps/defaults.json ${SERVICE_HOME}/conf/
COPY --from=builder mps/resources/template.env ${SERVICE_HOME}/template/template.env
```

---

## Question
How do I customize configuration like the base image, timezone, or service paths?

## Answer
Several settings are controlled via build args and `ENV`:

- **Base image:** override at build time.
  ```bash
  docker build --build-arg BASE_IMAGE=python:3.13-alpine3.23 ...
  ```
- **Service home / user IDs:** defined as `ENV` in the final stage (`SERVICE_HOME`, `SERVICE_GID`, `EPS_UID`, `EPS_USER`). These are baked in, so change them in the Dockerfile if needed.
- **Timezone:** the image is hardcoded to UTC:
  ```dockerfile
  && cp /usr/share/zoneinfo/UTC /etc/localtime \
  && echo "UTC" > /etc/timezone
  ```
- **App config:** runtime config lives in `${SERVICE_HOME}/conf/` (`promotion.toml`, `defaults.json`). Mount a volume over that path to supply your own config without rebuilding.

There's also a convenience symlink `load_images` pointing to the bundled `load_images.sh`, so you can run `load_images` inside the container directly.