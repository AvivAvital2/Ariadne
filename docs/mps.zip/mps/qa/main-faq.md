---
id: 7e99e0c8-74e6-59f6-a260-662ed680789d
type: qa
title: "  Main   FAQ"
created_at: 2026-06-06T19:03:09.898911+00:00
updated_at: 2026-06-20T22:55:26.759861+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  module_name: "mps.__main__"
  language: "python"
  source_name: "mps"
---
#   Main   FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

#   Main   FAQ


# `mps.__main__` — FAQ Documentation

This module is the entry point for the **SparkBeyond Model Promotion Service (MPS)**. It builds a FastAPI application, wires up routers, performs authentication on startup, and launches the Uvicorn server.

---

## How do I start the Model Promotion Service?

## Answer
The module is designed to be run directly as the application entry point. Since it lives at `mps/__main__.py`, you can launch it using Python's module execution syntax:

```bash
python -m mps
```

When run this way, the `if __name__ == '__main__'` block executes, which:
1. Runs the async `main()` coroutine to log in via the token manager.
2. Reads the host/port from environment variables.
3. Starts the Uvicorn server hosting the FastAPI `app`.

> **Note:** Running the file directly (e.g. `python mps/__main__.py`) may break the relative `conf/build.info` path and imports — prefer `python -m mps` from the project root.

---

## How do I configure the host and port the service runs on?

## Answer
The service reads two environment variables at startup:

| Variable | Default | Purpose |
|----------|---------|---------|
| `SERVICE_HOST` | `0.0.0.0` | Network interface to bind |
| `SERVICE_PORT` | `8010` | Port to listen on |

Example:

```bash
export SERVICE_HOST=127.0.0.1
export SERVICE_PORT=9000
python -m mps
```

**Pitfall — port type:** The default `8010` is an `int`, but `os.environ.get("SERVICE_PORT", 8010)` returns a **string** when the env var is set. Uvicorn generally coerces it, but to be safe you may want to cast it explicitly:

```python
service_port = int(os.environ.get("SERVICE_PORT", 8010))
```

---

## What does `MAINTENANCE_MODE` do?

## Answer
`MAINTENANCE_MODE` changes where the API documentation endpoints are served. When set to `true` (case-insensitive), the docs are mounted under the `/modelpromotion/` prefix:

```python
if os.environ.get('MAINTENANCE_MODE', 'False').lower() == 'true':
    params['docs_url'] = '/modelpromotion/docs'
    params['redoc_url'] = '/modelpromotion/redoc'
    params['openapi_url'] = '/modelpromotion/openapi.json'
```

| Mode | Swagger UI | ReDoc | OpenAPI schema |
|------|-----------|-------|----------------|
| Off (default) | `/docs` | `/redoc` | `/openapi.json` |
| On | `/modelpromotion/docs` | `/modelpromotion/redoc` | `/modelpromotion/openapi.json` |

Enable it with:

```bash
export MAINTENANCE_MODE=true
python -m mps
```

This is typically used when the service runs behind a reverse proxy that routes traffic under the `/modelpromotion` path during maintenance windows.

---

## Where does the service version come from?

## Answer
The version is read from a JSON file at `conf/build.info` relative to the working directory:

```python
with open('conf/build.info', 'r') as f:
    version = json.load(f)['version_tag']
```

The file must contain a `version_tag` key, for example:

```json
{ "version_tag": "1.4.2" }
```

This version is passed to FastAPI and appears in the OpenAPI schema and docs UI.

**Pitfall:** If `conf/build.info` is missing or lacks `version_tag`, the module raises an error *at import time* (before the server even starts). Make sure this file is present in your deployment artifact and that you launch from the correct working directory.

---

## Why are some routers hidden from the API docs?

## Answer
Two of the three routers are included with `include_in_schema=False`, meaning their endpoints work but are **not shown** in Swagger/ReDoc:

```python
app.include_router(basic.router, include_in_schema=False)
app.include_router(promote.router, include_in_schema=False)
app.include_router(maintenance.router)   # visible in docs
```

- `basic` and `promote` — functional but hidden (e.g. internal endpoints).
- `maintenance` — the only router exposed in the generated documentation.

If you need to debug a hidden route, you can still call it directly; it simply won't appear in the interactive docs. To temporarily expose it, remove `include_in_schema=False`.

---

## What does the `main()` coroutine do?

## Answer
`main()` performs authentication before the server accepts traffic:

```python
async def main():
    await mps.token_manager.login()
```

It awaits a login through the service's `token_manager`, ensuring a valid auth token is acquired up front. It runs **synchronously before** Uvicorn starts:

```python
asyncio.run(main())          # login completes first
uvicorn.run(app, ...)        # then the server starts
```

**Implication:** If login fails (bad credentials, unreachable auth server), the exception propagates and the server never starts. This is a deliberate fail-fast behavior — the service won't run without authentication.

---

## How can I run the FastAPI app without the built-in `uvicorn.run` call?

## Answer
The `app` object is created at module level, so you can import and serve it with any ASGI server. This is the recommended approach for production (e.g. multiple workers, process managers):

```bash
uvicorn mps.__main__:app --host 0.0.0.0 --port 8010 --workers 4
```

or with Gunicorn + Uvicorn workers:

```bash
gunicorn mps.__main__:app -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8010
```

**Important gotcha:** When you serve `app` this way, the `if __name__ == '__main__'` block does **not** run, so `mps.token_manager.login()` is never called automatically. You'll need to trigger login another way — for example, via a FastAPI startup event:

```python
@app.on_event("startup")
async def startup():
    await mps.token_manager.login()
```

Consider adding such a lifespan/startup hook so authentication works regardless of how the app is launched.

---

## Why doesn't login happen when running with multiple Uvicorn workers?

## Answer
Login (`asyncio.run(main())`) only happens in the `__main__` block, which runs in a single process. When you scale with workers via an external server command, that block is skipped entirely.

**Best practice:** Move the login logic into a FastAPI startup event so each worker authenticates independently:

```python
@app.on_event("startup")
async def on_startup():
    await mps.token_manager.login()
```

This ensures consistent behavior across both `python -m mps` and externally managed multi-worker deployments. (See the previous question on serving without `uvicorn.run`.)

---

## How do I debug startup failures?

## Answer
Common failure points and how to diagnose them:

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| `FileNotFoundError: conf/build.info` | Wrong working directory or missing file | Launch from project root; ensure file is deployed |
| `KeyError: 'version_tag'` | Malformed `build.info` | Add `version_tag` to the JSON |
| Hangs/errors before server start | `token_manager.login()` failing | Check auth credentials and network reachability |
| Docs at unexpected URL | `MAINTENANCE_MODE` set | Inspect the env var; defaults are `/docs`, `/redoc` |
| Port already in use | Stale process or conflict | Change `SERVICE_PORT` or free the port |

For verbose Uvicorn logging during debugging:

```bash
uvicorn mps.__main__:app --log-level debug
```

---

## What are the key pitfalls to avoid with this module?

## Answer
1. **Run from the project root** — the hard-coded `conf/build.info` path is relative to the working directory.
2. **Cast `SERVICE_PORT`** to `int` if you read it from the environment, to avoid type issues.
3. **Don't rely on `uvicorn.run` for production** — use an external ASGI server with workers, but remember to add a startup login hook.
4. **`MAINTENANCE_MODE` is string-compared** — it must equal `"true"` (any case). Values like `1` or `yes` won't enable it.
5. **Import-time side effects** — opening the build file and reading env vars happen on import, so importing the module in tests can trigger errors. Mock or provide `conf/build.info` in test setups.