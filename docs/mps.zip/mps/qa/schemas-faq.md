---
id: df6930af-b3d5-5978-bb7c-798bc0b1f22f
type: qa
title: "Schemas FAQ"
created_at: 2026-06-06T19:03:53.599813+00:00
updated_at: 2026-06-20T22:55:26.738307+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  module_name: "mps.api.schemas"
  language: "python"
  source_name: "mps"
---
# Schemas FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# Schemas FAQ


# `mps.api.schemas` — FAQ Documentation

This module defines marshmallow-dataclass schemas used to validate and deserialize API parameters and image definitions for the MPS API.

---

## Question
What is the purpose of this module and what library does it rely on?

## Answer
The module defines a set of schema classes used to validate and deserialize incoming data (typically from API requests). It is built on top of [`marshmallow-dataclass`](https://github.com/lovasoa/marshmallow_dataclass), which lets you declare schemas using Python's dataclass syntax while still getting marshmallow's validation and (de)serialization features.

Each class decorated with `@dataclass` (imported from `marshmallow_dataclass`, **not** the standard library) automatically gets an associated marshmallow `Schema`. You access it via the generated `.Schema` attribute:

```python
from mps.api.schemas import PromoteParams

schema = PromoteParams.Schema()
params = schema.load({"epsReleaseNumber": "1.2.3"})
# params -> PromoteParams(epsReleaseNumber='1.2.3', dockerCompose=False, ...)
```

> **Note:** The import is `from marshmallow_dataclass import dataclass`. Using the standard library `dataclasses.dataclass` would *not* give you the `.Schema` attribute or validation behavior.

---

## Question
How do I deserialize and validate `PromoteParams`, and which fields are optional?

## Answer
`PromoteParams` has one required field, `epsReleaseNumber`, and several boolean fields that default to `False`:

```python
from mps.api.schemas import PromoteParams

schema = PromoteParams.Schema()

# Minimal valid input
params = schema.load({"epsReleaseNumber": "2024.1"})
# PromoteParams(epsReleaseNumber='2024.1', dockerCompose=False,
#               linkedDataCore=False, knowledgeServer=False, openStreetMap=False)

# Enabling optional features
params = schema.load({
    "epsReleaseNumber": "2024.1",
    "dockerCompose": True,
    "openStreetMap": True,
})
```

If `epsReleaseNumber` is missing, marshmallow raises a `ValidationError`:

```python
from marshmallow import ValidationError

try:
    schema.load({"dockerCompose": True})
except ValidationError as err:
    print(err.messages)  # {'epsReleaseNumber': ['Missing data for required field.']}
```

Note the field names use camelCase (`epsReleaseNumber`, `linkedDataCore`), so your input keys must match exactly.

---

## Question
How does `AuxiliaryImage` handle image tags?

## Answer
`AuxiliaryImage` represents a single container image with an optional `tag` that defaults to `'latest'`:

```python
from mps.api.schemas import AuxiliaryImage

AuxiliaryImage(image="nginx")              # tag defaults to 'latest'
AuxiliaryImage(image="nginx", tag="1.25")  # explicit tag
```

This is most commonly populated indirectly via `AuxiliaryImages`, which parses `image:tag` strings (see below).

---

## Question
How does `AuxiliaryImages` parse a list of image strings?

## Answer
`AuxiliaryImages` takes `images_str` and, in its `__post_init__`, splits each entry on `:` to build a list of `AuxiliaryImage` objects:

```python
from mps.api.schemas import AuxiliaryImages

aux = AuxiliaryImages(images_str=["nginx:1.25", "redis"])
# aux.images -> [AuxiliaryImage(...), AuxiliaryImage(...)]
```

The parsing logic handles three cases:
- **1 part** (`"redis"`) → image with no explicit tag.
- **2 parts** (`"nginx:1.25"`) → image plus tag.
- **3+ parts** → raises `ValidationError('Invalid format. Expected "key:value"')`.

> ⚠️ **Known pitfall:** There is a bug in the 1-part case. The code calls `AuxiliaryImage(parts)` (passing the whole list) instead of `AuxiliaryImage(parts[0])`. This means a bare image name like `"redis"` will set `image=['redis']` (a list) rather than the string `'redis'`. When fixing, use:
> ```python
> case 1: self.images.append(AuxiliaryImage(parts[0]))
> ```

Also note that `images_str` is named as a single string but is actually iterated as a collection of strings — so the expected input is a list/iterable of strings, not one string.

---

## Question
What does the `make_versions_dict` post-load hook on `BaseImages` do?

## Answer
`BaseImages` defines a `@post_load` hook that runs after marshmallow deserializes the input. It transforms a `versions` collection into a dictionary, replacing hyphens with underscores in the keys:

```python
@post_load
def make_versions_dict(self, data, **kwargs):
    data['versions'] = {
        version.replace('-', '_'): version_data
        for version, version_data in data['versions']
    }
    return data
```

This is useful when version identifiers like `"my-release"` need to become valid identifier-style keys like `"my_release"`.

> ⚠️ **Gotcha:** The hook references `data['versions']`, but `BaseImages` only declares an `images` field of type `Flavours`. There is no `versions` field defined on the dataclass, so this hook will raise a `KeyError` unless the deserialized `data` actually contains a `versions` key. If you intend to use this transformation, ensure `versions` is a declared field or present in the input payload.

---

## Question
What fields does `Flavours` define, and how is it used?

## Answer
`Flavours` is a simple schema requiring four string fields, representing different image build variants:

```python
from mps.api.schemas import Flavours

f = Flavours.Schema().load({
    "minimal": "img-minimal:1.0",
    "gdata":   "img-gdata:1.0",
    "osm":     "img-osm:1.0",
    "aio":     "img-aio:1.0",
})
```

All four fields are required (no defaults), so omitting any of them raises a `ValidationError`. `Flavours` is also used as the type of the `images` field on `BaseImages`, so it can be nested automatically during deserialization.

---

## Question
How do I catch and handle validation errors across these schemas?

## Answer
All schema validation surfaces through marshmallow's `ValidationError`. Wrap `load()` calls and inspect `err.messages`:

```python
from marshmallow import ValidationError
from mps.api.schemas import ImageParams

schema = ImageParams.Schema()

try:
    params = schema.load({"project_id": "abc"})  # missing 'revision'
except ValidationError as err:
    print(err.messages)
    # {'revision': ['Missing data for required field.']}
```

For `AuxiliaryImages`, validation errors are raised inside `__post_init__` (the malformed `key:value` case), so handle them where you construct the object:

```python
try:
    AuxiliaryImages(images_str=["a:b:c"])
except ValidationError as err:
    print(err.messages)  # 'Invalid format. Expected "key:value"'
```

---

## Question
What is `ImageParams` used for?

## Answer
`ImageParams` is a minimal schema requiring two string fields, `project_id` and `revision`, typically used to identify a specific build of a project:

```python
from mps.api.schemas import ImageParams

params = ImageParams.Schema().load({
    "project_id": "my-project",
    "revision": "a1b2c3d",
})
# ImageParams(project_id='my-project', revision='a1b2c3d')
```

Both fields are required.

---

## Question
Should I instantiate these classes directly or use `.Schema().load()`?

## Answer
It depends on your goal:

- **Use `.Schema().load(data)`** when you receive raw input (e.g. JSON from an API request) and want validation, type coercion, and error reporting. This is the recommended path for untrusted input.
- **Instantiate directly** (e.g. `PromoteParams(epsReleaseNumber="1.0")`) when you already have valid Python values and want a typed object without re-validating.

```python
# Validating untrusted input
params = PromoteParams.Schema().load(request_json)

# Direct construction of known-good data
params = PromoteParams(epsReleaseNumber="1.0", dockerCompose=True)
```

> **Best practice:** Route all external/API input through `.Schema().load()` so you get consistent `ValidationError` handling, and reserve direct instantiation for internal, trusted code paths.