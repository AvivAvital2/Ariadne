---
id: bcdadfb7-71f2-530e-ba21-aa6a0fb2ec35
type: qa
title: "Logger FAQ"
created_at: 2026-06-06T19:03:48.086044+00:00
updated_at: 2026-06-20T22:55:26.740204+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  module_name: "mps.api.logger"
  language: "python"
  source_name: "mps"
---
# Logger FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# Logger FAQ


# `mps.api.logger` — FAQ Documentation

## Question
How do I start logging in my application using this module?

## Answer
The module exposes a ready-to-use `logger` instance at import time, configured for the Model Promotion Service. Just import it and start logging:

```python
from mps.api.logger import logger

logger.info("Service started")
logger.warning("Cache miss for key=abc")
logger.error("Failed to promote model")
```

The pre-built `logger` is created for the component name `'model_promotion'` and writes to both the console and a rotating file (`log/mps.log`). You don't need to instantiate anything yourself for the default case.

---

## Question
How do I create a logger for a different component instead of using the default one?

## Answer
Instantiate the `Logger` class directly with your own `component_name` and access its `.logger` attribute:

```python
from mps.api.logger import Logger
import logging

my_logger = Logger(
    component_name="my_component",
    log_level=logging.DEBUG,
    log_filename="log/my_component.log",
    max_bytes=10 * 1024 * 1024,  # 10 MB
    backup_count=5,
).logger

my_logger.debug("Component-specific debug message")
```

Note that `Logger` is a wrapper — the actual usable logger is the `.logger` attribute, **not** the `Logger` object itself.

---

## Question
How is the log file rotation configured, and how do I change it?

## Answer
The module uses a `RotatingFileHandler`. By default it rotates when the file reaches **5 MB** and keeps **2 backups** of `mps.log`. You control this through the `max_bytes` and `backup_count` arguments:

```python
from mps.api.logger import Logger

# Rotate at 1 MB, keep 10 backups
logger = Logger(
    component_name="model_promotion",
    max_bytes=1 * 1024 * 1024,
    backup_count=10,
).logger
```

This produces files like `mps.log`, `mps.log.1`, `mps.log.2`, etc., as rotation occurs.

> **Pitfall:** The default `log_filename` is `log/mps.log`, which assumes a `log/` directory already exists relative to your working directory. If it doesn't, the `RotatingFileHandler` will raise a `FileNotFoundError`. Create the directory first:
> ```python
> import os
> os.makedirs("log", exist_ok=True)
> ```

---

## Question
How do I configure the log level?

## Answer
The module-level `logger` reads from the `LOG_LEVEL` environment variable at import time:

```bash
export LOG_LEVEL=DEBUG
python my_app.py
```

Accepted values are `INFO`, `WARN`, `ERROR`, `FATAL`, and `DEBUG`. Any other value raises a `RuntimeWarning`:

```python
# If LOG_LEVEL=VERBOSE
# RuntimeWarning: Unexpected LOG_LEVEL. Expected 'INFO', ...
```

If you're using your own `Logger` instance, pass `log_level` directly instead of relying on the environment variable:

```python
import logging
logger = Logger("my_component", log_level=logging.DEBUG).logger
```

> **Gotcha:** The module passes the **string** `level` (e.g., `'DEBUG'`) into `Logger(log_level=level)`, but `setLevel` and standard logging usually expect integer constants like `logging.DEBUG`. Python's logging accepts level *name strings* in `setLevel`, so this works — but be aware the type hint `log_level: logging` is misleading and the value is really a string in the default path.

---

## Question
What does the `CustomLogger` class do with the `delimiter`?

## Answer
`CustomLogger` overrides `makeRecord` to inject a `delimiter` field into every log record's `extra` data. This delimiter is a run of spaces sized so that messages align neatly regardless of the level name's length:

```python
extra['delimiter'] = ' ' * (8 - len(logging.getLevelName(log_level)) + 1)
```

This pairs with the log format string:

```python
log_format = '%(levelname)s:%(delimiter)s%(message)s'
```

So output is column-aligned:

```
INFO:     Service started
WARNING:  Cache miss
ERROR:    Failed to promote model
```

`logging.setLoggerClass(CustomLogger)` is called in `Logger.__init__` so all loggers created afterward use this behavior.

> **Pitfall:** Because `setLoggerClass` is global, it affects loggers created *after* the call. Loggers already created (e.g., during early imports) won't get the `delimiter` and may fail to format with the custom format string if they reuse it.

---

## Question
Why aren't my healthcheck requests showing up in the logs?

## Answer
The module installs a `SkipHealthFilter` on the `uvicorn.access` logger to suppress noise from health/ping/favicon endpoints:

```python
logging.getLogger("uvicorn.access").addFilter(SkipHealthFilter())
```

This is intentional — repeated healthcheck pings would otherwise flood your access logs.

> **⚠️ Bug warning:** The current filter logic and endpoint list contain mistakes:
> ```python
> filtered_endpoints = [
>     "/healthcheck",
>     "/modelpromotion/ping"   # <-- missing comma!
>     "/favicon.ico"
> ]
> ```
> The missing comma causes Python string concatenation, producing `"/modelpromotion/ping/favicon.ico"` as a single element. Additionally, the filter condition:
> ```python
> return not any(endpoint not in record.getMessage() for endpoint in filtered_endpoints)
> ```
> uses inverted logic (`not in` combined with `not any(...)`) that almost certainly does not filter as intended. To suppress messages containing any filtered endpoint, the correct form is:
> ```python
> return not any(endpoint in record.getMessage() for endpoint in filtered_endpoints)
> ```

---

## Question
Why do I see duplicate log lines when I create multiple `Logger` instances with the same component name?

## Answer
Each call to `Logger(...)` calls `logging.getLogger(component_name)`, which returns the **same** underlying logger object for a given name — but then unconditionally adds a new file handler and console handler:

```python
_logger.addHandler(file_handler)
_logger.addHandler(console_handler)
```

Creating the logger twice with the same name attaches handlers twice, so every message is emitted twice (or more).

**Best practice:** Create each named logger only once and reuse the returned `.logger`. For the default component, rely on the module-level `logger` rather than re-instantiating:

```python
from mps.api.logger import logger  # use this everywhere
```

If you need to guard against duplicates in custom code, check `_logger.handlers` before adding handlers.

---

## Question
Can I add structured `extra` fields to my log records?

## Answer
Yes, but be careful: `CustomLogger.makeRecord` always sets `extra['delimiter']`. If you pass your own `extra` dict, the delimiter is merged in:

```python
logger.info("Promotion complete", extra={"model_id": "abc123"})
```

Just make sure you don't pass a key named `delimiter` yourself, and avoid keys that collide with reserved `LogRecord` attributes (like `message`, `args`, `levelname`), which would raise a `KeyError`.

To actually display your custom fields, update the format string in your own `Logger` configuration:

```python
log_format = '%(levelname)s:%(delimiter)s[%(model_id)s] %(message)s'
```

---

## Question
How do I send logs only to a file and not the console (or vice versa)?

## Answer
The `Logger` class hardcodes both a `RotatingFileHandler` and a `StreamHandler` (console). To customize, either:

1. **Subclass or build your own logger** using `logging` directly, or
2. **Remove unwanted handlers** after construction:

```python
import logging
from logging.handlers import RotatingFileHandler
from mps.api.logger import Logger

logger = Logger("my_component").logger

# Drop console output, keep only file logging
for handler in list(logger.handlers):
    if isinstance(handler, logging.StreamHandler) and not isinstance(handler, RotatingFileHandler):
        logger.removeHandler(handler)
```

> **Note:** `RotatingFileHandler` is a subclass of `StreamHandler`, so the `isinstance` check above explicitly excludes it to avoid removing the file handler.

---

## Question
Why does importing this module sometimes raise a `RuntimeWarning`?

## Answer
At import time the module validates `LOG_LEVEL` with a `match` statement. If the value is not one of `INFO`, `WARN`, `ERROR`, `FATAL`, or `DEBUG`, it **raises** a `RuntimeWarning`:

```python
case _:
    raise RuntimeWarning(f"Unexpected LOG_LEVEL... instead got {level=}")
```

This stops the import entirely. Ensure `LOG_LEVEL` is unset (defaults to `INFO`) or set to a valid value before importing:

```bash
export LOG_LEVEL=INFO
```

> **Gotcha:** `RuntimeWarning` is normally a warning category, but here it is `raise`d like an exception, so it behaves as a hard failure rather than a soft warning. Catch it with `except RuntimeWarning` if you need graceful handling.