---
id: bacc31de-11f0-5bdd-823a-b06c2c6e5ada
type: qa
title: "Token Manager FAQ"
created_at: 2026-06-06T19:03:59.766318+00:00
updated_at: 2026-06-20T22:55:26.757964+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  module_name: "mps.api.token_manager"
  language: "python"
  source_name: "mps"
---
# Token Manager FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# Token Manager FAQ


# `mps.api.token_manager` — FAQ

This module handles authentication against container registries (local, Azure, and AWS ECR). The base `TokenManager` covers `local` and `azure` providers, while `AWSTokenManager` extends it specifically for AWS ECR.

---

## How do I create and use a TokenManager for a local or Azure registry?

## Answer
Instantiate `TokenManager` with the registry address, credentials, and provider, then call the async `login()` method to authenticate and write the Docker config file.

```python
import asyncio
from mps.api.token_manager import TokenManager

async def main():
    tm = TokenManager(
        registry="myregistry.azurecr.io",
        username="myuser",
        password="mypassword",
        provider="azure",
    )
    await tm.login()
    # After login, tm.session is an MPSSession ready to use

asyncio.run(main())
```

On successful login, credentials are base64-encoded and written to `~/.docker/config.json`, and `self.session` is set to an authenticated `MPSSession`.

---

## How does the TokenManager decide between HTTP and HTTPS?

## Answer
The schema is chosen automatically in the constructor:

```python
self.schema = 'http' if ':' in self.registry and self.provider == 'local' else 'https'
```

So `http` is **only** used when the provider is `local` **and** the registry contains a port (e.g. `localhost:5000`). In all other cases (Azure, AWS, or a local registry without an explicit port), `https` is used.

This matters because a local registry is expected to bind port `443:5000` externally; the only time you'd hit it over plain HTTP is during local development with a `host:port` address.

---

## Can I run a local registry without a username and password?

## Answer
Yes. For the `local` provider, credentials are optional. The constructor sets:

```python
self.use_auth = False if (self.username is None or self.password is None) and self.provider == 'local' else True
```

When `provider="local"`, only `REGISTRY_ADDR`, `REGISTRY_PROVIDER`, and `REGISTRY_VERIFY_CERTIFICATE_SIGNING` are required. For any other provider, `REGISTRY_USER` and `REGISTRY_PASS` are also required, and a missing value raises `MissingConfigValues`.

```python
# Valid: anonymous local registry
tm = TokenManager(
    registry="localhost:5000",
    username=None,
    password=None,
    provider="local",
)
```

> **Gotcha:** If you set `provider="azure"` (or anything non-local) without a username/password, you'll get a `MissingConfigValues` error immediately at construction time.

---

## How do I authenticate against AWS ECR?

## Answer
Use `AWSTokenManager`, which requires a `region_name` in addition to the standard parameters. The `username`/`password` are your AWS access key ID and secret access key.

```python
import asyncio
from mps.api.token_manager import AWSTokenManager

async def main():
    tm = AWSTokenManager(
        registry="123456789012.dkr.ecr.us-east-1.amazonaws.com",
        region_name="us-east-1",
        username="AKIA...",            # AWS access key ID
        password="secret-access-key",  # AWS secret access key
    )
    await tm.login()

asyncio.run(main())
```

Internally, `AWSTokenManager`:
- Derives the 12-digit `registry_id` from the first 12 characters of the registry address.
- Creates a boto3 ECR client.
- Calls `get_authorization_token` to retrieve a short-lived token, decodes it, and writes it to `~/.docker/config.json`.

---

## Why does `AWSTokenManager.login()` fail with `InvalidAWSRegion`?

## Answer
`login()` checks that `region_name` is set before doing anything else:

```python
async def login(self):
    if not self.region_name:
        raise InvalidAWSRegion('AWS_REGISTRY_REGION was not set, quitting... ')
```

Make sure you always pass a non-empty `region_name` when constructing `AWSTokenManager`. An empty string or `None` will trigger this error.

---

## What errors should I handle, and what causes them?

## Answer
The module raises several domain-specific exceptions:

| Exception | When it's raised |
|-----------|------------------|
| `MissingConfigValues` | Required config params are `None` at construction. |
| `InvalidRegistryProvider` | `login()` called with a provider other than `azure` or `local` on the base class. |
| `UnableToStoreCredentialsFile` | The `~/.docker/config.json` file can't be found/read when reading credentials. |
| `InvalidAWSRegion` | `AWSTokenManager.login()` called without a region. |
| `UnableToGetAuthToken` | AWS ECR token retrieval fails (bad/missing credentials). |

Example handling AWS credential failures:

```python
from mps.api.errors import UnableToGetAuthToken, InvalidAWSRegion

try:
    await tm.login()
except InvalidAWSRegion:
    print("Set the AWS region before logging in.")
except UnableToGetAuthToken as e:
    print(f"AWS auth failed ({e.status_code}): {e.message}")
```

---

## Why does the base `TokenManager.login()` raise `InvalidRegistryProvider` for AWS?

## Answer
The base class only handles `azure` and `local` in its `match` statement:

```python
match self.provider:
    case "azure" | "local":
        ...
    case _:
        raise InvalidRegistryProvider(...)
```

For AWS you **must** use the `AWSTokenManager` subclass, which overrides `login()` and `get_username_and_password()` to use the ECR token flow.

> **Note:** The error message mentions `"gcp"` as a valid value, but GCP is not yet implemented (there's a `# Todo: Add support for "gcp"` comment). Don't expect GCP to work currently.

---

## What does `get_username_and_password()` do, and why is it different in the AWS subclass?

## Answer
- **Base class** reads previously stored credentials back from `~/.docker/config.json`, decoding the base64 `auth` entry into a `(username, password)` tuple. If the file is missing, it raises `UnableToStoreCredentialsFile`.

  ```python
  async def get_username_and_password(self) -> (str, str):
      with open(self.config_filename) as f:
          return tuple(base64.b64decode(
              json.load(f)['auths'][self.registry]['auth']
          ).decode('utf-8').split(':'))
  ```

- **AWS subclass** instead fetches a fresh ECR authorization token from AWS each time (guarded by an `asyncio.Lock` to avoid concurrent token requests), decodes it, and writes the new credentials to the Docker config file.

> **Gotcha:** In `AWSTokenManager.login()`, `get_username_and_password()` is called **twice** (once for `verify_connection_to_container_registry` and once for building `MPSSession`). Each call performs a separate ECR token request. If you need to optimize, consider caching the token.

---

## How are credentials stored on disk?

## Answer
Credentials are written to `~/.docker/config.json` in standard Docker auth format, with the `user:password` string base64-encoded:

```python
def get_credentials(self, registry_auth_url, username=None, password=None):
    return {
        'auths': {
            registry_auth_url: {
                "auth": base64.b64encode(
                    bytes(f"{username}:{password}", "utf-8")
                ).decode("utf-8")
            }
        }
    }
```

> **Pitfall:** `_write_credentials_to_file` opens the file in `'w'` mode, which **overwrites** the entire `config.json`. Existing auth entries for other registries will be lost. If you manage multiple registries through Docker config, back up or merge manually.

---

## Is `AWSTokenManager` safe to use concurrently?

## Answer
Partially. Token fetching is protected by an `asyncio.Lock`:

```python
async def get_username_and_password(self):
    async with self.lock:
        response = self.session.get_authorization_token(...)
        ...
```

This serializes ECR token requests and credential file writes for a single `AWSTokenManager` instance. However:
- The boto3 `get_authorization_token` call is **synchronous** and will block the event loop while it runs.
- The lock does not protect across separate `AWSTokenManager` instances writing to the same `config.json`.

For high-concurrency scenarios, prefer a single shared instance and be aware of the blocking boto3 call.