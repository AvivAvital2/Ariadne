---
id: 3d8720c9-a388-5955-988f-1c3fcac03b76
type: qa
title: "Update Version FAQ"
created_at: 2026-06-06T19:04:51.167250+00:00
updated_at: 2026-06-20T22:55:26.741765+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  module_name: "update_version"
  language: "python"
  source_name: "mps"
---
# Update Version FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# Update Version FAQ


# `update_version` FAQ

## What does the `update_version` function do?

## Answer
It updates the `version` field in your project's `pyproject.toml` file based on the value of the `VERSION` environment variable. Specifically, it reads the version from `os.getenv("VERSION")`, loads the TOML file, sets `tool.poetry.version` to the new value, and writes the file back.

This is commonly used in CI/CD pipelines to automate version bumping before publishing a Poetry package.

---

## How do I run this script?

## Answer
Set the `VERSION` environment variable and run the module directly. The script must be executed from the directory containing your `pyproject.toml`, since the path is relative.

```bash
# Linux/macOS
export VERSION=1.2.3
python update_version.py

# One-liner
VERSION=1.2.3 python update_version.py
```

```powershell
# Windows PowerShell
$env:VERSION = "1.2.3"
python update_version.py
```

After running, the `version` line under `[tool.poetry]` in `pyproject.toml` will be updated to `1.2.3`.

---

## What dependencies do I need to install?

## Answer
The script depends on two third-party libraries:

- **`tomli`** — for reading (parsing) TOML files.
- **`tomli_w`** — for writing TOML files.

Install both:

```bash
pip install tomli tomli-w
```

**Note:** As of Python 3.11+, `tomllib` is part of the standard library for *reading* TOML, but there is no standard library for *writing*, so `tomli_w` is still required. If you target Python 3.11+, you could replace `tomli` with the built-in `tomllib`.

---

## Why must the file be opened in binary mode (`"rb"` / `"wb"`)?

## Answer
Both `tomli` and `tomli_w` require binary file handles, not text handles. This is intentional in their API design to avoid encoding ambiguity (TOML is always UTF-8).

```python
# Correct
with open("pyproject.toml", "rb") as f:
    pyproject = tomli.load(f)

# Wrong — raises TypeError
with open("pyproject.toml", "r") as f:
    pyproject = tomli.load(f)
```

If you forget the `"b"`, you'll get a `TypeError` complaining about the stream type.

---

## What happens if the `VERSION` environment variable isn't set?

## Answer
The function raises a `ValueError` with a clear message:

```python
if not version:
    raise ValueError("VERSION environment variable is not set")
```

Note that this also triggers if `VERSION` is set to an *empty string*, because an empty string is falsy. To distinguish "unset" from "empty," you'd need:

```python
version = os.getenv("VERSION")
if version is None:
    raise ValueError("VERSION environment variable is not set")
if not version.strip():
    raise ValueError("VERSION environment variable is empty")
```

---

## Why does it fail with a `KeyError`?

## Answer
The line `pyproject["tool"]["poetry"]["version"]` assumes your `pyproject.toml` has a `[tool.poetry]` section. If you use a different build backend (e.g., `[project]` with PEP 621 metadata, Hatch, or setuptools), this key won't exist and you'll get a `KeyError`.

For a PEP 621-style project, the version lives under `[project]` instead:

```python
# Poetry layout (what this script expects)
pyproject["tool"]["poetry"]["version"] = version

# PEP 621 layout
pyproject["project"]["version"] = version
```

Make sure the script matches your project's actual structure.

---

## Will running this script preserve my comments and formatting in `pyproject.toml`?

## Answer
**No.** This is an important gotcha. `tomli` parses the file into plain Python dicts, discarding comments, blank lines, and original formatting. When `tomli_w.dump` writes it back, it regenerates the file in its own canonical style.

If preserving comments and formatting matters, use a round-trip-preserving library like **`tomlkit`** instead:

```python
import tomlkit

with open("pyproject.toml", "r", encoding="utf-8") as f:
    pyproject = tomlkit.parse(f.read())

pyproject["tool"]["poetry"]["version"] = version

with open("pyproject.toml", "w", encoding="utf-8") as f:
    f.write(tomlkit.dumps(pyproject))
```

---

## How can I make the script more robust for production use?

## Answer
The current version is minimal. For production CI usage, consider adding:

1. **Configurable file path** instead of hardcoding `pyproject.toml`.
2. **Version validation** (e.g., enforce semantic versioning).
3. **Graceful handling of missing keys.**

```python
import os
import re
import tomli
import tomli_w

SEMVER = re.compile(r"^\d+\.\d+\.\d+")

def update_version(path="pyproject.toml"):
    version = os.getenv("VERSION")
    if not version:
        raise ValueError("VERSION environment variable is not set")
    if not SEMVER.match(version):
        raise ValueError(f"Invalid version format: {version}")

    with open(path, "rb") as f:
        pyproject = tomli.load(f)

    try:
        pyproject["tool"]["poetry"]["version"] = version
    except KeyError as e:
        raise KeyError(f"Missing expected section in {path}: {e}")

    with open(path, "wb") as f:
        tomli_w.dump(pyproject, f)
```

---

## Can I import and call `update_version()` from another script instead of using the CLI?

## Answer
Yes. The `if __name__ == "__main__":` guard means the function only auto-runs when the file is executed directly. You can safely import it elsewhere:

```python
from update_version import update_version

os.environ["VERSION"] = "2.0.0"
update_version()
```

However, the current signature takes no arguments and reads from the environment, so you must set `VERSION` before calling. A more testable design would accept the version as a parameter:

```python
def update_version(version=None, path="pyproject.toml"):
    version = version or os.getenv("VERSION")
    ...
```

This makes the function easier to unit-test without manipulating environment variables.