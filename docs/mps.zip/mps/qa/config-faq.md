---
id: 466c84c8-b420-5628-8cb5-e39626a11d99
type: qa
title: "Config FAQ"
created_at: 2026-06-06T19:03:22.021786+00:00
updated_at: 2026-06-06T19:03:22.021801+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  module_name: "mps.api.config"
  language: "python"
  source_name: "mps"
---
# Config FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# `mps.api.config` — FAQ

This module loads and validates application configuration from two files: a JSON file of defaults and a TOML file with environment-specific settings. The two are merged, with TOML values taking precedence.

---

## Question
What does this module do and what gets loaded when I import it?

## Answer
On import, the module performs three steps:

1. **Validates** that both `conf/defaults.json` and `conf/promotion.toml` exist, are regular files, are non-empty, and are readable.
2. **Loads** the JSON defaults and the TOML config.
3. **Merges** the two, with TOML values overriding defaults, then exposes a few convenience variables.

After importing, you get access to:

```python
from mps.api import config

config.config              # merged dict (defaults + promotion.toml)
config.defaults            # raw defaults.json dict
config.base_images         # config['baseImage']
config.image_cache_path    # config['local_image_cache']['path']
config.repo_prefix         # config['general']['repo_prefix']
config.exported_image_path # config['exported_images']['path']
```

Because all of this runs at **import time** (module top level), the validation and loading happen the first time the module is imported anywhere in your process.

---

## Question
Where are the config files expected to be located?

## Answer
The paths are **relative to the current working directory**, not the module location:

```python
file_paths = [
    'conf/defaults.json',
    'conf/promotion.toml'
]
```

This means the process must be launched from a directory that contains a `conf/` folder. If you run your app from a different directory, the files won't be found and a `NoConfigurationFileFoundError` will be raised.

**Tip:** Be deliberate about your working directory (e.g., in your Dockerfile `WORKDIR`, systemd unit, or process manager). A common pitfall is that tests or scripts run from a different CWD and fail to locate `conf/`.

---

## Question
How does the merge between `defaults.json` and `promotion.toml` work?

## Answer
The defaults provide a baseline; the TOML file overrides or extends them. The merge is **two levels deep** (section → key):

```python
for section, section_defaults in defaults.items():
    section_dict = config.setdefault(section, {})
    for key, default in section_defaults.items():
        section_dict.setdefault(key, default)
```

- If a section exists only in `defaults.json`, it's added to `config`.
- Within a section, any key missing from the TOML gets the default value.
- Any key present in the TOML keeps its TOML value (defaults do **not** overwrite it).

**Gotcha:** This is *not* a recursive deep merge. Only the top-level section and its immediate keys are merged. If a default value is itself a nested dict and the TOML defines the same key with a partial dict, the TOML version replaces the whole nested structure — defaults inside it are **not** filled in.

---

## Question
What's an example layout for `defaults.json` and `promotion.toml`?

## Answer
Given the variables the module reads, your files need these sections:

`conf/defaults.json`:
```json
{
  "general": {
    "repo_prefix": "registry.example.com/"
  },
  "local_image_cache": {
    "path": "/var/cache/images"
  },
  "exported_images": {
    "path": "/var/exports"
  },
  "baseImage": {
    "python": "python:3.12-slim"
  }
}
```

`conf/promotion.toml`:
```toml
[general]
repo_prefix = "registry.prod.example.com/"

[baseImage]
node = "node:20-alpine"
```

After merging, `config['baseImage']` would contain both `python` (from defaults) and `node` (from TOML), and `repo_prefix` would be the TOML value.

---

## Question
What errors can this module raise and what do they mean?

## Answer
Validation happens in a `match` block per file. The possible failures:

| Condition | Exception | Likely cause |
|-----------|-----------|--------------|
| File doesn't exist | `NoConfigurationFileFoundError` | Wrong CWD, missing file, or unmounted volume |
| Path exists but isn't a regular file | `InvalidConfigurationFile` | Mounted as a directory/device incorrectly |
| File size is 0 bytes | `InvalidConfigurationFile` | Empty file or volume mounted without proper write/permission |
| File not readable | `InvalidConfigurationFile` | Permission issues on the file |

Both exceptions come from `mps.api.errors`. Handle them when importing or initializing your app:

```python
from mps.api.errors import NoConfigurationFileFoundError, InvalidConfigurationFile

try:
    from mps.api import config
except (NoConfigurationFileFoundError, InvalidConfigurationFile) as e:
    print(f"Configuration error: {e}")
    raise SystemExit(1)
```

The error messages hint at container/mount problems, which is the most common deployment cause.

---

## Question
Why is `promotion.toml` opened in binary mode but `defaults.json` in text mode?

## Answer
This is a requirement of the standard-library parsers:

```python
with open('conf/defaults.json') as defaults_fh:
    defaults = json.load(defaults_fh)        # text mode

with open('conf/promotion.toml', 'rb') as f:
    config = tomllib.load(f)                  # MUST be binary mode
```

`tomllib.load()` (added in Python 3.11) **requires a binary file object** (`'rb'`). Passing a text-mode file raises a `TypeError`. `json.load()`, by contrast, expects text. Keep these modes as-is.

**Note:** `tomllib` is only available in **Python 3.11+**. On older versions you'd need the third-party `tomli` package.

---

## Question
What happens if my config files have syntax errors?

## Answer
The module validates file *presence and accessibility* but does **not** catch parse errors. If your JSON or TOML is malformed, the loaders raise their own exceptions:

- Bad JSON → `json.JSONDecodeError`
- Bad TOML → `tomllib.TOMLDecodeError`

These propagate up uncaught by this module. If you want graceful handling, wrap the import:

```python
import json, tomllib
try:
    from mps.api import config
except (json.JSONDecodeError, tomllib.TOMLDecodeError) as e:
    print(f"Malformed config file: {e}")
    raise SystemExit(1)
```

---

## Question
Why might accessing `config['baseImage']` or `config['general']['repo_prefix']` raise a `KeyError`?

## Answer
The convenience variables are computed at the bottom of the module:

```python
base_images = config['baseImage']
image_cache_path = config['local_image_cache']['path']
repo_prefix = config['general']['repo_prefix']
exported_image_path = config['exported_images']['path']
```

These use **direct indexing**, not `.get()`, so a missing section or key raises `KeyError` at import time. A key is only guaranteed present if it appears in **either** `defaults.json` **or** `promotion.toml`.

**Best practice:** Define every required key in `defaults.json`. That way the merge step guarantees it exists in `config`, even when the TOML omits it, and these lookups won't fail.

---

## Question
How can I reuse this config across my application without re-reading the files?

## Answer
Because everything executes at module load and Python caches imported modules, the files are read **only once** per process. Simply import wherever needed:

```python
from mps.api import config

def build_image(name):
    full_name = config.repo_prefix + name
    base = config.base_images[name]
    ...
```

All importers share the same in-memory `config` dict. If you mutate `config` in one place, the change is visible everywhere — so treat it as read-only to avoid surprising side effects.

**Pitfall:** Since loading is import-time, you cannot change config files and "reload" without restarting the process (or explicitly reloading the module). For tests that need different config, isolate the working directory or refactor loading into a callable function.