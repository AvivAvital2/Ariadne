---
id: c265b084-57ed-5691-94f9-2d9375d3a07b
type: qa
title: "Image Manager FAQ"
created_at: 2026-06-06T19:03:41.794192+00:00
updated_at: 2026-06-20T22:55:26.758916+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  module_name: "mps.api.image_manager"
  language: "python"
  source_name: "mps"
---
# Image Manager FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# Image Manager FAQ


# ImageManager FAQ

The `ImageManager` class in `mps.api.image_manager` handles building, pushing, exporting, caching, and listing container images. It supports two primary operating modes: pushing to a remote container registry or exporting images as local `.tar.gz` archive files.

---

## How do I create and initialize an ImageManager?

## Answer
`ImageManager` requires a token manager (either `TokenManager` or `AWSTokenManager`) and an optional flag that switches between registry-push mode and file-export mode.

```python
from mps.api.image_manager import ImageManager
from mps.api.token_manager import AWSTokenManager

# Registry-push mode (default)
manager = ImageManager(token_manager=my_token_manager)

# File-export mode — images are exported to disk as .tar.gz archives
manager = ImageManager(token_manager=my_token_manager, export_image_as_file=True)

# Authenticate before pushing/inspecting
await manager.login()
```

The constructor also initializes an `AsyncPersistentImageCache` (`self.local_image_cache`) used to track known images and avoid redundant builds/pushes.

---

## What's the difference between registry-push mode and export-as-file mode?

## Answer
The `export_image_as_file` flag fundamentally changes how images are stored and looked up:

| Behavior | Registry mode (`False`) | File-export mode (`True`) |
|----------|------------------------|---------------------------|
| Where images go | Pushed to remote registry via `skopeo copy ... docker://` | Exported to `exported_image_path` as `<name>.tar`, then compressed with `pigz` to `.tar.gz` |
| Existence check | `skopeo inspect docker://...` against the registry | Checks the local filesystem **and** inspects the archive for the tag |
| Cache semantics | Behaves like a normal cache | Behaves like a **Bloom filter** (presence in cache is verified against disk) |
| Docker Compose export | Supported | **Disabled** — returns a 500 error |

This is why `push_image`, `get_if_image_exists`, and `check_if_image_tag_exists_in_cache` all branch on `self.export_image_as_file`.

---

## How do I build and push an image?

## Answer
Use `build_and_push`. It constructs a model ID tag, checks the cache, extracts the model zip, generates a Dockerfile dynamically, builds with `buildah`, and pushes/exports the result.

```python
result = await manager.build_and_push(
    base_image="registry.example.com/base:latest",
    project_id="myproject_abc",
    revision="v1",
    temp_directory="/tmp/build123",
    model_filename="model.zip",
    use_docker_compose=False,
    auxiliary_image_list=None,
    annotations_list=["org.opencontainers.image.version=1.0"],
)
```

Key behaviors:
- If the image already exists (cache + registry/disk), it returns immediately without rebuilding.
- The generated Dockerfile copies extracted models into `./models/{project_prefix}_{revision}`.
- The return value is either the **image path** (registry mode), the **archive file path** (export mode), or a `PlainTextResponse` (env file content or error).

**Gotcha:** `model_name` is derived from `project_id.split("_")[0]`, so only the portion *before the first underscore* is used as the project prefix.

---

## Why does my build_and_push return a 500 PlainTextResponse instead of an image path?

## Answer
There are two scenarios that produce a `PlainTextResponse` with status 500:

1. **Compose + export conflict.** If both `use_docker_compose=True` and `export_image_as_file=True`, the request is rejected early:
   ```python
   if all([use_docker_compose, self.export_image_as_file]):
       # returns 500 — compose export requires a real registry provider
   ```
   Fix: set `REGISTRY_PROVIDER` to `"aws"`, `"azure"`, `"gcp"`, or `"local"` (i.e., disable file export).

2. **Auxiliary image upload failure.** When using compose, if `upload_missing_auxiliary_images` raises `UnableToUploadOneOrMoreImages`, the error detail is returned as a 500.

If the **build itself** fails (non-zero exit code from `buildah bud`), it raises `UnavailableImage` rather than returning a response — handle that exception separately.

---

## How does caching work, and how do I avoid stale entries?

## Answer
The cache is the first line of defense against redundant work. `get_if_image_exists` cross-checks the cache against the actual storage (registry or disk) and **self-heals** discrepancies:

```python
match (exists_in_cache, already_exported):
    case (True, True):   return image_path      # cache hit, verified
    case (True, False):  await self.remove_from_cache(image_path)  # stale → purge
    case (False, True):  await self.cache_image(image_path); return image_path  # backfill
    # (False, False) → returns None, build proceeds
```

Manual cache operations:
```python
await manager.cache_image(tag)       # add/update entry with current timestamp
await manager.remove_from_cache(tag) # delete entry
```

**Pitfall:** In file-export mode the cache acts as a Bloom filter — a cache hit is *not trusted* until the archive on disk is inspected for the specific tag. Don't rely on cache presence alone to mean an image is usable.

---

## How do I list images, and what's the difference between the listing methods?

## Answer
There are three distinct listing methods, each serving a different purpose:

```python
# 1. Local images known to buildah (and refreshes the cache)
local = await manager.list_local_images()

# 2. Images present in the remote container registry catalog
pushed = await manager.list_pushed_images()
# -> { "registry/repo_prefix/name": ["tag1", "tag2"], ... }

# 3. Filter a candidate list down to those that actually exist in storage
existing = await manager.get_exported_image_list(["img1", "img2"])
```

- `list_local_images` queries `buildah images` and, as a side effect, writes each image into the cache with the current timestamp. In export mode it remaps names to archive paths.
- `list_pushed_images` hits the registry's `/v2/_catalog` endpoint and filters to repositories starting with `repo_prefix`. It raises `UnreachableContainerRegistry` on connection errors and `UnableToObtainPushedImagesFromContainerRegistry` if no repositories key is returned.

---

## How are auxiliary images handled when using Docker Compose?

## Answer
When `use_docker_compose=True` and an `auxiliary_image_list` is provided, `build_and_push` calls `upload_missing_auxiliary_images`, which:

1. Prefixes each tag with the registry: `f'{registry}/{image}'`.
2. Determines which images are **missing** from the registry.
3. Pushes the missing ones concurrently via `asyncio.gather`.
4. Raises `UnableToUploadOneOrMoreImages` if any push returns a non-zero exit code.

If everything succeeds, an env file is generated and returned:

```python
env_content = await manager.generate_env_file(image_path=docker_image_path)
```

`generate_env_file` reads `template/template.env` and substitutes `DOCKER_REPOSITORY_PREFIX=` and `EPS_IMAGE=` with the actual registry and image path.

**Note:** There's a subtle filter in `upload_missing_auxiliary_images` — `get_exported_image_list` returns images that *exist*, then the comprehension keeps only those `not in aux_images`. Review this logic carefully if your "missing" set looks unexpected.

---

## How does AWS ECR support differ during a push?

## Answer
When the token manager is an `AWSTokenManager`, `push_image` performs extra steps before copying the image:

```python
if isinstance(self.token_manager, AWSTokenManager):
    await self.token_manager.login()  # refresh ECR credentials

    parsed_tag = urlparse('//' + tag)
    repository_name, _, _ = parsed_tag.path.lstrip('/').partition(':')

    try:
        self.token_manager.session.create_repository(repositoryName=repository_name)
    except self.token_manager.session.exceptions.RepositoryAlreadyExistsException:
        pass  # repo already exists, continue
```

This means ECR repositories are **created on demand** — you don't need to pre-create them. Credentials are also refreshed on every push to avoid token expiry.

For non-AWS registries, TLS verification is controlled by `token_manager.verify_certificate_signing`; when `False`, `--src-tls-verify=false --dest-tls-verify=false` are added to the `skopeo` command (useful for local/self-signed registries).

---

## How do I clean up images and check disk usage?

## Answer
Use `delete_local_images` to prune non-release and dangling images, and `get_size_of_images` to measure total size.

```python
# Remove all non-release tagged images + dangling images, then clear the cache
deleted = await manager.delete_local_images()

# Total size of local buildah images (in bytes, parsed via humanfriendly)
total_bytes = await ImageManager.get_size_of_images()
```

`delete_local_images` deliberately preserves anything matching `*release*` (`reference!=*release*`). It only runs `buildah rmi` and clears the cache when there is at least one image or dangling image to remove.

**Best practice:** Schedule cleanup during low-traffic windows. Because deletion clears the *entire* cache, the next `build_and_push` calls will repopulate it via existence checks — expect a brief period of extra registry/disk lookups afterward.

---

## What exceptions should I be prepared to handle?

## Answer
`ImageManager` raises several domain-specific exceptions from `mps.api.errors`:

| Exception | Raised when |
|-----------|-------------|
| `UnavailableImage` | `buildah bud` build fails (non-zero exit); message contains the stderr output |
| `UnableToUploadOneOrMoreImages` | One or more auxiliary image pushes fail |
| `UnreachableContainerRegistry` | `list_pushed_images` cannot connect to the registry |
| `UnableToObtainPushedImagesFromContainerRegistry` | The catalog response has no `repositories` key |

Example handling pattern:

```python
from mps.api.errors import UnavailableImage, UnableToUploadOneOrMoreImages

try:
    result = await manager.build_and_push(...)
except UnavailableImage as e:
    logger.error(f"Build failed: {e}")
    # surface the stderr to the user
except UnableToUploadOneOrMoreImages as e:
    logger.error(f"Aux image push failed: {e.detail}")
```

Note that `build_and_push` *catches* `UnableToUploadOneOrMoreImages` internally and converts it to a 500 `PlainTextResponse`, so you typically only catch it directly when calling `upload_missing_auxiliary_images` yourself.