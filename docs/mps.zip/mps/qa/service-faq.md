---
id: a6648855-b82e-5401-9c7f-ea7d96b25b3c
type: qa
title: "Service FAQ"
created_at: 2026-06-06T19:04:39.061110+00:00
updated_at: 2026-06-20T22:55:26.740516+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  module_name: "mps.service"
  language: "python"
  source_name: "mps"
---
# Service FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# Service FAQ


# MPS Service FAQ

## Question
How do I get started using the `MPS` class?

## Answer
The `MPS` class is configured entirely through environment variables and instantiated automatically when you import the module. You don't need to pass any arguments to the constructor.

```python
from mps.service import mps

# mps is a ready-to-use, pre-instantiated MPS object
# Access its components directly:
mps.image_manager
mps.token_manager
```

At minimum, you must set the `REGISTRY_PROVIDER` environment variable before importing. The module instantiates `mps = MPS()` at import time, so any misconfiguration will raise an error immediately on import.

---

## Question
Which environment variables does `MPS` read, and what do they control?

## Answer
The constructor reads the following environment variables:

| Variable | Purpose | Default |
|----------|---------|---------|
| `REGISTRY_PROVIDER` | Selects the registry backend (`aws`, `azure`, `gcp`, `local`, `export`) | `None` |
| `REGISTRY_ADDR` | The registry address/host | `None` |
| `REGISTRY_USER` | Username for authentication | `None` |
| `REGISTRY_PASS` | Password for authentication | `None` |
| `AWS_REGISTRY_REGION` | AWS region (only used when provider is `aws`) | `None` |
| `REGISTRY_VERIFY_CERTIFICATE_SIGNING` | Whether to verify TLS cert signing (only used when provider is `local`) | `True` |

Example setup for an Azure registry:

```bash
export REGISTRY_PROVIDER=azure
export REGISTRY_ADDR=myregistry.azurecr.io
export REGISTRY_USER=myuser
export REGISTRY_PASS=mysecret
```

---

## Question
What registry providers are supported and how do they differ?

## Answer
There are five supported values for `REGISTRY_PROVIDER`:

- **`aws`** — Uses `AWSTokenManager`, which additionally requires `AWS_REGISTRY_REGION`.
- **`azure`** / **`gcp`** — Use the generic `TokenManager` with the provider name passed through.
- **`local`** — Uses `TokenManager` and respects the `REGISTRY_VERIFY_CERTIFICATE_SIGNING` flag for TLS verification.
- **`export`** — A special mode using `localhost` and empty credentials; it sets `export_image_as_file=True` so images are exported as files rather than pushed to a remote registry.

Any other value raises `InvalidRegistryProvider`.

---

## Question
How do I configure the `export` provider, and what makes it special?

## Answer
Set `REGISTRY_PROVIDER=export`. This mode is unique because:

1. The `TokenManager` is created with `registry="localhost"` and empty username/password — no real credentials are needed.
2. The `ImageManager` is created with `export_image_as_file=True`, meaning images are written to a file instead of pushed to a remote registry.

```bash
export REGISTRY_PROVIDER=export
```

This is the only provider that flips the `export_image_as_file` flag on. For all other providers, it remains `False`.

---

## Question
How does `verify_certificate_signing` work for the `local` provider, and what values are valid?

## Answer
The `local` provider accepts `REGISTRY_VERIFY_CERTIFICATE_SIGNING` as either a boolean or a string. Since environment variables are always strings, the code normalizes them:

- If it's a string `"true"` or `"false"` (case-insensitive), it's parsed via `json.loads()` into a real boolean.
- If it's already a `bool` (the default `True`), it's left as-is.
- Anything else raises a `ValueError`.

```bash
# All valid:
export REGISTRY_VERIFY_CERTIFICATE_SIGNING=true
export REGISTRY_VERIFY_CERTIFICATE_SIGNING=False
```

```python
# Invalid — raises ValueError
export REGISTRY_VERIFY_CERTIFICATE_SIGNING=yes
```

Note that `json.loads` is intentionally used instead of `eval` because it's safer — it won't execute arbitrary code from the environment variable.

---

## Question
What happens if I forget to set `REGISTRY_PROVIDER` or set it to an unsupported value?

## Answer
If `REGISTRY_PROVIDER` is unset (`None`) or set to any value other than `aws`, `azure`, `gcp`, `local`, or `export`, the constructor raises `InvalidRegistryProvider`:

```python
from mps.api.errors import InvalidRegistryProvider

# Raised at import time / instantiation:
# InvalidRegistryProvider: Expected "aws", "azure", "gcp", "local" or
# "export" as REGISTRY_PROVIDER. Instead got None
```

Because the module instantiates `mps = MPS()` at the bottom of the file, **this error fires the moment you import the module** — not lazily. Make sure your environment is configured before any import occurs.

---

## Question
How do I handle configuration errors gracefully?

## Answer
Wrap the import or instantiation in a try/except block. Two distinct exceptions can occur:

- `InvalidRegistryProvider` — for an unknown/missing provider.
- `ValueError` — for an invalid `verify_certificate_signing` value (local provider only).

```python
from mps.api.errors import InvalidRegistryProvider

try:
    from mps.service import mps
except InvalidRegistryProvider as e:
    print(f"Bad registry configuration: {e}")
except ValueError as e:
    print(f"Bad certificate verification setting: {e}")
```

If you want full control over when errors are raised, create your own instance instead of relying on the module-level singleton:

```python
from mps.service import MPS

try:
    my_mps = MPS()
except (InvalidRegistryProvider, ValueError) as e:
    # Handle and recover
    ...
```

---

## Question
Why does the AWS provider require an extra environment variable?

## Answer
AWS ECR authentication is region-specific, so `AWSTokenManager` needs the region to build the correct registry endpoint and token request. This comes from `AWS_REGISTRY_REGION`:

```bash
export REGISTRY_PROVIDER=aws
export REGISTRY_ADDR=123456789.dkr.ecr.us-east-1.amazonaws.com
export AWS_REGISTRY_REGION=us-east-1
export REGISTRY_USER=AWS
export REGISTRY_PASS=...
```

If `AWS_REGISTRY_REGION` is unset, it defaults to `None`, which will likely cause `AWSTokenManager` to fail downstream. Always set it explicitly for the `aws` provider.

---

## Question
Should I use the module-level `mps` object or create my own `MPS()` instance?

## Answer
The module exposes a pre-built singleton: `mps = MPS()`. This is convenient for most applications:

```python
from mps.service import mps
```

**Use the singleton when:** your configuration is fixed via environment variables at startup and you want a shared instance.

**Create your own instance when:**
- You need to control exactly when configuration errors surface (the singleton fails at import time).
- You're writing tests and want to set env vars before instantiation.
- You need multiple configurations in the same process (though note all instances still read the same global environment variables).

```python
import os
os.environ["REGISTRY_PROVIDER"] = "export"

from mps.service import MPS
my_mps = MPS()
```

**Pitfall:** Because the singleton is instantiated at import, setting environment variables *after* importing `mps.service` won't affect it. Set them before importing, or use a fresh `MPS()` instance.