---
id: a5ec3c0a-f0ae-5edd-82e6-f06a42c89cf4
type: qa
title: "Maintenance FAQ"
created_at: 2026-06-06T19:04:26.732329+00:00
updated_at: 2026-06-20T22:55:26.737022+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  module_name: "mps.routers.maintenance"
  language: "python"
  source_name: "mps"
---
# Maintenance FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# Maintenance FAQ


# Maintenance Router FAQ

The `mps.routers.maintenance` module provides FastAPI endpoints for inspecting and managing locally exported container images and images pushed to a container registry. Below are common questions developers ask about this module.

---

## How do I enable the maintenance endpoints?

## Answer
The maintenance routes are **conditionally registered** at import time, based on the `MAINTENANCE_MODE` environment variable. The endpoints only exist if `MAINTENANCE_MODE` is set to the string `"true"` (case-insensitive).

```bash
# Enable maintenance endpoints
export MAINTENANCE_MODE=true

# Then start your app
uvicorn mps.api.main:app
```

If `MAINTENANCE_MODE` is unset or any value other than `"true"`, the route definitions are skipped entirely and the endpoints will return `404 Not Found`.

```python
troubleshoot = os.environ.get('MAINTENANCE_MODE')
if troubleshoot and troubleshoot.lower() == 'true':
    # routes registered here
```

> **Gotcha:** The variable is evaluated only **once at module import time**. Changing the environment variable after the app has started has no effect — you must restart the process.

---

## What endpoints does this module expose?

## Answer
When maintenance mode is enabled, four endpoints are added under the `/modelpromotion/maintenance/` prefix, all tagged `Maintenance`:

| Method | Path | Purpose |
|--------|------|---------|
| `GET`    | `/modelpromotion/maintenance/local_images`      | List locally exported images |
| `DELETE` | `/modelpromotion/maintenance/local_images`      | Delete images from local storage |
| `GET`    | `/modelpromotion/maintenance/total_image_size`  | Get total size of exported images on disk |
| `GET`    | `/modelpromotion/maintenance/list_pushed_images`| List images pushed to the registry |

You can explore them interactively via the Swagger UI at `/modelpromotion/docs`.

---

## How do I list the images currently stored locally?

## Answer
Send a `GET` request to the `local_images` endpoint. It returns a JSON array of strings (`list[str]`).

```bash
curl http://localhost:8000/modelpromotion/maintenance/local_images
```

Example response:
```json
["model-a:1.0", "model-b:2.1"]
```

Internally this delegates to the image manager:
```python
async def list_images():
    return await mps.image_manager.list_local_images()
```

---

## How do I free up disk space by deleting local images?

## Answer
Use the `DELETE` method on the `local_images` endpoint. It removes images from local storage and returns the list of affected images.

```bash
curl -X DELETE http://localhost:8000/modelpromotion/maintenance/local_images
```

```python
async def delete_local_images():
    return await mps.image_manager.delete_local_images()
```

> **Important:** Deleting local images does **not** remove them from the container registry. As the endpoint summary notes, *"Successfully exported images would still be available on the {registry_provider} container registry."* This makes it safe to reclaim local disk space without losing already-pushed images.

For verifying what remains in the registry afterward, see the `list_pushed_images` endpoint below.

---

## How is the total image size reported, and what format is it in?

## Answer
The `total_image_size` endpoint returns a **human-readable string** (not raw bytes). It uses the `humanfriendly.format_size` helper to convert the byte count.

```bash
curl http://localhost:8000/modelpromotion/maintenance/total_image_size
# -> "1.5 GB"
```

```python
async def get_total_images_size():
    return PlainTextResponse(format_size(await mps.image_manager.get_size_of_images()))
```

> **Note:** This endpoint returns `PlainTextResponse`, so the body is the bare string `1.5 GB` rather than a JSON-quoted value. Parse it as plain text, not JSON.

---

## What is the difference between `local_images` and `list_pushed_images`?

## Answer
These two endpoints query different sources:

- **`/local_images`** — images that have been **exported to local disk** on the host running the service.
- **`/list_pushed_images`** — images that have been **pushed to the container registry** (e.g., your `registry_provider`).

```python
# Local disk
async def list_images():
    return await mps.image_manager.list_local_images()

# Registry
async def remote_images():
    return JSONResponse(content=await mps.image_manager.list_pushed_images())
```

A typical workflow is: export images locally → push to registry → confirm with `list_pushed_images` → delete local copies to reclaim space. Use both endpoints together to reconcile local vs. remote state.

---

## Why are some endpoints returning Response objects directly while others return plain values?

## Answer
There are two return styles in this module:

1. **Returning a value** (relies on FastAPI serialization via `response_model`):
   ```python
   async def list_images():
       return await mps.image_manager.list_local_images()  # -> list[str]
   ```
2. **Returning an explicit Response object:**
   ```python
   return PlainTextResponse(...)   # total_image_size
   return JSONResponse(content=...)  # list_pushed_images
   ```

When you return an explicit `Response` (like `PlainTextResponse` or `JSONResponse`), FastAPI bypasses the `response_model` validation/serialization. That's why `list_pushed_images` has **no** `response_model` — its shape is determined entirely by whatever `list_pushed_images()` returns.

> **Pitfall:** If you add a `response_model` to an endpoint that returns a raw `JSONResponse`, the model will **not** validate the body. Keep this in mind when documenting expected schemas.

---

## How can I debug whether maintenance mode is active at startup?

## Answer
When maintenance mode is enabled, the module emits a debug log line at import time:

```python
logger.debug('Adding maintenance routes. Endpoint documentation is available under /modelpromotion/docs\n')
```

To see this message, ensure your logger level is set to `DEBUG`. If you don't see it and the endpoints return `404`:

1. Confirm `MAINTENANCE_MODE=true` (exactly the string, case-insensitive).
2. Confirm the variable was set **before** the process started.
3. Check `/modelpromotion/docs` — the endpoints should appear under the **Maintenance** tag.

---

## Are these endpoints safe to expose in production?

## Answer
Treat them as **privileged operations**, especially the `DELETE` endpoint, which removes images from local storage. Best practices:

- Keep `MAINTENANCE_MODE` **disabled** in production by default, enabling it only during troubleshooting.
- Place these endpoints behind authentication/authorization or network restrictions — this module itself adds **no auth**.
- Remember the destructive `DELETE` is non-recoverable locally (though pushed images survive in the registry).

The intent, signaled by the `Maintenance` tag and the conditional registration, is that these are operator/troubleshooting tools rather than always-on public API surface.