---
id: 9573dc86-ed22-546d-8f4b-36b17cdabbe1
type: qa
title: "Dockerfile FAQ"
created_at: 2026-07-03T05:58:35.301807+00:00
updated_at: 2026-07-03T05:58:35.301820+00:00
source_files:
  - /Users/spark/git/service-model-promotion/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/builder/Dockerfile`

# stage0.Dockerfile — Q&A Documentation

## Question
What is the purpose of this Dockerfile and what base image does it use?

## Answer
This Dockerfile (`stage0`) builds a development/tooling image based on the official Python image `python:3.12.7-bookworm` (Python 3.12.7 on Debian Bookworm).

On top of Python, it installs a broad set of build and automation tooling:

- **Poetry 1.8.3** — Python dependency and packaging management
- **AWS CLI** — for interacting with AWS services
- **Podman** — a daemonless container engine (Docker alternative)
- **Git, curl, pigz** — version control, HTTP transfers, and parallel gzip compression
- **NVM + Node.js 18.14.0** — JavaScript runtime via Node Version Manager
- **typora-parser** — a Node package for parsing Typora/Markdown files

The name `stage0` suggests it's intended as a foundational base image that later build stages or downstream images extend.

---

## Question
How do I build and run this image?

## Answer
Build the image, giving it a tag:

```bash
docker build -f stage0.Dockerfile -t stage0:latest .
```

Run an interactive shell inside it:

```bash
docker run -it --rm stage0:latest bash
```

Verify the installed tools:

```bash
docker run --rm stage0:latest bash -lc "python --version && poetry --version && node --version && git --version"
```

---

## Question
Why is `ENV NODE_VERSION="18.14.0"` set, and how is it used?

## Answer
`NODE_VERSION` centralizes the Node.js version so it can be referenced in multiple `RUN` and `ENV` instructions. It's used both to construct the `PATH` and to `cd` into the correct NVM install directory:

```dockerfile
ENV PATH="${PATH}:/root/.nvm/versions/node/v18.14.0/bin/"
RUN cd /root/.nvm/versions/node/v$NODE_VERSION/bin ...
```

**Pitfall:** The `ENV PATH` line hardcodes `v18.14.0` rather than using `$NODE_VERSION`. If you bump the version variable, you must also update the `PATH` string, or the binaries won't be found. A cleaner approach is:

```dockerfile
ENV PATH="${PATH}:/root/.nvm/versions/node/v${NODE_VERSION}/bin/"
```

---

## Question
Why does the Dockerfile reinstall `debian-archive-keyring` and use `--allow-unauthenticated`?

## Answer
These are workarounds for **APT GPG key / repository authentication failures**, which commonly occur when the Debian archive signing keys in the base image are stale or expired:

```dockerfile
&& apt update --allow-unauthenticated \
&& apt install --reinstall debian-archive-keyring \
```

`debian-archive-keyring` refreshes the trusted signing keys, allowing subsequent `apt install` commands to succeed.

**Best practice caution:** `--allow-unauthenticated` bypasses package signature verification and weakens supply-chain security. Prefer refreshing the keyring first (and only running normal `apt update` afterward) rather than relying on unauthenticated installs. Consider whether the base image itself is out of date.

---

## Question
How does NVM/Node get installed, and why is `. ~/.bashrc` needed?

## Answer
Node is installed via the NVM install script:

```dockerfile
&& curl -LsS https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh | bash -s --
```

NVM sets up its environment through shell initialization files (`~/.bashrc`). Each Docker `RUN` uses a fresh non-login, non-interactive shell, so NVM functions and paths aren't automatically available. Sourcing `.bashrc` loads them:

```dockerfile
RUN cd /root/.nvm/versions/node/v$NODE_VERSION/bin \
    && . ~/.bashrc \
    && npm install -g typora-parser
```

**Gotcha:** The script installs whatever NVM version `master` points to at build time, making builds non-reproducible. Also, NVM's install script doesn't install a specific Node version by default — this Dockerfile relies on the `v18.14.0` directory already existing, which may fail if NVM doesn't install that version. A more robust approach:

```dockerfile
RUN curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash \
    && . ~/.nvm/nvm.sh \
    && nvm install $NODE_VERSION \
    && npm install -g typora-parser
```

---

## Question
Why is `podman` installed inside a container image?

## Answer
Podman is a daemonless container engine, often installed to enable **container-in-container** or **build** workflows (e.g., building/running images from within CI pipelines).

**Pitfall:** Running Podman inside a container typically requires elevated privileges or specific configuration (`--privileged`, user namespace setup, or rootless configuration). It won't work out of the box in a locked-down runtime. Verify your orchestrator/CI supports nested containerization before relying on this.

---

## Question
How can I make this image smaller and cleaner?

## Answer
The current Dockerfile leaves APT caches in the final image, increasing size. Clean up within the same `RUN` layer:

```dockerfile
RUN apt-get update \
    && apt-get install -y --no-install-recommends podman git curl pigz \
    && rm -rf /var/lib/apt/lists/*
```

Additional recommendations:
- Use `--no-install-recommends` to avoid pulling unnecessary packages.
- Pin the NVM install script to a tagged version for reproducibility.
- Combine related `RUN` steps to reduce layers, but keep logical grouping for cache efficiency.
- Consider a multi-stage build if `stage0` is only a build-time toolchain — copy only needed artifacts into a slim final image.

---

## Question
How do I use Poetry inside a container built from this image?

## Answer
Poetry 1.8.3 is preinstalled globally. Mount your project and run commands directly:

```bash
docker run -it --rm -v "$PWD:/app" -w /app stage0:latest \
    bash -lc "poetry install && poetry run pytest"
```

**Tip:** By default Poetry creates virtual environments. Inside a container you often want to install directly into the system environment:

```bash
poetry config virtualenvs.create false
poetry install
```

---

## Question
Node commands aren't found when I run the container — how do I debug this?

## Answer
This is usually a `PATH` or shell-initialization issue. Check the following:

1. **Confirm the Node directory exists** (it depends on NVM installing exactly `v18.14.0`):

   ```bash
   docker run --rm stage0:latest bash -lc "ls /root/.nvm/versions/node/"
   ```

2. **Use a login shell** so `.bashrc`/NVM initialization runs:

   ```bash
   docker run -it --rm stage0:latest bash -l
   ```

3. **Verify PATH** matches the actual installed version:

   ```bash
   docker run --rm stage0:latest bash -lc 'echo $PATH && which node'
   ```

If the version directory doesn't match the hardcoded `PATH`, update either `NODE_VERSION` and the `PATH` string together, or switch to sourcing `nvm.sh` and running `nvm use $NODE_VERSION` explicitly.

---

## Question
Is this image safe to use in production?

## Answer
This image is designed as a **build/tooling (stage0) base image**, not a lean production runtime. Concerns for production use:

- It uses `--allow-unauthenticated` APT installs (reduced supply-chain trust).
- It pulls the NVM install script from `master` at build time (non-reproducible, potential supply-chain risk).
- It bundles many heavy tools (AWS CLI, Podman, Git) that a running app usually doesn't need, increasing attack surface and image size.

**Recommendation:** Use this image for building/testing, then produce a minimal runtime image (e.g., via multi-stage builds copying only your application artifacts) for deployment.