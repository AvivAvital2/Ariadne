---
id: 2c638f68-c702-5999-97a9-804ad8d7253b
type: qa
title: "Basic FAQ"
created_at: 2026-06-06T19:04:20.707524+00:00
updated_at: 2026-06-20T22:55:26.760490+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  module_name: "mps.routers.basic"
  language: "python"
  source_name: "mps"
---
# Basic FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# Basic FAQ


# `mps.routers.basic` — FAQ

This module defines a small FastAPI `APIRouter` with three endpoints: a health check, a build-info endpoint, and a ping endpoint.

---

## What endpoints does this router expose?

## Answer
The router defines three GET endpoints:

| Method | Path | Returns |
|--------|------|---------|
| GET | `/healthcheck` | `PlainTextResponse("OK")` |
| GET | `/modelpromotion/buildInfo` | JSON content read from `conf/build.info` |
| GET | `/modelpromotion/ping` | `PlainTextResponse("Pong")` |

The `/healthcheck` and `/modelpromotion/ping` endpoints are lightweight liveness probes, while `/modelpromotion/buildInfo` exposes build metadata read from disk.

---

## How do I register this router in my FastAPI app?

## Answer
Import the `router` object and include it in your `FastAPI` application:

```python
from fastapi import FastAPI
from mps.routers.basic import router

app = FastAPI()
app.include_router(router)
```

Once registered, you can hit the endpoints:

```bash
curl http://localhost:8000/healthcheck          # -> OK
curl http://localhost:8000/modelpromotion/ping  # -> Pong
curl http://localhost:8000/modelpromotion/buildInfo  # -> JSON
```

You can also add a prefix and tags when including the router:

```python
app.include_router(router, prefix="/api", tags=["basic"])
# Now the healthcheck is at /api/healthcheck
```

---

## Why are there two functions named `ping`?

## Answer
There are two functions both named `ping` in the module — one for `/healthcheck` and one for `/modelpromotion/ping`. **This is a pitfall.**

Because they share a name, the second definition overwrites the first as a module-level attribute. The routing itself still works (FastAPI captures the function reference at decoration time), but:

- You **cannot** reference the first `ping` by name anywhere else in the module.
- Tooling, tests, and introspection (`from mps.routers.basic import ping`) will only see the second one (the `/modelpromotion/ping` handler returning `"Pong"`).

**Best practice:** give handlers unique, descriptive names:

```python
@router.get("/healthcheck")
async def healthcheck():
    return PlainTextResponse("OK")

@router.get("/modelpromotion/ping")
async def modelpromotion_ping():
    return PlainTextResponse("Pong")
```

---

## What format does `conf/build.info` need to be in?

## Answer
The `build_info` endpoint reads the file and parses it with `json.loads`, so the file **must contain valid JSON**:

```json
{
  "version": "1.2.3",
  "commit": "a1b2c3d",
  "buildDate": "2024-01-15T10:30:00Z"
}
```

The parsed object is returned directly as the JSON response body with HTTP 200. If the file contains anything that is not valid JSON, parsing will raise an exception (see error-handling question below).

---

## Why use `aiofiles` instead of a normal `open()`?

## Answer
The endpoint is an `async def` coroutine. Using the built-in blocking `open()` and `f.read()` would block the event loop, stalling all other concurrent requests while the file is read. `aiofiles` provides non-blocking file I/O so the event loop stays free:

```python
async with aiofiles.open("conf/build.info", mode="r") as f:
    data = await f.read()
```

**Pitfall:** never use synchronous file/network I/O inside an `async def` handler. Either use an async library (like `aiofiles`) or run the blocking call in a thread pool (`run_in_threadpool`).

---

## What happens if `conf/build.info` is missing or invalid?

## Answer
The current code does **no error handling**, so:

- Missing file → `FileNotFoundError` → FastAPI returns a `500 Internal Server Error`.
- Malformed JSON → `json.JSONDecodeError` → also a `500`.

To return cleaner errors, wrap the logic:

```python
from fastapi import HTTPException

@router.get("/modelpromotion/buildInfo")
async def build_info():
    try:
        async with aiofiles.open("conf/build.info", mode="r") as f:
            data = await f.read()
        return JSONResponse(content=json.loads(data), status_code=HTTP_200_OK)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="build.info not found")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="build.info is not valid JSON")
```

---

## Why is the path to `conf/build.info` a problem, and how do I fix it?

## Answer
`"conf/build.info"` is a **relative path**, resolved against the current working directory (CWD) of the running process — not the location of the source file. If you start the app from a different directory, the file won't be found.

**Best practice:** resolve the path relative to a known anchor or use an environment-configurable absolute path:

```python
from pathlib import Path
import os

BUILD_INFO_PATH = Path(os.getenv("BUILD_INFO_PATH", "conf/build.info"))

@router.get("/modelpromotion/buildInfo")
async def build_info():
    async with aiofiles.open(BUILD_INFO_PATH, mode="r") as f:
        ...
```

This makes the location predictable across environments (local dev, Docker, CI).

---

## Which endpoint should I use for Kubernetes liveness/readiness probes?

## Answer
Use `/healthcheck` (or `/modelpromotion/ping`) for lightweight liveness checks since they return immediately and have no dependencies:

```yaml
livenessProbe:
  httpGet:
    path: /healthcheck
    port: 8000
  initialDelaySeconds: 5
  periodSeconds: 10
```

Avoid using `/modelpromotion/buildInfo` for probes — it performs file I/O and can fail (500) if the build file is missing, which would incorrectly mark the pod as unhealthy.

---

## How do I test these endpoints?

## Answer
Use FastAPI's `TestClient`. Mount the router on a test app first:

```python
from fastapi import FastAPI
from fastapi.testclient import TestClient
from mps.routers.basic import router

app = FastAPI()
app.include_router(router)
client = TestClient(app)

def test_healthcheck():
    resp = client.get("/healthcheck")
    assert resp.status_code == 200
    assert resp.text == "OK"

def test_ping():
    resp = client.get("/modelpromotion/ping")
    assert resp.text == "Pong"
```

For `build_info`, create a temporary `conf/build.info` file (or monkeypatch the path) so the read succeeds during the test.

---

## Can I customize the response status codes or content types?

## Answer
Yes. The handlers return Starlette/FastAPI response objects directly, so you can adjust them:

- `PlainTextResponse` sets `Content-Type: text/plain`.
- `JSONResponse` sets `Content-Type: application/json`.
- `status_code` is explicit on `build_info` (`HTTP_200_OK`); the plain-text endpoints default to `200`.

To customize, just change the response object, for example returning a custom code:

```python
return PlainTextResponse("OK", status_code=200, headers={"X-Service": "mps"})
```

Returning the response object directly (rather than a plain dict) bypasses FastAPI's response-model serialization, giving you full control over body, headers, and status.