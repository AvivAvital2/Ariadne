---
id: 910d9598-4755-5115-b86c-dbb2c1b318ef
type: qa
title: "Errors FAQ"
created_at: 2026-06-06T19:03:28.176796+00:00
updated_at: 2026-06-20T22:55:26.776397+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  module_name: "mps.api.errors"
  language: "python"
  source_name: "mps"
---
# Errors FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# Errors FAQ


# `mps.api.errors` — FAQ Documentation

This module defines the custom exception hierarchy for the MPS (`mps.api`) package. All exceptions inherit from a common base, `ExceptionHandler`, which adds automatic logging and optional HTTP status codes.

---

## What is the purpose of the `ExceptionHandler` base class?

## Answer
`ExceptionHandler` is the common base class for every custom exception in this module. It does three things beyond a standard `Exception`:

1. Stores the error message in `self.detail`.
2. **Automatically logs the message at the `error` level** when the exception is created (via the module's `Logger`).
3. Optionally stores an HTTP-style `status_code`.

```python
class ExceptionHandler(Exception):
    def __init__(self, message, status_code=None):
        self.Logger = Logger(__name__).logger
        self.detail = message
        self.Logger.error(message)        # logged on instantiation
        self.status_code = status_code
```

Because logging happens in `__init__`, the error is recorded the moment you *instantiate* the exception — even before it is raised or caught.

---

## How do I raise one of these exceptions?

## Answer
Most exceptions take a single `message` string. Import the specific exception and `raise` it like any other Python exception.

```python
from mps.api.errors import NoConfigurationFileFoundError

def load_config(path):
    if not os.path.exists(path):
        raise NoConfigurationFileFoundError(
            f"Configuration file not found at: {path}"
        )
```

The message is automatically logged when the exception object is constructed, so you don't need a separate logging call.

---

## Which exceptions require a `status_code`, and how do I pass it?

## Answer
Only `UnableToGetAuthToken` accepts (and requires) a `status_code` argument in addition to the message:

```python
def __init__(self, message: str, status_code: int):
    super().__init__(message, status_code)
```

All other exceptions accept only a `message`. Example:

```python
from mps.api.errors import UnableToGetAuthToken

resp = requests.post(ecr_token_url)
if resp.status_code != 200:
    raise UnableToGetAuthToken(
        "Failed to fetch AWS ECR auth token",
        status_code=resp.status_code,
    )
```

For all other exceptions, `status_code` defaults to `None`. If you need a status code on them, you'd have to extend the class — passing one positionally to a single-`message` subclass will raise a `TypeError`.

---

## How should I catch these exceptions?

## Answer
Because every exception inherits from `ExceptionHandler`, you can catch them individually for specific handling or catch the base class to handle them all at once.

Catch a specific error:
```python
from mps.api.errors import UnreachableContainerRegistry

try:
    connect_to_registry(url)
except UnreachableContainerRegistry as e:
    print(f"Registry problem: {e.detail}")
```

Catch any MPS error:
```python
from mps.api.errors import ExceptionHandler

try:
    run_pipeline()
except ExceptionHandler as e:
    # All MPS errors share .detail and .status_code
    handle_failure(e.detail, e.status_code)
```

> **Tip:** Catch `ExceptionHandler` at your application boundary, but prefer catching specific subclasses where you can take meaningful, targeted action.

---

## How do I access the error message and status code after catching an exception?

## Answer
Each instance exposes:

- `e.detail` — the original message string
- `e.status_code` — the HTTP status code (or `None` if not provided)
- `str(e)` / `e.args[0]` — also the message

```python
try:
    fetch_token()
except UnableToGetAuthToken as e:
    print(e.detail)        # "Failed to fetch AWS ECR auth token"
    print(e.status_code)   # e.g. 403
    print(str(e))          # same message via __str__
```

Note that `__str__` returns `self.args[0]`, which is the first positional argument passed to `Exception.__init__` (the message).

---

## What's the difference between the various configuration-related errors?

## Answer
There are three closely related configuration exceptions. Use the one that matches the failure precisely:

| Exception | Use when... |
|---|---|
| `NoConfigurationFileFoundError` | The config **file itself** is missing. |
| `InvalidConfigurationFile` | The file exists but is **malformed/unparseable**. |
| `NoConfigurationFoundError` | The file is valid, but a required **value/version** isn't present in it. |
| `MissingConfigValues` | One or more **required config values** are absent. |

```python
if not config_file.exists():
    raise NoConfigurationFileFoundError("config.yaml missing")

try:
    data = yaml.safe_load(config_file.read_text())
except yaml.YAMLError:
    raise InvalidConfigurationFile("config.yaml is not valid YAML")

if "version" not in data:
    raise NoConfigurationFoundError("No 'version' key in configuration")

required = ["registry", "region"]
missing = [k for k in required if k not in data]
if missing:
    raise MissingConfigValues(f"Missing required config values: {missing}")
```

---

## Which errors relate to the container registry, and when does each apply?

## Answer
Several exceptions cover registry/image workflows:

- **`InvalidRegistryProvider`** — the configured registry provider isn't supported/recognized.
- **`InvalidAWSRegion`** — no `AWS_REGISTRY_REGION` was specified (AWS-specific).
- **`UnableToGetAuthToken`** — could not fetch an AWS ECR token (includes a `status_code`).
- **`UnreachableContainerRegistry`** — the registry endpoint can't be contacted.
- **`SelfSignedCertificate`** — certificate verification is enabled but the registry uses a self-signed cert.
- **`UnavailableImage`** — the configured base image doesn't exist locally or remotely.
- **`UnableToUploadOneOrMoreImages`** — pushing auxiliary images failed.
- **`UnableToObtainPushedImagesFromContainerRegistry`** — couldn't list/fetch repositories from the registry.
- **`UnableToStoreCredentialsFile`** — login succeeded but writing the credentials file failed.

Example flow:
```python
from mps.api.errors import (
    UnreachableContainerRegistry,
    SelfSignedCertificate,
    UnavailableImage,
)

try:
    registry.connect(url, verify=True)
except ConnectionError:
    raise UnreachableContainerRegistry(f"Cannot reach registry at {url}")
except ssl.SSLError:
    raise SelfSignedCertificate(f"Self-signed certificate at {url}")

if not registry.image_exists(image_ref):
    raise UnavailableImage(f"Image not found: {image_ref}")
```

---

## Is it a problem that logging happens inside `__init__`?

## Answer
It's an intentional design choice, but be aware of two gotchas:

1. **Logging occurs at construction, not at raise.** If you create an exception object without raising it, the error is still logged:
   ```python
   err = MissingConfigValues("oops")  # already logged here!
   ```
   Avoid pre-constructing these exceptions unless you intend the log entry.

2. **Re-raising won't double-log**, but creating a *new* instance for re-wrapping will produce a second log line. Prefer `raise` (bare) to preserve the original:
   ```python
   except MissingConfigValues:
       raise  # no extra log entry
   ```

---

## Can I add my own custom MPS exception?

## Answer
Yes. Subclass `ExceptionHandler` to inherit the automatic logging and `detail`/`status_code` attributes. Follow the existing pattern:

```python
from mps.api.errors import ExceptionHandler

class ImagePromotionFailed(ExceptionHandler):
    """Raised when promoting an image between environments fails."""
    def __init__(self, message: str):
        super().__init__(message)
```

If your error maps to an HTTP response, accept and forward a `status_code`:

```python
class RegistryRateLimited(ExceptionHandler):
    """Raised when the registry returns a 429."""
    def __init__(self, message: str, status_code: int):
        super().__init__(message, status_code)
```

This keeps your error consistent with the rest of the module and ensures it's caught by `except ExceptionHandler`.

---

## Why do `__repr__`, `__str__`, and `exception_handler` reference `self.args[0]`?

## Answer
These dunder methods rely on `Exception.args`, which Python populates from the positional arguments passed to the base `Exception.__init__`. Since the message is always passed first, `self.args[0]` is the message string.

```python
def __str__(self):
    return self.args[0]      # the message
```

These methods are marked `# pragma: no cover` (excluded from coverage) and are primarily for display/representation. Note that `__repr__` also reassigns `sys.excepthook` as a side effect — generally you should rely on `e.detail` or `str(e)` for the message rather than depending on `__repr__` behavior.