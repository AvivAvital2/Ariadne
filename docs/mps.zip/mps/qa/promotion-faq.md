---
id: 7d7a75e8-cdc8-5cb2-9e0c-49e7baed83e4
type: qa
title: "Promotion FAQ"
created_at: 2026-06-06T19:04:44.709237+00:00
updated_at: 2026-06-20T22:55:26.736401+00:00
source_files:
  - /Users/spark/git/service-model-promotion/promotion.conf
metadata:
  module_name: "promotion"
  language: "hocon"
  source_name: "mps"
---
# Promotion FAQ

**Related files:**
- `/Users/spark/git/service-model-promotion/promotion.conf`

# Promotion FAQ


# Promotion Module — FAQ Documentation

This document answers common questions about the `promotion` module's HOCON configuration, which covers HTTP client proxy settings, base image references, and model promotion authentication.

---

## How do I enable an HTTP proxy for the promotion module's HTTP client?

## Answer
By default, the proxy is disabled (`httpClient.proxy.enabled = false`). To route outbound HTTP traffic through a proxy, set `enabled` to `true` and supply the proxy host and port:

```hocon
httpClient.proxy.enabled = true
httpClient.proxy.config.host = "proxy.internal.example.com"
httpClient.proxy.config.port = 3128
```

The default port is `3128` (a common Squid proxy port). If your proxy listens elsewhere, override `port` accordingly.

> **Pitfall:** Setting `enabled = true` while leaving `host = ""` (the default) will likely cause connection failures, since there is no valid host to connect through. Always provide a non-empty host when enabling the proxy.

---

## How do I configure an authenticated proxy?

## Answer
Proxy authentication is controlled separately from the proxy itself via `httpClient.proxy.authentication`. Enable it and supply credentials:

```hocon
httpClient.proxy.enabled = true
httpClient.proxy.config.host = "proxy.internal.example.com"
httpClient.proxy.config.port = 3128

httpClient.proxy.authentication.enabled = true
httpClient.proxy.authentication.username = "svc-promotion"
httpClient.proxy.authentication.password = "s3cr3t"
```

Note that `proxy.enabled` and `proxy.authentication.enabled` are independent flags. You must enable **both** to use an authenticated proxy. Enabling authentication while the proxy itself is disabled has no effect.

> **Best practice:** Do not commit real credentials to source control. Inject the username/password via environment variables or a secrets manager and reference them, for example:
> ```hocon
> httpClient.proxy.authentication.password = ${?PROXY_PASSWORD}
> ```

---

## What are the `baseImage.3-0-0.*` entries and how do I use them?

## Answer
These entries map logical build variants to specific prediction-server Docker images for version `3.0.0`. Four variants are defined:

| Key | Image |
|-----|-------|
| `aio` | `reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.0.0-aio` |
| `osm` | `reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.0.0-osm` |
| `gdata` | `reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.0.0-gdata` |
| `minimal` | `reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.0.0` |

The promotion module selects one of these images as the base for a promoted model based on the requested variant. The `minimal` variant uses the unsuffixed tag (`prod-3.0.0`), while the others append a suffix describing their bundled capabilities.

---

## What's the difference between the `aio`, `osm`, `gdata`, and `minimal` variants?

## Answer
The variants are distinguished by their image tag suffixes:

- **`minimal`** — the base prediction server (`prod-3.0.0`), the leanest option.
- **`aio`** — "all-in-one"; the most complete image bundling extra capabilities.
- **`osm`** — an image bundling OpenStreetMap-related data/functions.
- **`gdata`** — an image bundling additional geo/data resources.

Choose `minimal` when you don't need bundled extras (smaller image, faster pulls). Choose `aio`, `osm`, or `gdata` when your model depends on the functions/data those variants include.

> **Pitfall:** All entries are pinned to the same `3.0.0` server version. Mixing models compiled against a different server version with these base images can cause runtime incompatibilities.

---

## How do I add support for a new base image version?

## Answer
The version is embedded in the configuration key (`baseImage.3-0-0`). To add another version, introduce a parallel block with the new version key and its variants:

```hocon
baseImage.3-1-0.aio     = "reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.1.0-aio"
baseImage.3-1-0.osm     = "reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.1.0-osm"
baseImage.3-1-0.gdata   = "reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.1.0-gdata"
baseImage.3-1-0.minimal = "reg.sparkbeyond.com/sparkbeyond/prediction-server:prod-3.1.0"
```

> **Note:** The dots in the version (`3.0.0`) are written as dashes (`3-0-0`) in the key. This is because HOCON treats `.` as a path separator — using `3.0.0` would create nested objects `3 → 0 → 0` instead of a single key. Keep the dash convention for all variants of a version.

---

## What does `modelpromotion.auth.enabled = off` mean?

## Answer
This disables authentication for the model promotion endpoint/process. In HOCON, `off` is a boolean literal equivalent to `false` (just as `on` equals `true`).

So the following are all equivalent:

```hocon
modelpromotion.auth.enabled = off
modelpromotion.auth.enabled = false
modelpromotion.auth.enabled = no
```

To require authentication for model promotion, set it to `on` / `true`:

```hocon
modelpromotion.auth.enabled = on
```

> **Best practice:** `off` is typically appropriate only for local development or trusted internal networks. In production or shared environments, enable authentication to prevent unauthorized model promotions.

---

## How can I verify which proxy and image settings are actually being applied?

## Answer
Because HOCON merges configuration from multiple sources (defaults, environment-specific overrides, environment variables), the effective values may differ from this file. To debug:

1. **Resolve the config** and log the merged result at startup, focusing on the relevant paths:
   - `httpClient.proxy.enabled`
   - `httpClient.proxy.config.host` / `port`
   - `modelpromotion.auth.enabled`
2. **Confirm the chosen base image** by logging the resolved `baseImage.<version>.<variant>` value used for a given promotion.

> **Common gotcha:** An empty proxy host (`""`) combined with `proxy.enabled = true` often surfaces as confusing connection timeouts rather than a clear configuration error. Always log the resolved host/port to catch this early.

---

## What are the default values if I leave the proxy section untouched?

## Answer
Out of the box, the module ships with proxying fully disabled:

```hocon
httpClient.proxy.enabled               = false   # no proxy
httpClient.proxy.config.host           = ""      # empty
httpClient.proxy.config.port           = 3128    # default Squid port
httpClient.proxy.authentication.enabled = false  # no proxy auth
httpClient.proxy.authentication.username = ""
httpClient.proxy.authentication.password = ""
```

This means HTTP traffic goes directly to its destination. You only need to change these values if your environment requires outbound traffic to pass through a proxy.

---

## Related Topics
- **Proxy configuration** → `httpClient.proxy.*` (host, port) and `httpClient.proxy.authentication.*` (credentials) work together.
- **Image selection** → `baseImage.<version>.<variant>` keys are consumed during model promotion.
- **Security** → `modelpromotion.auth.enabled` and `httpClient.proxy.authentication.enabled` both govern access control aspects of the module.