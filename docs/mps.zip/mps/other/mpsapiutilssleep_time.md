---
id: 5b917f26-2ee5-58cb-bde5-7a7d53dafcc8
type: catalog
title: "mps.api.utils.sleep_time"
created_at: 2026-06-06T18:47:29.302874+00:00
updated_at: 2026-06-20T22:55:25.561886+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.sleep_time"
  signature: "sleep_time = 10"
  location: {'line_start': 130, 'line_end': 130, 'col_start': 4, 'col_end': 19}
  parent_qualified_name: "None"
  sha_at_sync: "4bff81e9f01a3c8a63cfdf3d35c14d240c54078577a6d175ad73d0947e20dca1"
  description: "Defines a module-level constant specifying the delay in seconds (10) used between retry or polling operations."
---
# mps.api.utils.sleep_time

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.sleep_time


variable mps.api.utils.sleep_time [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:130-130 :: sleep_time = 10

Description: Defines a module-level constant specifying the delay in seconds (10) used between retry or polling operations.