---
id: 81f9b823-8008-505b-b641-941f04948346
type: catalog
title: "mps.__main__.params['redoc_url']"
created_at: 2026-06-06T18:47:26.710435+00:00
updated_at: 2026-07-03T06:16:15.000444+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.params['redoc_url']"
  signature: "params['redoc_url'] = '/modelpromotion/redoc'"
  location: {'line_start': 20, 'line_end': 20, 'col_start': 4, 'col_end': 49}
  parent_qualified_name: "None"
  sha_at_sync: "31bf07dfadf19f1bec5a8cdbe973c621660152c0454867658f52603d75902d51"
  description: "Sets the URL path for the ReDoc API documentation interface to `/modelpromotion/redoc`."
---
# mps.__main__.params['redoc_url']

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.params['redoc_url']


variable mps.__main__.params['redoc_url'] [python] /Users/spark/git/service-model-promotion/mps/__main__.py:20-20 :: params['redoc_url'] = '/modelpromotion/redoc'

Description: Sets the URL path for the ReDoc API documentation interface to `/modelpromotion/redoc`.

## Related Documents

- [mps.__main__.params['docs_url']](c102b626-fa79-565e-a225-3b801d2a0446.md) - Related (graph distance 1.28)
- [mps.__main__.params['openapi_url']](3b58a546-63fd-5121-81ee-76772aeb10e1.md) - Related (graph distance 1.40)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 2.91)
- [mps.__main__.app](852e4e9d-3828-5d3a-aa74-fc747bc19fb5.md) - Related (graph distance 3.04)
