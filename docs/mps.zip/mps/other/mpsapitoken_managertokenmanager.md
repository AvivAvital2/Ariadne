---
id: a2fa93e7-c3a5-5fe9-b71c-b112437c2893
type: catalog
title: "mps.api.token_manager.TokenManager"
created_at: 2026-06-06T18:47:28.315380+00:00
updated_at: 2026-07-03T06:16:15.093251+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.token_manager.TokenManager"
  signature: "class TokenManager:"
  location: {'line_start': 12, 'line_end': 116, 'col_start': 0, 'col_end': 17}
  parent_qualified_name: "None"
  sha_at_sync: "dad0f1c8c08677e450d9785a259ab41ae96a0fd067fe49e26a84dc310b6d1486"
  description: "Manages authentication tokens for the MPS API, handling token storage, retrieval, validation, and automatic refresh when tokens expire."
---
# mps.api.token_manager.TokenManager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager


class mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:12-116 :: class TokenManager:

Description: Manages authentication tokens for the MPS API, handling token storage, retrieval, validation, and automatic refresh when tokens expire.

## Related Documents

- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 1.30)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.41)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.41)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 1.50)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 1.53)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 1.55)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 2.83)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 2.84)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 2.86)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.88)
