---
id: 1344817b-c5e0-525f-a06e-04aac4d8ad8c
type: catalog
title: "mps.service.MPS"
created_at: 2026-06-06T18:47:26.302984+00:00
updated_at: 2026-07-03T06:16:15.063659+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.service.MPS"
  signature: "class MPS:"
  location: {'line_start': 8, 'line_end': 74, 'col_start': 0, 'col_end': 27}
  parent_qualified_name: "None"
  sha_at_sync: "593513308efc1795654a67db991c2c6f6631f5fd5b1d6e9d064357bebfa25a07"
  description: "Represents a Master Production Schedule (MPS) service that manages and computes production planning data such as projected on-hand inventory, available-to-promise quantities, and scheduled production orders."
---
# mps.service.MPS

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS


class mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:8-74 :: class MPS:

Description: Represents a Master Production Schedule (MPS) service that manages and computes production planning data such as projected on-hand inventory, available-to-promise quantities, and scheduled production orders.

## Related Documents

- [mps.service.mps](7b6bc492-8863-5c99-bf5e-4a64146df5c1.md) - Related (graph distance 1.38)
- [mps.service.MPS.__init__](02c9072a-d854-59c0-9250-5768ad8d046c.md) - Related (graph distance 1.51)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 3.02)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 3.07)
