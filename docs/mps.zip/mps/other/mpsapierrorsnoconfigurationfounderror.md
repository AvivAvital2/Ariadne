---
id: 2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b
type: catalog
title: "mps.api.errors.NoConfigurationFoundError"
created_at: 2026-06-06T18:47:29.762498+00:00
updated_at: 2026-07-03T06:16:15.057754+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.NoConfigurationFoundError"
  signature: "class NoConfigurationFoundError(ExceptionHandler):"
  location: {'line_start': 23, 'line_end': 26, 'col_start': 0, 'col_end': 64}
  parent_qualified_name: "None"
  sha_at_sync: "c9e1ea91a7ff9745814ec5553077b26c94319b62fdcbc9becd6ba9c55ac69e67"
  description: "Exception handler for cases where no configuration is found, extending the base `ExceptionHandler` class to manage missing configuration errors in the MPS API."
---
# mps.api.errors.NoConfigurationFoundError

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.NoConfigurationFoundError


class mps.api.errors.NoConfigurationFoundError [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:23-26 :: class NoConfigurationFoundError(ExceptionHandler):

Description: Exception handler for cases where no configuration is found, extending the base `ExceptionHandler` class to manage missing configuration errors in the MPS API.

## Related Documents

- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.06)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.32)
- [mps.api.errors.MissingConfigValues](04edf404-d21e-5354-b2ae-458a08e7e3f2.md) - Related (graph distance 1.32)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.51)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.54)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.67)
- [mps.api.errors.UnableToStoreCredentialsFile](dd706baa-9f4e-5d89-ab0c-97163e21942b.md) - Related (graph distance 2.67)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 2.72)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.78)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 2.81)
