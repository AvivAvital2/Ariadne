---
id: 8657be3d-c0d3-5523-972b-70729bb49b32
type: catalog
title: "mps.api.schemas.BaseImages.make_versions_dict"
created_at: 2026-06-06T18:47:28.910006+00:00
updated_at: 2026-07-03T06:16:15.082299+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "function"
  qualified_name: "mps.api.schemas.BaseImages.make_versions_dict"
  signature: "def make_versions_dict(self, data, **kwargs):"
  location: {'line_start': 18, 'line_end': 20, 'col_start': 4, 'col_end': 19}
  parent_qualified_name: "mps.api.schemas.BaseImages"
  sha_at_sync: "c6297ae713b37b890bbbc2d0c501b26f43d1f22fbcaaa3129faebe02cda1fdf7"
  description: "Transforms the deserialized `BaseImages` data by collecting version-related fields into a nested `versions` dictionary, restructuring the flat input into a grouped format."
---
# mps.api.schemas.BaseImages.make_versions_dict

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.BaseImages.make_versions_dict


function mps.api.schemas.BaseImages.make_versions_dict in mps.api.schemas.BaseImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:18-20 :: def make_versions_dict(self, data, **kwargs):

Description: Transforms the deserialized `BaseImages` data by collecting version-related fields into a nested `versions` dictionary, restructuring the flat input into a grouped format.

## Related Documents

- [mps.api.schemas.BaseImages.data['versions']](3752f446-dad8-5aca-aa2a-719905e56a24.md) - Related (graph distance 1.40)
