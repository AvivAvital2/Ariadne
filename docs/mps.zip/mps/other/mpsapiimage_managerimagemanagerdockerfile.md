---
id: 1d33a630-85c3-5a00-a529-ca0bc9a71208
type: catalog
title: "mps.api.image_manager.ImageManager.dockerfile"
created_at: 2026-06-06T18:47:28.996834+00:00
updated_at: 2026-06-20T22:55:24.190141+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.dockerfile"
  signature: "dockerfile = f"FROM {base_image}\n" \"
  location: {'line_start': 53, 'line_end': 54, 'col_start': 8, 'col_end': 85}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "0c9baf812f5a864cd451611233033fb1e3f1cd5e76c0c5892ef34fe8f3d0dfde"
  description: "Constructs a Dockerfile string starting with a `FROM` instruction using the specified base image, used as the build context for creating a Docker image."
---
# mps.api.image_manager.ImageManager.dockerfile

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.dockerfile


variable mps.api.image_manager.ImageManager.dockerfile in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:53-54 :: dockerfile = f"FROM {base_image}\n" \

Description: Constructs a Dockerfile string starting with a `FROM` instruction using the specified base image, used as the build context for creating a Docker image.