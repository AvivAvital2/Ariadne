---
id: 31b30f45-f79f-5c02-8548-ea2bbacc0278
type: gotcha
title: "Token Manager Gotchas"
created_at: 2026-06-06T19:04:01.459098+00:00
updated_at: 2026-06-20T22:55:24.509495+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  module_name: "mps.api.token_manager"
  language: "python"
  source_name: "mps"
---
# Token Manager Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# Token Manager Gotchas


# Gotchas and Pitfalls: `mps.api.token_manager`

### `use_auth` is a bool but checked against `None`
**Trigger:** `self.use_auth` is assigned a boolean (`False`/`True`), but later code checks `if self.use_auth is None`. This condition is *never* true, so the `auth` branch always falls through to the tuple/credential path.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Use `auth=None if not self.use_auth else (self.username, self.password)`. The `is None` check is logically dead.
**Category:** type-system
**Example:**
```python
self.use_auth = False if (...) else True   # always bool, never None
# later:
auth=None if self.use_auth is None else (self.username, self.password)
# self.use_auth is None -> always False, so auth is always the tuple,
# even when use_auth == False (no auth intended)!
```

---

### `get_username_and_password` raises misleading error on missing file
**Trigger:** When `config.json` doesn't exist, a `FileNotFoundError` is caught and re-raised as `UnableToStoreCredentialsFile('Unable to store credentials...')` — but this method *reads*, it doesn't store. The error message lies about what failed.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Raise an error indicating a *read* failure, e.g. `UnableToReadCredentialsFile`.
**Category:** domain
**Example:**
```python
except FileNotFoundError:
    raise UnableToStoreCredentialsFile('Unable to store credentials in the credentials file')
    # Actually we were trying to READ, not store.
```

---

### `async` methods perform blocking I/O
**Trigger:** `get_username_and_password`, `_write_credentials_to_file`, and the boto3 `get_authorization_token` call are all synchronous/blocking but invoked inside `async def`. They block the event loop.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Wrap blocking calls with `await asyncio.get_event_loop().run_in_executor(...)` or use `aiofiles` / aioboto3. The `asyncio.Lock` gives a false sense of async correctness.
**Category:** async
**Example:**
```python
async def get_username_and_password(self):
    async with self.lock:
        response = self.session.get_authorization_token(...)  # blocking network call!
        ...
```

---

### `asyncio.Lock` only guards boto3 call, not file write race
**Trigger:** In `AWSTokenManager.login`, `get_username_and_password()` is called twice. Each acquires/releases the lock independently, so two concurrent logins can interleave file writes. The lock does not protect `config.json` from concurrent writers across calls.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Acquire the lock at a higher granularity, or write the file atomically (temp file + rename).
**Category:** thread-safety
**Example:**
```python
auth=await self.get_username_and_password(),  # acquires & releases lock
...
auth=await self.get_username_and_password(),  # acquires & releases again - race window between
```

---

### `get_username_and_password` called twice — double network round-trip
**Trigger:** `AWSTokenManager.login` calls `get_username_and_password()` twice (once for `verify_connection`, once for `MPSSession`). Each call hits AWS ECR and rewrites the file. Tokens may even differ between calls.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Call once, store the result, reuse it.
**Category:** performance
**Example:**
```python
base_url = await verify_connection_to_container_registry(auth=await self.get_username_and_password(), ...)
...
self.session = MPSSession(auth=await self.get_username_and_password(), ...)  # second ECR call
```

---

### AWS `get_username_and_password` returns `None`, not credentials
**Trigger:** The base class version *returns* a tuple. The AWS override writes the file but has no `return` statement, so it returns `None`. Yet `login` passes its result directly as `auth=`.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Make the AWS override return the `(username, password)` tuple.
**Category:** type-system
**Example:**
```python
async def get_username_and_password(self):  # AWS override
    async with self.lock:
        ...
        self._write_credentials_to_file(...)
        # no return -> returns None
# login: auth=await self.get_username_and_password()  -> auth=None
```

---

### `registry_id` slice assumes prefix format
**Trigger:** `self.registry[:12]` assumes the registry string *starts* with the 12-digit account ID. AWS ECR registry URLs are `<acct>.dkr.ecr.<region>.amazonaws.com`, so `[:12]` happens to be the account number — but only if no scheme/prefix exists. Any deviation silently yields a wrong registry ID.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Parse the account ID explicitly (e.g. `registry.split('.')[0]`) and validate it's 12 digits.
**Category:** domain
**Example:**
```python
self.registry_id = self.registry[:12]
# "123456789012.dkr.ecr..." -> "123456789012" OK
# "https://123456789012..." -> "https://1234" wrong!
```

---

### `from mps.api.errors import *` shadows builtins/names
**Trigger:** Wildcard import pulls unknown names into the namespace, risking shadowing and making it impossible to know what's defined. Combined with `os.path` import but using `os.path.expanduser` — fine, but the wildcard is the real hazard.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Import error classes explicitly.
**Category:** type-system
**Example:**
```python
from mps.api.errors import *  # what's in here? could shadow anything
```

---

### `match self.provider` in base `login` rejects `aws`
**Trigger:** Base `TokenManager.login` only handles `azure | local`; default case raises `InvalidRegistryProvider`. But `AWSTokenManager` sets `provider="aws"` and overrides `login`, so base login is never called for AWS — *unless* someone calls `super().login()` or instantiates `TokenManager(provider="aws")` directly, which crashes.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Either implement the `aws` case in base, or document that AWS must use the subclass. The error message mentions "aws" as valid though it's not handled.
**Category:** domain
**Example:**
```python
case "azure" | "local": ...
case _: raise InvalidRegistryProvider('Expected "aws", "azure", ...')  # but aws not handled here
```

---

### `region_name` set twice in AWS subclass
**Trigger:** Base `__init__` sets `self.region_name = None` (region_name defaults to None and isn't passed in super call). Then the subclass sets it again *after* super. Order matters: if any base logic used `region_name`, it'd see `None`.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Pass `region_name` into `super().__init__(...)`.
**Category:** type-system
**Example:**
```python
super().__init__(registry=..., provider="aws")  # region_name -> None in base
self.region_name = region_name  # set afterwards
```

---

### `self.session` reused for two incompatible types
**Trigger:** In `AWSTokenManager`, `self.session` is initially a boto3 ECR client, then `login` reassigns it to an `MPSSession`. After `login()`, calling `get_username_and_password()` again would fail because `self.session.get_authorization_token` no longer exists.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Use separate attributes, e.g. `self.ecr_client` and `self.session`.
**Category:** type-system
**Example:**
```python
self.session = boto3.Session(...).client('ecr')   # in __init__
self.session = MPSSession(...)                     # in login -> overwrites client
# subsequent get_username_and_password() -> AttributeError
```

---

### `get_authorization_token(registryIds=...)` is deprecated
**Trigger:** AWS deprecated the `registryIds` parameter for ECR `GetAuthorizationToken`. It may be ignored or emit warnings; tokens are account-wide regardless.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Call `get_authorization_token()` without `registryIds`.
**Category:** framework
**Example:**
```python
self.session.get_authorization_token(registryIds=[self.registry_id])  # deprecated param
```

---

### `token_data.split(':')` fails if password contains `:`
**Trigger:** `username, password = token_data.split(':')` assumes exactly one colon. AWS ECR tokens are `AWS:<base64password>`, generally safe, but `split(':')` returning >2 parts raises `ValueError` and the unpack fails — caught? No, only `BotoCoreError`/`NoCredentialsError` are caught.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Use `token_data.split(':', 1)`.
**Category:** type-system
**Example:**
```python
username, password = token_data.split(':')  # ValueError if token has 2+ colons
```

---

### `.docker/config.json` overwritten, not merged
**Trigger:** `_write_credentials_to_file` does `json.dump(stored_credentials, fh)`, completely overwriting the user's existing `~/.docker/config.json`, destroying other registry auths and settings.
**Affected Files:** `mps/api/token_manager.py`
**Fix:** Read existing config, merge the `auths` entry, then write back.
**Category:** domain
**Example:**
```python
with open(self.config_filename, 'w') as fh:
    json.dump(stored_credentials, fh)  # nukes existing docker config!
```