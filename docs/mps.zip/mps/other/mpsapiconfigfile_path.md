---
id: c537075b-43cc-5484-a416-55e148109e5d
type: catalog
title: "mps.api.config.file_path"
created_at: 2026-06-06T18:47:27.700102+00:00
updated_at: 2026-07-03T06:16:15.114204+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.file_path"
  signature: "file_path = Path(config_file_path)"
  location: {'line_start': 13, 'line_end': 13, 'col_start': 4, 'col_end': 38}
  parent_qualified_name: "None"
  sha_at_sync: "084190087422fb2c2e5b7145c71edc82da466a16161d69dbd2a9c1792fb1ed83"
  description: "Stores the configuration file location as a `Path` object, converted from the `config_file_path` string for filesystem operations."
---
# mps.api.config.file_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.file_path


variable mps.api.config.file_path [python] /Users/spark/git/service-model-promotion/mps/api/config.py:13-13 :: file_path = Path(config_file_path)

Description: Stores the configuration file location as a `Path` object, converted from the `config_file_path` string for filesystem operations.

## Related Documents

- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.47)
- [mps.api.config.filename](f976f9bc-5eb9-5d4d-b394-48d2d3813036.md) - Related (graph distance 1.47)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.56)
- [mps.api.config.file_paths](7bb669fd-e1bc-5340-9254-1a1dfb2de7ce.md) - Related (graph distance 1.63)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 2.86)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 2.97)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 3.03)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 3.08)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 3.08)
