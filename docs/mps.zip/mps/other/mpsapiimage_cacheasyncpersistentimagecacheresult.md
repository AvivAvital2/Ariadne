---
id: 0682dcc4-e9d8-5858-8035-9f700da35ff0
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.result"
created_at: 2026-06-06T18:47:29.722399+00:00
updated_at: 2026-07-03T06:16:15.125021+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.result"
  signature: "result = await cursor.fetchone()"
  location: {'line_start': 33, 'line_end': 33, 'col_start': 12, 'col_end': 44}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "206a747247b46c73cc82006fcd8decd5a066f20264b653d84a9421c386cc5e1a"
  description: "Retrieves a single row from the executed database query, used to check for or fetch a cached image entry."
---
# mps.api.image_cache.AsyncPersistentImageCache.result

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.result


variable mps.api.image_cache.AsyncPersistentImageCache.result in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:33-33 :: result = await cursor.fetchone()

Description: Retrieves a single row from the executed database query, used to check for or fetch a cached image entry.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.results](34a6adec-7571-5b19-a7f7-6c2158915e2f.md) - Related (graph distance 1.27)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 2.85)
