---
id: 08e04a8e-3314-5ede-8121-f3e782ee37e6
type: catalog
title: "mps.api.utils.command"
created_at: 2026-06-06T18:47:29.299988+00:00
updated_at: 2026-06-20T22:55:23.132656+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.command"
  signature: "command = command.split(" ")"
  location: {'line_start': 28, 'line_end': 28, 'col_start': 8, 'col_end': 36}
  parent_qualified_name: "None"
  sha_at_sync: "d597655f9d9fbc32e20cfdbb69e6970fbe64ebbc7e27d62eabb2380880b2bb7b"
  description: "Splits the `command` string into a list of its space-separated tokens, reassigning the result back to the `command` variable."
---
# mps.api.utils.command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.command


variable mps.api.utils.command [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:28-28 :: command = command.split(" ")

Description: Splits the `command` string into a list of its space-separated tokens, reassigning the result back to the `command` variable.