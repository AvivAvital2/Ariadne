---
id: 08bf5b72-903c-54df-b4b0-ade249fc6655
type: catalog
title: "mps.api.image_manager.ImageManager.inspect_command"
created_at: 2026-06-06T18:47:29.001604+00:00
updated_at: 2026-07-03T06:16:15.008694+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.inspect_command"
  signature: "inspect_command = ("
  location: {'line_start': 241, 'line_end': 244, 'col_start': 16, 'col_end': 17}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6b8bdc8716423225b730737d8c5335a7d9b78ad007d688b2bd0ba2d892919e52"
  description: "Defines the command used to inspect Docker images, returning detailed metadata about a specified image."
---
# mps.api.image_manager.ImageManager.inspect_command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.inspect_command


variable mps.api.image_manager.ImageManager.inspect_command in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:241-244 :: inspect_command = (

Description: Defines the command used to inspect Docker images, returning detailed metadata about a specified image.

## Related Documents

- [mps.api.image_manager.ImageManager.push_command](2b87cf05-a881-5c6d-bf6e-dd63c664e2b8.md) - Related (graph distance 1.42)
- [mps.api.image_manager.ImageManager.build_command](a5945017-a664-5430-9dd0-bbfea34ea71e.md) - Related (graph distance 1.59)
