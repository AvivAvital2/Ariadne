---
id: ae92686e-28c9-5c1f-afcd-c4832e408a6b
type: catalog
title: ".ci.agent-release.spec"
created_at: 2026-06-06T18:47:26.937581+00:00
updated_at: 2026-06-20T22:55:24.762665+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent-release.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent-release.spec"
  signature: "spec:"
  location: {'line_start': 9, 'line_end': 48, 'col_start': 0, 'col_end': 0}
  parent_qualified_name: ".ci.agent-release"
  sha_at_sync: "efcec8494d36d6d615e1e68316f3efa77db480c28c551226e2d318b88623ccba"
  description: "Defines the Kubernetes Pod specification for the agent-release CI job, including container configurations, volumes, and resource settings used during the release process."
---
# .ci.agent-release.spec

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent-release.yaml`

# .ci.agent-release.spec


yaml_key .ci.agent-release.spec in .ci.agent-release [yaml] /Users/spark/git/service-model-promotion/.ci/agent-release.yaml:9-48 :: spec:

Description: Defines the Kubernetes Pod specification for the agent-release CI job, including container configurations, volumes, and resource settings used during the release process.