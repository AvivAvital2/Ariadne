---
id: 6a5a4d99-23ed-5520-9920-f21a72164625
type: catalog
title: "mps.api.errors.InvalidConfigurationFile"
created_at: 2026-06-06T18:47:29.763005+00:00
updated_at: 2026-07-03T06:16:15.103446+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.InvalidConfigurationFile"
  signature: "class InvalidConfigurationFile(ExceptionHandler):"
  location: {'line_start': 34, 'line_end': 37, 'col_start': 0, 'col_end': 63}
  parent_qualified_name: "None"
  sha_at_sync: "f987db46a4fb4de9182e9ebf6039ba0801508689de8aab4d616f8aa430b51dc9"
  description: "Exception handler class that handles errors arising from malformed or invalid configuration files in the MPS API."
---
# mps.api.errors.InvalidConfigurationFile

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidConfigurationFile


class mps.api.errors.InvalidConfigurationFile [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:34-37 :: class InvalidConfigurationFile(ExceptionHandler):

Description: Exception handler class that handles errors arising from malformed or invalid configuration files in the MPS API.

## Related Documents

- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.26)
- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 1.32)
- [mps.api.errors.MissingConfigValues](04edf404-d21e-5354-b2ae-458a08e7e3f2.md) - Related (graph distance 1.35)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.49)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.50)
- [mps.api.errors.InvalidAWSRegion](6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde.md) - Related (graph distance 1.52)
- [mps.api.errors.UnableToStoreCredentialsFile](dd706baa-9f4e-5d89-ab0c-97163e21942b.md) - Related (graph distance 1.54)
- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.60)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.63)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.66)
