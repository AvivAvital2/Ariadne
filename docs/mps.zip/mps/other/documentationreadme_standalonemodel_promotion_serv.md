---
id: ba8531a1-472c-5f54-b0d9-050da55b14a1
type: catalog
title: "documentation.README_standalone.model_promotion_service_mps_production_deployment_guide_standalone_procedure"
created_at: 2026-06-06T18:47:26.281502+00:00
updated_at: 2026-06-06T19:01:08.698992+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.model_promotion_service_mps_production_deployment_guide_standalone_procedure"
  signature: "# Model Promotion Service (MPS) - Production Deployment Guide - Standalone procedure"
  location: {'line_start': 1, 'line_end': 310, 'col_start': 0, 'col_end': 84}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "b979b21a8d8cf1892a6b7bde7df0be0a6c9924231a50c6f045070008d5466108"
  description: "Provides a self-contained, step-by-step procedure for deploying the Model Promotion Service (MPS) to a production environment, covering prerequisites, configuration, and deployment steps."
---
# documentation.README_standalone.model_promotion_service_mps_production_deployment_guide_standalone_procedure

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

md_section documentation.README_standalone.model_promotion_service_mps_production_deployment_guide_standalone_procedure in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:1-310 :: # Model Promotion Service (MPS) - Production Deployment Guide - Standalone procedure

Description: Provides a self-contained, step-by-step procedure for deploying the Model Promotion Service (MPS) to a production environment, covering prerequisites, configuration, and deployment steps.