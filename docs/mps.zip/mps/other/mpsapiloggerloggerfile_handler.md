---
id: 0027aaf8-fb06-5408-8dde-5fe2c7b80061
type: catalog
title: "mps.api.logger.Logger.file_handler"
created_at: 2026-06-06T18:47:28.692735+00:00
updated_at: 2026-07-03T06:16:14.989894+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger.file_handler"
  signature: "file_handler = RotatingFileHandler(log_filename, maxBytes=max_bytes, backupCount=backup_count)"
  location: {'line_start': 32, 'line_end': 32, 'col_start': 8, 'col_end': 102}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "14fac43c28b67e31b5ff3e3b0c10221e48f3753092fdeb90eadd9bc9d7534dcc"
  description: "Creates a rotating file handler that writes log output to a file, automatically rotating to a new file once the current one reaches `max_bytes` in size and retaining up to `backup_count` old log files."
---
# mps.api.logger.Logger.file_handler

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.file_handler


variable mps.api.logger.Logger.file_handler in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:32-32 :: file_handler = RotatingFileHandler(log_filename, maxBytes=max_bytes, backupCount=backup_count)

Description: Creates a rotating file handler that writes log output to a file, automatically rotating to a new file once the current one reaches `max_bytes` in size and retaining up to `backup_count` old log files.

## Related Documents

- [mps.api.logger.Logger.file_formatter](602a21af-d0b0-5b18-939a-1112561f8d98.md) - Related (graph distance 1.53)
- [mps.api.logger.Logger.console_handler](2a3b5941-578c-54de-aa16-2ea79fdfded9.md) - Related (graph distance 1.63)
- [mps.api.logger.Logger.console_formatter](10b77a84-a8e9-5196-8d6b-0fd076b45055.md) - Related (graph distance 2.70)
