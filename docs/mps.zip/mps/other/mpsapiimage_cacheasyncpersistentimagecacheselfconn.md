---
id: b23eeb5a-2004-5f5d-9a28-8bee812c752d
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.self.conn"
created_at: 2026-06-06T18:47:29.721881+00:00
updated_at: 2026-07-03T06:16:15.024447+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.self.conn"
  signature: "self.conn = await aiosqlite.connect(self.db_path)"
  location: {'line_start': 14, 'line_end': 14, 'col_start': 8, 'col_end': 57}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "0941417f13a83e77a6121fdd30d5f9dc1ee9a4c0376cb319b7b46ee25f99d876"
  description: "Establishes an asynchronous SQLite database connection to the cache's configured database path, storing it as an instance attribute for persistent image cache operations."
---
# mps.api.image_cache.AsyncPersistentImageCache.self.conn

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.self.conn


variable mps.api.image_cache.AsyncPersistentImageCache.self.conn in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:14-14 :: self.conn = await aiosqlite.connect(self.db_path)

Description: Establishes an asynchronous SQLite database connection to the cache's configured database path, storing it as an instance attribute for persistent image cache operations.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 1.39)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.51)
- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 1.53)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 2.78)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.90)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 2.99)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 3.00)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 3.02)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 3.04)
