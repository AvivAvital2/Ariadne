---
id: 7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8
type: catalog
title: "mps.api.config.image_cache_path"
created_at: 2026-06-06T18:47:27.702022+00:00
updated_at: 2026-07-03T06:16:15.122838+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.image_cache_path"
  signature: "image_cache_path = config['local_image_cache']['path']"
  location: {'line_start': 39, 'line_end': 39, 'col_start': 0, 'col_end': 54}
  parent_qualified_name: "None"
  sha_at_sync: "4c0c3ae0caf6e1690379bf906f67c6f6882f1272e6ca6ec26eb10e11ff37bb81"
  description: "Stores the filesystem path to the local image cache directory, retrieved from the application's configuration under the `local_image_cache` settings."
---
# mps.api.config.image_cache_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.image_cache_path


variable mps.api.config.image_cache_path [python] /Users/spark/git/service-model-promotion/mps/api/config.py:39-39 :: image_cache_path = config['local_image_cache']['path']

Description: Stores the filesystem path to the local image cache directory, retrieved from the application's configuration under the `local_image_cache` settings.

## Related Documents

- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.27)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 1.39)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.51)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 1.61)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 1.61)
- [mps.api.image_cache.AsyncPersistentImageCache.self.conn](b23eeb5a-2004-5f5d-9a28-8bee812c752d.md) - Related (graph distance 2.78)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 2.79)
- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 2.80)
