---
id: 45cb5036-88de-52b9-acec-417964547495
type: catalog
title: "mps.api.token_manager.AWSTokenManager.get_username_and_password"
created_at: 2026-06-06T18:47:28.314847+00:00
updated_at: 2026-07-03T06:16:15.086222+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.AWSTokenManager.get_username_and_password"
  signature: "async def get_username_and_password(self):"
  location: {'line_start': 132, 'line_end': 151, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "3ea4d786f6d05e9ec70017ec14b426ca04f98b316a209410d86898685ac811a6"
  description: "Asynchronously retrieves and returns the username and password credentials for AWS authentication, refreshing the token if it has expired."
---
# mps.api.token_manager.AWSTokenManager.get_username_and_password

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.get_username_and_password


method mps.api.token_manager.AWSTokenManager.get_username_and_password in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:132-151 :: async def get_username_and_password(self):

Description: Asynchronously retrieves and returns the username and password credentials for AWS authentication, refreshing the token if it has expired.

## Related Documents

- [mps.api.token_manager.TokenManager.get_username_and_password](352275c9-9866-54cf-91e4-d353f05e204e.md) - Related (graph distance 1.26)
- [mps.api.token_manager.AWSTokenManager.login](902a7ee2-9f46-53a1-8f0d-766ceb4c012a.md) - Related (graph distance 1.55)
- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 1.65)
- [mps.api.token_manager.TokenManager.login](f6c5822f-baca-5af9-b88e-a1a3b0d25885.md) - Related (graph distance 2.79)
- [mps.api.image_manager.ImageManager.login](04480485-a32b-5214-b53a-765a9c9a5dda.md) - Related (graph distance 3.01)
- [mps.api.token_manager.TokenManager.stored_credentials](6118c04d-ef3d-537e-a04b-20a6f6cf3f21.md) - Related (graph distance 3.21)
- [mps.api.token_manager.AWSTokenManager.__init__](57f392dc-511c-5b35-a6a9-d2ca1b3fb86e.md) - Related (graph distance 3.28)
