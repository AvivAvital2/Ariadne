---
id: d5288d92-39d5-5b40-993d-21eea4d39f9a
type: catalog
title: "mps.routers.promote.auxiliary_image_string"
created_at: 2026-06-06T18:47:27.627086+00:00
updated_at: 2026-07-03T06:16:15.074433+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.auxiliary_image_string"
  signature: "auxiliary_image_string = request_obj.headers.get('auxImages', None)"
  location: {'line_start': 64, 'line_end': 64, 'col_start': 4, 'col_end': 71}
  parent_qualified_name: "None"
  sha_at_sync: "16f62ad260b65c4df47d87982efba49285ff2a379faf232f206a076f043bd2e5"
  description: "Retrieves the value of the 'auxImages' HTTP request header, defaulting to None if the header is absent."
---
# mps.routers.promote.auxiliary_image_string

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.auxiliary_image_string


variable mps.routers.promote.auxiliary_image_string [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:64-64 :: auxiliary_image_string = request_obj.headers.get('auxImages', None)

Description: Retrieves the value of the 'auxImages' HTTP request header, defaulting to None if the header is absent.

## Related Documents

- [mps.routers.promote.annotations_string](308debdb-7c0b-525f-bd1f-94f84cd280e5.md) - Related (graph distance 1.42)
- [mps.routers.promote.auxiliary_image_list](e555d1cb-61ea-523a-8284-a3b7183d411a.md) - Related (graph distance 1.44)
- [mps.routers.promote.algorithm_string](b6417c2f-d7af-5ccf-8a65-d93929bed909.md) - Related (graph distance 1.47)
- [mps.routers.promote.annotations_list](9fb04024-1a86-548a-ad1a-d71b488cd891.md) - Related (graph distance 2.93)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 3.05)
