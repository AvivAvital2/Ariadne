---
id: e1aab0fd-640c-5a60-b51a-712975fb76f5
type: catalog
title: "docker-compose.services"
created_at: 2026-06-06T18:47:25.530805+00:00
updated_at: 2026-06-20T22:55:23.145752+00:00
source_files:
  - /Users/spark/git/service-model-promotion/docker-compose.yml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: "docker-compose.services"
  signature: "services:"
  location: {'line_start': 4, 'line_end': 49, 'col_start': 0, 'col_end': 38}
  parent_qualified_name: "docker-compose"
  sha_at_sync: "c2f3ce5e50702a5b408ccdd208a271e3f37394d235f6d5072a935fd91757194f"
  description: "Defines the collection of containerized application services and their configurations (images, ports, volumes, networks, dependencies) that Docker Compose orchestrates as a unified application stack."
---
# docker-compose.services

**Related files:**
- `/Users/spark/git/service-model-promotion/docker-compose.yml`

# docker-compose.services


yaml_key docker-compose.services in docker-compose [yaml] /Users/spark/git/service-model-promotion/docker-compose.yml:4-49 :: services:

Description: Defines the collection of containerized application services and their configurations (images, ports, volumes, networks, dependencies) that Docker Compose orchestrates as a unified application stack.