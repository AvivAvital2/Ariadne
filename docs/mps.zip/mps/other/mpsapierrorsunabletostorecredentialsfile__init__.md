---
id: 57785d64-9769-5883-8802-f6c54486e5b3
type: catalog
title: "mps.api.errors.UnableToStoreCredentialsFile.__init__"
created_at: 2026-06-06T18:47:29.761728+00:00
updated_at: 2026-07-03T06:16:15.048895+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnableToStoreCredentialsFile.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 87, 'line_end': 88, 'col_start': 4, 'col_end': 67}
  parent_qualified_name: "mps.api.errors.UnableToStoreCredentialsFile"
  sha_at_sync: "e77caf62ccae044042b59bdd191b927f0576823123ef7243bc2eb32cbc48bd34"
  description: "Initializes the `UnableToStoreCredentialsFile` exception with a custom error message describing why the credentials file could not be stored."
---
# mps.api.errors.UnableToStoreCredentialsFile.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToStoreCredentialsFile.__init__


method mps.api.errors.UnableToStoreCredentialsFile.__init__ in mps.api.errors.UnableToStoreCredentialsFile [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:87-88 :: def __init__(self, message: str):

Description: Initializes the `UnableToStoreCredentialsFile` exception with a custom error message describing why the credentials file could not be stored.

## Related Documents

- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.19)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.22)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 1.23)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.24)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.24)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.25)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.27)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.27)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.27)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.29)
