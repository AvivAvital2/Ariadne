---
id: ba539c01-6752-5e6d-83d2-b5bf0230790f
type: catalog
title: "mps.api.image_manager.ImageManager.compression_command"
created_at: 2026-06-06T18:47:28.998674+00:00
updated_at: 2026-06-20T22:55:26.360988+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.compression_command"
  signature: "compression_command = f"/usr/bin/pigz {abs_file_path}"
  location: {'line_start': 122, 'line_end': 122, 'col_start': 12, 'col_end': 66}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "5bffae533bd1844be9cd3a1d7a87dcd0bdf669a695bd28ddd2aefb3cd2ffec5d"
  description: "Constructs the shell command string to compress a file using `pigz` (parallel gzip), interpolating the file's absolute path."
---
# mps.api.image_manager.ImageManager.compression_command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.compression_command


variable mps.api.image_manager.ImageManager.compression_command in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:122-122 :: compression_command = f"/usr/bin/pigz {abs_file_path}"

Description: Constructs the shell command string to compress a file using `pigz` (parallel gzip), interpolating the file's absolute path.