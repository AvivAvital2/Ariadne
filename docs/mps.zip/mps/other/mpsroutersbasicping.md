---
id: ffe04ad5-9672-54db-b9e9-915dd50c5054
type: catalog
title: "mps.routers.basic.ping"
created_at: 2026-06-06T18:47:27.474265+00:00
updated_at: 2026-06-20T22:55:26.433239+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.basic.ping"
  signature: "async def ping():"
  location: {'line_start': 23, 'line_end': 24, 'col_start': 0, 'col_end': 36}
  parent_qualified_name: "None"
  sha_at_sync: "c99cbe170363aa45f60bf8da5c75ebb973ded5ba056d3aab5ded78d2188d46ab"
  description: "Async HTTP endpoint handler that returns a health-check response confirming the service is alive."
---
# mps.routers.basic.ping

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# mps.routers.basic.ping


async_function mps.routers.basic.ping [python] /Users/spark/git/service-model-promotion/mps/routers/basic.py:23-24 :: async def ping():

Description: Async HTTP endpoint handler that returns a health-check response confirming the service is alive.