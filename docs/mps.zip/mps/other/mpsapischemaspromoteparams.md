---
id: 9ea275a3-490e-5840-8aee-0dbaa9afddef
type: catalog
title: "mps.api.schemas.PromoteParams"
created_at: 2026-06-06T18:47:28.911399+00:00
updated_at: 2026-07-03T06:16:15.027237+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.PromoteParams"
  signature: "class PromoteParams:"
  location: {'line_start': 24, 'line_end': 29, 'col_start': 0, 'col_end': 31}
  parent_qualified_name: "None"
  sha_at_sync: "bd25282715e26fa28650dcd6db7826ee36e6c9ca2c7cece19011e642a8c6842a"
  description: "Defines the parameters required for a promote operation, serving as a structured data schema for promotion-related requests."
---
# mps.api.schemas.PromoteParams

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams


class mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:24-29 :: class PromoteParams:

Description: Defines the parameters required for a promote operation, serving as a structured data schema for promotion-related requests.

## Related Documents

- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 1.41)
- [mps.routers.promote.params](20f2f1b0-87b3-54f2-9129-6e162bce858c.md) - Related (graph distance 1.42)
- [mps.routers.promote.schema](db1a5046-6f29-597a-b23f-35ecea9392a9.md) - Related (graph distance 1.49)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 1.66)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 2.81)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 2.81)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 3.01)
- [mps.routers.promote.params_dict](4fcf3f76-7581-5b3b-b87a-d871ed2d60d5.md) - Related (graph distance 3.04)
- [mps.__main__.app](852e4e9d-3828-5d3a-aa74-fc747bc19fb5.md) - Related (graph distance 3.14)
