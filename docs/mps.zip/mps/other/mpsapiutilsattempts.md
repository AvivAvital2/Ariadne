---
id: 80159dc7-9f18-5376-a0cd-8a19ce08e418
type: catalog
title: "mps.api.utils.attempts"
created_at: 2026-06-06T18:47:29.302623+00:00
updated_at: 2026-06-20T22:55:24.648005+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.attempts"
  signature: "attempts = 30"
  location: {'line_start': 129, 'line_end': 129, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "None"
  sha_at_sync: "dc1ab44c73153c31cacebf3490ef5ddaa95c91aadd8f79690cc1210102f08d3c"
  description: "Defines the maximum number of retry attempts (30) used when polling or retrying an operation in the MPS API utilities module."
---
# mps.api.utils.attempts

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.attempts


variable mps.api.utils.attempts [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:129-129 :: attempts = 30

Description: Defines the maximum number of retry attempts (30) used when polling or retrying an operation in the MPS API utilities module.