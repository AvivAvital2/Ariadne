---
id: c102b626-fa79-565e-a225-3b801d2a0446
type: catalog
title: "mps.__main__.params['docs_url']"
created_at: 2026-06-06T18:47:26.710095+00:00
updated_at: 2026-07-03T06:16:15.081685+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.params['docs_url']"
  signature: "params['docs_url'] = '/modelpromotion/docs'"
  location: {'line_start': 19, 'line_end': 19, 'col_start': 4, 'col_end': 47}
  parent_qualified_name: "None"
  sha_at_sync: "64f10fd1cbb196c9ea95fc72a058f4d88f106b9b118c0b7fa9478b06c146afd4"
  description: "Sets the URL path where the FastAPI application's interactive API documentation (Swagger UI) is served to `/modelpromotion/docs`."
---
# mps.__main__.params['docs_url']

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.params['docs_url']


variable mps.__main__.params['docs_url'] [python] /Users/spark/git/service-model-promotion/mps/__main__.py:19-19 :: params['docs_url'] = '/modelpromotion/docs'

Description: Sets the URL path where the FastAPI application's interactive API documentation (Swagger UI) is served to `/modelpromotion/docs`.

## Related Documents

- [mps.__main__.params['redoc_url']](81f9b823-8008-505b-b641-941f04948346.md) - Related (graph distance 1.28)
- [mps.__main__.params['openapi_url']](3b58a546-63fd-5121-81ee-76772aeb10e1.md) - Related (graph distance 1.29)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 1.67)
- [mps.__main__.app](852e4e9d-3828-5d3a-aa74-fc747bc19fb5.md) - Related (graph distance 2.94)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 3.33)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 3.33)
