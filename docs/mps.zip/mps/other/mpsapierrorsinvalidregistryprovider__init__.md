---
id: b4a936e2-2578-5fd5-9872-794ec6914cb1
type: catalog
title: "mps.api.errors.InvalidRegistryProvider.__init__"
created_at: 2026-06-06T18:47:29.759935+00:00
updated_at: 2026-07-03T06:16:15.041670+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.InvalidRegistryProvider.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 47, 'line_end': 48, 'col_start': 4, 'col_end': 62}
  parent_qualified_name: "mps.api.errors.InvalidRegistryProvider"
  sha_at_sync: "e26a8fa22c252376b420757d4e4fd4f618ac027a0e8702194e9843b79c6b94b8"
  description: "Initializes an `InvalidRegistryProvider` exception with the provided error message string."
---
# mps.api.errors.InvalidRegistryProvider.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidRegistryProvider.__init__


method mps.api.errors.InvalidRegistryProvider.__init__ in mps.api.errors.InvalidRegistryProvider [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:47-48 :: def __init__(self, message: str):

Description: Initializes an `InvalidRegistryProvider` exception with the provided error message string.

## Related Documents

- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.22)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.22)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.23)
- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 1.26)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.28)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.31)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.32)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.42)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.37)
