---
id: d5a60bed-4825-5b07-b00c-3bdb9cfac66e
type: gotcha
title: "Dockerfile Gotchas"
created_at: 2026-07-03T05:57:46.458417+00:00
updated_at: 2026-07-03T05:57:46.458428+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/builder/Dockerfile`

# Dockerfile Gotchas and Pitfalls

### Pinned Base Image via Mutable Registry
**Trigger:** The `FROM` line references an ECR image tagged `20200615-2`. While tagged, ECR tags are mutable — someone can overwrite this tag, silently changing your base image without any Dockerfile change.
**Affected Files:** `stage0.Dockerfile` (line 1)
**Fix:** Pin by immutable digest (`@sha256:...`) rather than by tag for reproducible builds.
**Category:** framework
**Example:**
```dockerfile
# Fragile - tag can be re-pushed:
FROM 551806661322.dkr.ecr.eu-west-1.amazonaws.com/prediction-server/builder:20200615-2
# Robust:
FROM 551806661322.dkr.ecr.eu-west-1.amazonaws.com/prediction-server/builder@sha256:abc123...
```

---

### Silent Failure via `|| :` Swallows WordNet Setup Errors
**Trigger:** The WordNet RUN block ends with `|| :`, which forces the whole compound command to succeed even if `curl`, `rpm2cpio`, `mv`, or `chgrp` fail. A broken WordNet install produces a "successful" image that fails at runtime.
**Affected Files:** `stage0.Dockerfile` (WordNet RUN block)
**Fix:** Remove `|| :` or scope it only to the idempotency guard. Verify the target directory exists after the copy.
**Category:** framework
**Example:**
```dockerfile
# Any failure here is masked:
RUN /bin/sh -c "[ ! -d /opt/.../WordNet-3.0/ ]" && ... && rm -rf $(pwd) && popd || :
# The leading [ ! -d ] guard failing → whole line silently exits 0 with nothing done.
```

---

### `pushd`/`popd` Are Bash Builtins, Not POSIX sh
**Trigger:** The command runs under `/bin/sh -c` but uses `pushd`/`popd`, which are bash-only. If `/bin/sh` is dash or a minimal shell, these fail — and combined with `|| :`, the failure is masked, leaving `$(pwd)` pointing somewhere unexpected during `rm -rf $(pwd)`.
**Affected Files:** `stage0.Dockerfile` (WordNet RUN block)
**Fix:** Use `cd` explicitly, or invoke `bash -c`. Never `rm -rf $(pwd)` after an uncertain `cd`.
**Category:** framework
**Example:**
```dockerfile
# If pushd fails silently, pwd is still the build root:
&& rm -rf $(pwd)   # potentially deletes the wrong directory
```

---

### `rm -rf $(pwd)` Before `popd`
**Trigger:** `rm -rf $(pwd)` removes the current working directory, then `popd` is called — operating from a now-deleted directory. This produces "getcwd: cannot access parent directories" errors and can behave unpredictably.
**Affected Files:** `stage0.Dockerfile` (WordNet RUN block)
**Fix:** `popd` first (return to a valid dir), *then* `rm -rf /tmp/wordnet-fix`.
**Category:** framework
**Example:**
```dockerfile
&& rm -rf $(pwd) \
&& popd > /dev/null || :   # popd runs after cwd deleted → error
```

---

### Unpinned Package Versions Break Reproducibility
**Trigger:** `yum install -y git`, `libgomp`, `deltarpm`, `awscli`, and the wildcard `sparkbeyond-embedded-python3-${EMBEDDED_PYTHON3_VERSION}*` install whatever the repo currently offers. Two builds from the same Dockerfile can yield different binaries.
**Affected Files:** `stage0.Dockerfile` (multiple RUN yum blocks)
**Fix:** Pin exact versions (`git-2.x.y`). Be aware the `*` glob on python3 matches any patch/build suffix.
**Category:** framework
**Example:**
```dockerfile
# Wildcard silently picks a different build:
sparkbeyond-embedded-python3-${EMBEDDED_PYTHON3_VERSION}*
```

---

### `echo $'...'` Depends on Shell that Supports ANSI-C Quoting
**Trigger:** The `~/.sbt/repositories` file is written with `echo $'...\n...'`. `$'...'` is bash/ksh-specific. Under `/bin/sh` (dash), `$'\n'` is not interpreted and you get literal `$'...\n...'` text written to the file, silently corrupting the SBT repository config.
**Affected Files:** `stage0.Dockerfile` (last RUN block)
**Fix:** Use `printf` for portable escapes, or explicitly `RUN bash -c "..."`. Verify the resulting file contents.
**Category:** framework
**Example:**
```dockerfile
# Under dash, this writes literal backslash-n, not newlines:
RUN /bin/sh -c "echo $'[repositories]\n local\n...' > ~/.sbt/repositories"
```

---

### `~` in RUN Resolves to Root's HOME at Build Time Only
**Trigger:** `mkdir -p ~/.sbt` and the repositories file are created in root's home. At runtime the container may run as a different user (`sparkbeyond` group is referenced), and SBT won't find its config in that user's `$HOME`.
**Affected Files:** `stage0.Dockerfile` (SBT config RUN blocks)
**Fix:** Write to an absolute path and/or the intended runtime user's home. Set `HOME` explicitly.
**Category:** framework
**Example:**
```dockerfile
RUN mkdir -p ~/.sbt   # ~ = /root; broken if container runs as non-root
```

---

### Layer Cache Traps: Downloads Never Re-Fetched
**Trigger:** `curl` of Docker, helm, kubectl, and RPMs are cached as image layers. If an upstream URL changes content but keeps the same version string, Docker reuses the stale layer. Conversely, `yum install -y git` in a separate RUN is cached even after a security update lands.
**Affected Files:** `stage0.Dockerfile` (all curl/yum RUN blocks)
**Fix:** Combine invalidation-sensitive steps, use checksums (`echo "<sha> file" | sha256sum -c`), and pin digests.
**Category:** performance
**Example:**
```dockerfile
RUN curl -fsSL "https://get.helm.sh/helm-v${HELM_VERSION}-linux-amd64.tar.gz" | tar ...
# No checksum verification → MITM or upstream change goes undetected
```

---

### Piped `curl | tar` Hides HTTP Errors
**Trigger:** `curl -fsSL ... | tar xzf -` — with a pipe, `tar`'s exit code is what the shell sees (unless `pipefail` is set). A failed curl (e.g., 404) may still let `tar` "succeed" on empty/garbage input, and there's no `set -o pipefail` under `/bin/sh -c`.
**Affected Files:** `stage0.Dockerfile` (docker, helm curl-tar pipes)
**Fix:** Add `set -euo pipefail` (bash) or download-then-verify-then-extract in separate steps.
**Category:** framework
**Example:**
```dockerfile
RUN /bin/sh -c "curl -fsSL https://get.helm.sh/... | tar xzf - ..."
# curl fails → pipe still returns tar's status → build may pass
```

---

### `alternatives` Priority `1` Is Fragile
**Trigger:** `alternatives --install /usr/bin/java java <path> 1` uses priority 1 — the lowest. If any other package registers a higher-priority `java`, the corretto JDK is silently not selected in auto mode, and builds pick an unexpected JVM.
**Affected Files:** `stage0.Dockerfile` (alternatives RUN)
**Fix:** Use a high priority and/or `alternatives --set java <path>` to force the choice.
**Category:** framework
**Example:**
```dockerfile
RUN alternatives --install /usr/bin/java java /opt/.../bin/java 1  # priority 1 = easily overridden
```

---

### Mixing Nexus Hosts Creates Hidden Availability Coupling
**Trigger:** The SBT repositories file mixes `nexus.dev.sparkbeyond.ai` (dev) and `nexus.sparkbeyond.com` (prod-ish). If the dev Nexus is down/rotated, resolution fails at build time with confusing errors.
**Affected Files:** `stage0.Dockerfile` (repositories config + all yum-config-manager URLs)
**Fix:** Consolidate on one artifact source or make fallbacks explicit and monitored.
**Category:** domain
**Example:**
```
sparkbeyond-ivy-proxy-releases: https://nexus.dev.sparkbeyond.ai/...
sparkbeyond-mvn-proxy-releases: https://nexus.sparkbeyond.com/...   # different host
```

---

### `chgrp` Assumes `sparkbeyond` Group Exists
**Trigger:** `chgrp -R sparkbeyond /opt/.../WordNet-3.0/` presumes the group was created by an earlier RPM. If layer ordering changes or that RPM is removed, `chgrp` fails — but `|| :` masks it, leaving files with wrong ownership.
**Affected Files:** `stage0.Dockerfile` (WordNet RUN block)
**Fix:** Verify the group exists (`getent group sparkbeyond`) before chgrp; remove the error-masking.
**Category:** framework
**Example:**
```dockerfile
&& chgrp -R sparkbeyond /opt/.../WordNet-3.0/   # fails if group missing, masked by || :
```

---

### `uname` Locks Build to Host Architecture
**Trigger:** docker-compose URL uses `$(uname -s)-$(uname -m)`. On a cross-build (buildx for arm64) this resolves to the *build host* arch, potentially pulling the wrong binary while other tools hardcode `amd64`/`x86_64`.
**Affected Files:** `stage0.Dockerfile` (docker-compose curl)
**Fix:** Use `TARGETARCH`/`TARGETOS` build args from BuildKit instead of `uname`.
**Category:** framework
**Example:**
```dockerfile
docker-compose-$(uname -s)-$(uname -m)   # host arch, not target arch
```

---

### Excessive RUN Layers Bloat Image
**Trigger:** Many single-command RUN lines (helm, kubectl, mkdir, echo) each create a separate layer, and cleanup of `/var/cache/yum` in a *later* layer doesn't reduce the size committed by an *earlier* layer.
**Affected Files:** `stage0.Dockerfile` (all RUN blocks)
**Fix:** Merge related commands into one RUN, doing install + cleanup within the same layer.
**Category:** performance
**Example:**
```dockerfile
RUN yum install -y ...       # cache written to this layer
RUN rm -rf /var/cache/yum    # too late: previous layer already committed the cache
```

Note: within a single `&&` chain the cleanup does help — but the split kubectl/helm/mkdir RUNs above show the anti-pattern where cleanup is not co-located.