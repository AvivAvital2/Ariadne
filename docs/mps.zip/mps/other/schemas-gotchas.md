---
id: 67e27560-131e-5277-aec4-5bd34812dfac
type: gotcha
title: "Schemas Gotchas"
created_at: 2026-06-06T19:03:55.033728+00:00
updated_at: 2026-06-20T22:55:25.453804+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  module_name: "mps.api.schemas"
  language: "python"
  source_name: "mps"
---
# Schemas Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# Schemas Gotchas


# Gotchas and Pitfalls: `mps.api.schemas`

### `post_load` references wrong key
**Trigger:** `BaseImages.make_versions_dict` reads/writes `data['versions']`, but the dataclass field is named `images` (typed as `Flavours`). The key `'versions'` never exists in the deserialized data, so this raises `KeyError` at load time.
**Affected Files:** `mps/api/schemas.py` (`BaseImages`)
**Fix:** Reference the actual field (`data['images']`) or rename the field. Also guard with `data.get(...)`.
**Category:** framework
**Example:**
```python
@post_load
def make_versions_dict(self, data, **kwargs):
    # data has 'images', not 'versions' -> KeyError
    data['versions'] = {...}
```

---

### `post_load` iterates a dataclass instance, not a dict
**Trigger:** With `marshmallow_dataclass`, by default `post_load` may receive the constructed dataclass object, not a plain dict. `data['versions']` subscripting and tuple-unpacking iteration (`for version, version_data in data['versions']`) assumes a dict of `(str, value)` pairs — but iterating a dict yields keys only, not pairs. You'd need `.items()`.
**Affected Files:** `mps/api/schemas.py` (`BaseImages`)
**Fix:** Iterate with `.items()`, and confirm whether the hook gets a dict or instance (set `meta.ordered`/check `Schema` config). Don't mutate via item assignment on a frozen/dataclass object.
**Category:** framework
**Example:**
```python
for version, version_data in data['versions'].items():  # need .items()
    ...
```

---

### `__post_init__` is bypassed by marshmallow_dataclass deserialization
**Trigger:** `AuxiliaryImages.__post_init__` expects `images_str` to be an iterable of `"key:value"` strings, but the field is typed `str` (a single string). Iterating a `str` yields individual **characters**, so `item.split(':')` runs per character — producing garbage `AuxiliaryImage` objects.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`)
**Fix:** Type the field as `list[str]` if it's a list of entries; rename to reflect plural. Note marshmallow_dataclass may not invoke `__post_init__` reliably during `load()` (it constructs via schema) — prefer a `@post_load` hook for validation/transform.
**Category:** type-system
**Example:**
```python
AuxiliaryImages(images_str="a:1")  # iterates "a", ":", "1" individually
```

---

### `AuxiliaryImage(parts)` passes a list as the `image` string
**Trigger:** In the `case 1` branch, `parts` is a **list** (`['foo']`), so `AuxiliaryImage(parts)` sets `image=['foo']` instead of `image='foo'`. The type annotation `image: str` provides no runtime enforcement.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`, `AuxiliaryImage`)
**Fix:** Use `AuxiliaryImage(parts[0])`.
**Category:** type-system
**Example:**
```python
case 1: self.images.append(AuxiliaryImage(parts[0]))  # not parts
```

---

### `images`/`versions` attributes are not declared fields
**Trigger:** `AuxiliaryImages.images` and the dict `data['versions']` are set imperatively but aren't part of the dataclass schema. They won't be serialized, validated, or recognized by marshmallow, and may collide with schema-generated `__init__`/slots behavior.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`, `BaseImages`)
**Fix:** Declare derived fields explicitly with `field(init=False)` or compute in a proper `@post_load`/`@post_dump` hook returning the full structure.
**Category:** framework
**Example:**
```python
images: list[AuxiliaryImage] = field(init=False, default_factory=list)
```

---

### `raise ... from None` swallows the real cause
**Trigger:** `raise ValidationError(...) from None` suppresses the chained exception context, making debugging of malformed input harder. Also `ValidationError` raised inside `__post_init__` (not a marshmallow hook) won't be aggregated into marshmallow's normal error dict.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`)
**Fix:** Raise `ValidationError` inside a `@validates`/`@post_load` hook so marshmallow formats it correctly; drop `from None` unless intentional.
**Category:** framework
**Example:**
```python
# In __post_init__, marshmallow can't catch/format this as a field error.
raise ValidationError('Invalid format...')  # leaks as raw exception
```

---

### Snake_case vs camelCase field naming inconsistency
**Trigger:** `PromoteParams` uses camelCase (`epsReleaseNumber`, `dockerCompose`) while `ImageParams`/`AuxiliaryImages` use snake_case. Marshmallow loads by exact field name by default — JSON payloads must match exactly, and the inconsistency invites silent missing-field bugs (camelCase keys won't populate snake_case fields and vice versa).
**Affected Files:** `mps/api/schemas.py` (all)
**Fix:** Standardize naming and/or use `data_key`/`fields.Field(data_key=...)` to map external names; enable `Meta.unknown = RAISE` to catch typos.
**Category:** framework
**Example:**
```python
# Payload {"eps_release_number": "1"} silently leaves epsReleaseNumber unset/required-error
```

---

### Bool defaults make every flag silently optional
**Trigger:** All `PromoteParams` flags default to `False`. Omitted keys silently become `False` — there's no way to distinguish "not provided" from "explicitly false", which can mask client bugs.
**Affected Files:** `mps/api/schemas.py` (`PromoteParams`)
**Fix:** If the distinction matters, make them `Optional[bool] = None`, or set `Meta.unknown = RAISE` to surface unexpected keys.
**Category:** type-system
**Example:**
```python
PromoteParams(epsReleaseNumber="1")  # dockerCompose=False silently
```

---

### `match` statement requires Python 3.10+
**Trigger:** The `match len(parts):` syntax fails to even import on Python ≤3.9 with a `SyntaxError`, breaking the whole module regardless of which class is used.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`)
**Fix:** Ensure runtime is 3.10+, or replace with `if/elif`.
**Category:** framework
**Example:**
```python
match len(parts):  # SyntaxError on 3.9
```

---

### Mutable instance state defeats schema-level thread safety
**Trigger:** `AuxiliaryImages` builds `self.images` mutably in `__post_init__`. If a single schema/instance is cached and reused across requests (common in web frameworks), the imperative mutation and shared `[]` patterns can cause cross-request bleed.
**Affected Files:** `mps/api/schemas.py` (`AuxiliaryImages`)
**Fix:** Keep schemas stateless; produce a fresh deserialized object per `load()` and avoid mutating shared instances.
**Category:** thread-safety
**Example:**
```python
schema = AuxiliaryImages.Schema()  # if reused, ensure load() returns fresh objects
```