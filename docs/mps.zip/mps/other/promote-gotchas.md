---
id: 767ae70f-23cb-577e-89ed-063e88e743b5
type: gotcha
title: "Promote Gotchas"
created_at: 2026-06-06T19:04:34.338706+00:00
updated_at: 2026-06-20T22:55:24.559013+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  module_name: "mps.routers.promote"
  language: "python"
  source_name: "mps"
---
# Promote Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# Promote Gotchas


# Gotchas and Pitfalls: `mps.routers.promote`

### Fragile URL query string parsing
**Trigger:** Manually splitting the URL on `"?"` to extract query params instead of using FastAPI's built-in dependency injection or `request_obj.query_params`.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Use `request_obj.query_params` (a `QueryParams` multidict) or declare a Pydantic/dataclass model as a FastAPI dependency. The `str(url).split("?")[-1]` returns the *entire URL* if there is no `?`, causing `parse_qs` to silently produce an empty dict and `schema.load` to receive defaults/raise.
**Category:** framework
**Example:**
```python
# If URL has no '?', split returns the whole URL string:
str("http://x/promote/p/r").split("?")[-1]
# => "http://x/promote/p/r"  -> parse_qs(...) == {} (silent, wrong)
```

---

### `parse_qs` drops empty values silently
**Trigger:** `parse_qs` by default discards keys with blank values (`keep_blank_values=False`). A param sent as `?dockerCompose=` simply vanishes.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Pass `keep_blank_values=True` if blanks are meaningful, or use a typed schema with explicit defaults.
**Category:** type-system
**Example:**
```python
parse_qs("dockerCompose=&a=1")  # => {'a': ['1']}  -- dockerCompose lost
```

---

### List vs scalar collapse based on count
**Trigger:** The dict comprehension collapses single-element lists to scalars: `value[0] if len(value) == 1 else value`. A param legitimately meant to be a list-of-one becomes a string; a repeated param stays a list. Downstream schema typing is non-deterministic based on request shape.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Let the schema/loader handle multi-values explicitly, or always pass lists and coerce in the schema.
**Category:** type-system
**Example:**
```python
# ?tags=a        -> {'tags': 'a'}      (str)
# ?tags=a&tags=b -> {'tags': ['a','b']}(list)  inconsistent type!
```

---

### Type confusion: `image` can be a `PlainTextResponse` or a string
**Trigger:** `build_and_push` returns either a `PlainTextResponse` (error path) or a string path. The non-`export` branch does `f"{image}"`, which stringifies a `PlainTextResponse` object into garbage if an error response slips through.
**Affected Files:** `mps/routers/promote.py` (`promote`), `mps.image_manager.build_and_push`
**Fix:** Have `build_and_push` raise on error, or check `isinstance(image, PlainTextResponse)` in *all* branches, not just `export`.
**Category:** type-system
**Example:**
```python
# registry_provider != 'export' and image is a PlainTextResponse:
return PlainTextResponse(content=f"{image}")
# => content like "<starlette.responses.PlainTextResponse object at 0x...>"
```

---

### Whole request body loaded into memory
**Trigger:** `await request_obj.body()` reads the entire uploaded model.zip into RAM before writing. For large model archives this can OOM the worker.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Stream the body with `request_obj.stream()` and write chunks incrementally to the aiofiles handle.
**Category:** performance
**Example:**
```python
async with aiofiles.open(file_path, 'wb') as f:
    async for chunk in request_obj.stream():
        await f.write(chunk)
```

---

### Hardcoded vs parameterized filename mismatch
**Trigger:** `model_filename = 'model.zip'` is defined, but the file path is built with a *literal* `'model.zip'` (`os.path.join(dir_name, 'model.zip')`) rather than the variable. They happen to match now, but changing the variable won't change the written file.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Use `os.path.join(dir_name, model_filename)`.
**Category:** domain
**Example:**
```python
model_filename = 'model.tar'           # changed
file_path = os.path.join(dir_name, 'model.zip')  # still writes model.zip!
```

---

### Unvalidated JSON header crashes the endpoint
**Trigger:** `json.loads(annotations_string)` on the `X-ANNOTATIONS` header. Malformed JSON raises `JSONDecodeError` → unhandled 500. Also assumes the JSON is a flat object (`.items()`); a JSON array or scalar throws `AttributeError`.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Wrap in try/except and validate it's a dict; return a 400 on bad input.
**Category:** framework
**Example:**
```python
json.loads('["a"]').items()  # AttributeError: 'list' object has no attribute 'items'
```

---

### `match isinstance(...)` is an anti-pattern that hides type bugs
**Trigger:** Using `match` over a boolean (`match isinstance(image, PlainTextResponse): case True / False`) is convoluted and only handles the `export` provider. Any other provider value silently skips this check.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Use a plain `if isinstance(...)`. Centralize the error-vs-success handling before the provider switch.
**Category:** type-system
**Example:**
```python
if isinstance(image, PlainTextResponse):
    return image
return PlainTextResponse(content=os.path.basename(image), status_code=200)
```

---

### `get_promotion_status` returns None → 200 with null body
**Trigger:** The stub function has `pass`, returning `None`. FastAPI serializes this as a `200` with body `null`, masking that the endpoint is unimplemented.
**Affected Files:** `mps/routers/promote.py` (`get_promotion_status`)
**Fix:** Raise `HTTPException(501)` or `NotImplementedError` until implemented.
**Category:** framework
**Example:**
```python
@router.get(...)
async def get_promotion_status():
    pass  # client receives 200 "null"
```

---

### 404 PlainTextResponse with no body content
**Trigger:** `is_image_exists` returns `PlainTextResponse(status_code=404)` with no `content`, producing an empty 404 body that gives clients no diagnostic info.
**Affected Files:** `mps/routers/promote.py` (`is_image_exists`)
**Fix:** Include a message: `PlainTextResponse(content="image not found", status_code=404)`.
**Category:** framework
**Example:**
```python
return PlainTextResponse(status_code=404)  # empty body
```

---

### Schema instantiation per-request cost
**Trigger:** `class_schema(PromoteParams)()` builds the marshmallow schema on every request. `class_schema` is cached internally but instantiation still adds per-call overhead, and it bypasses FastAPI's native validation/docs.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Create the schema once at module level, or better, use FastAPI dependency-injected models for free OpenAPI + validation.
**Category:** performance
**Example:**
```python
_SCHEMA = class_schema(PromoteParams)()  # module scope
# then in handler: params = _SCHEMA.load(params_dict)
```

---

### Shared global `mps` service mutable state
**Trigger:** All handlers reference the module-global `mps` singleton (`mps.token_manager`, `mps.image_manager`, `mps.registry_provider`). If any of these are reassigned/refreshed concurrently (e.g. token rotation), in-flight async requests may read inconsistent state.
**Affected Files:** `mps/routers/promote.py`, `mps.service`
**Fix:** Ensure token/registry refresh is atomic, or snapshot needed values at request start.
**Category:** thread-safety
**Example:**
```python
reg = mps.token_manager.registry  # may change between this and next read
path = f'{reg}/{repo_prefix}/{tag}'
```

---

### Generic 500 leaks raw exception detail
**Trigger:** `NoConfigurationFoundError` handler returns `e.detail` content with a `500` status code. A 500 implies server error, but a missing/unsupported config combination is really a client/4xx condition; also `e.detail` may leak internal info.
**Affected Files:** `mps/routers/promote.py` (`promote`)
**Fix:** Return `400`/`422` for invalid parameter combinations and sanitize the message.
**Category:** domain
**Example:**
```python
except NoConfigurationFoundError as e:
    return PlainTextResponse(content=str(e.detail), status_code=400)
```