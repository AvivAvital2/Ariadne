---
id: dd706baa-9f4e-5d89-ab0c-97163e21942b
type: catalog
title: "mps.api.errors.UnableToStoreCredentialsFile"
created_at: 2026-06-06T18:47:29.771002+00:00
updated_at: 2026-07-03T06:16:14.946017+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnableToStoreCredentialsFile"
  signature: "class UnableToStoreCredentialsFile(ExceptionHandler):"
  location: {'line_start': 85, 'line_end': 88, 'col_start': 0, 'col_end': 67}
  parent_qualified_name: "None"
  sha_at_sync: "8485dc35f3fdd678f517267e89065c6d8b9b60a2c366f8c3afe7e65210e86e3c"
  description: "An exception handler that handles errors occurring when the application fails to write or store a credentials file to disk."
---
# mps.api.errors.UnableToStoreCredentialsFile

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToStoreCredentialsFile


class mps.api.errors.UnableToStoreCredentialsFile [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:85-88 :: class UnableToStoreCredentialsFile(ExceptionHandler):

Description: An exception handler that handles errors occurring when the application fails to write or store a credentials file to disk.

## Related Documents

- [mps.api.errors.UnableToGetAuthToken](2fa0fbad-f9c8-5e61-b90e-48175bf78545.md) - Related (graph distance 1.45)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.54)
- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.59)
- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.61)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.62)
- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 2.67)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.81)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.84)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.85)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.86)
