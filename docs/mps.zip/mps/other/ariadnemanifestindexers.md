---
id: b4484152-4a38-53f3-a83f-f4bf6cf0930e
type: catalog
title: ".ariadne.manifest.indexers"
created_at: 2026-06-06T18:47:25.554175+00:00
updated_at: 2026-06-29T23:12:34.733021+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".ariadne.manifest.indexers"
  signature: "indexers": ["
  location: {'line_start': 4, 'line_end': 28, 'col_start': 2, 'col_end': 3}
  parent_qualified_name: ".ariadne.manifest"
  sha_at_sync: "41d35b1d8b54f9b9ddb267ff7a46f5ba5c09bd005514753510bc3e854d5c5c2f"
  description: "Defines the array of indexer configurations within the Ariadne manifest, specifying the data sources or processors used for indexing."
---
# .ariadne.manifest.indexers

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

# .ariadne.manifest.indexers


json_key .ariadne.manifest.indexers in .ariadne.manifest [json] /Users/spark/git/service-model-promotion/.ariadne/manifest.json:4-28 :: "indexers": [

Description: Defines the array of indexer configurations within the Ariadne manifest, specifying the data sources or processors used for indexing.

## Related Documents

- [file_index:ariadne:ariadne.yaml](a73a2a3c-e782-58fa-873d-6bfbb98a8cd4.md) - Related (graph distance 2.87)
