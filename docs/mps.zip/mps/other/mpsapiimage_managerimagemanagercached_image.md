---
id: a5ca95c2-654d-5604-a500-9de6a73fb4c6
type: catalog
title: "mps.api.image_manager.ImageManager.cached_image"
created_at: 2026-06-06T18:47:28.996036+00:00
updated_at: 2026-07-03T06:16:15.002618+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.cached_image"
  signature: "cached_image = await self.get_if_image_exists(docker_image_path)"
  location: {'line_start': 45, 'line_end': 45, 'col_start': 8, 'col_end': 72}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ebd40256a230042e5d1ee810dd02c739a4b91cf400f1be7c87566fe36afadad7"
  description: "Stores the result of checking whether a Docker image already exists at the specified path, holding the cached image if found or a falsy value otherwise."
---
# mps.api.image_manager.ImageManager.cached_image

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.cached_image


variable mps.api.image_manager.ImageManager.cached_image in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:45-45 :: cached_image = await self.get_if_image_exists(docker_image_path)

Description: Stores the result of checking whether a Docker image already exists at the specified path, holding the cached image if found or a falsy value otherwise.

## Related Documents

- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 1.61)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 2.94)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.06)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 3.13)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 3.21)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 3.22)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 3.26)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 3.27)
