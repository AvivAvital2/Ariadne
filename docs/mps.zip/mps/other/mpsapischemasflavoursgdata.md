---
id: 421f70f2-749b-57fb-802a-4988a0b15516
type: catalog
title: "mps.api.schemas.Flavours.gdata"
created_at: 2026-06-06T18:47:28.913121+00:00
updated_at: 2026-07-03T06:16:15.048423+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.Flavours.gdata"
  signature: "gdata: str"
  location: {'line_start': 8, 'line_end': 8, 'col_start': 4, 'col_end': 14}
  parent_qualified_name: "mps.api.schemas.Flavours"
  sha_at_sync: "7301cfe0e158b5c8169528014456e8106c8ff18b9fb21456f71e5a52e1c8b978"
  description: "Defines a string-typed field named `gdata` within the `Flavours` schema class of the MPS API."
---
# mps.api.schemas.Flavours.gdata

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.Flavours.gdata


variable mps.api.schemas.Flavours.gdata in mps.api.schemas.Flavours [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:8-8 :: gdata: str

Description: Defines a string-typed field named `gdata` within the `Flavours` schema class of the MPS API.

## Related Documents

- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 1.60)
- [mps.api.schemas.Flavours.osm](158f2dda-ad59-551f-8cb0-3fd7f47d9750.md) - Related (graph distance 1.62)
- [mps.api.utils.flavours](99e4f257-b792-58b1-a023-c7b18602a57e.md) - Related (graph distance 3.05)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 3.07)
- [mps.api.schemas.Flavours.minimal](6f98a8fb-a158-538b-b12d-a9eacc2370cb.md) - Related (graph distance 3.22)
