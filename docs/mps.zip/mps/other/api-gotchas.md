---
id: df3105e1-1631-5e14-a6a5-fd1d3a520d9c
type: gotcha
title: "Api Gotchas"
created_at: 2026-06-06T19:03:17.287708+00:00
updated_at: 2026-06-20T22:55:21.841615+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/__init__.py
metadata:
  module_name: "mps.api"
  language: "python"
  source_name: "mps"
---
# Api Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/__init__.py`

# Api Gotchas


# Gotcha Analysis: `mps.api`

## No Source Code Provided

**Trigger:** The module `mps.api` was submitted for analysis, but the source code block is empty. No functions, classes, imports, or declarations are present to inspect.

**Affected Files:** `mps/api.py` (or equivalent) — content unavailable

**Fix:** Re-submit the analysis request with the actual source code populated in the code block. Specifically, include:
- Module-level imports (to assess framework usage like attrs, polars, DuckDB)
- Class and function definitions
- Any async/await usage
- Shared state, caches, or connection objects

**Category:** N/A

**Example:**
```python
# Expected: actual module contents, e.g.
import polars as pl
import duckdb

class MpsApi:
    def query(self, sql: str) -> pl.DataFrame:
        ...
```

---

## What I Can Offer Without Source

Since no code is available, I cannot identify concrete gotchas. However, here are the **categories of issues I will look for** once you provide the source, so you know what to expect:

| Category | What I'll Inspect |
|----------|-------------------|
| **thread-safety** | Shared DuckDB connections (not thread-safe by default), module-level mutable state, caches without locks |
| **type-system** | Silent `None` returns, implicit numeric coercion, `attrs` fields without validators/converters |
| **async** | Sync DB calls inside `async def`, blocking I/O on the event loop, missing `await` |
| **framework** | Polars eager vs. lazy confusion, `attrs` `frozen`/`slots` surprises, DuckDB relation lifetime tied to connection |
| **performance** | `.collect()` called repeatedly, row-wise iteration over DataFrames, N+1 query patterns |

**Please paste the contents of `mps.api` and I will produce a full gotcha report.**