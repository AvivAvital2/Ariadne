---
id: dad3db90-4ede-5b19-ba30-1598e73b079e
type: catalog
title: "mps.api.errors.NoConfigurationFoundError.__init__"
created_at: 2026-06-06T18:47:29.758902+00:00
updated_at: 2026-07-03T06:16:15.098118+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.NoConfigurationFoundError.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 25, 'line_end': 26, 'col_start': 4, 'col_end': 64}
  parent_qualified_name: "mps.api.errors.NoConfigurationFoundError"
  sha_at_sync: "1a081b6262b327b830dff0eb0ba939c6873de44fefd7ff9ecb63f989d0f87a80"
  description: "Initializes the NoConfigurationFoundError exception with the provided error message."
---
# mps.api.errors.NoConfigurationFoundError.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.NoConfigurationFoundError.__init__


method mps.api.errors.NoConfigurationFoundError.__init__ in mps.api.errors.NoConfigurationFoundError [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:25-26 :: def __init__(self, message: str):

Description: Initializes the NoConfigurationFoundError exception with the provided error message.

## Related Documents

- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.05)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.16)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.21)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.27)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.31)
- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 1.51)
- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.55)
- [mps.api.errors.ExceptionHandler.message](26783d80-9b8e-57d1-a7cd-c7ccfa993d2d.md) - Related (graph distance 1.66)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.37)
- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 2.40)
