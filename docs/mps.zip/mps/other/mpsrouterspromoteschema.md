---
id: db1a5046-6f29-597a-b23f-35ecea9392a9
type: catalog
title: "mps.routers.promote.schema"
created_at: 2026-06-06T18:47:27.626133+00:00
updated_at: 2026-07-03T06:16:15.039910+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.schema"
  signature: "schema = class_schema(PromoteParams)()"
  location: {'line_start': 49, 'line_end': 49, 'col_start': 4, 'col_end': 42}
  parent_qualified_name: "None"
  sha_at_sync: "c565e837b7ee2fb39d3ec9630aff5f75821b2ec009ce304218f38c22b6020f2a"
  description: "Creates a marshmallow schema instance from the `PromoteParams` dataclass for validating and deserializing promotion request parameters."
---
# mps.routers.promote.schema

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.schema


variable mps.routers.promote.schema [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:49-49 :: schema = class_schema(PromoteParams)()

Description: Creates a marshmallow schema instance from the `PromoteParams` dataclass for validating and deserializing promotion request parameters.

## Related Documents

- [mps.routers.promote.params](20f2f1b0-87b3-54f2-9129-6e162bce858c.md) - Related (graph distance 1.34)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 1.49)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 2.90)
- [mps.routers.promote.params_dict](4fcf3f76-7581-5b3b-b87a-d871ed2d60d5.md) - Related (graph distance 2.96)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 3.16)
