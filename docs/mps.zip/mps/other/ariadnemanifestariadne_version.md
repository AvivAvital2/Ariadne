---
id: 4c0293eb-ed88-5619-aa6a-5042460e2fee
type: catalog
title: ".ariadne.manifest.ariadne_version"
created_at: 2026-06-06T18:47:25.553472+00:00
updated_at: 2026-06-06T19:01:00.933501+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".ariadne.manifest.ariadne_version"
  signature: ""ariadne_version": "1""
  location: {'line_start': 2, 'line_end': 2, 'col_start': 2, 'col_end': 24}
  parent_qualified_name: ".ariadne.manifest"
  sha_at_sync: "dfd1b5bfb3ebb0542907c71e025b2609cc4b54708003e48517257ec322d242f4"
  description: "Specifies the schema version of the Ariadne manifest format, set to "1"."
---
# .ariadne.manifest.ariadne_version

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

json_key .ariadne.manifest.ariadne_version in .ariadne.manifest [json] /Users/spark/git/service-model-promotion/.ariadne/manifest.json:2-2 :: "ariadne_version": "1"

Description: Specifies the schema version of the Ariadne manifest format, set to "1".