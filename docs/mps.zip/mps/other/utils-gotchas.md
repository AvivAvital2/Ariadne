---
id: 056e840c-4fb9-5a69-a023-14f8d15eb647
type: gotcha
title: "Utils Gotchas"
created_at: 2026-06-06T19:04:07.851061+00:00
updated_at: 2026-06-20T22:55:24.292266+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  module_name: "mps.api.utils"
  language: "python"
  source_name: "mps"
---
# Utils Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# Utils Gotchas


# Gotchas and Pitfalls in `mps.api.utils`

### Naive command splitting breaks quoted arguments
**Trigger:** Passing a `str` command with quoted arguments or paths containing spaces to `run_command`.
**Affected Files:** `mps/api/utils.py` (`run_command`)
**Fix:** Use `shlex.split(command)` instead of `command.split(" ")`, or always pass a pre-tokenized list.
**Category:** domain
**Example:**
```python
await run_command('docker run --name "my container" img')
# splits into: ['docker', 'run', '--name', '"my', 'container"', 'img']
# the quotes are kept literally and the arg is wrongly broken at the space
```

---

### Subprocess deadlock risk avoided, but unbounded memory growth
**Trigger:** A command that emits massive stdout/stderr. `stream_reader` accumulates every line into a list in memory before returning.
**Affected Files:** `mps/api/utils.py` (`run_command`, `stream_reader`)
**Fix:** Stream/process lines incrementally, or cap output size. For commands like `docker pull` with verbose logs this can balloon.
**Category:** performance
**Example:**
```python
# A 'docker build' producing 500MB of logs -> entire output held in RAM as a list
output.append(line.decode().strip())
```

---

### `line.decode()` assumes UTF-8 and can crash
**Trigger:** Subprocess emits non-UTF-8 bytes (binary output, locale-specific encoding).
**Affected Files:** `mps/api/utils.py` (`stream_reader`)
**Fix:** Use `line.decode(errors='replace')` or specify the correct encoding.
**Category:** type-system
**Example:**
```python
output.append(line.decode().strip())  # UnicodeDecodeError on invalid bytes
```

---

### `construct_model_id`'s try/except is dead code
**Trigger:** An f-string interpolation of two strings cannot raise; the `except` block is unreachable.
**Affected Files:** `mps/api/utils.py` (`construct_model_id`)
**Fix:** Remove the try/except, or validate inputs (e.g. reject `None`, empty, or strings containing `:`). Note `None` would silently produce `'None:None'`.
**Category:** type-system
**Example:**
```python
await construct_model_id(None, None)  # returns 'None:None', no error raised
```

---

### `parse_version_number` regex is overly strict and silently wrong
**Trigger:** Versions like `1.10.0` parse, but `10.0.0` (two-digit major), `1.2.10` (two-digit patch), or pre-release tags fail. The minor allows 1-2 digits but major/patch allow exactly one.
**Affected Files:** `mps/api/utils.py` (`parse_version_number`)
**Fix:** Use a consistent pattern `\d+\.\d+\.\d+` (or a real semver library).
**Category:** domain
**Example:**
```python
await parse_version_number('10.2.5')  # raises — major digit > 9 rejected
await parse_version_number('1.2.15')  # raises — patch must be 1 digit
```

---

### `raise ... from None` on a bare `Exception` in a sync-style raise within match
**Trigger:** `raise Exception(...) from None` — using the broad `Exception` type makes callers unable to distinguish error classes; also the `from None` suppresses chaining unnecessarily.
**Affected Files:** `mps/api/utils.py` (`parse_version_number`)
**Fix:** Raise a specific exception type (e.g. `ValueError` or a domain error like `NoConfigurationFoundError`).
**Category:** type-system
**Example:**
```python
raise Exception(f"Release {version_string} ...")  # callers must catch bare Exception
```

---

### `resolve_base_image_id` ignores the 4-key flavour table
**Trigger:** The `flavours` dict has 4 entries keyed on `(linked_data, osm)`, but `use_docker_compose=True` collapses everything to `'minimal'` ignoring the other two flags silently.
**Affected Files:** `mps/api/utils.py` (`resolve_base_image_id`)
**Fix:** Make the override behavior explicit/documented; consider whether docker_compose should be part of the key.
**Category:** domain
**Example:**
```python
# user requests linked_data + osm + compose -> silently gets 'minimal'
resolve_base_image_id(imgs, '1.2.3', True, True, True)
```

---

### Log message uses literal `$baseImageId` placeholder
**Trigger:** Copy-paste from a templating language; the f-string does not interpolate `$baseImageId`, so logs show literal text.
**Affected Files:** `mps/api/utils.py` (`resolve_base_image_id`)
**Fix:** Remove the dollar placeholder or use proper f-string interpolation of the resolved id. Also note typo `useLinkedDataCode`.
**Category:** framework
**Example:**
```python
f'Resolved base image  $baseImageId for parameters...'  # prints literally
```

---

### `extract_model` deletes the zip even on extraction failure
**Trigger:** `zipfile.ZipFile(...)` raises `BadZipFile` — the `finally` block still calls `os.remove`, destroying the source file before it can be inspected/retried.
**Affected Files:** `mps/api/utils.py` (`extract_model`)
**Fix:** Only delete on success, or guard the removal. Also, the unconditional `os.remove` will raise if the file doesn't exist.
**Category:** domain
**Example:**
```python
with zipfile.ZipFile(bad_path) as z:  # raises BadZipFile
    ...
finally:
    os.remove(bad_path)  # source destroyed even though extraction failed
```

---

### Zip extraction path traversal vulnerability
**Trigger:** A malicious zip with entries like `../../etc/cron.d/x`. `extractall` to `destination` without sanitizing member names allows writing outside the target directory.
**Affected Files:** `mps/api/utils.py` (`extract_model`)
**Fix:** Validate member paths before extraction (Python 3.12+ has `filter='data'`), or manually check resolved paths.
**Category:** domain
**Example:**
```python
zip_ref.extractall(destination)  # ../../ entries escape destination
```

---

### Blocking sync `requests.get` inside async function
**Trigger:** `verify_connection_to_container_registry` is `async` but calls synchronous `requests.get`, blocking the event loop for the full network timeout (no timeout set, so potentially forever).
**Affected Files:** `mps/api/utils.py` (`verify_connection_to_container_registry`)
**Fix:** Use an async HTTP client (httpx/aiohttp) or run in `asyncio.to_thread`. Always pass a `timeout=`.
**Category:** async
**Example:**
```python
requests.get(f'{schema}://{registry}/v2/', auth=auth, verify=verify)
# no timeout + blocking = event loop frozen during retries
```

---

### SSL fallback path silently retries and can loop without resolution
**Trigger:** In the SSL-error branch, the HTTP fallback `requests.get(f'http://{registry}/v2/')` is itself unguarded — it can raise `ConnectionError` that escapes the loop entirely (not caught here), and if it returns non-200 it sleeps and retries indefinitely up to 30 times.
**Affected Files:** `mps/api/utils.py` (`verify_connection_to_container_registry`)
**Fix:** Wrap the fallback request in its own try/except; add a timeout.
**Category:** async
**Example:**
```python
except requests.exceptions.SSLError as e:
    ...
    if requests.get(f'http://{registry}/v2/').status_code == ...:  # uncaught exception
```

---

### `urllib3.disable_warnings` is a global side effect
**Trigger:** Calling this function disables InsecureRequestWarning process-wide, affecting all other code using requests/urllib3, permanently.
**Affected Files:** `mps/api/utils.py` (`verify_connection_to_container_registry`)
**Fix:** Avoid global mutation; configure warnings at app startup with explicit intent, or use a context manager.
**Category:** thread-safety
**Example:**
```python
urllib3.disable_warnings(...)  # affects every request anywhere in the process
```

---

### `MPSSession` re-uses the requests connection pool across threads/loops
**Trigger:** `requests.Session` is not thread-safe; sharing one `MPSSession` across concurrent async tasks (via `to_thread`) or threads causes connection-pool corruption.
**Affected Files:** `mps/api/utils.py` (`MPSSession`)
**Fix:** Use one session per thread, or switch to httpx with proper async support.
**Category:** thread-safety
**Example:**
```python
session = MPSSession(base_url)
# shared between threads -> race conditions in urllib3 connection pool
```

---

### `urljoin` base_url gotcha drops path segments
**Trigger:** `urljoin` follows URL-relative rules. If `base_url='https://host/api'` (no trailing slash) and `uri='models'`, result is `https://host/models`, dropping `/api`.
**Affected Files:** `mps/api/utils.py` (`MPSSession.request`)
**Fix:** Ensure base_url ends with `/` and uri has no leading `/`, or build URLs explicitly.
**Category:** framework
**Example:**
```python
urljoin('https://host/api', 'models')  # -> 'https://host/models' (loses /api)
urljoin('https://host/api', '/models') # -> 'https://host/models' (absolute path)
```

---

### `all([...])` evaluates all conditions eagerly (no short-circuit)
**Trigger:** `all([cond1, cond2, cond3])` builds a list and evaluates every element, unlike `and`. Minor here, but if any element had side effects or was expensive it would always run.
**Affected Files:** `mps/api/utils.py` (`verify_connection_to_container_registry`)
**Fix:** Use `cond1 and cond2 and cond3` for short-circuit semantics.
**Category:** performance
**Example:**
```python
all(["CERTIFICATE_VERIFY_FAILED" in str(e), provider == 'local', verify is True])
# all three always evaluated
```

---

### `docker_image_to_file_name` mishandles registry ports
**Trigger:** Tags like `registry:5000/image:tag` — `rpartition('/')` correctly isolates `image:tag`, but a tag with no slash and a port-like registry `localhost:5000` would be treated as image:tag and produce `localhost_5000`.
**Affected Files:** `mps/api/utils.py` (`docker_image_to_file_name`)
**Fix:** Parse the docker reference properly distinguishing registry-port from tag separator.
**Category:** domain
**Example:**
```python
docker_image_to_file_name('localhost:5000')  # -> 'localhost_5000' (treated as tag!)
```

---

### Return type annotation mismatch
**Trigger:** `run_command` is annotated `-> tuple[list, list, int | None]` but `process.returncode` after `wait()` is always an `int`, and the lists are `list[str]`. The loose `list` annotation loses element typing for callers.
**Affected Files:** `mps/api/utils.py` (`run_command`)
**Fix:** Annotate `tuple[list[str], list[str], int]`.
**Category:** type-system
**Example:**
```python
out, err, code = await run_command(...)  # out typed as list[Any], not list[str]
```