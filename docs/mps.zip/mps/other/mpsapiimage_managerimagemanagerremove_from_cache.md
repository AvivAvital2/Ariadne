---
id: 6dcb2bb0-26cc-5404-95fc-267d0c626297
type: catalog
title: "mps.api.image_manager.ImageManager.remove_from_cache"
created_at: 2026-06-06T18:47:28.986977+00:00
updated_at: 2026-07-03T06:16:15.100611+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.remove_from_cache"
  signature: "async def remove_from_cache(self, tag):"
  location: {'line_start': 293, 'line_end': 295, 'col_start': 4, 'col_end': 35}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "2df62942cae99027841a828bbbd63c2731036d700d3a57a546f15e46f6a1a928"
  description: "Asynchronously removes the image with the specified tag from the ImageManager's cache."
---
# mps.api.image_manager.ImageManager.remove_from_cache

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.remove_from_cache


method mps.api.image_manager.ImageManager.remove_from_cache in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:293-295 :: async def remove_from_cache(self, tag):

Description: Asynchronously removes the image with the specified tag from the ImageManager's cache.

## Related Documents

- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 1.21)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 1.52)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.53)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 1.54)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 2.57)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 2.57)
- [mps.api.image_cache.AsyncPersistentImageCache.update](b9099bc1-0ee6-547f-b844-bd21c0c852ea.md) - Related (graph distance 2.83)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 2.85)
