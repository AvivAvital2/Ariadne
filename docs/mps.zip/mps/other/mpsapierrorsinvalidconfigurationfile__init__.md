---
id: 1b2f4c39-2c17-54d9-ab45-75c1685aa2e4
type: catalog
title: "mps.api.errors.InvalidConfigurationFile.__init__"
created_at: 2026-06-06T18:47:29.759425+00:00
updated_at: 2026-07-03T06:16:15.056118+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.InvalidConfigurationFile.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 36, 'line_end': 37, 'col_start': 4, 'col_end': 63}
  parent_qualified_name: "mps.api.errors.InvalidConfigurationFile"
  sha_at_sync: "66a523cc97f1980ae405006ef920fc1f04e9ce9deadf7c22ff353a20bcb3d700"
  description: "Initializes an `InvalidConfigurationFile` exception with the provided error message describing the configuration file problem."
---
# mps.api.errors.InvalidConfigurationFile.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidConfigurationFile.__init__


method mps.api.errors.InvalidConfigurationFile.__init__ in mps.api.errors.InvalidConfigurationFile [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:36-37 :: def __init__(self, message: str):

Description: Initializes an `InvalidConfigurationFile` exception with the provided error message describing the configuration file problem.

## Related Documents

- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.13)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.16)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.19)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.19)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.22)
- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 1.24)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.29)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.30)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.32)
