---
id: 6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde
type: catalog
title: "mps.api.errors.InvalidAWSRegion"
created_at: 2026-06-06T18:47:29.763781+00:00
updated_at: 2026-07-03T06:16:15.068906+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.InvalidAWSRegion"
  signature: "class InvalidAWSRegion(ExceptionHandler):"
  location: {'line_start': 51, 'line_end': 54, 'col_start': 0, 'col_end': 55}
  parent_qualified_name: "None"
  sha_at_sync: "493dd8893df2238c6f7ff90955cc3b3ea30dd9d6fce9668b29d3d13b94a98d21"
  description: "Exception handler for cases where an invalid or unrecognized AWS region is specified. Inherits from `ExceptionHandler` to manage error responses for region validation failures."
---
# mps.api.errors.InvalidAWSRegion

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidAWSRegion


class mps.api.errors.InvalidAWSRegion [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:51-54 :: class InvalidAWSRegion(ExceptionHandler):

Description: Exception handler for cases where an invalid or unrecognized AWS region is specified. Inherits from `ExceptionHandler` to manage error responses for region validation failures.

## Related Documents

- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 1.44)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.52)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.52)
- [mps.api.errors.ExceptionHandler](cf4dd7f9-1a77-532c-ba34-3c1194c6363c.md) - Related (graph distance 1.54)
- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.63)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.68)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.69)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 2.74)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.75)
