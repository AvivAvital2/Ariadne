---
id: 0be21243-97ad-5473-82ca-dc0f6a92b6b9
type: catalog
title: ".ariadne.manifest.source_name"
created_at: 2026-06-06T18:47:25.553869+00:00
updated_at: 2026-06-20T22:55:22.827643+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".ariadne.manifest.source_name"
  signature: "source_name": "mps"
  location: {'line_start': 3, 'line_end': 3, 'col_start': 2, 'col_end': 22}
  parent_qualified_name: ".ariadne.manifest"
  sha_at_sync: "6d242b4bc58a06bdc8c4a615eac2f6f2a3781a9db8b931b8f82e0e327c3e596d"
  description: "Specifies the name identifier of the data source within the Ariadne manifest, set to "mps"."
---
# .ariadne.manifest.source_name

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

# .ariadne.manifest.source_name


json_key .ariadne.manifest.source_name in .ariadne.manifest [json] /Users/spark/git/service-model-promotion/.ariadne/manifest.json:3-3 :: "source_name": "mps"

Description: Specifies the name of the data source ("mps") within the Ariadne manifest configuration.

Description: Specifies the name identifier of the data source within the Ariadne manifest, set to "mps".

## Related Documents

- [.ariadne.manifest.source_name](9112bb66-54c4-5978-a5c4-664099281488.md) - Related (graph distance 1.14)
- [.ariadne.manifest.ariadne_version](a3d7fb1d-b757-561c-bc7f-635a7557d0a6.md) - Related (graph distance 1.48)
- [.ariadne.manifest.merged_scip](84726fb8-f4a6-5697-90cf-d36a523b71b3.md) - Related (graph distance 1.59)
- [ariadne.default_source](c61d3be8-6a8e-52f5-b7ab-f0709d10b0e2.md) - Related (graph distance 2.60)
- [.ariadne.manifest.merged_at](ca3f7827-1646-586c-b61d-f1efd675c521.md) - Related (graph distance 3.00)