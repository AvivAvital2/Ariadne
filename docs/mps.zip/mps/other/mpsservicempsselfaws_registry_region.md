---
id: dd85db50-7c3d-5649-b194-c5c4a804805f
type: catalog
title: "mps.service.MPS.self.aws_registry_region"
created_at: 2026-06-06T18:47:26.304353+00:00
updated_at: 2026-07-03T06:16:15.106365+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.aws_registry_region"
  signature: "self.aws_registry_region = os.getenv("AWS_REGISTRY_REGION", None)"
  location: {'line_start': 14, 'line_end': 14, 'col_start': 8, 'col_end': 73}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "de947c66bb99cbdc573e52f1f4775c4fbfe285df2230f84c76b246e262a43217"
  description: "Stores the AWS registry region read from the `AWS_REGISTRY_REGION` environment variable, defaulting to `None` if the variable is not set."
---
# mps.service.MPS.self.aws_registry_region

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.aws_registry_region


variable mps.service.MPS.self.aws_registry_region in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:14-14 :: self.aws_registry_region = os.getenv("AWS_REGISTRY_REGION", None)

Description: Stores the AWS registry region read from the `AWS_REGISTRY_REGION` environment variable, defaulting to `None` if the variable is not set.

## Related Documents

- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 1.34)
- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 1.35)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 1.37)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 1.38)
- [mps.api.token_manager.AWSTokenManager.region_name](1dacb1db-2e0a-5c6d-9346-b1edb16f86d5.md) - Related (graph distance 1.42)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.48)
- [mps.api.token_manager.TokenManager.region_name](f1d74add-cad1-572b-a333-d85b1ed35998.md) - Related (graph distance 1.49)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.80)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 2.88)
