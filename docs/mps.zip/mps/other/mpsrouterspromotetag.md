---
id: 29a0e745-d4bd-5b5f-b2c7-8ce597d7d251
type: catalog
title: "mps.routers.promote.tag"
created_at: 2026-06-06T18:47:27.615956+00:00
updated_at: 2026-07-03T06:16:15.003674+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.tag"
  signature: "tag = await construct_model_id("
  location: {'line_start': 29, 'line_end': 32, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "None"
  sha_at_sync: "98c01fc39754e94ffecd2c91780e1f51315b2b1e92be3aa3f415be24b8edbc4d"
  description: "Constructs and assigns a model ID (via the asynchronous `construct_model_id` function) used for tagging within the promote router."
---
# mps.routers.promote.tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.tag


variable mps.routers.promote.tag [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:29-32 :: tag = await construct_model_id(

Description: Constructs and assigns a model ID (via the asynchronous `construct_model_id` function) used for tagging within the promote router.

## Related Documents

- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.54)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 3.00)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 3.07)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.07)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 3.16)
