---
id: ce100262-33f0-5372-acbf-7561c204cea6
type: catalog
title: "mps.api.image_manager.ImageManager.generate_env_file"
created_at: 2026-06-06T18:47:28.993291+00:00
updated_at: 2026-06-20T22:55:23.784976+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.generate_env_file"
  signature: "async def generate_env_file(self, image_path: str):"
  location: {'line_start': 325, 'line_end': 333, 'col_start': 4, 'col_end': 113}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "424f4127d4d2a0f22a1e196cb1afa8191e0cd93883f67ef68a6d309c1f460a21"
  description: "Asynchronously generates an environment file for the specified image path."
---
# mps.api.image_manager.ImageManager.generate_env_file

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.generate_env_file


method mps.api.image_manager.ImageManager.generate_env_file in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:325-333 :: async def generate_env_file(self, image_path: str):

Description: Asynchronously generates an environment file for the specified image path.