---
id: ec437012-04cc-55dc-9ff9-72f363791ae7
type: catalog
title: "documentation.README_standalone.install_docker"
created_at: 2026-06-06T18:47:26.283300+00:00
updated_at: 2026-06-20T22:55:22.279960+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.install_docker"
  signature: "####  Install Docker"
  location: {'line_start': 35, 'line_end': 56, 'col_start': 0, 'col_end': 20}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "11f0cd3b2af5cdcd4820240c76d087807e5c44cfe0ca2efb3d9aea11de239762"
  description: "Provides instructions for installing Docker as a prerequisite for running the standalone application."
---
# documentation.README_standalone.install_docker

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.install_docker


md_section documentation.README_standalone.install_docker in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:35-56 :: ####  Install Docker

Description: Provides instructions for installing Docker as a prerequisite for running the standalone application.