---
id: ace7d034-38b2-5493-9c7d-9cd6df5da6fa
type: catalog
title: "mps.api.logger.SkipHealthFilter"
created_at: 2026-06-06T18:47:28.690799+00:00
updated_at: 2026-07-03T06:16:15.016027+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.logger.SkipHealthFilter"
  signature: "class SkipHealthFilter(logging.Filter):"
  location: {'line_start': 14, 'line_end': 22, 'col_start': 0, 'col_end': 94}
  parent_qualified_name: "None"
  sha_at_sync: "25b6c3d4c009aa0e3913b57589cb12bbacfd812172a7ce28d1daa77f4817caa0"
  description: "A `logging.Filter` subclass that suppresses log records for health check requests, preventing them from cluttering the logs."
---
# mps.api.logger.SkipHealthFilter

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.SkipHealthFilter


class mps.api.logger.SkipHealthFilter [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:14-22 :: class SkipHealthFilter(logging.Filter):

Description: A `logging.Filter` subclass that suppresses log records for health check requests, preventing them from cluttering the logs.

## Related Documents

- [mps.api.logger.SkipHealthFilter.filter](fe3155c9-4fa0-5a72-87d8-429ba1343760.md) - Related (graph distance 1.50)
- [mps.api.logger.SkipHealthFilter.filtered_endpoints](1960c946-fc9c-54cd-bf74-cc536adc42cc.md) - Related (graph distance 1.62)
