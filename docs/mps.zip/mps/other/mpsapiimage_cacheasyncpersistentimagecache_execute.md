---
id: 5ef1435a-0318-5b43-82f7-fe585031f6b8
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache._execute"
created_at: 2026-06-06T18:47:29.720041+00:00
updated_at: 2026-06-20T22:55:25.760809+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache._execute"
  signature: "async def _execute(self, query, parameters=None):"
  location: {'line_start': 42, 'line_end': 46, 'col_start': 4, 'col_end': 36}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "8305b41dfc6181da8cab41812fe13d3dac92b10807c6a25e3120a30c4d5bb6eb"
  description: "Asynchronously executes a database query with optional parameters using the cache's connection, awaiting completion."
---
# mps.api.image_cache.AsyncPersistentImageCache._execute

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache._execute


method mps.api.image_cache.AsyncPersistentImageCache._execute in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:42-46 :: async def _execute(self, query, parameters=None):

Description: Asynchronously executes a database query with optional parameters using the cache's connection, awaiting completion.