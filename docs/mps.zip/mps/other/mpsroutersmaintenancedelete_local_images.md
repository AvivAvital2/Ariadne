---
id: e7bd0b0a-6635-59aa-b7ab-72f4c2ab7f1b
type: catalog
title: "mps.routers.maintenance.delete_local_images"
created_at: 2026-06-06T18:47:27.296294+00:00
updated_at: 2026-07-03T06:16:14.940366+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.maintenance.delete_local_images"
  signature: "async def delete_local_images():"
  location: {'line_start': 29, 'line_end': 30, 'col_start': 4, 'col_end': 60}
  parent_qualified_name: "None"
  sha_at_sync: "88658b5cbb4b30a78af8023f0f20ee8386a3ed6488bcb88d64929136e915ed80"
  description: "Deletes all locally stored images as a maintenance operation, typically to free up disk space."
---
# mps.routers.maintenance.delete_local_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# mps.routers.maintenance.delete_local_images


async_function mps.routers.maintenance.delete_local_images [python] /Users/spark/git/service-model-promotion/mps/routers/maintenance.py:29-30 :: async def delete_local_images():

Description: Deletes all locally stored images as a maintenance operation, typically to free up disk space.

## Related Documents

- [mps.routers.maintenance.list_images](dba494fa-4ba4-5080-8dd6-afee381e737c.md) - Related (graph distance 1.25)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 1.31)
- [mps.routers.maintenance.remote_images](9cd933a2-32f1-5a4d-87ee-cd05d12fa057.md) - Related (graph distance 1.31)
- [mps.routers.maintenance.get_total_images_size](739fc960-32ce-543a-8f9a-9878beba79af.md) - Related (graph distance 1.40)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 1.60)
- [mps.api.image_manager.ImageManager.get_size_of_images](d33e623d-e2ff-5e78-b40c-db99afab80ae.md) - Related (graph distance 2.60)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 2.70)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 2.74)
- [mps.api.image_manager.ImageManager.get_exported_image_list](70dae0c7-4d5f-5c6a-98bb-1b86d0bb851a.md) - Related (graph distance 2.75)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.83)
