---
id: ece58668-9be1-5f1b-8ef8-616b430082c8
type: catalog
title: "mps.api.image_manager.ImageManager.error_message"
created_at: 2026-06-06T18:47:28.995241+00:00
updated_at: 2026-06-20T22:55:21.749312+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.error_message"
  signature: "error_message = 'Export as Docker Compose is disabled since REGISTRY_PROVIDER=export. '\"
  location: {'line_start': 34, 'line_end': 36, 'col_start': 12, 'col_end': 60}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "2538bd3e443d1edc2ad8603bee743d28f3f79551b07d1e5d5fcfaff82df7b42e"
  description: "Holds the error message string displayed when Docker Compose export is attempted while the REGISTRY_PROVIDER is set to "export", indicating the operation is disabled."
---
# mps.api.image_manager.ImageManager.error_message

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.error_message


variable mps.api.image_manager.ImageManager.error_message in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:34-36 :: error_message = 'Export as Docker Compose is disabled since REGISTRY_PROVIDER=export. '\

Description: Holds the error message string displayed when Docker Compose export is attempted while the REGISTRY_PROVIDER is set to "export", indicating the operation is disabled.