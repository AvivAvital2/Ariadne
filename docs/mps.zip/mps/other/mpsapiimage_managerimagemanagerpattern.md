---
id: ef084c6a-85c3-5354-a0da-f76e91cc0c51
type: catalog
title: "mps.api.image_manager.ImageManager.pattern"
created_at: 2026-06-06T18:47:29.004072+00:00
updated_at: 2026-06-20T22:55:23.878005+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.pattern"
  signature: "pattern = compile("|".join(map(escape, replacements.keys())))"
  location: {'line_start': 331, 'line_end': 331, 'col_start': 8, 'col_end': 69}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "b4209151190730aff50248fd5ec24f5b6d47b076ed6b7d070a741e168717aa64"
  description: "A precompiled regular expression that matches any of the keys in the `replacements` dictionary, with each key escaped to be treated as a literal string."
---
# mps.api.image_manager.ImageManager.pattern

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.pattern


variable mps.api.image_manager.ImageManager.pattern in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:331-331 :: pattern = compile("|".join(map(escape, replacements.keys())))

Description: A precompiled regular expression that matches any of the keys in the `replacements` dictionary, with each key escaped to be treated as a literal string.