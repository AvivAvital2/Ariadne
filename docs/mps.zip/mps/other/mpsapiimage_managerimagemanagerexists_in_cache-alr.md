---
id: 15197025-e3a5-5852-9444-cec1baadf6c1
type: catalog
title: "mps.api.image_manager.ImageManager.exists_in_cache, already_exported"
created_at: 2026-06-06T18:47:29.001345+00:00
updated_at: 2026-06-06T19:07:07.316208+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.exists_in_cache, already_exported"
  signature: "exists_in_cache, already_exported = await asyncio.gather("
  location: {'line_start': 189, 'line_end': 192, 'col_start': 16, 'col_end': 17}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "fdfbd215f735f2fbe2afd1687b48ffa6da5728e0ee381f8106bbb67356695cdb"
  description: "Unpacks the results of two concurrently awaited operations, capturing whether an image exists in the cache and whether it has already been exported."
---
# mps.api.image_manager.ImageManager.exists_in_cache, already_exported

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

variable mps.api.image_manager.ImageManager.exists_in_cache, already_exported in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:189-192 :: exists_in_cache, already_exported = await asyncio.gather(

Description: Unpacks the results of two concurrently awaited operations, capturing whether an image exists in the cache and whether it has already been exported.

## Related Documents

- [mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path)](667a325b-1850-541b-a628-997e8da32ed0.md) - Related (graph distance 1.16)
