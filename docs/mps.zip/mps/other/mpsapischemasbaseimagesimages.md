---
id: aeecab73-698c-51fc-9e93-ae299736af7b
type: catalog
title: "mps.api.schemas.BaseImages.images"
created_at: 2026-06-06T18:47:28.914151+00:00
updated_at: 2026-07-03T06:16:15.112542+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.BaseImages.images"
  signature: "images: Flavours"
  location: {'line_start': 15, 'line_end': 15, 'col_start': 4, 'col_end': 20}
  parent_qualified_name: "mps.api.schemas.BaseImages"
  sha_at_sync: "7a6fd87afae45972a9ce603e4c4f995bf956bca6b74dce6a36634560923b2be8"
  description: "Defines the `images` field on the `BaseImages` schema, holding a `Flavours` collection of base image definitions."
---
# mps.api.schemas.BaseImages.images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.BaseImages.images


variable mps.api.schemas.BaseImages.images in mps.api.schemas.BaseImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:15-15 :: images: Flavours

Description: Defines the `images` field on the `BaseImages` schema, holding a `Flavours` collection of base image definitions.

## Related Documents

- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 1.43)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.44)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 1.47)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 1.49)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 1.62)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 2.74)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 2.83)
- [mps.api.image_manager.ImageManager.stored_images](e9031a30-a2eb-54a4-bdcb-034b6e0bc3be.md) - Related (graph distance 2.83)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 2.85)
