---
id: e9031a30-a2eb-54a4-bdcb-034b6e0bc3be
type: catalog
title: "mps.api.image_manager.ImageManager.stored_images"
created_at: 2026-06-06T18:47:29.001872+00:00
updated_at: 2026-07-03T06:16:14.978177+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.stored_images"
  signature: "stored_images = dict("
  location: {'line_start': 251, 'line_end': 262, 'col_start': 12, 'col_end': 13}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "1f4ec9deba14bcc4af66044345cfbc7a9e774a755dccc88a887760d8c1fd6c4d"
  description: "Maintains a dictionary mapping image identifiers to their corresponding stored image data within the ImageManager instance."
---
# mps.api.image_manager.ImageManager.stored_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.stored_images


variable mps.api.image_manager.ImageManager.stored_images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:251-262 :: stored_images = dict(

Description: Maintains a dictionary mapping image identifiers to their corresponding stored image data within the ImageManager instance.

## Related Documents

- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 1.22)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 2.74)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 2.83)
