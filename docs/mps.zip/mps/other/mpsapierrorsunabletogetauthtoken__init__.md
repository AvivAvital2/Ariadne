---
id: 3e66395f-d166-564e-88e4-7a8764021cd5
type: catalog
title: "mps.api.errors.UnableToGetAuthToken.__init__"
created_at: 2026-06-06T18:47:29.759679+00:00
updated_at: 2026-07-03T06:16:15.017482+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnableToGetAuthToken.__init__"
  signature: "def __init__(self, message: str, status_code: int):"
  location: {'line_start': 41, 'line_end': 42, 'col_start': 4, 'col_end': 72}
  parent_qualified_name: "mps.api.errors.UnableToGetAuthToken"
  sha_at_sync: "fe231c6ed8c6c2bdcf842c01e5402419a184e126f4efa62c1dbc28792037a538"
  description: "Initializes an `UnableToGetAuthToken` exception with an error message and an HTTP status code."
---
# mps.api.errors.UnableToGetAuthToken.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToGetAuthToken.__init__


method mps.api.errors.UnableToGetAuthToken.__init__ in mps.api.errors.UnableToGetAuthToken [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:41-42 :: def __init__(self, message: str, status_code: int):

Description: Initializes an `UnableToGetAuthToken` exception with an error message and an HTTP status code.

## Related Documents

- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.23)
- [mps.api.errors.ExceptionHandler.__init__](217d2c38-8594-57a8-b81f-9b6355041445.md) - Related (graph distance 1.27)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.30)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.31)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.31)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.42)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 2.45)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.48)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 2.49)
