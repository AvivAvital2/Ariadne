---
id: 1fe550b7-eb9e-5156-8628-77f8352f5d0d
type: catalog
title: "mps.api.utils.verify_connection_to_container_registry"
created_at: 2026-06-06T18:47:29.298274+00:00
updated_at: 2026-07-03T06:16:15.027882+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.verify_connection_to_container_registry"
  signature: "async def verify_connection_to_container_registry("
  location: {'line_start': 124, 'line_end': 154, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: "None"
  sha_at_sync: "1678f3f26f883917fe69f84897c3b7765658738d3b863b98c5cecf2fdb0c5f2d"
  description: "Asynchronously verifies that a connection can be established to the configured container registry, raising an error if the registry is unreachable or authentication fails."
---
# mps.api.utils.verify_connection_to_container_registry

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.verify_connection_to_container_registry


async_function mps.api.utils.verify_connection_to_container_registry [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:124-154 :: async def verify_connection_to_container_registry(

Description: Asynchronously verifies that a connection can be established to the configured container registry, raising an error if the registry is unreachable or authentication fails.

## Related Documents

- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 1.60)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 2.94)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 3.00)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 3.02)
- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 3.25)
