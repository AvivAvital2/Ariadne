---
id: 73109235-6929-5b68-846e-9c12dab68101
type: catalog
title: "mps.api.image_manager.ImageManager.image_path"
created_at: 2026-06-06T18:47:29.000815+00:00
updated_at: 2026-07-03T06:16:15.091799+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.image_path"
  signature: "image_path = tag"
  location: {'line_start': 193, 'line_end': 193, 'col_start': 16, 'col_end': 32}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "bc36b05fee7b6b5f312eed9dd55a3ec0ba26a8d25fb82f841cade0eb38cac0b4"
  description: "Stores the image tag as the instance's image path attribute on the ImageManager."
---
# mps.api.image_manager.ImageManager.image_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.image_path


variable mps.api.image_manager.ImageManager.image_path in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:193-193 :: image_path = tag

Description: Stores the image tag as the instance's image path attribute on the ImageManager.

## Related Documents

- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 1.59)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.61)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 2.80)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 2.92)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 2.94)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 3.00)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 3.08)
