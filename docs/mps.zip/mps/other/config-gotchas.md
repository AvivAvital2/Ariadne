---
id: e44003dc-fb60-5a03-a608-e60353ba9e7e
type: gotcha
title: "Config Gotchas"
created_at: 2026-06-06T19:03:23.346067+00:00
updated_at: 2026-06-20T22:55:26.022476+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  module_name: "mps.api.config"
  language: "python"
  source_name: "mps"
---
# Config Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# Config Gotchas


# Gotchas and Pitfalls: `mps.api.config`

### Module-level side effects run at import time
**Trigger:** All the file validation, parsing, and assignments are at module top-level, so they execute on first `import mps.api.config`. Any failure raises an exception during import, which is hard to catch gracefully and breaks tooling (autocomplete, test collection, doc generators).
**Affected Files:** `mps/api/config.py`
**Fix:** Wrap initialization in a function (e.g., `load_config()`) or lazy-loaded cached property so imports stay side-effect-free.
**Category:** framework
**Example:**
```python
import mps.api.config  # may raise NoConfigurationFileFoundError just by importing!
```

### `match` statement is misused as a glorified if/else and the loop is dead logic
**Trigger:** The `match file_path: case file_path if ...:` pattern rebinds `file_path` to itself and uses guards only. This is equivalent to an `if/elif` chain but obscures intent. Worse, the loop validates files but then the `case _: continue` makes it pass through — the actual `open()` calls happen *after* the loop using hardcoded paths, not the validated `file_path`.
**Affected Files:** `mps/api/config.py`
**Fix:** Use a plain `if/elif`, and reuse the validated paths instead of re-hardcoding strings.
**Category:** type-system
**Example:**
```python
# Loop validates 'conf/defaults.json' and 'conf/promotion.toml',
# but open() re-specifies them — drift risk if file_paths changes.
with open('conf/defaults.json') as defaults_fh:  # not derived from file_paths
```

### Relative paths depend on the current working directory
**Trigger:** `'conf/defaults.json'` is relative to `os.getcwd()`, not the module location. Running from a different directory raises `NoConfigurationFileFoundError` even when the files exist next to the code.
**Affected Files:** `mps/api/config.py`
**Fix:** Anchor paths to the module: `Path(__file__).parent / 'conf' / 'defaults.json'`, or accept an explicit config dir/env var.
**Category:** domain
**Example:**
```python
$ cd /tmp && python -c "import mps.api.config"  # fails, conf/ not found
```

### TOCTOU race between validation and open
**Trigger:** The loop checks `exists()`, `is_file()`, `st_size`, and `R_OK`, then later `open()` runs separately. A file can be deleted/changed/truncated between the checks and the open — and the size-zero / permission checks give false confidence.
**Affected Files:** `mps/api/config.py`
**Fix:** Just attempt to open and parse, handling `OSError`/`FileNotFoundError`/`PermissionError` directly. Don't pre-check then act.
**Category:** thread-safety
**Example:**
```python
case file_path if file_path.stat().st_size == 0: ...  # checked here
# ... file truncated by another process ...
with open('conf/promotion.toml', 'rb') as f: ...      # now empty
```

### `st_size == 0` is not a reliable "empty config" signal
**Trigger:** A TOML/JSON file with only whitespace/comments has nonzero size but yields empty/partial data. Conversely, special files (pipes, `/dev/fd/...`) report size 0 but are valid. The zero-size check both misses real problems and falsely rejects valid streams.
**Affected Files:** `mps/api/config.py`
**Fix:** Validate the *parsed* content, not the byte count.
**Category:** domain
**Example:**
```python
# defaults.json containing just "{}" passes size check but has no defaults
```

### JSON/TOML parse errors are unwrapped
**Trigger:** `json.load` raises `json.JSONDecodeError` and `tomllib.load` raises `tomllib.TOMLDecodeError`. Neither is caught, so callers see raw decode errors instead of the module's `InvalidConfigurationFile`.
**Affected Files:** `mps/api/config.py`
**Fix:** Wrap parsing in try/except and re-raise as `InvalidConfigurationFile`.
**Category:** type-system
**Example:**
```python
config = tomllib.load(f)  # malformed TOML → bare TOMLDecodeError leaks out
```

### `setdefault` only merges top-level and one nested level
**Trigger:** The merge loop does `config.setdefault(section, {})` then `section_dict.setdefault(key, default)`. It is exactly two levels deep. If `defaults.json` has nested dicts under a key (e.g., `local_image_cache.path` with more sub-keys), defaults below level 2 are silently ignored.
**Affected Files:** `mps/api/config.py`
**Fix:** Use a recursive deep-merge for nested config structures.
**Category:** domain
**Example:**
```python
# defaults: {"a": {"b": {"c": 1}}}
# config:   {"a": {"b": {}}}
# result:   {"a": {"b": {}}}  -> c=1 NOT applied (b already exists)
```

### Final dict access assumes keys exist regardless of defaults
**Trigger:** `config['baseImage']`, `config['local_image_cache']['path']`, etc. raise `KeyError` if those keys are absent from *both* the TOML and the defaults. The KeyError is a raw Python error, not `InvalidConfigurationFile`.
**Affected Files:** `mps/api/config.py`
**Fix:** Validate required keys explicitly and raise `InvalidConfigurationFile` with a descriptive message.
**Category:** type-system
**Example:**
```python
repo_prefix = config['general']['repo_prefix']  # KeyError if 'general' missing
```

### Mutable shared state — `defaults` values are aliased into `config`
**Trigger:** `setdefault(key, default)` inserts the *same object* from `defaults` into `config`. If `default` is a list/dict and later mutated through `config`, the `defaults` dict mutates too (and vice versa). Also makes the module-level `config` a shared mutable global.
**Affected Files:** `mps/api/config.py`
**Fix:** Deep-copy defaults before insertion (`copy.deepcopy`), and expose config as read-only / immutable.
**Category:** thread-safety
**Example:**
```python
config['someSection']['list'].append(x)  # may also mutate defaults['someSection']['list']
```

### Inconsistent key naming hints at silent typos
**Trigger:** Keys mix camelCase (`baseImage`) and snake_case (`local_image_cache`, `repo_prefix`). A typo'd config key won't error — `setdefault` will just create the default-named key while user data sits under the wrong key, silently using defaults.
**Affected Files:** `mps/api/config.py`, `conf/promotion.toml`
**Fix:** Define a schema (e.g., dataclass/pydantic) and reject unknown keys.
**Category:** domain
**Example:**
```toml
[base_image]   # user used snake_case, code reads config['baseImage'] -> defaults used silently
```

### `from None` suppresses useful context unnecessarily
**Trigger:** `raise ... from None` hides any underlying exception chain. For `stat()`/`access()` failures this discards diagnostic info (e.g., the actual `OSError`).
**Affected Files:** `mps/api/config.py`
**Fix:** Use `from err` to preserve context, or omit `from None` when there's no exception being suppressed (there isn't one here — these aren't in an `except` block, so `from None` is meaningless/misleading).
**Category:** type-system
**Example:**
```python
raise NoConfigurationFileFoundError(...) from None  # no active exception to suppress anyway
```

### File handle for defaults is opened without explicit encoding
**Trigger:** `open('conf/defaults.json')` uses the platform default text encoding. On systems where that isn't UTF-8 (some Windows locales), non-ASCII JSON values decode incorrectly.
**Affected Files:** `mps/api/config.py`
**Fix:** Pass `encoding='utf-8'` explicitly.
**Category:** framework
**Example:**
```python
with open('conf/defaults.json', encoding='utf-8') as fh: ...
```