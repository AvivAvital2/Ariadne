---
id: d4ae9ba0-5586-594e-bbc1-51cb216e3ed7
type: catalog
title: "mps.api.errors.SelfSignedCertificate"
created_at: 2026-06-06T18:47:29.770734+00:00
updated_at: 2026-07-03T06:16:14.938099+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.SelfSignedCertificate"
  signature: "class SelfSignedCertificate(ExceptionHandler):"
  location: {'line_start': 80, 'line_end': 83, 'col_start': 0, 'col_end': 60}
  parent_qualified_name: "None"
  sha_at_sync: "c6cb9886c0cb627e828eb3e65433b3952db7eb4d2ed5d51f720453f849b07bd1"
  description: "Exception handler that handles errors arising from self-signed SSL certificates encountered during API requests."
---
# mps.api.errors.SelfSignedCertificate

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.SelfSignedCertificate


class mps.api.errors.SelfSignedCertificate [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:80-83 :: class SelfSignedCertificate(ExceptionHandler):

Description: Exception handler that handles errors arising from self-signed SSL certificates encountered during API requests.

## Related Documents

- [mps.api.errors.ExceptionHandler](cf4dd7f9-1a77-532c-ba34-3c1194c6363c.md) - Related (graph distance 1.49)
- [mps.api.errors.UnableToGetAuthToken](2fa0fbad-f9c8-5e61-b90e-48175bf78545.md) - Related (graph distance 1.54)
- [mps.api.errors.UnableToStoreCredentialsFile](dd706baa-9f4e-5d89-ab0c-97163e21942b.md) - Related (graph distance 1.59)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.60)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.60)
- [mps.api.errors.InvalidAWSRegion](6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde.md) - Related (graph distance 1.63)
- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 2.86)
- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 2.92)
