---
id: 9a3cc96b-b21c-5a57-a226-4016b151976e
type: catalog
title: "mps.api.token_manager.AWSTokenManager"
created_at: 2026-06-06T18:47:28.315637+00:00
updated_at: 2026-07-03T06:16:14.985864+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.token_manager.AWSTokenManager"
  signature: "class AWSTokenManager(TokenManager):"
  location: {'line_start': 120, 'line_end': 171, 'col_start': 0, 'col_end': 13}
  parent_qualified_name: "None"
  sha_at_sync: "e6e1e8f12a6692fb5c81ac8e8018af5c8ef4c126c388d085805c3a1a26fa51d0"
  description: "Manages authentication tokens for AWS-based services by extending the base TokenManager class, handling token acquisition, caching, and renewal specific to AWS credentials."
---
# mps.api.token_manager.AWSTokenManager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager


class mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:120-171 :: class AWSTokenManager(TokenManager):

Description: Manages authentication tokens for AWS-based services by extending the base TokenManager class, handling token acquisition, caching, and renewal specific to AWS credentials.

## Related Documents

- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.30)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 1.50)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.64)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.64)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 2.80)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 2.85)
- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 2.96)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 3.06)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 3.08)
