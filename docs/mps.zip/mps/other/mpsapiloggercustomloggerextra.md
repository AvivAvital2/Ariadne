---
id: e5111c25-b18e-549c-94fe-78a419034bb6
type: catalog
title: "mps.api.logger.CustomLogger.extra"
created_at: 2026-06-06T18:47:28.691473+00:00
updated_at: 2026-06-20T22:55:24.163074+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.CustomLogger.extra"
  signature: "extra = {}"
  location: {'line_start': 9, 'line_end': 9, 'col_start': 12, 'col_end': 22}
  parent_qualified_name: "mps.api.logger.CustomLogger"
  sha_at_sync: "1a11184f20bc2520da71310c1b1a96f7ebc6056ccc158fe4f2add039db4d8f4e"
  description: "Class-level dictionary attribute on `CustomLogger` that stores extra contextual key-value pairs to be included in log records, initialized as an empty dictionary."
---
# mps.api.logger.CustomLogger.extra

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.CustomLogger.extra


variable mps.api.logger.CustomLogger.extra in mps.api.logger.CustomLogger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:9-9 :: extra = {}

Description: Class-level dictionary attribute on `CustomLogger` that stores extra contextual key-value pairs to be included in log records, initialized as an empty dictionary.

## Related Documents

- [mps.api.logger.CustomLogger.extra['delimiter']](f3678951-3b38-5bbb-93cb-06dcd193a187.md) - Related (graph distance 1.58)
- [mps.api.logger.Logger.log_format](20544901-82a4-5cde-8e92-17ebf78c1ba8.md) - Related (graph distance 3.03)