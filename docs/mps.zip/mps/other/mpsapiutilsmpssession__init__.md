---
id: e5d5dc79-6074-5bee-b16a-413f978e8f4a
type: catalog
title: "mps.api.utils.MPSSession.__init__"
created_at: 2026-06-06T18:47:29.295813+00:00
updated_at: 2026-07-03T06:16:14.999235+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.utils.MPSSession.__init__"
  signature: "def __init__(self, base_url, auth=None, verify=True):"
  location: {'line_start': 15, 'line_end': 19, 'col_start': 4, 'col_end': 28}
  parent_qualified_name: "mps.api.utils.MPSSession"
  sha_at_sync: "dc1ac7a99340f273e75689e505c4bb564fc9b6f5358f2ace4efb0d081ddae56b"
  description: "Initializes an MPSSession instance with a base URL, optional authentication credentials, and an SSL certificate verification flag."
---
# mps.api.utils.MPSSession.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession.__init__


method mps.api.utils.MPSSession.__init__ in mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:15-19 :: def __init__(self, base_url, auth=None, verify=True):

Description: Initializes an MPSSession instance with a base URL, optional authentication credentials, and an SSL certificate verification flag.

## Related Documents

- [mps.api.utils.MPSSession.base_url](21e6face-0081-5442-b611-fbecb7c4adc7.md) - Related (graph distance 1.48)
- [mps.api.token_manager.AWSTokenManager.base_url](12f4babf-5ed5-53e8-8546-6ccbc741379b.md) - Related (graph distance 2.85)
- [mps.api.token_manager.TokenManager.base_url](18254814-cbc1-548b-9217-db5dfc57bc3d.md) - Related (graph distance 2.86)
