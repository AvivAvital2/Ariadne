---
id: be761185-3f99-5091-bd94-e95c5f147d39
type: catalog
title: "mps.api.token_manager.TokenManager.self.session"
created_at: 2026-06-06T18:47:28.317707+00:00
updated_at: 2026-07-03T06:16:14.985197+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.self.session"
  signature: "self.session = MPSSession("
  location: {'line_start': 112, 'line_end': 116, 'col_start': 16, 'col_end': 17}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "18afb8244cce0432339802b5ed615911ea90c5fcf67709437c1d957253628836"
  description: "Instance attribute holding an `MPSSession` object used by `TokenManager` to perform authenticated HTTP requests for token operations."
---
# mps.api.token_manager.TokenManager.self.session

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.self.session


variable mps.api.token_manager.TokenManager.self.session in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:112-116 :: self.session = MPSSession(

Description: Instance attribute holding an `MPSSession` object used by `TokenManager` to perform authenticated HTTP requests for token operations.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 1.10)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.42)
- [mps.api.utils.MPSSession](e7af71c1-4712-58c3-b981-9698f644339f.md) - Related (graph distance 1.50)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 2.58)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.69)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.69)
