---
id: ba3105ec-cf00-5064-85f2-207386a7823a
type: catalog
title: "mps.api.utils.resolve_base_image_id"
created_at: 2026-06-06T18:47:29.297704+00:00
updated_at: 2026-07-03T06:16:15.032575+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.resolve_base_image_id"
  signature: "async def resolve_base_image_id("
  location: {'line_start': 85, 'line_end': 107, 'col_start': 0, 'col_end': 112}
  parent_qualified_name: "None"
  sha_at_sync: "acd8406787603b2a760ae218a9c3c6abc72b4643a34a3ee8848187e388466e95"
  description: "Resolves a base image identifier (which may be a name or ID) to its canonical image ID by querying the available base images. Returns the matching image ID, or raises an error if no matching base image is found."
---
# mps.api.utils.resolve_base_image_id

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.resolve_base_image_id


async_function mps.api.utils.resolve_base_image_id [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:85-107 :: async def resolve_base_image_id(

Description: Resolves a base image identifier (which may be a name or ID) to its canonical image ID by querying the available base images. Returns the matching image ID, or raises an error if no matching base image is found.

## Related Documents

- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 1.40)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 2.92)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 3.02)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 3.04)
