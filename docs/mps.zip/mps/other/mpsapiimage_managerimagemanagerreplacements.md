---
id: b58fe9b3-a6dc-53d5-9c63-c53ea0b79be1
type: catalog
title: "mps.api.image_manager.ImageManager.replacements"
created_at: 2026-06-06T18:47:29.003742+00:00
updated_at: 2026-06-20T22:55:23.929930+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.replacements"
  signature: "replacements = {"
  location: {'line_start': 326, 'line_end': 329, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ecff3849291275b1470c2fb4b22167f2d9b342bb3dba36349c4236ad1494a50c"
  description: "Stores a dictionary mapping placeholder strings to their replacement values, used for substituting tokens within image-related text or paths during processing."
---
# mps.api.image_manager.ImageManager.replacements

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.replacements


variable mps.api.image_manager.ImageManager.replacements in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:326-329 :: replacements = {

Description: Stores a dictionary mapping placeholder strings to their replacement values, used for substituting tokens within image-related text or paths during processing.