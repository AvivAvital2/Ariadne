---
id: 6f98a8fb-a158-538b-b12d-a9eacc2370cb
type: catalog
title: "mps.api.schemas.Flavours.minimal"
created_at: 2026-06-06T18:47:28.912805+00:00
updated_at: 2026-07-03T06:16:15.047190+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.Flavours.minimal"
  signature: "minimal: str"
  location: {'line_start': 7, 'line_end': 7, 'col_start': 4, 'col_end': 16}
  parent_qualified_name: "mps.api.schemas.Flavours"
  sha_at_sync: "09365e4b75ca6383b776113f1f04e205d2733be266a9a30420f65e398e9b72a5"
  description: "Defines the string constant identifying the "minimal" flavour option within the `Flavours` schema, used to select a reduced or lightweight data representation."
---
# mps.api.schemas.Flavours.minimal

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.Flavours.minimal


variable mps.api.schemas.Flavours.minimal in mps.api.schemas.Flavours [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:7-7 :: minimal: str

Description: Defines the string constant identifying the "minimal" flavour option within the `Flavours` schema, used to select a reduced or lightweight data representation.

## Related Documents

- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 1.62)
- [mps.api.schemas.Flavours.osm](158f2dda-ad59-551f-8cb0-3fd7f47d9750.md) - Related (graph distance 1.63)
- [mps.api.utils.flavours](99e4f257-b792-58b1-a023-c7b18602a57e.md) - Related (graph distance 3.07)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 3.08)
- [mps.api.schemas.Flavours.gdata](421f70f2-749b-57fb-802a-4988a0b15516.md) - Related (graph distance 3.22)
