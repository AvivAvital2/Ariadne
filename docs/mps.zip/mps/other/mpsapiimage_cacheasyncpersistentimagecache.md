---
id: 3a3db6c0-be15-545e-8631-b0a1492e556e
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache"
created_at: 2026-06-06T18:47:29.721346+00:00
updated_at: 2026-07-03T06:16:14.947452+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  signature: "class AsyncPersistentImageCache:"
  location: {'line_start': 7, 'line_end': 67, 'col_start': 0, 'col_end': 48}
  parent_qualified_name: "None"
  sha_at_sync: "ffc5fa2850566239990618ba1f20d7406472e270955fc38369e9313a83a7ac06"
  description: "Provides an asynchronous, persistent cache for storing and retrieving images on disk, enabling non-blocking image caching operations."
---
# mps.api.image_cache.AsyncPersistentImageCache

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache


class mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:7-67 :: class AsyncPersistentImageCache:

Description: Provides an asynchronous, persistent cache for storing and retrieving images on disk, enabling non-blocking image caching operations.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 1.40)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.47)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 1.55)
- [mps.api.image_cache.AsyncPersistentImageCache.__aenter__](c6697df2-7934-5a7a-96ef-42333bcee700.md) - Related (graph distance 1.55)
- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 1.56)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 1.65)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 2.92)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 2.94)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.94)
