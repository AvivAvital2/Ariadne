---
id: f080103c-b71d-5917-9709-dde971633bbe
type: catalog
title: "mps.api.utils.output"
created_at: 2026-06-06T18:47:29.300524+00:00
updated_at: 2026-06-20T22:55:23.938572+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.output"
  signature: "output = []"
  location: {'line_start': 38, 'line_end': 38, 'col_start': 8, 'col_end': 19}
  parent_qualified_name: "None"
  sha_at_sync: "b4682db86bedf43eeb751c0e16768a2bbf92dc0729bbc22fdd58c14114411c06"
  description: "Initializes an empty list to accumulate output data at module level."
---
# mps.api.utils.output

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.output


variable mps.api.utils.output [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:38-38 :: output = []

Description: Initializes an empty list to accumulate output data at module level.