---
id: f942b514-970b-5d90-b5d1-f5e5777e2718
type: catalog
title: "mps.api.token_manager.TokenManager.provider"
created_at: 2026-06-06T18:47:28.316677+00:00
updated_at: 2026-07-03T06:16:15.059495+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.provider"
  signature: "self.provider = provider"
  location: {'line_start': 20, 'line_end': 20, 'col_start': 8, 'col_end': 32}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "46720a69f8aa678a1b3835f1be8da798e1bf1de9138e7d17a5bb62f5a7f5dc98"
  description: "Stores the authentication provider instance used by the `TokenManager` to obtain and refresh tokens."
---
# mps.api.token_manager.TokenManager.provider

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.provider


variable mps.api.token_manager.TokenManager.provider in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:20-20 :: self.provider = provider

Description: Stores the authentication provider instance used by the `TokenManager` to obtain and refresh tokens.

## Related Documents

- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 1.46)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.51)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 1.64)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 2.70)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 2.70)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.74)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 2.77)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 2.80)
