---
id: c3594af9-f163-5c08-a19d-854a4ea37cd0
type: catalog
title: "mps.api.image_manager.ImageManager.output, _, _"
created_at: 2026-06-06T18:47:28.999988+00:00
updated_at: 2026-07-03T06:16:15.080259+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.output, _, _"
  signature: "output, _, _ = await run_command(['buildah', 'images', '--format', '{{.Name}}:{{.Tag}} {{.ID}}'])"
  location: {'line_start': 154, 'line_end': 154, 'col_start': 8, 'col_end': 105}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "513a9c198d74b307dba88d3eef58ad42281ec28097fa57e19934a380de3f3687"
  description: "Captures the standard output from running `buildah images` to list available container images with their name, tag, and ID, discarding the command's error output and exit status."
---
# mps.api.image_manager.ImageManager.output, _, _

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.output, _, _


variable mps.api.image_manager.ImageManager.output, _, _ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:154-154 :: output, _, _ = await run_command(['buildah', 'images', '--format', '{{.Name}}:{{.Tag}} {{.ID}}'])

Description: Captures the standard output from running `buildah images` to list available container images with their name, tag, and ID, discarding the command's error output and exit status.

## Related Documents

- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 1.25)
- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 1.39)
- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 1.50)
- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 1.51)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 1.53)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 1.60)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 2.94)
- [mps.api.utils.stdout, stderr](c763f4e0-50eb-503d-abbf-927541162a1b.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 3.09)
