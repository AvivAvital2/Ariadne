---
id: bf2dd824-700b-53e4-aea7-29002bb142db
type: catalog
title: "mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__"
created_at: 2026-06-06T18:47:29.761979+00:00
updated_at: 2026-07-03T06:16:15.095277+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 92, 'line_end': 93, 'col_start': 4, 'col_end': 86}
  parent_qualified_name: "mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry"
  sha_at_sync: "b58c4f308e9ca1866d1c5d13ef181967e19c2088cbc392dfab011c01908fdad8"
  description: "Initializes the `UnableToObtainPushedImagesFromContainerRegistry` exception with a descriptive error message."
---
# mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__


method mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__ in mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:92-93 :: def __init__(self, message: str):

Description: Initializes the `UnableToObtainPushedImagesFromContainerRegistry` exception with a descriptive error message.

## Related Documents

- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.14)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.18)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.22)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.22)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.24)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.31)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 1.31)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 1.53)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.35)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.41)
