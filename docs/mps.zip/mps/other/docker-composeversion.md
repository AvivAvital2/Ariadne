---
id: 1b1c7a0c-150d-54a3-9086-48c94e44be28
type: catalog
title: "docker-compose.version"
created_at: 2026-06-06T18:47:25.530053+00:00
updated_at: 2026-06-20T22:55:24.892913+00:00
source_files:
  - /Users/spark/git/service-model-promotion/docker-compose.yml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: "docker-compose.version"
  signature: "version: '3.9'"
  location: {'line_start': 1, 'line_end': 1, 'col_start': 0, 'col_end': 14}
  parent_qualified_name: "docker-compose"
  sha_at_sync: "c2dd0e3f0a201da44c595135ed35bf26d717a55ba992e13eea5048668aa58722"
  description: "Specifies the Docker Compose file format version as 3.9, determining which configuration features and syntax are supported by the Compose specification."
---
# docker-compose.version

**Related files:**
- `/Users/spark/git/service-model-promotion/docker-compose.yml`

# docker-compose.version


yaml_key docker-compose.version in docker-compose [yaml] /Users/spark/git/service-model-promotion/docker-compose.yml:1-1 :: version: '3.9'

Description: Specifies the Docker Compose file format version as 3.9, determining which configuration features and syntax are supported by the Compose specification.