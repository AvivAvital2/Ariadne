---
id: bb8fd6f8-d27b-5d1d-8d84-553e051a13de
type: catalog
title: "mps.api.image_manager.ImageManager.self.local_image_cache"
created_at: 2026-06-06T18:47:28.994720+00:00
updated_at: 2026-07-03T06:16:15.018266+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.self.local_image_cache"
  signature: "self.local_image_cache = AsyncPersistentImageCache()"
  location: {'line_start': 22, 'line_end': 22, 'col_start': 8, 'col_end': 60}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6ee1252f9662e7fbb79b9a41547ae389c47377cb8e40853b1e88676602c307f0"
  description: "Instance attribute that holds an `AsyncPersistentImageCache` for storing and retrieving images locally with asynchronous, persistent caching."
---
# mps.api.image_manager.ImageManager.self.local_image_cache

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.self.local_image_cache


variable mps.api.image_manager.ImageManager.self.local_image_cache in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:22-22 :: self.local_image_cache = AsyncPersistentImageCache()

Description: Instance attribute that holds an `AsyncPersistentImageCache` for storing and retrieving images locally with asynchronous, persistent caching.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 1.43)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 1.47)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 1.49)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.51)
- [mps.api.image_cache.AsyncPersistentImageCache.self.conn](b23eeb5a-2004-5f5d-9a28-8bee812c752d.md) - Related (graph distance 1.51)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 1.53)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 1.59)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 2.78)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.81)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 2.92)
