---
id: 55615e34-e793-58a6-856c-246019e7536b
type: catalog
title: "mps.api.image_manager.ImageManager.images"
created_at: 2026-06-06T18:47:29.000246+00:00
updated_at: 2026-07-03T06:16:14.971996+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.images"
  signature: "images = {"
  location: {'line_start': 165, 'line_end': 168, 'col_start': 12, 'col_end': 13}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6922bb7384034668e9f329762dbd39377ff530089d0bc7e03475b6037a2f2518"
  description: "A dictionary attribute of the `ImageManager` class that stores and tracks managed image instances, keyed by their identifiers."
---
# mps.api.image_manager.ImageManager.images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.images


variable mps.api.image_manager.ImageManager.images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:165-168 :: images = {

Description: A dictionary attribute of the `ImageManager` class that stores and tracks managed image instances, keyed by their identifiers.

## Related Documents

- [mps.api.image_manager.ImageManager.stored_images](e9031a30-a2eb-54a4-bdcb-034b6e0bc3be.md) - Related (graph distance 1.22)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.52)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.62)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 2.88)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 2.95)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 3.05)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 3.08)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 3.08)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 3.09)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 3.12)
