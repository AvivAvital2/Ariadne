---
id: a417d983-8e28-583b-9445-be9ea78af9e2
type: catalog
title: "documentation.README_standalone.loading_the_eps_docker_artifacts"
created_at: 2026-06-06T18:47:26.286261+00:00
updated_at: 2026-06-20T22:55:21.988071+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.loading_the_eps_docker_artifacts"
  signature: "#### Loading the EPS Docker artifacts"
  location: {'line_start': 226, 'line_end': 274, 'col_start': 0, 'col_end': 37}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "5d9506cb7fe608743301cc708a63ae366e339c01e651e73466965f02eb336235"
  description: "Provides instructions for loading the EPS Docker image artifacts from saved files into a local Docker registry, typically using the `docker load` command to restore pre-built container images for standalone deployment."
---
# documentation.README_standalone.loading_the_eps_docker_artifacts

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.loading_the_eps_docker_artifacts


md_section documentation.README_standalone.loading_the_eps_docker_artifacts in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:226-274 :: #### Loading the EPS Docker artifacts

Description: Provides instructions for loading the EPS Docker image artifacts from saved files into a local Docker registry, typically using the `docker load` command to restore pre-built container images for standalone deployment.