---
id: 235b8a53-2362-56d9-ab74-c5209a1b4c88
type: catalog
title: "mps.api.token_manager.TokenManager._write_credentials_to_file"
created_at: 2026-06-06T18:47:28.313455+00:00
updated_at: 2026-07-03T06:16:14.994509+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.TokenManager._write_credentials_to_file"
  signature: "def _write_credentials_to_file(self, stored_credentials: dict):"
  location: {'line_start': 67, 'line_end': 70, 'col_start': 4, 'col_end': 55}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "f33edb85d3922b6aed36441b9ebe5f39bb0fc664b6bfc2f16f6d05bc45a6c5eb"
  description: "Writes the provided credentials dictionary to the token manager's credentials file, persisting authentication data for later retrieval."
---
# mps.api.token_manager.TokenManager._write_credentials_to_file

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager._write_credentials_to_file


method mps.api.token_manager.TokenManager._write_credentials_to_file in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:67-70 :: def _write_credentials_to_file(self, stored_credentials: dict):

Description: Writes the provided credentials dictionary to the token manager's credentials file, persisting authentication data for later retrieval.

## Related Documents

- [mps.api.token_manager.TokenManager.stored_credentials](6118c04d-ef3d-537e-a04b-20a6f6cf3f21.md) - Related (graph distance 1.66)
- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 3.22)
