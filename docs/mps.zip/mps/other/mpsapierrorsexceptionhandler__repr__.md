---
id: 354a3d34-fb7e-59f5-9c8c-7dab844609a6
type: catalog
title: "mps.api.errors.ExceptionHandler.__repr__"
created_at: 2026-06-06T18:47:29.758063+00:00
updated_at: 2026-07-03T06:16:14.938789+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.ExceptionHandler.__repr__"
  signature: "def __repr__(self):  # pragma: no cover"
  location: {'line_start': 12, 'line_end': 14, 'col_start': 4, 'col_end': 65}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "24cb05f480eee1ab5a945ca8335edf70b6d0bf97037dd43523ec0cd9f8d80d3a"
  description: "Returns a string representation of the ExceptionHandler instance for debugging purposes."
---
# mps.api.errors.ExceptionHandler.__repr__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.__repr__


method mps.api.errors.ExceptionHandler.__repr__ in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:12-14 :: def __repr__(self):  # pragma: no cover

Description: Returns a string representation of the ExceptionHandler instance for debugging purposes.

## Related Documents

- [mps.api.errors.ExceptionHandler.__str__](98eb7392-e75e-559e-9e37-cba956652a02.md) - Related (graph distance 1.12)
- [mps.api.errors.ExceptionHandler.exception_handler](3529722b-ea7e-531f-badf-5c1480baf8aa.md) - Related (graph distance 1.55)
