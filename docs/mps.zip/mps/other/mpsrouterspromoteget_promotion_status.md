---
id: 1f61f6fb-ba29-543e-a7b7-e7df6fb4a9bf
type: catalog
title: "mps.routers.promote.get_promotion_status"
created_at: 2026-06-06T18:47:27.614482+00:00
updated_at: 2026-07-03T06:16:15.016690+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.promote.get_promotion_status"
  signature: "async def get_promotion_status():"
  location: {'line_start': 21, 'line_end': 23, 'col_start': 0, 'col_end': 8}
  parent_qualified_name: "None"
  sha_at_sync: "41dc383ddc744ecd5765cc23522bdb07887f5290133959d995f932f4e1218792"
  description: "Asynchronously retrieves and returns the current status of a promotion operation."
---
# mps.routers.promote.get_promotion_status

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.get_promotion_status


async_function mps.routers.promote.get_promotion_status [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:21-23 :: async def get_promotion_status():

Description: Asynchronously retrieves and returns the current status of a promotion operation.

## Related Documents

- [mps.routers.promote.promote](670180bb-83e4-519e-853e-cefa8b7d4fd6.md) - Related (graph distance 1.54)
