---
id: 4bc2066b-0f3d-554e-88dc-2177cfd1d9df
type: catalog
title: "mps.api.schemas.PromoteParams.linkedDataCore"
created_at: 2026-06-06T18:47:28.915480+00:00
updated_at: 2026-06-20T22:55:23.177891+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.PromoteParams.linkedDataCore"
  signature: "linkedDataCore: bool = False"
  location: {'line_start': 27, 'line_end': 27, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "mps.api.schemas.PromoteParams"
  sha_at_sync: "12ddda3728a2367f6b8ca47dbc2b378ce0d99117278e6d3a9a5379b04143bed4"
  description: "Boolean flag indicating whether the linked data core should be included in the promotion operation, defaulting to `False`."
---
# mps.api.schemas.PromoteParams.linkedDataCore

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams.linkedDataCore


variable mps.api.schemas.PromoteParams.linkedDataCore in mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:27-27 :: linkedDataCore: bool = False

Description: Boolean flag indicating whether the linked data core should be included in the promotion operation, defaulting to `False`.