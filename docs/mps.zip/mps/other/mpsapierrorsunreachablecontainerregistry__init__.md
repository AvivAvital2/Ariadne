---
id: 8ce03501-19f0-51a6-8629-34bda8172c4b
type: catalog
title: "mps.api.errors.UnreachableContainerRegistry.__init__"
created_at: 2026-06-06T18:47:29.760962+00:00
updated_at: 2026-07-03T06:16:15.113366+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnreachableContainerRegistry.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 71, 'line_end': 72, 'col_start': 4, 'col_end': 67}
  parent_qualified_name: "mps.api.errors.UnreachableContainerRegistry"
  sha_at_sync: "599567539d87262a57163749d85a35773d47ce39989be43606e5364d9d1709a8"
  description: "Initializes an UnreachableContainerRegistry exception with the provided error message describing why the container registry could not be reached."
---
# mps.api.errors.UnreachableContainerRegistry.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnreachableContainerRegistry.__init__


method mps.api.errors.UnreachableContainerRegistry.__init__ in mps.api.errors.UnreachableContainerRegistry [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:71-72 :: def __init__(self, message: str):

Description: Initializes an UnreachableContainerRegistry exception with the provided error message describing why the container registry could not be reached.

## Related Documents

- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.14)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.23)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.29)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.30)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.32)
- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 1.40)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.32)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.45)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.45)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.45)
