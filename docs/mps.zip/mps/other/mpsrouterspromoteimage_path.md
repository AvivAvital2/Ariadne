---
id: 95156ea1-61e6-5355-83d3-d882569289a2
type: catalog
title: "mps.routers.promote.image_path"
created_at: 2026-06-06T18:47:27.625168+00:00
updated_at: 2026-07-03T06:16:15.116499+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.image_path"
  signature: "image_path = await mps.image_manager.get_if_image_exists(full_image_path)"
  location: {'line_start': 35, 'line_end': 35, 'col_start': 8, 'col_end': 81}
  parent_qualified_name: "None"
  sha_at_sync: "2cdd31201063e1ce1d4f246ebc4af2ee7751ca7fe4b1ae954ec7d748a3b6d030"
  description: "Retrieves the path to an existing image at the specified location, returning it if the image exists via the image manager's asynchronous existence check."
---
# mps.routers.promote.image_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.image_path


variable mps.routers.promote.image_path [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:35-35 :: image_path = await mps.image_manager.get_if_image_exists(full_image_path)

Description: Retrieves the path to an existing image at the specified location, returning it if the image exists via the image manager's asynchronous existence check.

## Related Documents

- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.38)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 1.49)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.cached_image](a5ca95c2-654d-5604-a500-9de6a73fb4c6.md) - Related (graph distance 1.57)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 2.83)
- [mps.routers.promote.tag](29a0e745-d4bd-5b5f-b2c7-8ce597d7d251.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 3.01)
- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 3.01)
- [mps.api.utils.resolve_base_image_id](ba3105ec-cf00-5064-85f2-207386a7823a.md) - Related (graph distance 3.04)
