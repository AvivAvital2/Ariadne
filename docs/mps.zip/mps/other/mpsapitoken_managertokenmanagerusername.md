---
id: a6d27e79-ca3c-5599-8890-bea2a8db8106
type: catalog
title: "mps.api.token_manager.TokenManager.username"
created_at: 2026-06-06T18:47:28.316162+00:00
updated_at: 2026-07-03T06:16:14.984532+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.username"
  signature: "username = username if username is not None else self.username"
  location: {'line_start': 73, 'line_end': 73, 'col_start': 8, 'col_end': 70}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "cafcdcb555246403416348e662eeb83af2c52e50d76a7006ee4c078079c0d90b"
  description: "Sets the instance's username attribute to the provided `username` argument if it is not None, otherwise retains the existing `self.username` value."
---
# mps.api.token_manager.TokenManager.username

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.username


variable mps.api.token_manager.TokenManager.username in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:73-73 :: username = username if username is not None else self.username

Description: Sets the instance's username attribute to the provided `username` argument if it is not None, otherwise retains the existing `self.username` value.

## Related Documents

- [mps.api.token_manager.TokenManager.password](0d0a563a-55d1-5500-8d3b-060e938ca7ae.md) - Related (graph distance 1.50)
