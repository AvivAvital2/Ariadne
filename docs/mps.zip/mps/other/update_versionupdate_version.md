---
id: 7633e1c4-0d51-5c43-8f87-46d692e925bd
type: catalog
title: "update_version.update_version"
created_at: 2026-06-06T18:47:25.294839+00:00
updated_at: 2026-06-20T22:55:23.977503+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "function"
  qualified_name: "update_version.update_version"
  signature: "def update_version():"
  location: {'line_start': 5, 'line_end': 16, 'col_start': 0, 'col_end': 34}
  parent_qualified_name: "None"
  sha_at_sync: "7922eea92c890c19947ad6a6db94a9fe8fe6ebde16053240236a80ef6be91dc6"
  description: "Reads the current version from a file, increments it, and writes the updated version back to the file."
---
# update_version.update_version

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# update_version.update_version


function update_version.update_version [python] /Users/spark/git/service-model-promotion/update_version.py:5-16 :: def update_version():

Description: Reads the current version from a file, increments it, and writes the updated version back to the file.