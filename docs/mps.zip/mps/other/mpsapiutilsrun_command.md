---
id: adae925f-b6d7-509d-9307-ee57f91a2e44
type: catalog
title: "mps.api.utils.run_command"
created_at: 2026-06-06T18:47:29.296527+00:00
updated_at: 2026-07-03T06:16:14.934826+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.run_command"
  signature: "async def run_command(command: str | list, supress_errors=False) -> tuple[list, list, int | None]:"
  location: {'line_start': 25, 'line_end': 60, 'col_start': 0, 'col_end': 36}
  parent_qualified_name: "None"
  sha_at_sync: "7e9ddb70e0bfc0e22b71ceb389b44326d21b436dff045e8b2fa69771f43db2e3"
  description: "Asynchronously executes a shell command (string or list) as a subprocess, returning a tuple of its captured stdout lines, stderr lines, and exit code. When `supress_errors` is False, it raises an exception on non-zero exit codes."
---
# mps.api.utils.run_command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.run_command


async_function mps.api.utils.run_command [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:25-60 :: async def run_command(command: str | list, supress_errors=False) -> tuple[list, list, int | None]:

Description: Asynchronously executes a shell command (string or list) as a subprocess, returning a tuple of its captured stdout lines, stderr lines, and exit code. When `supress_errors` is False, it raises an exception on non-zero exit codes.

## Related Documents

- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 1.55)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 3.01)
- [mps.api.utils.stdout, stderr](c763f4e0-50eb-503d-abbf-927541162a1b.md) - Related (graph distance 3.11)
- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 3.12)
