---
id: 83824c80-37f6-5dcd-aabe-a41114b0db3b
type: catalog
title: ".ci.agent-release.metadata"
created_at: 2026-06-06T18:47:26.937224+00:00
updated_at: 2026-06-20T22:55:26.492661+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent-release.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent-release.metadata"
  signature: "metadata:"
  location: {'line_start': 3, 'line_end': 8, 'col_start': 0, 'col_end': 59}
  parent_qualified_name: ".ci.agent-release"
  sha_at_sync: "92fde83d3df244969cef8b2b05c705d986ea73d7aa025e70a9e8d9afac2cf574"
  description: "Defines metadata configuration for the agent-release CI job, such as identifying information or descriptive attributes associated with the release."
---
# .ci.agent-release.metadata

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent-release.yaml`

# .ci.agent-release.metadata


yaml_key .ci.agent-release.metadata in .ci.agent-release [yaml] /Users/spark/git/service-model-promotion/.ci/agent-release.yaml:3-8 :: metadata:

Description: Defines metadata configuration for the agent-release CI job, such as identifying information or descriptive attributes associated with the release.