---
id: 5cdaf73f-5565-5da0-bc7a-a9dc44ac4861
type: catalog
title: "mps.service.MPS.self.registry_addr"
created_at: 2026-06-06T18:47:26.303525+00:00
updated_at: 2026-07-03T06:16:15.084075+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.registry_addr"
  signature: "self.registry_addr = os.getenv("REGISTRY_ADDR", None)"
  location: {'line_start': 11, 'line_end': 11, 'col_start': 8, 'col_end': 61}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "c0c4851b2fe793e51966e999311a8bd09ac47be919c071c61f85bbb8874b6742"
  description: "Stores the registry service address read from the `REGISTRY_ADDR` environment variable, defaulting to `None` if the variable is not set."
---
# mps.service.MPS.self.registry_addr

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.registry_addr


variable mps.service.MPS.self.registry_addr in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:11-11 :: self.registry_addr = os.getenv("REGISTRY_ADDR", None)

Description: Stores the registry service address read from the `REGISTRY_ADDR` environment variable, defaulting to `None` if the variable is not set.

## Related Documents

- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 1.24)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 1.27)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 1.29)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 1.34)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.61)
- [mps.__main__.service_host](a37f5104-a8ca-5d27-8a61-1d2e8fe885a6.md) - Related (graph distance 1.62)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.70)
- [mps.api.token_manager.AWSTokenManager.region_name](1dacb1db-2e0a-5c6d-9346-b1edb16f86d5.md) - Related (graph distance 2.76)
- [mps.api.token_manager.TokenManager.region_name](f1d74add-cad1-572b-a333-d85b1ed35998.md) - Related (graph distance 2.84)
- [mps.__main__.service_port](4a87beee-f4f7-5afb-a01a-deadf7514e7a.md) - Related (graph distance 2.86)
