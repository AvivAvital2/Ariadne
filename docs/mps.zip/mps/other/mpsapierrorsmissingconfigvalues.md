---
id: 04edf404-d21e-5354-b2ae-458a08e7e3f2
type: catalog
title: "mps.api.errors.MissingConfigValues"
created_at: 2026-06-06T18:47:29.769564+00:00
updated_at: 2026-07-03T06:16:15.011288+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.MissingConfigValues"
  signature: "class MissingConfigValues(ExceptionHandler):"
  location: {'line_start': 63, 'line_end': 66, 'col_start': 0, 'col_end': 58}
  parent_qualified_name: "None"
  sha_at_sync: "ad2ec9e9cc8c10d419f75dfdaf340c32d693705d418a35491c0f8d04a90aa183"
  description: "Exception handler that handles cases where required configuration values are absent or undefined."
---
# mps.api.errors.MissingConfigValues

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.MissingConfigValues


class mps.api.errors.MissingConfigValues [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:63-66 :: class MissingConfigValues(ExceptionHandler):

Description: Exception handler that handles cases where required configuration values are absent or undefined.

## Related Documents

- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 1.32)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.35)
- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.41)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.54)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.63)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.73)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.75)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.75)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.81)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 2.81)
