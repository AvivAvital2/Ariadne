---
id: 3bba5028-d5bd-52af-ac03-78e6399101b6
type: catalog
title: "mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry"
created_at: 2026-06-06T18:47:29.771266+00:00
updated_at: 2026-07-03T06:16:15.133256+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry"
  signature: "class UnableToObtainPushedImagesFromContainerRegistry(ExceptionHandler):"
  location: {'line_start': 90, 'line_end': 93, 'col_start': 0, 'col_end': 86}
  parent_qualified_name: None
  sha_at_sync: "2bc6be73d5c06056653e672bf508c0dbe4886d8b89d416f0ec7eeadf7990bf66"
  description: "An exception handler that handles failures when attempting to retrieve pushed images from a container registry."
---
# mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

class mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:90-93 :: class UnableToObtainPushedImagesFromContainerRegistry(ExceptionHandler):

Description: An exception handler that handles failures when attempting to retrieve pushed images from a container registry.

## Related Documents

- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 1.34)
- [mps.api.errors.UnableToUploadOneOrMoreImages](73549085-686e-5207-a376-8c21c11d75c1.md) - Related (graph distance 1.44)
- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 1.49)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.53)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.54)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 2.67)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.72)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.75)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.76)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 2.77)
