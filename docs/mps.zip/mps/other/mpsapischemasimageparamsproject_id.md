---
id: ce27fa6e-ba13-586d-a1d5-8d0f2a89b65e
type: catalog
title: "mps.api.schemas.ImageParams.project_id"
created_at: 2026-06-06T18:47:28.917905+00:00
updated_at: 2026-06-20T22:55:25.489041+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.ImageParams.project_id"
  signature: "project_id: str"
  location: {'line_start': 54, 'line_end': 54, 'col_start': 4, 'col_end': 19}
  parent_qualified_name: "mps.api.schemas.ImageParams"
  sha_at_sync: "ceb77e7e55f16c352d8b8269b1a1ef6fcd21dcc1b0db8c104990076ad12ffe7d"
  description: "Specifies the identifier of the project that the image belongs to or is associated with."
---
# mps.api.schemas.ImageParams.project_id

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.ImageParams.project_id


variable mps.api.schemas.ImageParams.project_id in mps.api.schemas.ImageParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:54-54 :: project_id: str

Description: Specifies the identifier of the project that the image belongs to or is associated with.