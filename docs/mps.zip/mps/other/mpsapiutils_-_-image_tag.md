---
id: de1a3c46-4968-53e2-8bb3-c409205df414
type: catalog
title: "mps.api.utils._, _, image_tag"
created_at: 2026-06-06T18:47:29.303127+00:00
updated_at: 2026-07-03T06:16:15.065868+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils._, _, image_tag"
  signature: "_, _, image_tag = tag.rpartition("/")"
  location: {'line_start': 157, 'line_end': 157, 'col_start': 4, 'col_end': 41}
  parent_qualified_name: "None"
  sha_at_sync: "437e4ee8b786e5072a1dfffe89acbebdaeaf094adb150d8213cb015022eab860"
  description: "Splits the `tag` string on the last forward slash, discarding the prefix portions and assigning the trailing segment (the image tag) to `image_tag`."
---
# mps.api.utils._, _, image_tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils._, _, image_tag


variable mps.api.utils._, _, image_tag [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:157-157 :: _, _, image_tag = tag.rpartition("/")

Description: Splits the `tag` string on the last forward slash, discarding the prefix portions and assigning the trailing segment (the image tag) to `image_tag`.

## Related Documents

- [mps.api.image_manager.ImageManager.repository_and_tag](f8a23958-62d7-5fb0-a1d2-1c99bd4089d6.md) - Related (graph distance 1.44)
- [mps.api.image_manager.ImageManager.repository_name, _, _](981f05af-6aa4-5d43-b007-43e8db1ef287.md) - Related (graph distance 1.46)
- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 3.14)
