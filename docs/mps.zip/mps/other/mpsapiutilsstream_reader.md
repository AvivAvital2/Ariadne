---
id: dc7c93b2-94e9-5fba-91f5-f37a6eb660e4
type: catalog
title: "mps.api.utils.stream_reader"
created_at: 2026-06-06T18:47:29.296826+00:00
updated_at: 2026-07-03T06:16:15.117199+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.stream_reader"
  signature: "async def stream_reader(stream):"
  location: {'line_start': 37, 'line_end': 45, 'col_start': 4, 'col_end': 21}
  parent_qualified_name: "None"
  sha_at_sync: "0c311f9e17c3a55b984278caaf9df57aeebf1f9cda810bd68cc7959e37c4a480"
  description: "Asynchronously reads and yields lines from a stream until it is exhausted, decoding each line and stripping trailing whitespace."
---
# mps.api.utils.stream_reader

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.stream_reader


async_function mps.api.utils.stream_reader [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:37-45 :: async def stream_reader(stream):

Description: Asynchronously reads and yields lines from a stream until it is exhausted, decoding each line and stripping trailing whitespace.

## Related Documents

- [mps.api.utils.line](71f11bba-5fa1-5c48-b6a8-f7d0bf8f4dc4.md) - Related (graph distance 1.52)
