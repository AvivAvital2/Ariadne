---
id: fbb32597-89ea-5e70-9f13-c6c729c197d9
type: catalog
title: "mps.defaults.local_image_cache"
created_at: 2026-06-06T18:47:26.172532+00:00
updated_at: 2026-07-03T06:16:15.101304+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/defaults.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: "mps.defaults.local_image_cache"
  signature: "local_image_cache": {"
  location: {'line_start': 2, 'line_end': 4, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "mps.defaults"
  sha_at_sync: "c0c87d039e56ea868a876dfc7ae2bcb922073d11dd5f0aaeb1d90a737ff5f8f9"
  description: "Configures the default settings for the local image cache used by the MPS (Material Point System or service), defining caching behavior for locally stored images."
---
# mps.defaults.local_image_cache

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/defaults.json`

# mps.defaults.local_image_cache


json_key mps.defaults.local_image_cache in mps.defaults [json] /Users/spark/git/service-model-promotion/mps/defaults.json:2-4 :: "local_image_cache": {

Description: Configures the default settings for the local image cache used by the MPS (Material Point System or service), defining caching behavior for locally stored images.

## Related Documents

- [mps.conf.defaults.local_image_cache](d1c16c36-5d5f-50ac-9f19-a84cbd69a748.md) - Related (graph distance 1.10)
- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 1.39)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 1.41)
- [mps.defaults.general](2544c733-f42f-515c-9797-59ab1130e0a9.md) - Related (graph distance 1.53)
- [mps.conf.defaults.general](c8d74d5e-6366-5eb7-8fa7-09bf252718c2.md) - Related (graph distance 1.56)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 2.92)
