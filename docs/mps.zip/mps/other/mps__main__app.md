---
id: 852e4e9d-3828-5d3a-aa74-fc747bc19fb5
type: catalog
title: "mps.__main__.app"
created_at: 2026-06-06T18:47:26.711119+00:00
updated_at: 2026-07-03T06:16:15.075701+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.app"
  signature: "app = FastAPI(**params)"
  location: {'line_start': 23, 'line_end': 23, 'col_start': 0, 'col_end': 23}
  parent_qualified_name: "None"
  sha_at_sync: "be339697e6967d83e25d9ac018f5e5143d9932b9e71bd55e99911327a3246a63"
  description: "Creates the module-level FastAPI application instance, configured with the unpacked `params` dictionary as constructor arguments."
---
# mps.__main__.app

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.app


variable mps.__main__.app [python] /Users/spark/git/service-model-promotion/mps/__main__.py:23-23 :: app = FastAPI(**params)

Description: Creates the module-level FastAPI application instance, configured with the unpacked `params` dictionary as constructor arguments.

## Related Documents

- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 1.48)
- [mps.__main__.params['openapi_url']](3b58a546-63fd-5121-81ee-76772aeb10e1.md) - Related (graph distance 1.64)
- [mps.__main__.params['docs_url']](c102b626-fa79-565e-a225-3b801d2a0446.md) - Related (graph distance 2.94)
- [mps.__main__.params['redoc_url']](81f9b823-8008-505b-b641-941f04948346.md) - Related (graph distance 3.04)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 3.14)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 3.14)
