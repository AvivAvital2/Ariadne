---
id: da191d67-f3f0-5d1d-b747-ba1b6473f80c
type: catalog
title: "mps.routers.maintenance.router"
created_at: 2026-06-06T18:47:27.297312+00:00
updated_at: 2026-07-03T06:16:15.047890+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.maintenance.router"
  signature: "router = APIRouter(tags=["Maintenance"])"
  location: {'line_start': 9, 'line_end': 9, 'col_start': 0, 'col_end': 40}
  parent_qualified_name: "None"
  sha_at_sync: "3db16ceb7d65aa8cfe1d5eb7fc0f3d3ebc476613a436b5014d1d01755a977c1d"
  description: "Creates an APIRouter instance tagged "Maintenance" for grouping and registering maintenance-related API endpoints."
---
# mps.routers.maintenance.router

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# mps.routers.maintenance.router


variable mps.routers.maintenance.router [python] /Users/spark/git/service-model-promotion/mps/routers/maintenance.py:9-9 :: router = APIRouter(tags=["Maintenance"])

Description: Creates an APIRouter instance tagged "Maintenance" for grouping and registering maintenance-related API endpoints.

## Related Documents

- [mps.routers.promote.router](f3c94327-2a1b-5390-9a08-e423ebc37e8c.md) - Related (graph distance 1.22)
- [mps.routers.basic.router](124f9a48-4686-575b-a662-623f3fafd829.md) - Related (graph distance 1.28)
