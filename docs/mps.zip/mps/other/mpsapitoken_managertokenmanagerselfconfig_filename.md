---
id: c65defa3-423c-5cda-98e9-7be8d7a7c794
type: catalog
title: "mps.api.token_manager.TokenManager.self.config_filename"
created_at: 2026-06-06T18:47:28.317451+00:00
updated_at: 2026-06-20T22:55:23.406845+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.self.config_filename"
  signature: "self.config_filename = f'{os.path.expanduser("~")}/.docker/config.json'"
  location: {'line_start': 23, 'line_end': 23, 'col_start': 8, 'col_end': 79}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "9caa9331a4ce24566ee194a1b58c0d8d3bd3d7e76e9570de68ec57c42cfbe027"
  description: "Stores the absolute path to the Docker configuration file (`config.json`) located in the user's home directory, used for reading or writing authentication tokens."
---
# mps.api.token_manager.TokenManager.self.config_filename

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.self.config_filename


variable mps.api.token_manager.TokenManager.self.config_filename in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:23-23 :: self.config_filename = f'{os.path.expanduser("~")}/.docker/config.json'

Description: Stores the absolute path to the Docker configuration file (`config.json`) located in the user's home directory, used for reading or writing authentication tokens.