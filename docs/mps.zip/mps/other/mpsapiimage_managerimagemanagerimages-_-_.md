---
id: 12b67c71-8fd6-54fb-9cd4-a449099882fd
type: catalog
title: "mps.api.image_manager.ImageManager.images, _, _"
created_at: 2026-06-06T18:47:29.002935+00:00
updated_at: 2026-07-03T06:16:15.049654+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.images, _, _"
  signature: "images, _, _ = await run_command("
  location: {'line_start': 298, 'line_end': 303, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "e3afad56ee7bb61e96d11db485b6fda8e0e72ccfdf00f41aa1e7560fcb11d650"
  description: "Retrieves the list of images by awaiting the `run_command` call, capturing the images output while discarding the two other returned values."
---
# mps.api.image_manager.ImageManager.images, _, _

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.images, _, _


variable mps.api.image_manager.ImageManager.images, _, _ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:298-303 :: images, _, _ = await run_command(

Description: Retrieves the list of images by awaiting the `run_command` call, capturing the images output while discarding the two other returned values.

## Related Documents

- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 1.37)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 1.46)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 1.50)
- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 2.86)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 2.94)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 3.12)
