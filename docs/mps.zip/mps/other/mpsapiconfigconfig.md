---
id: 84bbf7db-daf8-5c7a-bdd6-25c9c683bedc
type: catalog
title: "mps.api.config.config"
created_at: 2026-06-06T18:47:27.701067+00:00
updated_at: 2026-06-20T22:55:23.279003+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.config"
  signature: "config = tomllib.load(f)"
  location: {'line_start': 31, 'line_end': 31, 'col_start': 4, 'col_end': 28}
  parent_qualified_name: "None"
  sha_at_sync: "9c6dec9259a9d3e3090ec4404c6b69aab0cf0d3886909074830695a78cc7f23c"
  description: "Loads and parses the TOML configuration file into a dictionary stored in the module-level `config` variable."
---
# mps.api.config.config

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.config


variable mps.api.config.config [python] /Users/spark/git/service-model-promotion/mps/api/config.py:31-31 :: config = tomllib.load(f)

Description: Loads and parses the TOML configuration file into a dictionary stored in the module-level `config` variable.