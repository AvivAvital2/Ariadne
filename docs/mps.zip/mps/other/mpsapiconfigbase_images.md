---
id: 74d6912f-962d-55aa-b577-6c41224b23e4
type: catalog
title: "mps.api.config.base_images"
created_at: 2026-06-06T18:47:27.701703+00:00
updated_at: 2026-07-03T06:16:15.098858+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.base_images"
  signature: "base_images = config['baseImage']"
  location: {'line_start': 38, 'line_end': 38, 'col_start': 0, 'col_end': 33}
  parent_qualified_name: "None"
  sha_at_sync: "efe2c36778b0137a79eb81ab80cd1d765ea00419be74ce97cc7384e0fbe607b3"
  description: "Stores the base image configuration value extracted from the `baseImage` key of the loaded config dictionary."
---
# mps.api.config.base_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.base_images


variable mps.api.config.base_images [python] /Users/spark/git/service-model-promotion/mps/api/config.py:38-38 :: base_images = config['baseImage']

Description: Stores the base image configuration value extracted from the `baseImage` key of the loaded config dictionary.

## Related Documents

- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.55)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.56)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 1.63)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 2.95)
- [mps.api.utils.resolve_base_image_id](ba3105ec-cf00-5064-85f2-207386a7823a.md) - Related (graph distance 3.02)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 3.03)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 3.07)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 3.07)
- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 3.08)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 3.15)
