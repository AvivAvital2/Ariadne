---
id: e555d1cb-61ea-523a-8284-a3b7183d411a
type: catalog
title: "mps.routers.promote.auxiliary_image_list"
created_at: 2026-06-06T18:47:27.627392+00:00
updated_at: 2026-07-03T06:16:15.107893+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.auxiliary_image_list"
  signature: "auxiliary_image_list = None if not auxiliary_image_string else auxiliary_image_string.split(',')"
  location: {'line_start': 66, 'line_end': 66, 'col_start': 4, 'col_end': 100}
  parent_qualified_name: "None"
  sha_at_sync: "411801c870dab7ef10ba2488f164f23367ac8eaafd09a147dfd40aff1db7b5bc"
  description: "Parses a comma-separated string of auxiliary image names into a list, defaulting to `None` when the input string is empty or falsy."
---
# mps.routers.promote.auxiliary_image_list

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.auxiliary_image_list


variable mps.routers.promote.auxiliary_image_list [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:66-66 :: auxiliary_image_list = None if not auxiliary_image_string else auxiliary_image_string.split(',')

Description: Parses a comma-separated string of auxiliary image names into a list, defaulting to `None` when the input string is empty or falsy.

## Related Documents

- [mps.routers.promote.auxiliary_image_string](d5288d92-39d5-5b40-993d-21eea4d39f9a.md) - Related (graph distance 1.44)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 1.61)
- [mps.routers.promote.annotations_string](308debdb-7c0b-525f-bd1f-94f84cd280e5.md) - Related (graph distance 2.87)
- [mps.routers.promote.algorithm_string](b6417c2f-d7af-5ccf-8a65-d93929bed909.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.aux_images](3ec0e871-543e-5a41-933e-e1aa7b51c8c9.md) - Related (graph distance 3.08)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 3.18)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 3.21)
