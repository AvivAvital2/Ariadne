---
id: 2544c733-f42f-515c-9797-59ab1130e0a9
type: catalog
title: "mps.defaults.general"
created_at: 2026-06-06T18:47:26.173376+00:00
updated_at: 2026-07-03T06:16:14.998537+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/defaults.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: "mps.defaults.general"
  signature: "general": {"
  location: {'line_start': 8, 'line_end': 10, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "mps.defaults"
  sha_at_sync: "c7b5e87f25cf8f728d33742bed6954469b5a9e091131d63d808295d07ef35a3c"
  description: "Defines the default general configuration settings for MPS, nested under the `mps.defaults` section."
---
# mps.defaults.general

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/defaults.json`

# mps.defaults.general


json_key mps.defaults.general in mps.defaults [json] /Users/spark/git/service-model-promotion/mps/defaults.json:8-10 :: "general": {

Description: Defines the default general configuration settings for MPS, nested under the `mps.defaults` section.

## Related Documents

- [mps.conf.defaults.general](c8d74d5e-6366-5eb7-8fa7-09bf252718c2.md) - Related (graph distance 1.04)
- [mps.defaults.local_image_cache](fbb32597-89ea-5e70-9f13-c6c729c197d9.md) - Related (graph distance 1.53)
- [mps.conf.defaults.local_image_cache](d1c16c36-5d5f-50ac-9f19-a84cbd69a748.md) - Related (graph distance 1.54)
- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 1.55)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 1.59)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 3.08)
