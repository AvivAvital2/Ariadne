---
id: c056401c-c3a2-5425-9bc3-ad5d2fbb0573
type: catalog
title: "mps.service.MPS.self.registry_user"
created_at: 2026-06-06T18:47:26.303793+00:00
updated_at: 2026-07-03T06:16:15.094018+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.registry_user"
  signature: "self.registry_user = os.getenv("REGISTRY_USER", None)"
  location: {'line_start': 12, 'line_end': 12, 'col_start': 8, 'col_end': 61}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "df279f9053519d8d026e85b7461bd59ce575d6b2953a0ca5e7ff3ed3b950d7b3"
  description: "Stores the container registry username read from the `REGISTRY_USER` environment variable, defaulting to `None` if not set."
---
# mps.service.MPS.self.registry_user

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.registry_user


variable mps.service.MPS.self.registry_user in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:12-12 :: self.registry_user = os.getenv("REGISTRY_USER", None)

Description: Stores the container registry username read from the `REGISTRY_USER` environment variable, defaulting to `None` if not set.

## Related Documents

- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 1.25)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 1.25)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 1.29)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 1.37)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 1.58)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.58)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.70)
- [mps.api.token_manager.AWSTokenManager.region_name](1dacb1db-2e0a-5c6d-9346-b1edb16f86d5.md) - Related (graph distance 2.79)
- [mps.api.token_manager.TokenManager.region_name](f1d74add-cad1-572b-a333-d85b1ed35998.md) - Related (graph distance 2.87)
- [mps.__main__.service_host](a37f5104-a8ca-5d27-8a61-1d2e8fe885a6.md) - Related (graph distance 2.91)
