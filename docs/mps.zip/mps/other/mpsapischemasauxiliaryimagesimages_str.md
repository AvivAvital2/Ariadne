---
id: 7147aed6-0420-5c1a-b24f-e305d5a9b96f
type: catalog
title: "mps.api.schemas.AuxiliaryImages.images_str"
created_at: 2026-06-06T18:47:28.917010+00:00
updated_at: 2026-07-03T06:16:15.028582+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.AuxiliaryImages.images_str"
  signature: "images_str: str"
  location: {'line_start': 40, 'line_end': 40, 'col_start': 4, 'col_end': 19}
  parent_qualified_name: "mps.api.schemas.AuxiliaryImages"
  sha_at_sync: "bd54ff54906918c0b81c6a831bac9f69100d3d83bbfa85aae55947e6f6936b16"
  description: "Holds a string representation of the auxiliary images, serving as a field within the `AuxiliaryImages` schema."
---
# mps.api.schemas.AuxiliaryImages.images_str

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImages.images_str


variable mps.api.schemas.AuxiliaryImages.images_str in mps.api.schemas.AuxiliaryImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:40-40 :: images_str: str

Description: Holds a string representation of the auxiliary images, serving as a field within the `AuxiliaryImages` schema.

## Related Documents

- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 1.36)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.43)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.49)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.51)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.58)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 2.92)
- [mps.api.schemas.AuxiliaryImage.tag](4c441d3f-7079-518b-9f4c-a8cde1baa7a9.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 2.95)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 2.96)
