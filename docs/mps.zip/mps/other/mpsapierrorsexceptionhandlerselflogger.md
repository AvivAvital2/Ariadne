---
id: e44a3143-66f2-530f-b85e-34ddd1b4545f
type: catalog
title: "mps.api.errors.ExceptionHandler.self.Logger"
created_at: 2026-06-06T18:47:29.771540+00:00
updated_at: 2026-07-03T06:16:15.069641+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.errors.ExceptionHandler.self.Logger"
  signature: "self.Logger = Logger(__name__).logger"
  location: {'line_start': 7, 'line_end': 7, 'col_start': 8, 'col_end': 45}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "70387248df0a48eb004790a7ca1c96aa51aabef4bfdf3b53b842821b3e52a413"
  description: "Initializes the instance's logger by retrieving a configured logger instance scoped to the current module name (`__name__`) for use in exception handling."
---
# mps.api.errors.ExceptionHandler.self.Logger

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.self.Logger


variable mps.api.errors.ExceptionHandler.self.Logger in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:7-7 :: self.Logger = Logger(__name__).logger

Description: Initializes the instance's logger by retrieving a configured logger instance scoped to the current module name (`__name__`) for use in exception handling.

## Related Documents

- [mps.api.logger.Logger._logger](3b7e98d7-bfd2-5dcc-a8af-1078b647c414.md) - Related (graph distance 1.43)
- [mps.api.logger.logger](903b3696-6e75-5071-9f19-6d10a5038da1.md) - Related (graph distance 1.45)
- [mps.api.logger.Logger](b3389511-3834-54f5-836a-78c4848305dc.md) - Related (graph distance 1.53)
- [mps.api.logger.CustomLogger](17135ee0-4e31-5148-b47d-38c3ec5f0a95.md) - Related (graph distance 1.62)
