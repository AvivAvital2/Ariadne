---
id: 293799eb-b745-5578-9c72-96562a54239f
type: catalog
title: "mps.api.image_manager.ImageManager.build_and_push"
created_at: 2026-06-06T18:47:28.984272+00:00
updated_at: 2026-07-03T06:16:14.944649+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.build_and_push"
  signature: "async def build_and_push("
  location: {'line_start': 28, 'line_end': 105, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "79c4aa8a41e20e44a8561225ed68541833002ab90448e963645e114aabb1ff74"
  description: "Builds a Docker image from a specified source and pushes it to a configured container registry, returning details about the resulting image. This asynchronous method handles both the build and push phases as a combined operation."
---
# mps.api.image_manager.ImageManager.build_and_push

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.build_and_push


method mps.api.image_manager.ImageManager.build_and_push in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:28-105 :: async def build_and_push(

Description: Builds a Docker image from a specified source and pushes it to a configured container registry, returning details about the resulting image. This asynchronous method handles both the build and push phases as a combined operation.

## Related Documents

- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 1.41)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.45)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 1.63)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 2.72)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 2.83)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.93)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 2.95)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 2.96)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 2.98)
