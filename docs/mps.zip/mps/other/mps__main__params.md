---
id: fb7a8d60-c8e6-5b24-8660-bc723ec21936
type: catalog
title: "mps.__main__.params"
created_at: 2026-06-06T18:47:26.709747+00:00
updated_at: 2026-07-03T06:16:15.104099+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.params"
  signature: "params = {"
  location: {'line_start': 13, 'line_end': 16, 'col_start': 0, 'col_end': 1}
  parent_qualified_name: "None"
  sha_at_sync: "bd36b1167eea1f34b08b430fec229dd58e54ae540ea0fc8a8e5c77499e85cdc0"
  description: "A dictionary defining default configuration parameters used when running the `mps` module as a script."
---
# mps.__main__.params

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.params


variable mps.__main__.params [python] /Users/spark/git/service-model-promotion/mps/__main__.py:13-16 :: params = {

Description: A dictionary defining default configuration parameters used when running the `mps` module as a script.

## Related Documents

- [mps.__main__.app](852e4e9d-3828-5d3a-aa74-fc747bc19fb5.md) - Related (graph distance 1.48)
- [mps.__main__.params['openapi_url']](3b58a546-63fd-5121-81ee-76772aeb10e1.md) - Related (graph distance 1.51)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 1.66)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 1.67)
- [mps.__main__.params['docs_url']](c102b626-fa79-565e-a225-3b801d2a0446.md) - Related (graph distance 1.67)
- [mps.__main__.params['redoc_url']](81f9b823-8008-505b-b641-941f04948346.md) - Related (graph distance 2.91)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 3.06)
