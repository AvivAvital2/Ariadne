---
id: eab46ef5-e7e4-5266-a8b5-59055da14ef2
type: catalog
title: "mps.api.token_manager.TokenManager.__init__"
created_at: 2026-06-06T18:47:28.313019+00:00
updated_at: 2026-07-03T06:16:15.092539+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.TokenManager.__init__"
  signature: "def __init__("
  location: {'line_start': 13, 'line_end': 65, 'col_start': 4, 'col_end': 95}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "8a5c3a5e24c14bac2b964c46392af81864dbcff087bd0f5b267d2b904d3c72fe"
  description: "Initializes a TokenManager instance, setting up the configuration and state needed to acquire, store, and refresh API authentication tokens."
---
# mps.api.token_manager.TokenManager.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.__init__


method mps.api.token_manager.TokenManager.__init__ in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:13-65 :: def __init__(

Description: Initializes a TokenManager instance, setting up the configuration and state needed to acquire, store, and refresh API authentication tokens.

## Related Documents

- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.50)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 1.60)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.64)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 2.80)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 2.80)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.91)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 3.05)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 3.06)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 3.09)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 3.11)
