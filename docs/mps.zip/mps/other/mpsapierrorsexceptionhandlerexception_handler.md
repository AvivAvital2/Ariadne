---
id: 3529722b-ea7e-531f-badf-5c1480baf8aa
type: catalog
title: "mps.api.errors.ExceptionHandler.exception_handler"
created_at: 2026-06-06T18:47:29.758642+00:00
updated_at: 2026-07-03T06:16:15.121037+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.ExceptionHandler.exception_handler"
  signature: "def exception_handler(self):  # pragma: no cover"
  location: {'line_start': 19, 'line_end': 20, 'col_start': 4, 'col_end': 65}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "762d68033a4213e7cd1e989e1cc5a81808ac54885ddd676da19c729dd2ee793f"
  description: "Returns or provides the exception handler associated with the `ExceptionHandler` instance."
---
# mps.api.errors.ExceptionHandler.exception_handler

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.exception_handler


method mps.api.errors.ExceptionHandler.exception_handler in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:19-20 :: def exception_handler(self):  # pragma: no cover

Description: Returns or provides the exception handler associated with the `ExceptionHandler` instance.

## Related Documents

- [mps.api.errors.ExceptionHandler.__str__](98eb7392-e75e-559e-9e37-cba956652a02.md) - Related (graph distance 1.49)
- [mps.api.errors.ExceptionHandler.__repr__](354a3d34-fb7e-59f5-9c8c-7dab844609a6.md) - Related (graph distance 1.55)
- [mps.api.errors.ExceptionHandler](cf4dd7f9-1a77-532c-ba34-3c1194c6363c.md) - Related (graph distance 1.58)
- [mps.api.errors.ExceptionHandler.sys.excepthook](6e667dc6-8ea0-56f7-a2d0-c2398f428109.md) - Related (graph distance 1.60)
