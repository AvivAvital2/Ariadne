---
id: 3b58a546-63fd-5121-81ee-76772aeb10e1
type: catalog
title: "mps.__main__.params['openapi_url']"
created_at: 2026-06-06T18:47:26.710770+00:00
updated_at: 2026-07-03T06:16:15.064454+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.params['openapi_url']"
  signature: "params['openapi_url'] = '/modelpromotion/openapi.json'"
  location: {'line_start': 21, 'line_end': 21, 'col_start': 4, 'col_end': 58}
  parent_qualified_name: "None"
  sha_at_sync: "33a7dd8ac4ce072388aa3a0be1ed0a5a8091f32c9212e6dfe4f643d381e4d817"
  description: "Sets the OpenAPI schema endpoint URL to `/modelpromotion/openapi.json`, overriding the default location for the API's generated OpenAPI specification."
---
# mps.__main__.params['openapi_url']

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.params['openapi_url']


variable mps.__main__.params['openapi_url'] [python] /Users/spark/git/service-model-promotion/mps/__main__.py:21-21 :: params['openapi_url'] = '/modelpromotion/openapi.json'

Description: Sets the OpenAPI schema endpoint URL to `/modelpromotion/openapi.json`, overriding the default location for the API's generated OpenAPI specification.

## Related Documents

- [mps.__main__.params['docs_url']](c102b626-fa79-565e-a225-3b801d2a0446.md) - Related (graph distance 1.29)
- [mps.__main__.params['redoc_url']](81f9b823-8008-505b-b641-941f04948346.md) - Related (graph distance 1.40)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 1.51)
- [mps.__main__.app](852e4e9d-3828-5d3a-aa74-fc747bc19fb5.md) - Related (graph distance 1.64)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 3.18)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 3.18)
