---
id: 95980ebe-592a-5957-961c-2493a9af8ecf
type: catalog
title: "mps.routers.promote.is_image_exists"
created_at: 2026-06-06T18:47:27.614935+00:00
updated_at: 2026-07-03T06:16:15.034810+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.promote.is_image_exists"
  signature: "async def is_image_exists(params: ImageParams):"
  location: {'line_start': 27, 'line_end': 40, 'col_start': 0, 'col_end': 45}
  parent_qualified_name: "None"
  sha_at_sync: "e3b90870c84fd9040b40d35b9948d42479fd8175ac0186cdb13f10ab632c4f8c"
  description: "Asynchronously checks whether a container image specified by the given `ImageParams` exists in the registry. Returns a boolean indicating the image's existence."
---
# mps.routers.promote.is_image_exists

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.is_image_exists


async_function mps.routers.promote.is_image_exists [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:27-40 :: async def is_image_exists(params: ImageParams):

Description: Asynchronously checks whether a container image specified by the given `ImageParams` exists in the registry. Returns a boolean indicating the image's existence.

## Related Documents

- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 1.45)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.59)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 1.63)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 2.65)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 2.95)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 2.99)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 3.01)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.05)
