---
id: 47cc7f44-2a0a-5cc9-acc8-f7fe5887fa24
type: catalog
title: "README.optional_configure_exported_image_archives"
created_at: 2026-06-06T18:47:25.522009+00:00
updated_at: 2026-06-20T22:55:22.517909+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "README.optional_configure_exported_image_archives"
  signature: "#### (Optional) Configure exported image archives"
  location: {'line_start': 114, 'line_end': 129, 'col_start': 0, 'col_end': 50}
  parent_qualified_name: "README"
  sha_at_sync: "2d2e5fe745f60e03530925850ac4c30c779c9ff41de021e742617e20a76d6dd3"
  description: "Documents how to optionally configure the storage location and settings for exported image archives, typically by setting relevant configuration parameters before running the export process."
---
# README.optional_configure_exported_image_archives

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md`

# README.optional_configure_exported_image_archives


md_section README.optional_configure_exported_image_archives in README [markdown] /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md:114-129 :: #### (Optional) Configure exported image archives

Description: Documents how to optionally configure the storage location and settings for exported image archives, typically by setting relevant configuration parameters before running the export process.