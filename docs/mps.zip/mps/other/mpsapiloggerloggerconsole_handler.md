---
id: 2a3b5941-578c-54de-aa16-2ea79fdfded9
type: catalog
title: "mps.api.logger.Logger.console_handler"
created_at: 2026-06-06T18:47:28.693348+00:00
updated_at: 2026-07-03T06:16:15.088346+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger.console_handler"
  signature: "console_handler = logging.StreamHandler()"
  location: {'line_start': 37, 'line_end': 37, 'col_start': 8, 'col_end': 49}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "1626e99a6db194c905914f655bd8f22db129541140799f50f2e961759a6dd826"
  description: "A `logging.StreamHandler` instance attached to the `Logger` class that directs log output to the console (standard error stream)."
---
# mps.api.logger.Logger.console_handler

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.console_handler


variable mps.api.logger.Logger.console_handler in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:37-37 :: console_handler = logging.StreamHandler()

Description: A `logging.StreamHandler` instance attached to the `Logger` class that directs log output to the console (standard error stream).

## Related Documents

- [mps.api.logger.Logger.console_formatter](10b77a84-a8e9-5196-8d6b-0fd076b45055.md) - Related (graph distance 1.49)
- [mps.api.logger.Logger.file_handler](0027aaf8-fb06-5408-8dde-5fe2c7b80061.md) - Related (graph distance 1.63)
- [mps.api.logger.Logger.file_formatter](602a21af-d0b0-5b18-939a-1112561f8d98.md) - Related (graph distance 2.66)
- [mps.api.logger.Logger.log_format](20544901-82a4-5cde-8e92-17ebf78c1ba8.md) - Related (graph distance 2.98)
