---
id: 73847514-b1fb-5627-8728-c3c254d4f051
type: catalog
title: "mps.api.utils.docker_image_to_file_name"
created_at: 2026-06-06T18:47:29.298570+00:00
updated_at: 2026-07-03T06:16:15.003025+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "function"
  qualified_name: "mps.api.utils.docker_image_to_file_name"
  signature: "def docker_image_to_file_name(tag: str) -> str:"
  location: {'line_start': 156, 'line_end': 158, 'col_start': 0, 'col_end': 38}
  parent_qualified_name: "None"
  sha_at_sync: "578369f33a1f18c61e0fbc4177eb3b3dc083bf955095547c157f501ae42c9ad0"
  description: "Converts a Docker image tag into a filesystem-safe file name by sanitizing characters that are invalid in file names."
---
# mps.api.utils.docker_image_to_file_name

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.docker_image_to_file_name


function mps.api.utils.docker_image_to_file_name [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:156-158 :: def docker_image_to_file_name(tag: str) -> str:

Description: Converts a Docker image tag into a filesystem-safe file name by sanitizing characters that are invalid in file names.

## Related Documents

- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 2.73)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.17)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 3.22)
- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 3.24)
