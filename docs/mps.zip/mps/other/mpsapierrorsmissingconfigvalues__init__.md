---
id: bb2538a2-3351-5fcf-adae-88f9badde3c5
type: catalog
title: "mps.api.errors.MissingConfigValues.__init__"
created_at: 2026-06-06T18:47:29.760710+00:00
updated_at: 2026-07-03T06:16:15.056940+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.MissingConfigValues.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 65, 'line_end': 66, 'col_start': 4, 'col_end': 58}
  parent_qualified_name: "mps.api.errors.MissingConfigValues"
  sha_at_sync: "f39c417821816e5460a3b6fa5c7a6ed60a2c6039bc7b50f06672fd4a5efc483d"
  description: "Initializes a `MissingConfigValues` exception instance with the provided error message string."
---
# mps.api.errors.MissingConfigValues.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.MissingConfigValues.__init__


method mps.api.errors.MissingConfigValues.__init__ in mps.api.errors.MissingConfigValues [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:65-66 :: def __init__(self, message: str):

Description: Initializes a `MissingConfigValues` exception instance with the provided error message string.

## Related Documents

- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.19)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.21)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.21)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.27)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.27)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.28)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.30)
- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 1.30)
- [mps.api.errors.ExceptionHandler.__init__](217d2c38-8594-57a8-b81f-9b6355041445.md) - Related (graph distance 1.42)
