---
id: 667a325b-1850-541b-a628-997e8da32ed0
type: catalog
title: "mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path)"
created_at: 2026-06-06T18:47:29.000535+00:00
updated_at: 2026-07-03T06:16:14.974566+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path)"
  signature: "exists_in_cache, (already_exported, abs_file_path) = await asyncio.gather("
  location: {'line_start': 177, 'line_end': 180, 'col_start': 16, 'col_end': 17}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "bbffafb94ef64e7e88c99a631161fb65551732bdccec9cfa624348358d1602c8"
  description: "Concurrently checks whether an image already exists in the cache and resolves its absolute file path by awaiting two asynchronous operations via `asyncio.gather`."
---
# mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path)

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path)


variable mps.api.image_manager.ImageManager.exists_in_cache, (already_exported, abs_file_path) in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:177-180 :: exists_in_cache, (already_exported, abs_file_path) = await asyncio.gather(

Description: Concurrently checks whether an image already exists in the cache and resolves its absolute file path by awaiting two asynchronous operations via `asyncio.gather`.

## Related Documents

- [mps.api.image_manager.ImageManager.exists_in_cache, already_exported](15197025-e3a5-5852-9444-cec1baadf6c1.md) - Related (graph distance 1.16)
