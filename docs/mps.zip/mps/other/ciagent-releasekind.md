---
id: ac84c433-28a4-508c-bf47-af8e147e4b8d
type: catalog
title: ".ci.agent-release.kind"
created_at: 2026-06-06T18:47:26.936863+00:00
updated_at: 2026-06-20T22:55:25.959899+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent-release.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent-release.kind"
  signature: "kind: Pod"
  location: {'line_start': 2, 'line_end': 2, 'col_start': 0, 'col_end': 9}
  parent_qualified_name: ".ci.agent-release"
  sha_at_sync: "7963e6b7d677f6e80a43adf81f7a779334860f2a8f83ed18f09b7123105ac209"
  description: "Specifies that the CI agent-release resource is a Kubernetes Pod object."
---
# .ci.agent-release.kind

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent-release.yaml`

# .ci.agent-release.kind


yaml_key .ci.agent-release.kind in .ci.agent-release [yaml] /Users/spark/git/service-model-promotion/.ci/agent-release.yaml:2-2 :: kind: Pod

Description: Specifies that the CI agent-release resource is a Kubernetes Pod object.