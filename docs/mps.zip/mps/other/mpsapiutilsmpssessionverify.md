---
id: a5f6ebeb-5d97-5558-b156-7d68c086ca7f
type: catalog
title: "mps.api.utils.MPSSession.verify"
created_at: 2026-06-06T18:47:29.299712+00:00
updated_at: 2026-07-03T06:16:15.045771+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.MPSSession.verify"
  signature: "self.verify = verify"
  location: {'line_start': 19, 'line_end': 19, 'col_start': 8, 'col_end': 28}
  parent_qualified_name: "mps.api.utils.MPSSession"
  sha_at_sync: "85865a41efb6c3f99533f396ef000bb84800494e7333235909418b02f4f96d2e"
  description: "Instance attribute storing the SSL certificate verification setting for the MPSSession's HTTP requests. Controls whether server certificates are validated during connections."
---
# mps.api.utils.MPSSession.verify

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession.verify


variable mps.api.utils.MPSSession.verify in mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:19-19 :: self.verify = verify

Description: Instance attribute storing the SSL certificate verification setting for the MPSSession's HTTP requests. Controls whether server certificates are validated during connections.

## Related Documents

- [mps.api.token_manager.TokenManager.verify_certificate_signing](74dc6ac1-882d-545b-9cb1-41fa08944a4b.md) - Related (graph distance 1.47)
- [mps.service.MPS.self.verify_certificate_signing](f5607b28-3c1e-5f2f-91eb-47ec8057ec6d.md) - Related (graph distance 1.62)
