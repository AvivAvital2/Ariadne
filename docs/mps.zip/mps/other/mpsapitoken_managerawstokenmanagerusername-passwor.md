---
id: 5fc78839-79c2-5b61-a6f6-dc523f392751
type: catalog
title: "mps.api.token_manager.AWSTokenManager.username, password"
created_at: 2026-06-06T18:47:28.321791+00:00
updated_at: 2026-07-03T06:16:15.018901+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.username, password"
  signature: "username, password = token_data.split(':')"
  location: {'line_start': 137, 'line_end': 137, 'col_start': 16, 'col_end': 58}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "73acaa1cd3c7ed5f37dc59d6842980504248fb6caff3d845202a1f56cbd6d7ff"
  description: "Unpacks the colon-delimited token data string into separate username and password variables for AWS authentication."
---
# mps.api.token_manager.AWSTokenManager.username, password

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.username, password


variable mps.api.token_manager.AWSTokenManager.username, password in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:137-137 :: username, password = token_data.split(':')

Description: Unpacks the colon-delimited token data string into separate username and password variables for AWS authentication.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.token_data](c287bc81-4e6b-5205-8504-06eaa703e5c4.md) - Related (graph distance 1.59)
