---
id: 902a7ee2-9f46-53a1-8f0d-766ceb4c012a
type: catalog
title: "mps.api.token_manager.AWSTokenManager.login"
created_at: 2026-06-06T18:47:28.315112+00:00
updated_at: 2026-07-03T06:16:15.012040+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.AWSTokenManager.login"
  signature: "async def login(self):"
  location: {'line_start': 153, 'line_end': 171, 'col_start': 4, 'col_end': 13}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "50383e763575ea36b12b09a0306c4c1f04e584de9764c1c051d8cb0f12c467f1"
  description: "Authenticates with AWS Cognito asynchronously to obtain access credentials, storing the resulting token for subsequent API requests."
---
# mps.api.token_manager.AWSTokenManager.login

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.login


method mps.api.token_manager.AWSTokenManager.login in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:153-171 :: async def login(self):

Description: Authenticates with AWS Cognito asynchronously to obtain access credentials, storing the resulting token for subsequent API requests.

## Related Documents

- [mps.api.token_manager.TokenManager.login](f6c5822f-baca-5af9-b88e-a1a3b0d25885.md) - Related (graph distance 1.23)
- [mps.api.image_manager.ImageManager.login](04480485-a32b-5214-b53a-765a9c9a5dda.md) - Related (graph distance 1.46)
- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 1.55)
- [mps.api.token_manager.TokenManager.get_username_and_password](352275c9-9866-54cf-91e4-d353f05e204e.md) - Related (graph distance 2.81)
- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 3.20)
