---
id: 1942c980-d0ef-57bc-8c64-330f4aa597dc
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.get"
created_at: 2026-06-06T18:47:29.719516+00:00
updated_at: 2026-07-03T06:16:15.010450+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.get"
  signature: "async def get(self, key):"
  location: {'line_start': 26, 'line_end': 34, 'col_start': 4, 'col_end': 48}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "1ede32e5f9208f6239e606e8eca5a2bf0973ecb53a087d17725b0b4b4e6086b2"
  description: "Asynchronously retrieves a cached image by its key, returning the cached value if present or `None` if the key is not found in the persistent cache."
---
# mps.api.image_cache.AsyncPersistentImageCache.get

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.get


method mps.api.image_cache.AsyncPersistentImageCache.get in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:26-34 :: async def get(self, key):

Description: Asynchronously retrieves a cached image by its key, returning the cached value if present or `None` if the key is not found in the persistent cache.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 1.32)
- [mps.api.image_cache.AsyncPersistentImageCache.update](b9099bc1-0ee6-547f-b844-bd21c0c852ea.md) - Related (graph distance 1.43)
- [mps.api.image_cache.AsyncPersistentImageCache.set](5dc502b1-4a0d-5dd1-b13d-94f02f75f05f.md) - Related (graph distance 1.45)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.62)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 1.64)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.69)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.85)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 2.88)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 2.91)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 2.94)
