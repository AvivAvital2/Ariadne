---
id: bfca806c-74e3-5757-843f-a817bf0f1bc8
type: catalog
title: "mps.api.image_manager.ImageManager.docker_image_path"
created_at: 2026-06-06T18:47:28.995771+00:00
updated_at: 2026-07-03T06:16:15.033280+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.docker_image_path"
  signature: "docker_image_path = await self.push_image(docker_image_path)"
  location: {'line_start': 89, 'line_end': 89, 'col_start': 20, 'col_end': 80}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "30058e7e128104a80428b874b01325151b5500b388ba90d9f3abf7f97c155fcb"
  description: "Stores the path or reference to the Docker image after pushing it to a registry, reassigning the original local image path with the result of the `push_image` operation."
---
# mps.api.image_manager.ImageManager.docker_image_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.docker_image_path


variable mps.api.image_manager.ImageManager.docker_image_path in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:89-89 :: docker_image_path = await self.push_image(docker_image_path)

Description: Stores the path or reference to the Docker image after pushing it to a registry, reassigning the original local image path with the result of the `push_image` operation.

## Related Documents

- [mps.api.image_manager.ImageManager.cached_image](a5ca95c2-654d-5604-a500-9de6a73fb4c6.md) - Related (graph distance 1.61)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.61)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 1.66)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 3.00)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 3.08)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 3.12)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 3.17)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 3.17)
