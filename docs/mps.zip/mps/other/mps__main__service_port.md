---
id: 4a87beee-f4f7-5afb-a01a-deadf7514e7a
type: catalog
title: "mps.__main__.service_port"
created_at: 2026-06-06T18:47:26.711451+00:00
updated_at: 2026-07-03T06:16:15.014465+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.service_port"
  signature: "service_port = os.environ.get("SERVICE_PORT", 8010)"
  location: {'line_start': 34, 'line_end': 34, 'col_start': 4, 'col_end': 55}
  parent_qualified_name: "None"
  sha_at_sync: "498c0def882bd8c975f895f95fa735e02147cd83e7b3d460ddaca9255fe71bc0"
  description: "Retrieves the service port from the `SERVICE_PORT` environment variable, defaulting to 8010 if the variable is not set."
---
# mps.__main__.service_port

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.service_port


variable mps.__main__.service_port [python] /Users/spark/git/service-model-promotion/mps/__main__.py:34-34 :: service_port = os.environ.get("SERVICE_PORT", 8010)

Description: Retrieves the service port from the `SERVICE_PORT` environment variable, defaulting to 8010 if the variable is not set.

## Related Documents

- [mps.__main__.service_host](a37f5104-a8ca-5d27-8a61-1d2e8fe885a6.md) - Related (graph distance 1.24)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 2.86)
