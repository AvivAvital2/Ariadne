---
id: 4a12c0ac-f01d-52fb-89a9-1683f10008ec
type: catalog
title: "mps.api.logger.CustomLogger.makeRecord"
created_at: 2026-06-06T18:47:28.689342+00:00
updated_at: 2026-06-20T22:55:22.475900+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.logger.CustomLogger.makeRecord"
  signature: "def makeRecord(self, name, log_level, fn, lno, msg, args, exc_info, func=None, extra=None, sinfo=None):"
  location: {'line_start': 7, 'line_end': 11, 'col_start': 4, 'col_end': 93}
  parent_qualified_name: "mps.api.logger.CustomLogger"
  sha_at_sync: "9a81ce68cb7fe0421bb658ca417463d3dbf3adf37bceab61264fbc10c8bd1489"
  description: "Overrides the standard logging method to create a LogRecord, removing reserved keys from the `extra` dictionary before delegating to the parent implementation to avoid attribute collisions."
---
# mps.api.logger.CustomLogger.makeRecord

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.CustomLogger.makeRecord


method mps.api.logger.CustomLogger.makeRecord in mps.api.logger.CustomLogger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:7-11 :: def makeRecord(self, name, log_level, fn, lno, msg, args, exc_info, func=None, extra=None, sinfo=None):

Description: Overrides the standard logging method to create a LogRecord, removing reserved keys from the `extra` dictionary before delegating to the parent implementation to avoid attribute collisions.