---
id: 3a0402bf-ae9a-5423-92e9-de26c218af6d
type: catalog
title: "update_version.version"
created_at: 2026-06-06T18:47:25.295364+00:00
updated_at: 2026-06-20T22:55:23.425382+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "update_version.version"
  signature: "pyproject["tool"]["poetry"]["version"] = version"
  location: {'line_start': 13, 'line_end': 13, 'col_start': 4, 'col_end': 52}
  parent_qualified_name: "None"
  sha_at_sync: "ce3a3b55a4a8982b51661467651b69a75ce6e4195f000d89aae73883fa9a22d8"
  description: "Assigns the new version string to the Poetry tool's version field within the parsed `pyproject` configuration dictionary, updating the package version in place."
---
# update_version.version

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# update_version.version


variable update_version.version [python] /Users/spark/git/service-model-promotion/update_version.py:13-13 :: pyproject["tool"]["poetry"]["version"] = version

Description: Assigns the new version string to the Poetry tool's version field within the parsed `pyproject` configuration dictionary, updating the package version in place.