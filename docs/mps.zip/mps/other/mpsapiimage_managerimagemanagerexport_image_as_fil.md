---
id: bab0c882-ffa5-5ca9-9c98-1e64c9dc83fa
type: catalog
title: "mps.api.image_manager.ImageManager.export_image_as_file"
created_at: 2026-06-06T18:47:28.994980+00:00
updated_at: 2026-06-20T22:55:22.462209+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.export_image_as_file"
  signature: "self.export_image_as_file: bool = export_image_as_file"
  location: {'line_start': 23, 'line_end': 23, 'col_start': 8, 'col_end': 62}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6e976b8f3b9d0728c50138e373180c604fd023209d300434605f816622c2bb9d"
  description: "A boolean flag on the ImageManager instance indicating whether images should be exported as files. It is initialized from the constructor's `export_image_as_file` parameter."
---
# mps.api.image_manager.ImageManager.export_image_as_file

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.export_image_as_file


variable mps.api.image_manager.ImageManager.export_image_as_file in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:23-23 :: self.export_image_as_file: bool = export_image_as_file

Description: A boolean flag on the ImageManager instance indicating whether images should be exported as files. It is initialized from the constructor's `export_image_as_file` parameter.