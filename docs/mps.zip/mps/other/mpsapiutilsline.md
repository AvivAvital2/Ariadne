---
id: 71f11bba-5fa1-5c48-b6a8-f7d0bf8f4dc4
type: catalog
title: "mps.api.utils.line"
created_at: 2026-06-06T18:47:29.300804+00:00
updated_at: 2026-07-03T06:16:15.101962+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.line"
  signature: "line = await stream.readline()"
  location: {'line_start': 40, 'line_end': 40, 'col_start': 12, 'col_end': 42}
  parent_qualified_name: "None"
  sha_at_sync: "46d198e855f39ebbcaaa65d749d775a9b4d8f23ea343fec69a0a9b1568177c36"
  description: "Reads a single line from the stream asynchronously, awaiting until a complete line (terminated by a newline) is available."
---
# mps.api.utils.line

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.line


variable mps.api.utils.line [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:40-40 :: line = await stream.readline()

Description: Reads a single line from the stream asynchronously, awaiting until a complete line (terminated by a newline) is available.

## Related Documents

- [mps.api.utils.stream_reader](dc7c93b2-94e9-5fba-91f5-f37a6eb660e4.md) - Related (graph distance 1.52)
