---
id: 1db63d01-0836-5b7f-b409-5b08036af4b4
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.self.db_path"
created_at: 2026-06-06T18:47:29.721625+00:00
updated_at: 2026-07-03T06:16:15.083615+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.self.db_path"
  signature: "self.db_path = os.path.join(image_cache_path, 'image_cache.sqlite')"
  location: {'line_start': 9, 'line_end': 9, 'col_start': 8, 'col_end': 75}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "0917dbe5bd91fb55aa9e473eb7b2c0d1a0bfd6099f934f427049000e89615ae5"
  description: "Stores the filesystem path to the SQLite database file (`image_cache.sqlite`) used for persistent image caching, constructed by joining the cache directory with the database filename."
---
# mps.api.image_cache.AsyncPersistentImageCache.self.db_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.self.db_path


variable mps.api.image_cache.AsyncPersistentImageCache.self.db_path in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:9-9 :: self.db_path = os.path.join(image_cache_path, 'image_cache.sqlite')

Description: Stores the filesystem path to the SQLite database file (`image_cache.sqlite`) used for persistent image caching, constructed by joining the cache directory with the database filename.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.self.conn](b23eeb5a-2004-5f5d-9a28-8bee812c752d.md) - Related (graph distance 1.39)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.39)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.59)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.63)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 2.86)
- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 2.91)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 2.95)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 3.00)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 3.00)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 3.07)
