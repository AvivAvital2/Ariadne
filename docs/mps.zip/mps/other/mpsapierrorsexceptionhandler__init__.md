---
id: 217d2c38-8594-57a8-b81f-9b6355041445
type: catalog
title: "mps.api.errors.ExceptionHandler.__init__"
created_at: 2026-06-06T18:47:29.757647+00:00
updated_at: 2026-07-03T06:16:14.941149+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.ExceptionHandler.__init__"
  signature: "def __init__(self, message, status_code=None):"
  location: {'line_start': 6, 'line_end': 10, 'col_start': 4, 'col_end': 38}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "420915e7b432d4d9ccfc97cd4fb9eceefa2ff9b9ab4267ab8667439b3766ba22"
  description: "Initializes an ExceptionHandler instance with an error message and an optional HTTP status code, defaulting the status code when none is provided."
---
# mps.api.errors.ExceptionHandler.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.__init__


method mps.api.errors.ExceptionHandler.__init__ in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:6-10 :: def __init__(self, message, status_code=None):

Description: Initializes an ExceptionHandler instance with an error message and an optional HTTP status code, defaulting the status code when none is provided.

## Related Documents

- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 1.27)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.41)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.42)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.44)
- [mps.api.errors.ExceptionHandler.status_code](88dd3367-9cf9-5083-b43e-f70b775a7562.md) - Related (graph distance 1.52)
- [mps.api.errors.ExceptionHandler.message](26783d80-9b8e-57d1-a7cd-c7ccfa993d2d.md) - Related (graph distance 1.61)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.58)
