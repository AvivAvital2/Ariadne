---
id: 731b576a-3b5d-5ea0-a28e-75b7fc357339
type: gotcha
title: "Basic Gotchas"
created_at: 2026-06-06T19:04:22.217841+00:00
updated_at: 2026-06-20T22:55:22.102234+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  module_name: "mps.routers.basic"
  language: "python"
  source_name: "mps"
---
# Basic Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# Basic Gotchas


# Gotchas and Pitfalls: `mps.routers.basic`

### Duplicate function name `ping` silently shadows the first
**Trigger:** Two functions are both named `ping` in the same module. The second definition rebinds the name `ping`, shadowing the first. While FastAPI still registers both routes (because the decorator captures each function object before rebinding), any code that imports or references `ping` by name will only get the second one.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Give each handler a unique name (e.g., `healthcheck` and `modelpromotion_ping`).
**Category:** framework
**Example:**
```python
from mps.routers.basic import ping  # always the "/modelpromotion/ping" one
# The "/healthcheck" handler is unreachable by name; testing/mocking is confusing

# Fix:
@router.get("/healthcheck")
async def healthcheck():
    return PlainTextResponse("OK")
```

### Unhandled file-not-found / IO errors return 500 with stack trace
**Trigger:** `aiofiles.open("conf/build.info", ...)` raises `FileNotFoundError` if the file is missing (e.g., wrong working directory in container/CI). This propagates as an unhandled exception → generic 500.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Catch IO errors and return a structured error, or fail fast at startup if the file is required.
**Category:** framework
**Example:**
```python
try:
    async with aiofiles.open("conf/build.info", mode="r") as f:
        data = await f.read()
except FileNotFoundError:
    return JSONResponse({"error": "build.info missing"}, status_code=503)
```

### Relative path depends on process CWD, not module location
**Trigger:** `"conf/build.info"` is resolved relative to the *current working directory* of the process, not relative to the source file. Running from a different directory (uvicorn from project root vs. a subfolder, Docker, systemd) breaks it silently in some environments and works in others.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Resolve the path relative to a known anchor.
**Category:** framework
**Example:**
```python
from pathlib import Path
BUILD_INFO = Path(__file__).resolve().parents[2] / "conf" / "build.info"
async with aiofiles.open(BUILD_INFO, mode="r") as f:
    ...
```

### `json.loads` is synchronous — blocks the event loop on large/malformed files
**Trigger:** You async-read the file (non-blocking) but then call `json.loads(data)` synchronously. For large files this blocks the entire event loop. Worse, a malformed file raises `json.JSONDecodeError` (a subclass of `ValueError`) → unhandled 500.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Guard the parse; the async read benefit is largely wasted on a tiny config file anyway (consider caching).
**Category:** async
**Example:**
```python
try:
    content = json.loads(data)
except json.JSONDecodeError:
    return JSONResponse({"error": "invalid build.info"}, status_code=500)
return JSONResponse(content=content)
```

### File re-read on every request — no caching
**Trigger:** `build.info` is opened and parsed on *every* call to `/modelpromotion/buildInfo`. Build info is effectively immutable for the process lifetime, so this is pure overhead plus repeated event-loop blocking.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Load once at startup (lifespan/module load) and serve from memory.
**Category:** performance
**Example:**
```python
_build_info: dict | None = None

@router.get("/modelpromotion/buildInfo")
async def build_info():
    global _build_info
    if _build_info is None:
        async with aiofiles.open(BUILD_INFO) as f:
            _build_info = json.loads(await f.read())
    return JSONResponse(content=_build_info)
```

### `json.loads` accepts non-dict JSON, but `JSONResponse(content=...)` will serialize anything
**Trigger:** If `build.info` contains a JSON array or scalar (e.g., `"hello"` or `[1,2,3]`), `json.loads` succeeds and `JSONResponse` happily returns it. Downstream consumers expecting an object get a surprising shape with no validation.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Validate the parsed type (or use a Pydantic model) before returning.
**Category:** type-system
**Example:**
```python
content = json.loads(data)
if not isinstance(content, dict):
    return JSONResponse({"error": "expected JSON object"}, status_code=500)
```

### Module-level concurrent first-load race (if caching is added naively)
**Trigger:** If you add lazy caching (as above) without synchronization, multiple concurrent first requests can each enter the `if _build_info is None` branch and read the file concurrently. Usually harmless here, but it defeats the "load once" intent and can interleave under heavy startup load.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Load eagerly in a startup/lifespan handler, or guard with an `asyncio.Lock`.
**Category:** thread-safety
**Example:**
```python
_lock = asyncio.Lock()
async def build_info():
    async with _lock:
        if _build_info is None:
            ...  # load
```

### `HTTP_200_OK` is redundant — masks intent and inconsistency
**Trigger:** `JSONResponse` already defaults to `status_code=200`. Explicitly passing `HTTP_200_OK` here while the other endpoints rely on defaults creates inconsistent style and the false impression that status handling matters (it doesn't, since errors aren't handled).
**Affected Files:** `mps/routers/basic.py`
**Fix:** Drop the explicit 200 or, better, add real status codes for the error paths above.
**Category:** framework
**Example:**
```python
# Misleading: implies status logic, but 200 is the default
return JSONResponse(content=json.loads(data), status_code=HTTP_200_OK)
```

### Inconsistent health-check casing/conventions (`OK` vs `Pong`)
**Trigger:** `/healthcheck` returns `"OK"` and `/modelpromotion/ping` returns `"Pong"`. Monitoring tooling that string-matches health responses may break depending on which endpoint it hits.
**Affected Files:** `mps/routers/basic.py`
**Fix:** Standardize health-check response bodies/conventions across endpoints.
**Category:** domain
**Example:**
```python
# Two "ping"-like endpoints with different bodies — pick one convention
return PlainTextResponse("OK")    # /healthcheck
return PlainTextResponse("Pong")  # /modelpromotion/ping
```