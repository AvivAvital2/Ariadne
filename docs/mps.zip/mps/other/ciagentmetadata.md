---
id: 725eadcc-c5ec-57f1-acd5-d62ac92480b5
type: catalog
title: ".ci.agent.metadata"
created_at: 2026-06-06T18:47:26.696180+00:00
updated_at: 2026-06-20T22:55:25.729927+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent.metadata"
  signature: "metadata:"
  location: {'line_start': 3, 'line_end': 5, 'col_start': 0, 'col_end': 22}
  parent_qualified_name: ".ci.agent"
  sha_at_sync: "4c3d8c7f9085f3c53c9b2f276f2d6ddf28e6b3f446e7260cf3577fddc70ce5a2"
  description: "Defines metadata configuration for the CI agent, such as labels or annotations applied to the agent instance."
---
# .ci.agent.metadata

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent.yaml`

# .ci.agent.metadata


yaml_key .ci.agent.metadata in .ci.agent [yaml] /Users/spark/git/service-model-promotion/.ci/agent.yaml:3-5 :: metadata:

Description: Defines metadata configuration for the CI agent, such as labels or annotations applied to the agent instance.