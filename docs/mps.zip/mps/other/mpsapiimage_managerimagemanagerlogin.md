---
id: 04480485-a32b-5214-b53a-765a9c9a5dda
type: catalog
title: "mps.api.image_manager.ImageManager.login"
created_at: 2026-06-06T18:47:28.983966+00:00
updated_at: 2026-07-03T06:16:14.989185+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.login"
  signature: "async def login(self):"
  location: {'line_start': 25, 'line_end': 26, 'col_start': 4, 'col_end': 40}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "a9b748ffd5b280d2133c961d07663c4337abc16911475fe0508397a35a5da35d"
  description: "Authenticates the `ImageManager` instance asynchronously to establish access to the image API."
---
# mps.api.image_manager.ImageManager.login

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.login


method mps.api.image_manager.ImageManager.login in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:25-26 :: async def login(self):

Description: Authenticates the `ImageManager` instance asynchronously to establish access to the image API.

## Related Documents

- [mps.api.token_manager.TokenManager.login](f6c5822f-baca-5af9-b88e-a1a3b0d25885.md) - Related (graph distance 1.35)
- [mps.api.token_manager.AWSTokenManager.login](902a7ee2-9f46-53a1-8f0d-766ceb4c012a.md) - Related (graph distance 1.46)
- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 3.01)
