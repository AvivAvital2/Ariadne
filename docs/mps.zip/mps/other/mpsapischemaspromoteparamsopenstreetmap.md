---
id: 2630d7f9-4c38-5da1-9833-05017980b23d
type: catalog
title: "mps.api.schemas.PromoteParams.openStreetMap"
created_at: 2026-06-06T18:47:28.916101+00:00
updated_at: 2026-06-20T22:55:23.117033+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.PromoteParams.openStreetMap"
  signature: "openStreetMap: bool = False"
  location: {'line_start': 29, 'line_end': 29, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "mps.api.schemas.PromoteParams"
  sha_at_sync: "56c512e793952fa9ded0699d587036b4d05c24c99da514889b0b3513e1e98a88"
  description: "Boolean flag indicating whether to promote or include OpenStreetMap data, defaulting to `False`."
---
# mps.api.schemas.PromoteParams.openStreetMap

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams.openStreetMap


variable mps.api.schemas.PromoteParams.openStreetMap in mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:29-29 :: openStreetMap: bool = False

Description: Boolean flag indicating whether to promote or include OpenStreetMap data, defaulting to `False`.