---
id: 3011a42d-280b-5c01-ac37-84ac971d22b0
type: catalog
title: "mps.service.MPS.self.token_manager"
created_at: 2026-06-06T18:47:26.304891+00:00
updated_at: 2026-07-03T06:16:14.937220+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.token_manager"
  signature: "self.token_manager = self.get_token_manager()"
  location: {'line_start': 17, 'line_end': 17, 'col_start': 8, 'col_end': 53}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "a1edb0a6d41aaa3d37f8a20aee43d0b94a5deb98361475e5b4a1f26675eb3c93"
  description: "Instance attribute holding the token manager object returned by `get_token_manager()`, used by the MPS service to handle authentication tokens."
---
# mps.service.MPS.self.token_manager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.token_manager


variable mps.service.MPS.self.token_manager in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:17-17 :: self.token_manager = self.get_token_manager()

Description: Instance attribute holding the token manager object returned by `get_token_manager()`, used by the MPS service to handle authentication tokens.

## Related Documents

- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.17)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 1.27)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.41)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 1.42)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 1.45)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 1.47)
- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 1.47)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 1.57)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 1.60)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 1.64)
