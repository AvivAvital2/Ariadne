---
id: 5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9
type: catalog
title: "mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache"
created_at: 2026-06-06T18:47:28.985328+00:00
updated_at: 2026-07-03T06:16:15.044391+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache"
  signature: "async def check_if_image_tag_exists_in_cache(self, tag):"
  location: {'line_start': 213, 'line_end': 217, 'col_start': 4, 'col_end': 52}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "9ac5fa1dafe3bde0fee14e5efca2523c6ada528e7184ad6d3baa252e8ea9b6fd"
  description: "Checks whether an image with the specified tag exists in the cache, returning a boolean result asynchronously."
---
# mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache


method mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:213-217 :: async def check_if_image_tag_exists_in_cache(self, tag):

Description: Checks whether an image with the specified tag exists in the cache, returning a boolean result asynchronously.

## Related Documents

- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 1.19)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 1.19)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.26)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 1.33)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 1.38)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 1.63)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 2.64)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 2.88)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 2.92)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.96)
