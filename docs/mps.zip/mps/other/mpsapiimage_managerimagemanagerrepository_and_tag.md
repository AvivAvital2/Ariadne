---
id: f8a23958-62d7-5fb0-a1d2-1c99bd4089d6
type: catalog
title: "mps.api.image_manager.ImageManager.repository_and_tag"
created_at: 2026-06-06T18:47:28.999450+00:00
updated_at: 2026-07-03T06:16:15.114947+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.repository_and_tag"
  signature: "repository_and_tag = parsed_tag.path.lstrip('/')"
  location: {'line_start': 140, 'line_end': 140, 'col_start': 12, 'col_end': 60}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ce3f9b471d10b6956d5106e24c184ebac5bf9e88468d8820333bcedea5b211db"
  description: "Strips the leading slash from the parsed tag's path to produce the repository and tag string for the Docker image."
---
# mps.api.image_manager.ImageManager.repository_and_tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.repository_and_tag


variable mps.api.image_manager.ImageManager.repository_and_tag in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:140-140 :: repository_and_tag = parsed_tag.path.lstrip('/')

Description: Strips the leading slash from the parsed tag's path to produce the repository and tag string for the Docker image.

## Related Documents

- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 1.33)
- [mps.api.image_manager.ImageManager.repository_name, _, _](981f05af-6aa4-5d43-b007-43e8db1ef287.md) - Related (graph distance 1.36)
- [mps.api.utils._, _, image_tag](de1a3c46-4968-53e2-8bb3-c409205df414.md) - Related (graph distance 1.44)
- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 3.00)
