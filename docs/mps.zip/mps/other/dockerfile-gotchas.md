---
id: b9782052-1903-5e8f-bdde-cdd845f51f1b
type: gotcha
title: "Dockerfile Gotchas"
created_at: 2026-07-03T05:58:34.314689+00:00
updated_at: 2026-07-03T05:58:34.314703+00:00
source_files:
  - /Users/spark/git/service-model-promotion/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/builder/Dockerfile`

# Gotchas and Pitfalls: `stage0.Dockerfile`

### NVM install does not actually install Node
**Trigger:** The `nvm` install script only installs the `nvm` version manager, not any Node.js version. The subsequent commands assume `/root/.nvm/versions/node/v18.14.0/bin` exists, but no `nvm install 18.14.0` was ever run.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Explicitly install the Node version after installing nvm.
**Category:** framework
**Example:**
```dockerfile
RUN curl -LsS https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh | bash \
    && export NVM_DIR="/root/.nvm" \
    && . "$NVM_DIR/nvm.sh" \
    && nvm install 18.14.0 \
    && nvm use 18.14.0
```
Without the `nvm install`, the `cd /root/.nvm/versions/node/...` line will fail because the directory won't exist.

### `. ~/.bashrc` is a no-op in RUN layers
**Trigger:** Docker `RUN` executes with `/bin/sh -c` (non-interactive, non-login) by default. `~/.bashrc` typically starts with an early-return guard for non-interactive shells (`case $- in *i*) ;; *) return;; esac`), so sourcing it does nothing useful. nvm's environment setup lives in `.bashrc` and won't load.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Source `$NVM_DIR/nvm.sh` directly, or use `SHELL ["/bin/bash", "-lc"]`.
**Category:** framework
**Example:**
```dockerfile
# This does nothing:
RUN . ~/.bashrc && nvm --version   # nvm: command not found

# Do this instead:
RUN . /root/.nvm/nvm.sh && nvm --version
```

### Hardcoded Node path duplicates the ENV var — drift risk
**Trigger:** `ENV NODE_VERSION="18.14.0"` and `ENV PATH=".../node/v18.14.0/bin/"` both hardcode the version. Changing `NODE_VERSION` won't update `PATH`, silently breaking the build.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Reference the variable in PATH (note: Docker's `ENV` does support variable expansion).
**Category:** framework
**Example:**
```dockerfile
ENV NODE_VERSION="18.14.0"
ENV PATH="${PATH}:/root/.nvm/versions/node/v${NODE_VERSION}/bin/"
```

### `apt update` run twice, no `apt-get`, and cache never cleaned
**Trigger:** `apt` (vs `apt-get`) is not intended for scripts — it emits warnings ("apt does not have a stable CLI interface") and may behave differently across versions. Additionally, the apt lists are never cleaned, bloating the image.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Use `apt-get`, combine commands, and clean up in the same layer.
**Category:** performance
**Example:**
```dockerfile
RUN apt-get update \
    && apt-get install -y --no-install-recommends podman git curl pigz \
    && apt-get clean && rm -rf /var/lib/apt/lists/*
```

### `--allow-unauthenticated` masks a real keyring problem
**Trigger:** The `--allow-unauthenticated` flag plus reinstalling `debian-archive-keyring` is a band-aid for GPG verification failures. This disables package signature verification — a silent security hole. It also indicates the base image or mirror state is unstable, making builds non-reproducible.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Remove the flag; fix the underlying keyring issue by updating the base image or ensuring `ca-certificates` and `debian-archive-keyring` are current *before* other installs.
**Category:** domain
**Example:**
```dockerfile
# Avoid: silently skips signature verification
RUN apt install --allow-unauthenticated ...
```

### `pip3 install poetry awscli` pollutes system Python
**Trigger:** Installing poetry and awscli into the same global Python as your project causes dependency conflicts and version resolution surprises. Poetry's own dependencies can shadow or clash with project deps.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Use `pipx` for isolated CLI tool installs, or use poetry's official installer.
**Category:** framework
**Example:**
```dockerfile
RUN pip3 install pipx && pipx install poetry==1.8.3 && pipx install awscli
```

### Curl pipe-to-bash with no integrity check
**Trigger:** `curl ... | bash` from `master` branch pulls the latest (moving) install script with no checksum, no pinned commit, and executes it directly. Builds are non-reproducible and vulnerable to upstream tampering.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Pin to a specific nvm tag and verify.
**Category:** domain
**Example:**
```dockerfile
# Non-reproducible: master can change between builds
curl -LsS https://.../nvm-sh/nvm/master/install.sh | bash

# Better: pin the version
curl -LsS https://.../nvm-sh/nvm/v0.39.7/install.sh | bash
```

### Missing pip/network robustness — no `--no-cache-dir`, no retries
**Trigger:** `pip3 install` without `--no-cache-dir` leaves pip cache in the image, and transient network failures aren't retried, causing flaky builds.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Add `--no-cache-dir` and consider retry/timeout options.
**Category:** performance
**Example:**
```dockerfile
RUN pip3 install --no-cache-dir poetry==1.8.3
```

### `npm install -g` succeeds but the binary may not be on PATH at runtime
**Trigger:** `typora-parser` is installed globally into the nvm-managed node bin dir. This only works because `PATH` was manually set to that exact directory. Any consumer running a different Node version, or a login shell that re-sources nvm and switches versions, will not find the binary.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Verify installation in the build (`RUN typora-parser --version`) and avoid relying on nvm's PATH manipulation at runtime; symlink the binary to `/usr/local/bin`.
**Category:** framework
**Example:**
```dockerfile
RUN . /root/.nvm/nvm.sh && nvm use 18.14.0 \
    && npm install -g typora-parser \
    && ln -s "$(which typora-parser)" /usr/local/bin/typora-parser \
    && typora-parser --version
```

### Podman inside a container needs privileges/config
**Trigger:** Installing `podman` implies running containers inside this container. Rootless podman requires `newuidmap`/`newgidmap`, user namespace config, and often `--privileged` or fuse-overlayfs — none set up here. It will silently fail at runtime, not build time.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Configure `/etc/containers/` storage/registries and install `fuse-overlayfs`, `slirp4netns`, `uidmap` explicitly if nested containers are intended.
**Category:** domain
**Example:**
```dockerfile
RUN apt-get install -y fuse-overlayfs slirp4netns uidmap
# plus /etc/containers/storage.conf tuning
```

### No `ENV PATH` for pipx/user installs; trailing slash in PATH
**Trigger:** The `PATH` entry ends with a trailing slash (`.../bin/`). While usually harmless, it can break tooling that does naive string comparison or path joining, and differs from convention.
**Affected Files:** `stage0.Dockerfile`
**Fix:** Drop the trailing slash for consistency: `.../v${NODE_VERSION}/bin`.
**Category:** framework
**Example:**
```dockerfile
ENV PATH="${PATH}:/root/.nvm/versions/node/v18.14.0/bin"   # no trailing slash
```