---
id: 9d3213cc-ae53-550c-8ead-a9f9cc4882d3
type: gotcha
title: "Routers Gotchas"
created_at: 2026-06-06T19:04:16.268371+00:00
updated_at: 2026-06-20T22:55:23.479522+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/__init__.py
metadata:
  module_name: "mps.routers"
  language: "python"
  source_name: "mps"
---
# Routers Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/__init__.py`

# Routers Gotchas


# Gotcha Analysis: `mps.routers`

## No Source Code Provided

**Trigger:** The module `mps.routers` was specified, but the source code block is empty. No actual code was provided to analyze.

**Affected Files:** Unknown — the `mps.routers` module file(s) were not included in the submission.

**Fix:** Please resubmit with the actual source code. To get a useful gotcha/pitfall analysis, include:

- The full contents of the router module file(s)
- Any relevant imports and decorators (e.g., FastAPI `@router.get`, Flask `@app.route`)
- Dependency-injection setup and shared state
- attrs/polars/DuckDB usage if present

**Category:** N/A

**Example:** N/A

---

## What I Can Look For Once Code Is Provided

Since this appears to be a routing module (likely a web framework), here are the categories I'll examine when you provide the code:

| Category | Common router-specific gotchas |
|----------|-------------------------------|
| **async** | Mixing sync DB calls (DuckDB, blocking I/O) inside `async def` handlers, blocking the event loop |
| **thread-safety** | Module-level mutable state, shared DuckDB connections across requests/threads |
| **type-system** | Path/query params silently coerced or defaulting to `None`; unvalidated request bodies |
| **framework** | Route ordering (specific vs. catch-all), trailing-slash redirects, dependency caching quirks |
| **performance** | Per-request connection creation, N+1 queries, eager DataFrame materialization in polars |
| **domain** | Pagination edge cases, error-status mapping, auth-check placement |

**Please paste the contents of `mps.routers` and I'll produce the full gotcha breakdown.**