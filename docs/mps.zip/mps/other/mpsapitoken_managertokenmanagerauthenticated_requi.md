---
id: 88c5775b-0216-5169-9c74-d8ecc1b451c7
type: catalog
title: "mps.api.token_manager.TokenManager.authenticated_required_params"
created_at: 2026-06-06T18:47:28.318748+00:00
updated_at: 2026-07-03T06:16:14.981607+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.authenticated_required_params"
  signature: "authenticated_required_params = dict("
  location: {'line_start': 46, 'line_end': 57, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "e76c8a6d6b9f12477ce88df822ec85c81cfc7da344a65eec68d0ffffb459084f"
  description: "A class-level dictionary defining the required parameters for authenticated API requests in the TokenManager class."
---
# mps.api.token_manager.TokenManager.authenticated_required_params

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.authenticated_required_params


variable mps.api.token_manager.TokenManager.authenticated_required_params in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:46-57 :: authenticated_required_params = dict(

Description: A class-level dictionary defining the required parameters for authenticated API requests in the TokenManager class.

## Related Documents

- [mps.api.token_manager.TokenManager.required_params](4e2c0707-3cf9-53e1-b037-3cd4ed330632.md) - Related (graph distance 1.26)
- [mps.api.token_manager.TokenManager.local_required_params](dffe687c-24ed-5438-b503-8c3cb23c7d49.md) - Related (graph distance 1.37)
- [mps.api.token_manager.TokenManager.none_values](5e618a5f-3950-5107-a4eb-b8aea0b6f361.md) - Related (graph distance 2.84)
