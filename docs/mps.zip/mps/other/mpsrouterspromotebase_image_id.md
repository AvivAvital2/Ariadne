---
id: 79045cda-50cb-586c-a17c-b364eb27141d
type: catalog
title: "mps.routers.promote.base_image_id"
created_at: 2026-06-06T18:47:27.626776+00:00
updated_at: 2026-07-03T06:16:15.107106+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.base_image_id"
  signature: "base_image_id = await resolve_base_image_id("
  location: {'line_start': 54, 'line_end': 60, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "None"
  sha_at_sync: "86e7fafbd841924cb090c9de12d049e3bc69efef4ab4d1acd15bda80996efde2"
  description: "Module-level variable that asynchronously resolves and stores the base image identifier within the promote router, used as a reference for image promotion operations."
---
# mps.routers.promote.base_image_id

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.base_image_id


variable mps.routers.promote.base_image_id [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:54-60 :: base_image_id = await resolve_base_image_id(

Description: Module-level variable that asynchronously resolves and stores the base image identifier within the promote router, used as a reference for image promotion operations.

## Related Documents

- [mps.api.utils.resolve_base_image_id](ba3105ec-cf00-5064-85f2-207386a7823a.md) - Related (graph distance 1.40)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.53)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 1.63)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 2.98)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.06)
- [mps.routers.promote.tag](29a0e745-d4bd-5b5f-b2c7-8ce597d7d251.md) - Related (graph distance 3.07)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 3.15)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 3.18)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 3.19)
