---
id: 9a176a6e-28ed-5ee6-843f-44c572ffa4fa
type: gotcha
title: "Update Version Gotchas"
created_at: 2026-06-06T19:04:52.993265+00:00
updated_at: 2026-06-20T22:55:23.607583+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  module_name: "update_version"
  language: "python"
  source_name: "mps"
---
# Update Version Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# Update Version Gotchas


# Gotchas and Pitfalls: `update_version`

### Empty string vs unset VERSION are conflated
**Trigger:** `os.getenv("VERSION")` returns `""` when the variable is set but empty. The `if not version` check treats both unset and empty-string identically, but the error message lies ("is not set" when it may actually be set-but-empty).
**Affected Files:** `update_version.py`
**Fix:** Distinguish the two cases and validate the version format.
**Category:** type-system
**Example:**
```python
version = os.getenv("VERSION")
if version is None:
    raise ValueError("VERSION environment variable is not set")
version = version.strip()
if not version:
    raise ValueError("VERSION environment variable is empty")
```

---

### No version format validation — invalid versions silently written
**Trigger:** Any string is accepted (e.g. `VERSION="not a version"`, `VERSION="1.0.0; rm -rf"`). It gets written to `pyproject.toml`, breaking poetry downstream with a confusing error far from the root cause.
**Affected Files:** `update_version.py`
**Fix:** Validate against PEP 440 before writing.
**Category:** domain
**Example:**
```python
from packaging.version import Version, InvalidVersion
try:
    Version(version)
except InvalidVersion:
    raise ValueError(f"Invalid version: {version!r}")
```

---

### KeyError if pyproject structure differs (PEP 621 / poetry 2.x)
**Trigger:** Assumes `[tool.poetry]` exists. Modern poetry 2.0+ uses `[project]` with `version` at top level. On such a file, `pyproject["tool"]["poetry"]` raises `KeyError`, or worse, silently writes a version to the wrong location that poetry ignores.
**Affected Files:** `update_version.py`
**Fix:** Check which schema is present and update accordingly.
**Category:** framework
**Example:**
```python
if "project" in pyproject and "version" in pyproject.get("project", {}):
    pyproject["project"]["version"] = version
elif "tool" in pyproject and "poetry" in pyproject["tool"]:
    pyproject["tool"]["poetry"]["version"] = version
else:
    raise KeyError("No recognized version field in pyproject.toml")
```

---

### Non-atomic write corrupts pyproject.toml on failure
**Trigger:** `tomli_w.dump` opens the file in `"wb"` (truncate) mode. If the process is killed or `dump` raises mid-write, the original `pyproject.toml` is destroyed/half-written and unrecoverable.
**Affected Files:** `update_version.py`
**Fix:** Write to a temp file and atomically rename.
**Category:** performance
**Example:**
```python
import tempfile, os
fd, tmp = tempfile.mkstemp(dir=".", suffix=".toml")
try:
    with os.fdopen(fd, "wb") as f:
        tomli_w.dump(pyproject, f)
    os.replace(tmp, "pyproject.toml")   # atomic
except Exception:
    os.unlink(tmp)
    raise
```

---

### Comments and formatting are silently destroyed on round-trip
**Trigger:** `tomli` parses into plain dicts, discarding comments, blank lines, key ordering nuances, and inline-table styling. `tomli_w.dump` re-serializes with its own formatting. Your carefully-commented `pyproject.toml` loses all comments and may reorder/reformat everything.
**Affected Files:** `update_version.py`
**Fix:** Use a format-preserving library like `tomlkit` if comments matter.
**Category:** framework
**Example:**
```python
import tomlkit
doc = tomlkit.parse(open("pyproject.toml").read())  # preserves comments
doc["tool"]["poetry"]["version"] = version
open("pyproject.toml", "w").write(tomlkit.dumps(doc))
```

---

### Hardcoded relative path depends on CWD
**Trigger:** `open("pyproject.toml", ...)` resolves relative to the current working directory, not the script location. Running the script from any other directory either fails (`FileNotFoundError`) or worse, edits an unrelated `pyproject.toml` in the wrong project.
**Affected Files:** `update_version.py`
**Fix:** Anchor the path explicitly or make it configurable.
**Category:** framework
**Example:**
```python
from pathlib import Path
path = Path(__file__).resolve().parent.parent / "pyproject.toml"
# or accept via argparse / env var
```

---

### Concurrent invocations race on the same file
**Trigger:** If two processes (e.g. parallel CI jobs) run `update_version` against the same file, the read-modify-write is not locked. One write clobbers the other (lost update), and with truncate-mode writes one process may read a partially-written file.
**Affected Files:** `update_version.py`
**Fix:** Use a file lock (`filelock`/`fcntl.flock`) around the read-modify-write, or ensure serial execution.
**Category:** thread-safety
**Example:**
```python
from filelock import FileLock
with FileLock("pyproject.toml.lock"):
    # read, modify, atomic write
    ...
```

---

### No version-downgrade / no-op guard
**Trigger:** The function blindly overwrites the existing version. Re-running with an older or identical version silently succeeds, producing misleading "successful" CI runs and potential downgrades.
**Affected Files:** `update_version.py`
**Fix:** Compare against the existing value and warn or fail on downgrade.
**Category:** domain
**Example:**
```python
from packaging.version import Version
current = pyproject["tool"]["poetry"]["version"]
if Version(version) <= Version(current):
    raise ValueError(f"{version} is not newer than {current}")
```