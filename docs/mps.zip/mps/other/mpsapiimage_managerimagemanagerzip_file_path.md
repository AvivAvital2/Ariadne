---
id: 3e1de95d-3bac-5dd8-84da-a0de6c31cf9c
type: catalog
title: "mps.api.image_manager.ImageManager.zip_file_path"
created_at: 2026-06-06T18:47:28.996306+00:00
updated_at: 2026-07-03T06:16:15.129151+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.zip_file_path"
  signature: "zip_file_path = os.path.join(temp_directory, model_filename)"
  location: {'line_start': 49, 'line_end': 49, 'col_start': 8, 'col_end': 68}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6b3f9bc564abc625e2616d21a551a62ce9cd8b70c863d17e31cbf05b17e9798d"
  description: "Constructs the full filesystem path to the model zip file by joining the temporary directory with the model filename."
---
# mps.api.image_manager.ImageManager.zip_file_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.zip_file_path


variable mps.api.image_manager.ImageManager.zip_file_path in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:49-49 :: zip_file_path = os.path.join(temp_directory, model_filename)

Description: Constructs the full filesystem path to the model zip file by joining the temporary directory with the model filename.

## Related Documents

- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 1.34)
- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 1.66)
