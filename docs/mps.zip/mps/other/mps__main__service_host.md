---
id: a37f5104-a8ca-5d27-8a61-1d2e8fe885a6
type: catalog
title: "mps.__main__.service_host"
created_at: 2026-06-06T18:47:26.711791+00:00
updated_at: 2026-07-03T06:16:14.969517+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.service_host"
  signature: "service_host = os.environ.get("SERVICE_HOST", "0.0.0.0")"
  location: {'line_start': 35, 'line_end': 35, 'col_start': 4, 'col_end': 60}
  parent_qualified_name: "None"
  sha_at_sync: "14f05d9f77e8f43ad39c525866c3b7a30b9cf8bff291754cbeda4bef15056208"
  description: "Module-level variable that retrieves the service's bind address from the `SERVICE_HOST` environment variable, defaulting to `0.0.0.0` if not set."
---
# mps.__main__.service_host

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.service_host


variable mps.__main__.service_host [python] /Users/spark/git/service-model-promotion/mps/__main__.py:35-35 :: service_host = os.environ.get("SERVICE_HOST", "0.0.0.0")

Description: Module-level variable that retrieves the service's bind address from the `SERVICE_HOST` environment variable, defaulting to `0.0.0.0` if not set.

## Related Documents

- [mps.__main__.service_port](4a87beee-f4f7-5afb-a01a-deadf7514e7a.md) - Related (graph distance 1.24)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 1.62)
- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 2.86)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 2.89)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 2.91)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 2.97)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 3.23)
