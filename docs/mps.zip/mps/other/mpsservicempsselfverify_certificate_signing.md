---
id: f5607b28-3c1e-5f2f-91eb-47ec8057ec6d
type: catalog
title: "mps.service.MPS.self.verify_certificate_signing"
created_at: 2026-06-06T18:47:26.304622+00:00
updated_at: 2026-07-03T06:16:14.983018+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.verify_certificate_signing"
  signature: "self.verify_certificate_signing = json.loads(self.verify_certificate_signing.lower())"
  location: {'line_start': 45, 'line_end': 45, 'col_start': 24, 'col_end': 109}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "9df3885a234923165a572cfb0da5d0090832a824bc86e4a58fc9fa55b711b024"
  description: "Converts the `verify_certificate_signing` configuration value from a lowercased string into a Python boolean (or other JSON value) by parsing it with `json.loads`."
---
# mps.service.MPS.self.verify_certificate_signing

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.verify_certificate_signing


variable mps.service.MPS.self.verify_certificate_signing in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:45-45 :: self.verify_certificate_signing = json.loads(self.verify_certificate_signing.lower())

Description: Converts the `verify_certificate_signing` configuration value from a lowercased string into a Python boolean (or other JSON value) by parsing it with `json.loads`.

## Related Documents

- [mps.api.token_manager.TokenManager.verify_certificate_signing](74dc6ac1-882d-545b-9cb1-41fa08944a4b.md) - Related (graph distance 1.48)
- [mps.api.utils.MPSSession.verify](a5f6ebeb-5d97-5558-b156-7d68c086ca7f.md) - Related (graph distance 1.62)
