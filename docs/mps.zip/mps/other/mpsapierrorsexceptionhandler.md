---
id: cf4dd7f9-1a77-532c-ba34-3c1194c6363c
type: catalog
title: "mps.api.errors.ExceptionHandler"
created_at: 2026-06-06T18:47:29.762243+00:00
updated_at: 2026-07-03T06:16:15.052169+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.ExceptionHandler"
  signature: "class ExceptionHandler(Exception):"
  location: {'line_start': 5, 'line_end': 20, 'col_start': 0, 'col_end': 65}
  parent_qualified_name: "None"
  sha_at_sync: "1b8ff96745830983fdf8a9058d7622446d88ad8e538e821fedf1db806158da42"
  description: "Base exception class for handling errors in the MPS API, serving as the parent for more specific exception types."
---
# mps.api.errors.ExceptionHandler

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler


class mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:5-20 :: class ExceptionHandler(Exception):

Description: Base exception class for handling errors in the MPS API, serving as the parent for more specific exception types.

## Related Documents

- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.49)
- [mps.api.errors.InvalidAWSRegion](6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde.md) - Related (graph distance 1.54)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.56)
- [mps.api.errors.ExceptionHandler.exception_handler](3529722b-ea7e-531f-badf-5c1480baf8aa.md) - Related (graph distance 1.58)
