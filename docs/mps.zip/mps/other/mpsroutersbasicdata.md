---
id: 7b23dd38-2b3c-5125-bdb6-96e7c26fad39
type: catalog
title: "mps.routers.basic.data"
created_at: 2026-06-06T18:47:27.475531+00:00
updated_at: 2026-06-20T22:55:26.541975+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.basic.data"
  signature: "data = await f.read()"
  location: {'line_start': 18, 'line_end': 18, 'col_start': 8, 'col_end': 29}
  parent_qualified_name: "None"
  sha_at_sync: "0d852d1f5d33a50def9f37e292a638d66a3c13d45818472faf53dab1fe21a2b4"
  description: "Reads the entire contents of an asynchronously opened file into the `data` variable."
---
# mps.routers.basic.data

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# mps.routers.basic.data


variable mps.routers.basic.data [python] /Users/spark/git/service-model-promotion/mps/routers/basic.py:18-18 :: data = await f.read()

Description: Reads the entire contents of an asynchronously opened file into the `data` variable.