---
id: c287bc81-4e6b-5205-8504-06eaa703e5c4
type: catalog
title: "mps.api.token_manager.AWSTokenManager.token_data"
created_at: 2026-06-06T18:47:28.321522+00:00
updated_at: 2026-07-03T06:16:14.975288+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.token_data"
  signature: "token_data = base64.b64decode(response['authorizationData'][0]['authorizationToken']).decode()"
  location: {'line_start': 136, 'line_end': 136, 'col_start': 16, 'col_end': 110}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "43e0d3df31b4878f5418a75cf15fd739ad190eba52ba6555320ecaa62a1d7d3f"
  description: "Decodes the base64-encoded authorization token retrieved from the AWS ECR authorization data response into a UTF-8 string."
---
# mps.api.token_manager.AWSTokenManager.token_data

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.token_data


variable mps.api.token_manager.AWSTokenManager.token_data in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:136-136 :: token_data = base64.b64decode(response['authorizationData'][0]['authorizationToken']).decode()

Description: Decodes the base64-encoded authorization token retrieved from the AWS ECR authorization data response into a UTF-8 string.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.username, password](5fc78839-79c2-5b61-a6f6-dc523f392751.md) - Related (graph distance 1.59)
