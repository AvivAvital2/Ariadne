---
id: 18063d23-2baf-58c4-a746-af8b4a046a21
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.delete"
created_at: 2026-06-06T18:47:29.720833+00:00
updated_at: 2026-07-03T06:16:15.037373+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.delete"
  signature: "async def delete(self, key):"
  location: {'line_start': 60, 'line_end': 64, 'col_start': 4, 'col_end': 9}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "56dcca2c720d09629ab234e242a813e9411e2c514fcbd341d16d56b0644931e2"
  description: "Asynchronously removes the cached image entry associated with the given key from the persistent cache."
---
# mps.api.image_cache.AsyncPersistentImageCache.delete

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.delete


method mps.api.image_cache.AsyncPersistentImageCache.delete in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:60-64 :: async def delete(self, key):

Description: Asynchronously removes the cached image entry associated with the given key from the persistent cache.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.update](b9099bc1-0ee6-547f-b844-bd21c0c852ea.md) - Related (graph distance 1.30)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 1.32)
- [mps.api.image_cache.AsyncPersistentImageCache.set](5dc502b1-4a0d-5dd1-b13d-94f02f75f05f.md) - Related (graph distance 1.33)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 1.37)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 1.54)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 2.74)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 2.76)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 2.89)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 2.92)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 2.92)
