---
id: e6376e7d-3534-5633-9f84-2187d56f743e
type: catalog
title: "mps.api.schemas.Flavours"
created_at: 2026-06-06T18:47:28.910774+00:00
updated_at: 2026-07-03T06:16:14.979565+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.Flavours"
  signature: "class Flavours:"
  location: {'line_start': 6, 'line_end': 10, 'col_start': 0, 'col_end': 12}
  parent_qualified_name: "None"
  sha_at_sync: "96019a82f79e3b919a46a3112c4aabb5ed96eac8c1e209d30fb5fb0ea838877b"
  description: "Defines a schema class representing a collection of flavour options, likely used for serialization or validation of flavour-related data in the MPS API."
---
# mps.api.schemas.Flavours

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.Flavours


class mps.api.schemas.Flavours [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:6-10 :: class Flavours:

Description: Defines a schema class representing a collection of flavour options, likely used for serialization or validation of flavour-related data in the MPS API.

## Related Documents

- [mps.api.utils.flavours](99e4f257-b792-58b1-a023-c7b18602a57e.md) - Related (graph distance 1.45)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.47)
- [mps.api.schemas.Flavours.gdata](421f70f2-749b-57fb-802a-4988a0b15516.md) - Related (graph distance 1.60)
- [mps.api.schemas.Flavours.minimal](6f98a8fb-a158-538b-b12d-a9eacc2370cb.md) - Related (graph distance 1.62)
- [mps.api.schemas.Flavours.osm](158f2dda-ad59-551f-8cb0-3fd7f47d9750.md) - Related (graph distance 1.65)
- [mps.api.utils.flavour](d3152f57-40bf-54d0-a0a7-17073bed3cc6.md) - Related (graph distance 2.89)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 2.90)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 2.90)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 2.96)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 3.03)
