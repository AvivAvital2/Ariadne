---
id: 8474e7ee-75f8-52d3-92e2-dc2f2fb59079
type: catalog
title: "documentation.README_dp_integrated.maintenance_mode"
created_at: 2026-06-06T18:47:26.102324+00:00
updated_at: 2026-06-20T22:55:25.389079+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_dp_integrated.maintenance_mode"
  signature: "## Maintenance mode"
  location: {'line_start': 236, 'line_end': 244, 'col_start': 0, 'col_end': 19}
  parent_qualified_name: "documentation.README_dp_integrated"
  sha_at_sync: "e80698a6a653c865c371199ab96c3cf6072cb7e1d9a059b8561d9cd08ed9d2b3"
  description: "Documents how to enable maintenance mode for the data plane integrated deployment, taking the service offline for updates or repairs."
---
# documentation.README_dp_integrated.maintenance_mode

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md`

# documentation.README_dp_integrated.maintenance_mode


md_section documentation.README_dp_integrated.maintenance_mode in documentation.README_dp_integrated [markdown] /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md:236-244 :: ## Maintenance mode

Description: Documents how to enable maintenance mode for the data plane integrated deployment, taking the service offline for updates or repairs.