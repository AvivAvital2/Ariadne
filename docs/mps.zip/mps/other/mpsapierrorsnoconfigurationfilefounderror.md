---
id: 77bf0aae-c975-569a-9484-fd8c4d9e53ca
type: catalog
title: "mps.api.errors.NoConfigurationFileFoundError"
created_at: 2026-06-06T18:47:29.762751+00:00
updated_at: 2026-07-03T06:16:15.084823+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.NoConfigurationFileFoundError"
  signature: "class NoConfigurationFileFoundError(ExceptionHandler):"
  location: {'line_start': 29, 'line_end': 32, 'col_start': 0, 'col_end': 68}
  parent_qualified_name: "None"
  sha_at_sync: "14c3ad8e270815ab2961161c05fc9c5b9b0d21d85a7e4eb416ab474ba79305fb"
  description: "Exception handler that handles the error condition when no configuration file can be located. Extends the `ExceptionHandler` base class."
---
# mps.api.errors.NoConfigurationFileFoundError

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.NoConfigurationFileFoundError


class mps.api.errors.NoConfigurationFileFoundError [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:29-32 :: class NoConfigurationFileFoundError(ExceptionHandler):

Description: Exception handler that handles the error condition when no configuration file can be located. Extends the `ExceptionHandler` base class.

## Related Documents

- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 1.06)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.26)
- [mps.api.errors.MissingConfigValues](04edf404-d21e-5354-b2ae-458a08e7e3f2.md) - Related (graph distance 1.41)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 1.49)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.55)
- [mps.api.errors.UnableToStoreCredentialsFile](dd706baa-9f4e-5d89-ab0c-97163e21942b.md) - Related (graph distance 1.61)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.62)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 2.70)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.73)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 2.75)
