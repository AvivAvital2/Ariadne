---
id: 567da415-1695-58a5-ad82-a694a3f19563
type: catalog
title: ".ariadne.manifest.merged_at"
created_at: 2026-06-06T18:47:25.554456+00:00
updated_at: 2026-06-20T22:55:25.255018+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".ariadne.manifest.merged_at"
  signature: "merged_at": "2026-06-04T19:08:31.653030+00:00"
  location: {'line_start': 29, 'line_end': 29, 'col_start': 2, 'col_end': 49}
  parent_qualified_name: ".ariadne.manifest"
  sha_at_sync: "bf15c3f0817e50300bfc584ee3c5017d19d1eba8126e099f72a9b24026003467"
  description: "Records the UTC timestamp indicating when the Ariadne manifest was merged."
---
# .ariadne.manifest.merged_at

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

# .ariadne.manifest.merged_at


json_key .ariadne.manifest.merged_at in .ariadne.manifest [json] /Users/spark/git/service-model-promotion/.ariadne/manifest.json:29-29 :: "merged_at": "2026-06-04T19:08:31.653030+00:00"

Description: Records the UTC timestamp indicating when the Ariadne manifest was merged.

## Related Documents

- [.ariadne.manifest.merged_at](ca3f7827-1646-586c-b61d-f1efd675c521.md) - Related (graph distance 1.03)
- [.ariadne.manifest.merged_scip](84726fb8-f4a6-5697-90cf-d36a523b71b3.md) - Related (graph distance 1.52)
- [.ariadne.manifest.ariadne_version](a3d7fb1d-b757-561c-bc7f-635a7557d0a6.md) - Related (graph distance 2.55)
- [.ariadne.manifest.source_name](9112bb66-54c4-5978-a5c4-664099281488.md) - Related (graph distance 2.86)