---
id: 308debdb-7c0b-525f-bd1f-94f84cd280e5
type: catalog
title: "mps.routers.promote.annotations_string"
created_at: 2026-06-06T18:47:27.628010+00:00
updated_at: 2026-07-03T06:16:15.001159+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.annotations_string"
  signature: "annotations_string = request_obj.headers.get('X-ANNOTATIONS', None)"
  location: {'line_start': 72, 'line_end': 72, 'col_start': 4, 'col_end': 71}
  parent_qualified_name: "None"
  sha_at_sync: "def82e366674d50160d44205c5b5a1f025d2d970e30ad7b8fb272322091030fb"
  description: "Retrieves the optional `X-ANNOTATIONS` HTTP header value from the incoming request, defaulting to `None` if the header is absent."
---
# mps.routers.promote.annotations_string

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.annotations_string


variable mps.routers.promote.annotations_string [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:72-72 :: annotations_string = request_obj.headers.get('X-ANNOTATIONS', None)

Description: Retrieves the optional `X-ANNOTATIONS` HTTP header value from the incoming request, defaulting to `None` if the header is absent.

## Related Documents

- [mps.routers.promote.algorithm_string](b6417c2f-d7af-5ccf-8a65-d93929bed909.md) - Related (graph distance 1.41)
- [mps.routers.promote.auxiliary_image_string](d5288d92-39d5-5b40-993d-21eea4d39f9a.md) - Related (graph distance 1.42)
- [mps.routers.promote.annotations_list](9fb04024-1a86-548a-ad1a-d71b488cd891.md) - Related (graph distance 1.51)
- [mps.routers.promote.auxiliary_image_list](e555d1cb-61ea-523a-8284-a3b7183d411a.md) - Related (graph distance 2.87)
