---
id: 10b77a84-a8e9-5196-8d6b-0fd076b45055
type: catalog
title: "mps.api.logger.Logger.console_formatter"
created_at: 2026-06-06T18:47:28.693651+00:00
updated_at: 2026-07-03T06:16:14.983853+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger.console_formatter"
  signature: "console_formatter = logging.Formatter(log_format)"
  location: {'line_start': 39, 'line_end': 39, 'col_start': 8, 'col_end': 57}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "58b600e37aabe8bbf33c0618707150c671a03f4e0b4ebc62c1a4929ba1afdada"
  description: "Creates a logging formatter instance using the configured log format string, used to format log messages for console output."
---
# mps.api.logger.Logger.console_formatter

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.console_formatter


variable mps.api.logger.Logger.console_formatter in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:39-39 :: console_formatter = logging.Formatter(log_format)

Description: Creates a logging formatter instance using the configured log format string, used to format log messages for console output.

## Related Documents

- [mps.api.logger.Logger.file_formatter](602a21af-d0b0-5b18-939a-1112561f8d98.md) - Related (graph distance 1.17)
- [mps.api.logger.Logger.console_handler](2a3b5941-578c-54de-aa16-2ea79fdfded9.md) - Related (graph distance 1.49)
- [mps.api.logger.Logger.log_format](20544901-82a4-5cde-8e92-17ebf78c1ba8.md) - Related (graph distance 1.49)
- [mps.api.logger.Logger.file_handler](0027aaf8-fb06-5408-8dde-5fe2c7b80061.md) - Related (graph distance 2.70)
- [mps.api.logger.CustomLogger.extra['delimiter']](f3678951-3b38-5bbb-93cb-06dcd193a187.md) - Related (graph distance 3.00)
