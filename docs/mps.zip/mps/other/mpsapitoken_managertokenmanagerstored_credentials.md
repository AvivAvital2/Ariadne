---
id: 6118c04d-ef3d-537e-a04b-20a6f6cf3f21
type: catalog
title: "mps.api.token_manager.TokenManager.stored_credentials"
created_at: 2026-06-06T18:47:28.319879+00:00
updated_at: 2026-07-03T06:16:15.013499+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.stored_credentials"
  signature: "stored_credentials = self.get_credentials(self.registry)"
  location: {'line_start': 104, 'line_end': 104, 'col_start': 20, 'col_end': 76}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "c363de1472894304319dccb8c94ab6278ca568a51840179a63899c92fa962704"
  description: "Retrieves and stores the credentials associated with the instance's registry by calling `get_credentials`."
---
# mps.api.token_manager.TokenManager.stored_credentials

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.stored_credentials


variable mps.api.token_manager.TokenManager.stored_credentials in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:104-104 :: stored_credentials = self.get_credentials(self.registry)

Description: Retrieves and stores the credentials associated with the instance's registry by calling `get_credentials`.

## Related Documents

- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 1.56)
- [mps.api.token_manager.TokenManager._write_credentials_to_file](235b8a53-2362-56d9-ab74-c5209a1b4c88.md) - Related (graph distance 1.66)
- [mps.api.token_manager.AWSTokenManager.__init__](57f392dc-511c-5b35-a6a9-d2ca1b3fb86e.md) - Related (graph distance 3.18)
- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 3.21)
