---
id: 59a7e242-f832-5030-8f75-cb3addfb1ff7
type: catalog
title: "mps.api.schemas.ImageParams.revision"
created_at: 2026-06-06T18:47:28.918200+00:00
updated_at: 2026-06-20T22:55:22.888517+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.ImageParams.revision"
  signature: "revision: str"
  location: {'line_start': 55, 'line_end': 55, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "mps.api.schemas.ImageParams"
  sha_at_sync: "773fde194354059a4d66ef3261a4893b442c36a7723066865062a9a742cdacc5"
  description: "Specifies the Git revision (branch, tag, or commit hash) to use when building or pulling the image, as a string field of the `ImageParams` schema."
---
# mps.api.schemas.ImageParams.revision

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.ImageParams.revision


variable mps.api.schemas.ImageParams.revision in mps.api.schemas.ImageParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:55-55 :: revision: str

Description: Specifies the Git revision (branch, tag, or commit hash) to use when building or pulling the image, as a string field of the `ImageParams` schema.