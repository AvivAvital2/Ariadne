---
id: 17135ee0-4e31-5148-b47d-38c3ec5f0a95
type: catalog
title: "mps.api.logger.CustomLogger"
created_at: 2026-06-06T18:47:28.690480+00:00
updated_at: 2026-07-03T06:16:14.945337+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.logger.CustomLogger"
  signature: "class CustomLogger(logging.Logger):"
  location: {'line_start': 6, 'line_end': 11, 'col_start': 0, 'col_end': 93}
  parent_qualified_name: "None"
  sha_at_sync: "a78cacb4677932d2bc8fe2a18d5618e74f248b92796d47641c4ffaad8f4d9ac7"
  description: "A custom logging.Logger subclass that extends the standard Python logger with additional functionality for the mps.api module."
---
# mps.api.logger.CustomLogger

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.CustomLogger


class mps.api.logger.CustomLogger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:6-11 :: class CustomLogger(logging.Logger):

Description: A custom logging.Logger subclass that extends the standard Python logger with additional functionality for the mps.api module.

## Related Documents

- [mps.api.logger.Logger](b3389511-3834-54f5-836a-78c4848305dc.md) - Related (graph distance 1.42)
- [mps.api.errors.ExceptionHandler.self.Logger](e44a3143-66f2-530f-b85e-34ddd1b4545f.md) - Related (graph distance 1.62)
- [mps.api.logger.Logger._logger](3b7e98d7-bfd2-5dcc-a8af-1078b647c414.md) - Related (graph distance 3.05)
- [mps.api.logger.logger](903b3696-6e75-5071-9f19-6d10a5038da1.md) - Related (graph distance 3.05)
