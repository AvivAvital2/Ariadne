---
id: 1cbe7d58-5849-5877-945c-5f85350c05bf
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.clear"
created_at: 2026-06-06T18:47:29.721094+00:00
updated_at: 2026-07-03T06:16:15.033995+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.clear"
  signature: "async def clear(self):"
  location: {'line_start': 66, 'line_end': 67, 'col_start': 4, 'col_end': 48}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "e14cbc519464988a932ca8e2c88e8c6b39b30d00dadc61f58aa4254dc09c8e73"
  description: "Asynchronously removes all entries from the persistent image cache, clearing both in-memory and on-disk storage."
---
# mps.api.image_cache.AsyncPersistentImageCache.clear

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.clear


method mps.api.image_cache.AsyncPersistentImageCache.clear in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:66-67 :: async def clear(self):

Description: Asynchronously removes all entries from the persistent image cache, clearing both in-memory and on-disk storage.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 1.37)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 1.39)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 1.52)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 1.55)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 1.58)
- [mps.api.image_cache.AsyncPersistentImageCache.set](5dc502b1-4a0d-5dd1-b13d-94f02f75f05f.md) - Related (graph distance 1.61)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 1.66)
- [mps.api.image_cache.AsyncPersistentImageCache.update](b9099bc1-0ee6-547f-b844-bd21c0c852ea.md) - Related (graph distance 2.67)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 2.69)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 2.75)
