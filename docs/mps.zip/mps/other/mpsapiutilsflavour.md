---
id: d3152f57-40bf-54d0-a0a7-17073bed3cc6
type: catalog
title: "mps.api.utils.flavour"
created_at: 2026-06-06T18:47:29.302362+00:00
updated_at: 2026-07-03T06:16:15.004677+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.flavour"
  signature: "flavour = flavours.get((use_linked_data_core, use_open_street_map)) if not use_docker_compose else 'minimal'"
  location: {'line_start': 98, 'line_end': 98, 'col_start': 4, 'col_end': 112}
  parent_qualified_name: "None"
  sha_at_sync: "bc6344c63dfbe62d083bc83a6336042e354196910ea991dffc4bf4a605e27860"
  description: "Selects a configuration flavour based on the `use_linked_data_core` and `use_open_street_map` flags, defaulting to `'minimal'` when `use_docker_compose` is enabled."
---
# mps.api.utils.flavour

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.flavour


variable mps.api.utils.flavour [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:98-98 :: flavour = flavours.get((use_linked_data_core, use_open_street_map)) if not use_docker_compose else 'minimal'

Description: Selects a configuration flavour based on the `use_linked_data_core` and `use_open_street_map` flags, defaulting to `'minimal'` when `use_docker_compose` is enabled.

## Related Documents

- [mps.api.utils.flavours](99e4f257-b792-58b1-a023-c7b18602a57e.md) - Related (graph distance 1.44)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 2.89)
