---
id: 9001d943-860c-5925-9118-8eb1a74d536f
type: catalog
title: "mps.api.image_manager.ImageManager.repositories_in_prefix"
created_at: 2026-06-06T18:47:29.004849+00:00
updated_at: 2026-07-03T06:16:15.061693+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.repositories_in_prefix"
  signature: "repositories_in_prefix = list(filter(lambda repository: repository.startswith(repo_prefix), repositories))"
  location: {'line_start': 344, 'line_end': 344, 'col_start': 12, 'col_end': 118}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "209d320b55f33d107d623d67b915053ceb8bc3458f9bf1e9e149fb999a42a71e"
  description: "Filters the list of repositories to retain only those whose names start with the specified `repo_prefix`."
---
# mps.api.image_manager.ImageManager.repositories_in_prefix

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.repositories_in_prefix


variable mps.api.image_manager.ImageManager.repositories_in_prefix in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:344-344 :: repositories_in_prefix = list(filter(lambda repository: repository.startswith(repo_prefix), repositories))

Description: Filters the list of repositories to retain only those whose names start with the specified `repo_prefix`.

## Related Documents

- [mps.api.image_manager.ImageManager.repositories](7518500a-6dbd-5b7e-95aa-c43b5664b35f.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.response](72b74dcf-45b1-511b-938a-0d645ae30140.md) - Related (graph distance 3.22)
