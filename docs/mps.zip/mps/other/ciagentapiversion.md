---
id: b8f2fa7d-6549-5f11-be04-58ae382cb44a
type: catalog
title: ".ci.agent.apiVersion"
created_at: 2026-06-06T18:47:26.695374+00:00
updated_at: 2026-06-20T22:55:26.054857+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent.apiVersion"
  signature: "apiVersion: v1"
  location: {'line_start': 1, 'line_end': 1, 'col_start': 0, 'col_end': 14}
  parent_qualified_name: ".ci.agent"
  sha_at_sync: "f15401546056c580a76c2c3fd86b1ad831a4d70b92c3d474fd6950935fff6f27"
  description: "Specifies the Kubernetes API version (v1) used for the CI agent resource definition."
---
# .ci.agent.apiVersion

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent.yaml`

# .ci.agent.apiVersion


yaml_key .ci.agent.apiVersion in .ci.agent [yaml] /Users/spark/git/service-model-promotion/.ci/agent.yaml:1-1 :: apiVersion: v1

Description: Specifies the Kubernetes API version (v1) used for the CI agent resource definition.