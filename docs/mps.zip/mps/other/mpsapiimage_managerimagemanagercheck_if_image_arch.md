---
id: 9ca8f2c3-f656-5def-b0db-c4b19e8c4132
type: catalog
title: "mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage"
created_at: 2026-06-06T18:47:28.985849+00:00
updated_at: 2026-07-03T06:16:15.070778+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage"
  signature: "async def check_if_image_archive_exists_on_local_storage(self, tag: str):"
  location: {'line_start': 231, 'line_end': 247, 'col_start': 4, 'col_end': 28}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ebbc3b0670ace977f53ecb89d00704ff40d65a04f878684551411302c801cf81"
  description: "Checks whether an image archive file corresponding to the given tag exists in the local storage directory, returning a boolean result."
---
# mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage


method mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:231-247 :: async def check_if_image_archive_exists_on_local_storage(self, tag: str):

Description: Checks whether an image archive file corresponding to the given tag exists in the local storage directory, returning a boolean result.

## Related Documents

- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 1.19)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 1.20)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.32)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.57)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 2.65)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 2.74)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 3.21)
