---
id: 28d97056-7436-5bca-b84a-17f2a731e29d
type: catalog
title: "mps.api.token_manager.TokenManager.self.use_auth"
created_at: 2026-06-06T18:47:28.318231+00:00
updated_at: 2026-06-20T22:55:26.486048+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.self.use_auth"
  signature: "self.use_auth = False if (self.username is None or self.password is None) and self.provider == 'local' else True"
  location: {'line_start': 29, 'line_end': 29, 'col_start': 8, 'col_end': 120}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "2878f7c4361e622d7ef2716777890228ece51cf95959fb13e2f7b0bb7c1ca11b"
  description: "Instance flag indicating whether authentication is enabled, set to False when using the local provider without both a username and password, and True otherwise."
---
# mps.api.token_manager.TokenManager.self.use_auth

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.self.use_auth


variable mps.api.token_manager.TokenManager.self.use_auth in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:29-29 :: self.use_auth = False if (self.username is None or self.password is None) and self.provider == 'local' else True

Description: Instance flag indicating whether authentication is enabled, set to False when using the local provider without both a username and password, and True otherwise.