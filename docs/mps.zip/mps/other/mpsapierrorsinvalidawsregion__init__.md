---
id: 3400f057-5645-59b4-b20b-7095169ec205
type: catalog
title: "mps.api.errors.InvalidAWSRegion.__init__"
created_at: 2026-06-06T18:47:29.760200+00:00
updated_at: 2026-07-03T06:16:15.078145+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.InvalidAWSRegion.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 53, 'line_end': 54, 'col_start': 4, 'col_end': 55}
  parent_qualified_name: "mps.api.errors.InvalidAWSRegion"
  sha_at_sync: "10042fa7da76bb4f19a80d4a851b1e8419e94b7786987cba0cd7b6f0ecb25c19"
  description: "Initializes an `InvalidAWSRegion` exception instance with the provided error message string."
---
# mps.api.errors.InvalidAWSRegion.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidAWSRegion.__init__


method mps.api.errors.InvalidAWSRegion.__init__ in mps.api.errors.InvalidAWSRegion [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:53-54 :: def __init__(self, message: str):

Description: Initializes an `InvalidAWSRegion` exception instance with the provided error message string.

## Related Documents

- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.24)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.26)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.30)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.32)
- [mps.api.errors.InvalidAWSRegion](6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde.md) - Related (graph distance 1.44)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.37)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.40)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.48)
