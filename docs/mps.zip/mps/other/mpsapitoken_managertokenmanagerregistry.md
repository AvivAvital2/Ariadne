---
id: f40d394c-e24c-58db-86c6-d327648cb3f9
type: catalog
title: "mps.api.token_manager.TokenManager.registry"
created_at: 2026-06-06T18:47:28.315906+00:00
updated_at: 2026-07-03T06:16:15.109656+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.registry"
  signature: "self.registry = registry"
  location: {'line_start': 17, 'line_end': 17, 'col_start': 8, 'col_end': 32}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "39cce2d1468c9c65347cd2faa926b62b23b331a7bca6bea85f56ba565ff6bbde"
  description: "Stores a reference to the registry instance used by the TokenManager for token-related lookups or operations."
---
# mps.api.token_manager.TokenManager.registry

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.registry


variable mps.api.token_manager.TokenManager.registry in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:17-17 :: self.registry = registry

Description: Stores a reference to the registry instance used by the TokenManager for token-related lookups or operations.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.41)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.58)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 1.58)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 1.61)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 1.64)
- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 2.83)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.85)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 2.87)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 2.88)
