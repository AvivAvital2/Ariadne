---
id: 3064fc31-203e-5c7f-8774-d6870429e8e2
type: catalog
title: "documentation.README_standalone.discovery_platform_configuration"
created_at: 2026-06-06T18:47:26.283965+00:00
updated_at: 2026-06-20T22:55:23.474643+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.discovery_platform_configuration"
  signature: "### Discovery Platform configuration"
  location: {'line_start': 59, 'line_end': 87, 'col_start': 0, 'col_end': 36}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "90f073ce39db3cc0aeee2ce83da940bc22c3d53a80233651a0c3995de250eb06"
  description: "I don't have access to the actual content of the README section you're referring to. The metadata you've provided (section name, parent, signature, and location) describes where the code element is located, but the actual text content of the "Discovery Platform configuration" section at lines 59-87 was not included in your message."
---
# documentation.README_standalone.discovery_platform_configuration

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.discovery_platform_configuration


md_section documentation.README_standalone.discovery_platform_configuration in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:59-87 :: ### Discovery Platform configuration

Description: I don't have access to the actual content of the README section you're referring to. The metadata you've provided (section name, parent, signature, and location) describes where the code element is located, but the actual text content of the "Discovery Platform configuration" section at lines 59-87 was not included in your message.

To write an accurate description, please share the actual content of that documentation section.