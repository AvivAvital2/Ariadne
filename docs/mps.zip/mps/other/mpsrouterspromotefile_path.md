---
id: 4232ce15-0a82-5bf1-9a20-d9a1d94712aa
type: catalog
title: "mps.routers.promote.file_path"
created_at: 2026-06-06T18:47:27.628614+00:00
updated_at: 2026-07-03T06:16:14.990591+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.file_path"
  signature: "file_path = os.path.join(dir_name, 'model.zip')"
  location: {'line_start': 82, 'line_end': 82, 'col_start': 8, 'col_end': 55}
  parent_qualified_name: "None"
  sha_at_sync: "3edbc0e8ae7352d65aed981d702d8522ec19f152a946a437e007b6207c6ca8ce"
  description: "Constructs the full file path for a 'model.zip' file by joining the directory name with the filename."
---
# mps.routers.promote.file_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.file_path


variable mps.routers.promote.file_path [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:82-82 :: file_path = os.path.join(dir_name, 'model.zip')

Description: Constructs the full file path for a 'model.zip' file by joining the directory name with the filename.

## Related Documents

- [mps.api.image_manager.ImageManager.zip_file_path](3e1de95d-3bac-5dd8-84da-a0de6c31cf9c.md) - Related (graph distance 1.34)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 1.52)
- [mps.routers.promote.model_filename](5be0fdbe-32b1-5f58-b8d8-540f1d7ea650.md) - Related (graph distance 1.58)
