---
id: e704846b-d46b-5b8d-b5bb-72d52b00553b
type: catalog
title: "mps.api.errors.UnreachableContainerRegistry"
created_at: 2026-06-06T18:47:29.770128+00:00
updated_at: 2026-07-03T06:16:14.946734+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnreachableContainerRegistry"
  signature: "class UnreachableContainerRegistry(ExceptionHandler):"
  location: {'line_start': 69, 'line_end': 72, 'col_start': 0, 'col_end': 67}
  parent_qualified_name: "None"
  sha_at_sync: "2b5af16bac3abc262806d0562426f981679dbf8da70fe581948225892dad3909"
  description: "Exception handler that handles errors occurring when a container registry cannot be reached or accessed."
---
# mps.api.errors.UnreachableContainerRegistry

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnreachableContainerRegistry


class mps.api.errors.UnreachableContainerRegistry [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:69-72 :: class UnreachableContainerRegistry(ExceptionHandler):

Description: Exception handler that handles errors occurring when a container registry cannot be reached or accessed.

## Related Documents

- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 1.34)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.40)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 1.43)
- [mps.api.utils.verify_connection_to_container_registry](1fe550b7-eb9e-5156-8628-77f8352f5d0d.md) - Related (graph distance 1.60)
- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 1.65)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.54)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.63)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.69)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 2.70)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.72)
