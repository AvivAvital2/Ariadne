---
id: 65ebab83-1893-5c2a-a1c6-3d5925f96e41
type: catalog
title: "mps.service.MPS.self.image_manager"
created_at: 2026-06-06T18:47:26.305190+00:00
updated_at: 2026-07-03T06:16:15.026820+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.MPS.self.image_manager"
  signature: "self.image_manager = ImageManager("
  location: {'line_start': 18, 'line_end': 21, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "96373e34714929f2e7fe77d9f6b9d5ff3a6788329cf4c0b7ac1a3995b7fc6c10"
  description: "Initializes an `ImageManager` instance as an attribute of the `MPS` service class, responsible for handling image-related operations within the service."
---
# mps.service.MPS.self.image_manager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.self.image_manager


variable mps.service.MPS.self.image_manager in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:18-21 :: self.image_manager = ImageManager(

Description: Initializes an `ImageManager` instance as an attribute of the `MPS` service class, responsible for handling image-related operations within the service.

## Related Documents

- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 1.40)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.45)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.45)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.53)
- [mps.service.mps](7b6bc492-8863-5c99-bf5e-4a64146df5c1.md) - Related (graph distance 1.64)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.73)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 2.86)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 2.87)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 2.89)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.93)
