---
id: 4fcf3f76-7581-5b3b-b87a-d871ed2d60d5
type: catalog
title: "mps.routers.promote.params_dict"
created_at: 2026-06-06T18:47:27.625507+00:00
updated_at: 2026-07-03T06:16:14.983417+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.params_dict"
  signature: "params_dict = {key: value[0] if len(value) == 1 else value for key, value in params_dict.items()}"
  location: {'line_start': 46, 'line_end': 46, 'col_start': 4, 'col_end': 101}
  parent_qualified_name: "None"
  sha_at_sync: "0d0f2e676c3bd5ba7cd05f40961edce12f2ef5e13fa0ccab763fce31ab0bc11e"
  description: "Flattens a query parameters dictionary by unwrapping single-element value lists into their lone value while preserving multi-element lists as-is."
---
# mps.routers.promote.params_dict

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.params_dict


variable mps.routers.promote.params_dict [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:46-46 :: params_dict = {key: value[0] if len(value) == 1 else value for key, value in params_dict.items()}

Description: Flattens a query parameters dictionary by unwrapping single-element value lists into their lone value while preserving multi-element lists as-is.

## Related Documents

- [mps.routers.promote.params](20f2f1b0-87b3-54f2-9129-6e162bce858c.md) - Related (graph distance 1.62)
- [mps.routers.promote.schema](db1a5046-6f29-597a-b23f-35ecea9392a9.md) - Related (graph distance 2.96)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 3.04)
