---
id: e7af71c1-4712-58c3-b981-9698f644339f
type: catalog
title: "mps.api.utils.MPSSession"
created_at: 2026-06-06T18:47:29.298866+00:00
updated_at: 2026-07-03T06:16:15.118847+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.utils.MPSSession"
  signature: "class MPSSession(requests.Session):"
  location: {'line_start': 14, 'line_end': 23, 'col_start': 0, 'col_end': 84}
  parent_qualified_name: "None"
  sha_at_sync: "6bdaab27a07001fdce94eed4e26fd32b5e506fac0135049f5c8b7e129fc1ab4f"
  description: "A subclass of `requests.Session` that maintains persistent HTTP session state for interacting with the MPS API."
---
# mps.api.utils.MPSSession

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession


class mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:14-23 :: class MPSSession(requests.Session):

Description: A subclass of `requests.Session` that maintains persistent HTTP session state for interacting with the MPS API.

## Related Documents

- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 1.50)
- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 1.58)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 2.91)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 3.17)
