---
id: 1282bf7b-4fcc-5c26-904b-ade6132b5ae2
type: catalog
title: "mps.api.utils.extract_model"
created_at: 2026-06-06T18:47:29.297990+00:00
updated_at: 2026-06-20T22:55:23.153015+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.extract_model"
  signature: "async def extract_model(zip_file_path: str, destination: str):"
  location: {'line_start': 110, 'line_end': 122, 'col_start': 0, 'col_end': 51}
  parent_qualified_name: "None"
  sha_at_sync: "72283e24dfc0031cdd21dbb2c49470faeac03a6bbc43e6fc303108da94a3d3ec"
  description: "Asynchronously extracts a zip archive at the given path into the specified destination directory. Returns the path to the extracted model contents."
---
# mps.api.utils.extract_model

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.extract_model


async_function mps.api.utils.extract_model [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:110-122 :: async def extract_model(zip_file_path: str, destination: str):

Description: Asynchronously extracts a zip archive at the given path into the specified destination directory. Returns the path to the extracted model contents.