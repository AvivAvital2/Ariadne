---
id: 500b36fd-1db3-50a3-ba72-2aaf28537e5b
type: catalog
title: "mps.routers.promote.full_image_path"
created_at: 2026-06-06T18:47:27.624662+00:00
updated_at: 2026-07-03T06:16:15.097404+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.full_image_path"
  signature: "full_image_path = f'{mps.token_manager.registry}/{repo_prefix}/{tag}'"
  location: {'line_start': 34, 'line_end': 34, 'col_start': 8, 'col_end': 77}
  parent_qualified_name: "None"
  sha_at_sync: "b04f78fe2ebeb2d219d1b614e5634892a272587504355a96a3228e9953ff1f32"
  description: "Constructs the complete image path by combining the registry URL, repository prefix, and tag into a formatted string for use in image promotion operations."
---
# mps.routers.promote.full_image_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.full_image_path


variable mps.routers.promote.full_image_path [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:34-34 :: full_image_path = f'{mps.token_manager.registry}/{repo_prefix}/{tag}'

Description: Constructs the complete image path by combining the registry URL, repository prefix, and tag into a formatted string for use in image promotion operations.

## Related Documents

- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 1.49)
- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 1.52)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 1.53)
- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 1.59)
- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 2.75)
- [mps.api.image_manager.ImageManager.zip_file_path](3e1de95d-3bac-5dd8-84da-a0de6c31cf9c.md) - Related (graph distance 2.86)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 2.98)
