---
id: 3b7721ce-8d66-5371-9a43-b9f4c5d3f45a
type: catalog
title: "mps.api.token_manager.TokenManager.get_credentials"
created_at: 2026-06-06T18:47:28.313734+00:00
updated_at: 2026-07-03T06:16:15.110487+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.TokenManager.get_credentials"
  signature: "def get_credentials(self, registry_auth_url: str, username: str = None, password: str = None):"
  location: {'line_start': 72, 'line_end': 81, 'col_start': 4, 'col_end': 9}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "c0b5d92b216de4a0802cea039d5d8c7d89eb7faa988c7442f100e4f1c0156a10"
  description: "Retrieves authentication credentials for a given registry authorization URL, optionally using the provided username and password."
---
# mps.api.token_manager.TokenManager.get_credentials

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.get_credentials


method mps.api.token_manager.TokenManager.get_credentials in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:72-81 :: def get_credentials(self, registry_auth_url: str, username: str = None, password: str = None):

Description: Retrieves authentication credentials for a given registry authorization URL, optionally using the provided username and password.

## Related Documents

- [mps.api.token_manager.TokenManager.stored_credentials](6118c04d-ef3d-537e-a04b-20a6f6cf3f21.md) - Related (graph distance 1.56)
- [mps.api.token_manager.AWSTokenManager.__init__](57f392dc-511c-5b35-a6a9-d2ca1b3fb86e.md) - Related (graph distance 1.63)
- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 1.65)
- [mps.api.token_manager.TokenManager.get_username_and_password](352275c9-9866-54cf-91e4-d353f05e204e.md) - Related (graph distance 2.91)
- [mps.api.token_manager.AWSTokenManager.login](902a7ee2-9f46-53a1-8f0d-766ceb4c012a.md) - Related (graph distance 3.20)
- [mps.api.token_manager.TokenManager._write_credentials_to_file](235b8a53-2362-56d9-ab74-c5209a1b4c88.md) - Related (graph distance 3.22)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 3.24)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 3.29)
