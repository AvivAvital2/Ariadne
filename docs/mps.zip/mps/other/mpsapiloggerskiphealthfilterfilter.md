---
id: fe3155c9-4fa0-5a72-87d8-429ba1343760
type: catalog
title: "mps.api.logger.SkipHealthFilter.filter"
created_at: 2026-06-06T18:47:28.689795+00:00
updated_at: 2026-07-03T06:16:15.099864+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.logger.SkipHealthFilter.filter"
  signature: "def filter(self, record: logging.LogRecord) -> bool:"
  location: {'line_start': 15, 'line_end': 22, 'col_start': 4, 'col_end': 94}
  parent_qualified_name: "mps.api.logger.SkipHealthFilter"
  sha_at_sync: "83cb73a8ff49d53042a5089890d02ae3d63f4e5bef20a343f566364cb42ab94f"
  description: "Filters out log records whose messages reference health check endpoints, returning `False` to suppress them and `True` to allow all other records through."
---
# mps.api.logger.SkipHealthFilter.filter

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.SkipHealthFilter.filter


method mps.api.logger.SkipHealthFilter.filter in mps.api.logger.SkipHealthFilter [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:15-22 :: def filter(self, record: logging.LogRecord) -> bool:

Description: Filters out log records whose messages reference health check endpoints, returning `False` to suppress them and `True` to allow all other records through.

## Related Documents

- [mps.api.logger.SkipHealthFilter](ace7d034-38b2-5493-9c7d-9cd6df5da6fa.md) - Related (graph distance 1.50)
- [mps.api.logger.SkipHealthFilter.filtered_endpoints](1960c946-fc9c-54cd-bf74-cc536adc42cc.md) - Related (graph distance 3.12)
