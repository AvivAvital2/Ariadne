---
id: c88ae587-0a3b-5268-b34c-e7a41432ddda
type: catalog
title: "mps.api.token_manager.AWSTokenManager.self.registry_id"
created_at: 2026-06-06T18:47:28.320646+00:00
updated_at: 2026-07-03T06:16:15.077472+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.self.registry_id"
  signature: "self.registry_id = self.registry[:12]"
  location: {'line_start': 125, 'line_end': 125, 'col_start': 8, 'col_end': 45}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "a028186eba1833dd97af29784b8facff270271b5dab52259b732bf07790cdef6"
  description: "Stores the first 12 characters of the registry identifier, providing a truncated form of the AWS registry value for the token manager instance."
---
# mps.api.token_manager.AWSTokenManager.self.registry_id

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.self.registry_id


variable mps.api.token_manager.AWSTokenManager.self.registry_id in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:125-125 :: self.registry_id = self.registry[:12]

Description: Stores the first 12 characters of the registry identifier, providing a truncated form of the AWS registry value for the token manager instance.

## Related Documents

- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 1.41)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 1.48)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 1.58)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 1.58)
- [mps.api.token_manager.AWSTokenManager.response](67c5381a-ccc2-5500-a502-f007567820c3.md) - Related (graph distance 1.60)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 1.61)
- [mps.api.token_manager.AWSTokenManager.region_name](1dacb1db-2e0a-5c6d-9346-b1edb16f86d5.md) - Related (graph distance 1.65)
- [mps.api.token_manager.AWSTokenManager.__init__](57f392dc-511c-5b35-a6a9-d2ca1b3fb86e.md) - Related (graph distance 1.66)
- [mps.api.token_manager.TokenManager.region_name](f1d74add-cad1-572b-a333-d85b1ed35998.md) - Related (graph distance 2.69)
- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 2.83)
