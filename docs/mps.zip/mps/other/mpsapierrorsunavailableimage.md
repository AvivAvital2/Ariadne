---
id: b5b87be5-2944-5fde-9872-c65220767962
type: catalog
title: "mps.api.errors.UnavailableImage"
created_at: 2026-06-06T18:47:29.770455+00:00
updated_at: 2026-07-03T06:16:15.122123+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnavailableImage"
  signature: "class UnavailableImage(ExceptionHandler):"
  location: {'line_start': 75, 'line_end': 78, 'col_start': 0, 'col_end': 55}
  parent_qualified_name: "None"
  sha_at_sync: "6dd3d64b7a335759ee7dbd720ae81ec9206af8b754719bcd9fb35c70f4c9f8f0"
  description: "Exception handler for cases where a requested image is unavailable, extending the base `ExceptionHandler` class."
---
# mps.api.errors.UnavailableImage

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnavailableImage


class mps.api.errors.UnavailableImage [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:75-78 :: class UnavailableImage(ExceptionHandler):

Description: Exception handler for cases where a requested image is unavailable, extending the base `ExceptionHandler` class.

## Related Documents

- [mps.api.errors.UnableToUploadOneOrMoreImages](73549085-686e-5207-a376-8c21c11d75c1.md) - Related (graph distance 1.42)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 1.49)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.55)
- [mps.api.errors.UnableToGetAuthToken](2fa0fbad-f9c8-5e61-b90e-48175bf78545.md) - Related (graph distance 1.59)
- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 1.65)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.76)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.79)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.82)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 2.85)
