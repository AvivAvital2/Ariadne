---
id: f6c5822f-baca-5af9-b88e-a1a3b0d25885
type: catalog
title: "mps.api.token_manager.TokenManager.login"
created_at: 2026-06-06T18:47:28.314296+00:00
updated_at: 2026-07-03T06:16:15.124242+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.TokenManager.login"
  signature: "async def login(self):"
  location: {'line_start': 90, 'line_end': 116, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "f0aab4658c3e6063ec0178bba8d032ee7d8d36b1c0701d9a49aff3d99bc22290"
  description: "Authenticates with the API by sending login credentials asynchronously and stores the resulting access token for subsequent requests."
---
# mps.api.token_manager.TokenManager.login

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.login


method mps.api.token_manager.TokenManager.login in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:90-116 :: async def login(self):

Description: Authenticates with the API by sending login credentials asynchronously and stores the resulting access token for subsequent requests.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.login](902a7ee2-9f46-53a1-8f0d-766ceb4c012a.md) - Related (graph distance 1.23)
- [mps.api.image_manager.ImageManager.login](04480485-a32b-5214-b53a-765a9c9a5dda.md) - Related (graph distance 1.35)
- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 2.79)
