---
id: 88755e90-2570-5be0-8c60-ae3e61bdad0e
type: catalog
title: "mps.service.MPS.get_token_manager"
created_at: 2026-06-06T18:47:26.302693+00:00
updated_at: 2026-07-03T06:16:14.991678+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.service.MPS.get_token_manager"
  signature: "def get_token_manager(self) -> TokenManager | AWSTokenManager:"
  location: {'line_start': 23, 'line_end': 74, 'col_start': 4, 'col_end': 27}
  parent_qualified_name: "mps.service.MPS"
  sha_at_sync: "5494d973e2d940918d675b0ae5694a30a6db42bba09d58b44c8d0def715a3fca"
  description: "Returns the token manager instance for the MPS service, providing either a standard `TokenManager` or an `AWSTokenManager` depending on the service configuration."
---
# mps.service.MPS.get_token_manager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# mps.service.MPS.get_token_manager


method mps.service.MPS.get_token_manager in mps.service.MPS [python] /Users/spark/git/service-model-promotion/mps/service.py:23-74 :: def get_token_manager(self) -> TokenManager | AWSTokenManager:

Description: Returns the token manager instance for the MPS service, providing either a standard `TokenManager` or an `AWSTokenManager` depending on the service configuration.

## Related Documents

- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.27)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.46)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 1.50)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.53)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 2.69)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 2.73)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.74)
- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 2.75)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 2.85)
- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 2.87)
