---
id: 2b87cf05-a881-5c6d-bf6e-dd63c664e2b8
type: catalog
title: "mps.api.image_manager.ImageManager.push_command"
created_at: 2026-06-06T18:47:28.998144+00:00
updated_at: 2026-07-03T06:16:14.980257+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.push_command"
  signature: "push_command = ("
  location: {'line_start': 127, 'line_end': 133, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "76f4c2f11b28c8c4419f103ee843d1aeb7fcdaa08e79a5820f575b06ff4541dc"
  description: "Defines the shell command string used to push a Docker image to a registry, likely constructed with formatting placeholders for the image name and tag."
---
# mps.api.image_manager.ImageManager.push_command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.push_command


variable mps.api.image_manager.ImageManager.push_command in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:127-133 :: push_command = (

Description: Defines the shell command string used to push a Docker image to a registry, likely constructed with formatting placeholders for the image name and tag.

## Related Documents

- [mps.api.image_manager.ImageManager.inspect_command](08bf5b72-903c-54df-b4b0-ade249fc6655.md) - Related (graph distance 1.42)
- [mps.api.image_manager.ImageManager.build_command](a5945017-a664-5430-9dd0-bbfea34ea71e.md) - Related (graph distance 1.48)
