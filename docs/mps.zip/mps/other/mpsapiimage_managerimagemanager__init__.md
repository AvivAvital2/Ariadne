---
id: 7e00188c-702a-5ba7-9735-0fb573b0793a
type: catalog
title: "mps.api.image_manager.ImageManager.__init__"
created_at: 2026-06-06T18:47:28.983567+00:00
updated_at: 2026-07-03T06:16:14.999694+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.__init__"
  signature: "def __init__(self, token_manager: [TokenManager | AWSTokenManager], export_image_as_file: bool = False):"
  location: {'line_start': 20, 'line_end': 23, 'col_start': 4, 'col_end': 62}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "042d5d260c909b491faa7d68cb4582adb649ac0bb4692181820334c649207c83"
  description: "Initializes an ImageManager instance with a token manager (either TokenManager or AWSTokenManager) for authentication and an optional flag to control whether images are exported as files."
---
# mps.api.image_manager.ImageManager.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.__init__


method mps.api.image_manager.ImageManager.__init__ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:20-23 :: def __init__(self, token_manager: [TokenManager | AWSTokenManager], export_image_as_file: bool = False):

Description: Initializes an ImageManager instance with a token manager (either TokenManager or AWSTokenManager) for authentication and an optional flag to control whether images are exported as files.

## Related Documents

- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 1.44)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 1.60)
- [mps.api.token_manager.AWSTokenManager.__init__](57f392dc-511c-5b35-a6a9-d2ca1b3fb86e.md) - Related (graph distance 1.61)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 2.60)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 2.84)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 2.89)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.90)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 2.95)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 3.02)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 3.08)
