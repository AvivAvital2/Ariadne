---
id: f3678951-3b38-5bbb-93cb-06dcd193a187
type: catalog
title: "mps.api.logger.CustomLogger.extra['delimiter']"
created_at: 2026-06-06T18:47:28.691797+00:00
updated_at: 2026-07-03T06:16:15.115658+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.CustomLogger.extra['delimiter']"
  signature: "extra['delimiter'] = ' ' * (8 - len(logging.getLevelName(log_level)) + 1)"
  location: {'line_start': 10, 'line_end': 10, 'col_start': 8, 'col_end': 81}
  parent_qualified_name: "mps.api.logger.CustomLogger"
  sha_at_sync: "d083f3f19ad38ed7f0c3475abdeff0c69a3587b6daa4be20420b51f8cad78b25"
  description: "Stores a whitespace delimiter string sized to align log output by padding based on the length of the current log level's name."
---
# mps.api.logger.CustomLogger.extra['delimiter']

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.CustomLogger.extra['delimiter']


variable mps.api.logger.CustomLogger.extra['delimiter'] in mps.api.logger.CustomLogger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:10-10 :: extra['delimiter'] = ' ' * (8 - len(logging.getLevelName(log_level)) + 1)

Description: Stores a whitespace delimiter string sized to align log output by padding based on the length of the current log level's name.

## Related Documents

- [mps.api.logger.Logger.log_format](20544901-82a4-5cde-8e92-17ebf78c1ba8.md) - Related (graph distance 1.50)
- [mps.api.logger.Logger.file_formatter](602a21af-d0b0-5b18-939a-1112561f8d98.md) - Related (graph distance 2.94)
- [mps.api.logger.Logger.console_formatter](10b77a84-a8e9-5196-8d6b-0fd076b45055.md) - Related (graph distance 3.00)
