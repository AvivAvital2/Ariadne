---
id: 2757307d-26f0-5c87-8566-199b9f2ee899
type: catalog
title: "mps.api.schemas.ImageParams"
created_at: 2026-06-06T18:47:28.912471+00:00
updated_at: 2026-07-03T06:16:14.977779+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.ImageParams"
  signature: "class ImageParams:"
  location: {'line_start': 53, 'line_end': 55, 'col_start': 0, 'col_end': 17}
  parent_qualified_name: "None"
  sha_at_sync: "ab24eac40c0af76aab264d1ec4f75c24e24ce529cbc5b34e9170b8fa6be2694b"
  description: "Defines the schema for image-related parameters used in API requests or responses within the MPS API."
---
# mps.api.schemas.ImageParams

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.ImageParams


class mps.api.schemas.ImageParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:53-55 :: class ImageParams:

Description: Defines the schema for image-related parameters used in API requests or responses within the MPS API.

## Related Documents

- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 1.40)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.40)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 1.41)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.61)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 1.67)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 2.73)
- [mps.routers.promote.params](20f2f1b0-87b3-54f2-9129-6e162bce858c.md) - Related (graph distance 2.83)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 2.83)
