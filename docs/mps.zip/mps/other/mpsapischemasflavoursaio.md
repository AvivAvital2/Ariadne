---
id: 8bc232c1-2c40-5057-bf17-ff506959fc0a
type: catalog
title: "mps.api.schemas.Flavours.aio"
created_at: 2026-06-06T18:47:28.913741+00:00
updated_at: 2026-06-20T22:55:21.407504+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.Flavours.aio"
  signature: "aio: str"
  location: {'line_start': 10, 'line_end': 10, 'col_start': 4, 'col_end': 12}
  parent_qualified_name: "mps.api.schemas.Flavours"
  sha_at_sync: "f0ad7bf7bb5de3d04a90e6a7f4d6eb9610b917345790412d52641b5c89905f7c"
  description: "Stores the string identifier for the "aio" flavour variant within the `Flavours` schema."
---
# mps.api.schemas.Flavours.aio

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.Flavours.aio


variable mps.api.schemas.Flavours.aio in mps.api.schemas.Flavours [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:10-10 :: aio: str

Description: Stores the string identifier for the "aio" flavour variant within the `Flavours` schema.