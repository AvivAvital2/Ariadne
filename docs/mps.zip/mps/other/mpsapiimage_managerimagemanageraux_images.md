---
id: 3ec0e871-543e-5a41-933e-e1aa7b51c8c9
type: catalog
title: "mps.api.image_manager.ImageManager.aux_images"
created_at: 2026-06-06T18:47:29.002128+00:00
updated_at: 2026-07-03T06:16:15.038058+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.aux_images"
  signature: "aux_images = list(map(lambda image: f'{self.token_manager.registry}/{image}', tags))"
  location: {'line_start': 268, 'line_end': 268, 'col_start': 8, 'col_end': 92}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "c2e2cd7ff4d1b17ed8a97de0a41c0bce7d63ef54ab5937110d0b08def95a62ed"
  description: "Constructs a list of fully-qualified auxiliary image references by prefixing each tag with the token manager's registry URL."
---
# mps.api.image_manager.ImageManager.aux_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.aux_images


variable mps.api.image_manager.ImageManager.aux_images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:268-268 :: aux_images = list(map(lambda image: f'{self.token_manager.registry}/{image}', tags))

Description: Constructs a list of fully-qualified auxiliary image references by prefixing each tag with the token manager's registry URL.

## Related Documents

- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 1.57)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 3.03)
- [mps.routers.promote.auxiliary_image_list](e555d1cb-61ea-523a-8284-a3b7183d411a.md) - Related (graph distance 3.08)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 3.22)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 3.22)
