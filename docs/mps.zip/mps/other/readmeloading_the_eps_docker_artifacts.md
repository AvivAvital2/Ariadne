---
id: 245bf6d1-e2d0-5384-b131-45c9fca9aa3e
type: catalog
title: "README.loading_the_eps_docker_artifacts"
created_at: 2026-06-06T18:47:25.522705+00:00
updated_at: 2026-06-20T22:55:25.398785+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "README.loading_the_eps_docker_artifacts"
  signature: "#### Loading the EPS docker artifacts"
  location: {'line_start': 158, 'line_end': 210, 'col_start': 0, 'col_end': 37}
  parent_qualified_name: "README"
  sha_at_sync: "362716ad8f9d5f50beb4d4ec7da89bb2ffe6ef8d36f29584c6ecc29ff0e3588a"
  description: "Documents the process for loading the EPS Docker image artifacts into a local Docker registry, typically by importing pre-built image tarballs using `docker load`."
---
# README.loading_the_eps_docker_artifacts

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md`

# README.loading_the_eps_docker_artifacts


md_section README.loading_the_eps_docker_artifacts in README [markdown] /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md:158-210 :: #### Loading the EPS docker artifacts

Description: Documents the process for loading the EPS Docker image artifacts into a local Docker registry, typically by importing pre-built image tarballs using `docker load`.