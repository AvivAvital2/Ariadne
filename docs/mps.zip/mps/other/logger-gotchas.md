---
id: 8c71276e-8a41-5c4d-8961-82aa1d8f6965
type: gotcha
title: "Logger Gotchas"
created_at: 2026-06-06T19:03:49.416239+00:00
updated_at: 2026-06-20T22:55:22.832397+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  module_name: "mps.api.logger"
  language: "python"
  source_name: "mps"
---
# Logger Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# Logger Gotchas


# Gotchas and Pitfalls: `mps.api.logger`

### Missing comma creates silent string concatenation
**Trigger:** The `filtered_endpoints` list in `SkipHealthFilter` is missing a comma between two entries.
**Affected Files:** `mps/api/logger.py`
**Fix:** Add the missing comma after `"/modelpromotion/ping"`.
**Category:** type-system
**Example:**
```python
filtered_endpoints = [
    "/healthcheck",
    "/modelpromotion/ping"   # <-- missing comma!
    "/favicon.ico"
]
# Python concatenates the adjacent string literals:
# => ["/healthcheck", "/modelpromotion/ping/favicon.ico"]
# Both "/modelpromotion/ping" and "/favicon.ico" are NEVER filtered.
```

---

### Inverted filter logic suppresses almost everything (or nothing)
**Trigger:** The `filter()` boolean expression uses `not in` inside `any(...)` then negates, which does not implement "skip if message contains any filtered endpoint."
**Affected Files:** `mps/api/logger.py`
**Fix:** Use the correct logic: return `False` if the message contains any filtered endpoint.
**Category:** domain
**Example:**
```python
# Current:
return not any(endpoint not in record.getMessage() for endpoint in filtered_endpoints)
# For a normal request like "/api/foo":
#   "/healthcheck" not in msg  -> True
#   any(...) -> True
#   not True -> False  => normal log lines get DROPPED!

# Correct intent:
return not any(endpoint in record.getMessage() for endpoint in filtered_endpoints)
```

---

### Type annotation `log_level: logging` is wrong type
**Trigger:** Parameter annotated as the `logging` *module* rather than `int` (or `str`).
**Affected Files:** `mps/api/logger.py`
**Fix:** Annotate as `int` (logging levels are ints) and accept `str` only if you convert. Note the module default `level` is a *string* `'INFO'`, which is passed as the int-typed argument.
**Category:** type-system
**Example:**
```python
def __init__(self, component_name, log_level: logging = logging.INFO, ...):
    ...
    file_handler.setLevel(log_level)  # works with str 'INFO' OR int 20 — silently
# But logging.getLevelName(log_level) in makeRecord expects an int level number.
```

---

### `getLevelName` with a string breaks `delimiter` calculation
**Trigger:** `CustomLogger.makeRecord` calls `logging.getLevelName(log_level)`. The actual record `log_level` passed by the logging framework is always an **int**, so this works—but the inconsistency with the string-based `Logger` config masks an assumption. If `log_level` were ever a name string, `getLevelName` round-trips it to an int and `len()` produces a nonsensical delimiter.
**Affected Files:** `mps/api/logger.py`
**Fix:** The arithmetic `8 - len(name) + 1` can go negative for level names longer than 8 chars (e.g., a custom level), producing `' ' * negative = ''`. Guard with `max(1, ...)`.
**Category:** type-system
**Example:**
```python
extra['delimiter'] = ' ' * (8 - len('CRITICAL') + 1)  # 8-8+1 = 1, ok
# Custom level named 'VERYVERBOSE' (11 chars): 8-11+1 = -2 -> '' (no spacing)
```

---

### `setLoggerClass` is global and order-dependent
**Trigger:** `logging.setLoggerClass(CustomLogger)` mutates global state. If `getLogger(component_name)` was already created before the `Logger` is constructed, it won't be a `CustomLogger`, and `delimiter` will be missing from records → `KeyError` in formatting.
**Affected Files:** `mps/api/logger.py`
**Fix:** Ensure all loggers are obtained after `setLoggerClass`, or set a default `delimiter` in the formatter / via a filter. Better: use a `Filter` to inject `delimiter` instead of subclassing.
**Category:** framework
**Example:**
```python
# Elsewhere, executed first:
log = logging.getLogger('model_promotion')  # plain Logger, not CustomLogger
# Later Logger() runs but the cached instance keeps the base class.
# Formatting '%(delimiter)s' -> ValueError/KeyError: 'delimiter'
```

---

### Duplicate handlers on re-instantiation
**Trigger:** `getLogger(component_name)` returns a cached singleton; calling `Logger('model_promotion')` more than once `addHandler`s again, causing duplicate log lines and duplicate file handles.
**Affected Files:** `mps/api/logger.py`
**Fix:** Check `if not _logger.handlers:` before adding, or clear existing handlers.
**Category:** framework
**Example:**
```python
Logger('model_promotion')
Logger('model_promotion')  # now every message prints/writes twice
```

---

### `RotatingFileHandler` not multiprocess-safe
**Trigger:** Under uvicorn/gunicorn with multiple worker processes, several `RotatingFileHandler`s write to the same `log/mps.log`. Rotation is process-local and can corrupt/truncate logs or lose lines during rollover.
**Affected Files:** `mps/api/logger.py`
**Fix:** Use a single logging process (QueueHandler + QueueListener), per-worker filenames, or an external log aggregator. `RotatingFileHandler` rotation has a known race even with threads.
**Category:** thread-safety
**Example:**
```python
# Worker A rotates mps.log -> mps.log.1 while Worker B holds an open fd to old inode.
# Worker B keeps writing to a now-unlinked/renamed file.
```

---

### Log directory must pre-exist
**Trigger:** `RotatingFileHandler('log/mps.log')` raises `FileNotFoundError` at import time if the `log/` directory doesn't exist (relative to CWD, not module).
**Affected Files:** `mps/api/logger.py`
**Fix:** Create the directory first: `os.makedirs(os.path.dirname(log_filename), exist_ok=True)`. Also note the path is relative to the *current working directory*, which varies by launcher.
**Category:** framework
**Example:**
```python
# Run from a directory without ./log:
import mps.api.logger  # FileNotFoundError: [Errno 2] No such file or directory: 'log/mps.log'
```

---

### Import-time side effects and crash-on-bad-env
**Trigger:** Module-level code reads `LOG_LEVEL`, builds the logger, and `raise RuntimeWarning` on unexpected values. Importing the module can crash the whole app, and `RuntimeWarning` is a `Warning`, not an `Exception`-style error—raising it is unusual and confusing.
**Affected Files:** `mps/api/logger.py`
**Fix:** Move setup into a function; default invalid values to INFO with a logged warning, or raise `ValueError`.
**Category:** framework
**Example:**
```python
# LOG_LEVEL=info (lowercase) -> falls into `case _` -> raises at import.
match level:
    case 'INFO' | ...:
        ...
    case _:
        raise RuntimeWarning(...)  # crashes import for 'info', 'Info', ' INFO '
```

---

### Case sensitivity & whitespace in `LOG_LEVEL`
**Trigger:** Match is exact and case-sensitive; `WARN`/`FATAL` are also non-standard logging names. The error message even lists values with leading spaces (`' WARN'`), which would never match.
**Affected Files:** `mps/api/logger.py`
**Fix:** Normalize with `.strip().upper()` and map `WARN→WARNING`, `FATAL→CRITICAL` to real `logging` constants.
**Category:** type-system
**Example:**
```python
level = os.environ.get('LOG_LEVEL', 'INFO')  # 'warn' or 'Debug' both fail
# Also: 'WARN'/'FATAL' aren't canonical logging level names.
```

---

### No `propagate = False` → possible double logging via root
**Trigger:** Named loggers propagate to root by default. If the root logger has handlers configured elsewhere (e.g., by uvicorn or basicConfig), messages appear twice.
**Affected Files:** `mps/api/logger.py`
**Fix:** Set `_logger.propagate = False` if you want isolated output.
**Category:** framework
**Example:**
```python
logging.basicConfig()  # root gets a handler
logger.info("hi")      # printed by your handler AND root's handler
```