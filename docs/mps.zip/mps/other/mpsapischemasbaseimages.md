---
id: 49d4a102-f737-56a4-ae40-4e96c274145f
type: catalog
title: "mps.api.schemas.BaseImages"
created_at: 2026-06-06T18:47:28.911096+00:00
updated_at: 2026-07-03T06:16:14.982312+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.BaseImages"
  signature: "class BaseImages:"
  location: {'line_start': 14, 'line_end': 20, 'col_start': 0, 'col_end': 19}
  parent_qualified_name: "None"
  sha_at_sync: "3d278cd00f0abee86bdcdb92895c842f913afdf02e967d8e35988702696e62a6"
  description: "Defines a schema container for base image references used in the MPS API. Serves as a structured representation of one or more base images."
---
# mps.api.schemas.BaseImages

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.BaseImages


class mps.api.schemas.BaseImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:14-20 :: class BaseImages:

Description: Defines a schema container for base image references used in the MPS API. Serves as a structured representation of one or more base images.

## Related Documents

- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 1.40)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.43)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.46)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.47)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 2.80)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 2.81)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 2.82)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 2.90)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 3.05)
