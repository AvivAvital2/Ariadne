---
id: d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad
type: catalog
title: "mps.api.image_manager.ImageManager"
created_at: 2026-06-06T18:47:28.994167+00:00
updated_at: 2026-07-03T06:16:15.119594+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.image_manager.ImageManager"
  signature: "class ImageManager:"
  location: {'line_start': 19, 'line_end': 351, 'col_start': 0, 'col_end': 115}
  parent_qualified_name: "None"
  sha_at_sync: "1212a292054635ac2e4d222a4c0bf28678c934be7d6412d07c9b835237349c93"
  description: "Manages the lifecycle of container or virtual machine images, providing operations such as creation, retrieval, listing, and deletion."
---
# mps.api.image_manager.ImageManager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager


class mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:19-351 :: class ImageManager:

Description: Manages the lifecycle of container or virtual machine images, providing operations such as creation, retrieval, listing, and deletion.

## Related Documents

- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 1.40)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.55)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 1.65)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 2.85)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 2.85)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 2.85)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 2.92)
- [mps.service.mps](7b6bc492-8863-5c99-bf5e-4a64146df5c1.md) - Related (graph distance 3.04)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 3.05)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 3.05)
