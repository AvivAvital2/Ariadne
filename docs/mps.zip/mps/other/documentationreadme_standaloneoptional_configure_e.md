---
id: 618172c6-1263-5e30-a4ef-961f5fe981db
type: catalog
title: "documentation.README_standalone.optional_configure_exported_image_archives"
created_at: 2026-06-06T18:47:26.285613+00:00
updated_at: 2026-06-20T22:55:24.521650+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.optional_configure_exported_image_archives"
  signature: "#### (Optional) Configure exported image archives"
  location: {'line_start': 184, 'line_end': 197, 'col_start': 0, 'col_end': 50}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "c7f81799f5bd7d4f9c32888f9bed4597f7512572b7de452d7c61025c3bf8e00b"
  description: "Documents the optional configuration for customizing where and how exported container image archives are stored when running the application in standalone mode."
---
# documentation.README_standalone.optional_configure_exported_image_archives

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.optional_configure_exported_image_archives


md_section documentation.README_standalone.optional_configure_exported_image_archives in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:184-197 :: #### (Optional) Configure exported image archives

Description: Documents the optional configuration for customizing where and how exported container image archives are stored when running the application in standalone mode.