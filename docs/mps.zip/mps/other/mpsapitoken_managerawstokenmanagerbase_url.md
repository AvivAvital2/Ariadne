---
id: 12f4babf-5ed5-53e8-8546-6ccbc741379b
type: catalog
title: "mps.api.token_manager.AWSTokenManager.base_url"
created_at: 2026-06-06T18:47:28.322047+00:00
updated_at: 2026-07-03T06:16:14.976311+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.base_url"
  signature: "base_url = await verify_connection_to_container_registry("
  location: {'line_start': 158, 'line_end': 164, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "0aba93d70b4c5c8376732917647215d32b2698e47a0f7e3d0e15f420ddb4bd79"
  description: "Stores the verified base URL of the AWS container registry, obtained by asynchronously confirming connectivity to the registry endpoint."
---
# mps.api.token_manager.AWSTokenManager.base_url

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.base_url


variable mps.api.token_manager.AWSTokenManager.base_url in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:158-164 :: base_url = await verify_connection_to_container_registry(

Description: Stores the verified base URL of the AWS container registry, obtained by asynchronously confirming connectivity to the registry endpoint.

## Related Documents

- [mps.api.token_manager.TokenManager.base_url](18254814-cbc1-548b-9217-db5dfc57bc3d.md) - Related (graph distance 1.07)
- [mps.api.utils.MPSSession.base_url](21e6face-0081-5442-b611-fbecb7c4adc7.md) - Related (graph distance 1.37)
- [mps.api.utils.MPSSession.__init__](e5d5dc79-6074-5bee-b16a-413f978e8f4a.md) - Related (graph distance 2.85)
