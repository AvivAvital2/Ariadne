---
id: 5982b4fa-33a1-5ec9-9742-878c5acc43cd
type: catalog
title: "mps.api.logger.level"
created_at: 2026-06-06T18:47:28.694270+00:00
updated_at: 2026-07-03T06:16:15.038693+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.level"
  signature: "level = os.environ.get('LOG_LEVEL', 'INFO')"
  location: {'line_start': 51, 'line_end': 51, 'col_start': 0, 'col_end': 43}
  parent_qualified_name: "None"
  sha_at_sync: "f7398e9a0b42bffe227c6f88a14d3cc0ca614ccf60323299e99057bbe3a7c99a"
  description: "Module-level variable that sets the logging level from the `LOG_LEVEL` environment variable, defaulting to `'INFO'` if the variable is not set."
---
# mps.api.logger.level

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.level


variable mps.api.logger.level [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:51-51 :: level = os.environ.get('LOG_LEVEL', 'INFO')

Description: Module-level variable that sets the logging level from the `LOG_LEVEL` environment variable, defaulting to `'INFO'` if the variable is not set.

## Related Documents

- [mps.api.logger.logger](903b3696-6e75-5071-9f19-6d10a5038da1.md) - Related (graph distance 1.56)
- [mps.api.errors.ExceptionHandler.self.Logger](e44a3143-66f2-530f-b85e-34ddd1b4545f.md) - Related (graph distance 3.01)
- [mps.api.logger.Logger](b3389511-3834-54f5-836a-78c4848305dc.md) - Related (graph distance 3.19)
- [mps.api.logger.Logger._logger](3b7e98d7-bfd2-5dcc-a8af-1078b647c414.md) - Related (graph distance 3.20)
