---
id: 90d65b9f-8fdc-5294-8171-8bc7354c1e54
type: catalog
title: "mps.api.utils.parse_version_number"
created_at: 2026-06-06T18:47:29.297415+00:00
updated_at: 2026-07-03T06:16:15.076325+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.parse_version_number"
  signature: "async def parse_version_number(version_string: str, as_config_key: bool = False):"
  location: {'line_start': 73, 'line_end': 82, 'col_start': 0, 'col_end': 73}
  parent_qualified_name: "None"
  sha_at_sync: "ca0436909501a5857998ddea015ac88375c34caf5079592cf2582e1fa2989e26"
  description: "Asynchronously parses a version string into a structured version number, optionally formatting the result as a configuration key when `as_config_key` is True."
---
# mps.api.utils.parse_version_number

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.parse_version_number


async_function mps.api.utils.parse_version_number [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:73-82 :: async def parse_version_number(version_string: str, as_config_key: bool = False):

Description: Asynchronously parses a version string into a structured version number, optionally formatting the result as a configuration key when `as_config_key` is True.

## Related Documents

- [mps.api.utils.release_key](f53adf84-f42f-53c1-8374-7aab82e6012d.md) - Related (graph distance 1.37)
