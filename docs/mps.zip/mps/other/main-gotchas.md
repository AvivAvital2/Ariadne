---
id: df2d3fb1-17c2-5ec9-860a-fd0bc83972d9
type: gotcha
title: "  Main   Gotchas"
created_at: 2026-06-06T19:03:11.774825+00:00
updated_at: 2026-06-20T22:55:26.156997+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  module_name: "mps.__main__"
  language: "python"
  source_name: "mps"
---
#   Main   Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

#   Main   Gotchas


# Gotchas and Pitfalls: `mps.__main__`

### Module-level file I/O at import time
**Trigger:** The `open('conf/build.info', ...)` call runs at module import, not inside `main()`. Importing this module from anywhere (tests, tooling, ASGI server) crashes if the file is missing or CWD is wrong.
**Affected Files:** `mps/__main__.py`
**Fix:** Wrap in a function or guard, and resolve path relative to the module rather than CWD. Use a try/except or lazy loading.
**Category:** framework
**Example:**
```python
# Fails if launched from a different working directory:
with open('conf/build.info', 'r') as f:  # FileNotFoundError
    version = json.load(f)['version_tag']

# Better:
from pathlib import Path
conf = Path(__file__).resolve().parent.parent / 'conf' / 'build.info'
```

### `SERVICE_PORT` env var is a string, not an int
**Trigger:** `os.environ.get("SERVICE_PORT", 8010)` returns a default int `8010`, but when the env var IS set it returns a `str`. `uvicorn.run(port=...)` may behave inconsistently or fail depending on version.
**Affected Files:** `mps/__main__.py`
**Fix:** Always coerce: `int(os.environ.get("SERVICE_PORT", 8010))`.
**Category:** type-system
**Example:**
```python
service_port = os.environ.get("SERVICE_PORT", 8010)  # "8011" (str) if set, 8010 (int) if not
uvicorn.run(app, port=service_port)  # type inconsistency / TypeError risk
# Fix:
service_port = int(os.environ.get("SERVICE_PORT", 8010))
```

### Login token expires because event loop is closed before server runs
**Trigger:** `asyncio.run(main())` creates a *new* event loop, runs the login, then **closes** that loop. `uvicorn.run(app)` then starts a *different* loop. Any async resources (aiohttp sessions, connection pools) created during `login()` are bound to the now-closed loop and will raise `RuntimeError: Event loop is closed` when reused.
**Affected Files:** `mps/__main__.py`, `mps/service/mps.py` (token_manager)
**Fix:** Perform login inside a FastAPI startup event / lifespan handler so it runs on the same loop uvicorn uses.
**Category:** async
**Example:**
```python
# Problem: two separate loops
asyncio.run(main())        # loop A created and closed
uvicorn.run(app, ...)      # loop B

# Fix:
@asynccontextmanager
async def lifespan(app):
    await mps.token_manager.login()
    yield
app = FastAPI(lifespan=lifespan, **params)
```

### Token may expire between login and first request
**Trigger:** Even if loops were shared, logging in once at startup means the token is never refreshed. Long-running services will hit 401s after expiry.
**Affected Files:** `mps/__main__.py`, token_manager
**Fix:** Implement lazy re-login / refresh inside the token manager, not a one-shot startup call.
**Category:** domain
**Example:**
```python
await mps.token_manager.login()  # only happens once, ever
```

### `MAINTENANCE_MODE` parsing is brittle
**Trigger:** Only the exact lowercased string `'true'` enables maintenance docs paths. Values like `'1'`, `'yes'`, `'True '` (trailing space) silently disable it.
**Affected Files:** `mps/__main__.py`
**Fix:** Normalize and accept a known set: `os.environ.get('MAINTENANCE_MODE','').strip().lower() in {'true','1','yes'}`.
**Category:** type-system
**Example:**
```python
os.environ['MAINTENANCE_MODE'] = '1'   # ignored, maintenance docs not enabled
os.environ['MAINTENANCE_MODE'] = 'True '  # ignored due to trailing space
```

### Docs URLs only relocated in maintenance mode → conflicting/exposed routes
**Trigger:** When NOT in maintenance mode, FastAPI serves docs at default `/docs`, `/openapi.json`. Combined with `include_in_schema=False` on routers, the swagger UI shows almost no endpoints, which is confusing. In maintenance mode the prefix changes, so clients/bookmarks break across modes.
**Affected Files:** `mps/__main__.py`
**Fix:** Use consistent doc URLs across modes, or disable docs entirely outside maintenance mode explicitly.
**Category:** framework
**Example:**
```python
# Non-maintenance: docs at /docs but nearly empty (most routers hidden)
app.include_router(basic.router, include_in_schema=False)
```

### App object is built at import even under `__main__` guard
**Trigger:** `app = FastAPI(...)` and `include_router` calls are at module top level. This is intentional for ASGI (`uvicorn mps.__main__:app`), but means the maintenance-mode branch is evaluated once at import — changing the env var at runtime has no effect.
**Affected Files:** `mps/__main__.py`
**Fix:** Acceptable if documented, but be aware config is frozen at import time; restart required to change modes.
**Category:** framework
**Example:**
```python
# Setting MAINTENANCE_MODE after import does nothing
app = FastAPI(**params)  # params already resolved
```

### `uvicorn.run(app, ...)` disables reload/workers
**Trigger:** Passing the app *object* (not the `"module:app"` string) to `uvicorn.run` silently prevents `reload=True` and `workers>1` from working. No error is raised.
**Affected Files:** `mps/__main__.py`
**Fix:** Pass the import string when scaling is needed: `uvicorn.run("mps.__main__:app", ...)`.
**Category:** framework
**Example:**
```python
uvicorn.run(app, host=..., port=...)  # workers/reload silently ignored
```

### `version_tag` KeyError crashes startup with cryptic error
**Trigger:** If `build.info` exists but lacks `version_tag`, `json.load(f)['version_tag']` raises `KeyError` at import with no context.
**Affected Files:** `mps/__main__.py`
**Fix:** Use `.get('version_tag', 'unknown')` or validate explicitly.
**Category:** type-system
**Example:**
```python
version = json.load(f)['version_tag']  # KeyError if key missing
```

### Bind to `0.0.0.0` by default exposes service publicly
**Trigger:** Default host `0.0.0.0` binds all interfaces. In some deployment contexts this unintentionally exposes the service.
**Affected Files:** `mps/__main__.py`
**Fix:** Default to `127.0.0.1` unless explicitly intended; document the default.
**Category:** domain
**Example:**
```python
service_host = os.environ.get("SERVICE_HOST", "0.0.0.0")  # all interfaces
```