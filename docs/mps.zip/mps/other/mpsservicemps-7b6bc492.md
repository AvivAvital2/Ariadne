---
id: 7b6bc492-8863-5c99-bf5e-4a64146df5c1
type: catalog
title: "mps.service.mps"
created_at: 2026-06-06T18:47:26.305460+00:00
updated_at: 2026-06-06T19:07:07.247255+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.service.mps"
  signature: "mps = MPS()"
  location: {'line_start': 77, 'line_end': 77, 'col_start': 0, 'col_end': 11}
  parent_qualified_name: None
  sha_at_sync: "1c77a07f9fd41fc1870872192fc6b27eac715abc0b596ec2c60e5f1ed080d045"
  description: "Instantiates the module-level `MPS` service object, providing a shared singleton instance for handling MPS operations."
---
# mps.service.mps

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

variable mps.service.mps [python] /Users/spark/git/service-model-promotion/mps/service.py:77-77 :: mps = MPS()

Description: Instantiates the module-level `MPS` service object, providing a shared singleton instance for handling MPS operations.

## Related Documents

- [mps.service.MPS](1344817b-c5e0-525f-a06e-04aac4d8ad8c.md) - Related (graph distance 1.38)
- [mps.service.MPS.__init__](02c9072a-d854-59c0-9250-5768ad8d046c.md) - Related (graph distance 1.51)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager](d2c8a0f3-6200-56cf-bd7f-4e4bebd30aad.md) - Related (graph distance 3.04)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 3.07)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 3.10)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 3.10)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 3.17)
