---
id: 5e618a5f-3950-5107-a4eb-b8aea0b6f361
type: catalog
title: "mps.api.token_manager.TokenManager.none_values"
created_at: 2026-06-06T18:47:28.319338+00:00
updated_at: 2026-07-03T06:16:15.060178+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.none_values"
  signature: "none_values = list(filter(lambda key: required_params[key] is None, required_params))"
  location: {'line_start': 63, 'line_end': 63, 'col_start': 8, 'col_end': 93}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "29972a70d9e24352df85f66f0de39ac28649c9c0616f8d2a20f46fa9c5994bde"
  description: "A list of keys from `required_params` whose corresponding values are `None`, used to identify missing required parameters."
---
# mps.api.token_manager.TokenManager.none_values

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.none_values


variable mps.api.token_manager.TokenManager.none_values in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:63-63 :: none_values = list(filter(lambda key: required_params[key] is None, required_params))

Description: A list of keys from `required_params` whose corresponding values are `None`, used to identify missing required parameters.

## Related Documents

- [mps.api.token_manager.TokenManager.local_required_params](dffe687c-24ed-5438-b503-8c3cb23c7d49.md) - Related (graph distance 1.57)
- [mps.api.token_manager.TokenManager.required_params](4e2c0707-3cf9-53e1-b037-3cd4ed330632.md) - Related (graph distance 1.58)
- [mps.api.token_manager.TokenManager.authenticated_required_params](88c5775b-0216-5169-9c74-d8ecc1b451c7.md) - Related (graph distance 2.84)
