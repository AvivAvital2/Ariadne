---
id: f3c94327-2a1b-5390-9a08-e423ebc37e8c
type: catalog
title: "mps.routers.promote.router"
created_at: 2026-06-06T18:47:27.615627+00:00
updated_at: 2026-07-03T06:16:15.006191+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.router"
  signature: "router = APIRouter()"
  location: {'line_start': 17, 'line_end': 17, 'col_start': 0, 'col_end': 20}
  parent_qualified_name: "None"
  sha_at_sync: "a0e646f56cb54d447621951f3fa495be54e46bab923759b8b3af99ada0e732b4"
  description: "Creates an APIRouter instance for defining and grouping the promote-related API endpoints in the mps.routers.promote module."
---
# mps.routers.promote.router

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.router


variable mps.routers.promote.router [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:17-17 :: router = APIRouter()

Description: Creates an APIRouter instance for defining and grouping the promote-related API endpoints in the mps.routers.promote module.

## Related Documents

- [mps.routers.basic.router](124f9a48-4686-575b-a662-623f3fafd829.md) - Related (graph distance 1.15)
- [mps.routers.maintenance.router](da191d67-f3f0-5d1d-b747-ba1b6473f80c.md) - Related (graph distance 1.22)
