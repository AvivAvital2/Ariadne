---
id: c763f4e0-50eb-503d-abbf-927541162a1b
type: catalog
title: "mps.api.utils.stdout, stderr"
created_at: 2026-06-06T18:47:29.301063+00:00
updated_at: 2026-07-03T06:16:15.071487+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.stdout, stderr"
  signature: "stdout, stderr = await asyncio.gather("
  location: {'line_start': 47, 'line_end': 50, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "None"
  sha_at_sync: "bac7425ce0732dbc8995cbaa84f16220167610e0d5dbc192bd1f2df58b808025"
  description: "Captures the standard output and standard error streams from an asynchronous subprocess by concurrently awaiting their read operations via `asyncio.gather`."
---
# mps.api.utils.stdout, stderr

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.stdout, stderr


variable mps.api.utils.stdout, stderr [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:47-50 :: stdout, stderr = await asyncio.gather(

Description: Captures the standard output and standard error streams from an asynchronous subprocess by concurrently awaiting their read operations via `asyncio.gather`.

## Related Documents

- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 2.96)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 3.11)
