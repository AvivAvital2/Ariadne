---
id: 5208d1b8-2c19-516d-b565-31fcccb1095b
type: catalog
title: "mps.api.schemas.AuxiliaryImages"
created_at: 2026-06-06T18:47:28.912143+00:00
updated_at: 2026-07-03T06:16:14.939531+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.AuxiliaryImages"
  signature: "class AuxiliaryImages:"
  location: {'line_start': 39, 'line_end': 49, 'col_start': 0, 'col_end': 95}
  parent_qualified_name: "None"
  sha_at_sync: "87f4b59709f6eb013ebf77c1e329150b2e7f73a01d9d2692d1b202275ddbde31"
  description: "Defines a schema representing a collection of auxiliary image references (e.g., bump, normal, or displacement maps) associated with a primary image or material."
---
# mps.api.schemas.AuxiliaryImages

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImages


class mps.api.schemas.AuxiliaryImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:39-49 :: class AuxiliaryImages:

Description: Defines a schema representing a collection of auxiliary image references (e.g., bump, normal, or displacement maps) associated with a primary image or material.

## Related Documents

- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.18)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.36)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 1.46)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 1.51)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.57)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 1.61)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 2.51)
- [mps.api.schemas.AuxiliaryImages.__post_init__](895ec509-465c-5ea4-a061-7ff673eb9d85.md) - Related (graph distance 2.84)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 2.88)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 2.92)
