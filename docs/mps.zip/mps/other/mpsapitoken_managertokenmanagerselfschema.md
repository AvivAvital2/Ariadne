---
id: 3789867a-e5c7-592e-9d81-ec4b23483abc
type: catalog
title: "mps.api.token_manager.TokenManager.self.schema"
created_at: 2026-06-06T18:47:28.317972+00:00
updated_at: 2026-06-20T22:55:25.445914+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.self.schema"
  signature: "self.schema = 'http' if ':' in self.registry and self.provider == 'local' else 'https'"
  location: {'line_start': 28, 'line_end': 28, 'col_start': 8, 'col_end': 94}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "845616020a5881e44f9b7ab98c0b872025824ac9e9b319f6c353d6cbc0ee8e92"
  description: "Sets the URL scheme to 'http' for local providers with a port-specified registry, otherwise defaults to 'https'."
---
# mps.api.token_manager.TokenManager.self.schema

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.self.schema


variable mps.api.token_manager.TokenManager.self.schema in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:28-28 :: self.schema = 'http' if ':' in self.registry and self.provider == 'local' else 'https'

Description: Sets the URL scheme to 'http' for local providers with a port-specified registry, otherwise defaults to 'https'.