---
id: 0c79826e-d46d-5707-8567-4a2cacd5b52f
type: catalog
title: "mps.api.image_manager.ImageManager.upload_missing_auxiliary_images"
created_at: 2026-06-06T18:47:28.986466+00:00
updated_at: 2026-07-03T06:16:15.081015+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.upload_missing_auxiliary_images"
  signature: "async def upload_missing_auxiliary_images(self, tags: list):"
  location: {'line_start': 266, 'line_end': 287, 'col_start': 4, 'col_end': 13}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "749e227dc266e14eeabacd0b9dc4066c0f6bf3c50d9758239cbd521f7c25f60b"
  description: "Asynchronously uploads auxiliary images for the specified tags that are not already present, ensuring the required image set is complete. Returns after processing all provided tags."
---
# mps.api.image_manager.ImageManager.upload_missing_auxiliary_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.upload_missing_auxiliary_images


method mps.api.image_manager.ImageManager.upload_missing_auxiliary_images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:266-287 :: async def upload_missing_auxiliary_images(self, tags: list):

Description: Asynchronously uploads auxiliary images for the specified tags that are not already present, ensuring the required image set is complete. Returns after processing all provided tags.

## Related Documents

- [mps.api.image_manager.ImageManager.aux_images](3ec0e871-543e-5a41-933e-e1aa7b51c8c9.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 1.60)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.85)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 2.97)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 3.05)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 3.06)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 3.16)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 3.20)
