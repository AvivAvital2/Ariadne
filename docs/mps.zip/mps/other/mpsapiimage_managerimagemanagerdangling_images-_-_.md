---
id: 946455d5-78c7-5c4c-8634-7b4b10106fe5
type: catalog
title: "mps.api.image_manager.ImageManager.dangling_images, _, _"
created_at: 2026-06-06T18:47:29.003193+00:00
updated_at: 2026-07-03T06:16:14.977061+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.dangling_images, _, _"
  signature: "dangling_images, _, _ = await run_command("
  location: {'line_start': 305, 'line_end': 310, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "bc4ceaa1b5147a8757085270ca2dc60b19f41b6964a35c14b8c8958464c58fb9"
  description: "Retrieves the list of dangling (untagged) Docker images by asynchronously executing a command, capturing only the command's standard output while discarding the remaining return values."
---
# mps.api.image_manager.ImageManager.dangling_images, _, _

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.dangling_images, _, _


variable mps.api.image_manager.ImageManager.dangling_images, _, _ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:305-310 :: dangling_images, _, _ = await run_command(

Description: Retrieves the list of dangling (untagged) Docker images by asynchronously executing a command, capturing only the command's standard output while discarding the remaining return values.

## Related Documents

- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 1.53)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 1.59)
- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 2.84)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 2.89)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 2.94)
