---
id: 670180bb-83e4-519e-853e-cefa8b7d4fd6
type: catalog
title: "mps.routers.promote.promote"
created_at: 2026-06-06T18:47:27.615281+00:00
updated_at: 2026-07-03T06:16:15.035498+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.promote.promote"
  signature: "async def promote(project_id: str, revision: str, request_obj: Request):"
  location: {'line_start': 44, 'line_end': 104, 'col_start': 0, 'col_end': 56}
  parent_qualified_name: "None"
  sha_at_sync: "11f721aa1f768e66a64ed08db58119ddc73220bc5ddb3189b519dda4554451d5"
  description: "Promotes a specific revision of a project to production, handling the deployment workflow for the identified project and revision via the incoming HTTP request."
---
# mps.routers.promote.promote

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.promote


async_function mps.routers.promote.promote [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:44-104 :: async def promote(project_id: str, revision: str, request_obj: Request):

Description: Promotes a specific revision of a project to production, handling the deployment workflow for the identified project and revision via the incoming HTTP request.

## Related Documents

- [mps.routers.promote.get_promotion_status](1f61f6fb-ba29-543e-a7b7-e7df6fb4a9bf.md) - Related (graph distance 1.54)
