---
id: 201d6d5a-d07b-5776-abf2-3043105af3e5
type: catalog
title: "mps.api.utils.construct_model_id"
created_at: 2026-06-06T18:47:29.297116+00:00
updated_at: 2026-07-03T06:16:15.065163+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.api.utils.construct_model_id"
  signature: "async def construct_model_id(project_id: str, revision: str):"
  location: {'line_start': 63, 'line_end': 70, 'col_start': 0, 'col_end': 19}
  parent_qualified_name: "None"
  sha_at_sync: "78cb5fabb5c5cd6c1998e3a340d3d577f97ab23aadafceae216de1a55833be5b"
  description: "Asynchronously constructs and returns a model identifier string from the given project ID and revision."
---
# mps.api.utils.construct_model_id

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.construct_model_id


async_function mps.api.utils.construct_model_id [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:63-70 :: async def construct_model_id(project_id: str, revision: str):

Description: Asynchronously constructs and returns a model identifier string from the given project ID and revision.

## Related Documents

- [mps.api.image_manager.ImageManager.model_name](5d39322c-bf30-5148-8196-5e504c619f0d.md) - Related (graph distance 1.61)
