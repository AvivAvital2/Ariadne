---
id: 20f2f1b0-87b3-54f2-9129-6e162bce858c
type: catalog
title: "mps.routers.promote.params"
created_at: 2026-06-06T18:47:27.626452+00:00
updated_at: 2026-07-03T06:16:15.058571+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.params"
  signature: "params: PromoteParams = schema.load(params_dict)"
  location: {'line_start': 50, 'line_end': 50, 'col_start': 4, 'col_end': 52}
  parent_qualified_name: "None"
  sha_at_sync: "e13bf3923222e20c4fa82ffceed19854343673be452b54c7e594a7f27b85f95f"
  description: "Deserializes and validates a dictionary of raw request parameters into a typed `PromoteParams` object using the schema's `load` method."
---
# mps.routers.promote.params

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.params


variable mps.routers.promote.params [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:50-50 :: params: PromoteParams = schema.load(params_dict)

Description: Deserializes and validates a dictionary of raw request parameters into a typed `PromoteParams` object using the schema's `load` method.

## Related Documents

- [mps.routers.promote.schema](db1a5046-6f29-597a-b23f-35ecea9392a9.md) - Related (graph distance 1.34)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 1.42)
- [mps.routers.promote.params_dict](4fcf3f76-7581-5b3b-b87a-d871ed2d60d5.md) - Related (graph distance 1.62)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 2.83)
- [mps.__main__.params](fb7a8d60-c8e6-5b24-8660-bc723ec21936.md) - Related (graph distance 3.08)
