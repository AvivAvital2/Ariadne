---
id: 73549085-686e-5207-a376-8c21c11d75c1
type: catalog
title: "mps.api.errors.UnableToUploadOneOrMoreImages"
created_at: 2026-06-06T18:47:29.764028+00:00
updated_at: 2026-07-03T06:16:14.941876+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnableToUploadOneOrMoreImages"
  signature: "class UnableToUploadOneOrMoreImages(ExceptionHandler):"
  location: {'line_start': 57, 'line_end': 60, 'col_start': 0, 'col_end': 68}
  parent_qualified_name: "None"
  sha_at_sync: "0778a5bdb3f4fd27b3acea8ade1cd5728fe899a6f7312e98bd2388dbcef6313a"
  description: "An exception handler class that handles errors occurring when one or more images fail to upload to the MPS API."
---
# mps.api.errors.UnableToUploadOneOrMoreImages

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToUploadOneOrMoreImages


class mps.api.errors.UnableToUploadOneOrMoreImages [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:57-60 :: class UnableToUploadOneOrMoreImages(ExceptionHandler):

Description: An exception handler class that handles errors occurring when one or more images fail to upload to the MPS API.

## Related Documents

- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 1.42)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 1.44)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.49)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.67)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 2.70)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 2.73)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.78)
- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 2.78)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.79)
- [mps.api.errors.InvalidRegistryProvider](e5f7a08a-b659-5159-967e-b31b209f292b.md) - Related (graph distance 2.98)
