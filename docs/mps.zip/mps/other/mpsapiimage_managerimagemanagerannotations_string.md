---
id: 150d071a-af45-5902-a926-a9c51e437df6
type: catalog
title: "mps.api.image_manager.ImageManager.annotations_string"
created_at: 2026-06-06T18:47:28.997089+00:00
updated_at: 2026-06-20T22:55:23.057880+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.annotations_string"
  signature: "annotations_string = '' \"
  location: {'line_start': 57, 'line_end': 59, 'col_start': 8, 'col_end': 85}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "1113a4a8f72ebafbb2e6bcfdc10a76c35fc147f314e587a2e5592e37363f89be"
  description: "Instance variable that stores a string representation of image annotations, initialized as an empty string."
---
# mps.api.image_manager.ImageManager.annotations_string

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.annotations_string


variable mps.api.image_manager.ImageManager.annotations_string in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:57-59 :: annotations_string = '' \

Description: Instance variable that stores a string representation of image annotations, initialized as an empty string.