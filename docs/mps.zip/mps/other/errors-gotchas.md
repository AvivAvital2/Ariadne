---
id: 8431c828-e2df-5e95-9d0f-4871927039e9
type: gotcha
title: "Errors Gotchas"
created_at: 2026-06-06T19:03:29.806039+00:00
updated_at: 2026-06-20T22:55:22.930945+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  module_name: "mps.api.errors"
  language: "python"
  source_name: "mps"
---
# Errors Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# Errors Gotchas


# Gotchas and Pitfalls in `mps.api.errors`

### Parent `Exception` never receives the message via `super().__init__`
**Trigger:** `ExceptionHandler.__init__` sets `self.detail = message` but never calls `super().__init__(message)`. So `self.args` is never populated, yet `__str__` and `__repr__` rely on `self.args[0]`.
**Affected Files:** `mps/api/errors.py`
**Fix:** Call `super().__init__(message)` to populate `self.args`.
**Category:** type-system
**Example:**
```python
try:
    raise NoConfigurationFoundError("missing version")
except NoConfigurationFoundError as e:
    print(str(e))   # IndexError: tuple index out of range — self.args is empty!
```

---

### `__init__` triggers logging as a side effect of construction
**Trigger:** Every instantiation of an `ExceptionHandler` (or subclass) immediately logs an error, even if the exception is caught/handled and never propagated, or constructed for testing.
**Affected Files:** `mps/api/errors.py`
**Fix:** Log at the *raise/catch* site, not in the exception constructor. Constructing an exception object should be side-effect-free.
**Category:** domain
**Example:**
```python
# Even this benign construction logs an ERROR line:
e = UnavailableImage("just checking")  # logger.error fired unexpectedly
```

---

### `sys.excepthook` is mutated inside `__repr__`
**Trigger:** `__repr__` reassigns the global `sys.excepthook` as a side effect. Any code that reprs the exception (debuggers, logging with `%r`, REPL echo) silently changes global interpreter behavior.
**Affected Files:** `mps/api/errors.py`
**Fix:** Never mutate global state in `__repr__`. Remove the `sys.excepthook` assignment; set the hook explicitly during app startup if needed.
**Category:** thread-safety
**Example:**
```python
e = InvalidAWSRegion("bad region")
repr(e)          # globally swaps sys.excepthook — affects all later uncaught exceptions
```

---

### `exception_handler` has wrong signature for an excepthook
**Trigger:** `sys.excepthook` is called with `(type, value, traceback)`, but `exception_handler(self)` accepts no such arguments. If it ever fires, it raises `TypeError`.
**Affected Files:** `mps/api/errors.py`
**Fix:** Use the correct signature `def exception_handler(self, exc_type, exc_value, tb):` if you genuinely intend to use it as a hook.
**Category:** type-system
**Example:**
```python
sys.excepthook = e.exception_handler
raise ValueError("x")   # TypeError: exception_handler() takes 1 positional arg but 4 given
```

---

### A new `Logger` instance is created per exception
**Trigger:** `Logger(__name__).logger` runs on every exception construction. If `Logger.__init__` adds handlers without dedup, this can produce duplicated log lines and accumulate handlers/file descriptors.
**Affected Files:** `mps/api/errors.py`, `mps/api/logger.py`
**Fix:** Use a module-level cached logger (`logging.getLogger(__name__)`), which is idempotent.
**Category:** performance
**Example:**
```python
for i in range(1000):
    try: raise MissingConfigValues("x")
    except MissingConfigValues: pass
# Potentially 1000 logger setups; duplicated handlers → N-times log amplification
```

---

### Inconsistent `status_code` contract across subclasses
**Trigger:** Only `UnableToGetAuthToken` accepts/requires `status_code`. All other subclasses leave it as `None`. Callers expecting `e.status_code` (e.g. an API layer mapping to HTTP responses) silently get `None`.
**Affected Files:** `mps/api/errors.py`
**Fix:** Standardize: either give all errors a meaningful default `status_code`, or document that it's optional and handle `None` at the API boundary.
**Category:** type-system
**Example:**
```python
try:
    raise UnreachableContainerRegistry("down")
except ExceptionHandler as e:
    return Response(status=e.status_code)  # status=None → framework error / 200
```

---

### `UnableToGetAuthToken` requires `status_code` but siblings don't — fragile polymorphism
**Trigger:** Code that raises errors generically (`ErrClass(msg)`) breaks if `ErrClass` happens to be `UnableToGetAuthToken`, which mandates a second positional arg.
**Affected Files:** `mps/api/errors.py`
**Fix:** Make `status_code` keyword with a default (`status_code: int | None = None`) for uniform construction.
**Category:** type-system
**Example:**
```python
def raise_err(cls, msg): raise cls(msg)
raise_err(UnableToGetAuthToken, "expired")  # TypeError: missing 'status_code'
```

---

### `message` parameter is untyped/unvalidated; `self.args[0]` assumes a string
**Trigger:** `ExceptionHandler.__init__(message, ...)` has no type annotation; passing a non-string (e.g. a dict or exception) makes `str(e)` / `%s` formatting behave unexpectedly, and `logger.error(message)` may log non-string objects.
**Affected Files:** `mps/api/errors.py`
**Fix:** Annotate `message: str` on the base class and coerce/validate.
**Category:** type-system
**Example:**
```python
raise NoConfigurationFileFoundError({"err": "x"})  # logs a dict; str repr unhelpful
```

---

### Misleading/duplicated docstrings
**Trigger:** `InvalidConfigurationFile` and `NoConfigurationFileFoundError` share the docstring "Raised if configuration file was not found", though they mean different things.
**Affected Files:** `mps/api/errors.py`
**Fix:** Correct `InvalidConfigurationFile`'s docstring (e.g. "Raised if configuration file is malformed/invalid").
**Category:** domain
**Example:**
```python
help(InvalidConfigurationFile)  # wrong: says "not found" but means "invalid"
```

---

### `# pragma: no cover` hides genuinely broken methods
**Trigger:** `__repr__`, `__str__`, and `exception_handler` are all excluded from coverage, so their bugs (the `self.args[0]` IndexError, the excepthook side-effect, the bad signature) are never caught by tests.
**Affected Files:** `mps/api/errors.py`
**Fix:** Remove the pragmas and add tests for string conversion and representation.
**Category:** domain
**Example:**
```python
# Tests pass; production crashes on str(exception) because dunders aren't covered.
```

---

### Capitalized attribute `self.Logger` shadows convention and confuses introspection
**Trigger:** `self.Logger` (capital L) holds a logger instance, unusual naming that can collide with class-level `Logger` references and confuse readers/tooling.
**Affected Files:** `mps/api/errors.py`
**Fix:** Use lowercase `self._logger`; prefer a module-level logger entirely.
**Category:** domain
**Example:**
```python
e = SelfSignedCertificate("x")
e.Logger  # a logger object on every exception instance — unexpected & memory overhead
```