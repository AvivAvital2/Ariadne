---
id: fdcc994b-76dc-51c1-a22b-16e0fabb83d9
type: gotcha
title: "Dockerfile Gotchas"
created_at: 2026-07-03T05:57:46.122795+00:00
updated_at: 2026-07-03T05:57:46.122807+00:00
source_files:
  - /Users/spark/git/service-model-promotion/Dockerfile
metadata:
  module_name: "builder.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/Dockerfile`

# Dockerfile Gotchas and Pitfalls

### Invalid/Non-existent Base Image Tag
**Trigger:** `python:3.13.12-alpine3.23` references versions that don't exist — Python 3.13.12 and Alpine 3.23 are not released (Alpine's latest is 3.20/3.21, Python 3.13.x patch numbers stop far below .12). The build will fail at pull time, or silently pull a differently-tagged cached image.
**Affected Files:** `builder.Dockerfile`
**Fix:** Pin to a real, existing tag and verify it exists in the Nexus mirror. Add a CI check that pulls the base image.
**Category:** framework
**Example:**
```dockerfile
ARG BASE_IMAGE="python:3.13.12-alpine3.23"  # these versions don't exist
# should be e.g. python:3.13-alpine3.21
```

---

### `${VERSION//v/}` Removes ALL "v" Characters, Not Just the Prefix
**Trigger:** Bash parameter expansion `//v/` is a global substitution. It strips every `v` anywhere in the string, not just the leading `v`. A version like `v1.2.8-dev` works, but `v2.0-preview` becomes `2.0-preiew`.
**Affected Files:** `builder.Dockerfile`
**Fix:** Use single-slash prefix-anchored substitution: `${VERSION/#v/}` (removes only a leading `v`), or strip explicitly.
**Category:** type-system
**Example:**
```dockerfile
# VERSION="v2.0-preview"  ->  "2.0-preiew"  (broke the wheel filename!)
pip install dist/mps-${VERSION//v/}-py3-none-any.whl
# Fix:
pip install dist/mps-${VERSION/#v/}-py3-none-any.whl
```

---

### VERSION Not Validated — Silent Wheel Install Failure
**Trigger:** If `--build-arg VERSION` is omitted, `VERSION` is empty. The wheel path becomes `dist/mps--py3-none-any.whl`, which won't match the built wheel and the `pip install` fails midway through a chained `&&` command with a cryptic error.
**Affected Files:** `builder.Dockerfile`
**Fix:** Add a guard: `RUN test -n "${VERSION}" || (echo "VERSION required" && exit 1)` before use.
**Category:** framework
**Example:**
```dockerfile
ARG VERSION            # no default
pip install dist/mps-${VERSION//v/}-py3-none-any.whl  # empty -> fails obscurely
```

---

### `ENV KEY "value"` Legacy Syntax Includes Quotes Literally in Some Cases
**Trigger:** The space-separated `ENV` form (`ENV VERSION "${VERSION}"`) is deprecated. While Docker handles the quotes here, mixing this with the `=` form is inconsistent and error-prone. Values with special characters can be misparsed.
**Affected Files:** `builder.Dockerfile`
**Fix:** Use `ENV KEY="value"` consistently everywhere.
**Category:** framework
**Example:**
```dockerfile
ENV VERSION "${VERSION}"        # legacy form
ENV PYTHONUNBUFFERED 1          # legacy form
# Prefer: ENV PYTHONUNBUFFERED=1
```

---

### Container Runs as root Despite Creating a Service User
**Trigger:** A `predict` user and `sparkbeyond` group are created, but there is no `USER` directive. The `CMD` runs as **root**. The comment "Run the application as the created user" is misleading — the user is never activated.
**Affected Files:** `builder.Dockerfile`
**Fix:** Add `USER ${EPS_USER}` (or `USER ${EPS_UID}`) before `CMD`, and ensure `SERVICE_HOME` is chowned to that user. Note buildah/fuse-overlayfs often needs specific privileges — verify before switching.
**Category:** framework
**Example:**
```dockerfile
RUN adduser ... predict
# ... no USER directive ...
CMD ["sh", "-c", "python ${SERVICE_HOME}/bin/__main__.py"]  # runs as root!
```

---

### HEALTHCHECK Uses `bash` But Only `sh` Exists in Alpine
**Trigger:** Alpine ships with BusyBox `ash` as `/bin/sh`, not `bash`. The healthcheck invokes `bash -c "[[ ... ]]"`. If `bash` isn't installed (it isn't apk-added here), the healthcheck command fails to execute, marking the container permanently **unhealthy**.
**Affected Files:** `builder.Dockerfile`
**Fix:** Either `apk add bash` or rewrite the healthcheck to POSIX `sh` without `[[ ]]`.
**Category:** framework
**Example:**
```dockerfile
HEALTHCHECK ... CMD ["bash", "-c", "[[ $(curl ...) == \"200\" ]]"]
# bash not installed -> /bin/bash: not found -> always unhealthy
# Fix (POSIX sh):
# CMD sh -c 'test "$(curl -o /dev/null -s -w "%{http_code}" http://localhost:8010/healthcheck)" = "200"'
```

---

### Deleting pip Then Reinstalling Uses Unpinned get-pip.py
**Trigger:** `rm -fr .../pip*` followed by `get-pip.py` installs whatever the latest pip is at build time, breaking reproducibility. Two builds of the same commit can produce different pip versions and thus different resolved sub-deps of any post-install.
**Affected Files:** `builder.Dockerfile`, `get-pip.py`
**Fix:** Pin the pip version: `python get-pip.py "pip==X.Y.Z"` and pin `get-pip.py` itself to a known SHA.
**Category:** performance
**Example:**
```dockerfile
&& /usr/local/bin/python /tmp/get-pip.py   # installs latest pip, non-reproducible
```

---

### `pip-autoremove pip -y` Can Cascade-Remove Wanted Packages
**Trigger:** `pip-autoremove` removes a package **and its now-orphaned dependencies**. Running it on `pip` can uninstall shared dependencies still needed by the app, silently corrupting the runtime environment. The subsequent full pip wipe partially masks this but the site-packages may already be damaged.
**Affected Files:** `builder.Dockerfile`
**Fix:** Avoid `pip-autoremove pip`; if you want to slim pip, just delete `pip*` directories directly (as done later), no autoremove needed.
**Category:** framework
**Example:**
```dockerfile
&& pip install ... pip-autoremove \
&& pip-autoremove pip -y   # may remove setuptools/wheel deps of app packages
```

---

### `virtualenvs.create false` Installs Into System site-packages — COPY Fragility
**Trigger:** Poetry installs into `/usr/local/lib/python3.13/site-packages`, which is then bulk-copied to the final stage. Any package that installs compiled `.so` files linked against `.build-deps` (removed via `apk del .build-deps`) will have missing runtime libs in the final image.
**Affected Files:** `builder.Dockerfile`
**Fix:** Ensure runtime shared libs (libffi, openssl) are installed as non-virtual (`.build-deps` should only hold build-time-only tools). Add runtime deps to the final stage explicitly.
**Category:** framework
**Example:**
```dockerfile
apk add --virtual .build-deps ... libffi-dev openssl-dev
# ... later: apk del .build-deps  # removes libffi/openssl runtime libs too
# cryptography/cffi .so will fail to load in final image
```

---

### Site-packages Path Hard-Codes `python3.13`
**Trigger:** The COPY paths embed `python3.13`. Bumping the base image to 3.14 silently copies nothing (path doesn't exist) or copies to a wrong path — no error is raised by COPY of a non-matching source only if the glob fails; here it's a literal path so it errors, but a version drift in BASE_IMAGE breaks it non-obviously.
**Affected Files:** `builder.Dockerfile`
**Fix:** Derive the version dynamically or centralize it in an ARG (`PY_VER=3.13`) used in both stages.
**Category:** framework
**Example:**
```dockerfile
COPY --from=builder /usr/local/lib/python3.13/site-packages ...  # tied to 3.13
```

---

### Locale Set But Never Generated (Alpine Has No Locales)
**Trigger:** `ENV LC_ALL en_US.UTF-8` on Alpine/musl does nothing useful — musl doesn't ship locale data and `en_US.UTF-8` is not generated. Programs expecting a real UTF-8 locale may warn or fall back to `C`, causing subtle Unicode handling differences.
**Affected Files:** `builder.Dockerfile`
**Fix:** Use `LC_ALL=C.UTF-8` (musl-supported) or install `musl-locales`.
**Category:** framework
**Example:**
```dockerfile
ENV LC_ALL en_US.UTF-8   # not available on musl -> falls back to C
# Fix: ENV LANG=C.UTF-8 LC_ALL=C.UTF-8
```

---

### `rm -fr mps/routes/ mps/api/` After Wheel Build Is a No-op for Runtime
**Trigger:** These dirs are removed from the **builder** source tree after the wheel is already built and installed into site-packages. If `routes`/`api` were packaged into the wheel, they still exist in the installed package — the rm gives a false sense of removal.
**Affected Files:** `builder.Dockerfile`
**Fix:** Exclude these from the wheel via `pyproject.toml` packaging config, not by deleting source post-build.
**Category:** framework
**Example:**
```dockerfile
&& pip install dist/mps-...whl \   # already installed with routes/api inside
&& rm -fr mps/routes/ mps/api/     # only removes source, not installed pkg
```

---

### apk Layer Bloat and Non-deterministic `apk upgrade`
**Trigger:** `apk update && apk upgrade` in both stages pulls latest available packages at build time, making builds non-reproducible and defeating layer caching. Two builds days apart differ.
**Affected Files:** `builder.Dockerfile`
**Fix:** Avoid blanket `apk upgrade`; pin package versions or rely on the base image's patch cadence.
**Category:** performance
**Example:**
```dockerfile
RUN apk update && apk upgrade && apk --no-cache add buildah ...
# apk upgrade -> latest versions -> non-reproducible builds
```

---

### CMD Wraps Python in `sh -c` Making It Non-PID-1 Signal-Deaf
**Trigger:** `CMD ["sh", "-c", "python ..."]` runs python as a child of sh. Depending on shell, SIGTERM from `docker stop` may not propagate to python, causing slow (10s) kills and no graceful shutdown.
**Affected Files:** `builder.Dockerfile`
**Fix:** Use `exec` form or `exec python`: `CMD ["sh", "-c", "exec python ..."]`, or use exec-form CMD directly if no env expansion needed.
**Category:** framework
**Example:**
```dockerfile
CMD ["sh", "-c", "python ${SERVICE_HOME}/bin/__main__.py"]  # python not PID 1, signals dropped
# Fix: CMD ["sh", "-c", "exec python ${SERVICE_HOME}/bin/__main__.py"]
```