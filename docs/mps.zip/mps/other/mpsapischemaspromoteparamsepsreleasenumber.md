---
id: bb8fbd8f-9494-51ae-a400-be0950b9b311
type: catalog
title: "mps.api.schemas.PromoteParams.epsReleaseNumber"
created_at: 2026-06-06T18:47:28.914854+00:00
updated_at: 2026-06-20T22:55:24.834011+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.PromoteParams.epsReleaseNumber"
  signature: "epsReleaseNumber: str"
  location: {'line_start': 25, 'line_end': 25, 'col_start': 4, 'col_end': 25}
  parent_qualified_name: "mps.api.schemas.PromoteParams"
  sha_at_sync: "7201150ed1bed0b4f36de69275bbae271660d83fcc6dcb8e185e3486f191279a"
  description: "Stores the EPS release number as a string, used as a parameter when promoting a release in the `PromoteParams` schema."
---
# mps.api.schemas.PromoteParams.epsReleaseNumber

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams.epsReleaseNumber


variable mps.api.schemas.PromoteParams.epsReleaseNumber in mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:25-25 :: epsReleaseNumber: str

Description: Stores the EPS release number as a string, used as a parameter when promoting a release in the `PromoteParams` schema.