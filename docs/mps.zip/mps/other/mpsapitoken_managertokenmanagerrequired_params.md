---
id: 4e2c0707-3cf9-53e1-b037-3cd4ed330632
type: catalog
title: "mps.api.token_manager.TokenManager.required_params"
created_at: 2026-06-06T18:47:28.319007+00:00
updated_at: 2026-07-03T06:16:15.046454+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.required_params"
  signature: "required_params = dict(sorted((local_required_params | authenticated_required_params).items()))"
  location: {'line_start': 61, 'line_end': 61, 'col_start': 20, 'col_end': 115}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "d9dc52c2584a0c563e9dd7ff5fbb21eeb35600497ae2bee0c1305c0bb4f679e0"
  description: "Class variable holding a merged, alphabetically sorted dictionary of both local and authenticated required parameters used by the TokenManager."
---
# mps.api.token_manager.TokenManager.required_params

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.required_params


variable mps.api.token_manager.TokenManager.required_params in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:61-61 :: required_params = dict(sorted((local_required_params | authenticated_required_params).items()))

Description: Class variable holding a merged, alphabetically sorted dictionary of both local and authenticated required parameters used by the TokenManager.

## Related Documents

- [mps.api.token_manager.TokenManager.local_required_params](dffe687c-24ed-5438-b503-8c3cb23c7d49.md) - Related (graph distance 1.24)
- [mps.api.token_manager.TokenManager.authenticated_required_params](88c5775b-0216-5169-9c74-d8ecc1b451c7.md) - Related (graph distance 1.26)
- [mps.api.token_manager.TokenManager.none_values](5e618a5f-3950-5107-a4eb-b8aea0b6f361.md) - Related (graph distance 1.58)
