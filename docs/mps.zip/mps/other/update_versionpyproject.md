---
id: 968af15c-caa2-58cf-81bf-f35d5dcaa2a0
type: catalog
title: "update_version.pyproject"
created_at: 2026-06-06T18:47:25.295726+00:00
updated_at: 2026-06-20T22:55:22.104329+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "update_version.pyproject"
  signature: "pyproject = tomli.load(f)"
  location: {'line_start': 11, 'line_end': 11, 'col_start': 8, 'col_end': 33}
  parent_qualified_name: "None"
  sha_at_sync: "d3e2da6cc198f716125cadb31fcc06a2bd9bd0dcecb7c1abfdf478e5c62e8b7b"
  description: "Loads and parses the contents of a `pyproject.toml` file into a dictionary using the `tomli` library, reading from the file handle `f`."
---
# update_version.pyproject

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# update_version.pyproject


variable update_version.pyproject [python] /Users/spark/git/service-model-promotion/update_version.py:11-11 :: pyproject = tomli.load(f)

Description: Loads and parses the contents of a `pyproject.toml` file into a dictionary using the `tomli` library, reading from the file handle `f`.