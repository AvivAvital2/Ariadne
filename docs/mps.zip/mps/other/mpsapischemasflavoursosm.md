---
id: 158f2dda-ad59-551f-8cb0-3fd7f47d9750
type: catalog
title: "mps.api.schemas.Flavours.osm"
created_at: 2026-06-06T18:47:28.913430+00:00
updated_at: 2026-07-03T06:16:14.943948+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.Flavours.osm"
  signature: "osm: str"
  location: {'line_start': 9, 'line_end': 9, 'col_start': 4, 'col_end': 12}
  parent_qualified_name: "mps.api.schemas.Flavours"
  sha_at_sync: "34a7d9444f2860eedf13563366769b98fa99b44d4dcb8ca98107382f435ef714"
  description: "Defines the `osm` field of the `Flavours` schema as a string, representing the OSM (OpenStreetMap) flavour configuration."
---
# mps.api.schemas.Flavours.osm

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.Flavours.osm


variable mps.api.schemas.Flavours.osm in mps.api.schemas.Flavours [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:9-9 :: osm: str

Description: Defines the `osm` field of the `Flavours` schema as a string, representing the OSM (OpenStreetMap) flavour configuration.

## Related Documents

- [mps.api.schemas.Flavours.gdata](421f70f2-749b-57fb-802a-4988a0b15516.md) - Related (graph distance 1.62)
- [mps.api.schemas.Flavours.minimal](6f98a8fb-a158-538b-b12d-a9eacc2370cb.md) - Related (graph distance 1.63)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 1.65)
- [mps.api.utils.flavours](99e4f257-b792-58b1-a023-c7b18602a57e.md) - Related (graph distance 3.10)
