---
id: 08731dcb-1f4b-53a6-909a-860999290ad6
type: catalog
title: "mps.api.schemas.PromoteParams.dockerCompose"
created_at: 2026-06-06T18:47:28.915172+00:00
updated_at: 2026-06-20T22:55:26.059238+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.PromoteParams.dockerCompose"
  signature: "dockerCompose: bool = False"
  location: {'line_start': 26, 'line_end': 26, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "mps.api.schemas.PromoteParams"
  sha_at_sync: "deb315dc4ee2ece717e43a102c28fb107268455a2895ce1ead21d3c2d1f25177"
  description: "Optional boolean flag (defaulting to False) on PromoteParams that indicates whether Docker Compose should be used during the promote operation."
---
# mps.api.schemas.PromoteParams.dockerCompose

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams.dockerCompose


variable mps.api.schemas.PromoteParams.dockerCompose in mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:26-26 :: dockerCompose: bool = False

Description: Optional boolean flag (defaulting to False) on PromoteParams that indicates whether Docker Compose should be used during the promote operation.