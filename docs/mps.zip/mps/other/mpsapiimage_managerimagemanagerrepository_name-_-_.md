---
id: 981f05af-6aa4-5d43-b007-43e8db1ef287
type: catalog
title: "mps.api.image_manager.ImageManager.repository_name, _, _"
created_at: 2026-06-06T18:47:28.999726+00:00
updated_at: 2026-07-03T06:16:14.948136+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.repository_name, _, _"
  signature: "repository_name, _, _ = repository_and_tag.partition(':')"
  location: {'line_start': 141, 'line_end': 141, 'col_start': 12, 'col_end': 69}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "267311ab12f4bf0377d89228760b84d7bf8f76790f574a2c96acfe0465319a80"
  description: "Extracts the repository name from a `repository_and_tag` string by splitting on the first colon, discarding the tag and separator portions."
---
# mps.api.image_manager.ImageManager.repository_name, _, _

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.repository_name, _, _


variable mps.api.image_manager.ImageManager.repository_name, _, _ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:141-141 :: repository_name, _, _ = repository_and_tag.partition(':')

Description: Extracts the repository name from a `repository_and_tag` string by splitting on the first colon, discarding the tag and separator portions.

## Related Documents

- [mps.api.image_manager.ImageManager.repository_and_tag](f8a23958-62d7-5fb0-a1d2-1c99bd4089d6.md) - Related (graph distance 1.36)
- [mps.api.utils._, _, image_tag](de1a3c46-4968-53e2-8bb3-c409205df414.md) - Related (graph distance 1.46)
- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 2.69)
