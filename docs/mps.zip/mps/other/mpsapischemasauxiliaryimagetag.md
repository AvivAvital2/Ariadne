---
id: 4c441d3f-7079-518b-9f4c-a8cde1baa7a9
type: catalog
title: "mps.api.schemas.AuxiliaryImage.tag"
created_at: 2026-06-06T18:47:28.916700+00:00
updated_at: 2026-07-03T06:16:15.096018+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.AuxiliaryImage.tag"
  signature: "tag: str = 'latest'"
  location: {'line_start': 35, 'line_end': 35, 'col_start': 4, 'col_end': 23}
  parent_qualified_name: "mps.api.schemas.AuxiliaryImage"
  sha_at_sync: "ed746988243d2720d57016bc0490bb483d5fc037f2e5d2cbd5188c42bd4811ea"
  description: "Specifies the image tag for the auxiliary image, defaulting to `'latest'`."
---
# mps.api.schemas.AuxiliaryImage.tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImage.tag


variable mps.api.schemas.AuxiliaryImage.tag in mps.api.schemas.AuxiliaryImage [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:35-35 :: tag: str = 'latest'

Description: Specifies the image tag for the auxiliary image, defaulting to `'latest'`.

## Related Documents

- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 1.58)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 2.92)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 3.17)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 3.18)
