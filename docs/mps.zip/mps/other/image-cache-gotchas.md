---
id: d4bd6ce7-b44f-53a4-b7bf-0e208047474d
type: gotcha
title: "Image Cache Gotchas"
created_at: 2026-06-06T19:03:36.942815+00:00
updated_at: 2026-06-20T22:55:22.360299+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  module_name: "mps.api.image_cache"
  language: "python"
  source_name: "mps"
---
# Image Cache Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# Image Cache Gotchas


# Gotchas and Pitfalls: `mps.api.image_cache`

### Lock only protects writes, not reads
**Trigger:** `get()` and `list()` bypass `self.lock` entirely; only `_execute()` (writes) acquires it. With a single shared connection, concurrent reads and writes can interleave on the same sqlite connection.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Acquire `self.lock` in `get()` and `list()` too, or use a connection-per-operation model. aiosqlite serializes operations onto a single thread, but a single connection used concurrently can still error or produce inconsistent results across multi-statement flows.
**Category:** thread-safety
**Example:**
```python
async def get(self, key):
    async with self.lock:  # missing!
        async with self.conn.cursor() as cursor:
            await cursor.execute("SELECT value FROM cache WHERE key = ?", (key,))
            result = await cursor.fetchone()
            return result[0] if result else None
```

### Shared single connection across concurrent tasks
**Trigger:** `AsyncPersistentImageCache` holds one `self.conn`. If multiple coroutines call `get`/`set` concurrently using the same instance, they share one cursor pipeline. aiosqlite multiplexes through one worker thread, so simultaneous cursor usage on the same connection can raise or corrupt state.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Either guard ALL DB access with the single lock, or open per-task connections. Document that the instance is not safe for unsynchronized concurrent use.
**Category:** async
**Example:**
```python
cache = await AsyncPersistentImageCache().__aenter__()
await asyncio.gather(cache.get("a"), cache.set("b", data))  # racy
```

### `update()` silently no-ops on missing keys
**Trigger:** `UPDATE ... WHERE key = ?` affects zero rows if the key doesn't exist. No error, no return value—caller cannot tell whether the update happened.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Check `cursor.rowcount` and raise/return a status, or use `INSERT OR REPLACE` if upsert semantics are desired.
**Category:** domain
**Example:**
```python
await cache.update("nonexistent", b"data")  # returns None, did nothing
```

### `None` is ambiguous: missing key vs. stored NULL/falsy value
**Trigger:** `get()` returns `result[0] if result else None`. A stored value that is genuinely `None` (or you can't distinguish a row existing with NULL value) collapses to the same `None` as a cache miss.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Return a sentinel for misses, or return the raw row/tuple and let callers check existence separately.
**Category:** type-system
**Example:**
```python
await cache.set("k", None)   # stores NULL
await cache.get("k")         # None — indistinguishable from a miss
```

### `__aexit__` crashes if connection failed to open
**Trigger:** If `__aenter__` raised before assigning a valid `self.conn`, or `__aexit__` is invoked when `self.conn` is `None`, `await self.conn.close()` raises `AttributeError`, masking the original exception.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Guard the close: `if self.conn: await self.conn.close()`.
**Category:** async
**Example:**
```python
async with AsyncPersistentImageCache() as c:  # connect() fails midway
    ...  # __aexit__ then hits self.conn.close() on partial state
```

### Reusing the same instance across multiple `async with` blocks
**Trigger:** The class is designed as an async context manager but holds state in `self`. After `__aexit__` closes the connection, the instance is reused—calling `get`/`set` operates on a closed connection.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Reset `self.conn = None` in `__aexit__`, and raise a clear error if methods are called outside the context. Don't reuse instances.
**Category:** async
**Example:**
```python
cache = AsyncPersistentImageCache()
async with cache: ...
await cache.get("k")  # operates on closed connection -> error
```

### `commit()` not done inside the cursor/transaction guard consistently
**Trigger:** In `_execute`, `commit()` happens after the cursor's `async with` exits. Reads (`get`, `list`) never commit and run with autocommit-ish behavior; mixing transaction boundaries with the unlocked reads can yield stale/uncommitted views depending on isolation.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Standardize transaction handling; consider `isolation_level=None` (autocommit) or wrap reads in the same lock to ensure committed state is observed.
**Category:** framework
**Example:**
```python
await cache.set("k", v)   # commits under lock
# concurrent get() may read before commit if not locked
```

### `list()` loads the entire cache into memory
**Trigger:** `SELECT key, value FROM cache` with `fetchall()` materializes every BLOB into a Python dict. For an image cache, this can be gigabytes.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Return only keys, or stream rows with `async for`, or paginate. Avoid loading all BLOBs at once.
**Category:** performance
**Example:**
```python
all_images = await cache.list()  # OOM risk with large/many images
```

### `cursor.execute` with `parameters=None` may pass `None` to driver
**Trigger:** `clear()` calls `_execute("DELETE FROM cache")` → `_execute(query, None)` → `cursor.execute(query, None)`. Passing `None` as parameters is generally accepted, but relies on driver tolerance rather than calling the single-arg form.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Conditionally call `cursor.execute(query)` when `parameters is None`.
**Category:** framework
**Example:**
```python
async with self.conn.cursor() as cursor:
    if parameters is None:
        await cursor.execute(query)
    else:
        await cursor.execute(query, parameters)
```

### Directory `image_cache_path` may not exist
**Trigger:** `os.path.join(image_cache_path, ...)` builds a path, but `aiosqlite.connect` won't create missing parent directories—it raises `OperationalError: unable to open database file`.
**Affected Files:** `mps/api/image_cache.py`, `mps/api/config.py`
**Fix:** `os.makedirs(image_cache_path, exist_ok=True)` before connecting.
**Category:** framework
**Example:**
```python
self.conn = await aiosqlite.connect(self.db_path)  # fails if dir missing
```

### `lock` is bound to the event loop at construction-ish time
**Trigger:** `asyncio.Lock()` created in `__init__` binds to the running loop. If the instance is created in one loop and used in another (e.g., across `asyncio.run` calls or in tests), you may get `RuntimeError: got Future attached to a different loop`.
**Affected Files:** `mps/api/image_cache.py`
**Fix:** Create the lock lazily inside `__aenter__` (within the loop that will use it).
**Category:** async
**Example:**
```python
cache = AsyncPersistentImageCache()  # lock bound to current loop
asyncio.run(use(cache))  # new loop -> potential loop mismatch
```