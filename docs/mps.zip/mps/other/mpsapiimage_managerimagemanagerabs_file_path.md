---
id: e20816a3-c6c3-5c33-998b-da53b03788a3
type: catalog
title: "mps.api.image_manager.ImageManager.abs_file_path"
created_at: 2026-06-06T18:47:28.997882+00:00
updated_at: 2026-07-03T06:16:15.009602+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.abs_file_path"
  signature: "abs_file_path = f"{os.path.join(exported_image_path, docker_image_to_file_name(tag))}.tar.gz"
  location: {'line_start': 233, 'line_end': 233, 'col_start': 12, 'col_end': 105}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "5cfbb285fb94fdb025195f06f9a49fec5eaa461c5521d7786642ac66d445d9c2"
  description: "Constructs the absolute file path for an exported Docker image by joining the export directory with a filename derived from the image tag, appended with a `.tar.gz` extension."
---
# mps.api.image_manager.ImageManager.abs_file_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.abs_file_path


variable mps.api.image_manager.ImageManager.abs_file_path in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:233-233 :: abs_file_path = f"{os.path.join(exported_image_path, docker_image_to_file_name(tag))}.tar.gz"

Description: Constructs the absolute file path for an exported Docker image by joining the export directory with a filename derived from the image tag, appended with a `.tar.gz` extension.

## Related Documents

- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 1.16)
- [mps.api.image_manager.ImageManager.zip_file_path](3e1de95d-3bac-5dd8-84da-a0de6c31cf9c.md) - Related (graph distance 1.66)
- [mps.api.utils.docker_image_to_file_name](73847514-b1fb-5627-8728-c3c254d4f051.md) - Related (graph distance 2.73)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 2.75)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 2.80)
- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 2.82)
- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 3.00)
