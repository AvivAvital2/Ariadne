---
id: 6efbf190-8871-569d-b22a-0da70c142f68
type: gotcha
title: "Service Gotchas"
created_at: 2026-06-06T19:04:40.619122+00:00
updated_at: 2026-06-20T22:55:24.887022+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  module_name: "mps.service"
  language: "python"
  source_name: "mps"
---
# Service Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# Service Gotchas


# Gotchas and Pitfalls: `mps.service`

### Module-level singleton instantiated at import time
**Trigger:** The line `mps = MPS()` runs immediately when the module is imported. Any missing/invalid environment variable raises an exception during import, not at first use.
**Affected Files:** `mps/service.py`
**Fix:** Use lazy instantiation (factory function or `functools.lru_cache`) so failures surface when the service is actually used, and to make testing/mocking feasible.
**Category:** framework
**Example:**
```python
# Just importing the module can crash with InvalidRegistryProvider:
import mps.service   # raises if REGISTRY_PROVIDER is unset/invalid

# Better:
@functools.lru_cache(maxsize=1)
def get_mps() -> MPS:
    return MPS()
```

---

### `verify_certificate_signing` default is bool `True`, but env var is always a string
**Trigger:** `os.getenv(..., True)` returns the boolean `True` only when the variable is *absent*. When set, it returns a **string** like `"True"`, `"true"`, or `"yes"`. This silent type mismatch means the default path and the env-set path have different types.
**Affected Files:** `mps/service.py`
**Fix:** Normalize explicitly: `os.getenv("REGISTRY_VERIFY_CERTIFICATE_SIGNING", "true")` then parse uniformly to bool.
**Category:** type-system
**Example:**
```python
# Variable unset  -> True (bool)
# REGISTRY_VERIFY_CERTIFICATE_SIGNING=False -> "False" (str, truthy!)
if self.verify_certificate_signing:   # "False" is truthy -> wrong behavior
    ...
```

---

### `verify_certificate_signing` validation only runs for `local` provider
**Trigger:** The string-to-bool conversion and validation are nested inside `case "local":`. For `aws`/`azure`/`gcp`/`export`, the attribute keeps a raw string and is never validated or used—creating inconsistent state.
**Affected Files:** `mps/service.py`
**Fix:** Parse/validate `verify_certificate_signing` once in `__init__` before the match, independent of provider.
**Category:** domain
**Example:**
```python
# REGISTRY_PROVIDER=aws, REGISTRY_VERIFY_CERTIFICATE_SIGNING="garbage"
# -> no error, self.verify_certificate_signing == "garbage" silently
```

---

### `json.loads("yes")` / arbitrary truthy strings raise instead of converting
**Trigger:** Only the exact lowercase strings `"true"`/`"false"` are accepted. Common values like `"1"`, `"yes"`, `"on"`, `"True "` (trailing space) fall into the `case _` branch and raise `ValueError`, or worse, `"1"` would parse via json.loads to int `1` if the guard were loosened.
**Affected Files:** `mps/service.py`
**Fix:** Use a robust parser, e.g. `value.strip().lower() in {"true","1","yes","on"}`.
**Category:** type-system
**Example:**
```python
REGISTRY_VERIFY_CERTIFICATE_SIGNING="yes"   # raises ValueError
REGISTRY_VERIFY_CERTIFICATE_SIGNING="TRUE " # ".lower()" = "true " -> not in list -> ValueError
```

---

### `export_image_as_file` flag duplicates provider logic redundantly
**Trigger:** `True if self.registry_provider == 'export' else False` is just `self.registry_provider == 'export'`. More importantly, the `export` semantics are spread across two places (`get_token_manager` and `ImageManager` init), so changing the magic string `"export"` requires multiple edits.
**Affected Files:** `mps/service.py`
**Fix:** `export_image_as_file=self.registry_provider == "export"`; centralize the provider string as a constant/enum.
**Category:** framework
**Example:**
```python
export_image_as_file=(self.registry_provider == "export")
```

---

### Provider strings are case-sensitive
**Trigger:** `match` compares exact strings. `REGISTRY_PROVIDER="AWS"` or `"Aws"` falls through to `case _` and raises `InvalidRegistryProvider`, even though the user clearly intended AWS.
**Affected Files:** `mps/service.py`
**Fix:** Normalize: `self.registry_provider = (os.getenv("REGISTRY_PROVIDER") or "").lower()`.
**Category:** type-system
**Example:**
```python
REGISTRY_PROVIDER="AWS"   # -> InvalidRegistryProvider
```

---

### `None` provider produces a confusing error message
**Trigger:** When `REGISTRY_PROVIDER` is unset, `self.registry_provider` is `None`, and the error reads `...Instead got None`, which doesn't clearly indicate the variable is *missing* vs *misspelled*.
**Affected Files:** `mps/service.py`
**Fix:** Special-case the unset condition with a clear "REGISTRY_PROVIDER is not set" message.
**Category:** domain
**Example:**
```python
# unset env -> "Expected ... Instead got None"
```

---

### Empty-string env vars bypass the `None` default
**Trigger:** `os.getenv("REGISTRY_ADDR", None)` returns `""` (empty string), not `None`, if the variable is set but empty. Downstream `TokenManager`/`AWSTokenManager` may not handle `""` the same way as `None`.
**Affected Files:** `mps/service.py`
**Fix:** Treat empty strings as unset: `os.getenv("REGISTRY_ADDR") or None`.
**Category:** type-system
**Example:**
```python
REGISTRY_ADDR=    # set but empty -> self.registry_addr == "" not None
```

---

### Not thread-safe / not re-entrant due to mutated instance attribute
**Trigger:** `self.verify_certificate_signing` is reassigned in place (string → bool). If `get_token_manager` were ever called twice or `MPS` shared across threads during construction, the second pass sees a bool and the guards behave differently. The module-level singleton is also shared globally without synchronization.
**Affected Files:** `mps/service.py`
**Fix:** Compute into a local variable; never mutate the attribute mid-parse. Treat the singleton as immutable after construction.
**Category:** thread-safety
**Example:**
```python
verify = parse_bool(self.verify_certificate_signing)
self.verify_certificate_signing = verify  # set once, after parsing
```

---

### No validation that required credentials are present per provider
**Trigger:** For `aws`/`azure`/`gcp`/`local`, missing `registry_addr`/`registry_user`/`registry_password` are silently passed as `None`. Failures surface deep inside the manager classes with cryptic errors rather than at config time.
**Affected Files:** `mps/service.py`
**Fix:** Validate required fields per provider before constructing managers, raising a clear configuration error.
**Category:** domain
**Example:**
```python
# REGISTRY_PROVIDER=aws but AWS_REGISTRY_REGION unset
# -> AWSTokenManager(region_name=None) fails later, not here
```