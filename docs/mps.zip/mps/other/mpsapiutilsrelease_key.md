---
id: f53adf84-f42f-53c1-8374-7aab82e6012d
type: catalog
title: "mps.api.utils.release_key"
created_at: 2026-06-06T18:47:29.301859+00:00
updated_at: 2026-07-03T06:16:15.070324+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.release_key"
  signature: "release_key = await parse_version_number(release_version, as_config_key=True)"
  location: {'line_start': 89, 'line_end': 89, 'col_start': 4, 'col_end': 81}
  parent_qualified_name: "None"
  sha_at_sync: "1e08ac80bbea04026d91454f695ab44e6af268a297342f65e43ab57675bee128"
  description: "Stores the parsed release version number formatted as a configuration key, obtained by asynchronously calling `parse_version_number` with `as_config_key=True`."
---
# mps.api.utils.release_key

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.release_key


variable mps.api.utils.release_key [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:89-89 :: release_key = await parse_version_number(release_version, as_config_key=True)

Description: Stores the parsed release version number formatted as a configuration key, obtained by asynchronously calling `parse_version_number` with `as_config_key=True`.

## Related Documents

- [mps.api.utils.parse_version_number](90d65b9f-8fdc-5294-8171-8bc7354c1e54.md) - Related (graph distance 1.37)
