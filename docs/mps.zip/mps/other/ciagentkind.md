---
id: 91dc2e5f-ca93-52d1-93b7-77cbf21063b0
type: catalog
title: ".ci.agent.kind"
created_at: 2026-06-06T18:47:26.695816+00:00
updated_at: 2026-06-20T22:55:25.059556+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent.kind"
  signature: "kind: Pod"
  location: {'line_start': 2, 'line_end': 2, 'col_start': 0, 'col_end': 9}
  parent_qualified_name: ".ci.agent"
  sha_at_sync: "7963e6b7d677f6e80a43adf81f7a779334860f2a8f83ed18f09b7123105ac209"
  description: "Specifies that the CI agent runs as a Kubernetes Pod."
---
# .ci.agent.kind

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent.yaml`

# .ci.agent.kind


yaml_key .ci.agent.kind in .ci.agent [yaml] /Users/spark/git/service-model-promotion/.ci/agent.yaml:2-2 :: kind: Pod

Description: Specifies that the CI agent runs as a Kubernetes Pod.