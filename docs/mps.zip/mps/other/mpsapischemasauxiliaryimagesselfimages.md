---
id: a972b94b-def2-52ce-9596-3e368fa6b932
type: catalog
title: "mps.api.schemas.AuxiliaryImages.self.images"
created_at: 2026-06-06T18:47:28.917308+00:00
updated_at: 2026-07-03T06:16:15.050485+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.AuxiliaryImages.self.images"
  signature: "self.images = []"
  location: {'line_start': 43, 'line_end': 43, 'col_start': 8, 'col_end': 24}
  parent_qualified_name: "mps.api.schemas.AuxiliaryImages"
  sha_at_sync: "45c7e796f2b9a8d97f40dc2efe5468d7783c1f055c660368a1333f42915b1e5d"
  description: "Initializes the `images` instance attribute as an empty list to store the auxiliary image entries for the `AuxiliaryImages` schema."
---
# mps.api.schemas.AuxiliaryImages.self.images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImages.self.images


variable mps.api.schemas.AuxiliaryImages.self.images in mps.api.schemas.AuxiliaryImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:43-43 :: self.images = []

Description: Initializes the `images` instance attribute as an empty list to store the auxiliary image entries for the `AuxiliaryImages` schema.

## Related Documents

- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.36)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 1.43)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 1.44)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 1.52)
- [mps.api.image_manager.ImageManager.missing_auxiliary_images](beb57c1d-01a2-595a-a013-de7ef5cabe27.md) - Related (graph distance 1.56)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.57)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 1.59)
- [mps.api.schemas.AuxiliaryImages.__post_init__](895ec509-465c-5ea4-a061-7ff673eb9d85.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.stored_images](e9031a30-a2eb-54a4-bdcb-034b6e0bc3be.md) - Related (graph distance 2.74)
