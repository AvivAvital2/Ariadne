---
id: 5be0fdbe-32b1-5f58-b8d8-540f1d7ea650
type: catalog
title: "mps.routers.promote.model_filename"
created_at: 2026-06-06T18:47:27.625822+00:00
updated_at: 2026-07-03T06:16:15.066524+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.model_filename"
  signature: "model_filename = 'model.zip'"
  location: {'line_start': 47, 'line_end': 47, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "None"
  sha_at_sync: "975c1212d580d0b53242f8d3a68376fc7526e5e1fd7d1096075b6f4c973150b1"
  description: "Defines the standard filename (`'model.zip'`) used for the serialized model archive in the promote router."
---
# mps.routers.promote.model_filename

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.model_filename


variable mps.routers.promote.model_filename [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:47-47 :: model_filename = 'model.zip'

Description: Defines the standard filename (`'model.zip'`) used for the serialized model archive in the promote router.

## Related Documents

- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.zip_file_path](3e1de95d-3bac-5dd8-84da-a0de6c31cf9c.md) - Related (graph distance 2.92)
