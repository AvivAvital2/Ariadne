---
id: 26783d80-9b8e-57d1-a7cd-c7ccfa993d2d
type: catalog
title: "mps.api.errors.ExceptionHandler.message"
created_at: 2026-06-06T18:47:29.771803+00:00
updated_at: 2026-07-03T06:16:15.025402+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.errors.ExceptionHandler.message"
  signature: "self.detail = message"
  location: {'line_start': 8, 'line_end': 8, 'col_start': 8, 'col_end': 29}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "3a71311b9ddde6d2b7f88b0a90a1666e22d2692e695dd16b94abfda63dc30397"
  description: "Stores the exception's descriptive message as the `detail` attribute on the `ExceptionHandler` instance."
---
# mps.api.errors.ExceptionHandler.message

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.message


variable mps.api.errors.ExceptionHandler.message in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:8-8 :: self.detail = message

Description: Stores the exception's descriptive message as the `detail` attribute on the `ExceptionHandler` instance.

## Related Documents

- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.59)
- [mps.api.errors.ExceptionHandler.__init__](217d2c38-8594-57a8-b81f-9b6355041445.md) - Related (graph distance 1.61)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.66)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.71)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.78)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.81)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.82)
