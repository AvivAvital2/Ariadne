---
id: a9dd01b7-2426-5031-ac95-c881ede6158d
type: catalog
title: "mps.api.image_manager.ImageManager.stdout_size, _, _"
created_at: 2026-06-06T18:47:29.003450+00:00
updated_at: 2026-07-03T06:16:15.094806+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.stdout_size, _, _"
  signature: "stdout_size, _, _ = await run_command('buildah images --format {{.Size}}')"
  location: {'line_start': 322, 'line_end': 322, 'col_start': 8, 'col_end': 82}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ce62a3d75bcd5b771d6e64f0929f08881028b6de0671423b8580c8238ef36597"
  description: "Captures the output of a `buildah images` command to retrieve container image sizes, unpacking only the stdout while discarding the remaining return values (such as exit code and stderr)."
---
# mps.api.image_manager.ImageManager.stdout_size, _, _

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.stdout_size, _, _


variable mps.api.image_manager.ImageManager.stdout_size, _, _ in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:322-322 :: stdout_size, _, _ = await run_command('buildah images --format {{.Size}}')

Description: Captures the output of a `buildah images` command to retrieve container image sizes, unpacking only the stdout while discarding the remaining return values (such as exit code and stderr).

## Related Documents

- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 1.25)
- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 1.62)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 2.94)
- [mps.api.utils.stdout, stderr](c763f4e0-50eb-503d-abbf-927541162a1b.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 3.18)
