---
id: 6b464b8f-6b18-5983-ad4a-af0a5dd278ce
type: catalog
title: ".ariadne.manifest.merged_scip"
created_at: 2026-06-06T18:47:25.554747+00:00
updated_at: 2026-06-06T19:01:02.579426+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ariadne/manifest.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".ariadne.manifest.merged_scip"
  signature: ""merged_scip": "index.scip""
  location: {'line_start': 30, 'line_end': 30, 'col_start': 2, 'col_end': 29}
  parent_qualified_name: ".ariadne.manifest"
  sha_at_sync: "8db5c54ac1602d458ca815b8bd151d279da998ddb82a675b319528d609173210"
  description: "Specifies the filename of the merged SCIP (Source Code Indexing Protocol) index file within the Ariadne manifest, here set to "index.scip"."
---
# .ariadne.manifest.merged_scip

**Related files:**
- `/Users/spark/git/service-model-promotion/.ariadne/manifest.json`

json_key .ariadne.manifest.merged_scip in .ariadne.manifest [json] /Users/spark/git/service-model-promotion/.ariadne/manifest.json:30-30 :: "merged_scip": "index.scip"

Description: Specifies the filename of the merged SCIP (Source Code Indexing Protocol) index file within the Ariadne manifest, here set to "index.scip".