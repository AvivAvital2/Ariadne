---
id: 608cb4c7-b3f9-58cc-be19-857775969202
type: catalog
title: "mps.conf.defaults.exported_images"
created_at: 2026-06-06T18:47:29.693406+00:00
updated_at: 2026-07-03T06:16:15.005378+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/conf/defaults.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: "mps.conf.defaults.exported_images"
  signature: "exported_images": {"
  location: {'line_start': 5, 'line_end': 7, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "mps.conf.defaults"
  sha_at_sync: "632f05d878f4aea24e1bd1b80116d44da390eed79674b27e1ae49a3a34b6cf8d"
  description: "Defines the default configuration settings for exported images within the MPS configuration defaults."
---
# mps.conf.defaults.exported_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/conf/defaults.json`

# mps.conf.defaults.exported_images


json_key mps.conf.defaults.exported_images in mps.conf.defaults [json] /Users/spark/git/service-model-promotion/mps/conf/defaults.json:5-7 :: "exported_images": {

Description: Defines the default configuration settings for exported images within the MPS configuration defaults.

## Related Documents

- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 1.05)
- [mps.conf.defaults.local_image_cache](d1c16c36-5d5f-50ac-9f19-a84cbd69a748.md) - Related (graph distance 1.37)
- [mps.defaults.local_image_cache](fbb32597-89ea-5e70-9f13-c6c729c197d9.md) - Related (graph distance 1.41)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 1.52)
- [mps.conf.defaults.general](c8d74d5e-6366-5eb7-8fa7-09bf252718c2.md) - Related (graph distance 1.55)
- [mps.defaults.general](2544c733-f42f-515c-9797-59ab1130e0a9.md) - Related (graph distance 1.59)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 2.79)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 3.07)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 3.08)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 3.15)
