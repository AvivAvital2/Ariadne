---
id: 57143008-764f-5da7-b32a-c853c8e8c11f
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.self.lock"
created_at: 2026-06-06T18:47:29.722144+00:00
updated_at: 2026-07-03T06:16:14.990992+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.self.lock"
  signature: "self.lock = asyncio.Lock()"
  location: {'line_start': 11, 'line_end': 11, 'col_start': 8, 'col_end': 34}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "5682c6ff07131fe620bcdd3578568b09c37cee7218d656eebdfb63beb03d9d59"
  description: "An asyncio lock used to synchronize concurrent access to the cache, preventing race conditions during asynchronous read/write operations on the persistent image cache."
---
# mps.api.image_cache.AsyncPersistentImageCache.self.lock

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.self.lock


variable mps.api.image_cache.AsyncPersistentImageCache.self.lock in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:11-11 :: self.lock = asyncio.Lock()

Description: An asyncio lock used to synchronize concurrent access to the cache, preventing race conditions during asynchronous read/write operations on the persistent image cache.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.self.lock](55bbe536-6bf2-5b31-9588-88fb729c745b.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 1.43)
- [mps.api.image_cache.AsyncPersistentImageCache.self.conn](b23eeb5a-2004-5f5d-9a28-8bee812c752d.md) - Related (graph distance 1.53)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 1.56)
- [mps.api.image_cache.AsyncPersistentImageCache.__aenter__](c6697df2-7934-5a7a-96ef-42333bcee700.md) - Related (graph distance 1.63)
