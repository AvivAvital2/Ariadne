---
id: 30c1ce79-3607-5c21-97ec-a439b7f04a4a
type: catalog
title: "mps.api.image_manager.ImageManager.debug_messages"
created_at: 2026-06-06T18:47:29.001085+00:00
updated_at: 2026-06-20T22:55:25.678733+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.debug_messages"
  signature: "debug_messages = {"
  location: {'line_start': 194, 'line_end': 199, 'col_start': 16, 'col_end': 17}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "746be632aa4f94bca2f3990f7068141bb9e5d023e0557ad72e5e451cca53e200"
  description: "A dictionary mapping debug message keys to their corresponding text strings, used by the ImageManager to provide standardized debug output."
---
# mps.api.image_manager.ImageManager.debug_messages

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.debug_messages


variable mps.api.image_manager.ImageManager.debug_messages in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:194-199 :: debug_messages = {

Description: A dictionary mapping debug message keys to their corresponding text strings, used by the ImageManager to provide standardized debug output.