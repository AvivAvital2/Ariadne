---
id: 084aaffb-03f0-5dc4-a843-f2dd1811c343
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.list"
created_at: 2026-06-06T18:47:29.719777+00:00
updated_at: 2026-07-03T06:16:15.104820+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.list"
  signature: "async def list(self):"
  location: {'line_start': 36, 'line_end': 40, 'col_start': 4, 'col_end': 57}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "997f80c89091bb54233dfd2fb3174e237f63d0d0ecb86e44f3eb9dc59b82c345"
  description: "Asynchronously retrieves and returns a list of all cached image entries in the persistent cache."
---
# mps.api.image_cache.AsyncPersistentImageCache.list

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.list


method mps.api.image_cache.AsyncPersistentImageCache.list in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:36-40 :: async def list(self):

Description: Asynchronously retrieves and returns a list of all cached image entries in the persistent cache.

## Related Documents

- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 1.36)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 1.38)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 1.39)
- [mps.routers.maintenance.list_images](dba494fa-4ba4-5080-8dd6-afee381e737c.md) - Related (graph distance 1.49)
- [mps.api.image_cache.AsyncPersistentImageCache.results](34a6adec-7571-5b19-a7f7-6c2158915e2f.md) - Related (graph distance 1.58)
- [mps.routers.maintenance.remote_images](9cd933a2-32f1-5a4d-87ee-cd05d12fa057.md) - Related (graph distance 2.61)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 2.74)
- [mps.routers.maintenance.delete_local_images](e7bd0b0a-6635-59aa-b7ab-72f4c2ab7f1b.md) - Related (graph distance 2.74)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 2.76)
- [mps.api.image_manager.ImageManager.get_exported_image_list](70dae0c7-4d5f-5c6a-98bb-1b86d0bb851a.md) - Related (graph distance 2.80)
