---
id: ca15b54b-d63c-5d90-9adb-6e462c0058e8
type: catalog
title: "mps.api.errors.SelfSignedCertificate.__init__"
created_at: 2026-06-06T18:47:29.761478+00:00
updated_at: 2026-07-03T06:16:15.102717+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.SelfSignedCertificate.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 82, 'line_end': 83, 'col_start': 4, 'col_end': 60}
  parent_qualified_name: "mps.api.errors.SelfSignedCertificate"
  sha_at_sync: "e8ae6dc6e208681c915ab60ad7de53d566e6dd0ace059e84e3d3d4c22154ed7e"
  description: "Initializes a SelfSignedCertificate error instance with the provided message string."
---
# mps.api.errors.SelfSignedCertificate.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.SelfSignedCertificate.__init__


method mps.api.errors.SelfSignedCertificate.__init__ in mps.api.errors.SelfSignedCertificate [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:82-83 :: def __init__(self, message: str):

Description: Initializes a SelfSignedCertificate error instance with the provided message string.

## Related Documents

- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.25)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.27)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.30)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.31)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.32)
- [mps.api.errors.ExceptionHandler.__init__](217d2c38-8594-57a8-b81f-9b6355041445.md) - Related (graph distance 1.41)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.43)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.46)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.48)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.49)
