---
id: 1dacb1db-2e0a-5c6d-9346-b1edb16f86d5
type: catalog
title: "mps.api.token_manager.AWSTokenManager.region_name"
created_at: 2026-06-06T18:47:28.320387+00:00
updated_at: 2026-07-03T06:16:15.074889+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.region_name"
  signature: "self.region_name = region_name"
  location: {'line_start': 124, 'line_end': 124, 'col_start': 8, 'col_end': 38}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "ad7542cd7f02278fcefd4c522c232624605ac93f77fbacaca7db097920d04eb0"
  description: "Stores the AWS region name for the `AWSTokenManager` instance, used to configure region-specific AWS service requests."
---
# mps.api.token_manager.AWSTokenManager.region_name

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.region_name


variable mps.api.token_manager.AWSTokenManager.region_name in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:124-124 :: self.region_name = region_name

Description: Stores the AWS region name for the `AWSTokenManager` instance, used to configure region-specific AWS service requests.

## Related Documents

- [mps.api.token_manager.TokenManager.region_name](f1d74add-cad1-572b-a333-d85b1ed35998.md) - Related (graph distance 1.04)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 1.42)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.65)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 2.76)
- [mps.service.MPS.self.registry_provider](f73c4d6b-5dad-5cdc-84dc-5114f59c94d0.md) - Related (graph distance 2.76)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 2.79)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 2.80)
