---
id: 8289ab8f-a80a-5ede-9717-88d387d32693
type: catalog
title: "documentation.README_dp_integrated.optional_configure_exported_image_archives"
created_at: 2026-06-06T18:47:26.101022+00:00
updated_at: 2026-06-20T22:55:25.036759+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_dp_integrated.optional_configure_exported_image_archives"
  signature: "#### (Optional) Configure exported image archives"
  location: {'line_start': 114, 'line_end': 129, 'col_start': 0, 'col_end': 50}
  parent_qualified_name: "documentation.README_dp_integrated"
  sha_at_sync: "2d2e5fe745f60e03530925850ac4c30c779c9ff41de021e742617e20a76d6dd3"
  description: "This section explains how to optionally configure the export of container image archives, detailing the relevant settings for specifying archive output locations and formats during the integration setup."
---
# documentation.README_dp_integrated.optional_configure_exported_image_archives

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md`

# documentation.README_dp_integrated.optional_configure_exported_image_archives


md_section documentation.README_dp_integrated.optional_configure_exported_image_archives in documentation.README_dp_integrated [markdown] /Users/spark/git/service-model-promotion/documentation/README_dp_integrated.md:114-129 :: #### (Optional) Configure exported image archives

Description: This section explains how to optionally configure the export of container image archives, detailing the relevant settings for specifying archive output locations and formats during the integration setup.