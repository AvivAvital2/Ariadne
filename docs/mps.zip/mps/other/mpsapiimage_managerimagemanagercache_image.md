---
id: 7c5b8505-4032-52d1-8fe2-04ce6141f4e0
type: catalog
title: "mps.api.image_manager.ImageManager.cache_image"
created_at: 2026-06-06T18:47:28.986723+00:00
updated_at: 2026-07-03T06:16:14.936518+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.cache_image"
  signature: "async def cache_image(self, tag):"
  location: {'line_start': 289, 'line_end': 291, 'col_start': 4, 'col_end': 48}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "3d62f5066bae9c862ba619180b530d212b9d48cc67a6ba279e426bed9070fbdb"
  description: "Asynchronously caches the Docker image identified by the given tag, making it available locally for subsequent operations."
---
# mps.api.image_manager.ImageManager.cache_image

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.cache_image


method mps.api.image_manager.ImageManager.cache_image in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:289-291 :: async def cache_image(self, tag):

Description: Asynchronously caches the Docker image identified by the given tag, making it available locally for subsequent operations.

## Related Documents

- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 1.21)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 1.31)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 1.33)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.40)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 1.57)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 2.51)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 2.72)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 2.74)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.79)
