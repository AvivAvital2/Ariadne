---
id: 296ad955-0893-5bc1-9d28-b03b718b3cb1
type: catalog
title: "mps.api.image_manager.ImageManager.token_manager"
created_at: 2026-06-06T18:47:28.994453+00:00
updated_at: 2026-07-03T06:16:15.007717+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.token_manager"
  signature: "self.token_manager = token_manager"
  location: {'line_start': 21, 'line_end': 21, 'col_start': 8, 'col_end': 42}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "de7e1d45828ba1b190478e3adfb4a974446b997e9a0fbb8b2725d2e73894d64c"
  description: "Stores the token manager instance used by `ImageManager` to handle authentication tokens for API requests."
---
# mps.api.image_manager.ImageManager.token_manager

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.token_manager


variable mps.api.image_manager.ImageManager.token_manager in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:21-21 :: self.token_manager = token_manager

Description: Stores the token manager instance used by `ImageManager` to handle authentication tokens for API requests.

## Related Documents

- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.17)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 1.41)
- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 1.44)
- [mps.service.MPS.self.image_manager](65ebab83-1893-5c2a-a1c6-3d5925f96e41.md) - Related (graph distance 1.45)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 1.46)
- [mps.api.token_manager.TokenManager.provider](f942b514-970b-5d90-b5d1-f5e5777e2718.md) - Related (graph distance 1.51)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 1.58)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 1.64)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 2.58)
- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 2.64)
