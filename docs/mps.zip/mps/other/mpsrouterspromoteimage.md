---
id: 27547b1e-fb43-5004-8a56-9889cfe7c030
type: catalog
title: "mps.routers.promote.image"
created_at: 2026-06-06T18:47:27.628931+00:00
updated_at: 2026-07-03T06:16:15.063223+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.image"
  signature: "image = await mps.image_manager.build_and_push("
  location: {'line_start': 87, 'line_end': 96, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "None"
  sha_at_sync: "b8b13a9b71e66ce533f5f80005511394a4d81fb39a277d36ea5e093d4d5c55c7"
  description: "Builds a container image and pushes it to a registry via the image manager, storing the resulting image reference for use in the promote router."
---
# mps.routers.promote.image

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.image


variable mps.routers.promote.image [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:87-96 :: image = await mps.image_manager.build_and_push(

Description: Builds a container image and pushes it to a registry via the image manager, storing the resulting image reference for use in the promote router.

## Related Documents

- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 1.45)
- [mps.routers.promote.base_image_id](79045cda-50cb-586c-a17c-b364eb27141d.md) - Related (graph distance 1.53)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 1.53)
- [mps.routers.promote.tag](29a0e745-d4bd-5b5f-b2c7-8ce597d7d251.md) - Related (graph distance 1.54)
- [mps.routers.promote.is_image_exists](95980ebe-592a-5957-961c-2493a9af8ecf.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 2.86)
- [mps.api.utils.resolve_base_image_id](ba3105ec-cf00-5064-85f2-207386a7823a.md) - Related (graph distance 2.92)
- [mps.api.image_manager.ImageManager.cached_image](a5ca95c2-654d-5604-a500-9de6a73fb4c6.md) - Related (graph distance 2.94)
- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 3.05)
