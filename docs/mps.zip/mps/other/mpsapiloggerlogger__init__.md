---
id: 7f74628a-3716-5da6-8b24-9e163dd92380
type: catalog
title: "mps.api.logger.Logger.__init__"
created_at: 2026-06-06T18:47:28.690136+00:00
updated_at: 2026-06-20T22:55:25.845025+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.logger.Logger.__init__"
  signature: "def __init__(self, component_name: str, log_level: logging = logging.INFO, log_filename: str = 'log/mps.log',"
  location: {'line_start': 25, 'line_end': 48, 'col_start': 4, 'col_end': 29}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "191646d993ef81b98b32492ce023c3b9ab58cb9d4662d76d295e589b765523cc"
  description: "Initializes a Logger instance for a specified component, configuring the logging level and output to the given log file (defaulting to `log/mps.log` at INFO level)."
---
# mps.api.logger.Logger.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.__init__


method mps.api.logger.Logger.__init__ in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:25-48 :: def __init__(self, component_name: str, log_level: logging = logging.INFO, log_filename: str = 'log/mps.log',

Description: Initializes a Logger instance for a specified component, configuring the logging level and output to the given log file (defaulting to `log/mps.log` at INFO level).