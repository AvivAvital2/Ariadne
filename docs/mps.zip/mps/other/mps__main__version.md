---
id: 95efbc75-177c-50c7-9fe0-e17337dc9cf6
type: catalog
title: "mps.__main__.version"
created_at: 2026-06-06T18:47:26.709398+00:00
updated_at: 2026-06-20T22:55:26.346195+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.__main__.version"
  signature: "version = json.load(f)['version_tag']"
  location: {'line_start': 11, 'line_end': 11, 'col_start': 4, 'col_end': 41}
  parent_qualified_name: "None"
  sha_at_sync: "e4cf1a273f2d7b2523e2c2defe38346e0fd33717193222445c90049d0c00f563"
  description: "Loads the application's version tag from a JSON file into a module-level variable."
---
# mps.__main__.version

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

# mps.__main__.version


variable mps.__main__.version [python] /Users/spark/git/service-model-promotion/mps/__main__.py:11-11 :: version = json.load(f)['version_tag']

Description: Loads the application's version tag from a JSON file into a module-level variable.