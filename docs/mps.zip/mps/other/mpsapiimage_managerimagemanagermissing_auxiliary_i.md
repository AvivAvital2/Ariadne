---
id: beb57c1d-01a2-595a-a013-de7ef5cabe27
type: catalog
title: "mps.api.image_manager.ImageManager.missing_auxiliary_images"
created_at: 2026-06-06T18:47:29.002413+00:00
updated_at: 2026-07-03T06:16:15.053724+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.missing_auxiliary_images"
  signature: "missing_auxiliary_images = ["
  location: {'line_start': 269, 'line_end': 273, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "ccf28ada2c8bebf32d689da231a17849427e704eef2ee14f8447c3b7146d91c6"
  description: "Class-level list attribute on `ImageManager` that holds the names or identifiers of auxiliary images that are expected but not found."
---
# mps.api.image_manager.ImageManager.missing_auxiliary_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.missing_auxiliary_images


variable mps.api.image_manager.ImageManager.missing_auxiliary_images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:269-273 :: missing_auxiliary_images = [

Description: Class-level list attribute on `ImageManager` that holds the names or identifiers of auxiliary images that are expected but not found.

## Related Documents

- [mps.api.image_manager.ImageManager.aux_images](3ec0e871-543e-5a41-933e-e1aa7b51c8c9.md) - Related (graph distance 1.47)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 1.60)
- [mps.routers.promote.auxiliary_image_list](e555d1cb-61ea-523a-8284-a3b7183d411a.md) - Related (graph distance 1.61)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 2.92)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 3.00)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 3.00)
- [mps.routers.promote.auxiliary_image_string](d5288d92-39d5-5b40-993d-21eea4d39f9a.md) - Related (graph distance 3.05)
- [mps.api.image_manager.ImageManager.images](55615e34-e793-58a6-856c-246019e7536b.md) - Related (graph distance 3.08)
- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 3.13)
