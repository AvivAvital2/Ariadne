---
id: f976f9bc-5eb9-5d4d-b394-48d2d3813036
type: catalog
title: "mps.api.config.filename"
created_at: 2026-06-06T18:47:27.700430+00:00
updated_at: 2026-07-03T06:16:15.031226+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.filename"
  signature: "filename = os.path.basename(file_path)"
  location: {'line_start': 14, 'line_end': 14, 'col_start': 4, 'col_end': 42}
  parent_qualified_name: "None"
  sha_at_sync: "ec6af59076467a9e8ab1382b66b57b446703127cbedd1315e4fc69bfcba4c84a"
  description: "Extracts the base filename (without directory path) from the full file path stored in `file_path`."
---
# mps.api.config.filename

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.filename


variable mps.api.config.filename [python] /Users/spark/git/service-model-promotion/mps/api/config.py:14-14 :: filename = os.path.basename(file_path)

Description: Extracts the base filename (without directory path) from the full file path stored in `file_path`.

## Related Documents

- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 1.47)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 2.94)
