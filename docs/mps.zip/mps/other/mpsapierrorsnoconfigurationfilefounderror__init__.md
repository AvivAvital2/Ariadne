---
id: 305e165d-5ef3-5ff8-8431-7458a26c7ffc
type: catalog
title: "mps.api.errors.NoConfigurationFileFoundError.__init__"
created_at: 2026-06-06T18:47:29.759168+00:00
updated_at: 2026-07-03T06:16:15.118075+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.NoConfigurationFileFoundError.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 31, 'line_end': 32, 'col_start': 4, 'col_end': 68}
  parent_qualified_name: "mps.api.errors.NoConfigurationFileFoundError"
  sha_at_sync: "7828343458dad9b112be681b3fbb590b70f2a53f3c5b93c451e617b1f75695f3"
  description: "Initializes the `NoConfigurationFileFoundError` exception with a descriptive error message."
---
# mps.api.errors.NoConfigurationFileFoundError.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.NoConfigurationFileFoundError.__init__


method mps.api.errors.NoConfigurationFileFoundError.__init__ in mps.api.errors.NoConfigurationFileFoundError [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:31-32 :: def __init__(self, message: str):

Description: Initializes the `NoConfigurationFileFoundError` exception with a descriptive error message.

## Related Documents

- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 1.05)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.13)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.21)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.24)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.32)
- [mps.api.errors.NoConfigurationFileFoundError](77bf0aae-c975-569a-9484-fd8c4d9e53ca.md) - Related (graph distance 1.49)
- [mps.api.errors.NoConfigurationFoundError](2d8d2de0-7d99-5f1d-8e8d-9d4470f9713b.md) - Related (graph distance 1.54)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.35)
- [mps.api.errors.InvalidAWSRegion.__init__](3400f057-5645-59b4-b20b-7095169ec205.md) - Related (graph distance 2.37)
- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 2.42)
