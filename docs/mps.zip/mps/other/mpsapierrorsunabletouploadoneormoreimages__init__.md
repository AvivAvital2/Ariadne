---
id: f01cfb5d-a741-5696-a0af-4913f518cb12
type: catalog
title: "mps.api.errors.UnableToUploadOneOrMoreImages.__init__"
created_at: 2026-06-06T18:47:29.760454+00:00
updated_at: 2026-07-03T06:16:14.970454+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnableToUploadOneOrMoreImages.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 59, 'line_end': 60, 'col_start': 4, 'col_end': 68}
  parent_qualified_name: "mps.api.errors.UnableToUploadOneOrMoreImages"
  sha_at_sync: "3eba7244377fe547654109395469a67b4e819495c84db2d86f609bf567fa740f"
  description: "Initializes the `UnableToUploadOneOrMoreImages` exception with a provided error message string."
---
# mps.api.errors.UnableToUploadOneOrMoreImages.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToUploadOneOrMoreImages.__init__


method mps.api.errors.UnableToUploadOneOrMoreImages.__init__ in mps.api.errors.UnableToUploadOneOrMoreImages [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:59-60 :: def __init__(self, message: str):

Description: Initializes the `UnableToUploadOneOrMoreImages` exception with a provided error message string.

## Related Documents

- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.18)
- [mps.api.errors.UnavailableImage.__init__](7294acfc-63e5-53e1-aa50-42065ebe3449.md) - Related (graph distance 1.21)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.24)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 1.29)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 1.30)
- [mps.api.errors.UnableToUploadOneOrMoreImages](73549085-686e-5207-a376-8c21c11d75c1.md) - Related (graph distance 1.49)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 2.32)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.41)
- [mps.api.errors.NoConfigurationFileFoundError.__init__](305e165d-5ef3-5ff8-8431-7458a26c7ffc.md) - Related (graph distance 2.42)
- [mps.api.errors.NoConfigurationFoundError.__init__](dad3db90-4ede-5b19-ba30-1598e73b079e.md) - Related (graph distance 2.45)
