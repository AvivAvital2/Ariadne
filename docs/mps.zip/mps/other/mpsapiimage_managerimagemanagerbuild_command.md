---
id: a5945017-a664-5430-9dd0-bbfea34ea71e
type: catalog
title: "mps.api.image_manager.ImageManager.build_command"
created_at: 2026-06-06T18:47:28.997345+00:00
updated_at: 2026-07-03T06:16:14.973027+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.build_command"
  signature: "build_command = ("
  location: {'line_start': 65, 'line_end': 72, 'col_start': 12, 'col_end': 13}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "9a154dbef1cc97e3608c2ed648cf686849db78c34d39cf4ce590c308d68e9e86"
  description: "Constructs the command-line argument list used to build a container image, assembling options such as build context, tags, and other parameters into a list suitable for execution."
---
# mps.api.image_manager.ImageManager.build_command

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.build_command


variable mps.api.image_manager.ImageManager.build_command in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:65-72 :: build_command = (

Description: Constructs the command-line argument list used to build a container image, assembling options such as build context, tags, and other parameters into a list suitable for execution.

## Related Documents

- [mps.api.image_manager.ImageManager.push_command](2b87cf05-a881-5c6d-bf6e-dd63c664e2b8.md) - Related (graph distance 1.48)
- [mps.api.image_manager.ImageManager.inspect_command](08bf5b72-903c-54df-b4b0-ade249fc6655.md) - Related (graph distance 1.59)
