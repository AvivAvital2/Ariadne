---
id: 99e4f257-b792-58b1-a023-c7b18602a57e
type: catalog
title: "mps.api.utils.flavours"
created_at: 2026-06-06T18:47:29.302111+00:00
updated_at: 2026-07-03T06:16:14.933250+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.flavours"
  signature: "flavours = {"
  location: {'line_start': 91, 'line_end': 96, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "None"
  sha_at_sync: "7de90fb3e5810d01b6c0c5a998d3bad387068609cd3c82b1b46c052d7f9bf2ad"
  description: "A module-level dictionary mapping flavour identifiers to their corresponding configuration values for use in the MPS API utilities."
---
# mps.api.utils.flavours

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.flavours


variable mps.api.utils.flavours [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:91-96 :: flavours = {

Description: A module-level dictionary mapping flavour identifiers to their corresponding configuration values for use in the MPS API utilities.

## Related Documents

- [mps.api.utils.flavour](d3152f57-40bf-54d0-a0a7-17073bed3cc6.md) - Related (graph distance 1.44)
- [mps.api.schemas.Flavours](e6376e7d-3534-5633-9f84-2187d56f743e.md) - Related (graph distance 1.45)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 2.91)
- [mps.api.schemas.Flavours.gdata](421f70f2-749b-57fb-802a-4988a0b15516.md) - Related (graph distance 3.05)
- [mps.api.schemas.Flavours.minimal](6f98a8fb-a158-538b-b12d-a9eacc2370cb.md) - Related (graph distance 3.07)
- [mps.api.schemas.Flavours.osm](158f2dda-ad59-551f-8cb0-3fd7f47d9750.md) - Related (graph distance 3.10)
