---
id: c0d27ec0-9539-58a7-9834-d5d9c9cf44c0
type: catalog
title: "mps.api.config.defaults"
created_at: 2026-06-06T18:47:27.700755+00:00
updated_at: 2026-06-20T22:55:25.771830+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.defaults"
  signature: "defaults = json.load(defaults_fh)"
  location: {'line_start': 28, 'line_end': 28, 'col_start': 4, 'col_end': 37}
  parent_qualified_name: "None"
  sha_at_sync: "999bf807038a0e83168c72e5c3ffb0fdc926282c9da732365b56b6b67cc02ca9"
  description: "Loads default configuration settings from a JSON file into a dictionary for use as fallback values in the API configuration."
---
# mps.api.config.defaults

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.defaults


variable mps.api.config.defaults [python] /Users/spark/git/service-model-promotion/mps/api/config.py:28-28 :: defaults = json.load(defaults_fh)

Description: Loads default configuration settings from a JSON file into a dictionary for use as fallback values in the API configuration.