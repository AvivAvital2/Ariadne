---
id: 80529829-b9dc-5fad-9c49-2cfc13543f8e
type: catalog
title: "mps.api.config.repo_prefix"
created_at: 2026-06-06T18:47:27.702355+00:00
updated_at: 2026-06-20T22:55:22.008926+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.repo_prefix"
  signature: "repo_prefix = config['general']['repo_prefix']"
  location: {'line_start': 40, 'line_end': 40, 'col_start': 0, 'col_end': 46}
  parent_qualified_name: "None"
  sha_at_sync: "46ca81a83638d0db4d84fb1e13cca17c13cf6892231b964d09849332a9c46d98"
  description: "Retrieves the repository prefix string from the `general` section of the loaded configuration, used as a base path or identifier prefix for repositories."
---
# mps.api.config.repo_prefix

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.repo_prefix


variable mps.api.config.repo_prefix [python] /Users/spark/git/service-model-promotion/mps/api/config.py:40-40 :: repo_prefix = config['general']['repo_prefix']

Description: Retrieves the repository prefix string from the `general` section of the loaded configuration, used as a base path or identifier prefix for repositories.