---
id: 7bb669fd-e1bc-5340-9254-1a1dfb2de7ce
type: catalog
title: "mps.api.config.file_paths"
created_at: 2026-06-06T18:47:27.699660+00:00
updated_at: 2026-07-03T06:16:15.099256+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.file_paths"
  signature: "file_paths = ["
  location: {'line_start': 7, 'line_end': 10, 'col_start': 0, 'col_end': 1}
  parent_qualified_name: "None"
  sha_at_sync: "670df8fd3c31a9bca9a3caf5fbb5a666582396db2cf0c50284437ea15e850aa6"
  description: "Defines a list of filesystem paths used by the MPS API configuration module to locate or reference configuration files."
---
# mps.api.config.file_paths

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.file_paths


variable mps.api.config.file_paths [python] /Users/spark/git/service-model-promotion/mps/api/config.py:7-10 :: file_paths = [

Description: Defines a list of filesystem paths used by the MPS API configuration module to locate or reference configuration files.

## Related Documents

- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 1.63)
- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 3.10)
- [mps.api.config.filename](f976f9bc-5eb9-5d4d-b394-48d2d3813036.md) - Related (graph distance 3.10)
- [mps.api.config.exported_image_path](a5afb6f3-473f-5cc0-b8b4-6f8915df6df5.md) - Related (graph distance 3.18)
