---
id: e5f7a08a-b659-5159-967e-b31b209f292b
type: catalog
title: "mps.api.errors.InvalidRegistryProvider"
created_at: 2026-06-06T18:47:29.763533+00:00
updated_at: 2026-07-03T06:16:15.019669+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.InvalidRegistryProvider"
  signature: "class InvalidRegistryProvider(ExceptionHandler):"
  location: {'line_start': 45, 'line_end': 48, 'col_start': 0, 'col_end': 62}
  parent_qualified_name: "None"
  sha_at_sync: "0cbd573a32874fa284099cc268066dfbdbe240bb9b36eaea24a6bd06598d4ed2"
  description: "Exception handler for cases where an invalid or unsupported registry provider is specified, extending the base ExceptionHandler class."
---
# mps.api.errors.InvalidRegistryProvider

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.InvalidRegistryProvider


class mps.api.errors.InvalidRegistryProvider [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:45-48 :: class InvalidRegistryProvider(ExceptionHandler):

Description: Exception handler for cases where an invalid or unsupported registry provider is specified, extending the base ExceptionHandler class.

## Related Documents

- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 1.42)
- [mps.api.errors.UnreachableContainerRegistry](e704846b-d46b-5b8d-b5bb-72d52b00553b.md) - Related (graph distance 1.43)
- [mps.api.errors.InvalidConfigurationFile](6a5a4d99-23ed-5520-9920-f21a72164625.md) - Related (graph distance 1.49)
- [mps.api.errors.InvalidAWSRegion](6e2aa7f3-0fba-55c0-bc08-ac7f3a5fadde.md) - Related (graph distance 1.52)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry](3bba5028-d5bd-52af-ac03-78e6399101b6.md) - Related (graph distance 1.54)
- [mps.api.errors.ExceptionHandler](cf4dd7f9-1a77-532c-ba34-3c1194c6363c.md) - Related (graph distance 1.56)
- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.60)
- [mps.api.errors.MissingConfigValues](04edf404-d21e-5354-b2ae-458a08e7e3f2.md) - Related (graph distance 1.63)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.64)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 2.64)
