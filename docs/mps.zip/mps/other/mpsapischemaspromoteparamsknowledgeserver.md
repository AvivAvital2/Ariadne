---
id: 35857b92-0a17-5cf7-ae27-4ac04e4c9842
type: catalog
title: "mps.api.schemas.PromoteParams.knowledgeServer"
created_at: 2026-06-06T18:47:28.915801+00:00
updated_at: 2026-06-20T22:55:23.858452+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.PromoteParams.knowledgeServer"
  signature: "knowledgeServer: bool = False"
  location: {'line_start': 28, 'line_end': 28, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "mps.api.schemas.PromoteParams"
  sha_at_sync: "f9b828c8faa192007bc149c961c4df4fb3261e39c902ead64e6085a2c85f69f4"
  description: "Boolean flag in the PromoteParams schema that indicates whether the promotion should target a knowledge server, defaulting to False."
---
# mps.api.schemas.PromoteParams.knowledgeServer

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.PromoteParams.knowledgeServer


variable mps.api.schemas.PromoteParams.knowledgeServer in mps.api.schemas.PromoteParams [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:28-28 :: knowledgeServer: bool = False

Description: Boolean flag in the PromoteParams schema that indicates whether the promotion should target a knowledge server, defaulting to False.