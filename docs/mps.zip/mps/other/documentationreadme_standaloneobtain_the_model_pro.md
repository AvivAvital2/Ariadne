---
id: 1cf2f1b6-8cc4-555f-9e3d-8cc1a68322f7
type: catalog
title: "documentation.README_standalone.obtain_the_model_promotion_service_docker_artifacts"
created_at: 2026-06-06T18:47:26.284615+00:00
updated_at: 2026-06-20T22:55:23.927016+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.obtain_the_model_promotion_service_docker_artifacts"
  signature: "#### Obtain the Model Promotion Service Docker artifacts"
  location: {'line_start': 90, 'line_end': 111, 'col_start': 0, 'col_end': 56}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "e9dbdb9ec29d6c218e93d0dca6c3e6e6951b89c01862e27be89c4a2a892537f4"
  description: "Provides instructions for downloading or building the Model Promotion Service Docker image artifacts needed for a standalone deployment."
---
# documentation.README_standalone.obtain_the_model_promotion_service_docker_artifacts

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.obtain_the_model_promotion_service_docker_artifacts


md_section documentation.README_standalone.obtain_the_model_promotion_service_docker_artifacts in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:90-111 :: #### Obtain the Model Promotion Service Docker artifacts

Description: Provides instructions for downloading or building the Model Promotion Service Docker image artifacts needed for a standalone deployment.