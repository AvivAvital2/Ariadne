---
id: 6e667dc6-8ea0-56f7-a2d0-c2398f428109
type: catalog
title: "mps.api.errors.ExceptionHandler.sys.excepthook"
created_at: 2026-06-06T18:47:29.772329+00:00
updated_at: 2026-07-03T06:16:14.972638+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.errors.ExceptionHandler.sys.excepthook"
  signature: "sys.excepthook = self.exception_handler"
  location: {'line_start': 13, 'line_end': 13, 'col_start': 8, 'col_end': 47}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "78f63f7839a90b7ede10a86cbdf7c621af7043b61f726123b7f341e20a0a6fe0"
  description: "Assigns the instance's `exception_handler` method to `sys.excepthook`, overriding Python's default behavior for handling uncaught exceptions so they are processed by the custom handler."
---
# mps.api.errors.ExceptionHandler.sys.excepthook

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.sys.excepthook


variable mps.api.errors.ExceptionHandler.sys.excepthook in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:13-13 :: sys.excepthook = self.exception_handler

Description: Assigns the instance's `exception_handler` method to `sys.excepthook`, overriding Python's default behavior for handling uncaught exceptions so they are processed by the custom handler.

## Related Documents

- [mps.api.errors.ExceptionHandler.exception_handler](3529722b-ea7e-531f-badf-5c1480baf8aa.md) - Related (graph distance 1.60)
- [mps.api.errors.ExceptionHandler.__str__](98eb7392-e75e-559e-9e37-cba956652a02.md) - Related (graph distance 3.09)
- [mps.api.errors.ExceptionHandler.__repr__](354a3d34-fb7e-59f5-9c8c-7dab844609a6.md) - Related (graph distance 3.16)
