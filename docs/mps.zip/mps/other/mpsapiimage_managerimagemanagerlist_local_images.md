---
id: ee95e749-afbc-5cd0-83ea-b348fb8e1e44
type: catalog
title: "mps.api.image_manager.ImageManager.list_local_images"
created_at: 2026-06-06T18:47:28.984810+00:00
updated_at: 2026-07-03T06:16:15.123596+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.list_local_images"
  signature: "async def list_local_images(self):"
  location: {'line_start': 153, 'line_end': 172, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "eca50355a0dfb16df87b6cf43f001e92fb01e8d32e76014a194b3a41ed91e004"
  description: "Asynchronously retrieves and returns the collection of images stored locally by the ImageManager."
---
# mps.api.image_manager.ImageManager.list_local_images

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.list_local_images


method mps.api.image_manager.ImageManager.list_local_images in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:153-172 :: async def list_local_images(self):

Description: Asynchronously retrieves and returns the collection of images stored locally by the ImageManager.

## Related Documents

- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 1.33)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 1.36)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 1.38)
- [mps.routers.maintenance.remote_images](9cd933a2-32f1-5a4d-87ee-cd05d12fa057.md) - Related (graph distance 1.40)
- [mps.routers.maintenance.list_images](dba494fa-4ba4-5080-8dd6-afee381e737c.md) - Related (graph distance 1.41)
- [mps.api.image_manager.ImageManager.get_exported_image_list](70dae0c7-4d5f-5c6a-98bb-1b86d0bb851a.md) - Related (graph distance 1.45)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.get_size_of_images](d33e623d-e2ff-5e78-b40c-db99afab80ae.md) - Related (graph distance 1.57)
- [mps.routers.maintenance.delete_local_images](e7bd0b0a-6635-59aa-b7ab-72f4c2ab7f1b.md) - Related (graph distance 1.60)
- [mps.routers.maintenance.get_total_images_size](739fc960-32ce-543a-8f9a-9878beba79af.md) - Related (graph distance 2.74)
