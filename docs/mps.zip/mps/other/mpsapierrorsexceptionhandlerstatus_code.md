---
id: 88dd3367-9cf9-5083-b43e-f70b775a7562
type: catalog
title: "mps.api.errors.ExceptionHandler.status_code"
created_at: 2026-06-06T18:47:29.772067+00:00
updated_at: 2026-07-03T06:16:15.012734+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.errors.ExceptionHandler.status_code"
  signature: "self.status_code = status_code"
  location: {'line_start': 10, 'line_end': 10, 'col_start': 8, 'col_end': 38}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "fa0409c06d7febc1c599fac8b122e75ccc365f754dd3cea752a4998fce1a6bda"
  description: "Stores the HTTP status code associated with the exception, assigned from the constructor parameter during `ExceptionHandler` initialization."
---
# mps.api.errors.ExceptionHandler.status_code

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.status_code


variable mps.api.errors.ExceptionHandler.status_code in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:10-10 :: self.status_code = status_code

Description: Stores the HTTP status code associated with the exception, assigned from the constructor parameter during `ExceptionHandler` initialization.

## Related Documents

- [mps.api.errors.ExceptionHandler.__init__](217d2c38-8594-57a8-b81f-9b6355041445.md) - Related (graph distance 1.52)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 2.80)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 2.93)
