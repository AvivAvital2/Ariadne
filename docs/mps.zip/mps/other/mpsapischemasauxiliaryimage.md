---
id: 5d97c692-d4d3-5c60-80f4-4073e2fabfc7
type: catalog
title: "mps.api.schemas.AuxiliaryImage"
created_at: 2026-06-06T18:47:28.911770+00:00
updated_at: 2026-07-03T06:16:15.112060+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.schemas.AuxiliaryImage"
  signature: "class AuxiliaryImage:"
  location: {'line_start': 33, 'line_end': 35, 'col_start': 0, 'col_end': 23}
  parent_qualified_name: "None"
  sha_at_sync: "19e2edf76fa20a3e70ee832a73fa11390d862d5f54b297eb15983772f1293297"
  description: "Represents an auxiliary image associated with a primary resource, encapsulating its metadata or reference information."
---
# mps.api.schemas.AuxiliaryImage

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImage


class mps.api.schemas.AuxiliaryImage [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:33-35 :: class AuxiliaryImage:

Description: Represents an auxiliary image associated with a primary resource, encapsulating its metadata or reference information.

## Related Documents

- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 1.18)
- [mps.api.schemas.AuxiliaryImage.image](93dd0f21-fe6e-5935-bfa0-e20abb156acc.md) - Related (graph distance 1.33)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 1.40)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 1.47)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.57)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 1.58)
- [mps.api.schemas.AuxiliaryImages.__post_init__](895ec509-465c-5ea4-a061-7ff673eb9d85.md) - Related (graph distance 1.67)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 2.74)
- [mps.api.schemas.PromoteParams](9ea275a3-490e-5840-8aee-0dbaa9afddef.md) - Related (graph distance 2.81)
- [mps.api.schemas.AuxiliaryImage.tag](4c441d3f-7079-518b-9f4c-a8cde1baa7a9.md) - Related (graph distance 2.92)
