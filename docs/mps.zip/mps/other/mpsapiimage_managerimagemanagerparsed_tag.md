---
id: 68aae686-09d8-50b3-aa7e-da02513cdae2
type: catalog
title: "mps.api.image_manager.ImageManager.parsed_tag"
created_at: 2026-06-06T18:47:28.999193+00:00
updated_at: 2026-07-03T06:16:14.996289+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.parsed_tag"
  signature: "parsed_tag = urlparse('//' + tag)"
  location: {'line_start': 139, 'line_end': 139, 'col_start': 12, 'col_end': 45}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "fc8bde5667f973d2aee1588c8c91c2a1a2c06dde2a5d96e011570ec5ca0618b1"
  description: "Parses the image tag string (prefixed with `//`) into a URL components object, enabling extraction of host, path, and other registry reference parts."
---
# mps.api.image_manager.ImageManager.parsed_tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.parsed_tag


variable mps.api.image_manager.ImageManager.parsed_tag in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:139-139 :: parsed_tag = urlparse('//' + tag)

Description: Parses the image tag string (prefixed with `//`) into a URL components object, enabling extraction of host, path, and other registry reference parts.

## Related Documents

- [mps.api.image_manager.ImageManager.repository_and_tag](f8a23958-62d7-5fb0-a1d2-1c99bd4089d6.md) - Related (graph distance 1.33)
- [mps.api.utils._, _, image_tag](de1a3c46-4968-53e2-8bb3-c409205df414.md) - Related (graph distance 1.47)
- [mps.api.image_manager.ImageManager.tag](157b0e71-4b3f-5cba-9f9d-e6067dd488b8.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.repository_name, _, _](981f05af-6aa4-5d43-b007-43e8db1ef287.md) - Related (graph distance 2.69)
- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 2.82)
- [mps.api.utils.docker_image_to_file_name](73847514-b1fb-5627-8728-c3c254d4f051.md) - Related (graph distance 3.24)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 3.25)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 3.31)
