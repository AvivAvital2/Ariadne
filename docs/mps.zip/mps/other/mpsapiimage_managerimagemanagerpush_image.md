---
id: 20733469-cfa8-5f10-82dd-763f83500ffd
type: catalog
title: "mps.api.image_manager.ImageManager.push_image"
created_at: 2026-06-06T18:47:28.984547+00:00
updated_at: 2026-07-03T06:16:15.020435+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_manager.ImageManager.push_image"
  signature: "async def push_image(self, tag):"
  location: {'line_start': 107, 'line_end': 151, 'col_start': 4, 'col_end': 24}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "95d3d5e8fb73cf953e09c9b057aabdd6b6f7f8a0db950200663cd72c6f071f0b"
  description: "Asynchronously pushes a Docker image identified by the given tag to its registry, streaming and processing the push progress output. Returns the result of the push operation, raising an error if the push fails."
---
# mps.api.image_manager.ImageManager.push_image

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.push_image


method mps.api.image_manager.ImageManager.push_image in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:107-151 :: async def push_image(self, tag):

Description: Asynchronously pushes a Docker image identified by the given tag to its registry, streaming and processing the push progress output. Returns the result of the push operation, raising an error if the push fails.

## Related Documents

- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 1.31)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 1.41)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 1.52)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 1.53)
- [mps.api.image_manager.ImageManager.check_if_image_exists_on_remote_registry](f070493f-6d63-52eb-8ab6-5f7cb7150776.md) - Related (graph distance 1.54)
- [mps.api.image_manager.ImageManager.push_results](b86d8e6e-ca91-51dd-beef-b69e972bde6d.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager.upload_missing_auxiliary_images](0c79826e-d46d-5707-8567-4a2cacd5b52f.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.check_if_image_tag_exists_in_cache](5accd4da-3b6f-5d73-8be2-ed6c4f5ce3a9.md) - Related (graph distance 2.64)
- [mps.api.image_manager.ImageManager.check_if_image_archive_exists_on_local_storage](9ca8f2c3-f656-5def-b0db-c4b19e8c4132.md) - Related (graph distance 2.74)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 2.86)
