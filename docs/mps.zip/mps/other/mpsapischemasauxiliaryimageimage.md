---
id: 93dd0f21-fe6e-5935-bfa0-e20abb156acc
type: catalog
title: "mps.api.schemas.AuxiliaryImage.image"
created_at: 2026-06-06T18:47:28.916399+00:00
updated_at: 2026-07-03T06:16:14.934060+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.AuxiliaryImage.image"
  signature: "image: str"
  location: {'line_start': 34, 'line_end': 34, 'col_start': 4, 'col_end': 14}
  parent_qualified_name: "mps.api.schemas.AuxiliaryImage"
  sha_at_sync: "cb6e11b89e6d4feb6c5c21d166da90c0bf94b77af1bca8c1fb39d569c096fa9f"
  description: "Defines a required string field on the `AuxiliaryImage` schema that holds the auxiliary image's reference or path."
---
# mps.api.schemas.AuxiliaryImage.image

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImage.image


variable mps.api.schemas.AuxiliaryImage.image in mps.api.schemas.AuxiliaryImage [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:34-34 :: image: str

Description: Defines a required string field on the `AuxiliaryImage` schema that holds the auxiliary image's reference or path.

## Related Documents

- [mps.api.schemas.AuxiliaryImage](5d97c692-d4d3-5c60-80f4-4073e2fabfc7.md) - Related (graph distance 1.33)
- [mps.api.schemas.AuxiliaryImages.images_str](7147aed6-0420-5c1a-b24f-e305d5a9b96f.md) - Related (graph distance 1.36)
- [mps.api.schemas.AuxiliaryImage.tag](4c441d3f-7079-518b-9f4c-a8cde1baa7a9.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 1.59)
- [mps.api.schemas.AuxiliaryImages.self.images](a972b94b-def2-52ce-9596-3e368fa6b932.md) - Related (graph distance 1.59)
- [mps.api.schemas.AuxiliaryImages](5208d1b8-2c19-516d-b565-31fcccb1095b.md) - Related (graph distance 2.51)
- [mps.api.schemas.ImageParams](2757307d-26f0-5c87-8566-199b9f2ee899.md) - Related (graph distance 2.73)
- [mps.api.schemas.BaseImages](49d4a102-f737-56a4-ae40-4e96c274145f.md) - Related (graph distance 2.80)
- [mps.api.schemas.BaseImages.images](aeecab73-698c-51fc-9e93-ae299736af7b.md) - Related (graph distance 2.85)
- [mps.api.schemas.AuxiliaryImages.__post_init__](895ec509-465c-5ea4-a061-7ff673eb9d85.md) - Related (graph distance 3.00)
