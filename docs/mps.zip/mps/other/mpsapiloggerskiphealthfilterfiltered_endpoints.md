---
id: 1960c946-fc9c-54cd-bf74-cc536adc42cc
type: catalog
title: "mps.api.logger.SkipHealthFilter.filtered_endpoints"
created_at: 2026-06-06T18:47:28.692107+00:00
updated_at: 2026-07-03T06:16:15.091133+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.SkipHealthFilter.filtered_endpoints"
  signature: "filtered_endpoints = ["
  location: {'line_start': 16, 'line_end': 20, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.logger.SkipHealthFilter"
  sha_at_sync: "f262dff48305272d771dfd9cdd13e6851bd7e4d5a4233f53e0ed7c686d8d3faf"
  description: "A list of endpoint paths (such as health check routes) whose log records should be excluded by the `SkipHealthFilter`."
---
# mps.api.logger.SkipHealthFilter.filtered_endpoints

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.SkipHealthFilter.filtered_endpoints


variable mps.api.logger.SkipHealthFilter.filtered_endpoints in mps.api.logger.SkipHealthFilter [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:16-20 :: filtered_endpoints = [

Description: A list of endpoint paths (such as health check routes) whose log records should be excluded by the `SkipHealthFilter`.

## Related Documents

- [mps.api.logger.SkipHealthFilter](ace7d034-38b2-5493-9c7d-9cd6df5da6fa.md) - Related (graph distance 1.62)
- [mps.api.logger.SkipHealthFilter.filter](fe3155c9-4fa0-5a72-87d8-429ba1343760.md) - Related (graph distance 3.12)
