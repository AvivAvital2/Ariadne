---
id: 7518500a-6dbd-5b7e-95aa-c43b5664b35f
type: catalog
title: "mps.api.image_manager.ImageManager.repositories"
created_at: 2026-06-06T18:47:29.004591+00:00
updated_at: 2026-07-03T06:16:15.026111+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.repositories"
  signature: "repositories = response.get('repositories', None)"
  location: {'line_start': 342, 'line_end': 342, 'col_start': 8, 'col_end': 57}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6283ace6a53872f8ec8737bde06a4117bd8df0661ff1b1dfee5adbf4429b7bce"
  description: "Extracts the list of repositories from the API response, defaulting to `None` if the `repositories` key is absent."
---
# mps.api.image_manager.ImageManager.repositories

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.repositories


variable mps.api.image_manager.ImageManager.repositories in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:342-342 :: repositories = response.get('repositories', None)

Description: Extracts the list of repositories from the API response, defaulting to `None` if the `repositories` key is absent.

## Related Documents

- [mps.api.image_manager.ImageManager.response](72b74dcf-45b1-511b-938a-0d645ae30140.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager.repositories_in_prefix](9001d943-860c-5925-9118-8eb1a74d536f.md) - Related (graph distance 1.65)
- [mps.api.token_manager.AWSTokenManager.response](67c5381a-ccc2-5500-a502-f007567820c3.md) - Related (graph distance 2.85)
