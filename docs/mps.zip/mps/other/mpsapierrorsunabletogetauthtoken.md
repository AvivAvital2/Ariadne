---
id: 2fa0fbad-f9c8-5e61-b90e-48175bf78545
type: catalog
title: "mps.api.errors.UnableToGetAuthToken"
created_at: 2026-06-06T18:47:29.763286+00:00
updated_at: 2026-07-03T06:16:14.980923+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.errors.UnableToGetAuthToken"
  signature: "class UnableToGetAuthToken(ExceptionHandler):"
  location: {'line_start': 39, 'line_end': 42, 'col_start': 0, 'col_end': 72}
  parent_qualified_name: "None"
  sha_at_sync: "1d0de60e57352a3733c2e0888240af75a12e1a4a02ff8c18ace662ef10e99ba9"
  description: "An exception handler class that handles failures occurring when an authentication token cannot be retrieved."
---
# mps.api.errors.UnableToGetAuthToken

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnableToGetAuthToken


class mps.api.errors.UnableToGetAuthToken [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:39-42 :: class UnableToGetAuthToken(ExceptionHandler):

Description: An exception handler class that handles failures occurring when an authentication token cannot be retrieved.

## Related Documents

- [mps.api.errors.UnableToStoreCredentialsFile](dd706baa-9f4e-5d89-ab0c-97163e21942b.md) - Related (graph distance 1.45)
- [mps.api.errors.SelfSignedCertificate](d4ae9ba0-5586-594e-bbc1-51cb216e3ed7.md) - Related (graph distance 1.54)
- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 1.59)
