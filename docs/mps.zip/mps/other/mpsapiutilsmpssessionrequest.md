---
id: dd61517b-4a21-5082-b666-793f8f9318f4
type: catalog
title: "mps.api.utils.MPSSession.request"
created_at: 2026-06-06T18:47:29.296221+00:00
updated_at: 2026-06-20T22:55:26.659893+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.utils.MPSSession.request"
  signature: "def request(self, method, uri, *args, **kwargs):"
  location: {'line_start': 21, 'line_end': 23, 'col_start': 4, 'col_end': 84}
  parent_qualified_name: "mps.api.utils.MPSSession"
  sha_at_sync: "11bcc8082f2f98bb537d44b2937da7b547269f35791f7de905aef0c86e2790ab"
  description: "Overrides the parent session's request method to prepend a base URI to the given relative URI before delegating the HTTP request to the superclass."
---
# mps.api.utils.MPSSession.request

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession.request


method mps.api.utils.MPSSession.request in mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:21-23 :: def request(self, method, uri, *args, **kwargs):

Description: Overrides the parent session's request method to prepend a base URI to the given relative URI before delegating the HTTP request to the superclass.