---
id: 3b7e98d7-bfd2-5dcc-a8af-1078b647c414
type: catalog
title: "mps.api.logger.Logger._logger"
created_at: 2026-06-06T18:47:28.693966+00:00
updated_at: 2026-07-03T06:16:15.004054+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger._logger"
  signature: "self.logger = _logger"
  location: {'line_start': 48, 'line_end': 48, 'col_start': 8, 'col_end': 29}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "d56ac652b793c09484a4133852ca491bdc6673f3c529f4cad5dde6d1247f6a59"
  description: "Stores a reference to the underlying logger instance used by the `Logger` class to perform actual logging operations."
---
# mps.api.logger.Logger._logger

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger._logger


variable mps.api.logger.Logger._logger in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:48-48 :: self.logger = _logger

Description: Stores a reference to the underlying logger instance used by the `Logger` class to perform actual logging operations.

## Related Documents

- [mps.api.errors.ExceptionHandler.self.Logger](e44a3143-66f2-530f-b85e-34ddd1b4545f.md) - Related (graph distance 1.43)
- [mps.api.logger.logger](903b3696-6e75-5071-9f19-6d10a5038da1.md) - Related (graph distance 1.64)
- [mps.api.logger.Logger](b3389511-3834-54f5-836a-78c4848305dc.md) - Related (graph distance 2.96)
