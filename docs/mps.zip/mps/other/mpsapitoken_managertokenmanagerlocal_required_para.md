---
id: dffe687c-24ed-5438-b503-8c3cb23c7d49
type: catalog
title: "mps.api.token_manager.TokenManager.local_required_params"
created_at: 2026-06-06T18:47:28.318495+00:00
updated_at: 2026-07-03T06:16:15.006923+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.local_required_params"
  signature: "local_required_params = dict("
  location: {'line_start': 31, 'line_end': 44, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "f68ce73ba13b0659f73825c9db221ac2ad174a88dddb09da9db27748ffdf0f63"
  description: "A class attribute dictionary defining the required parameters for local token management operations in the `TokenManager` class."
---
# mps.api.token_manager.TokenManager.local_required_params

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.local_required_params


variable mps.api.token_manager.TokenManager.local_required_params in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:31-44 :: local_required_params = dict(

Description: A class attribute dictionary defining the required parameters for local token management operations in the `TokenManager` class.

## Related Documents

- [mps.api.token_manager.TokenManager.required_params](4e2c0707-3cf9-53e1-b037-3cd4ed330632.md) - Related (graph distance 1.24)
- [mps.api.token_manager.TokenManager.authenticated_required_params](88c5775b-0216-5169-9c74-d8ecc1b451c7.md) - Related (graph distance 1.37)
- [mps.api.token_manager.TokenManager.none_values](5e618a5f-3950-5107-a4eb-b8aea0b6f361.md) - Related (graph distance 1.57)
