---
id: fa86c227-9c12-5c75-a2c5-e7ad7ea7d477
type: catalog
title: ".ci.agent-release.apiVersion"
created_at: 2026-06-06T18:47:26.936390+00:00
updated_at: 2026-06-20T22:55:26.669311+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent-release.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent-release.apiVersion"
  signature: "apiVersion: v1"
  location: {'line_start': 1, 'line_end': 1, 'col_start': 0, 'col_end': 14}
  parent_qualified_name: ".ci.agent-release"
  sha_at_sync: "f15401546056c580a76c2c3fd86b1ad831a4d70b92c3d474fd6950935fff6f27"
  description: "Specifies the Kubernetes API version (v1) used for the agent-release CI resource definition."
---
# .ci.agent-release.apiVersion

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent-release.yaml`

# .ci.agent-release.apiVersion


yaml_key .ci.agent-release.apiVersion in .ci.agent-release [yaml] /Users/spark/git/service-model-promotion/.ci/agent-release.yaml:1-1 :: apiVersion: v1

Description: Specifies the Kubernetes API version (v1) used for the agent-release CI resource definition.