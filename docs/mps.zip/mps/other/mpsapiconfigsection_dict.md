---
id: b0f5e899-09a7-5bd1-94fd-b53758d6ce41
type: catalog
title: "mps.api.config.section_dict"
created_at: 2026-06-06T18:47:27.701392+00:00
updated_at: 2026-06-20T22:55:26.489283+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.section_dict"
  signature: "section_dict = config.setdefault(section, {})"
  location: {'line_start': 34, 'line_end': 34, 'col_start': 4, 'col_end': 49}
  parent_qualified_name: "None"
  sha_at_sync: "724680a570cef3e1301ff6d0e25852557959ec21074ddde51a8368657f3d748e"
  description: "Retrieves the dictionary for the specified configuration section, creating and inserting an empty dictionary if the section does not already exist in the config."
---
# mps.api.config.section_dict

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.section_dict


variable mps.api.config.section_dict [python] /Users/spark/git/service-model-promotion/mps/api/config.py:34-34 :: section_dict = config.setdefault(section, {})

Description: Retrieves the dictionary for the specified configuration section, creating and inserting an empty dictionary if the section does not already exist in the config.