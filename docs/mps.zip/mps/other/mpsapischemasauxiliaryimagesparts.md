---
id: 2384cc9f-3684-5c9b-a10b-909822a91f28
type: catalog
title: "mps.api.schemas.AuxiliaryImages.parts"
created_at: 2026-06-06T18:47:28.917601+00:00
updated_at: 2026-06-20T22:55:25.240173+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.AuxiliaryImages.parts"
  signature: "parts = item.split(':')"
  location: {'line_start': 45, 'line_end': 45, 'col_start': 12, 'col_end': 35}
  parent_qualified_name: "mps.api.schemas.AuxiliaryImages"
  sha_at_sync: "4422334096d01cb87ab88924addba4a4869b6cbeb58856573827cae6e14cd861"
  description: "Splits an auxiliary image item string on the colon delimiter to separate its components (such as name and path)."
---
# mps.api.schemas.AuxiliaryImages.parts

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.AuxiliaryImages.parts


variable mps.api.schemas.AuxiliaryImages.parts in mps.api.schemas.AuxiliaryImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:45-45 :: parts = item.split(':')

Description: Splits an auxiliary image item string on the colon delimiter to separate its components (such as name and path).