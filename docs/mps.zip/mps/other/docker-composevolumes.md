---
id: b31c20e3-462e-5ad3-98ff-41f3cb071004
type: catalog
title: "docker-compose.volumes"
created_at: 2026-06-06T18:47:25.531152+00:00
updated_at: 2026-06-20T22:55:26.533266+00:00
source_files:
  - /Users/spark/git/service-model-promotion/docker-compose.yml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: "docker-compose.volumes"
  signature: "volumes:"
  location: {'line_start': 51, 'line_end': 54, 'col_start': 0, 'col_end': 0}
  parent_qualified_name: "docker-compose"
  sha_at_sync: "a1f0a024648063c11187ffeb0f204e7afb3c180a17a059ea039c5bcff0a7c6d8"
  description: "Defines named Docker volumes at the top level of the Compose file, enabling persistent data storage that can be shared and reused across services."
---
# docker-compose.volumes

**Related files:**
- `/Users/spark/git/service-model-promotion/docker-compose.yml`

# docker-compose.volumes


yaml_key docker-compose.volumes in docker-compose [yaml] /Users/spark/git/service-model-promotion/docker-compose.yml:51-54 :: volumes:

Description: Defines named Docker volumes at the top level of the Compose file, enabling persistent data storage that can be shared and reused across services.