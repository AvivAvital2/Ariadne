---
id: 68855062-54d5-5042-8c51-8a71a564fbfc
type: catalog
title: "mps.api.image_manager.ImageManager.stdout, stderr, exit_code"
created_at: 2026-06-06T18:47:28.997611+00:00
updated_at: 2026-07-03T06:16:14.987852+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.stdout, stderr, exit_code"
  signature: "stdout, stderr, exit_code = await run_command(build_command, supress_errors=True)"
  location: {'line_start': 74, 'line_end': 74, 'col_start': 12, 'col_end': 93}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "a229cac729782b62ee46850cefccd065bd384bc222bb3321c1d4ca1ef23c11de"
  description: "Captures the standard output, standard error, and exit code returned from asynchronously executing the image build command, with error suppression enabled."
---
# mps.api.image_manager.ImageManager.stdout, stderr, exit_code

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.stdout, stderr, exit_code


variable mps.api.image_manager.ImageManager.stdout, stderr, exit_code in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:74-74 :: stdout, stderr, exit_code = await run_command(build_command, supress_errors=True)

Description: Captures the standard output, standard error, and exit code returned from asynchronously executing the image build command, with error suppression enabled.

## Related Documents

- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 1.38)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 1.39)
- [mps.api.image_manager.ImageManager._, _, exit_code](fca980a3-5095-57b3-813a-59efc6ac0fee.md) - Related (graph distance 1.40)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 1.55)
- [mps.api.utils.stdout, stderr](c763f4e0-50eb-503d-abbf-927541162a1b.md) - Related (graph distance 1.56)
- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 2.75)
- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 2.86)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 2.92)
