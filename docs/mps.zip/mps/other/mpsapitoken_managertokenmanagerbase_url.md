---
id: 18254814-cbc1-548b-9217-db5dfc57bc3d
type: catalog
title: "mps.api.token_manager.TokenManager.base_url"
created_at: 2026-06-06T18:47:28.319620+00:00
updated_at: 2026-07-03T06:16:15.055169+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.TokenManager.base_url"
  signature: "base_url = await verify_connection_to_container_registry("
  location: {'line_start': 93, 'line_end': 99, 'col_start': 12, 'col_end': 13}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "c60c5a02e4c2f0ccd34175708194c5e95182e6178ac2348ae77dc5931d200c36"
  description: "Stores the validated base URL of the container registry, set by awaiting `verify_connection_to_container_registry` to confirm connectivity before use."
---
# mps.api.token_manager.TokenManager.base_url

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.base_url


variable mps.api.token_manager.TokenManager.base_url in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:93-99 :: base_url = await verify_connection_to_container_registry(

Description: Stores the validated base URL of the container registry, set by awaiting `verify_connection_to_container_registry` to confirm connectivity before use.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.base_url](12f4babf-5ed5-53e8-8546-6ccbc741379b.md) - Related (graph distance 1.07)
- [mps.api.utils.MPSSession.base_url](21e6face-0081-5442-b611-fbecb7c4adc7.md) - Related (graph distance 1.37)
- [mps.api.utils.MPSSession.__init__](e5d5dc79-6074-5bee-b16a-413f978e8f4a.md) - Related (graph distance 2.86)
