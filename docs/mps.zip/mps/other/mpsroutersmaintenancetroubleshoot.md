---
id: eae30478-01d5-5289-9ea4-366b0127c865
type: catalog
title: "mps.routers.maintenance.troubleshoot"
created_at: 2026-06-06T18:47:27.297637+00:00
updated_at: 2026-06-20T22:55:21.521714+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.maintenance.troubleshoot"
  signature: "troubleshoot = os.environ.get('MAINTENANCE_MODE')"
  location: {'line_start': 10, 'line_end': 10, 'col_start': 0, 'col_end': 49}
  parent_qualified_name: "None"
  sha_at_sync: "c14c506c3d767e55af76f83bb6888395c34a001cce3c1135189c789ad57c938d"
  description: "Retrieves the value of the `MAINTENANCE_MODE` environment variable to determine whether maintenance troubleshooting mode is active, returning `None` if the variable is unset."
---
# mps.routers.maintenance.troubleshoot

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# mps.routers.maintenance.troubleshoot


variable mps.routers.maintenance.troubleshoot [python] /Users/spark/git/service-model-promotion/mps/routers/maintenance.py:10-10 :: troubleshoot = os.environ.get('MAINTENANCE_MODE')

Description: Retrieves the value of the `MAINTENANCE_MODE` environment variable to determine whether maintenance troubleshooting mode is active, returning `None` if the variable is unset.