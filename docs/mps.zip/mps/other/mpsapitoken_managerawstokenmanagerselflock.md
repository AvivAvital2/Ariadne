---
id: 55bbe536-6bf2-5b31-9588-88fb729c745b
type: catalog
title: "mps.api.token_manager.AWSTokenManager.self.lock"
created_at: 2026-06-06T18:47:28.320134+00:00
updated_at: 2026-07-03T06:16:15.015296+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.self.lock"
  signature: "self.lock = Lock()"
  location: {'line_start': 123, 'line_end': 123, 'col_start': 8, 'col_end': 26}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "3f106b7038d795e7d33c968c5ed51e894f940c85460057b3e44052c8232537d6"
  description: "A threading lock used to synchronize access to token operations within the AWSTokenManager, ensuring thread-safe token retrieval and refresh."
---
# mps.api.token_manager.AWSTokenManager.self.lock

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.self.lock


variable mps.api.token_manager.AWSTokenManager.self.lock in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:123-123 :: self.lock = Lock()

Description: A threading lock used to synchronize access to token operations within the AWSTokenManager, ensuring thread-safe token retrieval and refresh.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.self.lock](57143008-764f-5da7-b32a-c853c8e8c11f.md) - Related (graph distance 1.38)
- [mps.api.token_manager.AWSTokenManager](9a3cc96b-b21c-5a57-a226-4016b151976e.md) - Related (graph distance 1.58)
- [mps.api.token_manager.AWSTokenManager.self.session](1289e361-b043-5abd-acfe-85ce20e92151.md) - Related (graph distance 1.59)
- [mps.service.MPS.self.token_manager](3011a42d-280b-5c01-ac37-84ac971d22b0.md) - Related (graph distance 1.60)
- [mps.api.token_manager.TokenManager.self.session](be761185-3f99-5091-bd94-e95c5f147d39.md) - Related (graph distance 2.69)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 2.76)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 2.81)
- [mps.service.MPS.get_token_manager](88755e90-2570-5be0-8c60-ae3e61bdad0e.md) - Related (graph distance 2.87)
- [mps.api.token_manager.TokenManager](a2fa93e7-c3a5-5fe9-b71c-b112437c2893.md) - Related (graph distance 2.88)
- [mps.api.image_cache.AsyncPersistentImageCache.self.conn](b23eeb5a-2004-5f5d-9a28-8bee812c752d.md) - Related (graph distance 2.90)
