---
id: 157b0e71-4b3f-5cba-9f9d-e6067dd488b8
type: catalog
title: "mps.api.image_manager.ImageManager.tag"
created_at: 2026-06-06T18:47:28.995511+00:00
updated_at: 2026-07-03T06:16:15.073509+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.tag"
  signature: "tag = f"{os.path.join(exported_image_path, docker_image_to_file_name(tag))}.tar.gz"
  location: {'line_start': 215, 'line_end': 215, 'col_start': 23, 'col_end': 106}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "069ac479858ae3fce457499f2065568f60e390c7bfea6c179eed67b098fb3d2d"
  description: "Constructs the local filesystem path for an exported Docker image by joining the export directory with a filename derived from the image tag and appending a `.tar.gz` extension."
---
# mps.api.image_manager.ImageManager.tag

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.tag


variable mps.api.image_manager.ImageManager.tag in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:215-215 :: tag = f"{os.path.join(exported_image_path, docker_image_to_file_name(tag))}.tar.gz"

Description: Constructs the local filesystem path for an exported Docker image by joining the export directory with a filename derived from the image tag and appending a `.tar.gz` extension.

## Related Documents

- [mps.api.image_manager.ImageManager.abs_file_path](e20816a3-c6c3-5c33-998b-da53b03788a3.md) - Related (graph distance 1.16)
- [mps.api.utils.docker_image_to_file_name](73847514-b1fb-5627-8728-c3c254d4f051.md) - Related (graph distance 1.58)
- [mps.routers.promote.full_image_path](500b36fd-1db3-50a3-ba72-2aaf28537e5b.md) - Related (graph distance 1.59)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.parsed_tag](68aae686-09d8-50b3-aa7e-da02513cdae2.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.zip_file_path](3e1de95d-3bac-5dd8-84da-a0de6c31cf9c.md) - Related (graph distance 2.81)
- [mps.api.image_manager.ImageManager.repository_and_tag](f8a23958-62d7-5fb0-a1d2-1c99bd4089d6.md) - Related (graph distance 3.00)
- [mps.routers.promote.image_path](95156ea1-61e6-5355-83d3-d882569289a2.md) - Related (graph distance 3.08)
- [mps.routers.promote.file_path](4232ce15-0a82-5bf1-9a20-d9a1d94712aa.md) - Related (graph distance 3.11)
- [mps.routers.promote.image](27547b1e-fb43-5004-8a56-9889cfe7c030.md) - Related (graph distance 3.12)
