---
id: 400de0b1-3a33-579b-9168-2cbe14f7b6e4
type: catalog
title: "mps.api.utils.exit_code"
created_at: 2026-06-06T18:47:29.301333+00:00
updated_at: 2026-06-20T22:55:26.552807+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.exit_code"
  signature: "exit_code = process.returncode"
  location: {'line_start': 53, 'line_end': 53, 'col_start': 4, 'col_end': 34}
  parent_qualified_name: "None"
  sha_at_sync: "7e19e4d1de5c845ae98cd7242756b9af6bb281c563f00082c03c33307561f46e"
  description: "Stores the return code of a completed subprocess, capturing its exit status for subsequent error checking or flow control."
---
# mps.api.utils.exit_code

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.exit_code


variable mps.api.utils.exit_code [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:53-53 :: exit_code = process.returncode

Description: Stores the return code of a completed subprocess, capturing its exit status for subsequent error checking or flow control.