---
id: 72b74dcf-45b1-511b-938a-0d645ae30140
type: catalog
title: "mps.api.image_manager.ImageManager.response"
created_at: 2026-06-06T18:47:29.004333+00:00
updated_at: 2026-07-03T06:16:14.987149+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.response"
  signature: "response = self.token_manager.session.get('/v2/_catalog').json()"
  location: {'line_start': 338, 'line_end': 338, 'col_start': 12, 'col_end': 76}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "485d5d7955a3d2e03670fdb2af8eb76495dec895a0a3395a05a639165e74e9f5"
  description: "Stores the parsed JSON response from a GET request to the registry's `/v2/_catalog` endpoint, containing the list of available image repositories."
---
# mps.api.image_manager.ImageManager.response

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.response


variable mps.api.image_manager.ImageManager.response in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:338-338 :: response = self.token_manager.session.get('/v2/_catalog').json()

Description: Stores the parsed JSON response from a GET request to the registry's `/v2/_catalog` endpoint, containing the list of available image repositories.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.response](67c5381a-ccc2-5500-a502-f007567820c3.md) - Related (graph distance 1.28)
- [mps.api.image_manager.ImageManager.repositories](7518500a-6dbd-5b7e-95aa-c43b5664b35f.md) - Related (graph distance 1.56)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 2.88)
