---
id: 20544901-82a4-5cde-8e92-17ebf78c1ba8
type: catalog
title: "mps.api.logger.Logger.log_format"
created_at: 2026-06-06T18:47:28.692417+00:00
updated_at: 2026-07-03T06:16:14.971200+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger.log_format"
  signature: "log_format = '%(levelname)s:%(delimiter)s%(message)s'"
  location: {'line_start': 31, 'line_end': 31, 'col_start': 8, 'col_end': 61}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "1593e9c9b26492a5481e703b6080907b33da44316eb1f6223997dfe573306d3f"
  description: "Defines the format string for log messages, displaying the log level and message separated by a configurable delimiter."
---
# mps.api.logger.Logger.log_format

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.log_format


variable mps.api.logger.Logger.log_format in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:31-31 :: log_format = '%(levelname)s:%(delimiter)s%(message)s'

Description: Defines the format string for log messages, displaying the log level and message separated by a configurable delimiter.

## Related Documents

- [mps.api.logger.Logger.file_formatter](602a21af-d0b0-5b18-939a-1112561f8d98.md) - Related (graph distance 1.44)
- [mps.api.logger.Logger.console_formatter](10b77a84-a8e9-5196-8d6b-0fd076b45055.md) - Related (graph distance 1.49)
- [mps.api.logger.CustomLogger.extra['delimiter']](f3678951-3b38-5bbb-93cb-06dcd193a187.md) - Related (graph distance 1.50)
- [mps.api.logger.Logger.file_handler](0027aaf8-fb06-5408-8dde-5fe2c7b80061.md) - Related (graph distance 2.97)
- [mps.api.logger.Logger.console_handler](2a3b5941-578c-54de-aa16-2ea79fdfded9.md) - Related (graph distance 2.98)
