---
id: 602a21af-d0b0-5b18-939a-1112561f8d98
type: catalog
title: "mps.api.logger.Logger.file_formatter"
created_at: 2026-06-06T18:47:28.693041+00:00
updated_at: 2026-07-03T06:16:15.072577+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.Logger.file_formatter"
  signature: "file_formatter = logging.Formatter(log_format)"
  location: {'line_start': 34, 'line_end': 34, 'col_start': 8, 'col_end': 54}
  parent_qualified_name: "mps.api.logger.Logger"
  sha_at_sync: "d8bfc830aab658e712ee39130391b3f7564c72b4ed770c49365ae3509994f0ae"
  description: "Creates a logging formatter using the configured log format string, used to format log messages written to file output."
---
# mps.api.logger.Logger.file_formatter

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.Logger.file_formatter


variable mps.api.logger.Logger.file_formatter in mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:34-34 :: file_formatter = logging.Formatter(log_format)

Description: Creates a logging formatter using the configured log format string, used to format log messages written to file output.

## Related Documents

- [mps.api.logger.Logger.console_formatter](10b77a84-a8e9-5196-8d6b-0fd076b45055.md) - Related (graph distance 1.17)
- [mps.api.logger.Logger.log_format](20544901-82a4-5cde-8e92-17ebf78c1ba8.md) - Related (graph distance 1.44)
- [mps.api.logger.Logger.file_handler](0027aaf8-fb06-5408-8dde-5fe2c7b80061.md) - Related (graph distance 1.53)
- [mps.api.logger.Logger.console_handler](2a3b5941-578c-54de-aa16-2ea79fdfded9.md) - Related (graph distance 2.66)
- [mps.api.logger.CustomLogger.extra['delimiter']](f3678951-3b38-5bbb-93cb-06dcd193a187.md) - Related (graph distance 2.94)
