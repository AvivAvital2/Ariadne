---
id: bdd4c781-86fa-5a06-ad52-801952cb11cb
type: catalog
title: "mps.routers.basic.build_info"
created_at: 2026-06-06T18:47:27.474774+00:00
updated_at: 2026-06-20T22:55:26.110781+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "async_function"
  qualified_name: "mps.routers.basic.build_info"
  signature: "async def build_info():"
  location: {'line_start': 16, 'line_end': 19, 'col_start': 0, 'col_end': 78}
  parent_qualified_name: "None"
  sha_at_sync: "a1cfcca7142135efa60a27e9a9397edbc7fd002ef7ced8e6ba7cc8e2fb46cc43"
  description: "Handles a request for build information by returning the application's build details as a response."
---
# mps.routers.basic.build_info

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# mps.routers.basic.build_info


async_function mps.routers.basic.build_info [python] /Users/spark/git/service-model-promotion/mps/routers/basic.py:16-19 :: async def build_info():

Description: Handles a request for build information by returning the application's build details as a response.