---
id: 7294acfc-63e5-53e1-aa50-42065ebe3449
type: catalog
title: "mps.api.errors.UnavailableImage.__init__"
created_at: 2026-06-06T18:47:29.761222+00:00
updated_at: 2026-07-03T06:16:15.096713+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.UnavailableImage.__init__"
  signature: "def __init__(self, message: str):"
  location: {'line_start': 77, 'line_end': 78, 'col_start': 4, 'col_end': 55}
  parent_qualified_name: "mps.api.errors.UnavailableImage"
  sha_at_sync: "0472c79a5484817c693454ef1b940888835a73689c81833bdebd4ae542146a87"
  description: "Initializes an UnavailableImage error instance with the provided error message string."
---
# mps.api.errors.UnavailableImage.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.UnavailableImage.__init__


method mps.api.errors.UnavailableImage.__init__ in mps.api.errors.UnavailableImage [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:77-78 :: def __init__(self, message: str):

Description: Initializes an UnavailableImage error instance with the provided error message string.

## Related Documents

- [mps.api.errors.UnableToUploadOneOrMoreImages.__init__](f01cfb5d-a741-5696-a0af-4913f518cb12.md) - Related (graph distance 1.21)
- [mps.api.errors.UnableToObtainPushedImagesFromContainerRegistry.__init__](bf2dd824-700b-53e4-aea7-29002bb142db.md) - Related (graph distance 1.24)
- [mps.api.errors.UnableToStoreCredentialsFile.__init__](57785d64-9769-5883-8802-f6c54486e5b3.md) - Related (graph distance 1.27)
- [mps.api.errors.MissingConfigValues.__init__](bb2538a2-3351-5fcf-adae-88f9badde3c5.md) - Related (graph distance 1.30)
- [mps.api.errors.UnreachableContainerRegistry.__init__](8ce03501-19f0-51a6-8629-34bda8172c4b.md) - Related (graph distance 1.30)
- [mps.api.errors.UnableToGetAuthToken.__init__](3e66395f-d166-564e-88e4-7a8764021cd5.md) - Related (graph distance 1.31)
- [mps.api.errors.SelfSignedCertificate.__init__](ca15b54b-d63c-5d90-9adb-6e462c0058e8.md) - Related (graph distance 1.32)
- [mps.api.errors.UnavailableImage](b5b87be5-2944-5fde-9872-c65220767962.md) - Related (graph distance 1.55)
- [mps.api.errors.InvalidConfigurationFile.__init__](1b2f4c39-2c17-54d9-ab45-75c1685aa2e4.md) - Related (graph distance 2.46)
- [mps.api.errors.InvalidRegistryProvider.__init__](b4a936e2-2578-5fd5-9872-794ec6914cb1.md) - Related (graph distance 2.47)
