---
id: 352275c9-9866-54cf-91e4-d353f05e204e
type: catalog
title: "mps.api.token_manager.TokenManager.get_username_and_password"
created_at: 2026-06-06T18:47:28.314019+00:00
updated_at: 2026-07-03T06:16:15.079513+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.TokenManager.get_username_and_password"
  signature: "async def get_username_and_password(self) -> (str, str):"
  location: {'line_start': 83, 'line_end': 88, 'col_start': 4, 'col_end': 101}
  parent_qualified_name: "mps.api.token_manager.TokenManager"
  sha_at_sync: "58e4aa19463edf2a9b558991575ba136930fe210eb21f9cfff39d9662030c70a"
  description: "Asynchronously retrieves and returns the stored username and password as a tuple of strings."
---
# mps.api.token_manager.TokenManager.get_username_and_password

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.TokenManager.get_username_and_password


method mps.api.token_manager.TokenManager.get_username_and_password in mps.api.token_manager.TokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:83-88 :: async def get_username_and_password(self) -> (str, str):

Description: Asynchronously retrieves and returns the stored username and password as a tuple of strings.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.get_username_and_password](45cb5036-88de-52b9-acec-417964547495.md) - Related (graph distance 1.26)
- [mps.api.token_manager.AWSTokenManager.login](902a7ee2-9f46-53a1-8f0d-766ceb4c012a.md) - Related (graph distance 2.81)
- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 2.91)
