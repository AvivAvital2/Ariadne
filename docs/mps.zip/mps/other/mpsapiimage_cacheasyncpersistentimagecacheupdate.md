---
id: b9099bc1-0ee6-547f-b844-bd21c0c852ea
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.update"
created_at: 2026-06-06T18:47:29.720580+00:00
updated_at: 2026-07-03T06:16:15.043670+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.update"
  signature: "async def update(self, key, value):"
  location: {'line_start': 54, 'line_end': 58, 'col_start': 4, 'col_end': 9}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "6bd9dc7a6e242410aaea76eab8cd3c746c553f869df6153a0cccdac771e92e6b"
  description: "Asynchronously stores or updates a cached image entry for the given key with the provided value, persisting the change to the underlying storage."
---
# mps.api.image_cache.AsyncPersistentImageCache.update

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.update


method mps.api.image_cache.AsyncPersistentImageCache.update in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:54-58 :: async def update(self, key, value):

Description: Asynchronously stores or updates a cached image entry for the given key with the provided value, persisting the change to the underlying storage.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.set](5dc502b1-4a0d-5dd1-b13d-94f02f75f05f.md) - Related (graph distance 1.19)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 1.30)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 1.43)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.67)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.83)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 3.05)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 3.07)
