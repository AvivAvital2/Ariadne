---
id: 3752f446-dad8-5aca-aa2a-719905e56a24
type: catalog
title: "mps.api.schemas.BaseImages.data['versions']"
created_at: 2026-06-06T18:47:28.914510+00:00
updated_at: 2026-07-03T06:16:15.054415+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.schemas.BaseImages.data['versions']"
  signature: "data['versions'] = {version.replace('-', '_'): version_data for version, version_data in data['versions']}"
  location: {'line_start': 19, 'line_end': 19, 'col_start': 8, 'col_end': 114}
  parent_qualified_name: "mps.api.schemas.BaseImages"
  sha_at_sync: "48db944296e94fb24b9824a2df8c99d231ed6c07ebc6e07f20924c4988b32c3b"
  description: "Transforms the `versions` dictionary by replacing hyphens with underscores in each version key while preserving the associated version data."
---
# mps.api.schemas.BaseImages.data['versions']

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# mps.api.schemas.BaseImages.data['versions']


variable mps.api.schemas.BaseImages.data['versions'] in mps.api.schemas.BaseImages [python] /Users/spark/git/service-model-promotion/mps/api/schemas.py:19-19 :: data['versions'] = {version.replace('-', '_'): version_data for version, version_data in data['versions']}

Description: Transforms the `versions` dictionary by replacing hyphens with underscores in each version key while preserving the associated version data.

## Related Documents

- [mps.api.schemas.BaseImages.make_versions_dict](8657be3d-c0d3-5523-972b-70729bb49b32.md) - Related (graph distance 1.40)
