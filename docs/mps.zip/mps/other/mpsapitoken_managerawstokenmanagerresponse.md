---
id: 67c5381a-ccc2-5500-a502-f007567820c3
type: catalog
title: "mps.api.token_manager.AWSTokenManager.response"
created_at: 2026-06-06T18:47:28.321256+00:00
updated_at: 2026-07-03T06:16:15.031931+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.token_manager.AWSTokenManager.response"
  signature: "response = self.session.get_authorization_token(registryIds=[self.registry_id])"
  location: {'line_start': 135, 'line_end': 135, 'col_start': 16, 'col_end': 95}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "b3eeadb9190403ab6ad1b652bff507fd17a868ac8e84d847ea430c1c483240d0"
  description: "Retrieves an ECR authorization token from AWS for the specified registry ID by calling the session's `get_authorization_token` method."
---
# mps.api.token_manager.AWSTokenManager.response

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.response


variable mps.api.token_manager.AWSTokenManager.response in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:135-135 :: response = self.session.get_authorization_token(registryIds=[self.registry_id])

Description: Retrieves an ECR authorization token from AWS for the specified registry ID by calling the session's `get_authorization_token` method.

## Related Documents

- [mps.api.image_manager.ImageManager.response](72b74dcf-45b1-511b-938a-0d645ae30140.md) - Related (graph distance 1.28)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.60)
- [mps.api.image_manager.ImageManager.repositories](7518500a-6dbd-5b7e-95aa-c43b5664b35f.md) - Related (graph distance 2.85)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 3.00)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 3.08)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 3.17)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 3.18)
- [mps.service.MPS.self.registry_addr](5cdaf73f-5565-5da0-bc7a-a9dc44ac4861.md) - Related (graph distance 3.20)
- [mps.api.token_manager.AWSTokenManager.region_name](1dacb1db-2e0a-5c6d-9346-b1edb16f86d5.md) - Related (graph distance 3.24)
