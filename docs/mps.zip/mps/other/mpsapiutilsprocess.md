---
id: 056c716d-aab5-598a-a684-54765ce5cf19
type: catalog
title: "mps.api.utils.process"
created_at: 2026-06-06T18:47:29.300256+00:00
updated_at: 2026-06-20T22:55:25.808730+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.process"
  signature: "process = await asyncio.create_subprocess_exec("
  location: {'line_start': 31, 'line_end': 35, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "None"
  sha_at_sync: "7876593d546b020cdcda51f07a3fa7ccddae8692ee6316e8e7241a5cc47cbd06"
  description: "A module-level variable holding the asynchronous subprocess created by `asyncio.create_subprocess_exec`, used to execute an external command within the `mps.api.utils` module."
---
# mps.api.utils.process

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.process


variable mps.api.utils.process [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:31-35 :: process = await asyncio.create_subprocess_exec(

Description: A module-level variable holding the asynchronous subprocess created by `asyncio.create_subprocess_exec`, used to execute an external command within the `mps.api.utils` module.