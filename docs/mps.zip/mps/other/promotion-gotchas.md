---
id: dca85fe9-ce01-51d1-a297-875cbaf4b6a9
type: gotcha
title: "Promotion Gotchas"
created_at: 2026-06-06T19:04:46.478811+00:00
updated_at: 2026-06-20T22:55:24.387173+00:00
source_files:
  - /Users/spark/git/service-model-promotion/promotion.conf
metadata:
  module_name: "promotion"
  language: "hocon"
  source_name: "mps"
---
# Promotion Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/promotion.conf`

# Promotion Gotchas


# Gotchas & Pitfalls: `promotion` Module (HOCON Config)

### Dotted-key versioning with `3-0-0` instead of `3.0.0`
**Trigger:** The version segment uses hyphens (`3-0-0`) rather than dots, because dots are HOCON path separators. A developer expecting `baseImage."3.0.0".aio` will find nothing.
**Affected Files:** `promotion` config (this file)
**Fix:** Standardize on a documented convention. Either always quote dotted version keys (`baseImage."3.0.0".aio = ...`) or document that version keys use hyphens. Provide a lookup helper that normalizes `3.0.0` → `3-0-0`.
**Category:** framework
**Example:**
```hocon
# This does NOT create a key "3.0.0"; it creates nested 3 -> 0 -> 0
baseImage.3.0.0.aio = "..."
# Code lookup config.getString("baseImage.3-0-0.aio") fails if you used dots
```

### `off` / `on` parsed as boolean, not string
**Trigger:** `modelpromotion.auth.enabled = off` — HOCON interprets `off`, `on`, `yes`, `no`, `true`, `false` as booleans. Reading it as a string yields `"off"`, but reading as boolean works. Mixing the two access patterns silently breaks.
**Affected Files:** `promotion` config (this file)
**Fix:** Be consistent — always read auth flags via `getBoolean(...)`. Note that `httpClient.proxy.enabled = false` uses `false` while this uses `off`; unify the style to avoid confusion.
**Category:** type-system
**Example:**
```scala
config.getBoolean("modelpromotion.auth.enabled") // false  ✓
config.getString("modelpromotion.auth.enabled")  // throws WrongType ✗
```

### Empty-string defaults treated as valid configuration
**Trigger:** `proxy.config.host = ""`, `username = ""`, `password = ""` are empty strings, not absent/null. `hasPath(...)` returns `true` and `getString(...)` returns `""`, so naive validation passes and the client may attempt to connect to an empty host.
**Affected Files:** `promotion` config (this file)
**Fix:** Validate non-emptiness explicitly when `proxy.enabled` / `proxy.authentication.enabled` is true. Don't rely on `hasPath`.
**Category:** type-system
**Example:**
```scala
if (config.getBoolean("httpClient.proxy.enabled")) {
  val host = config.getString("httpClient.proxy.config.host")
  require(host.nonEmpty, "proxy enabled but host is empty") // needed!
}
```

### Decoupled enable-flags from their config blocks
**Trigger:** `proxy.enabled = false` but proxy host/port still defined; `proxy.authentication.enabled = false` while credentials sit in plaintext. Someone flipping only the auth flag without setting credentials gets empty username/password sent.
**Affected Files:** `promotion` config (this file)
**Fix:** Gate credential reads behind the auth flag and require non-empty values at that point. Consider grouping the flag inside its block so it can't be edited independently.
**Category:** domain
**Example:**
```hocon
httpClient.proxy.authentication.enabled = true
httpClient.proxy.authentication.username = ""  # silently sends empty creds
```

### Port as bare number — type coercion surprise
**Trigger:** `proxy.config.port = 3128` is read as Int. If a future override supplies it quoted (`"3128"`) from an env var (`PORT=3128`), `getInt` still works, but `getString` on the original numeric fails. Substitution from env vars yields strings.
**Affected Files:** `promotion` config (this file)
**Fix:** Standardize access via `getInt`. If using env substitution, ensure consumers don't assume string type.
**Category:** type-system
**Example:**
```hocon
proxy.config.port = ${?PROXY_PORT}   # env injects "3128" as string
# config.getInt is lenient and parses it; getString throws on the literal 3128
```

### Plaintext secrets in config
**Trigger:** `password = ""` placeholder invites real passwords being committed inline. Secrets in HOCON files end up in version control and logs.
**Affected Files:** `promotion` config (this file)
**Fix:** Use env-var substitution (`password = ${?PROXY_PASSWORD}`) or a secrets manager. Never commit real values. Mask on logging.
**Category:** domain
**Example:**
```hocon
httpClient.proxy.authentication.password = ${?PROXY_PASSWORD}
```

### Image tags are mutable references (`prod-3.0.0`)
**Trigger:** Base images reference tags, not digests. The `prod-3.0.0-aio` tag can be re-pushed, so "promoting" the same version may pull different image bytes over time — non-reproducible deployments.
**Affected Files:** `promotion` config (this file)
**Fix:** Pin by digest (`reg.sparkbeyond.com/...@sha256:...`) for promotion/reproducibility-critical paths.
**Category:** domain
**Example:**
```hocon
# Tag can change underneath you:
baseImage.3-0-0.aio = "reg.../prediction-server:prod-3.0.0-aio"
# Prefer:
baseImage.3-0-0.aio = "reg.../prediction-server@sha256:abc123..."
```

### `minimal` variant has no suffix — inconsistent naming
**Trigger:** Three variants use a suffix (`-aio`, `-osm`, `-gdata`), but `minimal` maps to the bare tag `prod-3.0.0`. Code that builds tags via string interpolation (`prod-3.0.0-$variant`) breaks for `minimal`.
**Affected Files:** `promotion` config (this file)
**Fix:** Always read the full image from config rather than constructing the tag programmatically; or give `minimal` an explicit `-minimal` suffix.
**Category:** framework
**Example:**
```scala
val img = s"reg.../prediction-server:prod-3.0.0-$variant" // wrong for "minimal"
```

### Sibling-key override merges, not replacement
**Trigger:** When a later config layer (env, override file) sets `baseImage.3-0-0.aio`, HOCON deep-merges objects. Removing a variant requires explicit `null`; redefining `baseImage` partially won't drop other keys, which can confuse "I cleared the images" assumptions.
**Affected Files:** `promotion` config (this file)
**Fix:** Understand HOCON object merge semantics; use `baseImage = null` then redefine, or override leaf keys explicitly.
**Category:** framework
**Example:**
```hocon
# override layer
baseImage.3-0-0.aio = "new"   # other variants remain from base layer
```