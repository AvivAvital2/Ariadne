---
id: 7dbc6126-80fa-55c9-a3f4-316fc8206f17
type: gotcha
title: "Image Manager Gotchas"
created_at: 2026-06-06T19:03:43.495875+00:00
updated_at: 2026-06-20T22:55:22.840885+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  module_name: "mps.api.image_manager"
  language: "python"
  source_name: "mps"
---
# Image Manager Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# Image Manager Gotchas


# Gotchas and Pitfalls: `mps.api.image_manager`

### `asyncio.Lock()` created fresh inside method provides no mutual exclusion
**Trigger:** Calling `get_exported_image_list` concurrently expecting serialized access.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Create the lock once in `__init__` (`self._lock = asyncio.Lock()`) and reuse it. A lock instantiated inside the method is unique per call and locks nothing.
**Category:** thread-safety
**Example:**
```python
async def get_exported_image_list(self, images: list):
    async with asyncio.Lock():   # NEW lock every call -> no protection
        ...
```

### Type hint `[TokenManager | AWSTokenManager]` is a list, not a union
**Trigger:** Reading the constructor signature and trusting the annotation; static checkers will not recognize the intended union.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Use `Union[TokenManager, AWSTokenManager]` or `TokenManager | AWSTokenManager` (no brackets).
**Category:** type-system
**Example:**
```python
def __init__(self, token_manager: [TokenManager | AWSTokenManager], ...):
    # This annotation is literally list[type], silently wrong
```

### `push_image` returns inconsistent types (str path vs. int exit_code)
**Trigger:** Callers treat the return value uniformly.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Normalize return type. Note in `build_and_push`, when `export_image_as_file=True`, `push_image` returns a `.gz` file path (reassigned to `docker_image_path`); otherwise it returns an `exit_code` int. Meanwhile `upload_missing_auxiliary_images` checks `exit_code == 0` — but in the export path it gets a string, which is never `== 0`, silently treated as failure.
**Category:** type-system
**Example:**
```python
push_results = await asyncio.gather(*[self.push_image(a) for a in missing])
if not all(exit_code == 0 for exit_code in push_results):  # str != 0 always
    raise UnableToUploadOneOrMoreImages(...)
```

### `check_if_image_archive_exists_on_local_storage` returns `None` when not in export mode
**Trigger:** Called via `get_exported_image_list` or `get_if_image_exists` when `export_image_as_file=False`; the method has no return on the false branch, yielding `None`.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Return a consistent tuple `(False, '')` for all branches, or guard the call site. Unpacking `None` later (`already_exported, abs_file_path = ...`) would raise.
**Category:** type-system
**Example:**
```python
async def check_if_image_archive_exists_on_local_storage(self, tag):
    if self.export_image_as_file is True:
        ...
    # implicit return None -> breaks tuple unpacking
```

### Inverted/contradictory debug messages in `get_if_image_exists` (remote path)
**Trigger:** Relying on log messages for debugging cache/registry state in the non-export branch.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Correct the mapping. `(True, True)` says "Unable to find remotely, removing from cache" yet the match returns `image_path` (treats as found). The messages contradict the actual logic.
**Category:** domain
**Example:**
```python
(True, True): f'Unable to find {tag} remotely, removing from cache',  # but code returns image_path
```

### Missing-image filter logic is inverted in `upload_missing_auxiliary_images`
**Trigger:** Expecting to push images that are *missing*.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** `get_exported_image_list` returns images that *exist* in the registry. Filtering those `if image not in aux_images` will almost always be empty (they came from `aux_images`). The "missing" set is computed from existing images, so genuinely missing images are never pushed.
**Category:** domain
**Example:**
```python
missing_auxiliary_images = [
    image for image in await self.get_exported_image_list(aux_images)  # these EXIST
    if image not in aux_images  # subset of aux_images -> usually []
]
```

### `match self.export_image_as_file: case True:` with no default reassigns nothing
**Trigger:** Calling `check_if_image_tag_exists_in_cache` when `export_image_as_file=False`.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Acceptable but fragile — `tag` stays unchanged on the non-True case. Be aware `case True` only matches the literal `True`, not truthy values. A non-bool truthy value would fall through.
**Category:** framework
**Example:**
```python
match self.export_image_as_file:
    case True: tag = ...   # only matches literal True; truthy ints/strs fall through
```

### Naked f-string nested quote syntax requires Python 3.12+
**Trigger:** Running on Python < 3.12.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** The f-string `f"{'...' if not self.token_manager.verify_certificate_signing else ''}"` uses same-quote nesting and multi-line conditional inside braces — only valid in 3.12+. Extract to a variable for compatibility.
**Category:** framework
**Example:**
```python
f"{'--src-tls-verify=false --dest-tls-verify=false '
if not self.token_manager.verify_certificate_signing else ''}"
```

### Shell injection / quoting in `build_command` and `push_command`
**Trigger:** `tag`, `docker_image_path`, `annotations_list`, or `temp_directory` containing shell metacharacters or spaces; commands built as strings and run via shell.
**Affected Files:** `mps/api/image_manager.py`, `mps/api/utils.py`
**Fix:** Pass argument lists (as done in `list_local_images`) instead of interpolated strings, or `shlex.quote` each value. Annotations are user-influenced.
**Category:** domain
**Example:**
```python
annotations_string = ''.join(f'--annotation {x} ' for x in annotations_list)  # unquoted user input
```

### `repo_prefix` filter matches via `startswith` then `list_pushed_images` issues N+1 sync HTTP calls inside a dict comp
**Trigger:** A registry with many repositories.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** These are synchronous `session.get(...)` calls inside an async method — they block the event loop, one per repo. Batch or offload to a thread, and use `asyncio.gather` with an async client.
**Category:** async
**Example:**
```python
return {
    f'{...}/{repository_name}': self.token_manager.session.get(  # blocking, sequential, N calls
        f'/v2/{repository_name}/tags/list').json().get('tags')
    for repository_name in repositories_in_prefix
}
```

### List comprehension used for side effects (awaiting `cache.set`)
**Trigger:** Reading `list_local_images` / `get_if_image_exists`; building a throwaway list just to run awaits.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Use a normal `for` loop or `asyncio.gather`. The list comp `[await cache.set(...) for ...]` allocates and runs sequentially, obscuring intent.
**Category:** performance
**Example:**
```python
[await cache.set(key, datetime.now()) for key, _ in images.items()]  # side-effect comprehension
```

### `delete_local_images` clears the entire cache even on partial deletion
**Trigger:** Any successful `buildah rmi` triggers `cache.clear()`, wiping cache entries for images that still exist (e.g. release images excluded by the filter).
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Delete only the removed tags from cache instead of clearing wholesale.
**Category:** domain
**Example:**
```python
await run_command(['buildah', 'rmi'] + images + dangling_images)
async with self.local_image_cache as cache:
    await cache.clear()  # nukes everything, including still-present release images
```

### `if auxiliary_image_list and auxiliary_image_list is not None:` redundant; non-compose path falls through silently
**Trigger:** `use_docker_compose=True` but `auxiliary_image_list` empty/None — no env file is generated and execution falls through to `cache_image`, returning `docker_image_path` instead of an env file.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Generate the env file regardless of whether aux images exist when compose is requested; the empty-list case currently silently returns the wrong artifact type.
**Category:** domain
**Example:**
```python
if use_docker_compose is True:
    if auxiliary_image_list and auxiliary_image_list is not None:  # empty list skips env generation
        ...
# falls through, returns docker_image_path not env file
```

### `list_local_images` dict comprehension key collision in export mode
**Trigger:** Two images mapping to the same file name via `docker_image_to_file_name`.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** The second dict-comp rebuilds keys from filenames; collisions silently overwrite. Also it iterates over `images` keys (tags) and discards values. Validate uniqueness or keep tag mapping.
**Category:** performance
**Example:**
```python
images = {
    f"{os.path.join(exported_image_path, docker_image_to_file_name(image))}.tar.gz": ""
    for image in images   # collisions silently dropped
}
```

### `NamedTemporaryFile` context closes before push in non-export... actually push happens inside, but model extraction path assumptions
**Trigger:** `push_image` for export reads `containers-storage:{tag}` after build; fine, but `docker_image_path` reassignment to `.gz` path happens *inside* the `with` block, while `use_docker_compose`/`cache_image` use it *after*. The Dockerfile temp is gone by then (acceptable), but the reassigned path semantics differ between branches.
**Affected Files:** `mps/api/image_manager.py`
**Fix:** Document that `docker_image_path` becomes a filesystem `.gz` path in export mode but a registry ref otherwise; downstream `cache_image`/`generate_env_file` must handle both.
**Category:** type-system
**Example:**
```python
case True:
    docker_image_path = await self.push_image(docker_image_path)  # now a .gz file path
...
await self.cache_image(docker_image_path)  # caches file path vs registry ref
```

### `parse_size` over empty/blank lines from `buildah images`
**Trigger:** `get_size_of_images` maps `parse_size` over every output line; an empty trailing line raises `InvalidSize`.
**Affected Files:** `mps/api/image_manager.py`, `humanfriendly`
**Fix:** Filter empty/whitespace lines before summing.
**Category:** framework
**Example:**
```python
return sum(map(parse_size, stdout_size))  # blank line -> humanfriendly.InvalidSize
```