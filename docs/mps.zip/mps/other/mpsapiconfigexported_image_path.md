---
id: a5afb6f3-473f-5cc0-b8b4-6f8915df6df5
type: catalog
title: "mps.api.config.exported_image_path"
created_at: 2026-06-06T18:47:27.702668+00:00
updated_at: 2026-07-03T06:16:15.030012+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.config.exported_image_path"
  signature: "exported_image_path = config['exported_images']['path']"
  location: {'line_start': 41, 'line_end': 41, 'col_start': 0, 'col_end': 55}
  parent_qualified_name: "None"
  sha_at_sync: "4f50bb676b159c0d5531b09b012cf56591e11a3de0f363ea72f9b42e933cda2e"
  description: "Module-level variable storing the filesystem path for exported images, retrieved from the application's configuration dictionary."
---
# mps.api.config.exported_image_path

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# mps.api.config.exported_image_path


variable mps.api.config.exported_image_path [python] /Users/spark/git/service-model-promotion/mps/api/config.py:41-41 :: exported_image_path = config['exported_images']['path']

Description: Module-level variable storing the filesystem path for exported images, retrieved from the application's configuration dictionary.

## Related Documents

- [mps.api.config.image_cache_path](7637cc3a-e5c8-5fdc-a9db-f029a1b0f8a8.md) - Related (graph distance 1.27)
- [mps.conf.defaults.exported_images](608cb4c7-b3f9-58cc-be19-857775969202.md) - Related (graph distance 1.52)
- [mps.defaults.exported_images](5c6257ad-766f-594d-8016-fc0009e656d2.md) - Related (graph distance 1.53)
- [mps.api.config.base_images](74d6912f-962d-55aa-b577-6c41224b23e4.md) - Related (graph distance 1.55)
- [mps.api.config.file_path](c537075b-43cc-5484-a416-55e148109e5d.md) - Related (graph distance 1.56)
- [mps.api.image_cache.AsyncPersistentImageCache.self.db_path](1db63d01-0836-5b7f-b409-5b08036af4b4.md) - Related (graph distance 1.63)
- [mps.api.image_manager.ImageManager.image_path](73109235-6929-5b68-846e-9c12dab68101.md) - Related (graph distance 1.64)
- [mps.api.image_manager.ImageManager.docker_image_path](bfca806c-74e3-5757-843f-a817bf0f1bc8.md) - Related (graph distance 1.65)
- [mps.api.image_manager.ImageManager.self.local_image_cache](bb8fd6f8-d27b-5d1d-8d84-553e051a13de.md) - Related (graph distance 2.78)
- [mps.conf.defaults.local_image_cache](d1c16c36-5d5f-50ac-9f19-a84cbd69a748.md) - Related (graph distance 2.89)
