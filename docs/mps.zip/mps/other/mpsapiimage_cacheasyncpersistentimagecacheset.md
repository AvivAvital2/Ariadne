---
id: 5dc502b1-4a0d-5dd1-b13d-94f02f75f05f
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.set"
created_at: 2026-06-06T18:47:29.720325+00:00
updated_at: 2026-07-03T06:16:15.045116+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.set"
  signature: "async def set(self, key, value):"
  location: {'line_start': 48, 'line_end': 52, 'col_start': 4, 'col_end': 9}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "0923b2d8cdc757a147300e62ee90da7519c0c1238a54be297930001fd828d594"
  description: "Asynchronously stores a value in the persistent image cache under the specified key, persisting it to durable storage."
---
# mps.api.image_cache.AsyncPersistentImageCache.set

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.set


method mps.api.image_cache.AsyncPersistentImageCache.set in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:48-52 :: async def set(self, key, value):

Description: Asynchronously stores a value in the persistent image cache under the specified key, persisting it to durable storage.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.update](b9099bc1-0ee6-547f-b844-bd21c0c852ea.md) - Related (graph distance 1.19)
- [mps.api.image_cache.AsyncPersistentImageCache.delete](18063d23-2baf-58c4-a746-af8b4a046a21.md) - Related (graph distance 1.33)
- [mps.api.image_cache.AsyncPersistentImageCache.get](1942c980-d0ef-57bc-8c64-330f4aa597dc.md) - Related (graph distance 1.45)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 1.61)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 2.87)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 3.00)
- [mps.api.image_manager.ImageManager.get_if_image_exists](4bc9ed61-10f5-552c-9c0d-3ab6cdce026a.md) - Related (graph distance 3.07)
- [mps.api.image_cache.AsyncPersistentImageCache](3a3db6c0-be15-545e-8631-b0a1492e556e.md) - Related (graph distance 3.10)
- [mps.api.image_manager.ImageManager.delete_local_images](faf4a613-2d0d-5eca-aa2a-24c570bc6fbf.md) - Related (graph distance 3.13)
- [mps.api.image_cache.AsyncPersistentImageCache.__init__](99785f2f-6c49-5afa-a1f7-8b99ca32ff10.md) - Related (graph distance 3.27)
