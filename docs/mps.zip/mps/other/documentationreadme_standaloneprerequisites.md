---
id: b1049bff-0af7-5371-828b-4297451ba95e
type: catalog
title: "documentation.README_standalone.prerequisites"
created_at: 2026-06-06T18:47:26.281950+00:00
updated_at: 2026-06-20T22:55:22.945143+00:00
source_files:
  - /Users/spark/git/service-model-promotion/documentation/README_standalone.md
metadata:
  kind: "element"
  source_name: "mps"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "documentation.README_standalone.prerequisites"
  signature: "## Prerequisites"
  location: {'line_start': 11, 'line_end': 24, 'col_start': 0, 'col_end': 16}
  parent_qualified_name: "documentation.README_standalone"
  sha_at_sync: "0531b1276e0c8a956325fe5084b63e7f37c963a20f8aec11299656cad8d7be96"
  description: "Lists the required software, dependencies, and environment configuration that must be installed or set up before installing and running the standalone application."
---
# documentation.README_standalone.prerequisites

**Related files:**
- `/Users/spark/git/service-model-promotion/documentation/README_standalone.md`

# documentation.README_standalone.prerequisites


md_section documentation.README_standalone.prerequisites in documentation.README_standalone [markdown] /Users/spark/git/service-model-promotion/documentation/README_standalone.md:11-24 :: ## Prerequisites

Description: Lists the required software, dependencies, and environment configuration that must be installed or set up before installing and running the standalone application.