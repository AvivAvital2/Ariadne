---
id: 5d39322c-bf30-5148-8196-5e504c619f0d
type: catalog
title: "mps.api.image_manager.ImageManager.model_name"
created_at: 2026-06-06T18:47:28.996577+00:00
updated_at: 2026-07-03T06:16:15.042995+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.model_name"
  signature: "model_name = f'{project_id.split("_")[0]}_{revision}'"
  location: {'line_start': 52, 'line_end': 52, 'col_start': 8, 'col_end': 61}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "6a3447c9895fa1174e7f8b53d8f1563a41e95b73f26d1b3731ba2c7092cb775f"
  description: "Constructs the model name by combining the prefix portion of the project ID (the substring before the first underscore) with the revision identifier, separated by an underscore."
---
# mps.api.image_manager.ImageManager.model_name

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.model_name


variable mps.api.image_manager.ImageManager.model_name in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:52-52 :: model_name = f'{project_id.split("_")[0]}_{revision}'

Description: Constructs the model name by combining the prefix portion of the project ID (the substring before the first underscore) with the revision identifier, separated by an underscore.

## Related Documents

- [mps.api.utils.construct_model_id](201d6d5a-d07b-5776-abf2-3043105af3e5.md) - Related (graph distance 1.61)
