---
id: 21e6face-0081-5442-b611-fbecb7c4adc7
type: catalog
title: "mps.api.utils.MPSSession.base_url"
created_at: 2026-06-06T18:47:29.299143+00:00
updated_at: 2026-07-03T06:16:15.042351+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.MPSSession.base_url"
  signature: "self.base_url = base_url"
  location: {'line_start': 17, 'line_end': 17, 'col_start': 8, 'col_end': 32}
  parent_qualified_name: "mps.api.utils.MPSSession"
  sha_at_sync: "474a2b0e4e83298af9cc23aa7e75d6d2f583ef2cf0e2738fa90266fd58ea05a0"
  description: "Stores the base URL for the MPS API session, used as the prefix for constructing request endpoints."
---
# mps.api.utils.MPSSession.base_url

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession.base_url


variable mps.api.utils.MPSSession.base_url in mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:17-17 :: self.base_url = base_url

Description: Stores the base URL for the MPS API session, used as the prefix for constructing request endpoints.

## Related Documents

- [mps.api.token_manager.AWSTokenManager.base_url](12f4babf-5ed5-53e8-8546-6ccbc741379b.md) - Related (graph distance 1.37)
- [mps.api.token_manager.TokenManager.base_url](18254814-cbc1-548b-9217-db5dfc57bc3d.md) - Related (graph distance 1.37)
- [mps.api.utils.MPSSession.__init__](e5d5dc79-6074-5bee-b16a-413f978e8f4a.md) - Related (graph distance 1.48)
