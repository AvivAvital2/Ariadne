---
id: b3389511-3834-54f5-836a-78c4848305dc
type: catalog
title: "mps.api.logger.Logger"
created_at: 2026-06-06T18:47:28.691114+00:00
updated_at: 2026-07-03T06:16:15.134034+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "class"
  qualified_name: "mps.api.logger.Logger"
  signature: "class Logger:"
  location: {'line_start': 24, 'line_end': 48, 'col_start': 0, 'col_end': 29}
  parent_qualified_name: None
  sha_at_sync: "4ab952c30d42c56f37b907418883ba09f01b19aaec31163cf0c48767eda20f68"
  description: "Provides a logging interface for the MPS API, encapsulating methods to record and manage log messages."
---
# mps.api.logger.Logger

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

class mps.api.logger.Logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:24-48 :: class Logger:

Description: Provides a logging interface for the MPS API, encapsulating methods to record and manage log messages.

## Related Documents

- [mps.api.logger.CustomLogger](17135ee0-4e31-5148-b47d-38c3ec5f0a95.md) - Related (graph distance 1.42)
- [mps.api.errors.ExceptionHandler.self.Logger](e44a3143-66f2-530f-b85e-34ddd1b4545f.md) - Related (graph distance 1.53)
- [mps.api.logger.logger](903b3696-6e75-5071-9f19-6d10a5038da1.md) - Related (graph distance 1.63)
- [mps.api.logger.Logger._logger](3b7e98d7-bfd2-5dcc-a8af-1078b647c414.md) - Related (graph distance 2.96)
