---
id: eb1a3ee7-1216-5c51-b8ba-a6c9df5c69b2
type: gotcha
title: "Maintenance Gotchas"
created_at: 2026-06-06T19:04:28.331872+00:00
updated_at: 2026-06-20T22:55:22.005008+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  module_name: "mps.routers.maintenance"
  language: "python"
  source_name: "mps"
---
# Maintenance Gotchas

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# Maintenance Gotchas


# Gotchas and Pitfalls: `mps.routers.maintenance`

### Routes silently disappear based on environment variable
**Trigger:** The entire route registration is wrapped in an `if troubleshoot and troubleshoot.lower() == 'true':` block evaluated at **import time**. If `MAINTENANCE_MODE` is unset, mistyped, or `'TRUE '` (with whitespace), the routes never register and clients receive a confusing 404 instead of a clear "disabled" message.
**Affected Files:** `mps/routers/maintenance.py`
**Fix:** Strip and normalize the env var, and consider always registering routes but returning 403 when disabled, so the behavior is explicit and testable.
**Category:** framework
**Example:**
```python
troubleshoot = os.environ.get('MAINTENANCE_MODE')
# 'true\n', ' true', 'True ' all silently fail this check
if troubleshoot and troubleshoot.strip().lower() == 'true':
    ...
# Better: handle whitespace and document why routes are missing
```

---

### Import-time evaluation of `mps.registry_provider`
**Trigger:** `mps.registry_provider` is interpolated into f-strings (`summary=...`) at **module import time**, not request time. If the registry provider isn't configured yet when this module is imported, you get a wrong/empty value baked into the OpenAPI docs permanently — or an `AttributeError` crashing app startup.
**Affected Files:** `mps/routers/maintenance.py`, `mps/service/mps.py`
**Fix:** Ensure `mps.registry_provider` is initialized before this module imports, or build summaries lazily. Avoid coupling docstring generation to runtime state.
**Category:** framework
**Example:**
```python
summary=f'... available on the {mps.registry_provider} container registry'
# If mps isn't fully initialized at import, this raises or embeds stale data
```

---

### `response_model` mismatch with `PlainTextResponse`/`JSONResponse`
**Trigger:** `get_total_images_size` declares `response_model=str` but returns a `PlainTextResponse`. When you return a `Response` object directly, FastAPI **bypasses** `response_model` validation and serialization entirely. The declared model is effectively a lie in the docs.
**Affected Files:** `mps/routers/maintenance.py`
**Fix:** Either return the raw value and let FastAPI serialize it via `response_model`, or set `response_class=PlainTextResponse` instead of `response_model`.
**Category:** framework
**Example:**
```python
# Misleading: response_model=str is ignored because a Response is returned
return PlainTextResponse(format_size(...))
# Cleaner:
@router.get(..., response_class=PlainTextResponse)
async def get_total_images_size() -> str:
    return format_size(await mps.image_manager.get_size_of_images())
```

---

### `format_size` chokes on `None` or non-int sizes
**Trigger:** If `get_size_of_images()` returns `None` (e.g., no images, error path) or a float/Decimal, `humanfriendly.format_size` may raise or produce unexpected output. The result is silently passed without validation.
**Affected Files:** `mps/routers/maintenance.py`, `mps/service` image manager
**Fix:** Guard against `None` and coerce to `int`/`float` before formatting.
**Category:** type-system
**Example:**
```python
size = await mps.image_manager.get_size_of_images()
return PlainTextResponse(format_size(size or 0))
```

---

### DELETE endpoint has no confirmation and returns deletion result as 200
**Trigger:** `delete_local_images` deletes everything with no filter, parameters, or dry-run. A single accidental request wipes all local images. `response_model=list[str]` suggests it returns the deleted names, but there's no idempotency or safety check.
**Affected Files:** `mps/routers/maintenance.py`, image manager
**Fix:** Require an explicit confirmation flag/query param, support selective deletion, and log the operation at WARNING level.
**Category:** domain
**Example:**
```python
@router.delete(".../local_images")
async def delete_local_images(confirm: bool = False):
    if not confirm:
        return JSONResponse(status_code=400, content={"error": "set confirm=true"})
```

---

### `remote_images` has no `response_model` — undocumented contract
**Trigger:** Unlike its siblings, `remote_images` omits `response_model`. The OpenAPI schema for this endpoint is untyped (`{}`), and any internal shape change in `list_pushed_images()` silently changes the API response with no validation.
**Affected Files:** `mps/routers/maintenance.py`
**Fix:** Add an explicit `response_model` so the response is validated and documented.
**Category:** framework
**Example:**
```python
@router.get(..., response_model=list[str])  # add this
async def remote_images():
    return await mps.image_manager.list_pushed_images()
```

---

### No error handling around shared `image_manager` I/O
**Trigger:** All four endpoints `await` `mps.image_manager.*` directly. Any filesystem error, registry timeout, or exception bubbles up as an unhandled 500. For a *maintenance* tool, callers get no actionable detail.
**Affected Files:** `mps/routers/maintenance.py`, image manager
**Fix:** Wrap calls in try/except, log, and return structured error responses with appropriate status codes.
**Category:** async
**Example:**
```python
try:
    return await mps.image_manager.list_local_images()
except Exception as e:
    logger.exception("list_local_images failed")
    return JSONResponse(status_code=500, content={"error": str(e)})
```

---

### Concurrent maintenance operations are not serialized
**Trigger:** Maintenance endpoints (delete vs. list vs. size) can run concurrently against the same local image storage. A `delete_local_images` racing with `get_total_images_size` or `list_images` can produce inconsistent results or errors mid-deletion (e.g., size of files being removed).
**Affected Files:** `mps/routers/maintenance.py`, image manager
**Fix:** Use an `asyncio.Lock` in `image_manager` around mutating operations, or document that maintenance must be run single-flight.
**Category:** thread-safety
**Example:**
```python
# Request A: GET total_image_size walks the dir
# Request B: DELETE local_images removes files mid-walk -> FileNotFoundError / stale total
```

---

### `logger.debug` for an operationally important state change
**Trigger:** The fact that maintenance routes are enabled is logged at `debug` level. In production where the level is typically INFO/WARNING, operators get **no record** that destructive maintenance endpoints are live.
**Affected Files:** `mps/routers/maintenance.py`
**Fix:** Log enabling of destructive endpoints at `warning` or `info` level.
**Category:** domain
**Example:**
```python
logger.warning("MAINTENANCE_MODE enabled: destructive endpoints exposed at /modelpromotion/maintenance/*")
```

---

### Module-level side effects make testing/mocking hard
**Trigger:** Route registration depends on env var + `mps` singleton state at import time. Tests cannot toggle `MAINTENANCE_MODE` after import, and `mps` must already be importable/initialized just to import this module.
**Affected Files:** `mps/routers/maintenance.py`
**Fix:** Move route setup into a `def register_maintenance_routes(app, settings)` function called explicitly during app startup, decoupling from import-time globals.
**Category:** framework
**Example:**
```python
# Hard to test:
import maintenance  # routes already decided based on env at this instant
# Better:
def register_maintenance_routes(router, enabled: bool): ...
```