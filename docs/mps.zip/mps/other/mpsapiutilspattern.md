---
id: c9355d1e-4a4c-586b-97f5-58ea8200f6e9
type: catalog
title: "mps.api.utils.pattern"
created_at: 2026-06-06T18:47:29.301592+00:00
updated_at: 2026-06-20T22:55:21.579489+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.pattern"
  signature: "pattern = r'\d\.\d{1,2}\.\d'"
  location: {'line_start': 74, 'line_end': 74, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "None"
  sha_at_sync: "9ea1c4b894147881bd102eda170466d2c46d8a2bf5d2eb8ed3a1d4d6ac6b02b5"
  description: "A module-level regular expression pattern string that matches version-like number sequences in the format of a single digit, followed by one or two digits, followed by another single digit (e.g., "1.23.4"), separated by dots."
---
# mps.api.utils.pattern

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.pattern


variable mps.api.utils.pattern [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:74-74 :: pattern = r'\d\.\d{1,2}\.\d'

Description: A module-level regular expression pattern string that matches version-like number sequences in the format of a single digit, followed by one or two digits, followed by another single digit (e.g., "1.23.4"), separated by dots.