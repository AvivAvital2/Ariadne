---
id: b86d8e6e-ca91-51dd-beef-b69e972bde6d
type: catalog
title: "mps.api.image_manager.ImageManager.push_results"
created_at: 2026-06-06T18:47:29.002672+00:00
updated_at: 2026-07-03T06:16:14.986500+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager.push_results"
  signature: "push_results = await asyncio.gather("
  location: {'line_start': 277, 'line_end': 282, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "f77d4b5e8723df4f0057bea7bb81544aa42c10c0a0c22c300ed373218cf5f96e"
  description: "Stores the results of concurrently awaited image push operations, gathered via `asyncio.gather` to execute multiple pushes in parallel."
---
# mps.api.image_manager.ImageManager.push_results

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager.push_results


variable mps.api.image_manager.ImageManager.push_results in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:277-282 :: push_results = await asyncio.gather(

Description: Stores the results of concurrently awaited image push operations, gathered via `asyncio.gather` to execute multiple pushes in parallel.

## Related Documents

- [mps.api.image_manager.ImageManager.push_image](20733469-cfa8-5f10-82dd-763f83500ffd.md) - Related (graph distance 1.62)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 1.63)
- [mps.api.image_manager.ImageManager.cache_image](7c5b8505-4032-52d1-8fe2-04ce6141f4e0.md) - Related (graph distance 2.93)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 2.96)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 3.02)
- [mps.api.image_manager.ImageManager.build_and_push](293799eb-b745-5578-9c72-96562a54239f.md) - Related (graph distance 3.03)
- [mps.routers.maintenance.remote_images](9cd933a2-32f1-5a4d-87ee-cd05d12fa057.md) - Related (graph distance 3.08)
- [mps.routers.maintenance.list_images](dba494fa-4ba4-5080-8dd6-afee381e737c.md) - Related (graph distance 3.09)
- [mps.api.image_manager.ImageManager.get_exported_image_list](70dae0c7-4d5f-5c6a-98bb-1b86d0bb851a.md) - Related (graph distance 3.13)
- [mps.api.image_manager.ImageManager.remove_from_cache](6dcb2bb0-26cc-5404-95fc-267d0c626297.md) - Related (graph distance 3.14)
