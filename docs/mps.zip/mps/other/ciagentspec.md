---
id: ef096854-8deb-55b3-ad30-9e36ce90c094
type: catalog
title: ".ci.agent.spec"
created_at: 2026-06-06T18:47:26.696520+00:00
updated_at: 2026-06-20T22:55:25.814883+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/agent.yaml
metadata:
  kind: "element"
  source_name: "mps"
  language: "yaml"
  subtype: "yaml_key"
  qualified_name: ".ci.agent.spec"
  signature: "spec:"
  location: {'line_start': 6, 'line_end': 86, 'col_start': 0, 'col_end': 0}
  parent_qualified_name: ".ci.agent"
  sha_at_sync: "8351536499552749feba243a2dbd8d5d8227e7abf9cf5572ed68134f6fa0fe08"
  description: "Defines the Kubernetes pod specification for the CI agent, including container images, resource requests/limits, volumes, and runtime configuration."
---
# .ci.agent.spec

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/agent.yaml`

# .ci.agent.spec


yaml_key .ci.agent.spec in .ci.agent [yaml] /Users/spark/git/service-model-promotion/.ci/agent.yaml:6-86 :: spec:

Description: Defines the Kubernetes pod specification for the CI agent, including container images, resource requests/limits, volumes, and runtime configuration.