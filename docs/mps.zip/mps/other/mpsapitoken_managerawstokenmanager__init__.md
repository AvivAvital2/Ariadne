---
id: 57f392dc-511c-5b35-a6a9-d2ca1b3fb86e
type: catalog
title: "mps.api.token_manager.AWSTokenManager.__init__"
created_at: 2026-06-06T18:47:28.314567+00:00
updated_at: 2026-07-03T06:16:15.036679+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.token_manager.AWSTokenManager.__init__"
  signature: "def __init__(self, registry: str, region_name: str, username: str, password: str):"
  location: {'line_start': 121, 'line_end': 130, 'col_start': 4, 'col_end': 36}
  parent_qualified_name: "mps.api.token_manager.AWSTokenManager"
  sha_at_sync: "5d1d207dd32074f26a0b323e932b50c6e29baabaf48c3a2945bf33abd5294e08"
  description: "Initializes an AWSTokenManager instance with the registry URL, AWS region name, and credentials (username and password) used to authenticate and obtain access tokens."
---
# mps.api.token_manager.AWSTokenManager.__init__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# mps.api.token_manager.AWSTokenManager.__init__


method mps.api.token_manager.AWSTokenManager.__init__ in mps.api.token_manager.AWSTokenManager [python] /Users/spark/git/service-model-promotion/mps/api/token_manager.py:121-130 :: def __init__(self, registry: str, region_name: str, username: str, password: str):

Description: Initializes an AWSTokenManager instance with the registry URL, AWS region name, and credentials (username and password) used to authenticate and obtain access tokens.

## Related Documents

- [mps.api.image_manager.ImageManager.__init__](7e00188c-702a-5ba7-9735-0fb573b0793a.md) - Related (graph distance 1.61)
- [mps.api.token_manager.TokenManager.get_credentials](3b7721ce-8d66-5371-9a43-b9f4c5d3f45a.md) - Related (graph distance 1.63)
- [mps.api.token_manager.AWSTokenManager.self.registry_id](c88ae587-0a3b-5268-b34c-e7a41432ddda.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.token_manager](296ad955-0893-5bc1-9d28-b03b718b3cb1.md) - Related (graph distance 3.05)
- [mps.api.token_manager.TokenManager.registry](f40d394c-e24c-58db-86c6-d327648cb3f9.md) - Related (graph distance 3.07)
- [mps.service.MPS.self.aws_registry_region](dd85db50-7c3d-5649-b194-c5c4a804805f.md) - Related (graph distance 3.14)
- [mps.api.token_manager.TokenManager.stored_credentials](6118c04d-ef3d-537e-a04b-20a6f6cf3f21.md) - Related (graph distance 3.18)
- [mps.api.token_manager.TokenManager.__init__](eab46ef5-e7e4-5266-a8b5-59055da14ef2.md) - Related (graph distance 3.21)
- [mps.service.MPS.self.registry_password](f9491758-501b-5aef-a28b-c8d7d0789dbd.md) - Related (graph distance 3.24)
- [mps.service.MPS.self.registry_user](c056401c-c3a2-5425-9bc3-ad5d2fbb0573.md) - Related (graph distance 3.24)
