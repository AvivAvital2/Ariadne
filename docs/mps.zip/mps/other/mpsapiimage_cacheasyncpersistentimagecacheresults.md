---
id: 34a6adec-7571-5b19-a7f7-6c2158915e2f
type: catalog
title: "mps.api.image_cache.AsyncPersistentImageCache.results"
created_at: 2026-06-06T18:47:29.722681+00:00
updated_at: 2026-07-03T06:16:15.090486+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_cache.AsyncPersistentImageCache.results"
  signature: "results = await cursor.fetchall()"
  location: {'line_start': 39, 'line_end': 39, 'col_start': 12, 'col_end': 45}
  parent_qualified_name: "mps.api.image_cache.AsyncPersistentImageCache"
  sha_at_sync: "e733694a163b6a2f7931dcc13a3b566212adb4adb1b757dc9185ca71566f5e01"
  description: "Retrieves all rows from the executed query as a list, used to populate the cache with previously stored image data from the database."
---
# mps.api.image_cache.AsyncPersistentImageCache.results

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# mps.api.image_cache.AsyncPersistentImageCache.results


variable mps.api.image_cache.AsyncPersistentImageCache.results in mps.api.image_cache.AsyncPersistentImageCache [python] /Users/spark/git/service-model-promotion/mps/api/image_cache.py:39-39 :: results = await cursor.fetchall()

Description: Retrieves all rows from the executed query as a list, used to populate the cache with previously stored image data from the database.

## Related Documents

- [mps.api.image_cache.AsyncPersistentImageCache.result](0682dcc4-e9d8-5858-8035-9f700da35ff0.md) - Related (graph distance 1.27)
- [mps.api.image_cache.AsyncPersistentImageCache.list](084aaffb-03f0-5dc4-a843-f2dd1811c343.md) - Related (graph distance 1.58)
- [mps.api.image_manager.ImageManager.list_local_images](ee95e749-afbc-5cd0-83ea-b348fb8e1e44.md) - Related (graph distance 2.94)
- [mps.api.image_manager.ImageManager.list_pushed_images](a49ecd9d-c6ad-5447-9525-862be81b8a08.md) - Related (graph distance 2.96)
- [mps.api.image_cache.AsyncPersistentImageCache.clear](1cbe7d58-5849-5877-945c-5f85350c05bf.md) - Related (graph distance 2.97)
- [mps.routers.maintenance.list_images](dba494fa-4ba4-5080-8dd6-afee381e737c.md) - Related (graph distance 3.07)
