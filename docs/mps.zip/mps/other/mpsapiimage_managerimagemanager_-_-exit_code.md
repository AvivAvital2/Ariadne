---
id: fca980a3-5095-57b3-813a-59efc6ac0fee
type: catalog
title: "mps.api.image_manager.ImageManager._, _, exit_code"
created_at: 2026-06-06T18:47:28.998406+00:00
updated_at: 2026-07-03T06:16:15.078836+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.image_manager.ImageManager._, _, exit_code"
  signature: "_, _, exit_code = await run_command(inspect_command, supress_errors=False)"
  location: {'line_start': 245, 'line_end': 245, 'col_start': 16, 'col_end': 90}
  parent_qualified_name: "mps.api.image_manager.ImageManager"
  sha_at_sync: "796654061f04f0a30ee5aee6141724c5fe927112c0fb963c5c15c5132d3b82d5"
  description: "Unpacks the result of an asynchronous image inspection command, discarding stdout and stderr while capturing the process exit code to verify the command's success."
---
# mps.api.image_manager.ImageManager._, _, exit_code

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# mps.api.image_manager.ImageManager._, _, exit_code


variable mps.api.image_manager.ImageManager._, _, exit_code in mps.api.image_manager.ImageManager [python] /Users/spark/git/service-model-promotion/mps/api/image_manager.py:245-245 :: _, _, exit_code = await run_command(inspect_command, supress_errors=False)

Description: Unpacks the result of an asynchronous image inspection command, discarding stdout and stderr while capturing the process exit code to verify the command's success.

## Related Documents

- [mps.api.image_manager.ImageManager._, _, _](01d87474-b7b8-53ea-8101-ad4ccaa679ef.md) - Related (graph distance 1.36)
- [mps.api.image_manager.ImageManager.stdout, stderr, exit_code](68855062-54d5-5042-8c51-8a71a564fbfc.md) - Related (graph distance 1.40)
- [mps.api.image_manager.ImageManager.images, _, _](12b67c71-8fd6-54fb-9cd4-a449099882fd.md) - Related (graph distance 1.46)
- [mps.api.image_manager.ImageManager.output, _, _](c3594af9-f163-5c08-a19d-854a4ea37cd0.md) - Related (graph distance 1.60)
- [mps.api.image_manager.ImageManager.stdout_size, _, _](a9dd01b7-2426-5031-ac95-c881ede6158d.md) - Related (graph distance 1.62)
- [mps.api.utils.run_command](adae925f-b6d7-509d-9307-ee57f91a2e44.md) - Related (graph distance 1.66)
- [mps.api.image_manager.ImageManager.dangling_images, _, _](946455d5-78c7-5c4c-8634-7b4b10106fe5.md) - Related (graph distance 2.84)
- [mps.api.utils.stdout, stderr](c763f4e0-50eb-503d-abbf-927541162a1b.md) - Related (graph distance 2.96)
