---
id: 4f64e29b-e019-5667-82f8-f35141907558
type: catalog
title: "mps.api.utils.MPSSession.auth"
created_at: 2026-06-06T18:47:29.299421+00:00
updated_at: 2026-06-20T22:55:23.888794+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.utils.MPSSession.auth"
  signature: "self.auth = auth"
  location: {'line_start': 18, 'line_end': 18, 'col_start': 8, 'col_end': 24}
  parent_qualified_name: "mps.api.utils.MPSSession"
  sha_at_sync: "548ace9aa36c393c4f2877dcb88bc7df8e542462b936a90ed42da4cd3baae2f5"
  description: "Stores the authentication credentials (e.g., token or auth handler) for the `MPSSession` instance, used to authenticate API requests."
---
# mps.api.utils.MPSSession.auth

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# mps.api.utils.MPSSession.auth


variable mps.api.utils.MPSSession.auth in mps.api.utils.MPSSession [python] /Users/spark/git/service-model-promotion/mps/api/utils.py:18-18 :: self.auth = auth

Description: Stores the authentication credentials (e.g., token or auth handler) for the `MPSSession` instance, used to authenticate API requests.