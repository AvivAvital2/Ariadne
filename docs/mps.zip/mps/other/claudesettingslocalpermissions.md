---
id: 6434ec44-3fe6-525f-97ca-e0ce7f49d7f2
type: catalog
title: ".claude.settings.local.permissions"
created_at: 2026-06-06T18:47:26.789074+00:00
updated_at: 2026-06-20T22:55:25.433396+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.claude/settings.local.json
metadata:
  kind: "element"
  source_name: "mps"
  language: "json"
  subtype: "json_key"
  qualified_name: ".claude.settings.local.permissions"
  signature: "permissions": {"
  location: {'line_start': 2, 'line_end': 7, 'col_start': 2, 'col_end': 3}
  parent_qualified_name: ".claude.settings.local"
  sha_at_sync: "79fd07ca6c92a2e5d1d5d52d3deda55c953476a1b83915fad75af4a49849251e"
  description: "Defines the permission configuration for Claude's local settings, controlling which actions or operations Claude is allowed or denied within the project."
---
# .claude.settings.local.permissions

**Related files:**
- `/Users/spark/git/service-model-promotion/.claude/settings.local.json`

# .claude.settings.local.permissions


json_key .claude.settings.local.permissions in .claude.settings.local [json] /Users/spark/git/service-model-promotion/.claude/settings.local.json:2-7 :: "permissions": {

Description: Defines the permission configuration for Claude's local settings, controlling which actions or operations Claude is allowed or denied within the project.