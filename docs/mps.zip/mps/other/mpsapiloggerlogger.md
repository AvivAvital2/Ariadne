---
id: 903b3696-6e75-5071-9f19-6d10a5038da1
type: catalog
title: "mps.api.logger.logger"
created_at: 2026-06-06T18:47:28.694572+00:00
updated_at: 2026-07-03T06:16:15.071894+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.api.logger.logger"
  signature: "logger = Logger('model_promotion', log_level=level).logger"
  location: {'line_start': 54, 'line_end': 54, 'col_start': 8, 'col_end': 66}
  parent_qualified_name: "None"
  sha_at_sync: "288f34e17df54051fa6189add812530252b9b3d89a560fec8acfd6a5e32131ad"
  description: "Module-level logger instance for the model promotion service, configured with the name 'model_promotion' and a log level determined by the `level` variable."
---
# mps.api.logger.logger

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# mps.api.logger.logger


variable mps.api.logger.logger [python] /Users/spark/git/service-model-promotion/mps/api/logger.py:54-54 :: logger = Logger('model_promotion', log_level=level).logger

Description: Module-level logger instance for the model promotion service, configured with the name 'model_promotion' and a log level determined by the `level` variable.

## Related Documents

- [mps.api.errors.ExceptionHandler.self.Logger](e44a3143-66f2-530f-b85e-34ddd1b4545f.md) - Related (graph distance 1.45)
- [mps.api.logger.level](5982b4fa-33a1-5ec9-9742-878c5acc43cd.md) - Related (graph distance 1.56)
- [mps.api.logger.Logger](b3389511-3834-54f5-836a-78c4848305dc.md) - Related (graph distance 1.63)
- [mps.api.logger.Logger._logger](3b7e98d7-bfd2-5dcc-a8af-1078b647c414.md) - Related (graph distance 1.64)
