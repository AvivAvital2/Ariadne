---
id: 9fb04024-1a86-548a-ad1a-d71b488cd891
type: catalog
title: "mps.routers.promote.annotations_list"
created_at: 2026-06-06T18:47:27.628313+00:00
updated_at: 2026-07-03T06:16:15.121436+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "variable"
  qualified_name: "mps.routers.promote.annotations_list"
  signature: "annotations_list = None \"
  location: {'line_start': 74, 'line_end': 76, 'col_start': 4, 'col_end': 76}
  parent_qualified_name: "None"
  sha_at_sync: "49a0dbcb78508d47e08c2b3ea190b79cb967bbe9fb739c2b5d1181fa13196fef"
  description: "Module-level variable in the promote router, initialized to `None`, intended to hold a list of annotations."
---
# mps.routers.promote.annotations_list

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# mps.routers.promote.annotations_list


variable mps.routers.promote.annotations_list [python] /Users/spark/git/service-model-promotion/mps/routers/promote.py:74-76 :: annotations_list = None \

Description: Module-level variable in the promote router, initialized to `None`, intended to hold a list of annotations.

## Related Documents

- [mps.routers.promote.annotations_string](308debdb-7c0b-525f-bd1f-94f84cd280e5.md) - Related (graph distance 1.51)
- [mps.routers.promote.algorithm_string](b6417c2f-d7af-5ccf-8a65-d93929bed909.md) - Related (graph distance 2.92)
- [mps.routers.promote.auxiliary_image_string](d5288d92-39d5-5b40-993d-21eea4d39f9a.md) - Related (graph distance 2.93)
