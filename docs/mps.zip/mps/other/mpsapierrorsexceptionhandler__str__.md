---
id: 98eb7392-e75e-559e-9e37-cba956652a02
type: catalog
title: "mps.api.errors.ExceptionHandler.__str__"
created_at: 2026-06-06T18:47:29.758378+00:00
updated_at: 2026-07-03T06:16:15.029233+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  kind: "element"
  source_name: "mps"
  language: "python"
  subtype: "method"
  qualified_name: "mps.api.errors.ExceptionHandler.__str__"
  signature: "def __str__(self):  # pragma: no cover"
  location: {'line_start': 16, 'line_end': 17, 'col_start': 4, 'col_end': 27}
  parent_qualified_name: "mps.api.errors.ExceptionHandler"
  sha_at_sync: "68105f35945184783dda551c788445c7ae97cdd0736b2807dfc91b414acd65a2"
  description: "Returns the string representation of the ExceptionHandler instance."
---
# mps.api.errors.ExceptionHandler.__str__

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# mps.api.errors.ExceptionHandler.__str__


method mps.api.errors.ExceptionHandler.__str__ in mps.api.errors.ExceptionHandler [python] /Users/spark/git/service-model-promotion/mps/api/errors.py:16-17 :: def __str__(self):  # pragma: no cover

Description: Returns the string representation of the ExceptionHandler instance.

## Related Documents

- [mps.api.errors.ExceptionHandler.__repr__](354a3d34-fb7e-59f5-9c8c-7dab844609a6.md) - Related (graph distance 1.12)
- [mps.api.errors.ExceptionHandler.exception_handler](3529722b-ea7e-531f-badf-5c1480baf8aa.md) - Related (graph distance 1.49)
