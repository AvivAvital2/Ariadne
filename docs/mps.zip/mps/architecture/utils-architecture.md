---
id: d362db5f-a038-5910-a1d0-a2dfbb42d6a9
type: architecture
title: "Utils Architecture"
created_at: 2026-06-06T19:04:04.608958+00:00
updated_at: 2026-06-20T22:55:26.801608+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/utils.py
metadata:
  source_name: "mps"
---
# Utils Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/utils.py`

# Utils Architecture


# Architecture Documentation: `mps.api.utils`

## 1. Component Overview

The `mps.api.utils` module is a **shared utility layer** within the MPS (Model Provisioning Service) API. It provides cross-cutting helper functions and a customized HTTP session that support the broader application's responsibilities around:

- **Process orchestration** — running external commands (e.g., Docker CLI invocations) asynchronously.
- **Container registry interaction** — verifying connectivity to and authenticating against Docker container registries.
- **Model identity & versioning** — constructing model identifiers and validating semantic version strings.
- **Image resolution** — mapping deployment parameters to concrete base image identifiers.
- **Artifact extraction** — unpacking model archives from disk.
- **HTTP convenience** — a base-URL-aware `requests.Session` subclass.

This module sits at a low level of the dependency hierarchy: it depends only on `mps.api.errors` internally and on standard/third-party libraries externally. It is intended to be consumed by higher-level API endpoints and service-layer logic.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Async-first function signatures** | Most utility functions (`run_command`, `verify_connection_to_container_registry`, `extract_model`, etc.) are `async`. This aligns with the FastAPI runtime, allowing I/O-bound work (subprocess execution, network calls, retries with sleeps) to be performed without blocking the event loop. |
| **`MPSSession` extends `requests.Session`** | Encapsulates a `base_url` so callers issue relative URIs. Centralizes auth and TLS verification configuration for repeated calls to the same host. |
| **Domain-specific exceptions** | Errors like `SelfSignedCertificate`, `UnreachableContainerRegistry`, and `NoConfigurationFoundError` are raised from `mps.api.errors`, giving callers semantically meaningful failure modes rather than generic exceptions. |
| **`HTTPException` raised directly in `construct_model_id`** | Indicates this function is meant to be called from within the FastAPI request lifecycle, where the framework translates the exception into an HTTP 400 response. |
| **Retry-with-backoff in registry verification** | Container registries may be slow to come online (e.g., during startup orchestration). A bounded retry loop (30 attempts × 10s) provides resilience without infinite blocking. |
| **HTTP/HTTPS fallback negotiation** | The verification logic attempts HTTPS first, then gracefully degrades to HTTP if the registry responds on the plaintext port, returning the resolved schema-qualified URL for downstream use. |
| **Configuration-driven base image resolution** | `resolve_base_image_id` uses a flavour matrix to map feature flags to image variants, decoupling deployment configuration from code. |

---

## 3. Component Diagram

```mermaid
graph TD
    subgraph "mps.api.utils"
        Session["MPSSession<br/>(requests.Session)"]
        RunCmd["run_command()"]
        StreamReader["stream_reader()<br/>(nested helper)"]
        ConstructId["construct_model_id()"]
        ParseVer["parse_version_number()"]
        ResolveImg["resolve_base_image_id()"]
        ExtractModel["extract_model()"]
        VerifyReg["verify_connection_to_container_registry()"]
        ImgToFile["docker_image_to_file_name()"]
    end

    subgraph "mps.api.errors"
        Err1["SelfSignedCertificate"]
        Err2["UnreachableContainerRegistry"]
        Err3["NoConfigurationFoundError"]
    end

    subgraph "External Libraries"
        Asyncio["asyncio"]
        Requests["requests / urllib3"]
        Zipfile["zipfile"]
        FastAPI["fastapi.HTTPException"]
        OSlib["os / re"]
    end

    RunCmd --> StreamReader
    RunCmd --> Asyncio
    ResolveImg --> ParseVer
    ResolveImg --> Err3
    VerifyReg --> Requests
    VerifyReg --> Asyncio
    VerifyReg --> Err1
    VerifyReg --> Err2
    ExtractModel --> Zipfile
    ExtractModel --> OSlib
    ConstructId --> FastAPI
    Session --> Requests
    ParseVer --> OSlib
```

---

## 4. Interfaces

### `MPSSession(base_url, auth=None, verify=True)`
A `requests.Session` subclass.
- **`base_url`**: prefix automatically prepended to all relative request URIs via `urljoin`.
- **`auth` / `verify`**: standard `requests` authentication and TLS verification toggles.
- **`request(method, uri, ...)`**: overridden to resolve `uri` against `base_url`.

### `async run_command(command: str | list, supress_errors=False) -> tuple[list, list, int | None]`
Executes a subprocess asynchronously.
- Accepts a command string (split on spaces) or pre-tokenized list.
- Returns `(stdout_lines, stderr_lines, exit_code)`.
- Raises `RuntimeError` on non-zero exit unless `supress_errors=True`.

### `async construct_model_id(project_id: str, revision: str) -> str`
Returns `"{project_id}:{revision}"`. Raises `HTTPException(400)` on failure.

### `async parse_version_number(version_string: str, as_config_key=False)`
Validates `<major>.<minor>.<patch>` format.
- Returns a `tuple[int, int, int]` by default.
- Returns a hyphen-joined config key string (e.g., `"1-2-3"`) when `as_config_key=True`.
- Raises a generic `Exception` on malformed input.

### `async resolve_base_image_id(base_images, release_version, use_linked_data_core, use_open_street_map, use_docker_compose) -> str`
Resolves a base image identifier from a configuration dictionary using a feature-flag flavour matrix. Raises `NoConfigurationFoundError` if no match exists.

### `async extract_model(zip_file_path: str, destination: str)`
Extracts a model archive to `destination`, deletes the source zip, then attempts a secondary extraction of a nested `model.ser`.

### `async verify_connection_to_container_registry(schema, registry, auth, verify, provider) -> str`
Verifies registry reachability via the `/v2/` endpoint with retry/backoff. Returns the resolved schema-qualified registry URL (`https://...` or `http://...`). Raises `SelfSignedCertificate` or `UnreachableContainerRegistry` on terminal failures.

### `docker_image_to_file_name(tag: str) -> str`
Synchronous helper. Strips the registry/repository prefix and converts the `image:tag` portion into a filesystem-safe `image_tag` name.

---

## 5. Data Flow

### Command Execution Flow
```mermaid
sequenceDiagram
    participant Caller
    participant run_command
    participant stream_reader
    participant Subprocess

    Caller->>run_command: command (str | list)
    run_command->>Subprocess: create_subprocess_exec
    par concurrent reads
        run_command->>stream_reader: read stdout
        run_command->>stream_reader: read stderr
    end
    Subprocess-->>stream_reader: stream lines
    stream_reader-->>run_command: collected output
    run_command->>Subprocess: wait() -> exit_code
    alt exit_code != 0 and not supress_errors
        run_command-->>Caller: raise RuntimeError
    else
        run_command-->>Caller: (stdout, stderr, exit_code)
    end
```

### Registry Verification Flow
```mermaid
flowchart TD
    Start([verify_connection_to_container_registry]) --> Try["GET {schema}://{registry}/v2/"]
    Try -->|Success| ReturnHTTPS["return https://registry"]
    Try -->|SSLError| CheckSelfSigned{Self-signed<br/>+ local + verify?}
    CheckSelfSigned -->|Yes| RaiseSSL[raise SelfSignedCertificate]
    CheckSelfSigned -->|No| TryHTTP["GET http://registry/v2/"]
    TryHTTP -->|200 OK| ReturnHTTP["return http://registry"]
    TryHTTP -->|Other| Sleep1[sleep & retry]
    Try -->|ConnectionError| Sleep2[sleep & retry]
    Sleep1 --> Try
    Sleep2 --> Try
    Try -.->|30 attempts exhausted| RaiseUnreachable[raise UnreachableContainerRegistry]
```

### Image Resolution Flow
1. `release_version` is normalized into a config key via `parse_version_number`.
2. Feature flags (`use_linked_data_core`, `use_open_street_map`, `use_docker_compose`) select a **flavour** (`aio` / `osm` / `gdata` / `minimal`).
3. The `base_images` config dict is queried with `[release_key][flavour]`.
4. Either the resolved image ID is returned or `NoConfigurationFoundError` is raised.

---

## 6. Extension Points

| Extension Point | How to Customize |
|-----------------|------------------|
| **HTTP session behavior** | Subclass `MPSSession` to inject custom headers, retry adapters, or default timeouts while preserving base-URL resolution. |
| **Image flavour matrix** | The `flavours` mapping in `resolve_base_image_id` defines the supported combinations. Add or modify entries to support new build flavours. The `base_images` dictionary is supplied by the caller, decoupling configuration from code. |
| **Command execution** | `run_command` accepts arbitrary commands, making it a generic shell adapter. Wrap it in domain-specific helpers (e.g., a `docker_build` function) rather than modifying it. |
| **Registry retry policy** | The `attempts` and `sleep_time` constants in `verify_connection_to_container_registry` control resilience behavior. These are good candidates for promotion to configurable parameters or environment variables. |
| **Version format** | The regex `\d\.\d{1,2}\.\d` in `parse_version_number` defines the accepted semantic version shape. Adjust here if versioning conventions change. |
| **Archive handling** | `extract_model` assumes a primary zip plus an optional nested `model.ser`. Additional archive layouts can be supported by extending the extraction sequence. |

---

## Notes & Observations

- **Error handling inconsistency**: `parse_version_number` raises a bare `Exception` rather than a domain-specific error from `mps.api.errors`. Aligning it with the established error hierarchy would improve consistency for callers.
- **Logging artifact**: The `resolve_base_image_id` log message contains an unresolved template literal (`$baseImageId`), likely a porting artifact. This is cosmetic but should be corrected for accurate log output.
- **TLS warning suppression**: `verify_connection_to_container_registry` globally disables `InsecureRequestWarning`. This is intentional for self-signed registry support but applies process-wide as a side effect.