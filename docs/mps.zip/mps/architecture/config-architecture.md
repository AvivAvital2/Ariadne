---
id: 1160f6dc-b870-5e5d-a62e-071aaef2acd6
type: architecture
title: "Config Architecture"
created_at: 2026-06-06T19:03:20.299397+00:00
updated_at: 2026-06-20T22:55:26.786005+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/config.py
metadata:
  source_name: "mps"
---
# Config Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/config.py`

# Config Architecture


# Architecture Documentation: `mps.api.config`

## 1. Component Overview

The `mps.api.config` module serves as the **centralized configuration loader and validator** for the MPS API. It is responsible for:

- **Validating** the presence and integrity of required configuration files at import time.
- **Loading** configuration data from two sources:
  - A JSON defaults file (`conf/defaults.json`)
  - A TOML environment/deployment file (`conf/promotion.toml`)
- **Merging** the two sources so that explicit TOML values override defaults, while missing keys fall back to defaults.
- **Exposing** commonly used configuration values as module-level constants for downstream consumers.

This module follows an **import-time initialization** pattern — configuration is loaded and validated as a side effect of importing the module, making `config` a single source of truth across the application.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Two-file configuration (JSON + TOML)** | Separates immutable application defaults (`defaults.json`, version-controlled) from deployment/environment-specific overrides (`promotion.toml`, often mounted at runtime). |
| **Fail-fast validation at import** | Configuration problems surface immediately on startup rather than as obscure runtime failures. Each file is checked for existence, regularity, non-zero size, and readability. |
| **Defensive container-aware checks** | Error messages explicitly reference mounting issues ("perhaps mounted incorrectly?"), indicating the system is designed to run in a containerized/mounted-volume environment (e.g., Kubernetes/Docker). |
| **`match`/`case` for validation** | Provides a readable, ordered chain of guard conditions for file validation, short-circuiting on the first failure. |
| **Defaults merged into config (`setdefault`)** | TOML values take precedence; absent keys inherit from JSON defaults. This guarantees all expected keys exist post-load. |
| **Custom exception types** | `NoConfigurationFileFoundError` and `InvalidConfigurationFile` (from `mps.api.errors`) distinguish *missing* from *malformed* configuration, aiding operational diagnostics. |

---

## 3. Component Diagram

```mermaid
flowchart TD
    subgraph Filesystem["Mounted Configuration (conf/)"]
        DEFAULTS["defaults.json<br/>(application defaults)"]
        PROMO["promotion.toml<br/>(deployment overrides)"]
    end

    subgraph ConfigModule["mps.api.config"]
        VALIDATE["File Validation<br/>(exists / is_file / size / readable)"]
        LOADJSON["json.load → defaults"]
        LOADTOML["tomllib.load → config"]
        MERGE["Merge defaults into config<br/>(setdefault)"]
        EXPORTS["Module Constants:<br/>base_images<br/>image_cache_path<br/>repo_prefix<br/>exported_image_path<br/>config"]
    end

    ERRORS["mps.api.errors<br/>NoConfigurationFileFoundError<br/>InvalidConfigurationFile"]

    DEFAULTS --> VALIDATE
    PROMO --> VALIDATE
    VALIDATE -- "on failure" --> ERRORS
    VALIDATE -- "on success" --> LOADJSON
    VALIDATE -- "on success" --> LOADTOML
    LOADJSON --> MERGE
    LOADTOML --> MERGE
    MERGE --> EXPORTS

    EXPORTS --> CONSUMERS["Downstream MPS API modules"]
```

---

## 4. Interfaces

### Inputs (Files)
| Path | Format | Purpose |
|------|--------|---------|
| `conf/defaults.json` | JSON | Baseline default values, structured by section. |
| `conf/promotion.toml` | TOML | Deployment-specific configuration overriding defaults. |

Both paths are **relative to the process working directory**, expecting `conf/` to be present (typically mounted into the container).

### Outputs (Module-level Constants)
| Name | Source Key | Description |
|------|-----------|-------------|
| `config` | (full merged dict) | The complete merged configuration object. |
| `defaults` | `defaults.json` | The raw defaults dictionary. |
| `base_images` | `config['baseImage']` | Base image definitions. |
| `image_cache_path` | `config['local_image_cache']['path']` | Local image cache directory. |
| `repo_prefix` | `config['general']['repo_prefix']` | Repository prefix used for image naming. |
| `exported_image_path` | `config['exported_images']['path']` | Output path for exported images. |

### Exceptions Raised
| Exception | Condition |
|-----------|-----------|
| `NoConfigurationFileFoundError` | A required config file does not exist. |
| `InvalidConfigurationFile` | File is not regular, is empty, or is unreadable. |

### Integration Contract
Consumers integrate simply by importing:
```python
from mps.api.config import config, base_images, repo_prefix
```
> ⚠️ **Note:** Because validation/loading occurs at import time, importing this module can raise an exception. Consumers should ensure configuration files are present before import, or wrap the import for graceful startup handling.

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant Importer as Importing Module
    participant Config as mps.api.config
    participant FS as Filesystem
    participant Errors as mps.api.errors

    Importer->>Config: import
    loop For each required file
        Config->>FS: check exists / is_file / size / readable
        alt validation fails
            Config->>Errors: raise NoConfigurationFile / InvalidConfigurationFile
            Errors-->>Importer: propagate exception
        end
    end
    Config->>FS: read defaults.json
    FS-->>Config: defaults dict
    Config->>FS: read promotion.toml
    FS-->>Config: config dict
    Config->>Config: merge defaults into config (setdefault)
    Config->>Config: extract derived constants
    Config-->>Importer: module ready with exported constants
```

**Step-by-step:**
1. **Validation phase** — iterate over `file_paths`; each file is checked through an ordered guard chain. The first failing condition raises a typed error.
2. **Load phase** — `defaults.json` is parsed via `json`; `promotion.toml` is parsed via `tomllib` (binary mode, as required by `tomllib`).
3. **Merge phase** — for each section/key in `defaults`, `setdefault` injects defaults only where the TOML config lacks a value. TOML always wins on conflict.
4. **Extraction phase** — frequently used nested values are hoisted to top-level module constants for convenient access.

---

## 6. Extension Points

### Adding a New Configuration File
Append to the `file_paths` list to bring additional files under the same validation umbrella:
```python
file_paths = [
    'conf/defaults.json',
    'conf/promotion.toml',
    'conf/feature_flags.toml',  # new
]
```
> Validation applies automatically; loading/merging logic must be extended separately.

### Adding New Default Sections / Keys
Add entries to `defaults.json`. The merge loop generically applies any new section/key as a fallback — no code change required for new defaults to be honored.

### Exposing New Derived Constants
Add extraction lines after the merge block:
```python
new_setting = config['some_section']['some_key']
```

### Customizing Validation Rules
Extend the `match`/`case` block with additional `case` guards (e.g., schema validation, value-range checks) before the final `case _: continue`.

### Recommended Future Improvements
- **Decouple file paths** from hardcoded relative strings (e.g., via environment variables) to improve portability and testability.
- **Wrap initialization in a function** (e.g., `load_config()`) to avoid import-time side effects and enable controlled re-loading and unit testing.
- **Schema validation** (e.g., via `pydantic` or `jsonschema`) to validate value types and required keys beyond file-level checks.

---

*Terminology note:* This document uses the codebase's existing terms — `config` (merged result), `defaults` (JSON baseline), and the `promotion.toml` deployment file — consistently throughout.