---
id: f5681770-d3ff-50d3-9dba-63fac3ef1c88
type: architecture
title: "Dockerfile Architecture"
created_at: 2026-07-03T05:57:43.655223+00:00
updated_at: 2026-07-03T05:57:43.655237+00:00
source_files:
  - /Users/spark/git/service-model-promotion/Dockerfile
metadata:
  module_name: "builder.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/Dockerfile`

# Architecture Document: `builder.Dockerfile` — Model Promotion Service Image

## 1. Component Overview

The `builder.Dockerfile` defines the container image build for the **Model Promotion Service (MPS)**, a Python-based service responsible for promoting (packaging, exporting, and moving) model container images between environments.

The Dockerfile implements a **multi-stage build**:

1. **Builder stage** — compiles native dependencies, installs the MPS Python package via Poetry, and produces a wheel artifact.
2. **Runtime stage** — a minimal, hardened image that carries over only the resolved Python site-packages and the essential service files, plus container-tooling binaries (`buildah`, `skopeo`, `fuse-overlayfs`, etc.) required for image promotion operations.

### Key Responsibilities
- Produce a reproducible, minimal runtime image for MPS.
- Isolate build-time toolchains from the final image (smaller attack surface, smaller size).
- Provision OCI/container tooling needed to inspect, copy, and archive images.
- Configure a non-root service user, working directory structure, timezone/locale, health checking, and the service entrypoint.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Multi-stage build** | Native build dependencies (`gcc`, `musl-dev`, `libffi-dev`, `openssl-dev`, `make`) are only needed to compile Python wheels. Discarding them from the final image reduces size and CVE exposure. |
| **Alpine base (`python:3.13.x-alpine`)** | Minimal footprint. `musl`-based image keeps the runtime small; the tradeoff is native compilation cost, which the builder stage absorbs. |
| **Internal Nexus registry (`nexus.dev.sparkbeyond.ai`)** | Pull base images from a controlled/proxied registry for supply-chain governance and availability. |
| **Poetry with `virtualenvs.create false`** | Install dependencies directly into the system site-packages so they can be copied cleanly between stages without virtualenv path indirection. |
| **`poetry install --only main` + `poetry build --format wheel`** | Excludes dev dependencies; builds a distributable wheel so the app is installed as a proper package (`mps-<version>`). |
| **`pip-autoremove pip` then reinstall via `get-pip.py`** | Strips residual/old `pip` versions to avoid version-residue issues, then reinstalls a clean, current `pip` in the runtime stage. |
| **Removal of `mps/routes/` and `mps/api/` in builder** | These source directories are stripped after the wheel is built — the installed package already contains compiled/packaged code; source is not shipped. |
| **Container tooling: `buildah`, `skopeo`, `fuse-overlayfs`, `netavark`, `pigz`, `tar`** | MPS's core function is *promotion of images*; it needs rootless container tooling to copy, archive, and compress images. |
| **Non-root service user (`predict`, UID 998 / GID 1001)** | Runs the service unprivileged. The specific UID (`EPS_UID`) aligns with the EPS "predict" user to avoid `chown` conflicts when volumes/sockets are mounted. |
| **UTC timezone + `en_US.UTF-8` locale** | Deterministic, consistent behavior for logging and timestamps across environments. |
| **Version injected via `ARG VERSION` / `${VERSION//v/}`** | Parameter expansion strips a leading `v` (e.g. `v1.2.8` → `1.2.8`) to match the wheel's PEP 440 version string. |
| **`HEALTHCHECK` on `/healthcheck`** | Enables orchestrator-level liveness/readiness gating; `--start-period=60s` accommodates service warm-up. |

---

## 3. Component Diagram

```dot
digraph MPSDockerfile {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#eef4fb", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    subgraph cluster_builder {
        label="Stage 1: builder";
        style="filled";
        color="#dce8f5";

        base_b       [label="Base Image\npython:3.13-alpine\n(from Nexus)"];
        build_deps   [label=".build-deps\ngcc, musl-dev,\nlibffi-dev, openssl-dev, make"];
        sources      [label="Source Inputs\npyproject.toml, poetry.lock, mps/"];
        poetry       [label="Poetry\ninstall --only main\nbuild --format wheel"];
        wheel        [label="Artifact\ndist/mps-<version>.whl"];
        site_pkgs_b  [label="site-packages\n(resolved deps + mps)"];

        base_b -> build_deps;
        build_deps -> poetry;
        sources -> poetry;
        poetry -> wheel;
        wheel -> site_pkgs_b [label="pip install"];
    }

    subgraph cluster_runtime {
        label="Stage 2: runtime";
        style="filled";
        color="#e6f5e6";

        base_r     [label="Base Image\npython:3.13-alpine\n(from Nexus)"];
        user       [label="Service User\npredict (UID 998)\ngroup sparkbeyond (GID 1001)"];
        dirs       [label="Directory Structure\nbin/ conf/ log/ cache/\ntemplate/ utils/\nimage_archives/ exported_images/"];
        tooling    [label="Container Tooling\nbuildah, skopeo,\nfuse-overlayfs, netavark,\npigz, tar, curl, jq"];
        pip_clean  [label="Clean pip\n(get-pip.py)"];
        app        [label="MPS Application\nbin/__main__.py\nconf/*.toml, defaults.json"];
        entry      [label="Entrypoint\npython __main__.py\nEXPOSE 8010"];
        health     [label="HEALTHCHECK\nGET /healthcheck"];

        base_r -> user;
        user -> dirs;
        dirs -> tooling;
        tooling -> pip_clean;
        pip_clean -> app;
        app -> entry;
        entry -> health;
    }

    site_pkgs_b -> app [label="COPY --from=builder\nsite-packages + bin", style=dashed, color="#2a6099"];
    poetry      -> app [label="COPY --from=builder\n__main__.py, conf, template", style=dashed, color="#2a6099"];
}
```

---

## 4. Interfaces

### Build-Time Interface (Build Arguments)
| Argument | Default | Purpose |
|----------|---------|---------|
| `BASE_IMAGE` | `python:3.13.12-alpine3.23` | Overridable base image reference (pulled from Nexus). |
| `VERSION` | *(required)* | Version tag; used to build/install the MPS wheel. Leading `v` is stripped. |

### Runtime Interface
| Interface | Detail |
|-----------|--------|
| **Network** | Exposes **TCP 8010** (HTTP service). |
| **Health endpoint** | `GET http://localhost:8010/healthcheck` — expected HTTP `200`. Polled every 10s after a 60s start period, 5 retries. |
| **Entrypoint** | `sh -c "python ${SERVICE_HOME}/bin/__main__.py"` — the MPS application entry module. |
| **CLI utility** | `load_images` — symlink to `${SERVICE_HOME}/utils/load_images.sh`, available on `PATH` for loading image archives. |

### Filesystem Interface (`SERVICE_HOME = /opt/sparkbeyond/service/promotion`)
| Path | Role |
|------|------|
| `bin/__main__.py` | Application entrypoint. |
| `conf/promotion.toml` | Primary service configuration. |
| `conf/build.info` | Build metadata. |
| `conf/defaults.json` | Default configuration values. |
| `template/template.env` | Environment file template for promoted artifacts. |
| `utils/load_images.sh` | Image-loading helper (exposed as `load_images`). |
| `image_archives/` | Storage for image archive inputs. |
| `exported_images/` | Storage for exported/promoted image outputs. |
| `log/`, `cache/` | Runtime logging and caching directories. |

### External Tooling Integration Points
- **`skopeo`** — inspect and copy container images between registries.
- **`buildah` + `fuse-overlayfs` + `netavark`** — rootless container image building/manipulation.
- **`pigz` / `tar`** — parallel compression and archiving of image bundles.
- **`curl` / `jq`** — HTTP calls and JSON processing (used in healthcheck and scripting).

---

## 5. Data Flow

### Build-Time Flow
```
pyproject.toml + poetry.lock + mps/  ─▶  Poetry (install main deps)
                                     ─▶  Poetry (build wheel: mps-<version>.whl)
                                     ─▶  pip install wheel  ─▶  site-packages
                                     ─▶  strip mps/routes/, mps/api/ (source not shipped)
                                     ─▶  COPY selected artifacts into runtime stage
```

### Runtime Flow
```
Container start
  └─▶ CMD: python bin/__main__.py
        └─▶ loads config from conf/ (promotion.toml, defaults.json, build.info)
        └─▶ binds HTTP server on :8010
        └─▶ HEALTHCHECK polls /healthcheck until 200

Promotion operation (representative)
  incoming image ref / archive  ──▶  image_archives/ (or load_images)
        └─▶ skopeo / buildah   ──▶  inspect, copy, repackage
        └─▶ pigz / tar         ──▶  compress / archive
        └─▶ exported_images/   ──▶  promoted output
```

---

## 6. Extension Points

1. **Base image override** — Pass a different `BASE_IMAGE` build arg to pin or upgrade the Python/Alpine base without editing the Dockerfile.

2. **Version pinning** — The `VERSION` build arg drives which MPS wheel is built and installed; the CI/CD pipeline supplies it (supports both `vX.Y.Z` and `X.Y.Z` forms via parameter expansion).

3. **Configuration overrides** — Mount or bake replacements for files under `conf/` (`promotion.toml`, `defaults.json`) to alter runtime behavior without rebuilding the application layer.

4. **Environment template customization** — `template/template.env` can be swapped to change the environment scaffolding applied to promoted artifacts.

5. **Additional tooling** — Extend the runtime `apk add` layer to include supplementary CLI tools if new promotion targets/registries require them.

6. **Utility scripts** — Add scripts under `utils/` and symlink them into `/usr/local/bin` (mirroring the `load_images` pattern) to expose new operator commands.

7. **User/UID alignment** — `SERVICE_GID`, `EPS_UID`, `EPS_USER`, and `SERVICE_GROUP` are ENV-driven; adjust to match host UID/GID mapping when mounting volumes or the Docker socket to avoid permission conflicts.

---

### Maintenance Notes
- Keep the hard-coded Python site-packages path (`/usr/local/lib/python3.13/...`) in sync with the base image's Python minor version; a base image bump to 3.14+ will require updating both `COPY --from=builder` paths.
- The `pip-autoremove`/`get-pip.py` dance is intentional — do not simplify without verifying that the runtime image ships a clean, current `pip` free of stale versions.
- Source directories `mps/routes/` and `mps/api/` are deliberately removed after the wheel build; runtime behavior depends on the installed package, not on the copied source tree.