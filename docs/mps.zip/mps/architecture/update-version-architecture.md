---
id: dd0e05ce-b891-5f6f-bdb2-1dfb9396457a
type: architecture
title: "Update Version Architecture"
created_at: 2026-06-06T19:04:49.475203+00:00
updated_at: 2026-06-20T22:55:26.781798+00:00
source_files:
  - /Users/spark/git/service-model-promotion/update_version.py
metadata:
  source_name: "mps"
---
# Update Version Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/update_version.py`

# Update Version Architecture


# Architecture Documentation: `update_version`

## 1. Component Overview

The `update_version` module is a lightweight build-time utility responsible for synchronizing the project's version string in `pyproject.toml` with a value provided through the environment. It serves as a glue component within a CI/CD or release-automation pipeline.

**Primary Responsibilities:**
- Read a version string from the `VERSION` environment variable.
- Validate that the version value is present.
- Load and parse the existing `pyproject.toml`.
- Update the Poetry-managed version field.
- Persist the modified configuration back to disk.

This component embodies a **single-responsibility, side-effecting script** pattern—it has no return value and operates entirely through I/O against the filesystem and environment.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Environment variable as input source** | Decouples the script from hard-coded values, enabling integration with CI systems (e.g., GitHub Actions, GitLab CI) where the version is typically derived from git tags or pipeline variables. |
| **Fail-fast validation** | Raising `ValueError` when `VERSION` is unset prevents silent corruption of `pyproject.toml` with an empty or invalid version. |
| **`tomli` / `tomli_w` for TOML handling** | `tomli` is the de-facto standard read-only TOML parser; `tomli_w` provides write support. Splitting read/write across two minimal libraries keeps dependencies lean and standards-compliant. |
| **Binary file modes (`rb` / `wb`)** | Required by `tomli`/`tomli_w`, which operate on bytes to guarantee correct UTF-8 / encoding handling per the TOML spec. |
| **Direct in-place mutation** | The full document is loaded, a single nested key is mutated, and the document is rewritten—preserving overall structure while updating only the targeted field. |
| **`if __name__ == "__main__"` entry point** | Allows the module to be both imported (for testing) and executed directly as a CLI script. |

---

## 3. Component Diagram

```mermaid
flowchart TD
    subgraph Environment
        ENV["VERSION env var"]
    end

    subgraph FileSystem
        TOML[("pyproject.toml")]
    end

    subgraph update_version_module["update_version module"]
        FN["update_version()"]
        VALIDATE{"VERSION set?"}
    end

    ENV -->|os.getenv| FN
    FN --> VALIDATE
    VALIDATE -->|No| ERR["raise ValueError"]
    VALIDATE -->|Yes| READ["tomli.load"]
    TOML -->|read bytes| READ
    READ --> MUTATE["Set tool.poetry.version"]
    MUTATE --> WRITE["tomli_w.dump"]
    WRITE -->|write bytes| TOML
```

---

## 4. Interfaces

### Public API

```python
def update_version() -> None
```

- **Inputs (implicit):**
  - `VERSION` environment variable (string, required)
  - `pyproject.toml` in the current working directory (read + write)
- **Outputs:** None (side effect: file modification)
- **Raises:** `ValueError` if `VERSION` is unset or empty.

### Integration Points

| Integration | Type | Contract |
|-------------|------|----------|
| `VERSION` env var | Input | Must be a non-empty string conforming to a valid version format (validation of format itself is **not** performed here). |
| `pyproject.toml` | Input/Output | Must exist and contain the nested path `tool.poetry.version`. The script assumes Poetry-style structure. |
| CLI invocation | Entry point | `python update_version.py` triggers `update_version()`. |

### External Dependencies

- `os` — environment variable access.
- `tomli` — TOML deserialization (read).
- `tomli_w` — TOML serialization (write).

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant CI as CI/CD Pipeline
    participant Script as update_version()
    participant FS as pyproject.toml

    CI->>Script: set VERSION, invoke script
    Script->>Script: version = os.getenv("VERSION")
    alt VERSION missing
        Script-->>CI: raise ValueError
    else VERSION present
        Script->>FS: open & tomli.load (rb)
        FS-->>Script: parsed dict
        Script->>Script: pyproject["tool"]["poetry"]["version"] = version
        Script->>FS: tomli_w.dump (wb)
        Script-->>CI: exit 0
    end
```

**Step-by-step:**
1. The version string is sourced from the `VERSION` environment variable.
2. Absence of the variable short-circuits execution via an exception.
3. `pyproject.toml` is parsed into an in-memory Python dictionary.
4. The nested key `tool → poetry → version` is overwritten.
5. The full dictionary is serialized and written back, overwriting the file.

---

## 6. Extension Points

The component is intentionally minimal. Likely customization scenarios and recommended approaches:

| Extension Need | Suggested Approach |
|----------------|--------------------|
| **Configurable file path** | Parameterize `update_version(path="pyproject.toml")` instead of hard-coding, enabling reuse across monorepo packages. |
| **Version format validation** | Insert a validation hook (e.g., semantic-version regex check) after reading `VERSION`, before mutation. |
| **Support non-Poetry layouts** | Abstract the key path (`["tool"]["poetry"]["version"]`) into a configurable accessor, e.g., supporting PEP 621 `[project]` tables. |
| **Dry-run mode** | Add a flag to print the resulting TOML to stdout instead of writing, useful for CI verification stages. |
| **Atomic writes** | Replace direct overwrite with a write-to-temp-then-rename strategy to prevent corruption on interrupted writes. |
| **Logging / observability** | Inject a logger to emit the old → new version transition for audit trails in pipelines. |

### Recommended Refactor for Testability

The current design couples I/O and environment access directly, making unit testing reliant on filesystem and environment mocking. A future refactor could separate the **pure transformation** from the **I/O boundary**:

```mermaid
flowchart LR
    A["read_env()"] --> B["bump_version(doc, version)"]
    C["load_toml(path)"] --> B
    B --> D["write_toml(path, doc)"]
```

This isolates `bump_version` as a pure, easily-testable function while keeping I/O at the edges.

---

### Maintenance Notes
- The script assumes execution from the project root (relative path `pyproject.toml`).
- It depends on Poetry's TOML schema; migration to PEP 621 standard `[project]` metadata would require updating the key path.
- No backup of the original file is created—consider this in disaster-recovery considerations.