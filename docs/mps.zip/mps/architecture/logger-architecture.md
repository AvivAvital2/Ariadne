---
id: 019639bf-f09c-5641-b2a6-a8a59a65524e
type: architecture
title: "Logger Architecture"
created_at: 2026-06-06T19:03:46.394110+00:00
updated_at: 2026-06-20T22:55:26.809040+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/logger.py
metadata:
  source_name: "mps"
---
# Logger Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/logger.py`

# Logger Architecture


# Architecture Documentation: `mps.api.logger`

## 1. Component Overview

The `mps.api.logger` module provides centralized logging infrastructure for the **Model Promotion Service (MPS)**. It establishes a consistent logging configuration across the application, supporting both file-based persistence (with automatic rotation) and console output.

### Responsibilities

- **Unified logging configuration** — Provides a single, pre-configured logger instance (`logger`) for application-wide use.
- **Log formatting consistency** — Enforces a uniform output format with aligned columns via a custom delimiter.
- **Log persistence with rotation** — Writes logs to disk with size-based rotation to bound disk usage.
- **Noise reduction** — Filters out high-frequency, low-value access log entries (health checks, favicon requests).
- **Environment-driven configuration** — Reads the desired log level from the `LOG_LEVEL` environment variable and validates it at import time.

### Key Classes

| Class | Role |
|-------|------|
| `CustomLogger` | Extends `logging.Logger` to inject a dynamic alignment delimiter into each record. |
| `SkipHealthFilter` | A `logging.Filter` that suppresses access logs for noise-generating endpoints. |
| `Logger` | Façade/builder that wires together handlers, formatters, and filters into a configured logger. |

---

## 2. Design Decisions

### Custom Logger for Column Alignment
The `CustomLogger.makeRecord` override computes a `delimiter` field (variable-width whitespace) so that messages line up visually regardless of log-level name length (`INFO`, `WARNING`, `ERROR`, etc.). This is a presentation concern baked into the record so the format string `%(levelname)s:%(delimiter)s%(message)s` produces aligned output.

> **Rationale**: Human-readable, aligned logs improve operational scanning of console/file output without external log-processing tooling.

### Dual Output (File + Console)
Two handlers are attached to the logger:
- `RotatingFileHandler` for durable, rotated log files (`log/mps.log`, 5 MB × 2 backups by default).
- `StreamHandler` for real-time console visibility (important in containerized/Uvicorn environments).

> **Rationale**: Supports both interactive observability (console) and post-mortem analysis (file).

### Uvicorn Access Log Filtering
The module attaches `SkipHealthFilter` directly to the `uvicorn.access` logger, integrating with the ASGI server's logging pipeline to reduce health-check noise.

> **Rationale**: Health-check and favicon requests are high-frequency and operationally uninteresting; filtering them keeps logs signal-rich.

### Import-Time Configuration & Validation
The module reads `LOG_LEVEL` and constructs the singleton `logger` at import time, raising `RuntimeWarning` on invalid values via a `match` statement.

> **Rationale**: Fail-fast configuration ensures misconfiguration surfaces immediately rather than at first log call.

> ⚠️ **Note on current implementation**: See [Known Issues](#known-issues--accuracy-notes) — there are bugs in `SkipHealthFilter.filter` logic and the `filtered_endpoints` list that affect actual filtering behavior.

---

## 3. Component Diagram

```mermaid
classDiagram
    class Logger {
        +logger: logging.Logger
        +__init__(component_name, log_level, log_filename, max_bytes, backup_count)
    }

    class CustomLogger {
        +makeRecord(...) LogRecord
    }

    class SkipHealthFilter {
        +filter(record) bool
    }

    class PythonLogger["logging.Logger"]
    class PythonFilter["logging.Filter"]
    class RotatingFileHandler
    class StreamHandler

    CustomLogger --|> PythonLogger : extends
    SkipHealthFilter --|> PythonFilter : extends

    Logger ..> CustomLogger : sets as logger class
    Logger ..> RotatingFileHandler : attaches
    Logger ..> StreamHandler : attaches
    Logger ..> SkipHealthFilter : applies to uvicorn.access
    Logger --> PythonLogger : produces configured instance
```

### Initialization Flow

```mermaid
flowchart TD
    A[Module import] --> B[Read LOG_LEVEL env var]
    B --> C{Valid level?}
    C -- No --> D[Raise RuntimeWarning]
    C -- Yes --> E[Instantiate Logger 'model_promotion']
    E --> F[setLoggerClass CustomLogger]
    E --> G[Create RotatingFileHandler]
    E --> H[Create StreamHandler]
    E --> I[Add SkipHealthFilter to uvicorn.access]
    F & G & H & I --> J[Configured logger exposed as module-level 'logger']
```

---

## 4. Interfaces

### Public Module-Level Export

```python
from mps.api.logger import logger

logger.info("Model promoted to production")
logger.error("Promotion failed: %s", error)
```

- **`logger`** — A fully configured `logging.Logger` instance named `model_promotion`. This is the primary integration point for the rest of the application.

### `Logger` Constructor

```python
Logger(
    component_name: str,
    log_level: logging = logging.INFO,
    log_filename: str = 'log/mps.log',
    max_bytes: int = 5 * 1024 * 1024,
    backup_count: int = 2,
)
```

| Parameter | Description |
|-----------|-------------|
| `component_name` | Logical name registered with `logging.getLogger`. |
| `log_level` | Minimum severity threshold for both handlers. |
| `log_filename` | Path to the rotating log file. |
| `max_bytes` | Rotation threshold per file (default 5 MB). |
| `backup_count` | Number of rotated backups retained (default 2). |

### Integration Points

- **`uvicorn.access` logger** — `SkipHealthFilter` is registered against the Uvicorn access logger, coupling this module to the ASGI server's logging namespace.
- **Filesystem** — Requires a writable `log/` directory for `RotatingFileHandler`.
- **Environment** — `LOG_LEVEL` environment variable controls verbosity.

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant App as Application Code
    participant L as logger (CustomLogger)
    participant F as Handlers' Formatter
    participant FH as RotatingFileHandler
    participant CH as StreamHandler

    App->>L: logger.info("message")
    L->>L: makeRecord() injects 'delimiter'
    L->>FH: emit LogRecord
    L->>CH: emit LogRecord
    FH->>F: format -> "LEVEL: message"
    CH->>F: format -> "LEVEL: message"
    FH->>FH: write to log/mps.log (rotate if > max_bytes)
    CH->>CH: write to stdout/stderr
```

**Uvicorn access log path** (separate flow):

```mermaid
sequenceDiagram
    participant U as uvicorn.access logger
    participant SF as SkipHealthFilter
    U->>SF: filter(record)
    SF-->>U: True (emit) / False (drop)
```

1. Application code calls a logging method on `logger`.
2. `CustomLogger.makeRecord` enriches the record with the alignment `delimiter`.
3. The record is dispatched to both attached handlers if it meets the level threshold.
4. Each handler formats the record using the shared format string and writes to its destination.
5. The file handler rotates the file once it exceeds `max_bytes`, retaining `backup_count` backups.

---

## 6. Extension Points

### Adjusting Verbosity
Set the `LOG_LEVEL` environment variable to one of `DEBUG`, `INFO`, `WARN`, `ERROR`, `FATAL` before process start.

### Creating Additional Component Loggers
Instantiate `Logger` directly with a distinct `component_name` to obtain a separately configured logger sharing the same conventions:

```python
from mps.api.logger import Logger

promo_logger = Logger('model_promotion.scheduler', log_filename='log/scheduler.log').logger
```

### Customizing Output Format
The `delimiter` field added by `CustomLogger` is available to any format string. To extend formatting, modify `log_format` in `Logger.__init__` or subclass `Logger`.

### Filtering Additional Endpoints / Loggers
Extend `SkipHealthFilter.filtered_endpoints` or create new `logging.Filter` subclasses and attach them to additional named loggers within `Logger.__init__`.

### Adding Output Destinations
Attach further handlers (e.g., syslog, HTTP, JSON formatter for log aggregation) within `Logger.__init__` or after retrieving the logger instance.

---

## Known Issues & Accuracy Notes

The following defects exist in the current implementation and should be addressed:

1. **Missing comma in `filtered_endpoints`** — `"/modelpromotion/ping"` and `"/favicon.ico"` are concatenated into a single string (`"/modelpromotion/ping/favicon.ico"`) due to a missing comma. Only two distinct entries effectively exist.

2. **Inverted filter logic** — `SkipHealthFilter.filter` returns:
   ```python
   not any(endpoint not in record.getMessage() for endpoint in filtered_endpoints)
   ```
   The `not in` inside `any(...)` combined with the outer `not` produces unintended behavior — it does **not** reliably suppress health-check messages. The intended logic is likely:
   ```python
   return not any(endpoint in record.getMessage() for endpoint in filtered_endpoints)
   ```

3. **`log_level` type annotation** — Annotated as `logging` (the module) but receives a string from the environment. The handlers' `setLevel` accepts string level names, so it functions, but the annotation is misleading.

4. **Directory dependency** — `RotatingFileHandler` will raise if the `log/` directory does not exist; consider ensuring directory creation during initialization.

These notes are documented for maintainers; the architecture intent described above reflects the *designed* behavior.