---
id: f9db31e6-dce4-54ef-89fd-588d5a4d7361
type: architecture
title: "Basic Architecture"
created_at: 2026-06-06T19:04:19.221395+00:00
updated_at: 2026-06-20T22:55:26.783419+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/basic.py
metadata:
  source_name: "mps"
---
# Basic Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/basic.py`

# Basic Architecture


# Architecture Documentation: `mps.routers.basic`

## 1. Component Overview

The `mps.routers.basic` module provides foundational HTTP endpoints for the Model Promotion Service (MPS). It is a **lightweight FastAPI router** responsible for operational and observability concerns rather than core business logic.

Its primary responsibilities are:

- **Liveness/Readiness checks** — exposing health endpoints for load balancers, orchestrators (e.g., Kubernetes), and uptime monitors.
- **Build metadata exposure** — surfacing deployment/build information (version, commit, build time) for diagnostics and release verification.

This component is intentionally minimal and stateless, acting as the "infrastructure plumbing" tier of the service's HTTP surface.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Use of `APIRouter`** | Encapsulates related routes in a self-contained unit that can be mounted onto a parent FastAPI app via `app.include_router(...)`. This keeps the application modular and supports prefix/tag composition at registration time. |
| **Asynchronous file I/O via `aiofiles`** | The `/buildInfo` endpoint reads a file from disk. Using `aiofiles` avoids blocking the event loop, preserving the non-blocking guarantees of the async runtime. |
| **Plain-text health responses** | `PlainTextResponse("OK")` / `"Pong"` are minimal, fast, and easily parseable by external probes that expect simple string responses rather than JSON envelopes. |
| **Reading build info at request time** | Build info is loaded on each request rather than cached at startup, trading a small amount of latency for always-fresh, file-driven configuration without requiring restarts. |
| **Dual health endpoints (`/healthcheck` and `/modelpromotion/ping`)** | Supports both a generic infrastructure-level probe and a service-namespaced probe, accommodating different consumers (gateway vs. internal tooling). |

> **Note on naming collision:** Two functions are named `ping`. Because they are registered with the router at import time, both routes are bound correctly. However, the second definition shadows the first symbol in the module namespace. This is functionally harmless for routing but should be considered a maintenance hazard (see Extension Points).

---

## 3. Component Diagram

```mermaid
graph TD
    subgraph Client["External Consumers"]
        LB[Load Balancer / Orchestrator]
        MON[Monitoring & Tooling]
    end

    subgraph App["FastAPI Application"]
        ROUTER["mps.routers.basic<br/>(APIRouter)"]
        EP1["GET /healthcheck<br/>ping()"]
        EP2["GET /modelpromotion/ping<br/>ping()"]
        EP3["GET /modelpromotion/buildInfo<br/>build_info()"]
    end

    subgraph FS["Filesystem"]
        BUILD["conf/build.info<br/>(JSON)"]
    end

    LB --> EP1
    MON --> EP2
    MON --> EP3

    ROUTER --> EP1
    ROUTER --> EP2
    ROUTER --> EP3

    EP3 -.->|aiofiles read| BUILD

    EP1 -->|PlainText 'OK'| LB
    EP2 -->|PlainText 'Pong'| MON
    EP3 -->|JSON build metadata| MON
```

---

## 4. Interfaces

### Exposed HTTP Endpoints

| Method | Path | Handler | Success Response | Content-Type |
|--------|------|---------|------------------|--------------|
| `GET` | `/healthcheck` | `ping` | `200` `OK` | `text/plain` |
| `GET` | `/modelpromotion/ping` | `ping` | `200` `Pong` | `text/plain` |
| `GET` | `/modelpromotion/buildInfo` | `build_info` | `200` build metadata | `application/json` |

### Integration Points

- **Inbound:** The `router` object is the integration surface. It must be mounted into the application via:
  ```python
  from mps.routers import basic
  app.include_router(basic.router)
  ```
- **Outbound (filesystem):** `build_info` depends on the presence of `conf/build.info`, a JSON file expected to be populated at build/deploy time. The path is relative to the process working directory.

### Contract Notes

- `build.info` **must** contain valid JSON; otherwise `json.loads` raises and the request fails with a `500`. There is currently **no graceful error handling** for a missing or malformed file.

---

## 5. Data Flow

### Health Check Flow (`/healthcheck`, `/modelpromotion/ping`)

```mermaid
sequenceDiagram
    participant C as Client/Probe
    participant R as basic.router
    C->>R: GET /healthcheck
    R-->>C: 200 PlainText "OK"
```

These handlers are pure and stateless — no I/O, no external dependencies. They return immediately.

### Build Info Flow (`/modelpromotion/buildInfo`)

```mermaid
sequenceDiagram
    participant C as Client/Tooling
    participant R as basic.router
    participant FS as conf/build.info

    C->>R: GET /modelpromotion/buildInfo
    R->>FS: async open + read (aiofiles)
    FS-->>R: raw JSON string
    R->>R: json.loads(data)
    R-->>C: 200 JSONResponse(content)
```

**Data lifecycle:** Disk file → in-memory string → parsed Python dict → serialized JSON response. No data is persisted or mutated; the flow is strictly read-only.

---

## 6. Extension Points

### Adding New Operational Endpoints
Add new route handlers decorated with `@router.<method>(...)` in this module. They are automatically included wherever `router` is mounted.

```python
@router.get("/modelpromotion/readiness")
async def readiness():
    # check downstream dependencies here
    return PlainTextResponse("READY")
```

### Recommended Hardening / Customizations

1. **Resolve the function name collision.** Rename the duplicate `ping` handlers (e.g., `healthcheck` and `service_ping`) to avoid namespace shadowing and improve testability and clarity.

2. **Add error handling to `build_info`.** Guard against a missing/invalid `conf/build.info`:
   ```python
   try:
       async with aiofiles.open("conf/build.info") as f:
           return JSONResponse(json.loads(await f.read()))
   except (FileNotFoundError, json.JSONDecodeError):
       return JSONResponse({"error": "build info unavailable"}, status_code=503)
   ```

3. **Externalize the file path.** Inject the `build.info` location via configuration rather than hardcoding `conf/build.info`, improving portability across environments.

4. **Caching opportunity.** Since build info is immutable for the life of a deployment, it could be loaded once at application startup (e.g., via a lifespan/startup hook) and served from memory.

5. **Router composition.** Apply a `prefix` and `tags` at registration time to group these endpoints in OpenAPI docs:
   ```python
   app.include_router(basic.router, tags=["operations"])
   ```

---

*This document reflects the current implementation of `mps.routers.basic`. Update it alongside changes to route definitions, the `build.info` contract, or error-handling behavior.*