---
id: 482d1c46-2501-5baa-9ce4-27b414e7b6b8
type: architecture
title: "Token Manager Architecture"
created_at: 2026-06-06T19:03:58.067589+00:00
updated_at: 2026-06-20T22:55:26.834747+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/token_manager.py
metadata:
  source_name: "mps"
---
# Token Manager Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/token_manager.py`

# Token Manager Architecture


# Architecture Documentation: `mps.api.token_manager`

## 1. Component Overview

The `token_manager` module is responsible for **authenticating against container registries** and **persisting credentials** in the Docker configuration file (`~/.docker/config.json`). It abstracts the differences between registry providers (local, Azure, AWS, and—planned—GCP) behind a consistent interface.

The module exposes two classes:

| Class | Responsibility |
|-------|----------------|
| `TokenManager` | Base implementation supporting `local` and `azure` providers. Handles configuration validation, schema/auth resolution, credential file I/O, and session creation. |
| `AWSTokenManager` | Specialization for AWS ECR. Overrides token acquisition to fetch short-lived authorization tokens from ECR using `boto3`. |

The core responsibilities are:

- **Configuration validation** — Ensure required parameters are present per provider type.
- **Connectivity verification** — Confirm the container registry is reachable before establishing a session.
- **Credential management** — Encode/decode credentials and write them to the Docker config file.
- **Session establishment** — Create an authenticated `MPSSession` for downstream registry operations.

---

## 2. Design Decisions

### Provider Strategy via Inheritance
A base `TokenManager` handles "static credential" providers (local, Azure) where the username/password are supplied directly. `AWSTokenManager` extends it because AWS ECR requires an **extra token-exchange step**: long-lived AWS access keys are exchanged for a short-lived ECR authorization token. This separation isolates the AWS SDK (`boto3`) dependency to a single subclass.

### Schema & Auth Resolution Heuristics
Two derived flags simplify downstream logic:
- `schema` — Defaults to `https`, but uses `http` for local registries that bind a port (e.g., `localhost:5000`). This reflects the deployment convention that production registries terminate TLS on port 443.
- `use_auth` — Disabled only when credentials are absent **and** the provider is `local`, allowing unauthenticated local development.

### Parameter Validation by Provider
Required parameters are computed conditionally:
- `local` requires only registry address, provider, and certificate-signing flag.
- All other providers additionally require user/password.

A `MissingConfigValues` error is raised early if any required value is `None`, enforcing **fail-fast configuration validation** at construction time.

### Async + Locking for AWS Token Refresh
`AWSTokenManager.get_username_and_password` is guarded by an `asyncio.Lock` to prevent **concurrent token refreshes** from racing on the credential file when multiple coroutines trigger re-authentication.

### Credentials Persisted to Docker Config
By writing to `~/.docker/config.json`, the module integrates with the standard Docker credential mechanism, so external Docker tooling can reuse the authenticated state.

---

## 3. Component Diagram

```mermaid
classDiagram
    class TokenManager {
        +str registry
        +str username
        +str password
        +str provider
        +str region_name
        +bool verify_certificate_signing
        +str config_filename
        +str schema
        +bool use_auth
        +session
        +__init__(...)
        -_write_credentials_to_file(stored_credentials)
        +get_credentials(registry_auth_url, username, password)
        +get_username_and_password() tuple
        +login()
    }

    class AWSTokenManager {
        +Lock lock
        +str region_name
        +str registry_id
        +boto3.client session
        +__init__(...)
        +get_username_and_password()
        +login()
    }

    TokenManager <|-- AWSTokenManager : extends

    class MPSSession {
        <<external utility>>
    }

    class verify_connection_to_container_registry {
        <<utility function>>
    }

    class boto3_ECR_Client {
        <<external>>
        +get_authorization_token()
    }

    class DockerConfigFile {
        <<filesystem>>
        ~/.docker/config.json
    }

    TokenManager ..> verify_connection_to_container_registry : uses
    TokenManager ..> MPSSession : creates
    TokenManager ..> DockerConfigFile : writes/reads
    AWSTokenManager ..> boto3_ECR_Client : token exchange
```

### Provider Login Flow

```mermaid
flowchart TD
    A[login called] --> B{provider}
    B -->|export| Z[Skip - no login]
    B -->|local / azure| C[verify_connection_to_container_registry]
    C --> D[get_credentials & write to config.json]
    D --> E[Create MPSSession]
    B -->|aws AWSTokenManager| F{region_name set?}
    F -->|No| G[raise InvalidAWSRegion]
    F -->|Yes| H[ECR get_authorization_token]
    H --> I[decode token, write to config.json]
    I --> J[verify_connection_to_container_registry]
    J --> K[Create MPSSession]
```

---

## 4. Interfaces

### Constructor — `TokenManager.__init__`
| Parameter | Type | Description |
|-----------|------|-------------|
| `registry` | `str` | Registry address (host[:port]). |
| `username` / `password` | `str` | Credentials (may be `None` for local). |
| `provider` | `str` | One of `local`, `azure`, `aws`, (planned `gcp`). |
| `region_name` | `str` | Optional region; required for AWS. |
| `verify_certificate_signing` | `bool` | TLS verification toggle. |

**Raises:** `MissingConfigValues` when required parameters for the provider are absent.

### Public Methods

| Method | Signature | Purpose |
|--------|-----------|---------|
| `get_credentials` | `(registry_auth_url, username=None, password=None) -> dict` | Builds the Docker-format `auths` dict with base64-encoded `user:pass`. |
| `get_username_and_password` | `async () -> (str, str)` | Reads & decodes credentials from the config file (overridden in AWS to refresh from ECR). |
| `login` | `async ()` | Verifies connectivity, persists credentials, and establishes the `MPSSession`. |

### Integration Points

| Dependency | Role |
|------------|------|
| `mps.api.utils.verify_connection_to_container_registry` | Validates registry reachability; returns the resolved `base_url`. |
| `mps.api.utils.MPSSession` | The authenticated session object consumed by downstream registry operations. |
| `mps.api.errors` | Domain-specific exceptions (`MissingConfigValues`, `InvalidRegistryProvider`, `UnableToStoreCredentialsFile`, `UnableToGetAuthToken`, `InvalidAWSRegion`). |
| `mps.api.logger.logger` | Structured logging of login activity. |
| `boto3` / `botocore` | AWS ECR token retrieval (AWS path only). |

---

## 5. Data Flow

### Local / Azure
1. **Construction** — Validate config; derive `schema` and `use_auth`.
2. **`login()`** — Call `verify_connection_to_container_registry` to obtain `base_url`.
3. **Credential build** — `get_credentials` base64-encodes `user:pass` into Docker-config format.
4. **Persist** — `_write_credentials_to_file` writes `~/.docker/config.json`.
5. **Session** — On valid `base_url`, decode stored credentials and instantiate `MPSSession`.

### AWS ECR
1. **Construction** — Initialize a `boto3` ECR client with AWS keys; derive `registry_id` (first 12 digits of registry).
2. **`login()`** — Guard against missing region.
3. **Token exchange** — Under `lock`, call `get_authorization_token`; the returned base64 token decodes to `username:password`.
4. **Persist** — Write the ephemeral credentials to the Docker config file.
5. **Session** — Verify connectivity and create `MPSSession`.

```mermaid
sequenceDiagram
    participant Caller
    participant AWSTM as AWSTokenManager
    participant ECR as boto3 ECR Client
    participant FS as config.json
    participant Reg as Registry

    Caller->>AWSTM: await login()
    AWSTM->>AWSTM: check region_name
    AWSTM->>ECR: get_authorization_token(registryIds)
    ECR-->>AWSTM: base64 token
    AWSTM->>AWSTM: decode -> (user, pass)
    AWSTM->>FS: write credentials
    AWSTM->>Reg: verify_connection_to_container_registry
    Reg-->>AWSTM: base_url
    AWSTM->>AWSTM: create MPSSession
```

---

## 6. Extension Points

### Adding a New Provider (e.g., GCP)
The codebase explicitly notes GCP support is pending (`# Todo: Add support for "gcp" as well`). Two extension patterns are available:

**A. Static-credential providers** (like Azure): extend the `match self.provider` block in `TokenManager.login`:
```python
case "azure" | "local" | "gcp":
    stored_credentials = self.get_credentials(self.registry)
    self._write_credentials_to_file(stored_credentials)
```

**B. Token-exchange providers** (like AWS): subclass `TokenManager`, mirroring `AWSTokenManager`:
- Override `__init__` to set up the provider SDK client and provider name.
- Override `get_username_and_password` to perform the provider-specific token exchange and persist credentials (use a lock if concurrent refresh is possible).
- Override `login` to enforce provider-specific preconditions and create the `MPSSession`.

### Customization Hooks

| Hook | How to Customize |
|------|------------------|
| `get_credentials` | Override to change the credential serialization format. |
| `_write_credentials_to_file` | Override to target a different config path or storage backend (e.g., a secrets manager). |
| `config_filename` | Reassign post-construction to redirect credential storage. |
| `get_username_and_password` | Override for dynamic/refreshable credentials. |

### Recommendations for Maintainers
- **Provider validation centralization** — The valid-provider list appears in both the error message and the `match` statement; consider extracting to an enum to keep them in sync.
- **Consistent connectivity flow** — `AWSTokenManager.login` calls `get_username_and_password` twice (once for verification, once for the session); a single fetch could reduce redundant ECR calls.
- **`use_auth` semantics** — Note `use_auth` is a `bool`, but `login` checks `self.use_auth is None`; align these to avoid sending `None` auth unexpectedly.