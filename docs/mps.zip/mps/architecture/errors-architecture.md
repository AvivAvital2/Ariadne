---
id: fb7d5f1f-3193-55f2-adf0-c54266ca7268
type: architecture
title: "Errors Architecture"
created_at: 2026-06-06T19:03:26.493255+00:00
updated_at: 2026-06-20T22:55:26.801924+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/errors.py
metadata:
  source_name: "mps"
---
# Errors Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/errors.py`

# Errors Architecture


# Architecture Document: `mps.api.errors`

## 1. Component Overview

The `mps.api.errors` module defines the centralized exception hierarchy for the MPS (Multi-Purpose Service) application. It provides a consistent error-handling contract across the system by:

- Establishing a common base exception (`ExceptionHandler`) that all domain-specific errors inherit from.
- Integrating automatic logging at the point of error instantiation.
- Carrying optional HTTP-style `status_code` metadata to support API-layer error responses.
- Defining semantically meaningful, domain-specific exception types covering configuration loading, authentication, container registry operations, and credential management.

This module acts as the **single source of truth for error semantics**, allowing other components to raise and catch well-named exceptions rather than relying on generic Python errors.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Single base class (`ExceptionHandler`)** | Centralizes shared behavior (logging, message storage, status code) so derived exceptions remain thin and consistent. |
| **Logging at construction time** | Guarantees that *every* raised exception is logged once, at the source, regardless of whether higher layers handle it. Reduces missed-logging bugs. |
| **Optional `status_code`** | Allows the same exception type to serve both internal logic flows and API boundary translation (e.g., mapping to HTTP responses) without separate classes. |
| **Granular, named exceptions** | Each failure mode (config, auth, registry, credentials) maps to a distinct class, enabling precise `except` clauses and clearer error reporting. |
| **Docstring-driven semantics** | Each subclass documents *exactly* when it should be raised, serving as inline contract documentation. |
| **`__repr__`/`__str__` overrides** | Provides human-readable representations and an exception hook for top-level interpreter integration. |

### Notable Inconsistency
Only `UnableToGetAuthToken` requires a `status_code` in its constructor; all other subclasses accept only a `message`. This suggests `status_code` propagation is currently limited to auth-token flows. A future refactor could standardize this across all subclasses.

---

## 3. Component Diagram

```mermaid
classDiagram
    class Exception
    class Logger {
        +logger
    }

    class ExceptionHandler {
        +Logger
        +detail
        +status_code
        +__init__(message, status_code)
        +__repr__()
        +__str__()
        +exception_handler()
    }

    Exception <|-- ExceptionHandler
    ExceptionHandler ..> Logger : uses

    ExceptionHandler <|-- NoConfigurationFoundError
    ExceptionHandler <|-- NoConfigurationFileFoundError
    ExceptionHandler <|-- InvalidConfigurationFile
    ExceptionHandler <|-- UnableToGetAuthToken
    ExceptionHandler <|-- InvalidRegistryProvider
    ExceptionHandler <|-- InvalidAWSRegion
    ExceptionHandler <|-- UnableToUploadOneOrMoreImages
    ExceptionHandler <|-- MissingConfigValues
    ExceptionHandler <|-- UnreachableContainerRegistry
    ExceptionHandler <|-- UnavailableImage
    ExceptionHandler <|-- SelfSignedCertificate
    ExceptionHandler <|-- UnableToStoreCredentialsFile
    ExceptionHandler <|-- UnableToObtainPushedImagesFromContainerRegistry
```

### Logical Grouping of Exceptions

```mermaid
flowchart TB
    EH[ExceptionHandler<br/>base class]

    subgraph Config["Configuration Errors"]
        NoConfigurationFoundError
        NoConfigurationFileFoundError
        InvalidConfigurationFile
        MissingConfigValues
    end

    subgraph Auth["Authentication & Credentials"]
        UnableToGetAuthToken
        UnableToStoreCredentialsFile
        SelfSignedCertificate
    end

    subgraph Registry["Container Registry / Image Errors"]
        InvalidRegistryProvider
        InvalidAWSRegion
        UnableToUploadOneOrMoreImages
        UnreachableContainerRegistry
        UnavailableImage
        UnableToObtainPushedImagesFromContainerRegistry
    end

    EH --> Config
    EH --> Auth
    EH --> Registry
```

---

## 4. Interfaces

### Base Class: `ExceptionHandler`

```python
ExceptionHandler(message: str, status_code: int | None = None)
```

**Attributes exposed:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `detail` | `str` | The error message; intended for surfacing to API consumers. |
| `status_code` | `int \| None` | Optional status code for API-layer mapping. |
| `Logger` | `logging.Logger` | The bound logger instance used internally. |

**Methods:**

| Method | Purpose |
|--------|---------|
| `__str__()` | Returns the message argument for display. |
| `__repr__()` | Returns `ClassName(message)` and installs a custom `sys.excepthook`. |
| `exception_handler()` | Formats the exception for the interpreter excepthook. |

### Integration Points

- **`.logger.Logger`** — Each exception instance constructs a logger named after the module (`__name__`) and emits an `error`-level log line containing the message at instantiation.
- **`sys`** — Used to register a custom `excepthook` via `__repr__`, integrating with the Python interpreter's top-level exception display.
- **API layer (consumer)** — Components catching these exceptions can read `detail` and `status_code` to build structured error responses.

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant Caller as Application Code
    participant Err as ExceptionHandler subclass
    participant Log as Logger

    Caller->>Err: raise SubError("message", [status_code])
    Err->>Err: store detail, status_code
    Err->>Log: logger.error("message")
    Err-->>Caller: exception propagates
    Note over Caller: catch block reads<br/>.detail / .status_code
    opt API boundary
        Caller->>Caller: map status_code -> HTTP response
    end
```

**Flow summary:**

1. Application code detects a failure condition and raises the appropriate domain exception.
2. The constructor records the message into `detail` and the optional `status_code`.
3. The message is immediately logged at `error` level — logging is a **side effect of construction**, not of being caught.
4. The exception propagates up the call stack.
5. A handling layer (e.g., an API controller) inspects `detail` and `status_code` to produce a response, or the unhandled exception reaches the interpreter where the custom excepthook formats it.

---

## 6. Extension Points

### Adding a New Domain Exception

Follow the established pattern — inherit from `ExceptionHandler` and document the trigger condition:

```python
class NewDomainError(ExceptionHandler):
    """Raised when <specific condition> occurs."""
    def __init__(self, message: str):
        super(NewDomainError, self).__init__(message)
```

If the error must carry an API status code:

```python
class NewApiError(ExceptionHandler):
    """Raised when <condition> at an API boundary."""
    def __init__(self, message: str, status_code: int):
        super(NewApiError, self).__init__(message, status_code)
```

### Customizing Cross-Cutting Behavior

- **Logging behavior** — Modify `ExceptionHandler.__init__` to change log level, formatting, or to add structured fields. All subclasses inherit the change automatically.
- **Status code standardization** — To make `status_code` universally available, update subclass constructors to accept and forward an optional `status_code` parameter.
- **Interpreter integration** — `exception_handler` and the `__repr__`-installed `sys.excepthook` can be customized to alter top-level crash reporting.

### Recommended Conventions When Extending

1. **One class per failure mode** — keep exceptions granular and named for the condition.
2. **Always provide a docstring** stating the raise condition (acts as the contract).
3. **Group logically** — place new classes near their domain peers (config / auth / registry).
4. **Avoid embedding remediation logic** in exceptions; keep them as data + logging carriers.

---

## Maintenance Notes

- The `__repr__`, `__str__`, and `exception_handler` methods are excluded from coverage (`# pragma: no cover`); changes here are not test-guarded and should be reviewed manually.
- Because logging occurs at construction, **constructing an exception without raising it still emits an error log** — avoid pre-constructing these objects for non-error purposes.