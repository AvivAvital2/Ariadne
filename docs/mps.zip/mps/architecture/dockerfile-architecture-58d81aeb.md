---
id: 58d81aeb-0833-5198-a02a-bcd2c0e95877
type: architecture
title: "Dockerfile Architecture"
created_at: 2026-07-03T05:57:43.754882+00:00
updated_at: 2026-07-03T05:57:43.754895+00:00
source_files:
  - /Users/spark/git/service-model-promotion/.ci/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/.ci/builder/Dockerfile`

# Architecture Documentation: `stage0.Dockerfile`

## 1. Component Overview

`stage0.Dockerfile` defines the **builder image** for the `service-promotion` project. It is a foundational CI/CD build environment image that packages all the tooling required to compile, test, and deploy SparkBeyond services.

The image is a *stage-0* base — it does not contain the application itself. Instead, it provides a reproducible, pinned toolchain that downstream build stages and CI pipelines consume. Its primary responsibilities are:

- **Language runtimes**: Java (Amazon Corretto 8), R, Python 2 & 3 (embedded SparkBeyond builds).
- **Build tooling**: SBT (Scala build tool), Git.
- **Containerization tooling**: Docker CLI, Docker Compose.
- **Orchestration tooling**: Helm, kubectl.
- **Cloud tooling**: AWS CLI.
- **SparkBeyond shared libraries**: MLlib driver, Weka wrapper, NLP4j, WordNet data, GData assets.
- **Repository configuration**: SBT resolver configuration pointing at internal Nexus proxies.

## 2. Design Decisions

| Decision | Rationale |
|---|---|
| **Inherits from `prediction-server/builder`** | Reuses an already-hardened base with CentOS 7 + common SparkBeyond conventions, avoiding duplication of low-level setup. |
| **All tool versions pinned via `ARG`** | Guarantees reproducible builds. Version bumps become explicit, reviewable changes rather than silent drift. |
| **UTC timezone forced** | Ensures deterministic timestamps/logs across build agents regardless of host locale. |
| **Internal Nexus proxies for RPM/Ivy/Maven** | Provides supply-chain control, caching, and offline resilience. All SparkBeyond artifacts and Maven Central are routed through `nexus.dev.sparkbeyond.ai` / `nexus.sparkbeyond.com`. |
| **Embedded runtimes (Corretto, Python, R) via RPM** | SparkBeyond-packaged runtimes are self-contained under `/opt/sparkbeyond/embedded/`, decoupling the build from OS-provided versions. |
| **`alternatives --install` for Java** | Makes the embedded Corretto JDK the default `java` binary, so build tools resolve the correct runtime transparently. |
| **Aggressive `yum clean` / cache removal** | Minimizes image layer size after each install group. |
| **WordNet extracted from a GData RPM via `rpm2cpio`** | Only the WordNet-3.0 dataset is needed, so a full RPM install is avoided; selective extraction reduces footprint. The guard `[ ! -d ... ]` makes the step idempotent-safe against the inherited base. |
| **GPG keys imported + `update-ca-trust`** | Establishes trust for CentOS/EPEL package signatures before installing third-party RPMs. |
| **Disabling `bintray--sbt-rpm` repo** | Bintray was deprecated; SBT is instead sourced from the SparkBeyond/Nexus repos. |

## 3. Component Diagram

```dot
digraph stage0_builder {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    base [label="Base Image\nprediction-server/builder:20200615-2\n(CentOS 7)", style="rounded,filled", fillcolor="#e8e8e8"];

    subgraph cluster_config {
        label="System Configuration";
        style=dashed;
        tz   [label="Timezone -> UTC"];
        trust[label="RPM GPG Keys +\nCA Trust"];
        repos[label="Yum Repo Config\n(Nexus proxies)"];
    }

    subgraph cluster_runtimes {
        label="Language Runtimes";
        style=dashed;
        jdk   [label="Amazon Corretto 8\n(embedded)"];
        r     [label="Embedded R"];
        py2   [label="Embedded Python 2"];
        py3   [label="Embedded Python 3"];
    }

    subgraph cluster_sblibs {
        label="SparkBeyond Shared Libraries";
        style=dashed;
        mllib [label="MLlib Driver"];
        weka  [label="Weka Wrapper"];
        nlp4j [label="NLP4j"];
        wordnet[label="WordNet-3.0 data"];
    }

    subgraph cluster_buildtools {
        label="Build & Delivery Tooling";
        style=dashed;
        sbt   [label="SBT 1.2.8"];
        git   [label="Git (WANdisco)"];
        docker[label="Docker CLI 18.06.2"];
        compose[label="Docker Compose 1.23.1"];
        helm  [label="Helm 3.2.1"];
        kubectl[label="kubectl 1.18.0"];
        aws   [label="AWS CLI"];
    }

    sbtcfg [label="~/.sbt/repositories\n(Nexus Ivy/Maven resolvers)"];
    nexus  [label="Nexus\n(RPM / Ivy / Maven proxies)", shape=cylinder, style=filled, fillcolor="#dde8ff"];

    base -> tz -> trust -> repos;
    repos -> jdk; repos -> r; repos -> py2; repos -> py3;
    repos -> mllib; repos -> weka; repos -> nlp4j;
    repos -> sbt; repos -> git;

    jdk -> sbtcfg [label="default java\n(alternatives)"];

    nexus -> repos [dir=back, label="RPM proxy"];
    nexus -> sbtcfg [dir=back, label="Ivy/Maven proxy"];
    nexus -> wordnet [dir=back, label="GData RPM extract"];

    external [label="External Sources\n(download.docker.com,\nget.helm.sh,\ngoogleapis kubectl)", shape=cylinder, style=filled, fillcolor="#ffe8dd"];
    external -> docker; external -> compose; external -> helm; external -> kubectl;
}
```

## 4. Interfaces

### Build Arguments (customization interface)
| ARG | Default | Purpose |
|---|---|---|
| `SBT_VERSION` | `1.2.8` | SBT package version |
| `DOCKER_VERSION` | `18.06.2-ce` | Docker static binary version |
| `DOCKER_COMPOSE_VERSION` | `1.23.1` | Docker Compose release |
| `EMBEDDED_PYTHON3_VERSION` | `1.0.4` | SparkBeyond embedded Python 3 RPM |
| `HELM_VERSION` | `3.2.1` | Helm release |
| `KUBECTL_VERSION` | `1.18.0` | kubectl release |

### Filesystem Contract (what consumers can rely on)
- `/opt/sparkbeyond/embedded/amazon-corretto-8.212.04.2-linux-x64/` — JDK home.
- `/opt/sparkbeyond/shared/WordNet-3.0/` — WordNet dataset (group `sparkbeyond`).
- `/usr/bin/java` — Corretto 8 (via `alternatives`).
- `/usr/bin/{docker,git,sbt,aws}` — build tools on PATH.
- `/usr/local/bin/{docker-compose,helm,kubectl}` — orchestration tools on PATH.
- `~/.sbt/repositories` — SBT resolver configuration.

### External Integration Points
- **Nexus (`nexus.dev.sparkbeyond.ai`, `nexus.sparkbeyond.com`)** — RPM, Ivy, and Maven artifact resolution.
- **AWS ECR** — image registry (`551806661322.dkr.ecr.eu-west-1.amazonaws.com`).
- **Public download endpoints** — Docker, Helm, kubectl binaries.

### Entrypoint
- `CMD ["/bin/bash"]` — interactive/CI shell; consumers typically override with build commands.

## 5. Data Flow

The Dockerfile is a **build-time pipeline**; "data" here is artifacts flowing into image layers:

1. **Configuration phase** — Timezone set to UTC; GPG keys imported and CA trust updated; Nexus yum repositories registered; deprecated Bintray repo disabled.
2. **Runtime + library provisioning** — RPMs for Corretto JDK, embedded R, MLlib driver, Weka wrapper, NLP4j, and embedded Python 2/3 are pulled from Nexus and installed.
3. **Selective dataset extraction** — The GData RPM is downloaded, unpacked with `rpm2cpio | cpio`, and only `WordNet-3.0` is moved into `/opt/sparkbeyond/shared/`, then group-owned by `sparkbeyond`.
4. **Java default selection** — `alternatives` points the system `java` at the embedded Corretto JDK.
5. **Tooling installation** — SBT, Git, AWS CLI from yum; Docker, Docker Compose, Helm, kubectl from external static binary downloads onto PATH.
6. **Resolver configuration** — `~/.sbt/repositories` is written to route SBT dependency resolution through Nexus Ivy/Maven proxies.

At **runtime**, downstream builds invoke `sbt`, `docker`, `helm`, etc., which fetch dependencies and produce artifacts — all dependency traffic funnels through Nexus per the resolver config.

```dot
digraph data_flow {
    rankdir=LR;
    node [shape=box, style=rounded];
    cfg    [label="1. System Config\n(UTC, GPG, repos)"];
    rt     [label="2. Runtimes +\nSB Libraries (RPM)"];
    wn     [label="3. WordNet extract"];
    java   [label="4. Java default\n(alternatives)"];
    tools  [label="5. Build/Deploy tools"];
    resolv [label="6. SBT resolvers"];
    image  [label="Final Builder Image", shape=cylinder, style=filled, fillcolor="#d8f8d8"];

    cfg -> rt -> wn -> java -> tools -> resolv -> image;
}
```

## 6. Extension Points

- **Version overrides via `--build-arg`** — Bump any pinned tool (e.g. `docker build --build-arg SBT_VERSION=1.3.13 ...`) without editing the Dockerfile.
- **Adding SparkBeyond libraries** — Append RPM URLs to the shared-tools `yum install` block; keep the `yum clean all` / cache cleanup in the same layer to control image size.
- **Alternate artifact sources** — Update the `~/.sbt/repositories` heredoc and the `yum-config-manager --add-repo` lines to retarget Nexus/Maven mirrors.
- **Downstream layering** — Use this image as a `FROM` base in a `stage1`/application Dockerfile; the documented filesystem contract (JDK home, PATH tools, resolver config) is the stable interface to build against.
- **Registry retagging** — The `LABEL name` documents the intended ECR target; update alongside the tag when promoting new versions.

### Maintenance Notes
- Several tools (Docker, Helm, kubectl, Docker Compose) are on **older pinned versions**; upgrading requires validating the corresponding external download URLs still exist and follow the same tarball structure (`--strip-components` assumptions).
- The base image reference is itself a mutable dependency — reproducibility is only guaranteed for a fixed base tag (`20200615-2`).
- The WordNet extraction step depends on the internal path layout of the GData RPM; changes upstream to that RPM could break the `mv`/`chgrp` steps.