---
id: 03bffd8e-b0b6-54bb-8694-1654c87533e3
type: architecture
title: "Image Cache Architecture"
created_at: 2026-06-06T19:03:33.449618+00:00
updated_at: 2026-06-20T22:55:26.831171+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_cache.py
metadata:
  source_name: "mps"
---
# Image Cache Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_cache.py`

# Image Cache Architecture


# Architecture Document: AsyncPersistentImageCache

**Module**: `mps.api.image_cache`

---

## 1. Component Overview

The `AsyncPersistentImageCache` provides a durable, asynchronous key-value store for binary image data, backed by a local SQLite database. It is designed for use in `asyncio`-based applications where image artifacts (or other binary blobs) must survive process restarts.

### Responsibilities
- **Persistence**: Stores image data in an on-disk SQLite database (`image_cache.sqlite`) so cached entries survive across application lifecycles.
- **Async I/O**: Performs all database operations non-blockingly via `aiosqlite`, integrating cleanly with cooperative concurrency models.
- **Lifecycle management**: Manages connection setup/teardown and schema initialization through the async context manager protocol.
- **CRUD operations**: Exposes a simple `get` / `set` / `update` / `delete` / `clear` / `list` interface keyed by string identifiers.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **SQLite as the backing store** | Provides zero-configuration, single-file persistence with ACID guarantees. No separate database server is required, simplifying deployment. |
| **`aiosqlite` over the standard `sqlite3`** | The standard library SQLite driver is blocking. `aiosqlite` wraps it in a worker thread, exposing an `async`/`await` interface that avoids stalling the event loop. |
| **Async context manager (`__aenter__`/`__aexit__`)** | Binds the database connection lifetime to a scoped `async with` block, guaranteeing schema initialization on entry and connection cleanup on exit. |
| **`asyncio.Lock` around writes** | Serializes write operations (`set`, `update`, `delete`, `clear`) to avoid interleaved commits and concurrent cursor usage on a single shared connection. |
| **Read operations are lock-free** | `get` and `list` do not acquire the lock, prioritizing read throughput. (See [Concurrency Considerations](#concurrency-considerations).) |
| **Config-driven storage path** | The database location is derived from `mps.api.config.image_cache_path`, decoupling storage policy from the cache logic. |
| **Simple schema (`key TEXT PRIMARY KEY, value BLOB`)** | A flat key→blob mapping keeps the abstraction minimal and the queries trivially indexed by primary key. |

### Concurrency Considerations
The write path is protected by an `asyncio.Lock`, ensuring only one write/commit happens at a time on the shared connection. Read operations bypass the lock — acceptable under SQLite's transactional isolation for this use case, but worth noting if strict read-after-write consistency under heavy concurrency is required.

---

## 3. Component Diagram

```mermaid
graph TD
    subgraph Application["Async Application Code"]
        Caller["Caller (async with)"]
    end

    subgraph Cache["AsyncPersistentImageCache"]
        Lifecycle["Lifecycle\n__aenter__ / __aexit__"]
        Reads["Read API\nget() / list()"]
        Writes["Write API\nset() / update()\ndelete() / clear()"]
        ExecGuard["_execute()\n(asyncio.Lock)"]
        Conn["aiosqlite Connection"]
    end

    subgraph Config["mps.api.config"]
        Path["image_cache_path"]
    end

    subgraph Storage["Persistence Layer"]
        DB[("image_cache.sqlite\ntable: cache(key, value)")]
    end

    Caller -->|async with| Lifecycle
    Caller --> Reads
    Caller --> Writes

    Lifecycle --> Conn
    Reads --> Conn
    Writes --> ExecGuard
    ExecGuard --> Conn
    Conn --> DB

    Path -.->|db_path| Lifecycle
```

---

## 4. Interfaces

### Lifecycle (Async Context Manager Protocol)

| Method | Description |
|--------|-------------|
| `async __aenter__()` | Opens the SQLite connection, creates the `cache` table if missing, commits, and returns `self`. |
| `async __aexit__(exc_type, exc_val, exc_tb)` | Closes the connection. Does **not** suppress exceptions. |

**Usage pattern:**
```python
async with AsyncPersistentImageCache() as cache:
    await cache.set("avatar:123", image_bytes)
    data = await cache.get("avatar:123")
```

### Read API

| Method | Signature | Returns |
|--------|-----------|---------|
| `get` | `async get(key: str)` | The stored `BLOB` value, or `None` if the key is absent. |
| `list` | `async list()` | A `dict[str, bytes]` of all cached entries. |

### Write API (serialized via `_execute`)

| Method | Signature | Behavior |
|--------|-----------|----------|
| `set` | `async set(key, value)` | Inserts or replaces the entry (`INSERT OR REPLACE`). |
| `update` | `async update(key, value)` | Updates an existing entry (no-op if key is absent). |
| `delete` | `async delete(key)` | Removes a single entry. |
| `clear` | `async clear()` | Removes all entries. |

### Integration Points
- **`mps.api.config.image_cache_path`** — directory path where the SQLite file is created. The component constructs `db_path` as `<image_cache_path>/image_cache.sqlite`.

---

## 5. Data Flow

### Write Flow (`set` / `update` / `delete` / `clear`)

```mermaid
sequenceDiagram
    participant C as Caller
    participant Cache as AsyncPersistentImageCache
    participant Lock as asyncio.Lock
    participant DB as SQLite (aiosqlite)

    C->>Cache: await set(key, value)
    Cache->>Cache: _execute(query, params)
    Cache->>Lock: acquire
    Lock-->>Cache: granted
    Cache->>DB: cursor.execute(query, params)
    Cache->>DB: commit()
    DB-->>Cache: ok
    Cache->>Lock: release
    Cache-->>C: returns
```

1. Caller invokes a write method.
2. The method delegates to `_execute`.
3. `_execute` acquires the write lock, runs the query within a cursor, commits, then releases the lock.

### Read Flow (`get` / `list`)

1. Caller invokes a read method.
2. A cursor executes the `SELECT` directly against the shared connection (no lock).
3. Results are fetched and mapped (`get` → single blob, `list` → dict).

---

## 6. Extension Points

The component is intentionally minimal. Common extensions:

- **Schema evolution / metadata**: Extend the `CREATE TABLE` statement in `__aenter__` to add columns (e.g., `created_at`, `content_type`, `ttl`). Existing read/write methods would need corresponding updates.
- **TTL / expiry**: Add an `expires_at` column and filter expired rows in `get`/`list`, plus a periodic eviction routine.
- **Connection pooling / sharing**: Currently each instance owns one connection scoped to an `async with` block. A subclass or wrapper could manage a long-lived shared connection for high-frequency access.
- **Read locking**: For strict consistency, override `get`/`list` to acquire `self.lock`.
- **Alternative backends**: Because the public interface (`get`/`set`/`update`/`delete`/`clear`/`list`) is storage-agnostic, an in-memory or remote (Redis) implementation could conform to the same async API, enabling polymorphic substitution.
- **Configurable path**: The constructor hardcodes the filename `image_cache.sqlite` under `image_cache_path`. Parameterizing the constructor (e.g., `__init__(self, filename=...)`) would allow multiple named caches.

---

## Notes & Caveats

- **No connection guard on operations**: Calling read/write methods outside the `async with` block (before `__aenter__` or after `__aexit__`) will fail because `self.conn` is `None` or closed. Always use the context manager.
- **Exception handling**: `__aexit__` closes the connection but does not roll back partial transactions; uncommitted writes are protected by the per-operation commit in `_execute`.
- **Blob size**: SQLite stores blobs inline. Very large images may impact performance; consider external file storage with DB-stored paths for large payloads.