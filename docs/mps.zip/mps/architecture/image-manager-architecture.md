---
id: d0b4f25c-a290-599c-a9d8-5c03c24ef5bd
type: architecture
title: "Image Manager Architecture"
created_at: 2026-06-06T19:03:40.087508+00:00
updated_at: 2026-06-20T22:55:26.823693+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/image_manager.py
metadata:
  source_name: "mps"
---
# Image Manager Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/image_manager.py`

# Image Manager Architecture


# Architecture Documentation: `mps.api.image_manager`

## 1. Component Overview

The `ImageManager` class is the central orchestration component responsible for the lifecycle of container images within the MPS (Model Prediction Service) platform. It encapsulates the full build-and-publish workflow: constructing Docker/OCI images from model artifacts, pushing them to a target destination, caching results to avoid redundant work, and managing image inventory (listing, sizing, and cleanup).

### Core Responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Image Construction** | Builds container images via `buildah` from a base image plus extracted model artifacts. |
| **Image Publishing** | Pushes images to a remote container registry (AWS, Azure, GCP, local) **or** exports them as compressed `.tar.gz` archives on local storage. |
| **Caching** | Maintains a persistent local cache (`AsyncPersistentImageCache`) to short-circuit rebuilds/re-pushes of existing images. |
| **Auxiliary Image Management** | Ensures supporting images (for Docker Compose pipelines) are present in the destination. |
| **Inventory & Cleanup** | Lists local/pushed images, computes total image size, and deletes stale local images. |
| **Compose Bundling** | Generates `.env` files for Docker Compose pipeline export. |

### Dual Operating Modes

A defining feature is the **bimodal output strategy** controlled by `export_image_as_file`:

- **Registry Mode** (`export_image_as_file=False`): Images are pushed to a remote OCI registry. Cache behaves as a true presence cache backed by remote registry checks.
- **Export Mode** (`export_image_as_file=True`): Images are serialized to compressed `docker-archive` files on disk. Cache behaves as a **Bloom-filter-like** hint backed by filesystem inspection.

---

## 2. Design Decisions

### Pluggable Token Management
`ImageManager` accepts a `TokenManager | AWSTokenManager` via constructor injection. This decouples authentication and registry-specific behavior (e.g., AWS ECR repository auto-creation) from image orchestration logic. AWS receives special handling (credential refresh + `create_repository`) detected via `isinstance` checks.

### Async-First with Subprocess Delegation
All I/O-bound operations (`buildah`, `skopeo`, `pigz`) are delegated to external CLI tools via `run_command`, and the entire surface is `async`. This allows concurrent execution of independent checks (e.g., `asyncio.gather` for cache + registry/storage lookups) and parallel auxiliary image pushes.

### Cache as Optimization, Not Source of Truth
Caching is treated as a *hint*. Every cache hit is validated against the actual destination (registry or filesystem). The four-state truth table (`exists_in_cache` × `already_exported`) drives self-healing logic—stale cache entries are removed, and discovered-but-uncached images are added.

```
(cache, dest) -> action
(True,  True)  -> return image_path        # confirmed
(True,  False) -> remove stale cache entry
(False, True)  -> add to cache, return     # repair
(False, False) -> rebuild required (None)
```

### Tool Choice Rationale
- **`buildah bud --layers`**: Enables daemonless builds with intermediate-layer caching.
- **`skopeo copy`**: Provides registry/archive-agnostic image transport without a Docker daemon.
- **`pigz`**: Parallel gzip for faster compression of exported archives.

### Mode Mutual Exclusion
Docker Compose export is explicitly incompatible with file-export mode and fails fast with a `500 PlainTextResponse` rather than producing a broken bundle.

---

## 3. Component Diagram

```mermaid
graph TB
    subgraph API["mps.api"]
        IM[ImageManager]
        TM[TokenManager]
        ATM[AWSTokenManager]
        Cache[AsyncPersistentImageCache]
        Errors[errors]
        Utils[utils]
        Config[config]
    end

    subgraph External["External Tools / Libs"]
        Buildah[buildah CLI]
        Skopeo[skopeo CLI]
        Pigz[pigz CLI]
        FS[(Local Filesystem)]
        Registry[(Container Registry)]
    end

    Caller[FastAPI Route / Service] -->|build_and_push, list_*, delete_*| IM

    IM -->|injected| TM
    IM -->|injected| ATM
    IM -->|set/get/delete/clear| Cache
    IM -->|construct_model_id, extract_model, run_command| Utils
    IM -->|repo_prefix, exported_image_path| Config
    IM -.->|raises| Errors

    IM -->|build images| Buildah
    IM -->|copy/inspect| Skopeo
    IM -->|compress archives| Pigz

    Skopeo -->|Registry Mode| Registry
    Skopeo -->|Export Mode| FS
    ATM -->|create_repository, get| Registry

    IM -->|returns| Caller
```

### Mode-Specific Data Path

```mermaid
flowchart LR
    Start[build_and_push] --> Build[buildah bud]
    Build --> Mode{export_image_as_file?}
    Mode -->|True| Export[skopeo copy → docker-archive]
    Export --> Compress[pigz → .tar.gz]
    Compress --> FileOut[(Local Archive)]
    Mode -->|False| Push[skopeo copy → docker://]
    Push --> RegOut[(Remote Registry)]
    FileOut --> CacheW[cache_image]
    RegOut --> CacheW
```

---

## 4. Interfaces

### Constructor

```python
ImageManager(
    token_manager: TokenManager | AWSTokenManager,
    export_image_as_file: bool = False
)
```

### Primary Public API

| Method | Purpose | Returns |
|--------|---------|---------|
| `login()` | Delegates authentication to the token manager. | `None` |
| `build_and_push(...)` | Full pipeline: build → push/export → optional compose bundle → cache. | `str` (image path) or `PlainTextResponse` (error) |
| `push_image(tag)` | Transports a built image to registry or archive. | `int` exit code (registry) or `str` archive path (export) |
| `list_local_images()` | Enumerates local images and refreshes cache. | `dict_keys` |
| `list_pushed_images()` | Queries remote registry `/v2/_catalog` for prefixed repos. | `dict[str, list]` |
| `get_if_image_exists(tag)` | Cache + destination validation with self-healing. | `str` path or `None` |
| `delete_local_images()` | Removes non-release and dangling images, clears cache. | `list` of deleted images |
| `get_size_of_images()` | Aggregate size of local images (static). | `int` bytes |
| `generate_env_file(image_path)` | Produces Docker Compose `.env` from template. | `str` |
| `upload_missing_auxiliary_images(tags)` | Ensures aux images exist in destination. | `None` (raises on failure) |

### Integration Points

- **Token Manager Protocol**: Requires `.login()`, `.registry`, `.verify_certificate_signing`, and `.session` (HTTP client). AWS variant additionally exposes `.session.create_repository(...)` and `.session.exceptions.RepositoryAlreadyExistsException`.
- **Cache Protocol**: `AsyncPersistentImageCache` used as async context manager exposing `set`, `delete`, `clear`.
- **FastAPI Contract**: Error paths return `PlainTextResponse(status_code=500)` for direct routing as HTTP responses.
- **Filesystem Contract**: `template/template.env` must exist; `exported_image_path` must be writable in export mode.

### Error Surface

| Exception | Trigger |
|-----------|---------|
| `UnavailableImage` | `buildah bud` non-zero exit. |
| `UnableToUploadOneOrMoreImages` | Any auxiliary image push fails. |
| `UnreachableContainerRegistry` | Registry catalog connection failure. |
| `UnableToObtainPushedImagesFromContainerRegistry` | Malformed/empty catalog response. |

---

## 5. Data Flow

### `build_and_push` Sequence

```mermaid
sequenceDiagram
    participant C as Caller
    participant IM as ImageManager
    participant TM as TokenManager
    participant Cache as ImageCache
    participant CLI as buildah/skopeo

    C->>IM: build_and_push(base_image, project_id, revision, ...)
    IM->>IM: validate (compose vs export mode)
    IM->>TM: construct_model_id() → tag
    IM->>IM: get_if_image_exists(docker_image_path)
    IM->>Cache: check_if_image_tag_exists_in_cache
    IM->>CLI: check existence (skopeo inspect / fs check)
    alt cached & valid
        IM-->>C: cached image path
    else not present
        IM->>IM: extract_model (unzip artifacts)
        IM->>IM: write temp Dockerfile
        IM->>CLI: buildah bud (build image)
        alt build fails
            CLI-->>IM: non-zero exit
            IM-->>C: raise UnavailableImage
        end
        IM->>IM: push_image()
        alt registry mode + AWS
            IM->>TM: login() + create_repository
        end
        IM->>CLI: skopeo copy (push or archive)
        opt export mode
            IM->>CLI: pigz (compress)
        end
        opt use_docker_compose
            IM->>IM: upload_missing_auxiliary_images
            IM->>IM: generate_env_file
            IM-->>C: .env content
        end
        IM->>Cache: cache_image()
        IM-->>C: image path
    end
```

### Key Data Transformations

1. **Model ID Construction**: `project_id` + `revision` → `tag` → `{registry}/{repo_prefix}/{tag}` image path.
2. **Artifact Extraction**: `model_filename` ZIP → unpacked into `{temp_directory}/models`.
3. **Dockerfile Synthesis**: In-memory string written to a `NamedTemporaryFile` scoped to the build context.
4. **Annotation Injection**: `annotations_list` mapped to repeated `--annotation k=v` flags (note: trailing-space sensitivity in shell parsing).
5. **Path-to-Filename**: `docker_image_to_file_name(tag)` converts image tags into filesystem-safe archive names for export mode.

---

## 6. Extension Points

### Adding a New Registry Provider
The primary extension axis is the **token manager**. To support a new provider:
1. Implement a class conforming to the `TokenManager` interface (`login`, `registry`, `verify_certificate_signing`, `session`).
2. If provider-specific pre-push behavior is needed (analogous to AWS repository creation), note that `push_image` currently uses an `isinstance(self.token_manager, AWSTokenManager)` branch.

> **Refactor opportunity**: The hardcoded `isinstance(..., AWSTokenManager)` check couples `ImageManager` to a concrete token type. Moving repository-provisioning logic into a polymorphic `token_manager.ensure_repository(name)` hook would eliminate this conditional and make new providers fully pluggable without modifying `ImageManager`.

### Customizing Output Strategy
The `export_image_as_file` flag toggles between registry push and file export. The `match self.export_image_as_file` blocks in `push_image`, `get_if_image_exists`, `check_if_