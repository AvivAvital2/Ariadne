---
id: 5637f86c-8445-57f7-aab0-4208276d6267
type: architecture
title: "Dockerfile Architecture"
created_at: 2026-07-03T05:58:31.331324+00:00
updated_at: 2026-07-03T05:58:31.331338+00:00
source_files:
  - /Users/spark/git/service-model-promotion/builder/Dockerfile
metadata:
  module_name: "stage0.Dockerfile"
  language: "dockerfile"
  provenance: "code-derived"
  source_name: "mps"
---
# Dockerfile Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/builder/Dockerfile`

# Architecture Documentation: `stage0.Dockerfile`

## 1. Component Overview

The `stage0.Dockerfile` defines a **foundational build/tooling container image** intended to serve as a base ("stage 0") for downstream build stages or development workflows. It assembles a polyglot toolchain on top of an official Python base image, combining:

- **Python 3.12.7** runtime and packaging tools (Poetry, AWS CLI)
- **Node.js 18.14.0** (via NVM) for JavaScript/TypeScript tooling
- **Container tooling** (Podman) for nested or rootless container operations
- **Source control and utilities** (Git, curl, pigz)
- **Document conversion** (`typora-parser` for parsing Typora Markdown exports)

Its primary responsibility is to provide a **consistent, reproducible environment** where multi-language automation—likely CI/CD pipelines, documentation generation, and AWS interactions—can execute.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Base on `python:3.12.7-bookworm`** | Pins a specific Python patch version on Debian Bookworm, ensuring reproducible builds and access to a mature apt ecosystem. |
| **Pin Poetry to `1.8.3`** | Locks dependency management behavior to avoid breaking changes across Poetry releases. |
| **Install Node via NVM (pinned `18.14.0`)** | NVM allows precise Node version control independent of distro packages; pinning avoids drift in JS tooling behavior. |
| **Use Podman instead of Docker** | Podman supports rootless/daemonless container operations, which is preferable inside CI containers and avoids Docker-in-Docker privilege concerns. |
| **`debian-archive-keyring` reinstall** | Defensive fix for apt GPG/key trust issues in the base image, ensuring package installation succeeds reliably. |
| **`pigz` inclusion** | Parallel gzip accelerates image layer compression/decompression in container-heavy workflows. |
| **Extend `PATH` to Node bin directory** | Makes the NVM-installed Node/npm globally available to non-interactive shells (which don't source `.bashrc`). |

> ⚠️ **Note:** The `--allow-unauthenticated` flag and keyring reinstall suggest a workaround for a specific apt trust problem. This is a fragility point worth revisiting (see Extension Points).

---

## 3. Component Diagram

```dot
digraph stage0 {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    base [label="python:3.12.7-bookworm\n(Base Image)", style="rounded,filled", fillcolor="#cce5ff"];

    subgraph cluster_python {
        label="Python Layer";
        style=dashed;
        poetry [label="Poetry 1.8.3\n(dependency mgmt)"];
        awscli [label="awscli\n(AWS integration)"];
    }

    subgraph cluster_system {
        label="System / OS Layer (apt)";
        style=dashed;
        keyring [label="debian-archive-keyring\n(trust fix)"];
        podman  [label="Podman\n(container runtime)"];
        git     [label="Git\n(SCM)"];
        curl    [label="curl"];
        pigz    [label="pigz\n(parallel gzip)"];
    }

    subgraph cluster_node {
        label="Node.js Layer";
        style=dashed;
        nvm    [label="NVM\n(version manager)"];
        node   [label="Node.js 18.14.0"];
        typora [label="typora-parser\n(npm global)"];
    }

    base -> poetry;
    base -> awscli;
    base -> keyring;
    base -> podman;
    base -> git;
    base -> curl;
    base -> pigz;

    curl -> nvm    [label="installs via script"];
    nvm  -> node   [label="provides"];
    node -> typora [label="npm install -g"];

    node -> path [style=dotted, label="exposed via PATH"];
    path [label="ENV PATH +=\n.nvm/.../node/v18.14.0/bin", shape=note, fillcolor="#fff2cc", style="filled"];
}
```

---

## 4. Interfaces

This component exposes its capabilities through the **container image contract** rather than code APIs:

### Environment Variables
| Variable | Value | Purpose |
|----------|-------|---------|
| `NODE_VERSION` | `18.14.0` | Single source of truth for the Node version installed and referenced in `PATH`. |
| `PATH` | Base `PATH` + NVM Node bin | Makes `node`, `npm`, and globally installed CLIs resolvable. |

### Command-Line Tools (integration points)
| Tool | Available As | Integration Purpose |
|------|--------------|--------------------|
| `python3` / `pip3` | On `PATH` (base image) | Python runtime & package installs |
| `poetry` | On `PATH` | Reproducible Python dependency resolution |
| `aws` | On `PATH` | AWS service interaction (S3, ECR, etc.) |
| `podman` | On `PATH` | Building/running containers within the image |
| `git` | On `PATH` | Source checkout and versioning |
| `node` / `npm` | Via extended `PATH` | JS tooling execution |
| `typora-parser` | npm global bin | Converting Typora Markdown documents |

### Consumption Contract
Downstream Dockerfiles or CI runners consume this image via:
```dockerfile
FROM <registry>/stage0:latest
```

---

## 5. Data Flow

The Dockerfile itself is **build-time only**; "data flow" refers to how the build process assembles the image and how runtime tools interact.

```dot
digraph dataflow {
    rankdir=LR;
    node [shape=box, fontname="Helvetica", style=rounded];

    src   [label="Base Image\nPull"];
    apt   [label="apt Registry\n(Debian mirrors)"];
    pypi  [label="PyPI\n(Poetry, awscli)"];
    gh    [label="GitHub\n(NVM install script)"];
    nvmdl [label="Node.js\ndistribution"];
    npmreg[label="npm Registry\n(typora-parser)"];
    image [label="Resulting\nstage0 Image", style="rounded,filled", fillcolor="#d5e8d4"];

    src   -> image;
    pypi  -> image [label="pip3 install"];
    apt   -> image [label="apt install"];
    gh    -> nvmdl [label="curl | bash"];
    nvmdl -> image [label="node runtime"];
    npmreg-> image [label="npm -g"];
}
```

**Build sequence (layer flow):**
1. Pull base Python image.
2. Update apt; install Python-side tools via `pip3` (Poetry, awscli).
3. Repair apt trust chain; install system packages (Podman, Git, curl, pigz).
4. Download and run the NVM install script from GitHub (installs Node 18.14.0).
5. Extend `PATH`; install `typora-parser` globally via npm.

**Runtime flow (when a container based on this image runs):**
- Consumer scripts invoke any of the installed CLIs; each resolves through the configured `PATH`.

---

## 6. Extension Points

### Recommended Customization Hooks

1. **Version overrides via build args**
   Convert hardcoded versions into `ARG`s to allow parameterized builds:
   ```dockerfile
   ARG NODE_VERSION=18.14.0
   ARG POETRY_VERSION=1.8.3
   ENV NODE_VERSION=${NODE_VERSION}
   RUN pip3 install poetry==${POETRY_VERSION} awscli
   ```

2. **Downstream stages (multi-stage builds)**
   Use this as `stage0` and layer application-specific stages:
   ```dockerfile
   FROM stage0 AS build
   # copy app, run poetry install, etc.
   ```

3. **Additional global npm tools**
   Append to the Node layer to install more JS CLIs, reusing the established `PATH`.

4. **Additional Python tooling**
   Extend the `pip3 install` line, or prefer a `poetry` lockfile-driven install in a downstream stage for reproducibility.

### Hardening / Maintenance Opportunities
- **Remove `--allow-unauthenticated`**: The keyring reinstall workaround should be replaced by proper key management once the root cause is resolved, reducing supply-chain risk.
- **Layer consolidation & cache cleanup**: Add `apt-get clean && rm -rf /var/lib/apt/lists/*` to shrink image size.
- **Pin apt packages**: Consider version-pinning `podman`, `git`, etc., for full reproducibility.
- **Non-root user**: For runtime consumers, add a dedicated non-root user to align with Podman's rootless philosophy.

---

### Summary
`stage0.Dockerfile` is a **base image assembly component** that unifies Python, Node.js, container, and AWS tooling into a single reproducible environment. Its design favors pinned versions and daemonless container tooling, at the cost of some apt-trust fragility that should be addressed in future iterations. Downstream stages extend it via `FROM` inheritance and additional tooling layers.