---
id: 033fc237-112b-54ee-875f-66971e4a86b9
type: architecture
title: "Promote Architecture"
created_at: 2026-06-06T19:04:31.337919+00:00
updated_at: 2026-06-20T22:55:26.808062+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/promote.py
metadata:
  source_name: "mps"
---
# Promote Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/promote.py`

# Promote Architecture


# Architecture Document: Model Promotion Router (`mps.routers.promote`)

## 1. Component Overview

The `mps.routers.promote` module is a **FastAPI router** responsible for the **Model Promotion** workflow within the Model Packaging Service (MPS). Its primary purpose is to take a trained model artifact and "promote" it into a deployable container image that is built and pushed to a target registry.

### Core Responsibilities

| Endpoint | Function | Responsibility |
|----------|----------|----------------|
| `GET /modelpromotion/promotion` | `get_promotion_status` | Reports promotion status *(currently a stub / `Todo`)* |
| `POST /modelpromotion/promotion/image/exists` | `is_image_exists` | Checks whether a promoted image already exists in the registry |
| `POST /modelpromotion/promotion/{project_id}/{revision}` | `promote` | Receives a model artifact, builds a container image, and pushes it to the registry |

The router acts as the **HTTP boundary layer** — it parses requests, resolves configuration, delegates heavy lifting to the `mps.service` layer (specifically `image_manager` and `token_manager`), and shapes the HTTP response.

---

## 2. Design Decisions

### 2.1 Thin Router, Delegated Business Logic
The router intentionally remains a **coordination layer**. Container build/push operations and registry interactions are delegated to the singleton `mps` service (`mps.image_manager`, `mps.token_manager`). This keeps HTTP concerns separate from packaging/registry concerns.

### 2.2 Streaming Upload to Temporary Directory
The `promote` endpoint writes the request body (model archive) to a **`TemporaryDirectory`** using **`aiofiles`** for non-blocking I/O. This avoids holding large model artifacts in memory longer than necessary and guarantees cleanup via the context manager.

### 2.3 Heterogeneous Parameter Passing
Parameters arrive via **three distinct channels**, reflecting client/proxy constraints:
- **Path parameters** — `project_id`, `revision` (resource identity)
- **Query string** — manually parsed via `parse_qs` and deserialized with `marshmallow_dataclass` into `PromoteParams`
- **HTTP headers** — `auxImages`, `X-Algorithm-Whitelist`, `X-ANNOTATIONS` (metadata that may be large or injected by gateways)

> **Rationale:** Query strings are manually parsed (rather than relying on FastAPI auto-binding) likely to support flexible/dynamic param sets and to control multi-value vs. single-value collapsing.

### 2.4 Registry-Provider Polymorphism
The response shape for `promote` branches on `mps.registry_provider`:
- `'export'` mode returns a **filename** (the image is exported to disk).
- Default mode returns the **image reference** directly.

This `match` statement isolates registry-specific behavior at the response boundary.

### 2.5 Plain-Text Responses
All endpoints return **`PlainTextResponse`** rather than JSON. This suggests the consumers are CLI tools or pipeline steps that expect raw image paths/identifiers, with HTTP status codes carrying semantic meaning (e.g., `404` for missing images).

### 2.6 Dual Export-Type Probing
`is_image_exists` probes both `compose` and `standalone` export variants, returning on the first match. This abstracts the export-type distinction away from callers.

---

## 3. Component Diagram

```mermaid
graph TD
    Client[HTTP Client / Pipeline]

    subgraph Router["mps.routers.promote"]
        GP[get_promotion_status<br/>GET /promotion]
        IE[is_image_exists<br/>POST /image/exists]
        PR[promote<br/>POST /{project_id}/{revision}]
    end

    subgraph API["mps.api"]
        Utils[utils<br/>resolve_base_image_id<br/>construct_model_id]
        Schemas[schemas<br/>PromoteParams, ImageParams]
        Config[config<br/>base_images, repo_prefix]
        Errors[errors<br/>NoConfigurationFoundError]
        Logger[logger]
    end

    subgraph Service["mps.service.mps (singleton)"]
        IM[image_manager<br/>build_and_push<br/>get_if_image_exists]
        TM[token_manager<br/>registry]
        RP[registry_provider]
    end

    Registry[(Container Registry<br/>/ Export Filesystem)]

    Client -->|requests| GP
    Client -->|requests| IE
    Client -->|requests| PR

    IE --> Utils
    IE --> Config
    IE --> IM
    IE --> TM

    PR --> Utils
    PR --> Schemas
    PR --> Config
    PR --> Errors
    PR --> Logger
    PR --> IM
    PR --> RP

    IM --> Registry
    TM --> Registry
```

---

## 4. Interfaces

### 4.1 Inbound HTTP Interface

#### `GET /modelpromotion/promotion`
- **Status:** Not implemented (stub).
- **Intended purpose:** Query the status of ongoing promotions.

#### `POST /modelpromotion/promotion/image/exists`
- **Request Body:** `ImageParams` (`project_id`, `revision`)
- **Behavior:** Constructs model IDs for `compose` and `standalone` export types, checks registry existence.
- **Responses:**
  - `200` — body contains the existing image path.
  - `404` — no matching image found.

#### `POST /modelpromotion/promotion/{project_id}/{revision}`
- **Path Params:** `project_id`, `revision`
- **Query Params:** Deserialized into `PromoteParams` — includes:
  - `epsReleaseNumber`, `linkedDataCore`, `openStreetMap`, `dockerCompose`
- **Headers:**
  | Header | Purpose |
  |--------|---------|
  | `auxImages` | Comma-separated auxiliary image list |
  | `X-Algorithm-Whitelist` | Algorithm whitelist (currently parsed but unused) |
  | `X-ANNOTATIONS` | JSON object → list of `key=value` annotations |
- **Body:** Raw model archive (`model.zip`).
- **Responses:**
  - `200` — image reference or exported filename.
  - `500` — `NoConfigurationFoundError` (no matching base image config).

### 4.2 Outbound Service Interface (`mps.service.mps`)

```python
# Registry / token
mps.token_manager.registry            # registry host
mps.registry_provider                 # 'export' | other

# Image lifecycle
await mps.image_manager.get_if_image_exists(full_image_path) -> str | None
await mps.image_manager.build_and_push(
    base_image, project_id, revision,
    temp_directory, model_filename,
    use_docker_compose, auxiliary_image_list, annotations_list
) -> str | PlainTextResponse
```

### 4.3 Utility / Config Interface (`mps.api`)

```python
await construct_model_id(project_id, revision) -> str
await resolve_base_image_id(base_images, release_version,
        use_linked_data_core, use_open_street_map,
        use_docker_compose) -> str   # raises NoConfigurationFoundError

base_images   # config: known base image definitions
repo_prefix   # config: registry repository prefix
```

---

## 5. Data Flow

### 5.1 `promote` Data Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant R as promote()
    participant U as api.utils
    participant Cfg as api.config
    participant FS as TempDir (aiofiles)
    participant IM as image_manager
    participant Reg as Registry/Export

    C->>R: POST /promotion/{project_id}/{revision}<br/>(query + headers + body)
    R->>R: parse_qs → PromoteParams
    R->>U: resolve_base_image_id(base_images, ...)
    U->>Cfg: read base_images
    alt no config match
        U-->>R: raise NoConfigurationFoundError
        R-->>C: 500 PlainText(detail)
    else resolved
        U-->>R: base_image_id
    end
    R->>R: parse auxImages / annotations headers
    R->>FS: write request body → model.zip
    R->>IM: build_and_push(base_image, ..., temp_directory)
    IM->>Reg: push or export image
    IM-->>R: image ref | PlainTextResponse
    alt registry_provider == 'export'
        R-->>C: 200 PlainText(basename(image))
    else
        R-->>C: PlainText(image)
    end
    Note over FS: TemporaryDirectory auto-cleaned
```

### 5.2 `is_image_exists` Data Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant R as is_image_exists()
    participant U as construct_model_id
    participant IM as image_manager

    C->>R: POST /image/exists (ImageParams)
    loop export_type in [compose, standalone]
        R->>U: construct_model_id(project_id_export_type, revision)
        U-->>R: tag
        R->>IM: get_if_image_exists(registry/prefix/tag)
        alt exists
            IM-->>R: image_path
            R-->>C: 200 PlainText(image_path)
        else
            IM-->>R: None
        end
    end
    R-->>C: 404
```

---

## 6. Extension Points

### 6.1 Implementing Promotion Status
`get_promotion_status` is a **stub (`# Todo`)**. To extend:
- Define a status store/query mechanism (e.g., in `image_manager` or a new tracking service).
- Bind path/query params and return status as `PlainTextResponse` or a structured response.

### 6.2 Adding Registry Providers
The `promote` response handling uses a `match mps.registry_provider:` block. New providers can be supported by adding `case` branches:
```python
match mps.registry_provider:
    case 'export': ...
    case 'my_new_provider': ...   # extension hook
    case _: ...                   # default
```

### 6.3 Extending Base Image Resolution
Build-target selection is centralized in `resolve_base_image_id` (`mps.api.utils`) driven by `base_images` config (`mps.api.config`). New build variants are added by:
- Extending `base_images` config entries.
- Adding corresponding flags to `PromoteParams` and threading them into `resolve_base_image_id`.

### 6.4 Additional Promotion Metadata
New header-driven metadata follows the established pattern:
```python
new_meta = request_obj.headers.get('X-NEW-META', None)
# parse → pass into build_and_push(...)
```
Note: `X-Algorithm-Whitelist` is **already parsed but currently unused** (`algorithm_list` commented out) — a ready-made hook for enabling algorithm filtering in `build_and_push`.

### 6.5 Export-Type Variants
`is_image_exists` iterates a hardcoded list `['compose', 'standalone']`. Adding new export types only requires extending this list (consider promoting it to `mps.api.config` for maintainability).

---

## 7. Notes & Observations for Maintainers

- **Hardcoded model filename:** `'model.zip'` is duplicated (`model_filename` and `file_path`). Consider centralizing.
- **Manual query parsing:** `parse_qs(str(request_obj.url).split("?")[-1])` bypasses FastAPI's native param binding; be cautious of URL-encoding edge cases.
- **Mixed response contract:** `build_and_push` may return either a `str` or a `PlainTextResponse`, requiring the `isinstance` check in `export`