---
id: d98122a7-0e11-538a-b1eb-fab3e1d96691
type: architecture
title: "Maintenance Architecture"
created_at: 2026-06-06T19:04:24.901339+00:00
updated_at: 2026-06-20T22:55:26.796759+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/routers/maintenance.py
metadata:
  source_name: "mps"
---
# Maintenance Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/routers/maintenance.py`

# Maintenance Architecture


# Architecture Documentation: Maintenance Router

**Module**: `mps.routers.maintenance`

---

## 1. Component Overview

The Maintenance Router is a FastAPI sub-router within the Model Promotion Service (MPS) that exposes administrative and diagnostic endpoints for managing exported container images. Its primary responsibilities are:

- **Image inventory**: Listing images stored locally on disk after export.
- **Storage management**: Deleting locally-cached images to reclaim disk space.
- **Capacity reporting**: Calculating and reporting the total on-disk size of exported images in human-readable form.
- **Registry visibility**: Listing images that have been pushed to the configured remote container registry.

This module is intentionally a **gated, opt-in feature**. The entire set of routes is only registered when the service runs in maintenance mode, isolating potentially destructive and diagnostic operations from the standard operational surface.

---

## 2. Design Decisions

### Environment-Gated Route Registration
The most significant architectural decision is that all routes are conditionally defined inside an `if` block keyed on the `MAINTENANCE_MODE` environment variable:

```python
troubleshoot = os.environ.get('MAINTENANCE_MODE')
if troubleshoot and troubleshoot.lower() == 'true':
    # routes defined here
```

**Rationale**:
- **Reduced attack/operational surface**: Destructive operations (e.g., `delete_local_images`) are not exposed during normal operation.
- **Clear separation of concerns**: Troubleshooting tooling is segregated from the production API contract.
- **Zero-overhead opt-in**: When disabled, the router carries no maintenance endpoints at all rather than relying on runtime authorization checks per request.

### Thin Router / Delegated Business Logic
The router functions contain no business logic of their own. Each handler delegates directly to `mps.image_manager`, which centralizes all image lifecycle operations. This keeps the router as a thin HTTP adapter layer (transport concern only).

### Explicit Response Type Selection
The handlers deliberately choose different response types based on the nature of the payload:
- `list_images` / `delete_local_images` return raw lists serialized via `response_model=list[str]`.
- `get_total_images_size` returns a `PlainTextResponse` because the formatted size is a human-readable string, not structured data.
- `remote_images` returns a `JSONResponse` wrapping the registry listing.

### Async I/O Throughout
All handlers are `async` and await `image_manager` coroutines, aligning with FastAPI's async model and the I/O-bound nature of disk and registry operations.

### Dynamic Documentation Strings
Endpoint `summary` text is interpolated with `mps.registry_provider`, so OpenAPI docs accurately name the active registry backend without hardcoding.

---

## 3. Component Diagram

```mermaid
graph TD
    Client[Admin / Operator Client]

    subgraph FastAPI["FastAPI Application"]
        Router["maintenance.router<br/>(APIRouter, tags=[Maintenance])"]
    end

    subgraph Routes["Conditionally Registered Routes<br/>(MAINTENANCE_MODE == true)"]
        L["GET /local_images<br/>list_images"]
        D["DELETE /local_images<br/>delete_local_images"]
        S["GET /total_image_size<br/>get_total_images_size"]
        R["GET /list_pushed_images<br/>remote_images"]
    end

    subgraph Service["mps.service"]
        MPS["mps"]
        IM["image_manager"]
        RP["registry_provider"]
    end

    Logger["mps.api.logger"]
    Env["ENV: MAINTENANCE_MODE"]
    HF["humanfriendly.format_size"]

    Client -->|HTTP| Router
    Router --> L
    Router --> D
    Router --> S
    Router --> R

    Env -.gates.-> Routes
    Router -.logs registration.-> Logger

    L --> IM
    D --> IM
    S --> IM
    R --> IM

    S --> HF

    MPS --> IM
    MPS --> RP
    Routes -.references.-> RP
```

---

## 4. Interfaces

### Exposed HTTP Endpoints

> All endpoints are prefixed under `/modelpromotion/maintenance` and only available when `MAINTENANCE_MODE=true`.

| Method | Path | Handler | Response | Description |
|--------|------|---------|----------|-------------|
| `GET` | `/modelpromotion/maintenance/local_images` | `list_images` | `list[str]` (JSON) | Lists images exported and cached locally. |
| `DELETE` | `/modelpromotion/maintenance/local_images` | `delete_local_images` | `list[str]` (JSON) | Deletes locally cached images; pushed copies remain in the registry. |
| `GET` | `/modelpromotion/maintenance/total_image_size` | `get_total_images_size` | `str` (plain text) | Human-readable total disk usage of exported images. |
| `GET` | `/modelpromotion/maintenance/list_pushed_images` | `remote_images` | JSON | Lists images pushed to the remote container registry. |

### Downstream Service Interface (`mps.image_manager`)

The router depends on the following coroutine contract:

| Method | Returns | Used By |
|--------|---------|---------|
| `list_local_images()` | `list[str]` | `list_images` |
| `delete_local_images()` | `list[str]` | `delete_local_images` |
| `get_size_of_images()` | numeric (bytes) | `get_total_images_size` |
| `list_pushed_images()` | JSON-serializable | `remote_images` |

### Integration Points
- **`mps.service.mps`**: Singleton service facade providing `image_manager` and `registry_provider`.
- **`mps.api.logger`**: Logs route registration at debug level.
- **`humanfriendly.format_size`**: Converts byte counts into human-readable size strings.
- **`MAINTENANCE_MODE` env var**: Controls whether the router registers any routes.

---

## 5. Data Flow

### Example: Total Image Size Request

```mermaid
sequenceDiagram
    participant C as Client
    participant R as maintenance.router
    participant IM as mps.image_manager
    participant HF as format_size
    participant FS as Local Disk

    C->>R: GET /total_image_size
    R->>IM: await get_size_of_images()
    IM->>FS: scan image storage
    FS-->>IM: raw byte total
    IM-->>R: size (bytes)
    R->>HF: format_size(bytes)
    HF-->>R: "1.2 GB"
    R-->>C: PlainTextResponse("1.2 GB")
```

### General Flow Pattern
1. A client issues an HTTP request to a maintenance endpoint (only resolvable if the service started in maintenance mode).
2. The thin handler awaits the corresponding `image_manager` coroutine.
3. `image_manager` performs the actual disk or registry operation.
4. The result is wrapped in the appropriate response type:
   - Lists/JSON → automatic serialization or `JSONResponse`.
   - Size → formatted with `humanfriendly` and returned as `PlainTextResponse`.
5. The response is returned to the client.

There is **no transformation or validation logic** in the router beyond response-type wrapping; data integrity is the responsibility of `image_manager`.

---

## 6. Extension Points

### Adding a New Maintenance Endpoint
New diagnostic or administrative operations should follow the established pattern:
1. Define the operation on `mps.image_manager` (or the relevant service component) as an `async` method.
2. Add a handler inside the `MAINTENANCE_MODE` guard block, delegating to the service.
3. Choose an appropriate response type (`response_model`, `JSONResponse`, or `PlainTextResponse`).
4. Interpolate dynamic context (e.g., `mps.registry_provider`) into the `summary` for accurate OpenAPI docs.

### Changing the Activation Condition
The gating logic (`MAINTENANCE_MODE == 'true'`) is a single, centralized check. To support additional modes or finer-grained access (e.g., role-based gating), this conditional is the natural extension point. Consider promoting it to a configuration object if more flags are added.

### Swapping the Registry Backend
Because endpoint summaries and behavior reference `mps.registry_provider` rather than a hardcoded provider name, the registry implementation can change behind `image_manager` without altering this router.

### Customizing Output Formatting
The size formatting via `humanfriendly.format_size` is isolated to a single handler. Alternative formatting (e.g., binary units, JSON-structured size) can be introduced there without affecting other endpoints.

---

## Notes & Considerations

- **Destructive operation safety**: `delete_local_images` is unguarded beyond the maintenance-mode gate (no confirmation parameter or authorization). Consumers should ensure maintenance mode is only enabled in controlled environments.
- **Consistency of response types**: The mixed use of `response_model`, `JSONResponse`, and `PlainTextResponse` is intentional but should be kept consistent per data shape when extending.
- **Documentation visibility**: When maintenance mode is active, these endpoints appear under `/modelpromotion/docs`, as logged during registration.