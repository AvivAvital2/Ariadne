---
id: 86d99884-0f6d-51ac-ac58-cf5ff978ed25
type: architecture
title: "Promotion Architecture"
created_at: 2026-06-06T19:04:43.001973+00:00
updated_at: 2026-06-20T22:55:26.819123+00:00
source_files:
  - /Users/spark/git/service-model-promotion/promotion.conf
metadata:
  source_name: "mps"
---
# Promotion Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/promotion.conf`

# Promotion Architecture


# Promotion Module — Architecture Documentation

## 1. Component Overview

The `promotion` module is responsible for **model promotion** within the SparkBeyond prediction platform. Model promotion is the process of taking a trained prediction model and packaging/deploying it into a runnable prediction server image suitable for a target environment.

Based on the available configuration, the module's primary responsibilities are:

- **Base image resolution** — mapping a platform version and deployment flavor (e.g., `aio`, `osm`, `gdata`, `minimal`) to a concrete container image reference used as the runtime base for a promoted model.
- **Outbound HTTP connectivity** — providing a configurable HTTP client (with optional proxy and proxy authentication) used to communicate with external services such as the container registry (`reg.sparkbeyond.com`) and other downstream endpoints during the promotion flow.
- **Promotion authentication policy** — controlling whether authentication is enforced on the model promotion entry points.

> **Note:** The source provided is configuration (HOCON). This document reflects the *configuration-driven architecture* of the module. Runtime behavior is inferred from the configuration surface and standard conventions.

---

## 2. Design Decisions

| Decision | Rationale (as evident from config) |
|----------|-----------------------------------|
| **Externalized configuration via HOCON** | Promotion behavior (proxy, base images, auth) is fully data-driven, allowing environment-specific overrides without code changes. |
| **Version + flavor → image mapping** (`baseImage.<version>.<flavor>`) | Promoted models must run on a runtime that matches a specific platform release and feature set. A keyed lookup table decouples model artifacts from the runtime image, enabling multiple coexisting versions. |
| **Configurable HTTP proxy with optional auth** | The promotion process operates in enterprise/restricted networks where outbound traffic (e.g., pulling/pushing registry images) must traverse a corporate proxy. Proxy and proxy-auth are independently toggleable. |
| **Pluggable promotion auth (`modelpromotion.auth.enabled`)** | Authentication on promotion endpoints can be disabled (e.g., in trusted internal deployments) or enabled for hardened environments. Defaults to `off`, favoring frictionless internal use. |

### Image Flavors

| Flavor | Intended Use |
|--------|--------------|
| `aio` | All-in-one image; bundles all capabilities. |
| `osm` | Open-source/maps-oriented variant (inferred). |
| `gdata` | Variant bundling geospatial / generated data assets (inferred). |
| `minimal` | Stripped-down base with core prediction-server only. |

---

## 3. Component Diagram

```mermaid
graph TD
    subgraph PromotionModule["promotion Module"]
        AuthGate["Promotion Auth Gate<br/>(modelpromotion.auth.enabled)"]
        ImageResolver["Base Image Resolver<br/>(baseImage.&lt;ver&gt;.&lt;flavor&gt;)"]
        HttpClient["HTTP Client<br/>(httpClient.proxy.*)"]
        Config["HOCON Configuration"]
    end

    Caller["Promotion Request<br/>(API / CLI / Service)"] --> AuthGate
    AuthGate --> ImageResolver
    ImageResolver --> HttpClient

    Config -.configures.-> AuthGate
    Config -.configures.-> ImageResolver
    Config -.configures.-> HttpClient

    HttpClient -->|optional proxy| Proxy["HTTP Proxy<br/>host:port"]
    Proxy --> Registry["Container Registry<br/>reg.sparkbeyond.com"]
    HttpClient -->|direct when proxy disabled| Registry

    ImageResolver -->|resolved image ref| Output["Promoted Model<br/>Runtime Image"]
```

---

## 4. Interfaces

### 4.1 Configuration Interface (HOCON)

The module is configured through the following keys:

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `httpClient.proxy.enabled` | boolean | `false` | Enables routing of outbound HTTP traffic through a proxy. |
| `httpClient.proxy.config.host` | string | `""` | Proxy host. |
| `httpClient.proxy.config.port` | int | `3128` | Proxy port. |
| `httpClient.proxy.authentication.enabled` | boolean | `false` | Enables proxy authentication. |
| `httpClient.proxy.authentication.username` | string | `""` | Proxy auth username. |
| `httpClient.proxy.authentication.password` | string | `""` | Proxy auth password (handle as a secret). |
| `baseImage.<version>.<flavor>` | string | — | Maps a platform version + flavor to a container image reference. |
| `modelpromotion.auth.enabled` | boolean (`on`/`off`) | `off` | Toggles authentication on promotion endpoints. |

### 4.2 Integration Points

- **Container Registry** (`reg.sparkbeyond.com`) — source/target for the prediction-server base images. Reached via the configured HTTP client, optionally through a proxy.
- **HTTP Proxy** — corporate egress proxy used when `httpClient.proxy.enabled = true`.
- **Authentication subsystem** — invoked by the promotion entry point when `modelpromotion.auth.enabled = on`.

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant Client as Promotion Request
    participant Auth as Auth Gate
    participant Resolver as Image Resolver
    participant Http as HTTP Client
    participant Proxy as Proxy (optional)
    participant Reg as Container Registry

    Client->>Auth: promote(model, version, flavor)
    alt auth.enabled = on
        Auth->>Auth: validate credentials
    end
    Auth->>Resolver: resolve(version, flavor)
    Resolver->>Resolver: lookup baseImage.<version>.<flavor>
    Resolver-->>Http: image reference
    alt proxy.enabled = true
        Http->>Proxy: request (+ proxy auth if enabled)
        Proxy->>Reg: forward request
    else proxy disabled
        Http->>Reg: direct request
    end
    Reg-->>Http: base image / status
    Http-->>Client: promoted model image result
```

**Summary of flow:**
1. A promotion request enters the module and passes through the **Auth Gate** (enforced only when `modelpromotion.auth.enabled = on`).
2. The **Image Resolver** maps the requested `(version, flavor)` to a concrete base image reference using the `baseImage.*` table.
3. The **HTTP Client** performs registry communication, transparently routing through the proxy (with optional proxy auth) when enabled.
4. The resolved/promoted runtime image is returned to the caller.

---

## 6. Extension Points

| Extension | How to Customize |
|-----------|------------------|
| **Add a new platform version** | Add a `baseImage.<new-version>.<flavor>` block mirroring existing flavors (e.g., `baseImage.3-1-0.aio`). |
| **Add a new image flavor** | Introduce a new key under an existing version (e.g., `baseImage.3-0-0.gpu = "..."`). Resolver lookups become available immediately. |
| **Operate behind a corporate proxy** | Set `httpClient.proxy.enabled = true` and configure `host`/`port`; enable `httpClient.proxy.authentication` with credentials if required. |
| **Harden promotion endpoints** | Set `modelpromotion.auth.enabled = on` to require authentication on promotion operations. |
| **Environment-specific overrides** | Override any of the above keys in environment-specific HOCON layers (e.g., `application-prod.conf`) without modifying defaults. |

### Maintenance Notes
- Keep the `baseImage` table synchronized with available registry tags; a missing mapping will cause promotion to fail for that `(version, flavor)`.
- Treat `httpClient.proxy.authentication.password` as a secret — prefer injecting it via environment variables or a secrets manager rather than committing it.
- The `on`/`off` style for `modelpromotion.auth.enabled` and the `true`/`false` style for proxy flags are both valid HOCON booleans; keep usage consistent within a given config layer for readability.