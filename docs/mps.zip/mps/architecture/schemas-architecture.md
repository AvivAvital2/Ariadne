---
id: e5204704-c07e-5c7c-b936-aff89b64085c
type: architecture
title: "Schemas Architecture"
created_at: 2026-06-06T19:03:52.020209+00:00
updated_at: 2026-06-20T22:55:26.793840+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/api/schemas.py
metadata:
  source_name: "mps"
---
# Schemas Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/api/schemas.py`

# Schemas Architecture


# Architecture Documentation: `mps.api.schemas`

## 1. Component Overview

The `mps.api.schemas` module defines the **data contract layer** for the MPS API. It contains a set of schema/dataclass definitions that describe the structure, validation rules, and serialization/deserialization behavior of data exchanged at API boundaries.

Each class represents a discrete data shape used in API request handling and image management operations:

| Class | Responsibility |
|-------|----------------|
| `Flavours` | Defines the set of available image flavours (variants). |
| `BaseImages` | Wraps a `Flavours` collection and post-processes version data into a normalized dictionary. |
| `PromoteParams` | Captures parameters for a promotion operation, including feature toggles. |
| `AuxiliaryImage` | Represents a single auxiliary image with an `image` name and `tag`. |
| `AuxiliaryImages` | Parses a collection of `image:tag` strings into `AuxiliaryImage` instances. |
| `ImageParams` | Identifies an image by `project_id` and `revision`. |

The module's primary role is to provide **declarative, validated boundary types** that decouple raw transport data (JSON, query parameters, environment inputs) from the rest of the application's business logic.

---

## 2. Design Decisions

### 2.1 Schema-as-Dataclass via `marshmallow_dataclass`
The module leverages `marshmallow_dataclass.dataclass` rather than hand-written `marshmallow.Schema` subclasses. This provides:

- **Single source of truth**: field types and validation derive directly from Python type annotations.
- **Reduced boilerplate**: no need to maintain a parallel schema definition for each dataclass.
- **Automatic schema generation**: each decorated class gets an associated `Schema` accessible for `load`/`dump`.

### 2.2 Lifecycle Hooks for Data Normalization
Two distinct normalization strategies appear in the code, reflecting different lifecycle integration points:

- **Marshmallow `@post_load`** (`BaseImages.make_versions_dict`): runs after marshmallow deserialization, allowing transformation of validated input (normalizing version keys by replacing `-` with `_`).
- **Dataclass `__post_init__`** (`AuxiliaryImages`): runs after standard dataclass construction, parsing a raw string list into structured `AuxiliaryImage` objects.

> **Note**: The mixing of both hook styles is a key architectural characteristic. `@post_load` integrates with the marshmallow deserialization pipeline, while `__post_init__` operates on direct instantiation. Consumers must be aware of which path triggers which hook.

### 2.3 Default-Driven Feature Toggles
`PromoteParams` uses boolean fields with `False` defaults (`dockerCompose`, `linkedDataCore`, `knowledgeServer`, `openStreetMap`). This makes feature flags **opt-in** and keeps the request payload minimal for callers who only need defaults.

### 2.4 Validation at the Boundary
`AuxiliaryImages` raises `marshmallow.ValidationError` for malformed `image:tag` strings, ensuring invalid data is rejected early at the parsing stage rather than propagating into downstream logic.

---

## 3. Component Diagram

```mermaid
classDiagram
    class Flavours {
        +str minimal
        +str gdata
        +str osm
        +str aio
    }

    class BaseImages {
        +Flavours images
        +make_versions_dict(data) post_load
    }

    class PromoteParams {
        +str epsReleaseNumber
        +bool dockerCompose = False
        +bool linkedDataCore = False
        +bool knowledgeServer = False
        +bool openStreetMap = False
    }

    class AuxiliaryImage {
        +str image
        +str tag = "latest"
    }

    class AuxiliaryImages {
        +str images_str
        +list~AuxiliaryImage~ images
        +__post_init__()
    }

    class ImageParams {
        +str project_id
        +str revision
    }

    BaseImages --> Flavours : contains
    AuxiliaryImages --> AuxiliaryImage : builds list of

    note for BaseImages "Uses marshmallow @post_load hook"
    note for AuxiliaryImages "Uses dataclass __post_init__ hook"
```

```mermaid
flowchart LR
    subgraph External
        MM[marshmallow]
        MMDC[marshmallow_dataclass]
    end

    subgraph schemas[mps.api.schemas]
        F[Flavours]
        BI[BaseImages]
        PP[PromoteParams]
        AI[AuxiliaryImage]
        AIS[AuxiliaryImages]
        IP[ImageParams]
    end

    MMDC -. "@dataclass decorator" .-> schemas
    MM -. "ValidationError, post_load" .-> schemas
```

---

## 4. Interfaces

### 4.1 Generated Schema Interface
Because each class is decorated with `marshmallow_dataclass.dataclass`, marshmallow generates an associated schema. The conventional integration points are:

| Operation | Method | Purpose |
|-----------|--------|---------|
| Deserialize | `Schema().load(payload)` | Convert raw dict/JSON into a validated dataclass instance. |
| Serialize | `Schema().dump(instance)` | Convert a dataclass instance back into a dict. |
| Construct | `ClassName(...)` | Direct instantiation (triggers `__post_init__` where defined). |

### 4.2 Class Contracts

- **`Flavours`**: Requires all four fields (`minimal`, `gdata`, `osm`, `aio`) as strings.
- **`BaseImages`**: Expects a nested `images` (`Flavours`). On `post_load`, normalizes `versions` keys (`-` → `_`).
- **`PromoteParams`**: Requires `epsReleaseNumber`; all feature flags optional.
- **`AuxiliaryImage`**: Requires `image`; `tag` defaults to `"latest"`.
- **`AuxiliaryImages`**: Accepts `images_str` (an iterable of `image:tag` strings); produces a parsed `images` list. Raises `ValidationError` on malformed entries.
- **`ImageParams`**: Requires `project_id` and `revision`.

### 4.3 Error Surface
- `marshmallow.ValidationError` — raised on schema validation failures and explicitly within `AuxiliaryImages` parsing.

---

## 5. Data Flow

### 5.1 Marshmallow Deserialization Path (`BaseImages`)

```mermaid
sequenceDiagram
    participant Caller
    participant Schema as BaseImages Schema
    participant Hook as make_versions_dict

    Caller->>Schema: load(raw_dict)
    Schema->>Schema: validate fields & nested Flavours
    Schema->>Hook: @post_load(data)
    Hook->>Hook: normalize version keys ("-"→"_")
    Hook-->>Schema: transformed data
    Schema-->>Caller: validated result
```

### 5.2 Direct Construction Path (`AuxiliaryImages`)

```mermaid
sequenceDiagram
    participant Caller
    participant AIS as AuxiliaryImages
    participant AI as AuxiliaryImage

    Caller->>AIS: AuxiliaryImages(images_str)
    AIS->>AIS: __post_init__()
    loop each item in images_str
        AIS->>AIS: split on ":"
        alt 1 part
            AIS->>AI: AuxiliaryImage(parts)
        else 2 parts
            AIS->>AI: AuxiliaryImage(image, tag)
        else >2 parts
            AIS-->>Caller: raise ValidationError
        end
    end
    AIS-->>Caller: instance with images list
```

> **Implementation Caveat**: In the `case 1` branch, `AuxiliaryImage(parts)` passes the entire `parts` list rather than `parts[0]`. Consumers and maintainers should review this against intended single-value behavior (likely should be `AuxiliaryImage(parts[0])`).

### 5.3 Pass-Through Types
`PromoteParams` and `ImageParams` perform no custom processing — they map directly between transport data and typed instances, relying on marshmallow validation only.

---

## 6. Extension Points

### 6.1 Adding New Schema Types
New boundary types should follow the established pattern:
```python
@dataclass
class NewParams:
    required_field: str
    optional_field: bool = False
```
Decorating with `marshmallow_dataclass.dataclass` automatically yields a validating schema.

### 6.2 Custom Post-Load Transformation
To add normalization after deserialization, attach a `@post_load`-decorated method (as in `BaseImages`):
```python
@post_load
def normalize(self, data, **kwargs):
    # transform validated data
    return data
```

### 6.3 Construction-Time Parsing
For types that must derive structured fields from raw inputs at instantiation, implement `__post_init__` (as in `AuxiliaryImages`). Use this for inputs that bypass the marshmallow pipeline.

### 6.4 Adding Feature Toggles
Extend `PromoteParams` with additional boolean defaults to introduce new opt-in capabilities without breaking existing callers:
```python
newFeature: bool = False
```

### 6.5 Custom Validation
Raise `marshmallow.ValidationError` within hooks or methods to enforce domain-specific constraints, consistent with the validation strategy in `AuxiliaryImages`.

---

## Maintenance Notes

- **Hook consistency**: Be deliberate about choosing `@post_load` vs `__post_init__` based on whether the type is created via marshmallow `load()` or direct construction.
- **Naming conventions**: `PromoteParams` uses `camelCase` field names (transport-aligned), while other types use `snake_case`. Maintain consistency with the external contract each schema represents.
- **Known issue**: Review the `case 1` branch in `AuxiliaryImages.__post_init__` (see §5.2 caveat).