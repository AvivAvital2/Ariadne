---
id: 5eb0a385-9400-545e-8dee-04cb56dc9f8e
type: architecture
title: "  Main   Architecture"
created_at: 2026-06-06T19:03:08.785994+00:00
updated_at: 2026-06-20T22:55:26.793197+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/__main__.py
metadata:
  source_name: "mps"
---
#   Main   Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/__main__.py`

#   Main   Architecture


# Architecture Documentation: `mps.__main__`

## 1. Component Overview

The `mps.__main__` module serves as the **application entry point and composition root** for the SparkBeyond Model Promotion Service (MPS). It is responsible for:

- **Application bootstrapping**: Instantiating and configuring the FastAPI application.
- **Router aggregation**: Wiring together the service's HTTP route handlers (`basic`, `promote`, `maintenance`).
- **Runtime configuration**: Reading build metadata and environment-driven settings (maintenance mode, host, port).
- **Lifecycle orchestration**: Performing an authentication/login step before the server begins serving requests.
- **Server startup**: Launching the ASGI server (Uvicorn) to host the application.

This module is the binding layer that brings together independent subsystems (routing, service logic, authentication) into a single runnable process.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **FastAPI as the web framework** | Provides built-in OpenAPI/ReDoc documentation, async support, and dependency-injection-friendly routing—well-suited for a service with multiple routers. |
| **Router-based modularization** | Each concern (`basic`, `promote`, `maintenance`) is encapsulated in its own router module, keeping the entry point thin and focused on composition. |
| **`include_in_schema=False` on `basic` and `promote`** | These internal endpoints are intentionally hidden from the public OpenAPI schema, reducing the documented surface to externally relevant operations. Only `maintenance` is exposed in the schema. |
| **Maintenance mode toggling via environment variable** | Allows the documentation endpoints (`/docs`, `/redoc`, `/openapi.json`) to be relocated under the `/modelpromotion/...` path namespace at runtime, supporting reverse-proxy / gateway routing scenarios without code changes. |
| **Version sourced from `conf/build.info`** | Decouples the deployed version metadata from source code, allowing the build pipeline to inject the canonical version tag. |
| **Pre-startup async `login()`** | Ensures the service authenticates (acquires a token) *before* accepting traffic, preventing the first inbound requests from failing due to missing credentials. |
| **Environment-driven host/port** | Twelve-factor style configuration; deployment targets supply `SERVICE_HOST` / `SERVICE_PORT` without modifying code. |

---

## 3. Component Diagram

```mermaid
graph TD
    subgraph Entry["mps.__main__"]
        MAIN["main() — async login bootstrap"]
        APP["FastAPI app (composition root)"]
        CONF["Config loader<br/>(build.info + env vars)"]
    end

    subgraph Routers["mps.routers"]
        BASIC["basic.router<br/>(hidden from schema)"]
        PROMOTE["promote.router<br/>(hidden from schema)"]
        MAINT["maintenance.router<br/>(in schema)"]
    end

    subgraph Service["mps.service"]
        MPS["mps service"]
        TOKEN["token_manager"]
    end

    subgraph External["External Runtime"]
        UVICORN["uvicorn ASGI server"]
        ENV["Environment Variables"]
        BUILDINFO["conf/build.info"]
    end

    CONF -->|reads| BUILDINFO
    CONF -->|reads| ENV
    CONF -->|configures| APP

    APP -->|include_router| BASIC
    APP -->|include_router| PROMOTE
    APP -->|include_router| MAINT

    MAIN -->|await login| TOKEN
    MPS --> TOKEN

    UVICORN -->|hosts| APP
    Entry -->|asyncio.run| MAIN
    Entry -->|uvicorn.run| UVICORN
```

---

## 4. Interfaces

### Inbound Interfaces (HTTP)
The composed FastAPI `app` exposes three router-mounted interface groups:

| Router | Schema Visibility | Purpose (inferred) |
|--------|-------------------|--------------------|
| `basic.router` | Hidden | Core/internal operations (e.g., health, root) |
| `promote.router` | Hidden | Model promotion operations |
| `maintenance.router` | Visible | Maintenance/operational endpoints |

### Documentation Endpoints
- **Default mode**: `/docs`, `/redoc`, `/openapi.json`
- **Maintenance mode** (`MAINTENANCE_MODE=true`): `/modelpromotion/docs`, `/modelpromotion/redoc`, `/modelpromotion/openapi.json`

### Outbound / Integration Points
- **`mps.service.mps.token_manager.login()`** — async authentication call invoked at startup.
- **`conf/build.info`** — JSON file read at import time; must contain a `version_tag` key.

### Configuration Surface (Environment Variables)
| Variable | Default | Effect |
|----------|---------|--------|
| `MAINTENANCE_MODE` | `False` | Relocates documentation endpoints under `/modelpromotion/` |
| `SERVICE_PORT` | `8010` | Server listening port |
| `SERVICE_HOST` | `0.0.0.0` | Server bind address |

---

## 5. Data Flow

### Startup Sequence

```mermaid
sequenceDiagram
    participant OS as OS / Runtime
    participant Main as mps.__main__
    participant Conf as build.info / env
    participant App as FastAPI app
    participant Token as token_manager
    participant Uvicorn as Uvicorn

    OS->>Main: Execute module
    Main->>Conf: Read version_tag + env vars
    Main->>App: Construct FastAPI(**params)
    Main->>App: include_router(basic, promote, maintenance)
    Main->>Token: asyncio.run(main()) → await login()
    Token-->>Main: Authenticated (token acquired)
    Main->>Uvicorn: uvicorn.run(app, host, port)
    Uvicorn-->>OS: Serving HTTP requests
```

### Request-Time Flow
1. An HTTP request arrives at the Uvicorn server.
2. FastAPI routes it to the matching router (`basic`, `promote`, or `maintenance`).
3. The router handlers delegate to `mps.service` logic, which relies on the authenticated `token_manager` context established at startup.

> **Note:** The `await login()` step runs *before* `uvicorn.run`. This is a one-time pre-flight authentication. If the service relies on token refresh during runtime, that responsibility lives within `token_manager`, not this entry point.

---

## 6. Extension Points

### Adding New Endpoints
Create a new router module under `mps.routers` and register it in the composition root:

```python
from mps.routers import new_feature
app.include_router(new_feature.router)  # add include_in_schema=False to hide
```

### Controlling Schema Visibility
Toggle the `include_in_schema` flag per router to control public API documentation exposure.

### Configuration Extension
Additional runtime behaviors should follow the established environment-variable pattern (read via `os.environ.get` with sensible defaults), keeping the module twelve-factor compliant.

### Startup Hooks
The current `main()` coroutine performs login. Additional async startup tasks (cache warming, connection pools) can be added here. **Recommendation:** For richer lifecycle management, consider migrating to FastAPI's `lifespan` context manager so startup/shutdown logic is bound to the app rather than executed pre-server.

### Documentation Path Strategy
The `MAINTENANCE_MODE` namespacing pattern can be generalized into a configurable path-prefix scheme if more deployment topologies (e.g., multiple gateway prefixes) are required.

---

## Maintenance Notes / Observations

- **Port type mismatch risk**: `os.environ.get("SERVICE_PORT", 8010)` returns a *string* when the env var is set, but Uvicorn expects an `int`. Consider wrapping with `int(...)` to avoid runtime errors.
- **Import-time file dependency**: `conf/build.info` is read at module import, not inside `main()`. Absence of this file will fail the entire import, including for any process that imports `app`.
- **Single login at startup**: Token lifecycle beyond initial login is delegated to `token_manager`; ensure refresh logic exists there for long-running deployments.