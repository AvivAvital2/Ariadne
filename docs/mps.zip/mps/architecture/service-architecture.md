---
id: e592de8c-6f1a-5bfc-af0f-5018b9202851
type: architecture
title: "Service Architecture"
created_at: 2026-06-06T19:04:37.370092+00:00
updated_at: 2026-06-20T22:55:26.789585+00:00
source_files:
  - /Users/spark/git/service-model-promotion/mps/service.py
metadata:
  source_name: "mps"
---
# Service Architecture

**Related files:**
- `/Users/spark/git/service-model-promotion/mps/service.py`

# Service Architecture


# Architecture Documentation: `mps.service`

## 1. Component Overview

The `mps.service` module provides the **MPS** class, which serves as the central orchestration and bootstrapping component for the MPS (likely "Multi-Provider Service" / container registry service) system. Its primary responsibilities are:

- **Configuration loading**: Reading registry connection details and provider settings from environment variables.
- **Provider resolution**: Selecting and instantiating the appropriate token manager based on the configured registry provider (AWS, Azure, GCP, local, or export).
- **Dependency assembly**: Wiring together the `TokenManager` and `ImageManager` instances that downstream code uses to interact with container registries.

The module exposes a ready-to-use singleton instance (`mps`) created at import time, making it the application's composition root.

---

## 2. Design Decisions

### 2.1 Environment-Driven Configuration
All configuration is sourced from environment variables (`REGISTRY_PROVIDER`, `REGISTRY_ADDR`, etc.). This follows the [Twelve-Factor App](https://12factor.net/config) principle of strict configuration/code separation, enabling the same image/codebase to run across environments without modification.

### 2.2 Strategy Pattern via `get_token_manager()`
The `match` statement on `registry_provider` selects the concrete token manager strategy:

| Provider | Token Manager | Notes |
|----------|---------------|-------|
| `aws`    | `AWSTokenManager` | Requires region; uses AWS-specific auth flow |
| `azure`  | `TokenManager`    | Generic provider auth |
| `gcp`    | `TokenManager`    | Generic provider auth |
| `local`  | `TokenManager`    | Adds TLS certificate signing verification |
| `export` | `TokenManager`    | Uses dummy localhost credentials; triggers file export mode |

This isolates provider-specific construction logic in a single factory method while keeping the calling code provider-agnostic.

### 2.3 Singleton Composition Root
The module-level `mps = MPS()` instantiates the service eagerly on import. This:
- Guarantees a single shared instance across the application.
- Fails fast at startup if configuration is invalid (e.g., unsupported provider raises `InvalidRegistryProvider`).

### 2.4 Safe Boolean Parsing
For `verify_certificate_signing`, the code uses `json.loads()` rather than `eval()` to convert string values (`"true"`/`"false"`) into booleans, explicitly avoiding arbitrary code execution risks. It also handles native `bool` types and raises a clear `ValueError` for invalid input.

### 2.5 Export Mode Coupling
The `export_image_as_file` flag on `ImageManager` is derived directly from whether the provider is `export`, coupling the image handling behavior to the provider selection in one place.

---

## 3. Component Diagram

```mermaid
graph TD
    ENV[Environment Variables] -->|read at init| MPS

    subgraph mps.service
        MPS[MPS<br/>composition root]
    end

    MPS -->|get_token_manager| Factory{registry_provider?}

    Factory -->|aws| AWSTM[AWSTokenManager]
    Factory -->|azure / gcp| TM1[TokenManager]
    Factory -->|local| TM2[TokenManager<br/>+verify_certificate_signing]
    Factory -->|export| TM3[TokenManager<br/>localhost dummy creds]
    Factory -->|unknown| ERR[InvalidRegistryProvider]

    AWSTM --> TMBase[TokenManager / AWSTokenManager]
    TM1 --> TMBase
    TM2 --> TMBase
    TM3 --> TMBase

    MPS -->|injects token_manager| IM[ImageManager]
    TMBase -.->|used by| IM

    MPS -.->|exports singleton| Singleton[(mps instance)]

    classDef external fill:#eee,stroke:#999;
    class ENV external;
```

---

## 4. Interfaces

### 4.1 Construction Interface
```python
MPS()  # No arguments; reads all config from environment.
```

**Consumed Environment Variables:**

| Variable | Purpose | Default |
|----------|---------|---------|
| `REGISTRY_PROVIDER` | Selects token manager strategy | `None` |
| `REGISTRY_ADDR` | Registry endpoint address | `None` |
| `REGISTRY_USER` | Registry username | `None` |
| `REGISTRY_PASS` | Registry password | `None` |
| `AWS_REGISTRY_REGION` | AWS region (AWS provider only) | `None` |
| `REGISTRY_VERIFY_CERTIFICATE_SIGNING` | TLS verification (local provider only) | `True` |

### 4.2 Public Method
```python
get_token_manager() -> TokenManager | AWSTokenManager
```
Factory method that resolves and returns the configured token manager. Raises:
- `InvalidRegistryProvider` — when `REGISTRY_PROVIDER` is unrecognized.
- `ValueError` — when `verify_certificate_signing` has an invalid value (local provider).

### 4.3 Exposed Attributes (Integration Points)
- `mps.token_manager` — the resolved `TokenManager`/`AWSTokenManager` instance.
- `mps.image_manager` — the `ImageManager` wired with the token manager.

### 4.4 Internal Integration Contracts
- **`TokenManager(registry, username, password, provider[, verify_certificate_signing])`** — generic registry auth contract.
- **`AWSTokenManager(registry, region_name, username, password)`** — AWS-specific contract.
- **`ImageManager(token_manager, export_image_as_file)`** — depends on a token manager for authenticated registry operations.

---

## 5. Data Flow

```mermaid
sequenceDiagram
    participant App as Application (import)
    participant MPS
    participant ENV as os.getenv
    participant TM as TokenManager Factory
    participant IM as ImageManager

    App->>MPS: MPS()  (module import)
    MPS->>ENV: read REGISTRY_* config
    ENV-->>MPS: config values
    MPS->>TM: get_token_manager()
    TM->>TM: match registry_provider
    alt valid provider
        TM-->>MPS: TokenManager / AWSTokenManager
    else invalid provider
        TM-->>MPS: raise InvalidRegistryProvider
    end
    MPS->>IM: ImageManager(token_manager, export_image_as_file)
    IM-->>MPS: image_manager instance
    MPS-->>App: mps singleton ready
```

**Flow summary:**
1. On import, the `MPS` constructor reads registry configuration from the environment.
2. `get_token_manager()` matches the provider string and constructs the appropriate token manager. For `local`, the certificate-signing flag is normalized from string to boolean.
3. The resolved token manager is injected into a new `ImageManager`, with file-export mode enabled only for the `export` provider.
4. Downstream consumers access `mps.image_manager` / `mps.token_manager` to perform authenticated registry operations.

---

## 6. Extension Points

### 6.1 Adding a New Registry Provider
Extend the `match` statement in `get_token_manager()` with a new `case`:
```python
case "newcloud":
    return NewCloudTokenManager(
        registry=self.registry_addr,
        username=self.registry_user,
        password=self.registry_password,
    )
```
Add the new provider name to the error message in the default `case` and implement the corresponding token manager in `mps.api.token_manager`.

### 6.2 Custom Token Manager Behavior
Subclass `TokenManager` or `AWSTokenManager` to alter authentication logic, then return the subclass from the factory. The `ImageManager` contract only depends on the token manager interface, so subclasses remain compatible.

### 6.3 Image Handling Customization
The `export_image_as_file` flag is the current customization hook for `ImageManager`. Additional behavior toggles can be passed at construction in the `MPS.__init__` wiring step.

### 6.4 Configuration Source Override
Currently configuration is hardcoded to `os.getenv`. To support alternative config sources (files, secret managers), introduce a configuration provider abstraction injected into `MPS.__init__`, replacing direct `os.getenv` calls.

---

## Recommendations & Caveats

- **Eager singleton risk**: Because `mps = MPS()` runs at import time, misconfiguration causes import failures. Consider a lazy factory (`get_mps()`) if startup-time validation needs to be deferred or made testable.
- **Default boolean type mismatch**: `verify_certificate_signing` defaults to a Python `bool` (`True`) but is treated as a string when sourced from the environment. The current `match` handles both, but tests should cover the default (non-env) path.
- **Testability**: Environment-coupled construction makes unit testing harder; the configuration-source extension point (6.4) would improve this.