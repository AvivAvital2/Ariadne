# Ariadne Library

This directory contains exported documentation from the Ariadne library.

## Contents

Total documents: 456

- **Architecture** (20): [architecture/](architecture/)
- **Catalog** (347): [other/](other/)
- **Diagram** (20): [diagrams/](diagrams/)
- **Explanation** (29): [explanations/](explanations/)
- **Gotcha** (20): [other/](other/)
- **Qa** (20): [qa/](qa/)

## Structure

- `manifest.yaml` - Index of all documents with metadata
- `INDEX.md` - Full document index with status info
- `explanations/` - How things work in the codebase
- `architecture/` - System design and component relationships
- `qa/` - Questions and answers about the codebase
- `diagrams/` - Visual diagrams (Graphviz DOT)
- `findings/` - Session discoveries and conclusions

## Usage

These documents can be read directly or searched using Ariadne.

```python
import ariadne

library = ariadne.Library(Path("ariadne.db"))
results = library.search(query_embedding, k=5)
```
