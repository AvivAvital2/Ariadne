---
type: meta
status: meta
updated_at: 2026-07-30T21:42:16.617949
---

# Available Documents

This is an auto-generated index of all Ariadne documents.

## Summary

**Total documents:** 435

### By Type

- Explanation: 43
- Architecture: 41
- Qa: 40
- Diagram: 40

### By Status

- Stable: 435

## Document List

| Title | Type | Status | Source Files |
|-------|------|--------|--------------|
| 0001 Initial Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| 0001 Initial Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| 0001 Initial FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| 0001 Initial Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| Alembic migration environment. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| App Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx |
| App Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py |
| App Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx |
| App Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py |
| App FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx |
| App FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py |
| App Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx |
| App Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py |
| App Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx |
| App Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py |
| Areatrend Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx |
| Areatrend Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx |
| Areatrend FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx |
| Areatrend Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx |
| Areatrend Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx |
| Audit Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| Audit Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| Audit Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| Audit Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| Audit FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| Audit FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| Audit Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| Audit Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| Audit-log endpoint (``/api/audit``). | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| Audit-log writes and reads. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| Auditlog Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx |
| Auditlog Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx |
| Auditlog FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx |
| Auditlog Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx |
| Auditlog Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx |
| backend.alembic.env.config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.env.connectable | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.env.run_migrations_offline | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.env.run_migrations_online | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.env.target_metadata | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.env.url | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| backend.alembic.versions.0001_initial.branch_labels | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.alembic.versions.0001_initial.depends_on | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.alembic.versions.0001_initial.down_revision | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.alembic.versions.0001_initial.downgrade | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.alembic.versions.0001_initial.revision | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.alembic.versions.0001_initial.upgrade | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| backend.app.constants.ALLOWED_STATUS_TRANSITIONS | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.ROLE_ASSIGNED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.ROLE_REVOKED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.USER_CREATED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.USER_DEACTIVATED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.USER_DELETED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.USER_REACTIVATED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.AuditAction.USER_UPDATED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.AUDIT_READ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.ROLES_MANAGE | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.USERS_CREATE | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.USERS_DEACTIVATE | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.USERS_DELETE | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.USERS_EDIT | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.Permission.USERS_READ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.UserStatus | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.UserStatus.ACTIVE | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.UserStatus.DEACTIVATED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.constants.UserStatus.INVITED | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| backend.app.database.Base | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.database.DATABASE_URL | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.database.db | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.database.engine | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.database.get_db | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.database.SessionLocal | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| backend.app.main.app | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| backend.app.main.db | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| backend.app.main.health | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| backend.app.main.lifespan | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| backend.app.models._utcnow | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.__tablename__ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.action | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.actor_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.created_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.detail | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.target_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.AuditLog.target_type | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission.__tablename__ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission.description | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Permission.roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.__tablename__ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.description | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.Role.users | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.role_permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.__tablename__ | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.created_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.email | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.updated_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.User.username | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.models.user_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| backend.app.reports.queries.USER_ACTIVITY_SQL | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| backend.app.routers.audit.list_audit | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| backend.app.routers.audit.router | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py |
| backend.app.routers.reports.router | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| backend.app.routers.reports.rows | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| backend.app.routers.reports.user_activity | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| backend.app.routers.roles.create_role | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| backend.app.routers.roles.list_permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| backend.app.routers.roles.list_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| backend.app.routers.roles.router | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| backend.app.routers.users.assign_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.create_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.delete_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.get_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.list_users | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.router | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.set_user_status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.update_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.routers.users.whoami | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| backend.app.schemas.AuditLogOut | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.action | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.actor_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.created_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.detail | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.model_config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.target_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.AuditLogOut.target_type | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser.permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.CurrentUser.username | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.PermissionOut | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.PermissionOut.description | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.PermissionOut.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.PermissionOut.model_config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.PermissionOut.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleAssignment | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleAssignment.role_ids | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleBrief | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleBrief.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleBrief.model_config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleBrief.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleCreate | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleCreate.description | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleCreate.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleCreate.permission_ids | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut.description | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut.model_config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.RoleOut.permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow.action_count | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow.last_action_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow.user_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserActivityRow.username | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserCreate | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserCreate.email | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserCreate.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserCreate.role_ids | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserCreate.username | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.created_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.email | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.model_config | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.updated_at | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserOut.username | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserStatusUpdate | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserStatusUpdate.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserUpdate | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserUpdate.email | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.schemas.UserUpdate.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| backend.app.security.actor | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| backend.app.security.checker | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| backend.app.security.current_actor | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| backend.app.security.require_permission | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| backend.app.seed._seed_audit_history | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.admin | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.alice | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.bob | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.editor | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.events | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.now | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.perms | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.root | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.seed_if_empty | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.ts | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.seed.viewer | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| backend.app.services.audit.entry | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| backend.app.services.audit.list_entries | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| backend.app.services.audit.query | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| backend.app.services.audit.record | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py |
| backend.app.services.roles.create_role | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.roles.get_role | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.roles.list_permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.roles.list_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.roles.role | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.roles.role.permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| backend.app.services.users._require | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users._status_action | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users._validate_transition | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.actor_has_permission | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.assign_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.create_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.delete_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.effective_permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.email | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.full_name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.get_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.list_users | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.query | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.set_status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.status | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.target_id | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.update_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| backend.app.services.users.user.roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| Barchart Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx |
| Barchart Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx |
| Barchart FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx |
| Barchart Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx |
| Barchart Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx |
| Client Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js |
| Client Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js |
| Client FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js |
| Client Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js |
| Client Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js |
| Config Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js |
| Config Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js |
| Config FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js |
| Config Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js |
| Config Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js |
| Constants Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js |
| Constants Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| Constants Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js |
| Constants Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| Constants FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js |
| Constants FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| Constants Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js |
| Constants Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| Constants Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js |
| Dashboard Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx |
| Dashboard Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx |
| Dashboard FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx |
| Dashboard Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx |
| Dashboard Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx |
| Database Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| Database Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| Database FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| Database Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| Database Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py |
| Domain constants shared across the backend. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py |
| Donutchart Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx |
| Donutchart Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx |
| Donutchart FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx |
| Donutchart Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx |
| Donutchart Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx |
| Env Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| Env Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| Env FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| Env Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py |
| First-run database bootstrap. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| frontend.package.dependencies | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.devDependencies | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.name | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.private | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.scripts | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.type | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.package.version | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| frontend.tsconfig.compilerOptions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json |
| frontend.tsconfig.include | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json |
| frontend/index.html#root | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/index.html |
| Hand-written SQL for reporting. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| HTTP routers, one module per resource. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py |
| Icons Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx |
| Icons Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx |
| Icons FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx |
| Icons Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx |
| Icons Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx |
| Index Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/index.html |
| Index Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/index.html |
| initial schema | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py |
| Main Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx |
| Main Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| Main Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx |
| Main Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| Main FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx |
| Main FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| Main Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx |
| Main Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| Main Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx |
| Models Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| Models Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| Models FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| Models Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| Models Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py |
| Package Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/package.json |
| Permission enforcement. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| Permissions Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js |
| Permissions Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js |
| Permissions FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js |
| Permissions Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js |
| Permissions Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js |
| Pydantic request/response schemas. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| Queries Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| Queries Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| Queries FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| Queries Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py |
| README.api_reference | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.architecture | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.authentication | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.backend | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.data_model | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.features | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.frontend | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.getting_started | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.license | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.permissions | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.project_structure | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.request_flow_deactivating_a_user | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.seeded_roles | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.status_lifecycle | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.tech_stack | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| README.userhub | catalog | stable | /Users/spark/git/Ariadne.orig/userhub/README.md |
| Reporting queries. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py |
| Reports Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| Reports Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py |
| Reports Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| Reports Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py |
| Reports FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| Reports FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py |
| Reports Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| Reports Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py |
| Reports Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py |
| Role and permission queries. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| Rolemanager Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx |
| Rolemanager Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx |
| Rolemanager FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx |
| Rolemanager Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx |
| Rolemanager Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx |
| Roles Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| Roles Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| Roles Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| Roles Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| Roles FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| Roles FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| Roles Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py |
| Roles Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| Roles Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py |
| Routers Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py |
| Routers Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py |
| Routers FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py |
| Routers Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py |
| Schemas Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| Schemas Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| Schemas FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| Schemas Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py |
| Security Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| Security Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| Security FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| Security Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py |
| Seed Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| Seed Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| Seed FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| Seed Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py |
| Services Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py |
| Services Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py |
| Services FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py |
| Services Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py |
| Services Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py |
| Sidebar Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx |
| Sidebar Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx |
| Sidebar FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx |
| Sidebar Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx |
| Sidebar Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx |
| Statcard Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx |
| Statcard Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx |
| Statcard FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx |
| Statcard Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx |
| Statcard Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx |
| Styles Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css |
| Styles Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css |
| Styles FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css |
| Styles Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css |
| Styles Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css |
| Topbar Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx |
| Topbar Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx |
| Topbar FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx |
| Topbar Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx |
| Topbar Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx |
| Tsconfig Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json |
| User lifecycle operations. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| User management endpoints (``/api/users``). | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| Userform Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx |
| Userform Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx |
| Userform FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx |
| Userform Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx |
| Userform Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx |
| UserHub FastAPI application entrypoint. | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py |
| Userlist Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx |
| Userlist Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx |
| Userlist FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx |
| Userlist Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx |
| Userlist Module | explanation | stable | /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx |
| Users Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| Users Architecture | architecture | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| Users Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| Users Diagram | diagram | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| Users FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| Users FAQ | qa | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
| Users Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py |
| Users Gotchas | gotcha | stable | /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py |
