---
id: 577429f1-4619-5b7b-b759-cf47ccc5f2a1
type: diagram
title: "Roles Diagram"
created_at: 2026-07-30T17:23:59.072201+00:00
updated_at: 2026-07-30T17:23:59.072217+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  module_name: "backend.app.routers.roles"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph roles_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module cluster
    subgraph cluster_module {
        label="backend.app.routers.roles";
        style=dashed;
        color=gray;

        list_roles       [label="list_roles(db, actor)"];
        create_role      [label="create_role(payload, db, actor)"];
        list_permissions [label="list_permissions(db, actor)"];
    }

    // API endpoints
    ep_roles_get   [label="GET /api/roles", shape=ellipse, style=filled, fillcolor="#cce5ff"];
    ep_roles_post  [label="POST /api/roles", shape=ellipse, style=filled, fillcolor="#cce5ff"];
    ep_perms_get   [label="GET /api/permissions", shape=ellipse, style=filled, fillcolor="#cce5ff"];

    // Dependencies
    db     [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#d5f5d5"];
    actor  [label="actor\n(Auth User)", shape=component, style=filled, fillcolor="#fff2cc"];
    payload [label="payload\n(Role data)", shape=note, style=filled, fillcolor="#ffe0e0"];

    // Endpoint routing
    ep_roles_get  -> list_roles       [label="routes"];
    ep_roles_post -> create_role      [label="routes"];
    ep_perms_get  -> list_permissions [label="routes"];

    // Data flow / dependencies
    db     -> list_roles       [label="query", style=dashed];
    db     -> create_role      [label="persist", style=dashed];
    db     -> list_permissions [label="query", style=dashed];

    actor  -> list_roles       [label="authz", color=darkorange];
    actor  -> create_role      [label="authz", color=darkorange];
    actor  -> list_permissions [label="authz", color=darkorange];

    payload -> create_role     [label="input", color=firebrick];
}"
  source_name: "userhub"
---
# Roles Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`



```dot
digraph roles_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module cluster
    subgraph cluster_module {
        label="backend.app.routers.roles";
        style=dashed;
        color=gray;

        list_roles       [label="list_roles(db, actor)"];
        create_role      [label="create_role(payload, db, actor)"];
        list_permissions [label="list_permissions(db, actor)"];
    }

    // API endpoints
    ep_roles_get   [label="GET /api/roles", shape=ellipse, style=filled, fillcolor="#cce5ff"];
    ep_roles_post  [label="POST /api/roles", shape=ellipse, style=filled, fillcolor="#cce5ff"];
    ep_perms_get   [label="GET /api/permissions", shape=ellipse, style=filled, fillcolor="#cce5ff"];

    // Dependencies
    db     [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#d5f5d5"];
    actor  [label="actor\n(Auth User)", shape=component, style=filled, fillcolor="#fff2cc"];
    payload [label="payload\n(Role data)", shape=note, style=filled, fillcolor="#ffe0e0"];

    // Endpoint routing
    ep_roles_get  -> list_roles       [label="routes"];
    ep_roles_post -> create_role      [label="routes"];
    ep_perms_get  -> list_permissions [label="routes"];

    // Data flow / dependencies
    db     -> list_roles       [label="query", style=dashed];
    db     -> create_role      [label="persist", style=dashed];
    db     -> list_permissions [label="query", style=dashed];

    actor  -> list_roles       [label="authz", color=darkorange];
    actor  -> create_role      [label="authz", color=darkorange];
    actor  -> list_permissions [label="authz", color=darkorange];

    payload -> create_role     [label="input", color=firebrick];
}
```