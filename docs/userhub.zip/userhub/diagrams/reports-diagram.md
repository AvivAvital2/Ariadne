---
id: 2f3c489c-f5c6-5acd-ba57-07bdb6de20bc
type: diagram
title: "Reports Diagram"
created_at: 2026-07-30T17:23:17.988319+00:00
updated_at: 2026-07-30T17:23:17.988334+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  module_name: "backend.app.routers.reports"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph reports_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module / entry point
    subgraph cluster_router {
        label="backend.app.routers.reports";
        style=dashed;
        color=gray;

        endpoint [label="GET /api/reports\n(user_activity endpoint)", shape=component, style=filled, fillcolor="#e3f2fd"];
        user_activity [label="user_activity(db, actor)", shape=box, style="rounded,filled", fillcolor="#bbdefb"];
    }

    // Dependencies (injected params)
    db [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#c8e6c9"];
    actor [label="actor\n(authenticated user)", shape=box, style=filled, fillcolor="#fff9c4"];

    // Data source
    sql [label="Hand-written SQL\n(user activity query)", shape=note, style=filled, fillcolor="#ffe0b2"];

    // Response
    report [label="User Activity Report\n(response payload)", shape=box, style=filled, fillcolor="#d1c4e9"];

    // Flows
    endpoint -> user_activity [label="routes to"];
    db -> user_activity [label="injects session"];
    actor -> user_activity [label="injects identity"];

    user_activity -> sql [label="executes"];
    sql -> db [label="runs against"];
    user_activity -> report [label="returns"];
}"
  source_name: "userhub"
---
# Reports Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`



```dot
digraph reports_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module / entry point
    subgraph cluster_router {
        label="backend.app.routers.reports";
        style=dashed;
        color=gray;

        endpoint [label="GET /api/reports\n(user_activity endpoint)", shape=component, style=filled, fillcolor="#e3f2fd"];
        user_activity [label="user_activity(db, actor)", shape=box, style="rounded,filled", fillcolor="#bbdefb"];
    }

    // Dependencies (injected params)
    db [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#c8e6c9"];
    actor [label="actor\n(authenticated user)", shape=box, style=filled, fillcolor="#fff9c4"];

    // Data source
    sql [label="Hand-written SQL\n(user activity query)", shape=note, style=filled, fillcolor="#ffe0b2"];

    // Response
    report [label="User Activity Report\n(response payload)", shape=box, style=filled, fillcolor="#d1c4e9"];

    // Flows
    endpoint -> user_activity [label="routes to"];
    db -> user_activity [label="injects session"];
    actor -> user_activity [label="injects identity"];

    user_activity -> sql [label="executes"];
    sql -> db [label="runs against"];
    user_activity -> report [label="returns"];
}
```