---
id: 7ab98ed0-81d3-54b4-9584-54ad4ea8d58e
type: diagram
title: "Permissions Diagram"
created_at: 2026-07-30T17:26:48.965133+00:00
updated_at: 2026-07-30T17:26:48.965151+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js
metadata:
  module_name: "frontend.src.auth.permissions"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph permissions {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.auth.permissions";
    labelloc=t;
    fontname="Helvetica";

    // No classes or functions were detected in this module.
    module [
        label="frontend.src.auth.permissions\n(empty / no classes or functions found)",
        shape=note,
        style="filled",
        fillcolor="#f5f5f5"
    ];
}"
  source_name: "userhub"
---
# Permissions Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js`



```dot
digraph permissions {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.auth.permissions";
    labelloc=t;
    fontname="Helvetica";

    // No classes or functions were detected in this module.
    module [
        label="frontend.src.auth.permissions\n(empty / no classes or functions found)",
        shape=note,
        style="filled",
        fillcolor="#f5f5f5"
    ];
}
```