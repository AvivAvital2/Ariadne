---
id: d490569e-a110-5b1d-904e-0fa47e84cabb
type: diagram
title: "Topbar Diagram"
created_at: 2026-07-30T17:28:33.943374+00:00
updated_at: 2026-07-30T17:28:33.943388+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx
metadata:
  module_name: "frontend.src.components.Topbar"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph Topbar {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Component module
    Topbar [label="Topbar\n(component)", style="rounded,filled", fillcolor="#cde4ff"];

    // Note node since no classes/functions were detected
    Note [label="No exported classes\nor functions detected", shape=note, fillcolor="#fff4cc", style=filled];

    // Module location context
    Module [label="frontend.src.components", shape=folder, fillcolor="#e8e8e8", style=filled];

    Module -> Topbar [label="contains"];
    Topbar -> Note [style=dashed, label="details"];
}"
  source_name: "userhub"
---
# Topbar Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx`



```dot
digraph Topbar {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Component module
    Topbar [label="Topbar\n(component)", style="rounded,filled", fillcolor="#cde4ff"];

    // Note node since no classes/functions were detected
    Note [label="No exported classes\nor functions detected", shape=note, fillcolor="#fff4cc", style=filled];

    // Module location context
    Module [label="frontend.src.components", shape=folder, fillcolor="#e8e8e8", style=filled];

    Module -> Topbar [label="contains"];
    Topbar -> Note [style=dashed, label="details"];
}
```