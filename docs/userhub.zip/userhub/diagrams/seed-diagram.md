---
id: 4012c382-78c7-5fb4-93c0-89faa53410de
type: diagram
title: "Seed Diagram"
created_at: 2026-07-30T17:24:52.818772+00:00
updated_at: 2026-07-30T17:24:52.818785+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  module_name: "backend.app.seed"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph seed_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.app.seed\n(First-run DB bootstrap)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Function
    seed_if_empty [label="seed_if_empty(db)", shape=component, style=filled, fillcolor="#fff2cc"];

    // Dependencies / data flow
    db [label="db\n(Database session)", shape=cylinder, style=filled, fillcolor="#d9ead3"];
    check [label="Check if\ntable empty", shape=diamond, style=filled, fillcolor="#f4cccc"];
    insert [label="Insert seed\nrecords", shape=box, style=filled, fillcolor="#d0e0e3"];

    // Relationships
    module -> seed_if_empty [label="defines"];
    db -> seed_if_empty [label="input"];
    seed_if_empty -> check [label="queries"];
    check -> insert [label="if empty"];
    insert -> db [label="commits"];
}"
  source_name: "userhub"
---
# Seed Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`



```dot
digraph seed_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.app.seed\n(First-run DB bootstrap)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Function
    seed_if_empty [label="seed_if_empty(db)", shape=component, style=filled, fillcolor="#fff2cc"];

    // Dependencies / data flow
    db [label="db\n(Database session)", shape=cylinder, style=filled, fillcolor="#d9ead3"];
    check [label="Check if\ntable empty", shape=diamond, style=filled, fillcolor="#f4cccc"];
    insert [label="Insert seed\nrecords", shape=box, style=filled, fillcolor="#d0e0e3"];

    // Relationships
    module -> seed_if_empty [label="defines"];
    db -> seed_if_empty [label="input"];
    seed_if_empty -> check [label="queries"];
    check -> insert [label="if empty"];
    insert -> db [label="commits"];
}
```