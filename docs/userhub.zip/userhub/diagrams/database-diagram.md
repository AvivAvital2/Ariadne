---
id: aa848f6a-da61-5f4e-9137-bfaf7ec9e256
type: diagram
title: "Database Diagram"
created_at: 2026-07-30T17:21:42.053192+00:00
updated_at: 2026-07-30T17:21:42.053206+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  module_name: "backend.app.database"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph database {
    rankdir=LR;
    node [fontname="Helvetica"];

    // Module container
    subgraph cluster_module {
        label="backend.app.database";
        style=filled;
        color=lightgrey;
        fontname="Helvetica Bold";

        engine   [label="engine\n(SQLAlchemy Engine)", shape=cylinder, style=filled, fillcolor=lightyellow];
        session  [label="SessionLocal\n(session factory)", shape=box3d, style=filled, fillcolor=lightblue];
        Base     [label="Base\n(DeclarativeBase)", shape=box, style=filled, fillcolor=lightgreen];
        get_db   [label="get_db()", shape=ellipse, style=filled, fillcolor=lightpink];
    }

    // External dependencies
    DeclarativeBase [label="DeclarativeBase\n(sqlalchemy.orm)", shape=box, style=dashed];
    consumer        [label="ORM Models /\nRoute Handlers", shape=note, style=dashed];

    // Relationships
    DeclarativeBase -> Base    [label="inherits", style=dashed, arrowhead=onormal];
    engine          -> session [label="bound to"];
    session         -> get_db  [label="creates session"];
    get_db          -> consumer[label="yields db\n(dependency)"];
    Base            -> consumer[label="base for models"];
}"
  source_name: "userhub"
---
# Database Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`



```dot
digraph database {
    rankdir=LR;
    node [fontname="Helvetica"];

    // Module container
    subgraph cluster_module {
        label="backend.app.database";
        style=filled;
        color=lightgrey;
        fontname="Helvetica Bold";

        engine   [label="engine\n(SQLAlchemy Engine)", shape=cylinder, style=filled, fillcolor=lightyellow];
        session  [label="SessionLocal\n(session factory)", shape=box3d, style=filled, fillcolor=lightblue];
        Base     [label="Base\n(DeclarativeBase)", shape=box, style=filled, fillcolor=lightgreen];
        get_db   [label="get_db()", shape=ellipse, style=filled, fillcolor=lightpink];
    }

    // External dependencies
    DeclarativeBase [label="DeclarativeBase\n(sqlalchemy.orm)", shape=box, style=dashed];
    consumer        [label="ORM Models /\nRoute Handlers", shape=note, style=dashed];

    // Relationships
    DeclarativeBase -> Base    [label="inherits", style=dashed, arrowhead=onormal];
    engine          -> session [label="bound to"];
    session         -> get_db  [label="creates session"];
    get_db          -> consumer[label="yields db\n(dependency)"];
    Base            -> consumer[label="base for models"];
}
```