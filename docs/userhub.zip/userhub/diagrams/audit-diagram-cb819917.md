---
id: cb819917-aea0-5576-868e-fe72f2864470
type: diagram
title: "Audit Diagram"
created_at: 2026-07-30T17:25:26.068764+00:00
updated_at: 2026-07-30T17:25:26.068779+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py
metadata:
  module_name: "backend.app.services.audit"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph audit_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module
    module [label="backend.app.services.audit\n(Audit-log writes and reads)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Functions
    record [label="record(db, actor_id, action,\ntarget_id, target_type, detail)", style=filled, fillcolor="#d5f5e3"];
    list_entries [label="list_entries(db, action, limit)", style=filled, fillcolor="#d5f5e3"];

    // External dependencies / data stores
    db [label="db\n(Session)", shape=cylinder, style=filled, fillcolor="#fdebd0"];
    audit_log [label="AuditLog\n(records)", shape=cylinder, style=filled, fillcolor="#fadbd8"];

    // Module contains functions
    module -> record [label="defines", style=dashed];
    module -> list_entries [label="defines", style=dashed];

    // Data flows
    record -> db [label="uses session"];
    record -> audit_log [label="write entry"];

    list_entries -> db [label="uses session"];
    list_entries -> audit_log [label="read/filter\nby action, limit"];
}"
  source_name: "userhub"
---
# Audit Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py`



```dot
digraph audit_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module
    module [label="backend.app.services.audit\n(Audit-log writes and reads)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Functions
    record [label="record(db, actor_id, action,\ntarget_id, target_type, detail)", style=filled, fillcolor="#d5f5e3"];
    list_entries [label="list_entries(db, action, limit)", style=filled, fillcolor="#d5f5e3"];

    // External dependencies / data stores
    db [label="db\n(Session)", shape=cylinder, style=filled, fillcolor="#fdebd0"];
    audit_log [label="AuditLog\n(records)", shape=cylinder, style=filled, fillcolor="#fadbd8"];

    // Module contains functions
    module -> record [label="defines", style=dashed];
    module -> list_entries [label="defines", style=dashed];

    // Data flows
    record -> db [label="uses session"];
    record -> audit_log [label="write entry"];

    list_entries -> db [label="uses session"];
    list_entries -> audit_log [label="read/filter\nby action, limit"];
}
```