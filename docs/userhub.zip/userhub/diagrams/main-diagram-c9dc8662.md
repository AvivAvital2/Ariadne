---
id: c9dc8662-15dc-5fd1-bdf8-e5a1d6008a30
type: diagram
title: "Main Diagram"
created_at: 2026-07-30T17:21:52.060615+00:00
updated_at: 2026-07-30T17:21:52.060630+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  module_name: "backend.app.main"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph UserHubMain {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica", fillcolor="#eef5ff"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.app.main\n(FastAPI entrypoint)", shape=folder, fillcolor="#d5e8d4"];

    // Application object
    app [label="app: FastAPI", shape=component, fillcolor="#ffe6cc"];

    // Functions
    lifespan [label="lifespan(app)\n(startup / shutdown)"];
    health   [label="health()\n(health check)"];

    // External dependency
    fastapi [label="FastAPI", shape=ellipse, fillcolor="#f8cecc"];

    // Relationships
    module -> app       [label="creates"];
    module -> lifespan  [label="defines"];
    module -> health    [label="defines"];

    fastapi -> app      [label="instantiates"];

    lifespan -> app     [label="manages\nlifecycle"];
    app -> lifespan     [label="uses as\nlifespan handler"];

    app -> health       [label="routes\nGET /health"];
    health -> app       [label="returns status"];
}"
  source_name: "userhub"
---
# Main Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`



```dot
digraph UserHubMain {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica", fillcolor="#eef5ff"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.app.main\n(FastAPI entrypoint)", shape=folder, fillcolor="#d5e8d4"];

    // Application object
    app [label="app: FastAPI", shape=component, fillcolor="#ffe6cc"];

    // Functions
    lifespan [label="lifespan(app)\n(startup / shutdown)"];
    health   [label="health()\n(health check)"];

    // External dependency
    fastapi [label="FastAPI", shape=ellipse, fillcolor="#f8cecc"];

    // Relationships
    module -> app       [label="creates"];
    module -> lifespan  [label="defines"];
    module -> health    [label="defines"];

    fastapi -> app      [label="instantiates"];

    lifespan -> app     [label="manages\nlifecycle"];
    app -> lifespan     [label="uses as\nlifespan handler"];

    app -> health       [label="routes\nGET /health"];
    health -> app       [label="returns status"];
}
```