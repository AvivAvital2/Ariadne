---
id: b3d497f0-6745-53b1-81ed-72a00c7aa512
type: diagram
title: "App Diagram"
created_at: 2026-07-30T17:26:29.711051+00:00
updated_at: 2026-07-30T17:26:29.711066+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx
metadata:
  module_name: "frontend.src.App"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph AppModule {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    App [label="frontend.src.App\n(Root Component)", style="rounded,filled", fillcolor="#cce5ff"];

    // Note node explaining lack of details
    Note [
        label="No classes or functions detected\nNo imports/relationships available",
        shape=note,
        style=filled,
        fillcolor="#fff3cd"
    ];

    App -> Note [label="metadata", style=dashed, color=gray];
}"
  source_name: "userhub"
---
# App Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx`



```dot
digraph AppModule {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    App [label="frontend.src.App\n(Root Component)", style="rounded,filled", fillcolor="#cce5ff"];

    // Note node explaining lack of details
    Note [
        label="No classes or functions detected\nNo imports/relationships available",
        shape=note,
        style=filled,
        fillcolor="#fff3cd"
    ];

    App -> Note [label="metadata", style=dashed, color=gray];
}
```