---
id: 935f9130-932a-5c81-94f3-d1d24872dc59
type: diagram
title: "Users Diagram"
created_at: 2026-07-30T17:25:48.459667+00:00
updated_at: 2026-07-30T17:25:48.459682+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  module_name: "backend.app.services.users"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph users_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    label="backend.app.services.users\nUser lifecycle operations";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Data source
    db [label="db (Session)", shape=cylinder, style=filled, fillcolor="#e0f0ff"];

    // Read / query functions
    subgraph cluster_read {
        label="Read / Query";
        style=dashed;
        color=gray;
        get_user      [label="get_user(user_id)"];
        list_users    [label="list_users(status)"];
    }

    // Permission helpers
    subgraph cluster_perm {
        label="Permissions";
        style=dashed;
        color=gray;
        actor_has_permission  [label="actor_has_permission(actor, permission)"];
        effective_permissions [label="effective_permissions(user)"];
    }

    // Write / mutation functions
    subgraph cluster_write {
        label="Write / Mutations";
        style=dashed;
        color=gray;
        create_user   [label="create_user(actor_id, username, email, ...)"];
        update_user   [label="update_user(actor_id, user_id, ...)"];
        set_status    [label="set_status(actor_id, user_id, status)"];
        delete_user   [label="delete_user(actor_id, user_id)"];
        assign_roles  [label="assign_roles(actor_id, user_id, role_ids)"];
    }

    // Data flow: functions query/persist through db
    get_user     -> db [label="query"];
    list_users   -> db [label="query"];
    create_user  -> db [label="persist"];
    update_user  -> db [label="persist"];
    set_status   -> db [label="persist"];
    delete_user  -> db [label="persist"];
    assign_roles -> db [label="persist"];

    // Mutations enforce authorization via actor_has_permission
    create_user  -> actor_has_permission [label="authorize"];
    update_user  -> actor_has_permission [label="authorize"];
    set_status   -> actor_has_permission [label="authorize"];
    delete_user  -> actor_has_permission [label="authorize"];
    assign_roles -> actor_has_permission [label="authorize"];

    // Permission resolution
    actor_has_permission -> effective_permissions [label="resolves"];

    // Mutations may load target user
    update_user  -> get_user [label="load target", style=dotted];
    set_status   -> get_user [label="load target", style=dotted];
    delete_user  -> get_user [label="load target", style=dotted];
    assign_roles -> get_user [label="load target", style=dotted];
}"
  source_name: "userhub"
---
# Users Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`



```dot
digraph users_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    label="backend.app.services.users\nUser lifecycle operations";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Data source
    db [label="db (Session)", shape=cylinder, style=filled, fillcolor="#e0f0ff"];

    // Read / query functions
    subgraph cluster_read {
        label="Read / Query";
        style=dashed;
        color=gray;
        get_user      [label="get_user(user_id)"];
        list_users    [label="list_users(status)"];
    }

    // Permission helpers
    subgraph cluster_perm {
        label="Permissions";
        style=dashed;
        color=gray;
        actor_has_permission  [label="actor_has_permission(actor, permission)"];
        effective_permissions [label="effective_permissions(user)"];
    }

    // Write / mutation functions
    subgraph cluster_write {
        label="Write / Mutations";
        style=dashed;
        color=gray;
        create_user   [label="create_user(actor_id, username, email, ...)"];
        update_user   [label="update_user(actor_id, user_id, ...)"];
        set_status    [label="set_status(actor_id, user_id, status)"];
        delete_user   [label="delete_user(actor_id, user_id)"];
        assign_roles  [label="assign_roles(actor_id, user_id, role_ids)"];
    }

    // Data flow: functions query/persist through db
    get_user     -> db [label="query"];
    list_users   -> db [label="query"];
    create_user  -> db [label="persist"];
    update_user  -> db [label="persist"];
    set_status   -> db [label="persist"];
    delete_user  -> db [label="persist"];
    assign_roles -> db [label="persist"];

    // Mutations enforce authorization via actor_has_permission
    create_user  -> actor_has_permission [label="authorize"];
    update_user  -> actor_has_permission [label="authorize"];
    set_status   -> actor_has_permission [label="authorize"];
    delete_user  -> actor_has_permission [label="authorize"];
    assign_roles -> actor_has_permission [label="authorize"];

    // Permission resolution
    actor_has_permission -> effective_permissions [label="resolves"];

    // Mutations may load target user
    update_user  -> get_user [label="load target", style=dotted];
    set_status   -> get_user [label="load target", style=dotted];
    delete_user  -> get_user [label="load target", style=dotted];
    assign_roles -> get_user [label="load target", style=dotted];
}
```