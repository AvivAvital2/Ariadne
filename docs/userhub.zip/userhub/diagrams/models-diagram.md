---
id: 06d5e4f4-30ac-5496-b8db-78cbb83b0cda
type: diagram
title: "Models Diagram"
created_at: 2026-07-30T17:22:33.524625+00:00
updated_at: 2026-07-30T17:22:33.524639+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  module_name: "backend.app.models"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph models {
    rankdir=TB;
    labelloc="t";
    label="backend.app.models — SQLAlchemy ORM Models";
    node [shape=record, style=filled, fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Declarative base
    Base [label="Base\n(DeclarativeBase)", shape=box, style="filled,rounded", fillcolor="#d5f5e3"];

    // ORM model classes
    User       [label="{User|+ id\l+ username\l+ email\l+ roles\l}"];
    Role       [label="{Role|+ id\l+ name\l+ permissions\l+ users\l}"];
    Permission [label="{Permission|+ id\l+ name\l+ code\l}"];
    AuditLog   [label="{AuditLog|+ id\l+ action\l+ timestamp\l+ user_id\l}"];

    // Inheritance from Base
    User       -> Base [label="extends", style=dashed, arrowhead=onormal];
    Role       -> Base [label="extends", style=dashed, arrowhead=onormal];
    Permission -> Base [label="extends", style=dashed, arrowhead=onormal];
    AuditLog   -> Base [label="extends", style=dashed, arrowhead=onormal];

    // Associations / relationships
    User -> Role       [label="M:N (user_roles)", dir=both, color="#1a73e8"];
    Role -> Permission [label="M:N (role_perms)", dir=both, color="#1a73e8"];
    AuditLog -> User   [label="FK user_id", color="#d93025"];
}"
  source_name: "userhub"
---
# Models Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`



```dot
digraph models {
    rankdir=TB;
    labelloc="t";
    label="backend.app.models — SQLAlchemy ORM Models";
    node [shape=record, style=filled, fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Declarative base
    Base [label="Base\n(DeclarativeBase)", shape=box, style="filled,rounded", fillcolor="#d5f5e3"];

    // ORM model classes
    User       [label="{User|+ id\l+ username\l+ email\l+ roles\l}"];
    Role       [label="{Role|+ id\l+ name\l+ permissions\l+ users\l}"];
    Permission [label="{Permission|+ id\l+ name\l+ code\l}"];
    AuditLog   [label="{AuditLog|+ id\l+ action\l+ timestamp\l+ user_id\l}"];

    // Inheritance from Base
    User       -> Base [label="extends", style=dashed, arrowhead=onormal];
    Role       -> Base [label="extends", style=dashed, arrowhead=onormal];
    Permission -> Base [label="extends", style=dashed, arrowhead=onormal];
    AuditLog   -> Base [label="extends", style=dashed, arrowhead=onormal];

    // Associations / relationships
    User -> Role       [label="M:N (user_roles)", dir=both, color="#1a73e8"];
    Role -> Permission [label="M:N (role_perms)", dir=both, color="#1a73e8"];
    AuditLog -> User   [label="FK user_id", color="#d93025"];
}
```