---
id: 9f9d43b0-acd5-5381-8b33-2d9235e9fd46
type: diagram
title: "Env Diagram"
created_at: 2026-07-30T17:20:57.699200+00:00
updated_at: 2026-07-30T17:20:57.699215+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  module_name: "backend.alembic.env"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph AlembicEnv {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.alembic.env", shape=folder, style=filled, fillcolor="#e8eef7"];

    // Functions
    offline [label="run_migrations_offline()", style=filled, fillcolor="#f2f7e8"];
    online  [label="run_migrations_online()", style=filled, fillcolor="#f2f7e8"];

    // Alembic context / config components
    config      [label="alembic config", shape=component, style=filled, fillcolor="#f7efe8"];
    context     [label="alembic context", shape=component, style=filled, fillcolor="#f7efe8"];
    metadata    [label="target_metadata", shape=cylinder, style=filled, fillcolor="#f7e8f2"];
    engine      [label="Engine / Connection", shape=component, style=filled, fillcolor="#f7efe8"];

    // Module contains functions
    module -> offline [label="defines"];
    module -> online  [label="defines"];

    // Config / metadata setup
    config   -> module [label="provides settings"];
    metadata -> module [label="schema target"];

    // Offline flow
    offline -> config    [label="reads url"];
    offline -> metadata  [label="uses"];
    offline -> context   [label="configure()"];
    context -> offline   [label="run_migrations()", style=dashed];

    // Online flow
    online -> config    [label="reads config"];
    online -> engine    [label="create engine"];
    engine -> context   [label="connect"];
    online -> metadata  [label="uses"];
    online -> context   [label="configure()"];
    context -> online   [label="run_migrations()", style=dashed];
}"
  source_name: "userhub"
---
# Env Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`



```dot
digraph AlembicEnv {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module
    module [label="backend.alembic.env", shape=folder, style=filled, fillcolor="#e8eef7"];

    // Functions
    offline [label="run_migrations_offline()", style=filled, fillcolor="#f2f7e8"];
    online  [label="run_migrations_online()", style=filled, fillcolor="#f2f7e8"];

    // Alembic context / config components
    config      [label="alembic config", shape=component, style=filled, fillcolor="#f7efe8"];
    context     [label="alembic context", shape=component, style=filled, fillcolor="#f7efe8"];
    metadata    [label="target_metadata", shape=cylinder, style=filled, fillcolor="#f7e8f2"];
    engine      [label="Engine / Connection", shape=component, style=filled, fillcolor="#f7efe8"];

    // Module contains functions
    module -> offline [label="defines"];
    module -> online  [label="defines"];

    // Config / metadata setup
    config   -> module [label="provides settings"];
    metadata -> module [label="schema target"];

    // Offline flow
    offline -> config    [label="reads url"];
    offline -> metadata  [label="uses"];
    offline -> context   [label="configure()"];
    context -> offline   [label="run_migrations()", style=dashed];

    // Online flow
    online -> config    [label="reads config"];
    online -> engine    [label="create engine"];
    engine -> context   [label="connect"];
    online -> metadata  [label="uses"];
    online -> context   [label="configure()"];
    context -> online   [label="run_migrations()", style=dashed];
}
```