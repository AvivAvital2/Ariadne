---
id: 1c9ead74-1e8f-5f23-8231-59bcd5e3be5f
type: diagram
title: "Main Diagram"
created_at: 2026-07-30T17:30:29.679287+00:00
updated_at: 2026-07-30T17:30:29.679300+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx
metadata:
  module_name: "frontend.src.main"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph frontend_main {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.main";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Entry point module
    main [label="frontend.src.main\n(entry point)", shape=box, style="rounded,filled", fillcolor="#cfe8fc"];

    // Note: no classes or functions detected within the module
    note [label="No classes or functions\ndetected in module", shape=note, style=filled, fillcolor="#f5f5dc", fontsize=10];

    main -> note [style=dashed, arrowhead=none, label="content"];
}"
  source_name: "userhub"
---
# Main Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx`



```dot
digraph frontend_main {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.main";
    labelloc="t";
    fontname="Helvetica";
    fontsize=14;

    // Entry point module
    main [label="frontend.src.main\n(entry point)", shape=box, style="rounded,filled", fillcolor="#cfe8fc"];

    // Note: no classes or functions detected within the module
    note [label="No classes or functions\ndetected in module", shape=note, style=filled, fillcolor="#f5f5dc", fontsize=10];

    main -> note [style=dashed, arrowhead=none, label="content"];
}
```