---
id: 43d40d5a-4fcc-537c-a836-4a88c678c90f
type: diagram
title: "Users Diagram"
created_at: 2026-07-30T17:24:05.527840+00:00
updated_at: 2026-07-30T17:24:05.527854+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  module_name: "backend.app.routers.users"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph users_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Router entrypoint
    router [label="/api/users\n(users router)", shape=folder, style=filled, fillcolor="#dbeafe"];

    // Endpoint functions
    subgraph cluster_endpoints {
        label="Endpoints";
        style=dashed;
        color="#94a3b8";

        whoami          [label="whoami(actor)"];
        list_users      [label="list_users(status, db, actor)"];
        get_user        [label="get_user(user_id, db, actor)"];
        create_user     [label="create_user(payload, db, actor)"];
        update_user     [label="update_user(user_id, payload, db, actor)"];
        set_user_status [label="set_user_status(user_id, payload, db, actor)"];
        assign_roles    [label="assign_roles(user_id, payload, db, actor)"];
        delete_user     [label="delete_user(user_id, db, actor)"];
    }

    // Shared dependencies
    actor [label="actor\n(auth dependency)", shape=ellipse, style=filled, fillcolor="#fef9c3"];
    db    [label="db\n(DB session)", shape=cylinder, style=filled, fillcolor="#dcfce7"];

    // Router registers endpoints
    router -> whoami          [label="GET /me"];
    router -> list_users      [label="GET /"];
    router -> get_user        [label="GET /{id}"];
    router -> create_user     [label="POST /"];
    router -> update_user     [label="PUT /{id}"];
    router -> set_user_status [label="PATCH /{id}/status"];
    router -> assign_roles    [label="PUT /{id}/roles"];
    router -> delete_user     [label="DELETE /{id}"];

    // Auth dependency (all endpoints require actor)
    whoami          -> actor [style=dotted, label="auth"];
    list_users      -> actor [style=dotted];
    get_user        -> actor [style=dotted];
    create_user     -> actor [style=dotted];
    update_user     -> actor [style=dotted];
    set_user_status -> actor [style=dotted];
    assign_roles    -> actor [style=dotted];
    delete_user     -> actor [style=dotted];

    // DB access
    list_users      -> db [color="#16a34a", label="query"];
    get_user        -> db [color="#16a34a", label="read"];
    create_user     -> db [color="#16a34a", label="insert"];
    update_user     -> db [color="#16a34a", label="update"];
    set_user_status -> db [color="#16a34a", label="update"];
    assign_roles    -> db [color="#16a34a", label="update"];
    delete_user     -> db [color="#16a34a", label="delete"];
}"
  source_name: "userhub"
---
# Users Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`



```dot
digraph users_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Router entrypoint
    router [label="/api/users\n(users router)", shape=folder, style=filled, fillcolor="#dbeafe"];

    // Endpoint functions
    subgraph cluster_endpoints {
        label="Endpoints";
        style=dashed;
        color="#94a3b8";

        whoami          [label="whoami(actor)"];
        list_users      [label="list_users(status, db, actor)"];
        get_user        [label="get_user(user_id, db, actor)"];
        create_user     [label="create_user(payload, db, actor)"];
        update_user     [label="update_user(user_id, payload, db, actor)"];
        set_user_status [label="set_user_status(user_id, payload, db, actor)"];
        assign_roles    [label="assign_roles(user_id, payload, db, actor)"];
        delete_user     [label="delete_user(user_id, db, actor)"];
    }

    // Shared dependencies
    actor [label="actor\n(auth dependency)", shape=ellipse, style=filled, fillcolor="#fef9c3"];
    db    [label="db\n(DB session)", shape=cylinder, style=filled, fillcolor="#dcfce7"];

    // Router registers endpoints
    router -> whoami          [label="GET /me"];
    router -> list_users      [label="GET /"];
    router -> get_user        [label="GET /{id}"];
    router -> create_user     [label="POST /"];
    router -> update_user     [label="PUT /{id}"];
    router -> set_user_status [label="PATCH /{id}/status"];
    router -> assign_roles    [label="PUT /{id}/roles"];
    router -> delete_user     [label="DELETE /{id}"];

    // Auth dependency (all endpoints require actor)
    whoami          -> actor [style=dotted, label="auth"];
    list_users      -> actor [style=dotted];
    get_user        -> actor [style=dotted];
    create_user     -> actor [style=dotted];
    update_user     -> actor [style=dotted];
    set_user_status -> actor [style=dotted];
    assign_roles    -> actor [style=dotted];
    delete_user     -> actor [style=dotted];

    // DB access
    list_users      -> db [color="#16a34a", label="query"];
    get_user        -> db [color="#16a34a", label="read"];
    create_user     -> db [color="#16a34a", label="insert"];
    update_user     -> db [color="#16a34a", label="update"];
    set_user_status -> db [color="#16a34a", label="update"];
    assign_roles    -> db [color="#16a34a", label="update"];
    delete_user     -> db [color="#16a34a", label="delete"];
}
```