---
id: f593e9e0-4e03-5a52-8338-fc2e17adf7a0
type: diagram
title: "Constants Diagram"
created_at: 2026-07-30T17:21:41.978424+00:00
updated_at: 2026-07-30T17:21:41.978439+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  module_name: "backend.app.constants"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph constants {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_module {
        label="backend.app.constants";
        style="dashed";
        color="gray50";
        fontname="Helvetica-Bold";

        UserStatus  [label="UserStatus\n(str, Enum)",  fillcolor="#cfe8ff"];
        Permission  [label="Permission\n(str, Enum)",  fillcolor="#cfe8ff"];
        AuditAction [label="AuditAction\n(str, Enum)", fillcolor="#cfe8ff"];
    }

    // Base classes
    str  [label="str",  fillcolor="#ffe6cc"];
    Enum [label="Enum\n(enum.Enum)", fillcolor="#ffe6cc"];

    // Inheritance edges
    UserStatus  -> str  [label="inherits"];
    UserStatus  -> Enum [label="inherits"];
    Permission  -> str  [label="inherits"];
    Permission  -> Enum [label="inherits"];
    AuditAction -> str  [label="inherits"];
    AuditAction -> Enum [label="inherits"];
}"
  source_name: "userhub"
---
# Constants Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`



```dot
digraph constants {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_module {
        label="backend.app.constants";
        style="dashed";
        color="gray50";
        fontname="Helvetica-Bold";

        UserStatus  [label="UserStatus\n(str, Enum)",  fillcolor="#cfe8ff"];
        Permission  [label="Permission\n(str, Enum)",  fillcolor="#cfe8ff"];
        AuditAction [label="AuditAction\n(str, Enum)", fillcolor="#cfe8ff"];
    }

    // Base classes
    str  [label="str",  fillcolor="#ffe6cc"];
    Enum [label="Enum\n(enum.Enum)", fillcolor="#ffe6cc"];

    // Inheritance edges
    UserStatus  -> str  [label="inherits"];
    UserStatus  -> Enum [label="inherits"];
    Permission  -> str  [label="inherits"];
    Permission  -> Enum [label="inherits"];
    AuditAction -> str  [label="inherits"];
    AuditAction -> Enum [label="inherits"];
}
```