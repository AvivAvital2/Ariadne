---
id: 7bb57181-674a-525b-b4c1-7a7d0c46414f
type: diagram
title: "Queries Diagram"
created_at: 2026-07-30T17:22:35.786725+00:00
updated_at: 2026-07-30T17:22:35.786738+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  module_name: "backend.app.reports.queries"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph reports_queries {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    module [
        label="backend.app.reports.queries\n(Hand-written SQL for reporting)",
        shape=box3d,
        style=filled,
        fillcolor="#e6f2ff"
    ];

    // Data source
    db [
        label="Database\n(Reporting Tables)",
        shape=cylinder,
        style=filled,
        fillcolor="#fff2cc"
    ];

    // SQL layer
    sql [
        label="Raw SQL Statements",
        shape=note,
        style=filled,
        fillcolor="#f0f0f0"
    ];

    // Consumers / output
    result [
        label="Query Result Sets",
        shape=box,
        style=filled,
        fillcolor="#e2f0d9"
    ];

    consumer [
        label="Report Services / Callers",
        shape=box,
        style=filled,
        fillcolor="#fce4d6"
    ];

    // Relationships / data flow
    module    -> sql      [label="defines"];
    sql       -> db       [label="executes against"];
    db        -> result   [label="returns rows"];
    result    -> consumer [label="provides data"];
    consumer  -> module   [label="invokes queries", style=dashed];
}"
  source_name: "userhub"
---
# Queries Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`



```dot
digraph reports_queries {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    module [
        label="backend.app.reports.queries\n(Hand-written SQL for reporting)",
        shape=box3d,
        style=filled,
        fillcolor="#e6f2ff"
    ];

    // Data source
    db [
        label="Database\n(Reporting Tables)",
        shape=cylinder,
        style=filled,
        fillcolor="#fff2cc"
    ];

    // SQL layer
    sql [
        label="Raw SQL Statements",
        shape=note,
        style=filled,
        fillcolor="#f0f0f0"
    ];

    // Consumers / output
    result [
        label="Query Result Sets",
        shape=box,
        style=filled,
        fillcolor="#e2f0d9"
    ];

    consumer [
        label="Report Services / Callers",
        shape=box,
        style=filled,
        fillcolor="#fce4d6"
    ];

    // Relationships / data flow
    module    -> sql      [label="defines"];
    sql       -> db       [label="executes against"];
    db        -> result   [label="returns rows"];
    result    -> consumer [label="provides data"];
    consumer  -> module   [label="invokes queries", style=dashed];
}
```