---
id: 8fd197e1-cc66-5252-be0e-3449cfbe281c
type: diagram
title: "0001 Initial Diagram"
created_at: 2026-07-30T17:20:57.682615+00:00
updated_at: 2026-07-30T17:20:57.682629+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  module_name: "backend.alembic.versions.0001_initial"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph AlembicInitialMigration {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    module [label="0001_initial\n(initial schema)", shape=folder, fillcolor="#E8EAF6", color="#3F51B5"];

    // Migration functions
    upgrade [label="upgrade()", fillcolor="#C8E6C9", color="#388E3C"];
    downgrade [label="downgrade()", fillcolor="#FFCDD2", color="#D32F2F"];

    // Alembic runtime
    alembic_op [label="alembic.op", shape=component, fillcolor="#FFF9C4", color="#FBC02D"];
    sa [label="sqlalchemy (sa)", shape=component, fillcolor="#FFF9C4", color="#FBC02D"];

    // Schema state nodes
    empty_db [label="empty schema", shape=cylinder, fillcolor="#F5F5F5", color="#9E9E9E"];
    initial_db [label="initial schema", shape=cylinder, fillcolor="#F5F5F5", color="#9E9E9E"];

    // Module contains functions
    module -> upgrade   [label="defines"];
    module -> downgrade [label="defines"];

    // Function dependencies
    upgrade   -> alembic_op [label="create_table"];
    upgrade   -> sa         [label="column types"];
    downgrade -> alembic_op [label="drop_table"];

    // Data flow / schema transitions
    empty_db   -> upgrade   [label="apply", style=dashed];
    upgrade    -> initial_db [label="creates", style=dashed];
    initial_db -> downgrade [label="revert", style=dashed];
    downgrade  -> empty_db   [label="removes", style=dashed];
}"
  source_name: "userhub"
---
# 0001 Initial Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`



```dot
digraph AlembicInitialMigration {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    module [label="0001_initial\n(initial schema)", shape=folder, fillcolor="#E8EAF6", color="#3F51B5"];

    // Migration functions
    upgrade [label="upgrade()", fillcolor="#C8E6C9", color="#388E3C"];
    downgrade [label="downgrade()", fillcolor="#FFCDD2", color="#D32F2F"];

    // Alembic runtime
    alembic_op [label="alembic.op", shape=component, fillcolor="#FFF9C4", color="#FBC02D"];
    sa [label="sqlalchemy (sa)", shape=component, fillcolor="#FFF9C4", color="#FBC02D"];

    // Schema state nodes
    empty_db [label="empty schema", shape=cylinder, fillcolor="#F5F5F5", color="#9E9E9E"];
    initial_db [label="initial schema", shape=cylinder, fillcolor="#F5F5F5", color="#9E9E9E"];

    // Module contains functions
    module -> upgrade   [label="defines"];
    module -> downgrade [label="defines"];

    // Function dependencies
    upgrade   -> alembic_op [label="create_table"];
    upgrade   -> sa         [label="column types"];
    downgrade -> alembic_op [label="drop_table"];

    // Data flow / schema transitions
    empty_db   -> upgrade   [label="apply", style=dashed];
    upgrade    -> initial_db [label="creates", style=dashed];
    initial_db -> downgrade [label="revert", style=dashed];
    downgrade  -> empty_db   [label="removes", style=dashed];
}
```