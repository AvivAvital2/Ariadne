---
id: 36dbed84-6661-5a66-b710-83a9f828ca28
type: diagram
title: "Schemas Diagram"
created_at: 2026-07-30T17:24:07.506570+00:00
updated_at: 2026-07-30T17:24:07.506585+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  module_name: "backend.app.schemas"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph SchemasModule {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10];
    edge [fontname="Helvetica", fontsize=8];

    // Base class
    BaseModel [label="pydantic.BaseModel", fillcolor="#d0e0f0", shape=ellipse];

    // Schema classes
    RoleBrief         [label="RoleBrief", fillcolor="#e0f0e0"];
    PermissionOut     [label="PermissionOut", fillcolor="#e0f0e0"];
    RoleOut           [label="RoleOut", fillcolor="#e0f0e0"];
    RoleCreate        [label="RoleCreate", fillcolor="#f0e0d0"];
    UserCreate        [label="UserCreate", fillcolor="#f0e0d0"];
    UserUpdate        [label="UserUpdate", fillcolor="#f0e0d0"];
    UserStatusUpdate  [label="UserStatusUpdate", fillcolor="#f0e0d0"];
    RoleAssignment    [label="RoleAssignment", fillcolor="#f0e0d0"];
    UserOut           [label="UserOut", fillcolor="#e0f0e0"];
    CurrentUser       [label="CurrentUser", fillcolor="#e0f0e0"];
    AuditLogOut       [label="AuditLogOut", fillcolor="#e0f0e0"];
    UserActivityRow   [label="UserActivityRow", fillcolor="#e0f0e0"];

    // Inheritance from BaseModel
    edge [color="#3060a0", label="inherits"];
    RoleBrief        -> BaseModel;
    PermissionOut    -> BaseModel;
    RoleOut          -> BaseModel;
    RoleCreate       -> BaseModel;
    UserCreate       -> BaseModel;
    UserUpdate       -> BaseModel;
    UserStatusUpdate -> BaseModel;
    RoleAssignment   -> BaseModel;
    UserOut          -> BaseModel;
    CurrentUser      -> BaseModel;
    AuditLogOut      -> BaseModel;
    UserActivityRow  -> BaseModel;

    // Composition / data relationships
    edge [color="#a06030", style=dashed, label="composes"];
    RoleOut     -> PermissionOut [label="permissions[]"];
    UserOut     -> RoleBrief     [label="roles[]"];
    CurrentUser -> RoleBrief     [label="roles[]"];

    // Request -> Response data flow
    edge [color="#308030", style=dotted, label="produces"];
    RoleCreate  -> RoleOut;
    UserCreate  -> UserOut;
    UserUpdate  -> UserOut;
}"
  source_name: "userhub"
---
# Schemas Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`



```dot
digraph SchemasModule {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica", fontsize=10];
    edge [fontname="Helvetica", fontsize=8];

    // Base class
    BaseModel [label="pydantic.BaseModel", fillcolor="#d0e0f0", shape=ellipse];

    // Schema classes
    RoleBrief         [label="RoleBrief", fillcolor="#e0f0e0"];
    PermissionOut     [label="PermissionOut", fillcolor="#e0f0e0"];
    RoleOut           [label="RoleOut", fillcolor="#e0f0e0"];
    RoleCreate        [label="RoleCreate", fillcolor="#f0e0d0"];
    UserCreate        [label="UserCreate", fillcolor="#f0e0d0"];
    UserUpdate        [label="UserUpdate", fillcolor="#f0e0d0"];
    UserStatusUpdate  [label="UserStatusUpdate", fillcolor="#f0e0d0"];
    RoleAssignment    [label="RoleAssignment", fillcolor="#f0e0d0"];
    UserOut           [label="UserOut", fillcolor="#e0f0e0"];
    CurrentUser       [label="CurrentUser", fillcolor="#e0f0e0"];
    AuditLogOut       [label="AuditLogOut", fillcolor="#e0f0e0"];
    UserActivityRow   [label="UserActivityRow", fillcolor="#e0f0e0"];

    // Inheritance from BaseModel
    edge [color="#3060a0", label="inherits"];
    RoleBrief        -> BaseModel;
    PermissionOut    -> BaseModel;
    RoleOut          -> BaseModel;
    RoleCreate       -> BaseModel;
    UserCreate       -> BaseModel;
    UserUpdate       -> BaseModel;
    UserStatusUpdate -> BaseModel;
    RoleAssignment   -> BaseModel;
    UserOut          -> BaseModel;
    CurrentUser      -> BaseModel;
    AuditLogOut      -> BaseModel;
    UserActivityRow  -> BaseModel;

    // Composition / data relationships
    edge [color="#a06030", style=dashed, label="composes"];
    RoleOut     -> PermissionOut [label="permissions[]"];
    UserOut     -> RoleBrief     [label="roles[]"];
    CurrentUser -> RoleBrief     [label="roles[]"];

    // Request -> Response data flow
    edge [color="#308030", style=dotted, label="produces"];
    RoleCreate  -> RoleOut;
    UserCreate  -> UserOut;
    UserUpdate  -> UserOut;
}
```