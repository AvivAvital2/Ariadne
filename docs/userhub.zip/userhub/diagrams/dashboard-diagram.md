---
id: 76f00a38-5b4b-5def-a4bd-9e024a5b8684
type: diagram
title: "Dashboard Diagram"
created_at: 2026-07-30T17:27:44.033237+00:00
updated_at: 2026-07-30T17:27:44.033250+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx
metadata:
  module_name: "frontend.src.components.Dashboard"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph Dashboard {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Main component
    Dashboard [label="Dashboard\n(frontend.src.components)", style="rounded,filled", fillcolor="#cce5ff"];

    // Note about limited introspection
    Note [label="No classes or functions\ndetected in module", shape=note, style=filled, fillcolor="#fff3cd"];

    Dashboard -> Note [label="contains", style=dashed];
}"
  source_name: "userhub"
---
# Dashboard Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx`



```dot
digraph Dashboard {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Main component
    Dashboard [label="Dashboard\n(frontend.src.components)", style="rounded,filled", fillcolor="#cce5ff"];

    // Note about limited introspection
    Note [label="No classes or functions\ndetected in module", shape=note, style=filled, fillcolor="#fff3cd"];

    Dashboard -> Note [label="contains", style=dashed];
}
```