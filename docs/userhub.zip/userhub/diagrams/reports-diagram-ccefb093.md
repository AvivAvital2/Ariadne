---
id: ccefb093-4b71-5cd3-876f-5c4190023d66
type: diagram
title: "Reports Diagram"
created_at: 2026-07-30T17:22:26.887765+00:00
updated_at: 2026-07-30T17:22:26.887784+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py
metadata:
  module_name: "backend.app.reports"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph reports_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="backend.app.reports\n(Reporting queries)";
    labelloc="t";
    fontsize=14;

    // Main module node
    reports [label="backend.app.reports\n(Reporting queries)", style="rounded,filled", fillcolor=lightblue];

    // Note: No classes or functions were detected in this module.
    note [label="No classes or functions found\n(module body only)", shape=note, style=filled, fillcolor=lightyellow];

    reports -> note [label="contains", style=dashed];
}"
  source_name: "userhub"
---
# Reports Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py`



```dot
digraph reports_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="backend.app.reports\n(Reporting queries)";
    labelloc="t";
    fontsize=14;

    // Main module node
    reports [label="backend.app.reports\n(Reporting queries)", style="rounded,filled", fillcolor=lightblue];

    // Note: No classes or functions were detected in this module.
    note [label="No classes or functions found\n(module body only)", shape=note, style=filled, fillcolor=lightyellow];

    reports -> note [label="contains", style=dashed];
}
```