---
id: a8738663-4e56-5ebf-8495-1235f30ddc09
type: diagram
title: "App Diagram"
created_at: 2026-07-30T17:21:07.022641+00:00
updated_at: 2026-07-30T17:21:07.022655+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py
metadata:
  module_name: "backend.app"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph UserHubBackend {
    rankdir=LR;
    fontname="Helvetica";
    node [shape=box, style="rounded,filled", fillcolor="#eef4fb", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10, color="#555555"];

    // ---- Application layer ----
    subgraph cluster_app {
        label="backend.app";
        style="rounded";
        color="#8fb4d6";

        FastAPIApp   [label="FastAPI\napp instance", fillcolor="#d6e8fb"];
        Routes       [label="API Routes\n(endpoints)"];
        Middleware   [label="Middleware\n(CORS / Auth)"];
    }

    // ---- Service / logic layer ----
    subgraph cluster_service {
        label="Service Layer";
        style="rounded";
        color="#a6d6a6";

        UserService  [label="UserService\n(business logic)", fillcolor="#e4f7e4"];
        AuthService  [label="AuthService\n(login / tokens)", fillcolor="#e4f7e4"];
    }

    // ---- Data / persistence layer ----
    subgraph cluster_data {
        label="Data Layer (SQLAlchemy)";
        style="rounded";
        color="#d6c68f";

        Schemas   [label="Pydantic\nSchemas", fillcolor="#faf3d6"];
        Models    [label="SQLAlchemy\nModels (User)", fillcolor="#faf3d6"];
        Database  [label="DB Session /\nEngine", fillcolor="#faf3d6"];
    }

    // ---- External ----
    DB [label="Database\n(Postgres)", shape=cylinder, fillcolor="#f0d6d6"];

    // ---- Flows ----
    FastAPIApp   -> Middleware  [label="wraps"];
    FastAPIApp   -> Routes      [label="mounts"];

    Routes       -> Schemas     [label="validate I/O"];
    Routes       -> UserService [label="calls"];
    Routes       -> AuthService [label="calls"];

    AuthService  -> UserService [label="verify user"];

    UserService  -> Models      [label="ORM ops"];
    AuthService  -> Models      [label="lookup"];

    Models       -> Database    [label="mapped to"];
    UserService  -> Database    [label="session"];
    Database     -> DB          [label="connects"];

    Schemas      -> Models      [label="serialize", style=dashed];
}"
  source_name: "userhub"
---
# App Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py`



```dot
digraph UserHubBackend {
    rankdir=LR;
    fontname="Helvetica";
    node [shape=box, style="rounded,filled", fillcolor="#eef4fb", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10, color="#555555"];

    // ---- Application layer ----
    subgraph cluster_app {
        label="backend.app";
        style="rounded";
        color="#8fb4d6";

        FastAPIApp   [label="FastAPI\napp instance", fillcolor="#d6e8fb"];
        Routes       [label="API Routes\n(endpoints)"];
        Middleware   [label="Middleware\n(CORS / Auth)"];
    }

    // ---- Service / logic layer ----
    subgraph cluster_service {
        label="Service Layer";
        style="rounded";
        color="#a6d6a6";

        UserService  [label="UserService\n(business logic)", fillcolor="#e4f7e4"];
        AuthService  [label="AuthService\n(login / tokens)", fillcolor="#e4f7e4"];
    }

    // ---- Data / persistence layer ----
    subgraph cluster_data {
        label="Data Layer (SQLAlchemy)";
        style="rounded";
        color="#d6c68f";

        Schemas   [label="Pydantic\nSchemas", fillcolor="#faf3d6"];
        Models    [label="SQLAlchemy\nModels (User)", fillcolor="#faf3d6"];
        Database  [label="DB Session /\nEngine", fillcolor="#faf3d6"];
    }

    // ---- External ----
    DB [label="Database\n(Postgres)", shape=cylinder, fillcolor="#f0d6d6"];

    // ---- Flows ----
    FastAPIApp   -> Middleware  [label="wraps"];
    FastAPIApp   -> Routes      [label="mounts"];

    Routes       -> Schemas     [label="validate I/O"];
    Routes       -> UserService [label="calls"];
    Routes       -> AuthService [label="calls"];

    AuthService  -> UserService [label="verify user"];

    UserService  -> Models      [label="ORM ops"];
    AuthService  -> Models      [label="lookup"];

    Models       -> Database    [label="mapped to"];
    UserService  -> Database    [label="session"];
    Database     -> DB          [label="connects"];

    Schemas      -> Models      [label="serialize", style=dashed];
}
```