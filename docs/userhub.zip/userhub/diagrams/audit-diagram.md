---
id: 8322cb4e-aca7-56e7-b9cb-6917f5f0d94c
type: diagram
title: "Audit Diagram"
created_at: 2026-07-30T17:23:11.356409+00:00
updated_at: 2026-07-30T17:23:11.356424+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  module_name: "backend.app.routers.audit"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph audit_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module / Endpoint
    subgraph cluster_router {
        label="backend.app.routers.audit";
        style=dashed;
        color=gray;

        endpoint [label="GET /api/audit", shape=oval, style=filled, fillcolor="#cce5ff"];
        list_audit [label="list_audit(action, limit, db, actor)", style=filled, fillcolor="#d4edda"];
    }

    // Inputs / Dependencies
    action [label="action\n(query param)", shape=note, fillcolor="#fff3cd", style=filled];
    limit  [label="limit\n(query param)", shape=note, fillcolor="#fff3cd", style=filled];
    db     [label="db\n(DB session)", shape=cylinder, fillcolor="#f8d7da", style=filled];
    actor  [label="actor\n(auth user)", shape=component, fillcolor="#e2d9f3", style=filled];

    // Output
    audit_log [label="Audit Log Records", shape=folder, fillcolor="#d1ecf1", style=filled];
    response  [label="JSON Response", shape=oval, fillcolor="#cce5ff", style=filled];

    // Flows
    endpoint -> list_audit [label="routes to"];

    action -> list_audit [label="filter"];
    limit  -> list_audit [label="paginate"];
    db     -> list_audit [label="inject"];
    actor  -> list_audit [label="authorize"];

    list_audit -> db        [label="query"];
    db         -> audit_log [label="fetch"];
    audit_log  -> list_audit [label="records"];
    list_audit -> response  [label="returns"];
}"
  source_name: "userhub"
---
# Audit Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`



```dot
digraph audit_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module / Endpoint
    subgraph cluster_router {
        label="backend.app.routers.audit";
        style=dashed;
        color=gray;

        endpoint [label="GET /api/audit", shape=oval, style=filled, fillcolor="#cce5ff"];
        list_audit [label="list_audit(action, limit, db, actor)", style=filled, fillcolor="#d4edda"];
    }

    // Inputs / Dependencies
    action [label="action\n(query param)", shape=note, fillcolor="#fff3cd", style=filled];
    limit  [label="limit\n(query param)", shape=note, fillcolor="#fff3cd", style=filled];
    db     [label="db\n(DB session)", shape=cylinder, fillcolor="#f8d7da", style=filled];
    actor  [label="actor\n(auth user)", shape=component, fillcolor="#e2d9f3", style=filled];

    // Output
    audit_log [label="Audit Log Records", shape=folder, fillcolor="#d1ecf1", style=filled];
    response  [label="JSON Response", shape=oval, fillcolor="#cce5ff", style=filled];

    // Flows
    endpoint -> list_audit [label="routes to"];

    action -> list_audit [label="filter"];
    limit  -> list_audit [label="paginate"];
    db     -> list_audit [label="inject"];
    actor  -> list_audit [label="authorize"];

    list_audit -> db        [label="query"];
    db         -> audit_log [label="fetch"];
    audit_log  -> list_audit [label="records"];
    list_audit -> response  [label="returns"];
}
```