---
id: 8799506e-db0f-579f-863a-65e2e9b00b06
type: diagram
title: "Routers Diagram"
created_at: 2026-07-30T17:23:11.459219+00:00
updated_at: 2026-07-30T17:23:11.459233+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py
metadata:
  module_name: "backend.app.routers"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph routers {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_routers {
        label="backend.app.routers";
        style="rounded,dashed";
        color="#888888";

        pkg [label="__init__\n(router registry)", fillcolor="#d0e8ff"];

        users    [label="users.py"];
        items    [label="items.py"];
        auth     [label="auth.py"];
        health   [label="health.py"];
    }

    // External framework / dependencies
    fastapi [label="FastAPI\nAPIRouter", shape=component, fillcolor="#fff2cc"];
    app     [label="app.main\n(FastAPI app)", shape=component, fillcolor="#d5e8d4"];

    // Router modules depend on FastAPI's APIRouter
    users  -> fastapi [label="APIRouter"];
    items  -> fastapi [label="APIRouter"];
    auth   -> fastapi [label="APIRouter"];
    health -> fastapi [label="APIRouter"];

    // Package aggregates the resource routers
    pkg -> users  [label="include"];
    pkg -> items  [label="include"];
    pkg -> auth   [label="include"];
    pkg -> health [label="include"];

    // Main app mounts the aggregated routers
    app -> pkg [label="include_router", style=dashed];
}"
  source_name: "userhub"
---
# Routers Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py`



```dot
digraph routers {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_routers {
        label="backend.app.routers";
        style="rounded,dashed";
        color="#888888";

        pkg [label="__init__\n(router registry)", fillcolor="#d0e8ff"];

        users    [label="users.py"];
        items    [label="items.py"];
        auth     [label="auth.py"];
        health   [label="health.py"];
    }

    // External framework / dependencies
    fastapi [label="FastAPI\nAPIRouter", shape=component, fillcolor="#fff2cc"];
    app     [label="app.main\n(FastAPI app)", shape=component, fillcolor="#d5e8d4"];

    // Router modules depend on FastAPI's APIRouter
    users  -> fastapi [label="APIRouter"];
    items  -> fastapi [label="APIRouter"];
    auth   -> fastapi [label="APIRouter"];
    health -> fastapi [label="APIRouter"];

    // Package aggregates the resource routers
    pkg -> users  [label="include"];
    pkg -> items  [label="include"];
    pkg -> auth   [label="include"];
    pkg -> health [label="include"];

    // Main app mounts the aggregated routers
    app -> pkg [label="include_router", style=dashed];
}
```