---
id: 269e8a96-b4bb-59c7-866c-60c2a3635e12
type: diagram
title: "Styles Diagram"
created_at: 2026-07-30T17:31:15.201093+00:00
updated_at: 2026-07-30T17:31:15.201108+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css
metadata:
  module_name: "frontend.src.styles"
  language: "css"
  provenance: "code-derived"
  dot_code: "digraph styles_module {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_styles {
        label="frontend.src.styles";
        labelloc="t";
        fontname="Helvetica-Bold";
        style="rounded,dashed";
        color="#4285f4";

        module [label="styles\n(module)", fillcolor="#fce8e6", shape=folder];
        note [label="No classes or functions defined\n(style definitions only)", shape=note, fillcolor="#fef7e0"];

        module -> note [style=dotted, arrowhead=none];
    }
}"
  source_name: "userhub"
---
# Styles Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css`



```dot
digraph styles_module {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module container
    subgraph cluster_styles {
        label="frontend.src.styles";
        labelloc="t";
        fontname="Helvetica-Bold";
        style="rounded,dashed";
        color="#4285f4";

        module [label="styles\n(module)", fillcolor="#fce8e6", shape=folder];
        note [label="No classes or functions defined\n(style definitions only)", shape=note, fillcolor="#fef7e0"];

        module -> note [style=dotted, arrowhead=none];
    }
}
```