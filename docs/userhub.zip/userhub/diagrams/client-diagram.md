---
id: 0b4fc284-a6aa-5a0b-ba60-33bc243760b6
type: diagram
title: "Client Diagram"
created_at: 2026-07-30T17:26:56.360223+00:00
updated_at: 2026-07-30T17:26:56.360242+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js
metadata:
  module_name: "frontend.src.api.client"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph frontend_api_client {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.api.client";
    labelloc=t;
    fontsize=14;

    // Module node
    client [label="api.client\n(module)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Placeholder note — no classes or functions were detected
    empty [label="No classes or functions found\n(module currently empty or\ncontains only declarations)", shape=note, style=filled, fillcolor="#fff8e1"];

    client -> empty [label="contains", style=dashed];
}"
  source_name: "userhub"
---
# Client Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js`



```dot
digraph frontend_api_client {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="Module: frontend.src.api.client";
    labelloc=t;
    fontsize=14;

    // Module node
    client [label="api.client\n(module)", shape=folder, style=filled, fillcolor="#e8f0fe"];

    // Placeholder note — no classes or functions were detected
    empty [label="No classes or functions found\n(module currently empty or\ncontains only declarations)", shape=note, style=filled, fillcolor="#fff8e1"];

    client -> empty [label="contains", style=dashed];
}
```