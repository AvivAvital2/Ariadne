---
id: b11cc5b2-059a-5100-bfe9-859ca6042c20
type: diagram
title: "Security Diagram"
created_at: 2026-07-30T17:24:44.596177+00:00
updated_at: 2026-07-30T17:24:44.596192+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  module_name: "backend.app.security"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph security {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module label
    label="backend.app.security — Permission enforcement";
    labelloc=t;
    fontname="Helvetica";
    fontsize=14;

    // Inputs
    x_actor_id [label="x_actor_id\n(header)", shape=note, style=filled, fillcolor="#f0f0f0"];
    db         [label="db\n(session)", shape=cylinder, style=filled, fillcolor="#e6f2ff"];
    permission [label="permission\n(required)", shape=note, style=filled, fillcolor="#f0f0f0"];

    // Functions
    current_actor    [label="current_actor(x_actor_id, db)", style=filled, fillcolor="#d5f5e3"];
    require_permission [label="require_permission(permission)", style=filled, fillcolor="#fcf3cf"];
    checker          [label="checker()", style=filled, fillcolor="#fadbd8"];

    // Data flow into current_actor
    x_actor_id -> current_actor [label="resolves actor"];
    db         -> current_actor [label="lookup"];
    current_actor -> Actor [label="returns"];

    Actor [label="Actor", shape=box, style=filled, fillcolor="#eaeaea"];

    // require_permission factory
    permission -> require_permission [label="configures"];
    require_permission -> checker [label="returns\ndependency"];

    // checker enforcement
    checker -> current_actor [label="depends on"];
    checker -> permission [label="validates against", style=dashed];
    checker -> Result [label="allow / 403"];

    Result [label="Authorized / HTTP 403", shape=oval, style=filled, fillcolor="#f9e79f"];
}"
  source_name: "userhub"
---
# Security Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`



```dot
digraph security {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module label
    label="backend.app.security — Permission enforcement";
    labelloc=t;
    fontname="Helvetica";
    fontsize=14;

    // Inputs
    x_actor_id [label="x_actor_id\n(header)", shape=note, style=filled, fillcolor="#f0f0f0"];
    db         [label="db\n(session)", shape=cylinder, style=filled, fillcolor="#e6f2ff"];
    permission [label="permission\n(required)", shape=note, style=filled, fillcolor="#f0f0f0"];

    // Functions
    current_actor    [label="current_actor(x_actor_id, db)", style=filled, fillcolor="#d5f5e3"];
    require_permission [label="require_permission(permission)", style=filled, fillcolor="#fcf3cf"];
    checker          [label="checker()", style=filled, fillcolor="#fadbd8"];

    // Data flow into current_actor
    x_actor_id -> current_actor [label="resolves actor"];
    db         -> current_actor [label="lookup"];
    current_actor -> Actor [label="returns"];

    Actor [label="Actor", shape=box, style=filled, fillcolor="#eaeaea"];

    // require_permission factory
    permission -> require_permission [label="configures"];
    require_permission -> checker [label="returns\ndependency"];

    // checker enforcement
    checker -> current_actor [label="depends on"];
    checker -> permission [label="validates against", style=dashed];
    checker -> Result [label="allow / 403"];

    Result [label="Authorized / HTTP 403", shape=oval, style=filled, fillcolor="#f9e79f"];
}
```