---
id: 1edcbc17-e2a1-5215-bd21-3c7916a6e29a
type: diagram
title: "Icons Diagram"
created_at: 2026-07-30T17:27:43.872068+00:00
updated_at: 2026-07-30T17:27:43.872082+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx
metadata:
  module_name: "frontend.src.components.Icons"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph Icons {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="frontend.src.components.Icons";
    labelloc="t";
    fontsize=16;

    // Module node
    Icons [label="Icons\n(module)", shape=component, style="filled,rounded", fillcolor="#e3f2fd"];

    // Note node explaining lack of detected symbols
    Note [label="No classes or functions detected\n(likely icon component exports\nor SVG assets)", shape=note, style=filled, fillcolor="#fff9c4"];

    Icons -> Note [style=dashed, label="contains"];
}"
  source_name: "userhub"
---
# Icons Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx`



```dot
digraph Icons {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    label="frontend.src.components.Icons";
    labelloc="t";
    fontsize=16;

    // Module node
    Icons [label="Icons\n(module)", shape=component, style="filled,rounded", fillcolor="#e3f2fd"];

    // Note node explaining lack of detected symbols
    Note [label="No classes or functions detected\n(likely icon component exports\nor SVG assets)", shape=note, style=filled, fillcolor="#fff9c4"];

    Icons -> Note [style=dashed, label="contains"];
}
```