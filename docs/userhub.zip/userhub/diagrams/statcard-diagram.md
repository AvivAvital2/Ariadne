---
id: a21b42fb-7160-5bf7-bb4f-37c0b8b846e1
type: diagram
title: "Statcard Diagram"
created_at: 2026-07-30T17:28:26.494725+00:00
updated_at: 2026-07-30T17:28:26.494740+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx
metadata:
  module_name: "frontend.src.components.StatCard"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph StatCard {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Component module
    StatCard [label="StatCard\n(Component)", style="rounded,filled", fillcolor="#cce5ff"];

    // Typical props / inputs for a stat card component
    Props [label="Props", shape=note, fillcolor="#fff3cd", style=filled];
    Title [label="title", shape=ellipse];
    Value [label="value", shape=ellipse];
    Icon [label="icon", shape=ellipse];
    Trend [label="trend", shape=ellipse];

    // Rendered output
    Render [label="Rendered UI\n(card layout)", shape=component, fillcolor="#d4edda", style=filled];

    // Data flow from props into component
    Title -> Props;
    Value -> Props;
    Icon -> Props;
    Trend -> Props;

    Props -> StatCard [label="input"];
    StatCard -> Render [label="renders"];
}"
  source_name: "userhub"
---
# Statcard Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx`



```dot
digraph StatCard {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Component module
    StatCard [label="StatCard\n(Component)", style="rounded,filled", fillcolor="#cce5ff"];

    // Typical props / inputs for a stat card component
    Props [label="Props", shape=note, fillcolor="#fff3cd", style=filled];
    Title [label="title", shape=ellipse];
    Value [label="value", shape=ellipse];
    Icon [label="icon", shape=ellipse];
    Trend [label="trend", shape=ellipse];

    // Rendered output
    Render [label="Rendered UI\n(card layout)", shape=component, fillcolor="#d4edda", style=filled];

    // Data flow from props into component
    Title -> Props;
    Value -> Props;
    Icon -> Props;
    Trend -> Props;

    Props -> StatCard [label="input"];
    StatCard -> Render [label="renders"];
}
```