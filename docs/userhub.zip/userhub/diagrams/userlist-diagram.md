---
id: 9596990d-9bc4-5f62-ab1e-c908cee1a08e
type: diagram
title: "Userlist Diagram"
created_at: 2026-07-30T17:29:17.385740+00:00
updated_at: 2026-07-30T17:29:17.385754+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx
metadata:
  module_name: "frontend.src.components.UserList"
  language: "javascript"
  provenance: "code-derived"
  dot_code: "digraph UserList {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    UserList [label="UserList\n(frontend/src/components)", fillcolor="#c9e0ff", shape=component];

    // Informational note node
    note [
        label="No classes or functions detected\nin this module.\n\nLikely a presentational component\nor an index/re-export file.",
        shape=note,
        fillcolor="#fff8dc"
    ];

    // Relationship
    UserList -> note [label="analysis result", style=dashed, color=gray];
}"
  source_name: "userhub"
---
# Userlist Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx`



```dot
digraph UserList {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e8f0fe", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Module node
    UserList [label="UserList\n(frontend/src/components)", fillcolor="#c9e0ff", shape=component];

    // Informational note node
    note [
        label="No classes or functions detected\nin this module.\n\nLikely a presentational component\nor an index/re-export file.",
        shape=note,
        fillcolor="#fff8dc"
    ];

    // Relationship
    UserList -> note [label="analysis result", style=dashed, color=gray];
}
```