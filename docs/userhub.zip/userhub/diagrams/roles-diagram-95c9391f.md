---
id: 95c9391f-ad38-565e-9587-87d4d81f972a
type: diagram
title: "Roles Diagram"
created_at: 2026-07-30T17:25:38.129382+00:00
updated_at: 2026-07-30T17:25:38.129395+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  module_name: "backend.app.services.roles"
  language: "python"
  provenance: "code-derived"
  dot_code: "digraph roles_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module cluster
    subgraph cluster_module {
        label="backend.app.services.roles";
        style=dashed;
        color=gray;

        list_roles       [label="list_roles(db)"];
        get_role         [label="get_role(db, role_id)"];
        create_role      [label="create_role(db, name,\ndescription, permission_ids)"];
        list_permissions [label="list_permissions(db)"];
    }

    // External dependency
    db [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#e0e0e0"];

    // Data entities
    Role       [label="Role", shape=ellipse, style=filled, fillcolor="#cfe8ff"];
    Permission [label="Permission", shape=ellipse, style=filled, fillcolor="#d5f5d5"];

    // Function -> DB dependency (data flow)
    list_roles       -> db [label="query"];
    get_role         -> db [label="query"];
    create_role      -> db [label="insert/commit"];
    list_permissions -> db [label="query"];

    // Function -> entity data flow
    list_roles       -> Role       [label="returns [Role]"];
    get_role         -> Role       [label="returns Role"];
    create_role      -> Role       [label="returns Role"];
    list_permissions -> Permission [label="returns [Permission]"];

    // Entity relationship
    create_role -> Permission [label="links permission_ids", style=dashed];
    Role -> Permission [label="has many", style=dashed, dir=both];
}"
  source_name: "userhub"
---
# Roles Diagram

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`



```dot
digraph roles_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // Module cluster
    subgraph cluster_module {
        label="backend.app.services.roles";
        style=dashed;
        color=gray;

        list_roles       [label="list_roles(db)"];
        get_role         [label="get_role(db, role_id)"];
        create_role      [label="create_role(db, name,\ndescription, permission_ids)"];
        list_permissions [label="list_permissions(db)"];
    }

    // External dependency
    db [label="db\n(DB Session)", shape=cylinder, style=filled, fillcolor="#e0e0e0"];

    // Data entities
    Role       [label="Role", shape=ellipse, style=filled, fillcolor="#cfe8ff"];
    Permission [label="Permission", shape=ellipse, style=filled, fillcolor="#d5f5d5"];

    // Function -> DB dependency (data flow)
    list_roles       -> db [label="query"];
    get_role         -> db [label="query"];
    create_role      -> db [label="insert/commit"];
    list_permissions -> db [label="query"];

    // Function -> entity data flow
    list_roles       -> Role       [label="returns [Role]"];
    get_role         -> Role       [label="returns Role"];
    create_role      -> Role       [label="returns Role"];
    list_permissions -> Permission [label="returns [Permission]"];

    // Entity relationship
    create_role -> Permission [label="links permission_ids", style=dashed];
    Role -> Permission [label="has many", style=dashed, dir=both];
}
```