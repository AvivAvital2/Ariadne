---
id: 1428ecb4-0931-5389-9241-afbe925da3d3
type: explanation
title: "Domain constants shared across the backend."
created_at: 2026-07-30T17:21:42.178869+00:00
updated_at: 2026-07-30T17:21:42.178883+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  module_name: "backend.app.constants"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Domain constants shared across the backend.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

# `backend.app.constants` — Domain Constants

## Overview

The `backend.app.constants` module is a central repository for domain constants that are shared across the backend and, critically, across the HTTP boundary with the frontend. It defines three enumerations—`UserStatus`, `Permission`, and `AuditAction`—along with a lookup table (`ALLOWED_STATUS_TRANSITIONS`) that encodes the rules governing how a user account may move between lifecycle states.

The module's most important characteristic is stated plainly in its docstring: the **string values** of these enums form part of the API contract with the frontend. The frontend maintains a parallel set of constants in `frontend/src/constants.js`, and the two sides agree on literal strings such as `"deactivated"`, `"users:deactivate"`, and `"user.deactivated"` purely by convention. There is no shared type or generated schema spanning client and server, so the two files must be kept manually in sync whenever either changes.

## Key Concepts

### String-backed enums

All three classes inherit from both `str` and `Enum`:

```python
class UserStatus(str, Enum):
    ACTIVE = "active"
    ...
```

Subclassing `str` alongside `Enum` produces members that *are* strings. This is a deliberate and important design choice. A `UserStatus.ACTIVE` value can be compared to, serialized as, and used interchangeably with the plain string `"active"`. This makes the enums friendly to JSON serialization (they render directly as their string value) and to comparison against raw request data, without requiring explicit `.value` access at every call site.

### The three domains

- **`UserStatus`** — the lifecycle state of a user account: `ACTIVE`, `INVITED`, or `DEACTIVATED`. These are serialized to and from the frontend as their raw values.

- **`Permission`** — named permission strings that gate each API action, using a `resource:action` naming scheme (e.g. `USERS_DEACTIVATE = "users:deactivate"`). The frontend uses these to hide controls the current user cannot use, while the backend independently enforces them.

- **`AuditAction`** — action verbs recorded in the audit log, using a dotted `resource.verb` scheme (e.g. `USER_DEACTIVATED = "user.deactivated"`). The frontend audit view maps these exact strings to human-readable labels and icons.

### The transition table

`ALLOWED_STATUS_TRANSITIONS` is a dictionary mapping each status value to the set of statuses it may legally transition into:

```python
ALLOWED_STATUS_TRANSITIONS: dict[str, set[str]] = {
    UserStatus.INVITED.value: {UserStatus.ACTIVE.value, UserStatus.DEACTIVATED.value},
    UserStatus.ACTIVE.value: {UserStatus.DEACTIVATED.value},
    UserStatus.DEACTIVATED.value: {UserStatus.ACTIVE.value},
}
```

Note that the keys and set members are `.value` strings, not enum members. This keeps the structure aligned with the string-based data that flows across the API boundary.

## How It Works

### Enum values as the contract

Because each enum member is a string, the values do double duty:

1. Inside the backend, code can reference symbolic names like `Permission.USERS_DEACTIVATE` for clarity and refactor-safety.
2. When those values cross the wire, they become plain strings that the frontend recognizes.

The docstrings emphasize the "two enforcement points, no shared symbol" pattern. For permissions, the frontend hides a UI control when the user lacks a permission string, and the backend separately checks the same string via `security.require_permission`. Both sides rely on the literal string matching—there is no compile-time or runtime guarantee that they agree, only convention.

### Status transition validation

The transition table encodes a small state machine:

- An **invited** user may become **active** (they accept the invite) or be **deactivated**.
- An **active** user may only be **deactivated**.
- A **deactivated** user may be reactivated back to **active**.

Notably, there is no transition *into* the `INVITED` state—it is only ever an initial state. The service layer consults this table to decide whether a requested status change is permitted before applying it.

## Usage Examples

Referencing a permission when enforcing access control:

```python
from backend.app.constants import Permission

security.require_permission(Permission.USERS_DEACTIVATE)
```

Recording an audit entry:

```python
from backend.app.constants import AuditAction

audit_log.record(action=AuditAction.USER_DEACTIVATED, user_id=target.id)
```

Validating a lifecycle transition in the service layer:

```python
from backend.app.constants import ALLOWED_STATUS_TRANSITIONS

def change_status(current: str, requested: str) -> None:
    if requested not in ALLOWED_STATUS_TRANSITIONS.get(current, set()):
        raise ValueError(f"Cannot move from {current!r} to {requested!r}")
```

Because the enums subclass `str`, comparing an incoming request value against a member works directly:

```python
if incoming_status == UserStatus.DEACTIVATED:
    ...  # True when incoming_status == "deactivated"
```

## Integration

This module sits at the base of the backend's dependency graph—it imports nothing but the standard library `enum` module, so any part of the backend can depend on it without risk of circular imports.

Its constants surface in several places:

- **Security enforcement** — the `Permission` enum feeds `security.require_permission`, the backend's authorization gate.
- **Audit logging** — the `AuditAction` enum supplies the canonical action strings written to the audit log.
- **Service layer** — `ALLOWED_STATUS_TRANSITIONS` drives validation of user status changes.
- **Frontend** — `frontend/src/constants.js` mirrors these same string values. The frontend uses them to hide UI controls (permissions) and to render human-friendly labels and icons (audit actions).

The key integration concern is the manual synchronization requirement. Because the client and server share only string literals and not a type or schema, any change to an enum value here must be accompanied by a matching change in the frontend constants file. The module docstring calls this out explicitly as the primary maintenance obligation.