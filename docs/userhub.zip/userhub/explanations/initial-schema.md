---
id: b0c509dc-0265-52b8-afb1-6a67a240353c
type: explanation
title: "initial schema"
created_at: 2026-07-30T17:20:58.015284+00:00
updated_at: 2026-07-30T17:20:58.015302+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  module_name: "backend.alembic.versions.0001_initial"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# initial schema

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

# Initial Schema Migration (`0001_initial`)

## Overview

This module is the **first Alembic migration** in the project's database version history. It defines the foundational schema for a user management and access-control system, creating six tables that model users, their roles, and permissions, along with an audit trail.

As the initial migration, it establishes the baseline against which all future schema changes are compared. It has no predecessor (`down_revision = None`), meaning running `alembic upgrade head` on a fresh database begins here.

The module exposes two functions:

- `upgrade()` — applies the schema by creating tables and indexes.
- `downgrade()` — reverts the schema by dropping all created tables.

## Key Concepts

### Alembic Migrations

Alembic is SQLAlchemy's database migration tool. Each migration is a Python module with a unique identity and a defined position in a linear (or branching) chain of revisions. The module-level metadata variables control this positioning:

| Variable | Value | Meaning |
|----------|-------|---------|
| `revision` | `"0001_initial"` | This migration's unique ID |
| `down_revision` | `None` | No prior migration — this is the root |
| `branch_labels` | `None` | Not part of a named branch |
| `depends_on` | `None` | No cross-branch dependencies |

Because `down_revision` is `None`, Alembic treats this as the starting point of the migration history.

### The Operations Object (`op`)

All schema changes are performed through Alembic's `op` proxy, which issues database-agnostic DDL statements (`create_table`, `create_index`, `drop_table`). This lets the same migration run against different database backends.

### Schema Domain Model

The six tables form a classic **Role-Based Access Control (RBAC)** structure plus auditing:

- **Core entities**: `users`, `roles`, `permissions`
- **Association tables** (many-to-many links): `user_roles`, `role_permissions`
- **Auditing**: `audit_log`

## How It Works

### The `upgrade()` Function

The function creates tables in a deliberate order so that foreign key references always point to tables that already exist.

**1. `users` table**

The central entity. Notable design choices:

- `username` and `email` are both `nullable=False` and `unique=True`, guaranteeing every user has distinct identifiers.
- `status` defaults to `"invited"` via `server_default`, implying users are created in an invited state before becoming active.
- `full_name` defaults to an empty string rather than allowing NULL, avoiding null-handling in application code.
- An explicit index is added on `username` to speed up lookups:

```python
op.create_index("ix_users_username", "users", ["username"])
```

**2. `roles` and `permissions` tables**

These are structurally identical simple lookup tables, each with a unique `name` and an optional `description`. They represent the two building blocks of the access model.

**3. Association tables**

`user_roles` and `role_permissions` implement many-to-many relationships. Each uses a **composite primary key** made of two foreign keys:

```python
sa.Column("user_id", sa.Integer, sa.ForeignKey("users.id"), primary_key=True),
sa.Column("role_id", sa.Integer, sa.ForeignKey("roles.id"), primary_key=True),
```

By making both columns part of the primary key, the schema enforces that a given user-role (or role-permission) pairing can only exist once. This is the standard pattern for a link table.

The resulting relationship chain is:

```
users ── user_roles ── roles ── role_permissions ── permissions
```

A user's effective permissions are derived by traversing from their roles.

**4. `audit_log` table**

This table records actions taken within the system. Key details:

- `actor_id` is a **nullable** foreign key to `users.id`. Nullability allows logging system-initiated actions where no human actor exists.
- `target_type` defaults to `"user"`, indicating audit entries most commonly concern user records, but the column allows other target types.
- `target_id` is nullable and, notably, is *not* a foreign key. This is a deliberate trade-off: it can reference records in different tables (as indicated by `target_type`) without being tied to a single one.
- `detail` is a `Text` column for free-form descriptions.

Two indexes support common query patterns — filtering by `action` and ordering or filtering by `created_at`:

```python
op.create_index("ix_audit_log_action", "audit_log", ["action"])
op.create_index("ix_audit_log_created_at", "audit_log", ["created_at"])
```

### The `downgrade()` Function

The downgrade reverses the migration by dropping every table. Crucially, it drops them in **reverse dependency order**:

```python
for table in (
    "audit_log",
    "role_permissions",
    "user_roles",
    "permissions",
    "roles",
    "users",
):
    op.drop_table(table)
```

Tables containing foreign keys are dropped before the tables they reference. For example, `user_roles` (which references `users` and `roles`) is dropped before either `users` or `roles`. This ordering prevents foreign key constraint violations during teardown.

## Usage Examples

Migrations are typically not called directly; they are driven by the Alembic CLI.

**Apply the migration to a fresh database:**

```bash
alembic upgrade head
```

Because this is the first revision, `head` resolves to `0001_initial` (until later migrations are added), and `upgrade()` runs.

**Revert the migration entirely:**

```bash
alembic downgrade base
```

This runs `downgrade()`, dropping all six tables and returning the database to an empty state.

**Move to this specific revision:**

```bash
alembic upgrade 0001_initial
```

## Integration

### Relationship to Alembic

This module fits into the broader Alembic migration system. The `alembic/versions/` directory holds all migration files, and Alembic reads the `revision` / `down_revision` metadata to build the migration chain. Any subsequent migration will set its `down_revision` to `"0001_initial"`, chaining onto this baseline.

### Relationship to the Application Models

The tables defined here are expected to correspond to SQLAlchemy ORM models elsewhere in the application. The migration is the authoritative source for the *physical* schema, while the ORM models describe how the application interacts with it. Keeping them in sync is the developer's responsibility — Alembic can autogenerate migrations by comparing models against the current database state, but this initial migration establishes the ground truth.

### Design Implications for the Rest of the System

Several decisions in this schema constrain application behavior:

- The RBAC structure means authorization logic must traverse users → roles → permissions rather than checking permissions on users directly.
- The `status` default of `"invited"` suggests an invitation-based onboarding flow that application code must handle.
- The audit log's flexible, non-foreign-keyed `target_id`/`target_type` design means referential integrity for audit targets is enforced by convention in application code, not the database.

Understanding this migration is the natural starting point for anyone learning the data model, since it defines the tables every other part of the persistence layer builds upon.