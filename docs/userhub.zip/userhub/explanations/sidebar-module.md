---
id: 2913aadd-7bbe-557b-bcfe-2fe8682eaccc
type: explanation
title: "Sidebar Module"
created_at: 2026-07-30T17:28:24.366455+00:00
updated_at: 2026-07-30T17:28:24.366474+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx
metadata:
  module_name: "frontend.src.components.Sidebar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Sidebar Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx`

# Sidebar Component

**Module**: `frontend.src.components.Sidebar`

## Overview

The `Sidebar` module defines a React presentational component that renders the primary navigation panel for the UserHub application. It displays the application brand, a list of navigable sections (with associated icons), and — when available — a footer showing information about the currently authenticated user.

As a presentational component, `Sidebar` holds no internal state of its own. All of its data and behavior are supplied by its parent through props, which makes it easy to reason about and reuse.

## Key Concepts

### Icon Mapping

The module maintains a static lookup table, `ICONS`, that maps string keys to icon components imported from `Icons.jsx`:

```javascript
const ICONS = {
  dashboard: IconDashboard,
  users: IconUsers,
  roles: IconShield,
  audit: IconActivity,
};
```

This indirection lets navigation items reference an icon by a simple string key (such as `"users"`) rather than importing and passing the icon component directly. Only keys present in this map will render an icon; any unrecognized key simply omits the icon.

### Props-Driven Rendering

The component accepts four props:

| Prop | Purpose |
|------|---------|
| `items` | An array of navigation entries, each with a `key` and a `label` |
| `active` | The `key` of the currently selected navigation item |
| `onNavigate` | A callback invoked with an item's `key` when it is clicked |
| `actor` | An optional object representing the current user |

Because the component is stateless, the source of truth for the active section and the current user lives in the parent. The `Sidebar` only reflects that state and reports user intent back up via `onNavigate`.

### The `initials` Helper

A small utility function derives up to two uppercase characters from a username to display inside an avatar circle:

```javascript
function initials(name) {
  return (name || "?").slice(0, 2).toUpperCase();
}
```

The `name || "?"` fallback ensures the function returns a sensible value even when `name` is `undefined`, empty, or otherwise falsy, guarding against rendering a blank avatar.

## How It Works

The component renders an `<aside className="sidebar">` element composed of three regions:

**1. Brand section.** A fixed header displaying the application mark (`UH`) and name (`UserHub`). This section is static and does not depend on props.

**2. Navigation section.** The component iterates over the `items` array and renders one `<button>` per entry:

- Each button uses `item.key` as its React `key`, which requires those keys to be unique across the list.
- The `active` prop is compared against `item.key`; when they match, the `active` CSS class is appended, allowing the current section to be styled distinctly.
- The corresponding icon is looked up in `ICONS`. The `Icon && <Icon size={18} />` expression renders the icon only if one exists for that key, avoiding errors for keys without a mapped icon.
- Clicking a button calls `onNavigate(item.key)`, delegating the actual navigation logic to the parent.

**3. Footer section.** The footer is rendered conditionally with `actor && (...)`, so it appears only when an `actor` object is provided. When present, it shows:

- An avatar containing the user's initials, produced by `initials(actor.username)`.
- A display name that prefers `actor.full_name` but falls back to `actor.username` if the full name is not set.
- The username prefixed with `@`.

## Usage Example

A parent component would typically manage the active section and pass the navigation configuration and callback:

```javascript
import Sidebar from "./components/Sidebar.jsx";

const NAV_ITEMS = [
  { key: "dashboard", label: "Dashboard" },
  { key: "users", label: "Users" },
  { key: "roles", label: "Roles" },
  { key: "audit", label: "Audit Log" },
];

function App() {
  const [active, setActive] = useState("dashboard");
  const currentUser = { username: "jdoe", full_name: "Jane Doe" };

  return (
    <Sidebar
      items={NAV_ITEMS}
      active={active}
      onNavigate={setActive}
      actor={currentUser}
    />
  );
}
```

In this example, item keys align with the entries in `ICONS`, so each navigation button renders with its matching icon. Selecting an item updates `active`, which the `Sidebar` reflects by highlighting the corresponding button.

## Integration

- **`Icons.jsx`**: The sole direct dependency. The component imports four icon components (`IconActivity`, `IconDashboard`, `IconShield`, `IconUsers`) and expects them to accept a `size` prop.
- **Parent container**: The component relies on a parent to own navigation state and supply the `items`, `active`, `onNavigate`, and `actor` props. It communicates user intent upward exclusively through `onNavigate`.
- **Styling**: All visual presentation depends on external CSS targeting the class names used here (`sidebar`, `brand`, `nav`, `nav-item`, `active`, `sidebar-footer`, `avatar`, `who`, and others). These class names form the contract between this component and the application's stylesheet.

Because it maintains no state and has no side effects, `Sidebar` is straightforward to test and reuse: rendering it with a fixed set of props always produces the same output, and its only external interaction is the `onNavigate` callback.