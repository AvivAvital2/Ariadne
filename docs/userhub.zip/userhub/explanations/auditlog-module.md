---
id: 606eeee7-692a-5d04-a0d2-b2ede0e43f01
type: explanation
title: "Auditlog Module"
created_at: 2026-07-30T17:27:10.848784+00:00
updated_at: 2026-07-30T17:27:10.848798+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx
metadata:
  module_name: "frontend.src.components.AuditLog"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Auditlog Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx`

# AuditLog Component

## Overview

The `AuditLog` module defines a React component that renders a read-only table of audit log entries. Its purpose is to give users a chronological view of significant actions performed within the system — for example, when records were created, deactivated, deleted, or reactivated.

The component fetches audit data from the backend on mount, formats it for human readability, and displays it in a styled table. It also provides basic visual cues (colored dots) to help users quickly distinguish the nature of each action, and gracefully handles fetch errors.

## Key Concepts

### Functional Component with Hooks

`AuditLog` is a functional React component that uses two hooks:

- `useState` — to manage the list of audit entries and any error state.
- `useEffect` — to perform the data fetch when the component first mounts.

This is the standard modern React pattern for components that load data asynchronously and render based on it.

### Local State

The component maintains two pieces of state:

- `entries` — an array of audit log records fetched from the API (initialized as an empty array).
- `error` — a string error message, or `null` if no error has occurred.

Because `entries` starts as an empty array, the table renders cleanly (with no rows) before the data arrives.

### Action Classification

A key concept is the semantic categorization of actions. Two helper functions translate raw action strings into user-facing presentation:

- `dotClass(action)` — maps an action to a CSS class (`good`, `bad`, or `neutral`) used to color a status dot.
- `label(action)` — maps an action to a friendly display label using the `AUDIT_ACTION_LABELS` lookup table.

This separation keeps the backend's raw action identifiers (e.g. `"user_created"`) decoupled from how they appear in the UI.

## How It Works

### 1. Fetching Data on Mount

When the component mounts, the `useEffect` hook runs once (its dependency array is empty):

```javascript
useEffect(() => {
  api.listAudit().then(setEntries).catch((e) => setError(e.message));
}, []);
```

- `api.listAudit()` returns a promise that resolves to the array of audit entries.
- On success, `setEntries` stores the results in state, triggering a re-render.
- On failure, the error's `message` is captured into `error` state.

Because the effect has no dependencies, it runs exactly once per mount and does not re-fetch on subsequent renders.

### 2. Deriving the Action Label

The `label` helper looks up a friendly name for each action:

```javascript
const label = (action) => AUDIT_ACTION_LABELS[action] ?? action;
```

If the action is not present in the `AUDIT_ACTION_LABELS` map, the raw action string is used as a fallback (via the nullish coalescing operator `??`). This ensures the UI never renders `undefined` even if a new, unmapped action type appears.

### 3. Classifying the Status Dot

The `dotClass` function inspects the action string for keywords:

```javascript
function dotClass(action) {
  if (action.includes("deactivated") || action.includes("deleted")) return "bad";
  if (action.includes("created") || action.includes("reactivated")) return "good";
  return "neutral";
}
```

- Destructive actions (`deactivated`, `deleted`) map to `"bad"`.
- Constructive actions (`created`, `reactivated`) map to `"good"`.
- Anything else defaults to `"neutral"`.

This keyword-matching approach is flexible — it works for any action string containing these substrings, without requiring an exhaustive list. The trade-off is that it relies on a naming convention in the backend's action identifiers; an action whose name doesn't contain these keywords will silently fall into `"neutral"`.

### 4. Rendering the Table

The component returns a `<section>` styled as a card containing:

- **A header** with the title "Audit log" and a subtitle showing the current entry count (`entries.length`).
- **A conditional error banner**, rendered only when `error` is truthy.
- **A table** with columns for *When*, *Action*, *Actor*, *Target*, and *Detail*.

Each entry becomes a table row, keyed by `entry.id`. Notable rendering details:

- **When**: `entry.created_at` is parsed into a `Date` and formatted with `toLocaleString()`, adapting to the user's locale and timezone.
- **Action**: shows a colored dot (via `dotClass`) alongside the human-readable label (via `label`).
- **Actor**: displays `entry.actor_id`, falling back to an em dash (`"—"`) when null or undefined.
- **Target**: combines `entry.target_type` and `entry.target_id` (e.g. `user #42`), with a dash fallback for the ID.
- **Detail**: displays the raw `entry.detail` text.

The em-dash fallbacks (`?? "—"`) keep the table visually consistent when optional fields are absent.

## Usage Examples

The component is self-contained and takes no props. It is used simply by rendering it wherever the audit log should appear:

```javascript
import AuditLog from "./components/AuditLog.jsx";

function AdminPage() {
  return (
    <div>
      <h2>Administration</h2>
      <AuditLog />
    </div>
  );
}
```

All data loading, formatting, and error handling happens internally, so no additional wiring is required by the consumer.

## Integration

The `AuditLog` component connects to the rest of the system through two imports:

- **`../api/client.js`** — The API client module, imported as a namespace (`api`). The component depends specifically on `api.listAudit()`, which is expected to return a promise resolving to an array of audit entry objects. Each entry is expected to expose the fields `id`, `created_at`, `action`, `actor_id`, `target_type`, `target_id`, and `detail`.

- **`../constants.js`** — Provides the `AUDIT_ACTION_LABELS` object, a lookup map from raw action identifiers to display-friendly labels. Centralizing these labels in a constants module keeps display text consistent across the application and separate from component logic.

The component assumes a stylesheet elsewhere in the application defines the CSS classes it references — `card`, `card-head`, `card-sub`, `error`, `action`, `dot`, `good`, `bad`, `neutral`, `muted`, and `nowrap`. These class names govern the visual presentation but are not defined within this module.

Overall, `AuditLog` sits at the presentation layer: it delegates data retrieval to the API client, delegates label definitions to a shared constants file, and focuses solely on transforming and displaying audit data.