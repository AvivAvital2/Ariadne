---
id: 89237fe7-f4d1-57c6-a678-1d3c729d2c99
type: explanation
title: "Config Module"
created_at: 2026-07-30T17:31:07.723242+00:00
updated_at: 2026-07-30T17:31:07.723253+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js
metadata:
  module_name: "frontend.vite.config"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Config Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js`

# `frontend.vite.config` — Vite Configuration

## Overview

This module is the [Vite](https://vitejs.dev/) build tool configuration for the frontend application. It defines how the development server behaves and which plugins are active during development and builds.

Its two primary responsibilities are:

1. **Enabling React support** through the official `@vitejs/plugin-react` plugin.
2. **Configuring the development server**, including its port and — most importantly — a proxy that forwards API requests to a FastAPI backend.

The proxy configuration is the centerpiece of this file. It allows the frontend to make same-origin relative API calls during development without running into cross-origin (CORS) issues, even though the frontend and backend run on separate ports.

## Key Concepts

### `defineConfig`

Vite exports a `defineConfig` helper that wraps a configuration object. Passing your config through this function does not change its behavior at runtime — its value is in **editor tooling**. It provides TypeScript/IntelliSense type inference so that config properties are auto-completed and validated as you edit.

### Plugins

Vite is plugin-driven. The `plugins` array registers extensions that hook into the build and dev-server lifecycle. Here, `react()` enables features like JSX transformation and React Fast Refresh (hot module replacement that preserves component state).

### The Dev Server Proxy

A **proxy** in this context is a rule that tells the Vite dev server to forward certain requests to another server instead of trying to resolve them locally. This is a development-only convenience: it lets the browser talk to a single origin (the Vite server) while requests matching a pattern are transparently relayed to the backend.

## How It Works

The configuration object has two top-level keys under the exported config.

### 1. Plugin Registration

```javascript
plugins: [react()]
```

Calling `react()` returns a configured plugin instance, which is added to Vite's plugin pipeline. This activates React-specific handling for the project's source files.

### 2. Server Configuration

```javascript
server: {
  port: 5173,
  proxy: {
    "/api": "http://127.0.0.1:8000",
  },
}
```

- **`port: 5173`** — The dev server listens on port `5173` (Vite's default). Explicitly stating it makes the intended port clear.

- **`proxy`** — This maps a URL prefix to a target server. Any request whose path begins with `/api` is forwarded to `http://127.0.0.1:8000`, where the FastAPI backend runs.

The request flow during development looks like this:

1. The browser (loaded from `http://localhost:5173`) issues a fetch to a relative URL such as `/api/users/42/status`.
2. Because the URL is relative, it goes to the Vite dev server on port `5173`.
3. Vite matches the `/api` prefix and forwards the request to `http://127.0.0.1:8000/api/users/42/status`.
4. The FastAPI backend handles it and the response is relayed back to the browser.

Since the browser only ever talks to `localhost:5173`, all requests are same-origin from its perspective, sidestepping CORS entirely.

### Two Deliberate Design Decisions (Documented Inline)

The comments in this file capture two non-obvious choices worth highlighting:

**Same-origin relative URLs.** The frontend is expected to issue relative URLs like `/api/users/{id}/status` rather than absolute ones pointing at the backend's port. This keeps frontend code free of hardcoded backend hosts and lets the same relative paths work in production, where the frontend and backend are typically served under one origin.

**Using `127.0.0.1` instead of `localhost`.** The proxy target deliberately uses the literal IPv4 address `127.0.0.1` rather than the hostname `localhost`. On many systems `localhost` resolves to *both* IPv6 (`::1`) and IPv4 (`127.0.0.1`). If the backend only listens on IPv4, an initial attempt to connect over IPv6 fails and forces a fallback, adding latency to every request. Pinning the target to `127.0.0.1` avoids this entirely.

## Usage Examples

This file is not imported or called directly by application code. Vite automatically discovers and loads it (by convention, `vite.config.js` at the project root) when you run Vite commands:

```bash
# Start the development server on port 5173 with the proxy active
npm run dev

# Produce a production build
npm run build
```

For the proxy to be useful, the FastAPI backend must be running separately on port `8000`. Frontend code then makes requests through relative paths, for example:

```javascript
// Resolves against the current origin (localhost:5173),
// then gets proxied to the backend.
const res = await fetch(`/api/users/${userId}/status`);
```

## Integration

This module sits at the boundary between the frontend and backend during local development:

- **Frontend application code** relies on the proxy rule to reach the backend without knowing its host or port. As long as calls use the `/api` prefix, they are routed correctly.
- **The FastAPI backend** on `127.0.0.1:8000` receives forwarded requests. The relative paths used by the frontend are designed to map directly onto the backend's route templates, so no path rewriting is needed.
- **The React plugin** ties into the broader frontend build, but has no direct relationship to the proxy or backend.

Note that the proxy applies only to the Vite **development server**. In production, request routing to the backend must be handled by other infrastructure (such as a reverse proxy or the deployment's server configuration), which is outside the scope of this file.