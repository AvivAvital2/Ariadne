---
id: e1337577-7dec-5be9-9194-d7e2717e2f5d
type: explanation
title: "Hand-written SQL for reporting."
created_at: 2026-07-30T17:22:35.998277+00:00
updated_at: 2026-07-30T17:22:35.998288+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  module_name: "backend.app.reports.queries"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Hand-written SQL for reporting.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`

# `backend.app.reports.queries`

## Overview

This module is a small, focused component of the reporting subsystem. Its sole responsibility is to hold **hand-written SQL** used to generate reports about user activity.

The defining characteristic of this module is stated plainly in its docstring: these queries **read directly from the database tables** (`users` and `audit_log`) **without going through the ORM**. In many Python web applications, database access is mediated by an Object-Relational Mapper (ORM) that translates Python objects into SQL. This module deliberately steps outside that layer for reporting purposes.

At present, the module contains a single query string, `USER_ACTIVITY_SQL`, which produces a summary of each user's activity.

## Key Concepts

### Raw SQL as a module-level constant

The query is defined as a plain Python string constant (`USER_ACTIVITY_SQL`) at module scope. This is a common and intentional pattern for reporting code:

- **Separation of concerns.** The SQL lives in one place, isolated from the code that executes it and processes results. This makes the query easy to locate, review, and modify.
- **Readability of complex queries.** Reporting queries often involve joins, aggregations, and grouping that are cumbersome to express through an ORM's fluent interface. Writing plain SQL keeps the intent clear.

### Bypassing the ORM

The module docstring explicitly notes that these queries do not use the ORM. This is a deliberate design choice with clear trade-offs:

- **Advantages:** Full control over the exact SQL executed, which matters for performance-sensitive aggregate queries and for expressing patterns (like `LEFT JOIN` with `COUNT` and `MAX`) that map awkwardly onto ORM abstractions.
- **Costs:** The application loses the ORM's protections and conveniences, such as automatic entity mapping and, in some cases, dialect portability. Results come back as raw rows rather than mapped model objects.

### The report's data shape

The query returns one row per user, with the following named columns:

| Column | Source | Meaning |
|---|---|---|
| `user_id` | `u.id` | The user's unique identifier |
| `username` | `u.username` | The user's login name |
| `status` | `u.status` | The user's account status |
| `action_count` | `COUNT(a.id)` | Number of audit-log entries attributed to the user |
| `last_action_at` | `MAX(a.created_at)` | Timestamp of the user's most recent action |

## How It Works

The `USER_ACTIVITY_SQL` statement builds a user-activity summary through the following steps:

1. **Start from the users table.** The query begins with `FROM users u`, ensuring every user is a candidate for the report.

2. **Join in audit-log entries.** A `LEFT JOIN audit_log a ON a.actor_id = u.id` connects each user to the audit-log rows where they were the actor. The choice of a **`LEFT JOIN` (rather than an inner join) is significant**: it guarantees that users with *no* recorded actions still appear in the results, rather than being silently dropped.

3. **Group by user.** The `GROUP BY u.id, u.username, u.status` clause collapses all of a user's audit-log rows into a single summary row. All non-aggregated selected columns appear in the `GROUP BY`, as required by standard SQL grouping semantics.

4. **Aggregate activity.** Within each group:
   - `COUNT(a.id)` counts the user's audit-log entries. Because of the `LEFT JOIN`, users with no actions get a count of `0` (SQL's `COUNT` ignores the `NULL`s produced by unmatched rows).
   - `MAX(a.created_at)` finds the most recent action timestamp, which will be `NULL` for users who have never acted.

5. **Order the results.** `ORDER BY action_count DESC` sorts the report so that the most active users appear first — the natural presentation for an activity report.

## Usage Examples

This module only *defines* the query; it does not execute it. Consuming code is expected to import the constant and run it against a database connection or cursor. A typical use looks like this:

```python
from backend.app.reports.queries import USER_ACTIVITY_SQL

rows = connection.execute(USER_ACTIVITY_SQL).fetchall()

for row in rows:
    print(row.username, row.action_count, row.last_action_at)
```

Because the columns are given explicit aliases (`user_id`, `username`, `status`, `action_count`, `last_action_at`), calling code can reliably reference results by these stable names regardless of the underlying column names in the tables.

Note that the query takes **no parameters**. It always summarizes activity across all users, so no filtering values need to be bound at execution time.

## Integration

This module sits at the boundary between the reporting subsystem and the database:

- **Downstream (data).** It reads from two tables: `users` (the source of user identity and status) and `audit_log` (a record of actions, linked to users via the `actor_id` column). The module assumes these tables and columns exist with the referenced names.

- **Upstream (callers).** Some other part of the `backend.app.reports` package is responsible for obtaining a database connection, executing `USER_ACTIVITY_SQL`, and transforming the raw rows into a report format (for example, an API response or an exported file). That execution logic is intentionally kept out of this module.

No other modules were identified as direct dependencies, which is consistent with the module's minimal, single-purpose design: it is a repository of SQL strings, nothing more. This keeps the query definitions loosely coupled from the mechanics of database access and result handling.