---
id: 3cb7a969-f841-5145-b90f-0a1aaf0f40f4
type: explanation
title: "Userlist Module"
created_at: 2026-07-30T17:29:17.798326+00:00
updated_at: 2026-07-30T17:29:17.798340+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx
metadata:
  module_name: "frontend.src.components.UserList"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userlist Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx`

# UserList Component

**Module**: `frontend.src.components.UserList`

## Overview

`UserList` is a React component that renders an administrative table of all users in the system. It provides a complete interface for user management, including viewing user details, creating new users, editing existing ones, deactivating/reactivating accounts, and deleting users.

A central design theme of this component is **permission-driven rendering**: every action is gated behind an explicit permission check tied to the current `actor` (the logged-in user). Controls that the actor is not authorized to use are simply never rendered, rather than being disabled or hidden after the fact.

## Key Concepts

### The `actor` prop

The component receives a single prop, `actor`, representing the authenticated user viewing the list. This object is passed to `hasPermission` to determine which capabilities the current user has. The component itself does not fetch or manage the actor—it is provided by a parent component.

### Permission gating

Four boolean flags are derived once per render from the `actor`:

```javascript
const canCreate = hasPermission(actor, PERMISSIONS.USERS_CREATE);
const canEdit = hasPermission(actor, PERMISSIONS.USERS_EDIT);
const canDeactivate = hasPermission(actor, PERMISSIONS.USERS_DEACTIVATE);
const canDelete = hasPermission(actor, PERMISSIONS.USERS_DELETE);
```

These flags guard the corresponding UI elements. Because they are checked at render time, the interface automatically reflects the actor's authorization level. Note that these are *client-side* checks intended for UI presentation—the underlying API is still responsible for enforcing authorization server-side.

### Component state

The component manages three pieces of local state via `useState`:

- **`users`** — the array of user objects returned from the API.
- **`editing`** — a tri-state value that drives the form. It can be:
  - a **user object** (editing an existing user),
  - the string `"new"` (creating a user), or
  - `null` (no form shown).
- **`error`** — the most recent error message, or `null`.

The overloaded meaning of `editing` is a deliberate simplification: a single state variable controls both *whether* the form appears and *which mode* it operates in.

### Status as data

User status is treated as a data-driven value. The status string is used both as display text and as a CSS class (`badge ${user.status}`), and it is compared against the `USER_STATUS.DEACTIVATED` constant to decide whether to show a "Deactivate" or "Reactivate" button.

## How It Works

### 1. Initial data load

The `load` function calls `api.listUsers()`, stores the result in state on success, or captures the error message on failure:

```javascript
const load = () =>
  api.listUsers().then(setUsers).catch((e) => setError(e.message));
```

A `useEffect` with an empty dependency array runs `load` once when the component first mounts, populating the table.

### 2. Rendering the table

The component renders a card containing a header, an optional error banner, and a table. Each user row displays:

- An **avatar** built from the first two characters of the username, uppercased. A `"?"` fallback protects against a missing username.
- A **name** cell showing `full_name` if present, otherwise falling back to `username`, with the `@username` handle below it.
- **Email**, **status badge**, and a comma-joined list of **role names** (with an em dash `"—"` shown when there are no roles).
- A set of **action buttons**, each conditionally rendered.

### 3. Conditional action buttons

Within each row, action buttons appear based on permissions and the user's current status:

- **Edit** — shown when `canEdit` is true.
- **Deactivate** — shown when `canDeactivate` is true *and* the user is not already deactivated.
- **Reactivate** — shown when `canDeactivate` is true *and* the user is deactivated. The same permission governs both directions of the toggle.
- **Delete** — shown when `canDelete` is true, styled with the `danger` class to signal a destructive action.

### 4. Performing mutating actions

Deactivate, reactivate, and delete all flow through a shared helper, `runAction`:

```javascript
const runAction = async (fn) => {
  setError(null);
  try {
    await fn();
    await load();
  } catch (e) {
    setError(e.message);
  }
};
```

This wrapper standardizes the pattern for every mutation: clear any prior error, run the API call, then reload the list to reflect the change. If anything fails, the error message is surfaced in the UI. Callers pass a thunk (e.g. `() => api.deleteUser(user.id)`) so the actual API invocation is deferred until inside the try/catch.

### 5. Creating and editing users

Clicking **New user** sets `editing` to `"new"`; clicking **Edit** sets it to the specific user object. When `editing` is truthy, the `UserForm` component is rendered:

```javascript
<UserForm
  user={editing === "new" ? null : editing}
  onClose={() => setEditing(null)}
  onSaved={() => {
    setEditing(null);
    load();
  }}
/>
```

The `user` prop is `null` in create mode or the existing user object in edit mode. `UserForm` communicates back through two callbacks: `onClose` simply dismisses the form, while `onSaved` dismisses it *and* reloads the list so the new or updated record appears.

## Usage Example

`UserList` is designed to be dropped into an admin view with the current user supplied as `actor`:

```jsx
import UserList from "./components/UserList.jsx";

function AdminPage({ currentUser }) {
  return (
    <div className="admin">
      <UserList actor={currentUser} />
    </div>
  );
}
```

The component is self-contained: once mounted, it loads its own data and manages its own form and error state. The parent only needs to provide a valid `actor`.

## Integration

`UserList` connects to several other parts of the system:

- **`../api/client.js`** — provides all data operations: `listUsers`, `deactivateUser`, `reactivateUser`, and `deleteUser`. All server communication is delegated here.
- **`../auth/permissions.js`** — supplies `hasPermission`, the single source of truth for authorization decisions in the UI.
- **`../constants.js`** — defines the `PERMISSIONS` and `USER_STATUS` constants, keeping permission keys and status values consistent across the codebase rather than hard-coded strings.
- **`./Icons.jsx`** — provides the `IconPlus` icon used in the "New user" button.
- **`./UserForm.jsx`** — the child component that handles the actual create/edit form. `UserList` owns the decision of *when* to show the form and *what* to do when it closes or saves, while `UserForm` owns the form's internal behavior.

This division of responsibility keeps `UserList` focused on listing and orchestration, delegating detailed form handling, data access, and authorization logic to specialized modules.