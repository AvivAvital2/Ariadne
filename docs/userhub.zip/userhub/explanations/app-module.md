---
id: 478c0a5d-7a9c-56d4-990c-0068db1c932e
type: explanation
title: "App Module"
created_at: 2026-07-30T17:26:29.945554+00:00
updated_at: 2026-07-30T17:26:29.945568+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx
metadata:
  module_name: "frontend.src.App"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# App Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx`

# `frontend.src.App` — Application Root Component

## Overview

The `App` module defines the root React component for the frontend application. It serves as the top-level container that establishes the overall page layout, manages application-wide state (such as the current user and active view), and orchestrates which feature screen is displayed at any given time.

In practical terms, this component is the entry point for the user interface: it renders the persistent navigation chrome (sidebar and topbar) and swaps the main content area between four distinct views—Dashboard, Users, Roles, and Audit log—based on user navigation.

## Key Concepts

### Navigation Configuration (`NAV`)

The module defines a module-level constant, `NAV`, which is an array of navigation entries. Each entry is an object with two fields:

- `key` — a stable identifier used internally to track the active view (e.g., `"dashboard"`).
- `label` — a human-readable string displayed in the UI (e.g., `"Dashboard"`).

```javascript
const NAV = [
  { key: "dashboard", label: "Dashboard" },
  { key: "users", label: "Users" },
  { key: "roles", label: "Roles" },
  { key: "audit", label: "Audit log" },
];
```

This structure is the single source of truth for navigation. It is passed to the sidebar to render the menu, and it is used to derive the page title. Keeping this configuration as data (rather than hard-coded markup) means the navigation list and its labels can be maintained in one place.

### Component State

`App` uses React's `useState` hook to manage three pieces of local state:

- **`actor`** — represents the currently authenticated user. It starts as `null` and is populated asynchronously once the current user is fetched. The term "actor" is used consistently throughout, signaling this is the user *performing* actions in the system.
- **`view`** — tracks which screen is currently active. It defaults to `"dashboard"` and holds one of the `key` values from `NAV`.
- **`error`** — holds an error message string (or `null`) used to display failures, currently limited to failures while loading the current user.

### Conditional View Rendering

Rather than using a client-side router, `App` selects which feature component to render through direct conditional checks against the `view` state. This is a lightweight approach suited to an application with a small, fixed set of top-level screens.

## How It Works

### 1. Initial User Load

When the component first mounts, a `useEffect` hook with an empty dependency array runs exactly once:

```javascript
useEffect(() => {
  api.getCurrentUser().then(setActor).catch((e) => setError(e.message));
}, []);
```

This calls `api.getCurrentUser()` from the API client module. On success, the resolved user object is stored in `actor` via `setActor`. On failure, the error's message is captured in `error` via `setError`. Because this runs asynchronously, the initial render occurs with `actor` still `null`; the component re-renders once the request resolves.

### 2. Deriving the Page Title

On every render, the component computes the current page title by looking up the active view in `NAV`:

```javascript
const title = NAV.find((n) => n.key === view)?.label ?? "";
```

The optional chaining (`?.`) and nullish coalescing (`??`) operators ensure that if no matching entry is found, the title safely falls back to an empty string rather than throwing an error.

### 3. Rendering the Layout

The component returns a layout composed of three regions:

- A **`Sidebar`**, which receives the full `NAV` list, the currently `active` view, an `onNavigate` callback (wired directly to `setView`), and the `actor`. When the user clicks a navigation item, the sidebar calls `onNavigate` with the corresponding key, updating `view` and triggering a re-render.
- A **`Topbar`**, which displays the derived `title` and the `actor`.
- A **content area**, which conditionally renders the active feature component.

### 4. Content Switching

Within the content area, an error banner is shown when `error` is set, followed by exactly one feature component based on `view`:

```javascript
{error && <div className="error">{error}</div>}
{view === "dashboard" && <Dashboard />}
{view === "users" && <UserList actor={actor} />}
{view === "roles" && <RoleManager actor={actor} />}
{view === "audit" && <AuditLog />}
```

Note the difference in props: `UserList` and `RoleManager` both receive the `actor`, because those views involve actions that depend on who is performing them (e.g., permission checks). By contrast, `Dashboard` and `AuditLog` receive no props, indicating they are read-only or self-contained views.

## Usage Examples

`App` is designed to be mounted once as the root of the React tree, typically in an application entry file:

```javascript
import { createRoot } from "react-dom/client";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(<App />);
```

The component takes no props and manages its own state internally, so no configuration is required at the call site. All behavior—user loading, navigation, and view switching—is self-contained.

## Integration

`App` sits at the center of the frontend and connects several other parts of the system:

- **API client (`./api/client.js`)** — `App` depends on `api.getCurrentUser()` to identify the authenticated user. This is the module's only direct data-fetching responsibility; individual feature components are expected to handle their own data needs.
- **Layout components** — `Sidebar` and `Topbar` provide the persistent UI shell. The sidebar drives navigation by invoking `onNavigate`, making it the primary mechanism through which the `view` state changes.
- **Feature components** — `Dashboard`, `UserList`, `RoleManager`, and `AuditLog` each implement a top-level screen. `App` decides which one is visible and, where relevant, passes down the `actor` so those components can tailor behavior to the current user.

In this arrangement, `App` acts as the coordinator: it owns cross-cutting state (the current user and the active view) and delegates all feature-specific logic to the child components it renders.