---
id: ed065b1d-c828-50f4-9d74-03028b025ebd
type: explanation
title: "Roles Module"
created_at: 2026-07-30T17:23:59.438942+00:00
updated_at: 2026-07-30T17:23:59.438961+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  module_name: "backend.app.routers.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

# Roles and Permissions Router

## Overview

The `backend.app.routers.roles` module defines the HTTP API endpoints for managing roles and permissions within the application. It exposes three routes under the `/api/roles` and `/api/permissions` paths:

- `GET /api/roles` — retrieve all roles
- `POST /api/roles` — create a new role
- `GET /api/permissions` — retrieve all available permissions

This module is a thin **routing layer**. Its responsibility is to accept HTTP requests, enforce access control, delegate the actual work to a service layer, and shape the response according to well-defined schemas. It deliberately contains no business logic itself, which keeps the endpoints easy to read and the domain logic reusable and testable in isolation.

## Key Concepts

### The APIRouter

The module creates a FastAPI `APIRouter` tagged with `"roles"`:

```python
router = APIRouter(tags=["roles"])
```

The `tags` argument groups these endpoints together in generated OpenAPI documentation. This router is intended to be included in the main application instance elsewhere in the codebase.

### Dependency Injection

FastAPI's dependency system is used throughout via the `Depends` helper. Two dependencies appear in every endpoint:

- **`get_db`** — provides a SQLAlchemy `Session` for database access. FastAPI resolves this per request, and the session lifecycle (creation and cleanup) is managed inside `get_db`.
- **`require_permission(...)`** — an access-control dependency that both authenticates the caller and verifies they hold a specific permission. It returns the authenticated `User`, bound here to the `actor` parameter.

By expressing these as dependencies rather than inline code, the framework handles resolution automatically before the endpoint body runs. If a dependency fails (for example, the user lacks the required permission), FastAPI short-circuits the request with an appropriate error response and the endpoint function never executes.

### Permission-Based Authorization

Access is controlled through named permissions defined in the `Permission` enum from `app.constants`. Each endpoint declares the permission it requires:

- `list_roles` requires `Permission.USERS_READ`
- `create_role` requires `Permission.ROLES_MANAGE`
- `list_permissions` requires `Permission.ROLES_MANAGE`

Note that listing roles requires only read access to users, while creating roles and listing permissions require the more privileged `ROLES_MANAGE` permission. This reflects a design distinction: viewing which roles exist is a relatively low-sensitivity operation, whereas modifying roles or inspecting the full permission catalog is restricted to administrators.

The `.value` accessor is used (`Permission.USERS_READ.value`) because `require_permission` expects the underlying permission string rather than the enum member itself.

### Response and Request Schemas

The endpoints use Pydantic schemas to define their input and output contracts:

- **`RoleOut`** — the serialized representation of a role returned to clients.
- **`RoleCreate`** — the request body for creating a role, containing `name`, `description`, and `permission_ids`.
- **`PermissionOut`** — the serialized representation of a permission.

Declaring `response_model` on each route tells FastAPI to validate and serialize the return value against the schema, ensuring the response shape is consistent and documented.

## How It Works

Each endpoint follows the same pattern: resolve dependencies, delegate to the service layer, and return the result.

### Listing Roles

```python
@router.get("/api/roles", response_model=list[RoleOut])
def list_roles(db, actor):
    return role_service.list_roles(db)
```

When a `GET /api/roles` request arrives, FastAPI first resolves `get_db` to obtain a session and then `require_permission(Permission.USERS_READ.value)` to authenticate and authorize the caller. If both succeed, the function calls `role_service.list_roles(db)` and returns the list of roles. FastAPI serializes each item as a `RoleOut`.

### Creating a Role

```python
@router.post("/api/roles", response_model=RoleOut, status_code=201)
def create_role(payload, db, actor):
    return role_service.create_role(
        db,
        name=payload.name,
        description=payload.description,
        permission_ids=payload.permission_ids,
    )
```

The `POST /api/roles` endpoint accepts a JSON body that FastAPI parses and validates into a `RoleCreate` instance (`payload`). After the `ROLES_MANAGE` permission check passes, the endpoint unpacks the payload fields and passes them explicitly to `role_service.create_role`. Passing fields individually rather than forwarding the whole payload keeps the service function decoupled from the HTTP schema.

The route returns HTTP `201 Created` on success, following REST conventions for resource creation, and serializes the created role as `RoleOut`.

### Listing Permissions

```python
@router.get("/api/permissions", response_model=list[PermissionOut])
def list_permissions(db, actor):
    return role_service.list_permissions(db)
```

This endpoint mirrors `list_roles` in structure but returns the catalog of available permissions and requires `ROLES_MANAGE`. Because assigning permissions to roles requires knowing which permissions exist, this endpoint typically supports administrative role-management workflows.

## Usage Examples

These endpoints are consumed over HTTP. Assuming an authenticated client with the appropriate permissions:

**Retrieve all roles:**
```
GET /api/roles
```
Returns a JSON array of role objects.

**Create a role:**
```
POST /api/roles
Content-Type: application/json

{
  "name": "Editor",
  "description": "Can edit content",
  "permission_ids": [1, 2, 3]
}
```
Returns `201 Created` with the newly created role object.

**Retrieve all permissions:**
```
GET /api/permissions
```
Returns a JSON array of permission objects, useful for populating `permission_ids` when creating or editing roles.

A caller lacking the required permission will receive an authorization error before the endpoint logic runs.

## Integration

This module sits at the boundary between the HTTP layer and the application's internal services, connecting several parts of the system:

- **`app.services.roles`** — the service layer that contains the actual database logic for listing roles, creating roles, and listing permissions. This router delegates all real work here, which keeps domain logic separate from transport concerns.
- **`app.database.get_db`** — supplies request-scoped SQLAlchemy sessions.
- **`app.security.require_permission`** — enforces authentication and permission checks, returning the acting `User`.
- **`app.constants.Permission`** — the canonical source of permission identifiers, ensuring endpoints reference permissions by a shared, typed enum rather than magic strings.
- **`app.schemas`** — defines the request and response contracts (`RoleCreate`, `RoleOut`, `PermissionOut`).
- **`app.models.User`** — the domain model representing the authenticated actor.

The `router` object defined here must be registered with the main FastAPI application (typically via `app.include_router(...)`) for these endpoints to become active. Once registered, the routes participate in the application's shared middleware, dependency system, and automatically generated OpenAPI documentation under the `roles` tag.