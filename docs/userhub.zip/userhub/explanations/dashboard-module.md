---
id: 16499dfe-7d84-5bbd-8cd6-2a191fab9cae
type: explanation
title: "Dashboard Module"
created_at: 2026-07-30T17:27:44.349183+00:00
updated_at: 2026-07-30T17:27:44.349202+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx
metadata:
  module_name: "frontend.src.components.Dashboard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Dashboard Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx`

# Dashboard Component

**Module**: `frontend.src.components.Dashboard`

## Overview

The `Dashboard` module defines a React component that serves as the main analytics and summary view of the application. It fetches user, role, and audit data from the backend, transforms that raw data into aggregated statistics, and renders them through a collection of visual widgets: summary stat cards, trend charts, distribution charts, and an activity feed.

Its purpose is to give administrators an at-a-glance operational overview — how many users exist and in what state, how activity has trended over the past week, how users are distributed across roles, who the most active users are, and what recently happened in the system.

The component is self-contained: it manages its own data fetching, holds all derived computations in helper functions within the same file, and renders directly to a structured layout of cards.

## Key Concepts

### Container Component with Local State

`Dashboard` is a stateful function component. It uses React hooks (`useState`, `useEffect`, `useMemo`) rather than external state management. All fetched data lives in local component state:

- `users` — list of user records
- `roles` — list of role definitions
- `audit` — audit log events
- `report` — a pre-aggregated activity report (described as coming "from the SQL activity report")
- `error` — a captured error message string, or `null`

### Separation of Fetching, Computation, and Rendering

The module cleanly separates three responsibilities:

1. **Fetching** happens once in a `useEffect` on mount.
2. **Computation** happens in the pure `computeStats` function, memoized to avoid recomputing on every render.
3. **Rendering** consumes the computed `stats` object and maps it to presentational child components.

This separation makes the derived-statistics logic testable in isolation and keeps the JSX focused on layout.

### Derived Data Structures

The central data structure is the `stats` object returned by `computeStats`. It is a flat bag of ready-to-render values, so the render function never has to compute anything inline. Its notable fields include:

- Scalar counts: `total`, `active`, `invited`, `deactivated`, `events7d`
- `activity` — a 7-element array of `{ label, value }` points for the trend chart
- `statusData` — status distribution formatted for the donut chart
- `roleData` — per-role user counts for a bar chart
- `activeUsers` — top-5 most active users for a bar chart
- `recent` — the 7 most recent audit events for the feed

### Chart-Friendly Shapes

Chart components expect data in a consistent `{ label, value, color }` shape. Much of `computeStats` is about reshaping raw records into this format, attaching colors from `STATUS_COLOR` or the shared `SERIES_BLUE` constant.

## How It Works

### 1. Data Loading

On mount, the effect fires four API calls in parallel via `Promise.all`:

```javascript
Promise.all([
  api.listUsers(),
  api.listRoles(),
  api.listAudit(),
  api.userActivityReport(),
])
```

Parallel loading minimizes total wait time since the four requests are independent. When all resolve, the results are destructured and written into their respective state slots. If any request rejects, the `.catch` stores the error message, which is later rendered in an error banner. The empty dependency array (`[]`) ensures this runs only once.

### 2. Computing Statistics

Whenever any of the four data slices change, `useMemo` recomputes `stats` by calling `computeStats(users, roles, audit, report)`. Because the initial state values are empty arrays, the first render produces a valid (empty) `stats` object before data arrives, which prevents undefined-access errors during loading.

Inside `computeStats`:

**Status tallying** — a single pass over `users` builds a `byStatus` map counting how many users fall into each status.

**Role distribution** — for each role, it counts users whose `roles` array contains that role's id:

```javascript
value: users.filter((u) => u.roles.some((x) => x.id === r.id)).length
```

This is an O(roles × users × rolesPerUser) computation, acceptable for typical admin-scale data.

**7-day activity trend** — it constructs an array of the last seven `Date` objects (oldest first), then walks the audit log and increments the bucket whose day matches each event's `created_at`. The `sameDay` helper compares year, month, and day. The resulting per-day counts feed both the `activity` chart array and the `events7d` total.

**Most active users** — the `report` array is copied (`.slice()` to avoid mutating state), sorted descending by `action_count`, trimmed to the top five, filtered to drop zero-activity entries, and mapped into chart shape.

**Recent activity** — the audit log is copied, sorted by `created_at` descending, and sliced to the seven newest events.

### 3. Rendering

The component renders in two regions:

- A **stat row** of four `StatCard`s showing totals, active/deactivated counts with percentage hints (via `pct`), and the 7-day event count.
- A **panel grid** of cards containing the area trend, status donut, role bar chart, active-users bar chart, and the recent-activity feed.

Several panels guard against empty data — for example, the role chart shows "No roles yet." when `roleData` is empty, and the feed shows "No activity yet." when there are no events. This gives graceful empty states during loading or on fresh systems.

The activity feed maps each event to a list item, applying:
- A colored status dot via `dotClass`, which inspects the action string for keywords (`deactivated`/`deleted` → `bad`, `created`/`reactivated` → `good`, otherwise `neutral`).
- A human-readable action label from `AUDIT_ACTION_LABELS`, falling back to the raw action if unmapped (`?? e.action`).
- A relative timestamp via `timeAgo`, which converts an ISO string into "just now", "Nm ago", "Nh ago", or "Nd ago".

### Helper Functions

The module includes small, pure formatting helpers:

- `pct(n, total)` — safe percentage formatting that returns `"0%"` when `total` is zero, avoiding division-by-zero.
- `fmtDay(d)` — formats a date as a short weekday name using the runtime's default locale.
- `sameDay`, `dotClass`, `timeAgo` — as described above.

Their purity makes them straightforward to reason about and reuse.

## Usage Examples

`Dashboard` takes no props and manages everything internally, so it is used simply as a route or page element:

```jsx
import Dashboard from "./components/Dashboard.jsx";

function App() {
  return <Dashboard />;
}
```

There is no configuration surface — behavior is driven entirely by the data returned from the API layer.

## Integration

The component sits at the intersection of several parts of the system:

### API Layer

All data comes from `../api/client.js`, imported as `api`. The component depends on four functions:

- `api.listUsers()` — expected to return records with `status` and a `roles` array of `{ id }`.
- `api.listRoles()` — records with `id` and `name`.
- `api.listAudit()` — events with `id`, `action`, `target_id`, and `created_at`.
- `api.userActivityReport()` — pre-aggregated rows with `username` and `action_count`.

The card comment "from the SQL activity report" indicates this endpoint is backed by a database aggregation rather than computed client-side, offloading heavier work to the server.

### Constants

`../constants.js` supplies `USER_STATUS` (the canonical status enum used as keys throughout) and `AUDIT_ACTION_LABELS` (a mapping from raw action codes to display strings). Using shared constants keeps status handling consistent across the app and centralizes label wording.

### Presentational Components

Rendering is delegated to a family of child components:

- `StatCard` — a summary tile taking `icon`, `tone`, `label`, `value`, and `hint`.
- `AreaTrend`, `BarChart`, `DonutChart` — chart components consuming the standardized `{ label, value, color }` data shapes.
- `Icons.jsx` — provides the `IconUsers`, `IconUserCheck`, `IconUserX`, and `IconActivity` glyphs passed to stat cards.

By keeping `Dashboard` as a data-and-layout container and pushing all visual rendering into these children, the module remains focused on orchestration: fetch, transform, distribute.