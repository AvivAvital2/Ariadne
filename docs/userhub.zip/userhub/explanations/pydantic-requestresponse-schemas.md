---
id: ff0be81b-7739-52c4-91b0-f2e9841ba767
type: explanation
title: "Pydantic request/response schemas."
created_at: 2026-07-30T17:24:07.737776+00:00
updated_at: 2026-07-30T17:24:07.737791+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  module_name: "backend.app.schemas"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Pydantic request/response schemas.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

# `backend.app.schemas` — Request/Response Schema Definitions

## Overview

The `backend.app.schemas` module defines the data contracts for the application's API layer. Every class in this module is a [Pydantic](https://docs.pydantic.dev/) model, meaning it describes the shape, types, and defaults of data that flows into and out of the backend.

These schemas serve two distinct roles:

- **Request schemas** validate and parse incoming data (for example, the body of a `POST` or `PATCH` request).
- **Response schemas** define exactly which fields are serialized back to the client, decoupling the API's public shape from internal database models.

By centralizing these definitions, the module gives the rest of the system a single source of truth for what user, role, permission, and audit data looks like on the wire.

## Key Concepts

### Pydantic `BaseModel`

Every class inherits from `pydantic.BaseModel`. This provides automatic validation, type coercion, and serialization. When data is passed into one of these models, Pydantic checks that each field matches its declared type and raises a clear validation error if it does not.

### ORM Compatibility with `from_attributes`

Several response schemas include:

```python
model_config = ConfigDict(from_attributes=True)
```

This setting (Pydantic v2's replacement for the older `orm_mode`) allows a model to be constructed directly from an object with matching attributes rather than only from a dictionary. In practice, this means a database ORM row can be handed to the schema and Pydantic will read its attributes to build the response.

Notably, the schemas that **omit** `from_attributes` are all request-side models (`RoleCreate`, `UserCreate`, `UserUpdate`, `UserStatusUpdate`, `RoleAssignment`, `CurrentUser`, `UserActivityRow`). These are built from parsed request payloads or computed values, so they do not need to read from ORM objects.

### Input vs. Output Naming

The module follows a consistent naming convention that signals a schema's direction:

- Suffix **`Out`** (`PermissionOut`, `RoleOut`, `UserOut`, `AuditLogOut`) — data leaving the system.
- Suffix **`Create`** (`RoleCreate`, `UserCreate`) — data for creating new entities.
- Suffix **`Update`** (`UserUpdate`, `UserStatusUpdate`) — data for partial modifications.
- **`Brief`** (`RoleBrief`) — a lightweight subset used when embedding one entity inside another.

### Nested and "Brief" Models

The module distinguishes between full and abbreviated representations of the same entity. `RoleOut` contains full role detail including its permissions, while `RoleBrief` carries only an `id` and `name`. This lets `UserOut` embed a list of roles (`list[RoleBrief]`) without dragging along every permission for every role — a deliberate trade-off that keeps user responses compact.

## How It Works

### Roles and Permissions

Three schemas model the role/permission domain:

- **`PermissionOut`** — a single permission with `id`, `name`, and `description`.
- **`RoleOut`** — a role with its full permission list. The `permissions` field defaults to an empty list, so a role with no permissions serializes cleanly.
- **`RoleBrief`** — the minimal role reference used inside user responses.
- **`RoleCreate`** — the request body for creating a role. Rather than embedding full permission objects, it accepts `permission_ids: list[int]`, so the client references existing permissions by ID.

This ID-based approach for creation is a recurring pattern: incoming requests reference related entities by primary key, while outgoing responses embed the resolved objects.

### Users

The user lifecycle is covered by several schemas:

- **`UserCreate`** requires a `username` and `email`, with optional `full_name` and a list of `role_ids` to assign at creation time.
- **`UserUpdate`** supports partial updates. Both `email` and `full_name` are typed as `str | None` and default to `None`, allowing a client to send only the fields it intends to change.
- **`UserStatusUpdate`** handles the deactivate/reactivate flow specifically. Its docstring notes that `status` carries a raw `UserStatus` value such as `"deactivated"`. Separating status changes into their own schema keeps the state-transition endpoint distinct from general profile edits.
- **`RoleAssignment`** carries a single `role_ids` list, used for updating which roles a user holds.
- **`UserOut`** is the full user response, embedding role briefs and including audit timestamps (`created_at`, `updated_at`).

### The Acting User: `CurrentUser`

`CurrentUser` represents the authenticated user making a request, and it differs meaningfully from `UserOut`. Instead of nested role objects, it carries a flat `permissions: list[str]` field. As its docstring explains, these strings look like `"users:deactivate"` and are the exact values the React frontend checks before rendering each control.

This design flattens the role → permission relationship into a simple list of permission strings, so the frontend can perform straightforward membership checks (e.g., "does this user have `users:deactivate`?") without traversing nested structures.

### Auditing and Reporting

Two schemas support observability:

- **`AuditLogOut`** describes a single audit log entry. Fields like `actor_id` and `target_id` are nullable (`int | None`) to accommodate system-initiated actions or events without a specific target.
- **`UserActivityRow`** represents one row of a raw-SQL user-activity report. Its docstring explicitly notes it maps to raw SQL output. Its fields (`action_count`, `last_action_at`) are aggregates rather than direct entity attributes, and `last_action_at` is nullable to handle users who have taken no actions.

## Usage Examples

**Validating an incoming request body** — a web framework typically instantiates the schema from parsed JSON:

```python
payload = UserCreate(
    username="jdoe",
    email="jdoe@example.com",
    role_ids=[1, 2],
)
```

Missing required fields or wrong types raise a `ValidationError` before the data reaches business logic.

**Serializing a database object for a response** — thanks to `from_attributes=True`:

```python
user_row = db.get_user(user_id)   # an ORM object
response = UserOut.model_validate(user_row)
```

Pydantic reads the attributes off `user_row`, including its nested roles, and produces a validated response model.

## Integration

This module sits at the boundary between the API surface and the rest of the backend:

- **API endpoints** use request schemas (`UserCreate`, `UserUpdate`, `RoleAssignment`, etc.) to declare and validate what they accept, and response schemas (`UserOut`, `RoleOut`, etc.) to declare what they return.
- **ORM/data layer** objects feed directly into the `Out` schemas via `from_attributes`, keeping the persistence layer and the API contract loosely coupled.
- **The React frontend** consumes these response shapes directly. The `CurrentUser.permissions` list of strings, in particular, is designed around the frontend's permission-check logic for conditionally rendering UI controls.
- **Reporting queries** produce `UserActivityRow` instances, letting even raw-SQL results be validated and serialized through the same Pydantic pipeline as the rest of the API.

The only external dependencies are Python's standard `datetime` module (for timestamp fields) and `pydantic` itself, keeping this module lightweight and free of coupling to the framework or database libraries.