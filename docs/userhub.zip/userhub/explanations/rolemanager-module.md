---
id: 035af082-8406-5249-a0c0-14c0ce339310
type: explanation
title: "Rolemanager Module"
created_at: 2026-07-30T17:27:52.105704+00:00
updated_at: 2026-07-30T17:27:52.105719+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx
metadata:
  module_name: "frontend.src.components.RoleManager"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Rolemanager Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx`

# RoleManager Component

## Overview

The `RoleManager` module is a React component that provides a user interface for viewing and managing **roles** within an access-control (RBAC) system. It serves two primary functions:

1. **Display** — Lists all existing roles along with their descriptions and associated permissions.
2. **Creation** — Allows authorized users to create new roles by assigning a name, description, and a set of permissions.

A key design characteristic of this component is that it is **permission-aware**: the ability to see the management controls and create roles is gated behind a specific permission check. Users without the required permission see only the read-only list of roles.

## Key Concepts

### Roles and Permissions

The component operates on two related data structures:

- **Roles** — Each role has an `id`, `name`, `description`, and an array of `permissions`. A role represents a named bundle of permissions that can be assigned to users.
- **Permissions** — Each permission has at least an `id` and a `name`. These are the atomic capabilities that can be grouped into roles.

### The `actor` Prop

The component receives a single prop, `actor`, representing the currently authenticated user. The `actor` drives two behaviors:

- It determines whether the component has enough context to load data (data only loads when `actor` is present).
- It is passed to `hasPermission` to decide whether management features are shown.

### Permission Gating

The line:

```javascript
const canManage = hasPermission(actor, PERMISSIONS.ROLES_MANAGE);
```

computes a single boolean that acts as the gate for privileged behavior. This value influences both **data fetching** (whether the permission list is loaded) and **rendering** (whether the "New role" form appears). Centralizing this check into one variable keeps the authorization logic consistent throughout the component.

### Local State via Hooks

The component manages all of its state locally using `useState`:

| State | Purpose |
|-------|---------|
| `roles` | The list of roles fetched from the API |
| `permissions` | The list of assignable permissions (only loaded for managers) |
| `name` | Controlled input value for the new role's name |
| `description` | Controlled input value for the new role's description |
| `permIds` | The set of permission IDs selected for the new role |
| `error` | The most recent error message, if any |

There is no external state store; all data lives within the component and is refreshed by re-fetching from the API.

## How It Works

### Loading Data

The `load` function is the central data-fetching routine. It:

1. Clears any existing error.
2. Fetches the full role list via `api.listRoles()` and stores it.
3. **Only if** the actor can manage roles, fetches the permission list via `api.listPermissions()`.
4. Catches any error and stores its message in state.

The conditional fetch of permissions is an efficiency and authorization decision: users who cannot create roles have no need for the list of available permissions, so that request is skipped entirely.

Data loading is triggered by an effect:

```javascript
useEffect(() => {
  if (actor) load();
}, [actor]);
```

This runs whenever the `actor` prop changes and only proceeds when an actor is present. This guards against making API calls before a user is known.

### Toggling Permission Selection

When building a new role, the user selects permissions via checkboxes. The `togglePerm` function manages the `permIds` array:

```javascript
const togglePerm = (id) =>
  setPermIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]));
```

If the ID is already selected, it is removed; otherwise it is added. This produces an immutable update using the functional form of `setPermIds`, which safely derives the new state from the previous value.

### Creating a Role

The `createRole` function handles form submission:

1. Calls `event.preventDefault()` to stop the browser's default form submission.
2. Clears any prior error.
3. Sends the new role to the backend via `api.createRole(...)`, mapping the local state onto the expected payload shape (note the conversion from `permIds` to the `permission_ids` field).
4. On success, resets all form fields (`name`, `description`, `permIds`).
5. Calls `load()` again to refresh the role list so the newly created role appears.
6. On failure, captures the error message in state.

The reload-after-write pattern ensures the displayed data reflects the server's actual state rather than optimistically updating locally.

### Rendering

The component always renders a **Roles** card containing a table of existing roles. Each row shows the role name, description, and a row of permission tags. If an error is present, it is displayed above the table.

The **New role** form is rendered conditionally:

```javascript
{canManage && (
  <section className="card">
    ...
  </section>
)}
```

This form uses **controlled inputs** — each input's value is bound to state and updated via `onChange` handlers. The permission checkboxes reflect the current `permIds` selection, and the `name` field is marked `required` to enforce basic client-side validation.

## Usage Examples

The component is used by passing the authenticated user as the `actor` prop:

```jsx
import RoleManager from "./components/RoleManager.jsx";

function AdminPage({ currentUser }) {
  return <RoleManager actor={currentUser} />;
}
```

- If `currentUser` has the `ROLES_MANAGE` permission, they see both the role list and the creation form.
- If not, they see only the read-only list.
- If `currentUser` is falsy, no data is loaded and an empty list is displayed.

## Integration

`RoleManager` depends on three internal modules:

- **`../api/client.js`** — Provides the async functions `listRoles`, `listPermissions`, and `createRole` that communicate with the backend. The component is agnostic to how these requests are made; it relies on the client to handle transport and return parsed data.
- **`../auth/permissions.js`** — Supplies the `hasPermission(actor, permission)` helper that encapsulates the authorization logic. By delegating to this helper, the component avoids hard-coding permission-checking rules.
- **`../constants.js`** — Provides the `PERMISSIONS` object, referenced here for `PERMISSIONS.ROLES_MANAGE`. Using a named constant instead of a string literal reduces the chance of typos and centralizes permission identifiers.

The component fits into a larger administrative interface as a self-contained unit: it manages its own state and data lifecycle, requires only the current user to operate, and communicates all changes back to the server through the shared API client.

## Design Notes

- **Consistent error handling** — Both `load` and `createRole` follow the same pattern of clearing the error, attempting the operation, and capturing any thrown message. This provides uniform feedback to the user.
- **Server as source of truth** — Rather than mutating local state after creating a role, the component re-fetches the list. This trades a slight increase in network activity for guaranteed consistency with the backend.
- **Authorization applied in two layers** — The `canManage` flag both avoids unnecessary network requests and hides UI controls the user cannot use, keeping the interface aligned with the user's actual capabilities.