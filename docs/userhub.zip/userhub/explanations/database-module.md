---
id: f7be98cb-beed-58a4-89b0-28ed2e1cd411
type: explanation
title: "Database Module"
created_at: 2026-07-30T17:21:42.907199+00:00
updated_at: 2026-07-30T17:21:42.907213+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  module_name: "backend.app.database"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Database Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

# `backend.app.database`

## Overview

The `backend.app.database` module is the foundational data-access layer for the application. It centralizes all SQLAlchemy configuration in a single place, providing three things that the rest of the codebase depends on:

1. A configured **database engine** that knows how to connect to the underlying SQLite database.
2. A **session factory** (`SessionLocal`) used to create short-lived database sessions.
3. A **declarative base class** (`Base`) that every ORM model inherits from.

It also exposes a `get_db` function designed to integrate cleanly with FastAPI's dependency injection system, ensuring each request gets its own session that is reliably cleaned up afterward.

By keeping this configuration in one module, the rest of the application can import a consistent engine, base class, and session provider without repeating connection details or worrying about session lifecycle management.

## Key Concepts

### The Engine

The engine is SQLAlchemy's core interface to the database. It manages connection pooling and dialect-specific behavior. In this module the engine is created once at import time and reused everywhere:

```python
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
)
```

The database is a local SQLite file (`userhub.db`), configured through the `DATABASE_URL` string. The `check_same_thread=False` argument is specific to SQLite and is discussed in *How It Works* below.

### The Session Factory

`SessionLocal` is a `sessionmaker`—a factory that produces `Session` objects. A session represents a "workspace" for interacting with the database: it tracks the objects you load and modify, and it manages transactions.

Two configuration choices are worth noting:

- `autoflush=False`: SQLAlchemy will not automatically flush pending changes to the database before queries. This gives the application explicit control over when changes are sent.
- `autocommit=False`: Transactions are not committed automatically. Code using a session must call `commit()` deliberately, which makes transaction boundaries explicit and predictable.

### The Declarative Base

`Base` is defined by subclassing SQLAlchemy's `DeclarativeBase`:

```python
class Base(DeclarativeBase):
    """Declarative base for every ORM model."""
```

Every ORM model in the application inherits from this class. This is what allows SQLAlchemy to collect table metadata across all models and, for example, generate the corresponding tables in the database.

### The Dependency Pattern

`get_db` follows the **generator-based dependency** pattern. Rather than returning a session directly, it *yields* one and then guarantees cleanup in a `finally` block. This pattern pairs naturally with FastAPI, which understands generator dependencies and treats the code after `yield` as teardown logic.

## How It Works

### Module Initialization

When the module is first imported, several things happen in order:

1. The `DATABASE_URL` constant is defined, pointing to a SQLite file in the current working directory.
2. The `engine` is created. This does not open a connection immediately; it configures how connections will be made when they are needed.
3. `SessionLocal` is bound to the engine, so any session it creates will use that engine.
4. `Base` is defined, ready to be inherited by model classes.

Because these are all module-level statements, they run exactly once per process, and the resulting objects are shared throughout the application.

### The SQLite Threading Concern

By default, SQLite's Python driver forbids using a connection across multiple threads. FastAPI, however, serves synchronous request handlers from a threadpool, meaning a session may be created on one thread and used on another. Setting:

```python
connect_args={"check_same_thread": False}
```

disables that safety check so SQLAlchemy can manage connections across threads. The inline comment in the code makes this intent explicit. This setting is specific to SQLite and would not be needed for other databases.

### Session Lifecycle in `get_db`

The `get_db` function manages a session for the duration of a single request:

```python
def get_db() -> Iterator[Session]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

Step by step:

1. A new `Session` is created from `SessionLocal`.
2. The session is `yield`ed to the caller. When used as a FastAPI dependency, this is the object injected into the route handler.
3. The route handler runs, using the session to query or modify data.
4. Regardless of whether the handler succeeds or raises an exception, the `finally` block runs and closes the session, releasing its connection back to the pool.

The `try/finally` structure is what makes this robust: even if an error occurs during request handling, the session is always closed, preventing connection leaks. The return type annotation `Iterator[Session]` accurately reflects that the function is a generator producing sessions.

## Usage Examples

### Defining a Model

ORM models inherit from `Base`:

```python
from sqlalchemy.orm import Mapped, mapped_column
from backend.app.database import Base

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]
```

### Creating the Tables

Because every model registers itself on `Base`, the tables can be created from the shared metadata:

```python
from backend.app.database import Base, engine

Base.metadata.create_all(bind=engine)
```

### Using `get_db` in a FastAPI Route

The most common usage is as an injected dependency:

```python
from fastapi import Depends
from sqlalchemy.orm import Session
from backend.app.database import get_db

@app.get("/users")
def list_users(db: Session = Depends(get_db)):
    return db.query(User).all()
```

FastAPI calls `get_db`, passes the yielded session as `db`, runs the handler, and then executes the teardown that closes the session—all automatically.

## Integration

This module sits at the center of the application's persistence layer and connects to the rest of the system in three main ways:

- **ORM models** across the codebase import `Base` and inherit from it, so their table definitions are collected into a single metadata registry.
- **Route handlers** (and other request-scoped code) depend on `get_db` to obtain a properly managed session, ensuring consistent transaction and cleanup behavior.
- **Application setup or migration code** uses the shared `engine` and `Base.metadata` to create or manage the database schema.

Its external dependencies are minimal: `sqlalchemy` provides the engine, session, and declarative base machinery, while `collections.abc.Iterator` supplies the type annotation for the generator return type. Because all database configuration is consolidated here, changing the database backend or connection settings—such as switching from SQLite to another database—would primarily involve updating this single module.