---
id: 6aef7b81-b955-5a0b-bc37-0f62f2ee42e0
type: explanation
title: "Client Module"
created_at: 2026-07-30T17:26:56.656360+00:00
updated_at: 2026-07-30T17:26:56.656375+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js
metadata:
  module_name: "frontend.src.api.client"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Client Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js`

# API Client (`frontend.src.api.client`)

## Overview

This module is the **single communication boundary** between the frontend application and the backend server. Every network request the frontend makes to the API is funneled through this module, which exposes a set of small, purpose-built functions—one per backend endpoint.

The design goal is centralization: rather than scattering `fetch` calls throughout the UI code, all HTTP concerns (request construction, headers, error handling, response parsing) live in one place. The comment at the top of the file states this intent directly: "there is one fetch call site per endpoint." This means UI components never touch `fetch` directly—they call semantic functions like `listUsers()` or `deactivateUser(id)` instead.

## Key Concepts

### The `request` helper

At the heart of the module is a single private async function, `request(method, url, body)`. Every exported function is a thin wrapper that delegates to it. This is the core pattern of the module: **one shared implementation for HTTP mechanics, many named endpoints on top of it.**

Consolidating logic here means that concerns like JSON serialization, the content type header, error translation, and empty-response handling are implemented once and applied uniformly.

### The actor identity

The module maintains a piece of mutable module-level state:

```javascript
let currentActorId = 1;
```

This represents the "logged in" user. As the comment explains, the system has no authentication layer, so instead of a real auth token, the frontend simply declares who it is acting as via a custom HTTP header, `X-Actor-Id`. The value defaults to `1` (the seeded admin) and can be changed at runtime through `setActor(id)`.

This is a deliberate simplification: it lets the application exercise permission-based behavior (different actors seeing different results) without building out a login flow. The trade-off is that identity is trust-based and client-controlled, which is only appropriate in a development or demonstration context.

### Relative URLs

Every endpoint uses a relative path such as `/api/users`. This means the client assumes it is served from the same origin as the backend, avoiding hardcoded hostnames and CORS configuration.

## How It Works

### Building and sending a request

When any exported function calls `request`, the following steps occur:

1. **Options assembly.** An `options` object is built with the HTTP method and two headers: `Content-Type: application/json` and the actor header carrying the current actor ID as a string.

2. **Conditional body.** The body is only attached if one was passed (`body !== undefined`). This distinction matters—it lets `GET` and `DELETE` calls omit a body entirely while `POST`/`PUT`/`PATCH` calls serialize their payload with `JSON.stringify`.

3. **Fetch execution.** The native `fetch` API sends the request and the function awaits the response.

### Handling the response

The response is processed in two phases:

- **Error case.** If `response.ok` is false (any non-2xx status), the client attempts to parse the response body as JSON to extract a `detail` message. The `.catch(() => ({}))` ensures that a body which isn't valid JSON doesn't crash the error path—it falls back to an empty object. It then throws an `Error` using the backend's `detail` message if present, or a generated fallback like `POST /api/users failed (400)`.

- **Success case.** A `204 No Content` response returns `null` (there is no body to parse), while any other successful response is parsed as JSON and returned.

This means callers receive either parsed data (or `null`) on success, or an exception on failure—a clean contract that lets UI code use `try/catch` or promise rejection handling.

## Usage Examples

The exported functions map cleanly onto backend resources. A few representative examples:

**Fetching data:**
```javascript
const me = await getCurrentUser();
const activeUsers = await listUsers("active");   // adds ?status=active
const roles = await listRoles();
```

**Creating and updating:**
```javascript
const newUser = await createUser({ name: "Ada", email: "ada@example.com" });
await updateUser(newUser.id, { name: "Ada Lovelace" });
```

**Switching the acting user:**
```javascript
setActor(newUser.id);   // subsequent requests send this actor ID
```

### Query parameters

Two functions, `listUsers` and `listAudit`, accept an optional filter argument. Both follow the same pattern: if the argument is truthy, it is appended as a URL-encoded query string; otherwise the query is omitted entirely.

```javascript
export function listUsers(status) {
  const query = status ? `?status=${encodeURIComponent(status)}` : "";
  return request("GET", `/api/users${query}`);
}
```

Using `encodeURIComponent` guards against special characters in filter values breaking the URL.

### Convenience wrappers for status changes

The module demonstrates a small layered abstraction with user status management. The primitive is `setUserStatus(userId, status)`, which PATCHes the status route. Two named helpers build on it:

```javascript
export function deactivateUser(userId) {
  return setUserStatus(userId, USER_STATUS.DEACTIVATED);
}

export function reactivateUser(userId) {
  return setUserStatus(userId, USER_STATUS.ACTIVE);
}
```

These give UI code intention-revealing names ("Deactivate" button calls `deactivateUser`) while keeping the actual status strings defined once in shared constants.

## Integration

### With the constants module

The client imports `USER_STATUS` from `../constants.js`. This ensures that the status strings sent to the backend (`ACTIVE`, `DEACTIVATED`) come from a single shared source. Because these same constants are presumably used elsewhere in the frontend, there is no risk of a typo causing a mismatch between what the UI displays and what the API sends.

### With the backend API

Each function corresponds to a backend route under `/api`. The full surface the client covers includes:

| Concern | Functions |
|---------|-----------|
| Current user | `getCurrentUser` |
| Users | `listUsers`, `getUser`, `createUser`, `updateUser`, `deleteUser` |
| User status | `setUserStatus`, `deactivateUser`, `reactivateUser` |
| Roles & permissions | `assignRoles`, `listRoles`, `createRole`, `listPermissions` |
| Audit & reports | `listAudit`, `userActivityReport` |

Note that request and response payload shapes are dictated by the backend. For example, `assignRoles` wraps its argument as `{ role_ids: roleIds }`, matching the backend's expected field name (snake_case), even though the JavaScript parameter uses camelCase.

### With UI components

Because this module owns all HTTP interaction and the actor identity, UI components depend on it as their gateway to server state. Components import the specific functions they need, await the returned promises, and handle thrown errors for failure feedback. Switching the acting user anywhere in the app is as simple as calling `setActor`, after which all subsequent requests automatically carry the new identity—no need to thread the actor ID through every call site.