---
id: 05563a1d-964a-52bc-87c1-09dce9c931c9
type: explanation
title: "User lifecycle operations."
created_at: 2026-07-30T17:25:48.801307+00:00
updated_at: 2026-07-30T17:25:48.801323+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  module_name: "backend.app.services.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# User lifecycle operations.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

# `backend.app.services.users` — User Lifecycle Operations

## Overview

This module is the **service layer** for everything related to user accounts. It sits between the HTTP routing layer (FastAPI routes) and the database (SQLAlchemy models), providing the business logic for creating, reading, updating, deleting, and transitioning users through their lifecycle.

Its responsibilities include:

- Fetching and listing users
- Creating and updating user records
- Managing role assignments
- Enforcing valid **status transitions** (e.g., a user can only move from one state to another in allowed ways)
- Writing **audit log** entries for every state-changing operation
- Evaluating permissions derived from a user's roles

The module docstring highlights one function in particular, `set_status`, as the "far end" of a cross-language trace that begins with a React "Deactivate" button click, travels through an API client and a `PATCH` route, and terminates here where the `users` and `audit_log` tables are actually written. In other words, this module is where user-facing actions become persisted database changes.

## Key Concepts

### Service functions operate on an injected `Session`

Every public function takes a SQLAlchemy `Session` (`db`) as its first argument. The module does not create or manage database connections itself; the session is supplied by the caller (typically a FastAPI dependency). This keeps the service layer decoupled from connection lifecycle management and makes the functions easy to test with a controlled session.

### Keyword-only arguments for clarity

Most mutating functions use the `*` separator to force keyword arguments:

```python
def create_user(db, *, actor_id, username, email, full_name, role_ids): ...
```

This is a deliberate design choice. Because these operations carry several parameters of similar types (multiple integers and strings), forcing keyword usage prevents callers from silently passing arguments in the wrong order.

### The `actor_id` parameter and auditing

Every state-changing function requires an `actor_id` — the ID of the user *performing* the action, as opposed to the `user_id` being acted upon. This distinction feeds the audit log: each mutation records who did what to whom. Auditing is not optional or bolted on; it is woven directly into every write path via the `audit.record(...)` call.

### Status transitions as a validated state machine

User status is not a free-form field. Valid values come from the `UserStatus` enum (e.g. `INVITED`, `ACTIVE`, `DEACTIVATED`), and legal moves between them are defined in `ALLOWED_STATUS_TRANSITIONS`. This effectively models the user lifecycle as a state machine, enforced by `_validate_transition`.

### Permissions flow through roles

Users don't hold permissions directly. Instead, a user has **roles**, and each role has **permissions**. The functions `actor_has_permission` and `effective_permissions` compute permissions by traversing this two-level relationship.

## How It Works

### Reading users

- **`get_user`** is a thin wrapper over `db.get(User, user_id)`. It returns `None` if the user does not exist, leaving the caller to decide how to handle absence.
- **`_require`** is a private helper that also fetches a user but raises an `HTTPException(404)` when the user is missing. This is used internally by every function that *must* have a valid target user, so the 404 behavior is defined in exactly one place.
- **`list_users`** builds a query ordered by username, with an optional `status` filter applied only when a status is provided.

### Permission evaluation

```python
def actor_has_permission(actor: User, permission: str) -> bool:
    return any(
        perm.name == permission for role in actor.roles for perm in role.permissions
    )
```

`actor_has_permission` short-circuits as soon as a matching permission is found across all of the actor's roles. `effective_permissions` performs the complementary operation: it collects *all* permission names into a set (deduplicating overlaps between roles) and returns them sorted. These functions are pure — they take a `User` object and require no database session, since they rely on already-loaded role relationships.

### Creating a user

`create_user` follows a careful sequence:

1. **Uniqueness check** — if the username already exists, it raises `HTTPException(409)`.
2. **Construction** — a new `User` is built with an initial status of `INVITED`. This is the entry state of the lifecycle; new users are never created as `ACTIVE`.
3. **Role assignment** — if `role_ids` are provided, the corresponding `Role` objects are loaded and attached.
4. **Flush before audit** — `db.add(user)` followed by `db.flush()` assigns the database-generated primary key *without* committing. This is important: the audit record needs `user.id` as its `target_id`, so the flush makes the ID available before the audit entry is written.
5. **Audit and commit** — the creation is recorded, then everything is committed together in a single transaction. Finally `db.refresh(user)` reloads the fully-populated object.

The flush-then-audit-then-commit pattern ensures the user row and its audit entry are atomic: either both persist or neither does.

### Updating a user

`update_user` accepts optional `email` and `full_name`. The `is not None` checks implement a **partial update** — only the fields explicitly provided are modified, leaving others untouched. An audit entry is recorded (without a `detail` payload) and the change is committed.

### Changing status — the flagship operation

`set_status` is the highlighted end of the cross-language trace:

1. Load the target user (raising 404 if missing).
2. **Validate the transition** with `_validate_transition`:
   - If the target status is not a known `UserStatus`, raise `422` ("unknown status").
   - If the current and target status are identical, allow it as a no-op.
   - Otherwise, verify the move is present in `ALLOWED_STATUS_TRANSITIONS[current]`, raising `409` ("illegal transition") if not.
3. Apply the new status.
4. **Record the audit action**, choosing the action type via `_status_action`: deactivation maps to `USER_DEACTIVATED`, activation to `USER_REACTIVATED`, and anything else falls back to the generic `USER_UPDATED`. This gives the audit log semantically meaningful entries rather than a single generic "status changed" event.
5. Commit and refresh.

### Deleting a user

`delete_user` captures the user's ID and username **before** deletion, records the audit entry, then deletes the row and commits. Capturing the identifying details first is necessary because after `db.delete(user)` those attributes may no longer be reliably accessible. Note the audit record persists even though the user itself is gone — the audit log is a durable history independent of the users table.

### Assigning roles

`assign_roles` **replaces** a user's roles wholesale (`user.roles = [...]`) rather than adding to them. It records the assigned role IDs as a comma-separated string in the audit detail, providing a human-readable trail of what roles were set.

## Usage Examples

Fetching a user and checking a permission:

```python
user = get_user(db, user_id=42)
if user and actor_has_permission(user, "users:write"):
    ...
```

Creating a user (note the required keyword arguments):

```python
new_user = create_user(
    db,
    actor_id=current_user.id,
    username="jdoe",
    email="jdoe@example.com",
    full_name="Jane Doe",
    role_ids=[1, 3],
)
# new_user.status == "invited"
```

Deactivating a user — the operation reached by the React "Deactivate" button:

```python
set_status(
    db,
    actor_id=current_user.id,
    user_id=42,
    status=UserStatus.DEACTIVATED.value,
)
```

If the user is already deleted, this raises `404`. If the current status doesn't permit deactivation, it raises `409`.

## Integration

This module connects several parts of the system:

- **FastAPI (`fastapi`)** — service functions raise `HTTPException` directly, so error handling is expressed in HTTP terms (404, 409, 422). This tightly couples the service layer to the web framework, trading strict layering purity for the convenience of not translating errors at the route boundary.
- **SQLAlchemy (`sqlalchemy`)** — all persistence goes through an injected `Session`. The module relies on ORM relationships (`user.roles`, `role.permissions`) for permission evaluation.
- **`app.constants`** — supplies the enums and transition rules (`UserStatus`, `AuditAction`, `ALLOWED_STATUS_TRANSITIONS`) that define the lifecycle's valid states and moves. Centralizing these constants keeps the state machine's definition separate from its enforcement.
- **`app.models`** — provides the `User` and `Role` ORM classes this module reads and writes.
- **`app.services.audit`** — every mutating function calls `audit.record(...)`. This module is a primary producer of audit log entries, and the two services are designed to be used together within the same transaction so that a business change and its audit trail commit atomically.

### The cross-language trace

As the module docstring describes, `set_status` is the server-side terminus of a full-stack flow:

```
React "Deactivate" button
  → deactivateUser (API client)
    → PATCH /api/users/{user_id}/status (FastAPI route)
      → set_status (this module)
        → writes to users + audit_log tables
```

Understanding `set_status` therefore means understanding where a user-facing action becomes a durable, audited database change — the point at which the frontend intent is finally realized in persistent state.