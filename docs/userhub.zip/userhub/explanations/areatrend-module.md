---
id: 9d712722-7af4-5830-a385-0a74d44f9e53
type: explanation
title: "Areatrend Module"
created_at: 2026-07-30T17:29:28.663902+00:00
updated_at: 2026-07-30T17:29:28.663917+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx
metadata:
  module_name: "frontend.src.components.charts.AreaTrend"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Areatrend Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx`

# AreaTrend Component

## Overview

`AreaTrend` is a self-contained React component that renders a single-series time-based visualization combining a filled **area chart** with an overlaid **line chart**. It is designed to display "activity over time" data — for example, daily event counts, user sign-ups, or any metric tracked across a sequence of labeled intervals.

The component is built directly with SVG rather than relying on a third-party charting library. This keeps it lightweight and gives it complete control over rendering, styling, and interaction. It includes an interactive hover feature that snaps to the nearest data point, drawing a vertical crosshair and displaying a floating tooltip.

A notable design characteristic is its use of a **fixed SVG `viewBox`** (`640 × height`) that scales to 100% of its container's width via CSS. This approach ensures the chart's internal geometry — text labels, stroke widths, and marker sizes — remains proportionally consistent regardless of the actual rendered size, avoiding the distortion that can occur when scaling absolute pixel dimensions.

## Key Concepts

### The `points` data structure

The component expects a `points` prop: an array of objects, each shaped like:

```javascript
{ label: "Mon", value: 42 }
```

- `label` — a string shown on the x-axis and in tooltips (e.g., a date or category name)
- `value` — a numeric quantity that determines the vertical position of each marker

### Coordinate mapping functions

The heart of the chart is the translation from *data space* (labels and values) into *SVG coordinate space* (x/y pixel positions within the viewBox). Three helper functions handle this:

- **`xAt(i)`** — maps a point's index to a horizontal position, evenly distributing points across the plot width. When there is only one point, it centers it.
- **`yAt(v)`** — maps a data value to a vertical position. Note that SVG's y-axis grows downward, so higher values produce *smaller* y-coordinates (the subtraction from `plotH` inverts the axis).
- **`baseY`** — the y-coordinate of the chart's baseline (the bottom of the plot), used as the anchor for the filled area.

### The padding/plot model

The component divides the drawing surface into an outer canvas (`W × H`) and an inner plotting region defined by four padding constants:

| Constant | Purpose |
|----------|---------|
| `padL` (34) | Left space for y-axis value labels |
| `padR` (14) | Right margin |
| `padT` (16) | Top margin |
| `padB` (28) | Bottom space for x-axis labels |

The `plotW` and `plotH` values are the remaining interior dimensions where data is actually drawn. This is a standard charting pattern that keeps axis labels from being clipped or overlapping the data.

### "Nice" axis scaling

The `niceCeil` function computes an aesthetically pleasing upper bound for the y-axis rather than using the raw maximum value. Given the largest data value, it rounds up to a clean number (1, 2, 5, or 10 times a power of ten). For example, a max value of 73 rounds up to 100; a max of 34 rounds up to 50.

```javascript
function niceCeil(v) {
  if (v <= 5) return 5;
  const pow = Math.pow(10, Math.floor(Math.log10(v)));
  const n = v / pow;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10;
  return step * pow;
}
```

This produces round, readable axis tick values and prevents the chart from being tightly cropped against its highest point.

## How It Works

### 1. Establishing the scale

On each render, the component calculates `niceMax` by finding the highest value in the dataset and passing it through `niceCeil`. The `Math.max(1, ...)` guard ensures the maximum is never below 1, which prevents division-by-zero issues in `yAt` when all values are zero.

### 2. Building the SVG geometry

Two path strings are constructed from the data:

- **`line`** — a space-separated list of `x,y` coordinate pairs used directly by an SVG `<polyline>` to draw the trend line.
- **`area`** — a complete SVG path (`M ... L ... Z`) that starts at the baseline under the first point, traces up and across each data point, drops back down to the baseline under the last point, and closes. This creates the filled region beneath the line. When `points` is empty, `area` is an empty string, safely producing nothing.

### 3. Rendering the layers

The SVG is drawn in a deliberate back-to-front order so later elements sit visually on top:

1. **Gridlines and y-axis labels** — three horizontal reference lines at `0`, `niceMax / 2`, and `niceMax`.
2. **Filled area** — the `area` path rendered at low opacity (`0.12`) so it reads as a subtle tint.
3. **Trend line** — the `polyline` in the full accent color.
4. **Crosshair** — a vertical line drawn only when a point is hovered.
5. **Data markers** — circles at each point, enlarged from `3.5` to `5` when hovered. Each circle contains a native SVG `<title>` element, which provides an accessible built-in tooltip on hover.
6. **X-axis labels** — the `label` text for each point along the bottom.

### 4. Interactive hover detection

The `onMove` handler implements "snap to nearest point" behavior:

```javascript
const onMove = (e) => {
  const rect = e.currentTarget.getBoundingClientRect();
  const px = ((e.clientX - rect.left) / rect.width) * W;
  // ...find the point with the smallest |xAt(i) - px|
  setHover(best);
};
```

Because the SVG is scaled by CSS, the raw mouse position (`e.clientX`) is in screen pixels. The handler converts it into viewBox coordinates by measuring the element's actual on-screen width with `getBoundingClientRect()` and rescaling into the fixed `W` space. It then loops over all points to find the one whose x-position is closest to the cursor, storing that index in the `hover` state. `onMouseLeave` resets `hover` to `null`.

### 5. The floating tooltip

Separate from the SVG's native `<title>` tooltips, a styled HTML tooltip (`div.chart-tooltip`) is rendered when a point is hovered. Its horizontal position is set as a percentage — `(xAt(hover) / W) * 100%` — so it aligns with the hovered point even after the chart scales to fit its container. This percentage-based positioning is what allows the HTML overlay to stay in sync with the scaled SVG.

## Usage Examples

Import the component and pass it an array of labeled data points:

```javascript
import AreaTrend from "./components/charts/AreaTrend";

function Dashboard() {
  const data = [
    { label: "Mon", value: 12 },
    { label: "Tue", value: 34 },
    { label: "Wed", value: 28 },
    { label: "Thu", value: 55 },
    { label: "Fri", value: 41 },
  ];

  return <AreaTrend points={data} color="#e0562d" height={260} />;
}
```

### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `points` | `Array<{ label: string, value: number }>` | *(required)* | The data series to plot |
| `color` | `string` | `"#2a78d6"` | Accent color for the line, fill, and markers |
| `height` | `number` | `220` | The SVG height in viewBox units |

## Integration

This component is a **presentational leaf component** — it has no external dependencies beyond React's `useState` hook and does not import from other project modules. It is intended to be dropped into any parent view that has prepared a `points` array in the expected shape.

### Styling dependency

The component assigns CSS class names to nearly every element (`area-chart`, `area-svg`, `grid`, `axis-label`, `crosshair`, `chart-tooltip`), but defines no styles itself. It therefore depends on an external stylesheet to provide the visual appearance of gridlines, label typography, the crosshair, and the tooltip container. The `.area-chart` wrapper should be positioned (e.g., `position: relative`) so the absolutely-positioned tooltip anchors correctly against it.

### Data contract

Any parent component supplying data must conform to the `{ label, value }` contract. Because the component reads `points.length`, maps over the array, and computes a maximum value, callers should pass a non-empty array for a meaningful render — though the code does gracefully handle empty and single-point cases (via the empty-string `area` path and the centering branch in `xAt`).