---
id: 6595f383-f6b9-5177-bae1-01ddafd868fe
type: explanation
title: "Barchart Module"
created_at: 2026-07-30T17:29:51.980063+00:00
updated_at: 2026-07-30T17:29:51.980081+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx
metadata:
  module_name: "frontend.src.components.charts.BarChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Barchart Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx`

# BarChart Component

**Module**: `frontend.src.components.charts.BarChart`

## Overview

The `BarChart` module provides a lightweight React component for rendering a **horizontal bar chart**. Each data point is displayed as a labeled row containing a proportionally-sized fill bar and its numeric value.

Unlike charting solutions that rely on canvas or SVG rendering libraries, this component is built entirely from styled HTML `div` elements. This makes it dependency-free, easy to style through CSS, and inexpensive to render. It is well-suited for displaying categorical magnitude comparisons—for example, counts, scores, or aggregated metrics grouped by label.

A notable design detail is captured in the leading comment: value labels are rendered directly on each row. Beyond being informative, these labels serve an accessibility/design purpose—they satisfy a "relief rule" for categorical colors that may have lower contrast. In other words, the numeric value is always readable even when the bar color alone would not provide sufficient visual distinction.

## Key Concepts

### The `data` structure

The component expects an array of data objects, each describing one bar. Based on the properties accessed in the code, each object has the following shape:

| Property | Type   | Purpose                                          |
|----------|--------|--------------------------------------------------|
| `label`  | string | Identifies the bar; used as the React key and shown as text |
| `value`  | number | The magnitude that determines bar width          |
| `color`  | string | A CSS color applied as the bar's background      |

### The `max` prop and normalization

Bars are drawn proportionally. To convert a raw `value` into a width percentage, the component needs a reference maximum. This is the role of `top`:

```javascript
const top = max ?? Math.max(1, ...data.map((d) => d.value));
```

- If a `max` value is explicitly provided, it is used directly.
- Otherwise, `top` falls back to the largest `value` in the dataset.
- The `Math.max(1, ...)` guard ensures `top` is never less than `1`, which prevents division-by-zero (or a zero-width baseline) when all values are `0`.

Allowing an explicit `max` is a deliberate flexibility: it lets multiple charts share a common scale, so bars remain visually comparable across different chart instances rather than each chart auto-scaling to its own maximum.

### Presentational, stateless component

The component is a pure function of its props. It holds no internal state, performs no side effects, and simply maps input data to markup. This keeps it predictable and easy to reuse.

## How It Works

The component executes the following steps:

1. **Determine the scale.** It computes `top`, the reference maximum used to normalize all bar widths (see above).

2. **Render a container.** It outputs a wrapping `div` with the class `hbars` that holds all rows.

3. **Map each data point to a row.** For every entry in `data`, it renders a `hbar-row` element. The `label` is used as the React `key`, so labels are expected to be unique within a dataset.

4. **Render the three parts of each row:**
   - **Label** (`hbar-label`): Displays `d.label` as text. A `title` attribute is set to the same label so the full text is available via tooltip if it is truncated by CSS.
   - **Track and fill** (`hbar-track` / `hbar-fill`): The track is the full-width background lane. Inside it, the fill's width is calculated as a percentage:
     ```javascript
     width: `${(d.value / top) * 100}%`
     ```
     The fill's `background` is set to `d.color`, and its `title` shows both label and value (e.g. `"Revenue: 42"`) on hover.
   - **Value** (`hbar-value`): Displays the raw numeric `value` alongside the bar.

All visual styling—row layout, spacing, track appearance, and label truncation—is expected to be defined externally in CSS via the referenced class names. The component only concerns itself with structure and the computed inline `width` and `background` values.

## Usage Examples

Import the component and provide it with an array of labeled values:

```jsx
import BarChart from "@/components/charts/BarChart";

function Report() {
  const data = [
    { label: "Chrome",  value: 68, color: "#4285F4" },
    { label: "Firefox", value: 12, color: "#FF7139" },
    { label: "Safari",  value: 20, color: "#0FB5EE" },
  ];

  return <BarChart data={data} />;
}
```

Here bars are auto-scaled so the largest value (`68`) fills the track.

To keep multiple charts on a shared scale, pass an explicit `max`:

```jsx
<BarChart data={quarterOne} max={100} />
<BarChart data={quarterTwo} max={100} />
```

With `max={100}`, a value of `50` always renders as a half-width bar, regardless of the other values present—making the two charts directly comparable.

## Integration

This module is a standalone, presentational building block within the frontend's `components/charts` directory. It has no imports and no identified dependencies on other modules, which makes it self-contained and easy to drop into any view that needs a horizontal bar visualization.

Its integration points are:

- **Consumers**: Any parent component that has categorical numeric data can render `BarChart` by supplying the `data` array (and optionally `max`). The parent is responsible for shaping raw application data into the `{ label, value, color }` format.
- **Styling**: The component depends on an external stylesheet defining the `hbars`, `hbar-row`, `hbar-label`, `hbar-track`, `hbar-fill`, and `hbar-value` classes. The visual appearance is therefore controlled outside this file.
- **Color assignment**: The component does not choose colors itself; each bar's `color` must be provided by the caller. This delegates palette decisions to the consumer, allowing consistent theming across the application.

Because it accepts a normalized data contract and defers presentation to CSS, `BarChart` can be reused anywhere a comparison of labeled magnitudes is needed without modification.