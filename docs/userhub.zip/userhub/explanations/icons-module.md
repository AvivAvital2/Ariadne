---
id: ea40d929-b301-5b55-a38d-ad27382332fa
type: explanation
title: "Icons Module"
created_at: 2026-07-30T17:27:44.055380+00:00
updated_at: 2026-07-30T17:27:44.055393+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx
metadata:
  module_name: "frontend.src.components.Icons"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Icons Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx`

# Icons Module Documentation

**Module**: `frontend.src.components.Icons`

## Overview

The Icons module provides a self-contained set of SVG icons rendered directly as React components. Rather than pulling in an external icon library (such as `react-icons` or `lucide-react`), this module defines each icon inline using raw SVG markup.

The design comment at the top of the file states the core intent explicitly:

> Inline SVG icon set (no icon-library dependency). Each icon inherits the current text color via `stroke="currentColor"`, so CSS controls color/size.

This approach has two notable benefits:

- **No third-party dependency**: The icons ship as part of the codebase, reducing bundle size and eliminating an external package to maintain or update.
- **CSS-driven styling**: Because icons inherit color and can be sized via props, they behave like text and integrate cleanly with existing styling rules.

## Key Concepts

### The `Svg` Wrapper Component

At the heart of the module is a single private helper component, `Svg`. It is not exported, meaning it is only used internally by the icon definitions in this file. Every exported icon delegates the rendering of the outer `<svg>` element to this wrapper.

The `Svg` component centralizes all the shared attributes that every icon needs:

```javascript
function Svg({ size = 20, children, ...rest }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...rest}
    >
      {children}
    </svg>
  );
}
```

Several design choices are encoded here:

- **`size` prop with a default of `20`**: Controls both `width` and `height`, keeping icons square.
- **`viewBox="0 0 24 24"`**: All icon path data is drawn on a 24×24 coordinate grid, independent of the rendered pixel size. This is why the coordinates in the individual icons (e.g. `x="3"`, `cx="12"`) refer to the 0–24 space rather than actual pixels.
- **`fill="none"` with `stroke="currentColor"`**: Icons are drawn as outlines that take on the surrounding text color rather than being filled shapes.
- **Stroke styling** (`strokeWidth`, `strokeLinecap`, `strokeLinejoin`): Consistent line weight and rounded joins/caps give every icon a uniform visual style.
- **`aria-hidden="true"`**: Marks the icons as decorative so screen readers skip them by default.

### The `currentColor` Pattern

Using `stroke="currentColor"` is the key mechanism for CSS-controlled coloring. `currentColor` is a CSS keyword that resolves to the computed value of the `color` property on the element. In practice, this means an icon placed inside an element with `color: red` renders red without any icon-specific styling. Changing the parent's text color automatically changes the icon color.

### Prop Forwarding via Rest Spread

The `Svg` component collects any additional props into `...rest` and spreads them onto the `<svg>` element. Each individual icon does the same, forwarding its props (`p`) directly to `Svg`:

```javascript
export const IconDashboard = (p) => (
  <Svg {...p}>
    {/* shapes */}
  </Svg>
);
```

This two-layer forwarding means that any prop passed to an icon (like `className`, `onClick`, `style`, or a custom `size`) flows through to the underlying `<svg>`. It keeps each icon definition minimal—an icon is essentially just its shape data plus the shared wrapper.

## How It Works

The rendering flow for any icon follows the same steps:

1. **The consumer renders an icon component**, for example `<IconSearch size={24} className="search-icon" />`.
2. **The icon function receives all props as `p`** and passes them to `Svg` via `{...p}`.
3. **The `Svg` component destructures `size`** (defaulting to 20 if not provided) and gathers remaining props into `rest`.
4. **`Svg` renders the outer `<svg>` element** with all the shared attributes, applying `size` to width/height and spreading `rest` for any extra attributes.
5. **The icon-specific shapes** (passed as `children`) are rendered inside the `<svg>`, drawing the visible glyph.

Each exported icon contains only the SVG primitives that define its shape. For example:

- `IconDashboard` uses four `<rect>` elements arranged in a grid to represent a dashboard.
- `IconSearch` combines a `<circle>` (the magnifying lens) with a `<line>` (the handle).
- `IconClock` draws a `<circle>` outline plus a `<polyline>` for the clock hands.

Because all shapes are drawn on the shared 24×24 viewBox with the wrapper's stroke settings, the icons render consistently regardless of the final display size.

## Usage Examples

### Basic usage with default size

```javascript
import { IconDashboard } from "./components/Icons";

<IconDashboard />
```

This renders a 20×20 dashboard icon that inherits the current text color.

### Customizing size

```javascript
import { IconBell } from "./components/Icons";

<IconBell size={32} />
```

### Applying color and other attributes

Since color comes from CSS, you typically set it on the icon or a parent:

```javascript
<IconUserCheck size={24} className="status-approved" style={{ color: "green" }} />
```

Any prop passed here (`className`, `style`) is forwarded onto the `<svg>` element.

### Using multiple icons together

```javascript
import { IconUsers, IconShield, IconActivity } from "./components/Icons";

function Toolbar() {
  return (
    <div className="toolbar">
      <IconUsers />
      <IconShield />
      <IconActivity />
    </div>
  );
}
```

## Available Icons

The module exports the following icon components:

| Export | Visual meaning |
| --- | --- |
| `IconDashboard` | Four-square grid layout |
| `IconUsers` | Group of people |
| `IconShield` | Security/protection badge |
| `IconActivity` | Heartbeat/activity line |
| `IconUserCheck` | User with a checkmark (approved) |
| `IconUserX` | User with an X (rejected/removed) |
| `IconClock` | Clock face with hands |
| `IconPlus` | Plus sign (add) |
| `IconSearch` | Magnifying glass |
| `IconBell` | Notification bell |

The naming and iconography (users, shield, user-check/user-x, activity, bell) suggest this set supports an administrative or dashboard-oriented interface involving user management, notifications, and activity monitoring.

## Integration

No directly related modules were identified for analysis, but the integration model is straightforward and follows standard React conventions:

- **Import by name**: Each icon is a named export, so consumers import only the icons they use. This is friendly to tree-shaking, allowing bundlers to drop unused icons.
- **Composition into UI components**: Icons are intended to be embedded inside buttons, navigation items, status indicators, and similar elements throughout the frontend.
- **Styling handoff to CSS**: Because icons rely on `currentColor` and a `size` prop, the surrounding components and stylesheets control appearance. There is no per-icon color logic to maintain here.

The `Svg` helper is deliberately not exported, keeping it an internal implementation detail. This means the module presents a clean public surface—just the ten icon components—while consolidating shared SVG configuration in one place. If the visual style needs to change (for example, adjusting stroke width or default size), a single edit to `Svg` propagates to every icon.