---
id: 207e9cc9-b70d-516c-8716-3c972d54c701
type: explanation
title: "UserHub FastAPI application entrypoint."
created_at: 2026-07-30T17:21:52.332236+00:00
updated_at: 2026-07-30T17:21:52.332250+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  module_name: "backend.app.main"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# UserHub FastAPI application entrypoint.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`

# `backend.app.main` — Application Entrypoint

## Overview

This module is the entrypoint for the **UserHub** FastAPI application. It is responsible for assembling the running web service: creating the `FastAPI` application instance, wiring up middleware, registering the API routers that expose the application's endpoints, and defining a lightweight health-check route.

Beyond simple assembly, the module also handles **first-run bootstrapping** through a lifespan handler. When the server starts, it ensures the database schema exists and seeds baseline data if the database is empty. Because these operations are designed to be idempotent, the same startup logic runs safely on every launch — the first run creates and seeds, and subsequent runs simply find everything already in place.

The application is intended to be run from the `backend/` directory with:

```
uv run uvicorn app.main:app --reload
```

The `app.main:app` reference tells Uvicorn to import the `app` object defined in this module.

## Key Concepts

### The `app` Object

The central artifact of this module is the module-level `app` variable — a configured `FastAPI` instance. This is the object that the ASGI server (Uvicorn) serves. Everything else in the module contributes to configuring this object.

### The Lifespan Handler

FastAPI supports a **lifespan** context manager for running code at application startup and shutdown. This module uses the `@asynccontextmanager` decorator from `contextlib` to define a `lifespan` function. Code before the `yield` runs on startup; code after `yield` (if any) would run on shutdown. Here, only startup logic is present.

The lifespan handler is passed to `FastAPI(..., lifespan=lifespan)` so it becomes part of the application's lifecycle.

### Idempotent Bootstrapping

A recurring design theme is **idempotency**. Both startup steps are safe to run repeatedly:

- `Base.metadata.create_all(engine)` creates database tables only if they do not already exist.
- `seed_if_empty(db)` inserts baseline data only when the database is empty.

This avoids the need for separate "first-time setup" scripts or migration commands during development — the server takes care of it automatically.

### Routers

The application's actual endpoints are not defined here. Instead, they live in separate router modules (`users`, `roles`, `audit`, `reports`) under `app.routers`. This module simply imports each router and includes it, keeping the entrypoint focused on composition rather than endpoint logic.

## How It Works

### Startup Sequence

When Uvicorn loads and starts the application, the following happens in order:

1. **Schema creation.** `Base.metadata.create_all(engine)` inspects the SQLAlchemy models registered on `Base` and issues `CREATE TABLE` statements for any tables that don't yet exist.

2. **Session creation.** A database session is opened via `SessionLocal()`.

3. **Conditional seeding.** `seed_if_empty(db)` is called. If the database was empty, it populates baseline permissions, roles, and users, and returns a truthy value — in which case a confirmation message is printed:

   ```
   UserHub: seeded baseline permissions, roles, and users (first run).
   ```

   If data already exists, seeding is skipped and no message is printed.

4. **Cleanup.** The session is closed in a `finally` block, ensuring the connection is released even if seeding raises an error.

5. **Yield.** Control passes to `yield`, at which point the application begins handling requests. Since there is no code after `yield`, no special shutdown behavior is defined.

### Application Configuration

After the lifespan handler is defined, the `app` object is created with a title (`"UserHub"`), a version (`"0.1.0"`), and the lifespan handler attached.

### CORS Middleware

The application adds `CORSMiddleware` configured to allow requests from `http://localhost:5173` — the origin of the Vite development server. According to the inline comment, the Vite dev server proxies `/api` requests to this backend, making most browser calls same-origin. The CORS allowance primarily supports **direct calls**, such as those made from the interactive Swagger UI at `/docs`. All methods and headers are permitted.

### Router Registration

Four routers are included, each contributing a group of related endpoints:

- `users.router`
- `roles.router`
- `audit.router`
- `reports.router`

The specific paths and behaviors of these endpoints are defined within their respective modules.

### Health Endpoint

Finally, a single endpoint is defined directly in this module:

```python
@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
```

This provides a simple way to verify that the service is up and responding. It returns a fixed JSON payload `{"status": "ok"}` and performs no database or dependency checks. Its placement under the `/api` prefix is consistent with the Vite proxy convention described above.

## Usage Examples

### Running the Application

From the `backend/` directory:

```
uv run uvicorn app.main:app --reload
```

The `--reload` flag enables automatic restarts on code changes, which is convenient during development.

### Checking Service Health

Once running, the health endpoint can be queried directly:

```
GET http://localhost:8000/api/health
```

Response:

```json
{ "status": "ok" }
```

### Exploring the API

Because the application uses FastAPI, interactive documentation is automatically available at `/docs` (Swagger UI). The open CORS configuration allows these in-browser requests to succeed even when called directly against the backend.

## Integration

This module sits at the top of the application's dependency graph and ties together several other parts of the codebase:

- **`app.database`** provides `Base`, `SessionLocal`, and `engine`. `Base` and `engine` are used to create the schema; `SessionLocal` is used to open a session for seeding.
- **`app.seed`** provides `seed_if_empty`, which encapsulates the logic for detecting an empty database and populating it with baseline data.
- **`app.routers`** provides the four router modules whose endpoints make up the application's public API.
- **`fastapi` and `fastapi.middleware.cors`** supply the web framework and CORS support.
- **`contextlib`** supplies the `asynccontextmanager` decorator used to implement the lifespan handler.

On the deployment side, this module integrates with:

- **Uvicorn**, the ASGI server that imports and runs the `app` object.
- **The Vite dev server** on port `5173`, which proxies frontend `/api` requests to this backend. The CORS configuration and the `/api` route prefix are both aligned with this frontend integration.

In summary, `backend.app.main` is a thin but critical composition layer: it does not implement business logic itself, but instead wires together the database, seeding, routers, and middleware into a single runnable FastAPI application with automatic, idempotent first-run setup.