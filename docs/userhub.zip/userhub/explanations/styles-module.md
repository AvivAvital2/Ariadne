---
id: 919496f3-1349-5b90-b574-ef452dc1a177
type: explanation
title: "Styles Module"
created_at: 2026-07-30T17:31:15.565770+00:00
updated_at: 2026-07-30T17:31:15.565785+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css
metadata:
  module_name: "frontend.src.styles"
  language: "css"
  provenance: "code-derived"
  source_name: "userhub"
---
# Styles Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css`

# Styles Module (`frontend.src.styles`)

## Overview

This module is the global stylesheet for a single-page dashboard/admin application. Rather than being a Python module, it is a CSS file that defines the entire visual language of the frontend: colors, typography, layout structure, and the appearance of every reusable UI component (cards, tables, buttons, forms, charts, modals, and more).

The stylesheet establishes a two-zone application shell — a **dark sidebar** for navigation and a **light content area** for data — and provides a consistent set of styled building blocks that React (or similar) components can consume simply by applying class names. There are no scoped or CSS-module conventions here; every rule lives in the global scope and is applied through plain class names such as `.card`, `.btn`, or `.stat-card`.

The design is oriented toward a data-heavy interface: it includes dedicated styles for statistics cards, donut charts, horizontal bar charts, area charts, activity feeds, status badges, and tabular data.

## Key Concepts

### Design Tokens via CSS Custom Properties

The foundation of the stylesheet is a set of CSS custom properties (variables) declared on the `:root` selector. These act as **design tokens** — a single source of truth for colors, spacing, and shadows that the rest of the file references through `var(...)`.

```css
:root {
  --sidebar-bg: #0f172a;
  --page: #f4f6f9;
  --primary: #2a78d6;
  --radius: 12px;
  --shadow: 0 1px 2px rgba(16, 24, 40, 0.06), 0 1px 3px rgba(16, 24, 40, 0.08);
}
```

The tokens are organized into logical groups:

- **Dark sidebar** (`--sidebar-bg`, `--sidebar-fg`, `--sidebar-muted`) — the navigation zone's palette.
- **Light content** (`--page`, `--card`, `--ink`, `--ink-2`, `--muted`, `--faint`, `--line`, `--track`, `--grid`) — background, surface, and multiple text/line shades for the main area. The `--ink*` variables provide a text-color hierarchy from strongest (`--ink`) to faintest (`--faint`).
- **Status / data-viz palette** (`--primary`, `--primary-ink`, `--good`, `--warning`, `--critical`) — semantic colors that map to meanings like success, warning, and error.
- **Shape tokens** (`--radius`, `--shadow`) — reused corner rounding and elevation.

Centralizing these values means the whole theme can be adjusted in one place, and the semantic naming (e.g. `--critical` rather than `#d03b3b`) keeps the intent clear wherever the token is used.

### Semantic Modifier Classes

Many components follow a base-plus-modifier pattern reminiscent of BEM. A base class carries shared structure, and a modifier class adjusts appearance:

- Buttons: `.btn` plus `.primary`, `.ghost`, `.danger`, or `.sm`.
- Badges: `.badge` plus `.active`, `.invited`, or `.deactivated`.
- Stat icons: `.stat-icon` plus `.tone-primary`, `.tone-good`, `.tone-critical`, or `.tone-warning`.
- Feed dots: `.dot` plus `.good`, `.bad`, or `.neutral`.
- Avatars: `.avatar` plus `.sm`.

This lets a component render its structural class unconditionally and append a variant class based on data (for example, mapping a user's status string directly to a badge modifier).

### Layout Primitives

A small number of flex/grid utility-like classes handle page composition: `.layout`, `.sidebar`, `.main`, `.content`, `.stack`, `.stat-row`, `.panel-grid`, and `.panel-wide`. These do the heavy lifting of arranging the app shell and dashboard grids.

## How It Works

### 1. Base Reset and Document Sizing

The file begins with a light reset. `box-sizing: border-box` is applied to every element so padding and borders are included in declared widths. `html`, `body`, and `#root` are all set to `height: 100%`, which is required so that full-height flex layouts (like the sticky sidebar) can stretch to fill the viewport. The `#root` selector confirms the app mounts into a container with that ID — a common convention for React applications.

The `body` establishes global defaults: a system font stack, the `--page` background, the `--ink` text color, a 14px base size, and antialiasing.

### 2. The Application Shell

The overall page structure is a horizontal flex container:

```css
.layout { display: flex; min-height: 100vh; }
.sidebar { width: 240px; flex: 0 0 240px; position: sticky; top: 0; height: 100vh; }
.main { flex: 1; min-width: 0; }
```

The `.sidebar` is a fixed-width, non-shrinking column pinned to the viewport with `position: sticky`, so it stays visible while the content scrolls. The `.main` region takes all remaining space; the `min-width: 0` guard prevents flex children (such as wide tables) from forcing the layout to overflow.

Inside `.main`, a sticky `.topbar` sits above a scrollable `.content` area, giving a persistent header with search and action controls.

### 3. Sidebar Navigation

The `.nav` is a vertical flex list that grows to fill the sidebar (`flex: 1`), pushing the `.sidebar-footer` to the bottom. Each `.nav-item` is styled as a borderless, transparent button so that interactive `<button>` elements look like navigation links. Two interaction states are defined:

- `:hover` adds a subtle translucent white overlay.
- `.active` fills the item with the `--primary` color to indicate the current route.

### 4. Cards and Dashboard Panels

Content is grouped into surfaces built on the shared card recipe (background `--card`, `--line` border, `--radius` corners, `--shadow` elevation). `.stat-row` and `.panel-grid` arrange these surfaces:

```css
.stat-row { display: grid; grid-template-columns: repeat(4, 1fr); }
.panel-grid { display: grid; grid-template-columns: 1fr 1fr; }
.panel-wide { grid-column: 1 / -1; }
```

`.stat-row` lays out four equal stat cards. `.panel-grid` creates a two-column dashboard, and `.panel-wide` lets a single panel span the full width by occupying all grid columns.

### 5. Data Visualization Styles

The stylesheet supports several chart types rendered as SVG or CSS:

- **Donut charts** (`.donut`, `.donut-total`, `.legend`, `.legend-dot`) — note that text elements use `fill` rather than `color`, because they are SVG `<text>` nodes.
- **Horizontal bars** (`.hbar-row`) — a three-column grid of `label | track | value`, where `.hbar-fill` grows inside a rounded `.hbar-track`.
- **Area charts** (`.area-svg`, with descendant selectors like `.area-svg .grid` and `.area-svg .crosshair`) — styles SVG internals such as gridlines and a dashed crosshair, plus an absolutely positioned `.chart-tooltip` that follows the pointer (`pointer-events: none` keeps it from blocking mouse events).

Numeric values throughout use `font-variant-numeric: tabular-nums` so digits align in consistent-width columns.

### 6. Tables, Badges, and Feeds

Tables use `border-collapse: collapse` with light bottom borders per row and an uppercase, faint header style. Row hover highlights with the `--page` color. Helper classes like `.muted`, `.nowrap`, `.col-actions`, and `.cell-user` handle common cell formatting needs.

Status is communicated through pill-shaped `.badge` elements and small `.dot` indicators, both of which use the semantic palette (green for good, amber for warning/invited, red for critical/deactivated) with translucent backgrounds.

### 7. Forms and Modals

Form styling leans on element selectors (`label`, `input`, `fieldset`, `legend`) rather than requiring extra classes, so plain markup is styled by default. Labels are flex columns stacking a caption over an input; the `.checkbox` modifier switches a label back to a horizontal row. Inputs get a visible focus ring built from `border-color` plus a translucent `box-shadow` in the primary color.

Modals use `position: fixed; inset: 0` to cover the viewport with a translucent scrim, centering a white dialog via flexbox. The dialog caps its height at `90vh` and scrolls internally when content overflows.

### 8. Responsive Behavior

A single breakpoint adapts the dashboard for narrower screens:

```css
@media (max-width: 980px) {
  .stat-row { grid-template-columns: repeat(2, 1fr); }
  .panel-grid { grid-template-columns: 1fr; }
}
```

Below 980px, stat cards collapse from four columns to two, and dashboard panels stack into a single column.

## Usage Examples

Components apply these styles by attaching class names. A stat card, for instance, combines the base class with a tone modifier:

```html
<div class="stat-card">
  <div class="stat-icon tone-good"><!-- icon --></div>
  <div>
    <div class="stat-value">1,284</div>
    <div class="stat-label">Active users</div>
  </div>
</div>
```

A status badge maps a data value to a modifier class:

```html
<span class="badge active">active</span>
<span class="badge deactivated">deactivated</span>
```

And a primary action button:

```html
<button class="btn primary sm">Save</button>
```

In each case the component supplies structure and content; the stylesheet supplies all appearance.

## Integration

This file is a **global stylesheet**, so it is typically imported once at the application entry point (for example, alongside where the app mounts into `#root`). Once loaded, its rules apply everywhere in the document.

Because the styles are keyed on plain, semantic class names and bare element selectors, they are framework-agnostic in principle, though the presence of `#root` and the button-based navigation pattern strongly indicate a React application. Components across the codebase — dashboards, user tables, forms, modals, and charts — all depend on the class-name contract defined here.

No other modules were identified as direct dependencies. The primary integration point is the naming contract itself: any component that wants a card, badge, button, or chart must use the exact class names defined in this file. Changing a class name here requires updating every consuming component, whereas changing a value inside a design token (such as `--primary`) automatically propagates the new appearance everywhere that token is used.