---
id: 52f7f2aa-5c48-54ec-82f3-ed1267d8fb55
type: explanation
title: "Reports Module"
created_at: 2026-07-30T17:23:18.319174+00:00
updated_at: 2026-07-30T17:23:18.319188+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  module_name: "backend.app.routers.reports"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Reports Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

# `backend.app.routers.reports`

Reporting endpoints backed by hand-written SQL, exposed under the `/api/reports` path prefix.

## Overview

This module provides read-only reporting endpoints for the application. It currently exposes a single endpoint, `/api/reports/user-activity`, which returns a summary of user activity.

What distinguishes this module from the application's standard CRUD routes is its data-access strategy. Rather than querying through the SQLAlchemy ORM (working with mapped model objects), it executes a **raw SQL statement** directly against the underlying database tables (`users` and `audit_log`). The module docstring makes this design choice explicit.

This approach is common for reporting workloads, where queries often join and aggregate across multiple tables in ways that don't map cleanly to a single ORM entity. Hand-written SQL gives the author full control over the query shape and typically produces more efficient reporting queries than an ORM-generated equivalent.

## Key Concepts

### Router registration

The module defines a FastAPI `APIRouter` tagged as `"reports"`:

```python
router = APIRouter(tags=["reports"])
```

The `tags` argument groups this endpoint under a "reports" section in the automatically generated API documentation. The full route path (`/api/reports/user-activity`) is declared directly on the endpoint decorator rather than through a router-level prefix.

### Raw SQL as a named constant

The SQL query itself is not inlined in the route function. Instead it is imported as a constant:

```python
from app.reports.queries import USER_ACTIVITY_SQL
```

Keeping the SQL in a dedicated `app.reports.queries` module separates the query text from the HTTP-handling logic. This makes the SQL easier to locate, review, and test independently of the routing layer.

### Response schema

The endpoint declares its return type using a Pydantic schema:

```python
response_model=list[UserActivityRow]
```

`UserActivityRow` (imported from `app.schemas`) describes the shape of a single row in the report. FastAPI uses this schema both to validate/serialize the response and to document the endpoint's output structure.

### Permission-based access control

Access is gated behind a permission check via a dependency:

```python
actor: User = Depends(require_permission(Permission.AUDIT_READ.value))
```

`require_permission` is a dependency factory: calling it with a specific permission value produces a dependency that FastAPI resolves before running the endpoint. Because the report reads from the `audit_log` table, it requires the `AUDIT_READ` permission. If the caller lacks this permission, the request is rejected before any SQL executes.

## How It Works

The `user_activity` function handles a single `GET` request. Its execution proceeds as follows:

1. **Dependency resolution.** Before the function body runs, FastAPI resolves two dependencies:
   - `get_db` provides an active SQLAlchemy `Session` (`db`).
   - `require_permission(Permission.AUDIT_READ.value)` authenticates the caller and confirms they hold the `AUDIT_READ` permission, returning the authenticated `User` as `actor`. If the check fails, the endpoint never runs.

2. **Query execution.** The function wraps the raw SQL string in SQLAlchemy's `text()` construct and executes it against the session:

   ```python
   rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
   ```

   - `text(...)` marks the string as a literal SQL statement to be sent to the database as-is.
   - `.mappings()` configures the result so each row is returned as a dictionary-like mapping of column names to values, rather than a positional tuple.
   - `.all()` materializes every row into a list.

3. **Serialization into schema objects.** Each row mapping is unpacked into a `UserActivityRow`:

   ```python
   return [UserActivityRow(**row) for row in rows]
   ```

   Because `.mappings()` yields column-name-keyed dictionaries, the `**row` unpacking maps SQL column names directly onto the schema's fields. This requires the columns selected by `USER_ACTIVITY_SQL` to match the field names defined on `UserActivityRow`.

4. **Response.** FastAPI serializes the returned list according to the declared `response_model`, producing a JSON array of user-activity records.

Note that the `actor` parameter is bound for the sole purpose of enforcing the permission check — the function body does not reference it. Its presence as a dependency is what triggers authorization.

## Usage Examples

This is an HTTP endpoint rather than a library function, so it is "used" by issuing a request to the running service:

```
GET /api/reports/user-activity
Authorization: <credentials establishing an authenticated user>
```

A successful response is a JSON array whose elements conform to `UserActivityRow`:

```json
[
  { "...": "fields as defined by UserActivityRow" },
  { "...": "one object per row returned by USER_ACTIVITY_SQL" }
]
```

The caller must be authenticated and must hold the `AUDIT_READ` permission. A caller lacking that permission will receive an authorization error instead of report data.

## Integration

This module sits at the intersection of several parts of the application:

- **`app.database`** supplies the `get_db` dependency, giving the endpoint a managed database session consistent with the rest of the application.
- **`app.security`** provides `require_permission`, integrating this endpoint with the application's centralized authorization model.
- **`app.constants`** defines the `Permission` enumeration; using `Permission.AUDIT_READ.value` keeps the permission reference aligned with the shared permission definitions rather than a hard-coded string.
- **`app.models`** provides the `User` type used to type-hint the authenticated actor.
- **`app.reports.queries`** owns the actual SQL (`USER_ACTIVITY_SQL`), keeping query logic decoupled from routing.
- **`app.schemas`** defines `UserActivityRow`, which acts as the contract between the SQL result columns and the JSON response.

To make these endpoints reachable, the `router` object defined here must be included in the application's main FastAPI instance (typically via `app.include_router(...)`).

### Relationship to the CRUD routes

The module deliberately diverges from the ORM-based pattern used elsewhere in the codebase. The trade-off is explicit:

- **Benefit:** Direct SQL allows efficient, purpose-built reporting queries that can aggregate and join across the `users` and `audit_log` tables without forcing that shape onto ORM entities.
- **Cost:** The response correctness now depends on an implicit contract — the column names produced by `USER_ACTIVITY_SQL` must exactly match the fields of `UserActivityRow`. Because raw SQL bypasses the ORM's model definitions, this alignment is not enforced by the type system and must be maintained by hand.