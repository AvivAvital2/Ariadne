---
id: aded8221-8fb6-525e-aa8f-58224a17fbed
type: explanation
title: "Models Module"
created_at: 2026-07-30T17:22:33.834114+00:00
updated_at: 2026-07-30T17:22:33.834128+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  module_name: "backend.app.models"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Models Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

# `backend.app.models` — Data Model Documentation

## Overview

This module defines the persistence layer for the application using **SQLAlchemy 2.0's declarative ORM style**. It maps Python classes to database tables in a SQLite database, providing an object-oriented interface to the underlying relational data.

The module implements a **role-based access control (RBAC)** data model consisting of four entities:

- **`User`** — application accounts
- **`Role`** — named groupings of permissions assigned to users
- **`Permission`** — discrete capabilities within the system
- **`AuditLog`** — an append-only record of significant actions

Together, these tables model *who can do what* (via users, roles, and permissions) and *what actually happened* (via the audit log). This separation of authorization structure from activity history is a common pattern in systems that need both fine-grained access control and accountability.

---

## Key Concepts

### SQLAlchemy 2.0 Declarative Style

All model classes inherit from `Base`, imported from `app.database`. `Base` is the declarative base that ties each class to a table and registers its metadata. Column definitions use the modern **typed mapping** syntax:

```python
username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
```

Here, `Mapped[str]` is a type annotation that both informs static type checkers of the attribute's Python type *and* participates in ORM configuration. The `mapped_column(...)` call supplies the database-level details (length, uniqueness, indexing, defaults). This is a shift from older SQLAlchemy styles where types were declared inside `Column(...)` alone.

Nullable columns are expressed through the type annotation itself:

```python
actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
```

The `int | None` annotation communicates optionality to the type system, while `nullable=True` enforces it at the schema level.

### Association Tables for Many-to-Many Relationships

Two plain `Table` objects — `user_roles` and `role_permissions` — implement many-to-many relationships. These are **association tables**, not mapped classes, because they carry no data beyond the two foreign keys forming a composite primary key:

```python
user_roles = Table(
    "user_roles",
    Base.metadata,
    Column("user_id", ForeignKey("users.id"), primary_key=True),
    Column("role_id", ForeignKey("roles.id"), primary_key=True),
)
```

Using a bare `Table` (rather than a full ORM class) is the idiomatic choice when the join table has no extra attributes. The composite primary key naturally prevents duplicate assignments (e.g., the same role attached to the same user twice).

### The Relationship Web

The RBAC structure is a two-level chain of many-to-many links:

```
User  <--user_roles-->  Role  <--role_permissions-->  Permission
```

Each relationship is bidirectional, wired together with `back_populates`:

- `User.roles` ↔ `Role.users`
- `Role.permissions` ↔ `Permission.roles`

Because relationships are defined on both sides and linked by name, updating one collection keeps the other consistent in the same session. For example, appending a `Role` to `user.roles` will make that user appear in `role.users`.

### Consistent UTC Timestamps

A small helper centralizes timestamp generation:

```python
def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)
```

This function is passed as a *callable* default (not called immediately) so that SQLAlchemy invokes it at insert time for each row. Using an explicit timezone-aware UTC value avoids the ambiguity of naive local timestamps — a deliberate choice for auditability and cross-timezone consistency.

---

## How It Works

### The `User` Model

`User` represents an account and is the central entity:

- `username` and `email` are both `unique`, enforcing one-account-per-identifier. `username` is also indexed, indicating it is a common lookup key.
- `status` holds a string value such as `"invited"`, `"active"`, or `"deactivated"`. The default is `"invited"`, suggesting accounts begin life pending activation. The inline comment notes this maps to a `UserStatus` value defined elsewhere in the system.
- `created_at` is set once via the `default=_utcnow` callable.
- `updated_at` uses both `default=_utcnow` (at insert) and `onupdate=_utcnow` (on every update), so it always reflects the last modification time automatically.
- `roles` links the user to its assigned `Role` objects through the `user_roles` association table.

### The `Role` Model

A `Role` is a named bundle. It has a unique `name` and an optional `description`. It sits in the middle of the RBAC chain, exposing:

- `users` — the users holding this role
- `permissions` — the capabilities this role grants

### The `Permission` Model

A `Permission` represents a single granular capability. Its `name` (e.g., `"users:deactivate"`, per the comment) follows a `resource:action` convention, and the `unique` constraint ensures each capability is defined once. Permissions connect back to the roles that include them via `roles`.

### The `AuditLog` Model

`AuditLog` records events for accountability. Its design reflects append-only usage:

- `actor_id` is a **nullable** foreign key to `users.id`. Nullability accommodates actions with no identifiable user (e.g., automated or system events).
- `action` is an indexed string like `"user.deactivated"`, enabling efficient filtering by event type.
- `target_type` (defaulting to `"user"`) and `target_id` describe *what* the action affected. This generic pairing lets the log reference different kinds of entities without a dedicated foreign key per type.
- `detail` is a free-form `Text` field for additional context.
- `created_at` is indexed, supporting time-ordered queries — the typical way audit logs are read.

Notably, `AuditLog` does **not** define an ORM relationship back to `User`. The `actor_id` remains a raw foreign key. This keeps the log decoupled from the mutable user graph: even if a user is later modified or has roles reassigned, the historical record stays intact and independent.

---

## Usage Examples

These examples assume an active SQLAlchemy `Session` obtained from the database layer.

**Creating a user with a role and permissions:**

```python
deactivate = Permission(name="users:deactivate", description="Deactivate users")
admin = Role(name="admin", permissions=[deactivate])
user = User(username="alice", email="alice@example.com", status="active", roles=[admin])

session.add(user)
session.commit()
```

Because the relationships are bidirectional, `admin.users` now includes `alice`, and `deactivate.roles` includes `admin`.

**Recording an audit event:**

```python
entry = AuditLog(
    actor_id=user.id,
    action="user.deactivated",
    target_type="user",
    target_id=42,
    detail="Deactivated during offboarding",
)
session.add(entry)
session.commit()
```

The `created_at` timestamp is populated automatically by `_utcnow`.

**Checking a user's effective permissions:**

```python
granted = {perm.name for role in user.roles for perm in role.permissions}
if "users:deactivate" in granted:
    ...  # authorized
```

This traversal walks the `User → Role → Permission` chain that the model structure was built to support.

---

## Integration

- **`app.database`** — Supplies the `Base` declarative class and its `metadata`. All models and association tables register themselves against this shared metadata, which the database layer uses to create the schema and manage sessions.
- **`datetime`** — Provides the timezone-aware UTC timestamps used for `created_at` and `updated_at` defaults.
- **`sqlalchemy`** — Supplies the core building blocks (`Column`, `Table`, foreign keys, column types) and ORM primitives (`Mapped`, `mapped_column`, `relationship`).

Within the broader application, these models serve as the contract between the database and higher-level code. The string-based fields (`status`, `action`, `permission.name`) are documented to correspond to enumerated values (`UserStatus`, `AuditAction`, `Permission`) defined elsewhere, indicating that business logic layers interpret and validate these strings while the database stores them plainly. Any service performing authorization checks, user management, or audit recording will operate on the classes defined here.