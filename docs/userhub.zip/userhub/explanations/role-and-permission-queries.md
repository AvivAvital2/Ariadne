---
id: cd4b2fdb-c3aa-5383-89f3-69773956ecda
type: explanation
title: "Role and permission queries."
created_at: 2026-07-30T17:25:38.465614+00:00
updated_at: 2026-07-30T17:25:38.465629+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  module_name: "backend.app.services.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Role and permission queries.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

# `backend.app.services.roles` — Role and Permission Queries

## Overview

The `roles` service module provides the data-access layer for managing **roles** and **permissions** in the application. It sits between the API/route layer and the database, encapsulating all the SQLAlchemy queries needed to read and create roles, and to read the list of available permissions.

This module is part of a typical role-based access control (RBAC) setup: roles group together sets of permissions, and users are (presumably elsewhere) assigned roles. By centralizing these queries in a service module, the rest of the application interacts with roles and permissions through a small, well-defined set of functions rather than writing raw queries in multiple places.

The module exposes four functions:

| Function | Purpose |
|----------|---------|
| `list_roles` | Retrieve all roles, sorted by name |
| `get_role` | Retrieve a single role by its ID (or 404) |
| `create_role` | Create a new role, optionally linking permissions |
| `list_permissions` | Retrieve all permissions, sorted by name |

## Key Concepts

### The `Session` dependency

Every function takes a `db: Session` argument — a SQLAlchemy ORM `Session`. This is the standard pattern for passing an active database connection/transaction into a query function. The functions do not create or manage their own sessions; the caller (typically a FastAPI route via dependency injection) is responsible for supplying one. This keeps the service functions stateless and easy to test.

### ORM models: `Role` and `Permission`

The module operates on two ORM models imported from `app.models`:

- **`Role`** — has at least `name`, `description`, and a `permissions` relationship.
- **`Permission`** — has at least `id` and `name`.

The relationship between them (`role.permissions`) is a collection, strongly suggesting a many-to-many association: a role can have many permissions, and a permission can belong to many roles.

### Raising HTTP errors from the service layer

Notably, this module raises `fastapi.HTTPException` directly (with status codes `404` and `409`) rather than raising a domain-specific exception. This is a deliberate design choice that tightly couples the service layer to the web framework, but it simplifies the calling code: routes don't need to translate errors into HTTP responses themselves.

- `404 Not Found` — when a requested role does not exist.
- `409 Conflict` — when attempting to create a role whose name already exists.

## How It Works

### `list_roles`

```python
return db.query(Role).order_by(Role.name).all()
```

Returns every `Role` in the database, ordered alphabetically by name. This provides a stable, predictable ordering for display purposes.

### `get_role`

Uses `db.get(Role, role_id)`, which is the efficient primary-key lookup method in modern SQLAlchemy (it can return an already-loaded object from the session's identity map without hitting the database). If no role is found, the function raises a `404` HTTP error rather than returning `None`, so callers can rely on always receiving a valid `Role`.

### `create_role`

This is the most involved function. It is defined with keyword-only arguments (note the `*` in the signature), forcing callers to be explicit about `name`, `description`, and `permission_ids`:

1. **Uniqueness check** — It queries for an existing role with the same name. If one is found, it raises a `409 Conflict`. This enforces that role names are unique.
2. **Object creation** — A new `Role` instance is created with the given name and description.
3. **Permission linking** — If `permission_ids` is non-empty, it fetches the matching `Permission` records in a single query using `Permission.id.in_(permission_ids)` and assigns them to `role.permissions`. Assigning a list to the relationship attribute is how SQLAlchemy populates the association.
4. **Persistence** — The role is added to the session, committed, and then refreshed. The `db.refresh(role)` call reloads the object from the database so that any database-generated fields (such as the auto-generated `id`) are populated on the returned instance.

Note that if a caller passes permission IDs that don't exist, they are silently ignored — only IDs that match existing permissions are linked. The function does not validate that every requested ID was found.

### `list_permissions`

```python
return db.query(Permission).order_by(Permission.name).all()
```

Mirrors `list_roles`: returns all permissions sorted by name. This is typically used to present the available permissions when building or editing a role.

## Usage Examples

These functions are designed to be called from within a request handler that already has a database session. A typical FastAPI usage looks like this:

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.services import roles
from app.dependencies import get_db  # provides a Session

router = APIRouter()

@router.get("/roles")
def read_roles(db: Session = Depends(get_db)):
    return roles.list_roles(db)

@router.get("/roles/{role_id}")
def read_role(role_id: int, db: Session = Depends(get_db)):
    return roles.get_role(db, role_id)  # raises 404 automatically

@router.post("/roles")
def add_role(payload: RoleCreate, db: Session = Depends(get_db)):
    return roles.create_role(
        db,
        name=payload.name,
        description=payload.description,
        permission_ids=payload.permission_ids,
    )
```

Because `create_role` uses keyword-only arguments, calls must name each parameter explicitly — this improves readability and prevents accidental argument reordering.

## Integration

This module connects three parts of the system:

- **`app.models`** — Supplies the `Role` and `Permission` ORM models that these functions query and construct. All persistence behavior (table names, relationships, constraints) is defined there.
- **`sqlalchemy`** — Provides the `Session` and query API used to interact with the database. The module relies on the caller to manage the session lifecycle.
- **`fastapi`** — Provides `HTTPException`, which the module uses to signal error conditions. This choice means the service layer assumes it runs within a FastAPI request context, so these functions are not framework-agnostic.

In the overall architecture, this module is the **service/data-access layer** for RBAC. Route handlers depend on it for reading and writing roles, while it depends on the models for schema and on the session for database access. Any user-authorization logic that checks a user's role permissions would build on top of the data this module manages.