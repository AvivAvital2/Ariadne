---
id: e2cc2baf-743f-57ed-b55a-847912941c9c
type: explanation
title: "Userform Module"
created_at: 2026-07-30T17:29:09.018176+00:00
updated_at: 2026-07-30T17:29:09.018190+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx
metadata:
  module_name: "frontend.src.components.UserForm"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userform Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx`

# UserForm Component

## Overview

The `UserForm` component is a React modal dialog for creating and editing users. It serves a dual purpose through a single interface: when given an existing user, it acts as an edit form; when given `null`, it acts as a creation form. This "create or edit" pattern is common in administrative interfaces where the same set of fields applies to both operations, with only minor behavioral differences.

The component manages its own form state, loads the list of available roles from the backend, and delegates persistence to an API client module. When a save succeeds, it notifies its parent through a callback rather than managing navigation or list-refreshing itself.

## Key Concepts

### Controlled Components

Every input in this form is a **controlled component**—its value is bound to React state, and changes flow through `onChange` handlers back into that state. For example, the username field reads from the `username` state variable and updates it on each keystroke:

```javascript
<input value={username} onChange={(e) => setUsername(e.target.value)} required />
```

This pattern gives the component full control over form values, making them available for submission and enabling validation or transformation if needed.

### The `isNew` Flag

The single most important piece of logic is derived at the top of the component:

```javascript
const isNew = user === null;
```

This boolean drives most of the conditional behavior throughout the component: which fields are shown, what heading appears, which button label is used, and—crucially—which API calls are made on submit. Centralizing this decision into one flag keeps the mode-switching logic consistent.

### State Shape

The component maintains six pieces of local state:

| State | Purpose | Initial Value |
|-------|---------|---------------|
| `username` | The user's login name | Existing username, or `""` |
| `email` | The user's email address | Existing email, or `""` |
| `fullName` | The user's display name | Existing full name, or `""` |
| `roles` | All available roles (loaded from API) | `[]` |
| `roleIds` | IDs of roles assigned to this user | Existing role IDs, or `[]` |
| `error` | Error message from a failed save | `null` |

Note the distinction between `roles` (the complete catalog of roles the system offers) and `roleIds` (the subset currently assigned to this user). The form renders a checkbox for each entry in `roles` and marks it checked when its ID appears in `roleIds`.

### Optional Chaining for Initialization

The state initializers rely heavily on optional chaining and nullish coalescing to safely handle the `null` user case:

```javascript
const [username, setUsername] = useState(user?.username ?? "");
const [roleIds, setRoleIds] = useState(user?.roles?.map((r) => r.id) ?? []);
```

When `user` is `null` (create mode), `user?.username` evaluates to `undefined`, and `?? ""` supplies a safe empty default. This lets a single set of initializers serve both modes without branching.

## How It Works

### Loading Available Roles

On mount, the component fetches the full list of roles once:

```javascript
useEffect(() => {
  api.listRoles().then(setRoles).catch(() => setRoles([]));
}, []);
```

The empty dependency array ensures this runs only once. If the request fails, the `catch` handler falls back to an empty array rather than leaving `roles` in a broken state—the form still functions, it just shows no role checkboxes.

### Toggling Role Assignments

Role selection is managed by `toggleRole`, which adds or removes a role ID from the `roleIds` set:

```javascript
const toggleRole = (id) =>
  setRoleIds((ids) =>
    ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id],
  );
```

This uses the functional update form of `setRoleIds`, receiving the current array and returning a new one. If the ID is already present, it's filtered out; otherwise, it's appended. Returning a fresh array (rather than mutating in place) is important for React to detect the change and re-render.

### Submitting the Form

The `submit` handler is where the create/edit divergence becomes concrete:

```javascript
const submit = async (event) => {
  event.preventDefault();
  setError(null);
  try {
    if (isNew) {
      await api.createUser({ username, email, full_name: fullName, role_ids: roleIds });
    } else {
      await api.updateUser(user.id, { email, full_name: fullName });
      await api.assignRoles(user.id, roleIds);
    }
    onSaved();
  } catch (err) {
    setError(err.message);
  }
};
```

Several things happen here:

1. `event.preventDefault()` stops the browser's default form submission (which would reload the page).
2. `setError(null)` clears any previous error before attempting the save.
3. For **new users**, a single `createUser` call carries everything—including role assignments via `role_ids`—in one payload.
4. For **existing users**, the operation is split into two calls: `updateUser` handles the profile fields, and a separate `assignRoles` call synchronizes role membership. Notably, `username` is *not* sent in the update path, reflecting that usernames are immutable after creation.
5. On success, `onSaved()` notifies the parent. On failure, the error message is surfaced in the UI.

### Conditional Rendering

The rendered output adapts to the mode in several ways:

- The heading reads `"Create user"` or `` `Edit @${user.username}` ``.
- The username field is rendered **only** in create mode (`{isNew && ...}`), matching the immutability constraint enforced in `submit`.
- The submit button reads `"Create"` or `"Save"`.
- The error banner appears only when `error` is set.

### Field-Level Validation

The form relies on native HTML validation. The email input uses `type="email"`, and both username and email are marked `required`. This browser-level validation runs before `submit` is invoked, providing basic guardrails without additional JavaScript.

## Usage Examples

The component expects three props: a `user` object (or `null`), and two callbacks.

Creating a new user:

```jsx
<UserForm
  user={null}
  onClose={() => setShowForm(false)}
  onSaved={() => {
    setShowForm(false);
    refreshUserList();
  }}
/>
```

Editing an existing user:

```jsx
<UserForm
  user={selectedUser}
  onClose={() => setSelectedUser(null)}
  onSaved={() => {
    setSelectedUser(null);
    refreshUserList();
  }}
/>
```

The `user` object, when provided, is expected to have `id`, `username`, `email`, `full_name`, and a `roles` array of objects each carrying an `id` and `name`.

## Integration

### Parent Component

`UserForm` is designed to be embedded within a parent that manages a user list. The parent controls whether the form is visible and passes down:

- **`user`**: the record to edit, or `null` to create.
- **`onClose`**: invoked when the user cancels; the parent typically hides the modal.
- **`onSaved`**: invoked after a successful save; the parent typically hides the modal and refreshes its data.

By delegating these actions upward via callbacks, the form remains decoupled from how the surrounding application manages state, modals, or data refreshing.

### API Client

All backend communication goes through the `../api/client.js` module, imported as `api`. The component depends on four functions from it:

- `listRoles()` — returns the full catalog of roles.
- `createUser(payload)` — creates a user and assigns roles in one step.
- `updateUser(id, payload)` — updates a user's mutable profile fields.
- `assignRoles(id, roleIds)` — synchronizes a user's role assignments.

These functions are expected to return promises and to throw errors carrying a `message` property, which the component displays directly to the user.

### Field Naming Convention

The component bridges two naming conventions. Internally, React state uses camelCase (`fullName`), but the API payloads use snake_case (`full_name`, `role_ids`). This translation happens at the point of the API call, suggesting the backend follows a snake_case convention typical of Python or similar server frameworks.