---
id: ebb64223-5b1c-56e2-b6fa-08d0e7a27ede
type: explanation
title: "Audit-log writes and reads."
created_at: 2026-07-30T17:25:26.378004+00:00
updated_at: 2026-07-30T17:25:26.378018+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py
metadata:
  module_name: "backend.app.services.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit-log writes and reads.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py`

# `backend.app.services.audit`

## Overview

The `audit` module provides a small, focused service layer for writing and reading **audit-log entries**. Its purpose is to create a persistent, queryable trail of mutating operations performed against users and roles in the system.

The module exposes two functions:

- **`record`** — appends a single audit entry to the database.
- **`list_entries`** — reads back audit entries, optionally filtered by action type.

As the module docstring notes, every mutating user or role operation is expected to funnel an `AuditAction` value through `record`. This creates a single, consistent choke point for auditing, rather than scattering logging logic across many call sites. On the read side, a frontend audit view consumes the entries returned by `list_entries` and maps each `action` string to a human-readable label.

## Key Concepts

### The `AuditLog` model

The module operates on the `AuditLog` model imported from `app.models`. Each audit entry captures:

- `actor_id` — the user who performed the action (nullable, so system-initiated or actor-less events are permitted).
- `action` — a string describing what happened; expected to be an `AuditAction` value.
- `target_type` — the kind of entity affected, defaulting to `"user"`.
- `target_id` — the identifier of the affected entity (nullable).
- `detail` — free-form text describing the event, defaulting to an empty string.
- `created_at` — a timestamp used for ordering (populated by the model itself, not this module).

### Action strings as a shared contract

The `action` field is a plain `str`, but the documentation makes clear it should hold an `AuditAction` value. This means the set of valid actions is defined elsewhere (as an enumeration or similar), and both the writer (`record`) and the reader (the frontend view) rely on the same vocabulary. Storing the value as a string keeps the database schema simple while allowing the application layer to enforce meaning.

### Session-based persistence

Both functions accept a SQLAlchemy `Session` (`db`) as their first argument. The module itself does not manage transactions or sessions—it receives them from the caller. This is a deliberate separation of concerns: the audit service handles *what* to persist, while the surrounding code owns *when* to commit.

### Keyword-only arguments

Both functions use the `*` marker to make most parameters keyword-only. This forces call sites to be explicit, for example:

```python
record(db, actor_id=5, action="user.delete", target_id=42)
```

This improves readability at the call site and prevents accidental argument transposition, which is especially valuable when several parameters share the same `int | None` type.

## How It Works

### Writing an entry with `record`

The `record` function performs four steps:

1. **Construct** an `AuditLog` instance from the supplied fields.
2. **Add** it to the session with `db.add(entry)`, staging it for insertion.
3. **Flush** the session with `db.flush()`, which sends the pending INSERT to the database and populates server-generated fields (such as the primary key) on the `entry` object.
4. **Return** the fully populated `entry`.

The use of `flush()` rather than `commit()` is significant. Flushing writes the row to the database within the current transaction but leaves the final commit decision to the caller. This lets `record` participate in a larger unit of work—for example, deleting a user and recording the audit entry in the same transaction—so that both succeed or fail together.

### Reading entries with `list_entries`

The `list_entries` function builds a query in stages:

1. Start with all `AuditLog` rows, ordered by `created_at` descending so the most recent entries come first.
2. If an `action` filter is provided (i.e., not `None`), narrow the query to matching action values.
3. Apply a `limit` (default `100`) and execute the query with `.all()`.

The default limit acts as a safeguard against unbounded result sets, keeping response sizes predictable for the frontend view. The conditional filter pattern—reassigning `query` only when a filter is present—lets a single code path serve both "all actions" and "specific action" queries.

## Usage Examples

### Recording an action

```python
entry = record(
    db,
    actor_id=current_user.id,
    action="role.assign",
    target_id=target_user.id,
    detail="Assigned editor role",
)
```

Note that `target_type` defaults to `"user"`, so it only needs to be passed when the affected entity is something else (for example, a role).

### Listing recent entries

```python
# Most recent 100 entries of any action
entries = list_entries(db)

# Only user-deletion events, capped at 25
deletions = list_entries(db, action="user.delete", limit=25)
```

## Integration

This module sits in the service layer (`app.services`) and connects two other parts of the system:

- **`app.models`** provides the `AuditLog` ORM model that defines the underlying table structure. This module depends on that model for both writing and querying.
- **`sqlalchemy.orm.Session`** is the persistence mechanism. Because the session is passed in rather than created here, the module integrates cleanly with whatever transaction and request-lifecycle management the application already uses.

On the producing side, mutating user and role operations elsewhere in the codebase are expected to call `record` to leave a trail. On the consuming side, a frontend audit view calls `list_entries` and translates the raw `action` strings into human-readable labels. Together these establish a clear, one-way flow: operations write audit entries through a single function, and the UI reads them back for display.