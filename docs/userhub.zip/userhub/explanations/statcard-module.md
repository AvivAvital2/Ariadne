---
id: 0e69c05c-c43e-5421-a6c0-8f6468f7197e
type: explanation
title: "Statcard Module"
created_at: 2026-07-30T17:28:26.676933+00:00
updated_at: 2026-07-30T17:28:26.676947+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx
metadata:
  module_name: "frontend.src.components.StatCard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Statcard Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx`

# StatCard Component

**Module**: `frontend.src.components.StatCard`

## Overview

The `StatCard` module defines a small, reusable React presentational component used to display a single statistic or metric in a compact, card-style layout. Its typical use case is on dashboards or summary screens where several key figures — such as totals, counts, or status indicators — need to be shown side by side in a consistent visual format.

Because the component is stateless and derives its entire output from the props it receives, it fits the "dumb" or presentational component pattern: it is responsible only for rendering, not for fetching or managing data.

## Key Concepts

### Presentational, Prop-Driven Component

`StatCard` is a **function component** that takes props and returns JSX. It holds no internal state, performs no side effects, and issues no data requests. All the information it displays is passed in by a parent, which makes it easy to reason about, test, and reuse.

### Component Props

The component destructures the following props directly in its parameter list:

| Prop    | Purpose                                                             | Required |
|---------|--------------------------------------------------------------------|----------|
| `label` | Descriptive text shown beneath the value (e.g., "Active Users")    | Yes      |
| `value` | The primary figure being highlighted (e.g., a number or string)    | Yes      |
| `hint`  | Optional secondary text for extra context (e.g., "+5% this week")  | No       |
| `tone`  | A visual variant name that controls styling, defaults to `"primary"` | No     |
| `icon`  | A React component used to render an icon, aliased locally as `Icon` | No      |

### Icon Aliasing

The prop `icon` is renamed to `Icon` during destructuring:

```javascript
{ ..., icon: Icon }
```

This is a deliberate and common React convention. JSX treats lowercase names as HTML tags and capitalized names as component references. By aliasing `icon` to the capitalized `Icon`, the component can render it as `<Icon />`, which JSX correctly interprets as a component invocation rather than a literal HTML element.

### Tone-Based Styling

The `tone` prop drives a dynamically generated CSS class name (`tone-${tone}`). Rather than encoding colors or styles in JavaScript, the component defers all visual decisions to CSS. This allows different tones (for example, `primary`, `success`, `warning`) to be defined entirely in a stylesheet, keeping the component logic minimal.

## How It Works

The component renders a fixed structure and conditionally includes some elements based on the props provided.

1. **Root container**: A `<div>` with the class `stat-card` wraps the entire component.

2. **Icon area**: A `<div>` receives two classes — the static `stat-icon` and a dynamic `tone-${tone}` class. Inside it, the icon is only rendered if one was supplied:

   ```javascript
   {Icon && <Icon size={20} />}
   ```

   This uses short-circuit evaluation: if `Icon` is `undefined`, the expression evaluates to a falsy value and React renders nothing. When present, the icon is rendered at a fixed size of `20`.

3. **Body area**: A `<div className="stat-body">` groups the textual content:
   - `stat-value` displays the main `value`.
   - `stat-label` displays the descriptive `label`.
   - `stat-hint` displays the optional `hint`, again using short-circuit evaluation so it only appears when a hint is provided.

The visual ordering places the value above the label, emphasizing the figure itself while keeping its meaning immediately accessible below.

## Usage Examples

A basic card showing a value and label:

```jsx
<StatCard label="Total Users" value={1284} />
```

A card with a hint and a specific tone:

```jsx
<StatCard
  label="Revenue"
  value="$12,430"
  hint="+8% vs last month"
  tone="success"
/>
```

A card including an icon (for example, an icon component from a library like `lucide-react`):

```jsx
import { Users } from "lucide-react";

<StatCard label="Active Sessions" value={42} tone="warning" icon={Users} />
```

Note that the `icon` prop expects a **component reference**, not a rendered element. You pass `Users`, not `<Users />`. The `StatCard` internally renders and sizes it.

## Integration

No directly related modules were identified for this component, and it imports nothing itself. This confirms its role as a self-contained, leaf-level UI building block.

Integration happens in two directions:

- **Parent components** supply the data and configuration through props. Dashboard views, summary panels, or report pages would import `StatCard` and render one instance per metric, typically inside a grid or flex layout.

- **Stylesheets** provide all visual definitions. The component depends on external CSS rules for the classes `stat-card`, `stat-icon`, `stat-body`, `stat-value`, `stat-label`, `stat-hint`, and the tone variants (`tone-primary`, and any other tones used). Without these styles, the component still renders valid markup but will lack its intended appearance.

Because the component is exported as a default export, consumers import it under whatever name they choose, though `StatCard` is the conventional and recommended name.