---
id: 7101c6ec-d97d-5608-92cb-e813e14cc214
type: explanation
title: "Donutchart Module"
created_at: 2026-07-30T17:30:05.036641+00:00
updated_at: 2026-07-30T17:30:05.036656+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx
metadata:
  module_name: "frontend.src.components.charts.DonutChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Donutchart Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx`

# DonutChart Component

## Overview

`DonutChart` is a React presentational component that renders a **donut (ring) chart** for visualizing part-to-whole relationships. It draws a circular ring divided into colored segments, displays a running total in the center, and pairs the visualization with a labelled legend beneath it.

The component's design reflects a deliberate accessibility principle stated in its header comment:

> Status colors are never shown alone — the legend carries label + value.

This means the chart does not rely on color alone to convey information. Every segment has a corresponding legend entry with a text label and numeric value, ensuring the data remains understandable to users who cannot distinguish colors or who rely on assistive technology.

## Key Concepts

### The Data Shape

The component expects a `data` prop that is an array of objects, each describing one segment:

```javascript
{ label: "Active", value: 42, color: "#4caf50" }
```

- `label` — a human-readable name (also used as the React `key`)
- `value` — a numeric quantity that determines the segment's size
- `color` — the stroke color for that segment

### SVG Stroke-Based Rings

Rather than drawing arc paths, the component builds the donut from **overlapping SVG `<circle>` elements** that share the same center and radius. Each segment is a full circle whose stroke is made partially visible using `strokeDasharray`. This is a common and lightweight technique: a stroked circle's outline has a known length (its circumference), so controlling the dash pattern effectively controls how much of the ring is "filled."

### Circumference Math

Several derived values drive the geometry:

- `r = (size - thickness) / 2` — the radius, inset by half the stroke thickness so the ring stays inside the SVG bounds.
- `c = size / 2` — the center coordinate (used for both `cx` and `cy`).
- `circumference = 2 * Math.PI * r` — the total length of the ring, the basis for all dash calculations.

### Segment Offsetting

A mutable `offset` accumulator tracks how far around the ring each subsequent segment should begin. As the component iterates through the data, it advances `offset` by each segment's arc length so segments are laid out end-to-end rather than stacking on top of each other.

## How It Works

### 1. Compute the Total and Geometry

The component first sums all segment values to get `total`, then computes the radius, center, and circumference. It also defines a small `GAP` (2px) to create visual separation between adjacent segments.

### 2. Draw the Background Track

A single `<circle>` with `stroke="var(--track)"` is rendered first. This is the empty "track" of the donut — the full ring outline that shows through where no data segment is drawn (and provides a neutral base when the chart is otherwise empty).

### 3. Render Each Data Segment

Segments are only drawn when `total > 0` (a guard that prevents division-by-zero and avoids rendering meaningless arcs for empty data). For each data entry:

- **Fraction**: `frac = d.value / total` gives the segment's share of the whole.
- **Dash length**: `len = Math.max(frac * circumference - GAP, 0)` computes the visible arc length, subtracting the gap and clamping at zero so tiny segments never produce negative lengths.
- **Dash array**: `strokeDasharray={\`${len} ${circumference - len}\`}` makes exactly `len` pixels of the stroke visible, with the remainder invisible.
- **Dash offset**: `strokeDashoffset={-offset}` rotates the visible portion around the ring so it starts where the previous segment ended.
- **Rotation**: `transform={\`rotate(-90 ${c} ${c})\`}` rotates the entire circle so segments begin at the top (12 o'clock) rather than at the default 3 o'clock start point.

Each segment also includes an SVG `<title>` element:

```
Active: 42 (35%)
```

This provides a native browser tooltip on hover and contributes to accessibility.

After rendering a segment, `offset` is advanced by the segment's **full** fractional circumference (not the gap-adjusted length), so the next segment starts at the correct position and gaps remain consistent.

### 4. Render the Centered Total

Two `<text>` elements are centered horizontally (`textAnchor="middle"`). The first shows the numeric `total`, the second shows the literal word "total" as a label below it. Their vertical positions (`c - 2` and `c + 16`) are manually tuned to stack neatly in the ring's hollow center.

### 5. Render the Legend

Below the SVG, an unordered list renders one entry per data item. Each entry contains:

- A `legend-dot` span whose background is set to the segment's color (visually linking the legend to the ring).
- A `legend-label` span with the text label.
- A `legend-value` span with the numeric value.

This legend is the mechanism that satisfies the "never color alone" principle — it always provides the textual meaning of each color.

## Usage Examples

Basic usage with default size and thickness:

```jsx
<DonutChart
  data={[
    { label: "Active",   value: 42, color: "#4caf50" },
    { label: "Idle",     value: 18, color: "#ff9800" },
    { label: "Offline",  value: 6,  color: "#f44336" },
  ]}
/>
```

Customizing the chart's dimensions via props:

```jsx
<DonutChart data={statusData} size={240} thickness={30} />
```

The `size` prop controls the overall SVG width/height in pixels, and `thickness` controls how wide the ring stroke is. Both have sensible defaults (`190` and `22`).

Behavior with empty or all-zero data:

```jsx
<DonutChart data={[]} />
```

Because segments are guarded by `total > 0`, an empty dataset renders just the background track and a centered total of `0` — no error occurs.

## Integration

`DonutChart` is a **standalone, self-contained presentational component** with no dependencies on other modules in the codebase. It is a default export, so it is imported by name of choice wherever a ring chart is needed:

```jsx
import DonutChart from "@/components/charts/DonutChart";
```

### Styling Dependencies

The component relies on external CSS for its appearance. It references several class names (`donut`, `donut-total`, `donut-total-label`, `legend`, `legend-dot`, `legend-label`, `legend-value`) and the CSS custom property `var(--track)` for the background ring color. These must be defined in the consuming application's stylesheet or theme for the chart to display correctly.

### Data Contract

Any parent component or data layer supplying the `data` prop must conform to the `{ label, value, color }` shape. Because the component derives all geometry from `value` and uses `label` as the React reconciliation key, callers should ensure labels are unique within a single chart to avoid key collisions.