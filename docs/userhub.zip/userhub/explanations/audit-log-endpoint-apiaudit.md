---
id: 895630f1-7ded-5858-9e30-727ddb982e2e
type: explanation
title: "Audit-log endpoint (``/api/audit``)."
created_at: 2026-07-30T17:23:11.585232+00:00
updated_at: 2026-07-30T17:23:11.585246+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  module_name: "backend.app.routers.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit-log endpoint (``/api/audit``).

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

# Audit Log Endpoint (`backend.app.routers.audit`)

## Overview

This module defines a single HTTP endpoint that exposes the application's audit log to authorized clients. Audit logs typically record significant actions taken within a system—who did what, and when—which is essential for security review, compliance, and debugging.

The module follows the FastAPI router pattern, registering a `GET /api/audit` route that returns recent audit entries. It acts as a thin HTTP layer: it validates the request, enforces access control, and delegates the actual data retrieval to a dedicated service module. This separation keeps the routing logic focused on the concerns of the web layer, while business logic lives elsewhere.

## Key Concepts

### FastAPI Router

The module creates an `APIRouter` instance rather than attaching routes directly to the application:

```python
router = APIRouter(tags=["audit"])
```

Using a router allows the endpoint to be defined in isolation and later mounted onto the main application. The `tags=["audit"]` argument groups this endpoint under an "audit" heading in the automatically generated API documentation (such as Swagger UI).

### Dependency Injection

FastAPI's dependency injection system is central to this module. Two dependencies are declared via `Depends(...)`:

- **`get_db`** — Provides a database session (`Session`) for the request. FastAPI resolves this before the handler runs and typically closes the session afterward, ensuring proper resource management per request.
- **`require_permission(Permission.AUDIT_READ.value)`** — A dependency *factory* that returns a dependency enforcing a specific permission. When resolved, it yields the authenticated `User` (bound to `actor`) only if that user holds the `AUDIT_READ` permission. Otherwise, the request is rejected before the handler body executes.

This pattern moves cross-cutting concerns—database access and authorization—out of the handler logic and into declarative parameters.

### Response Schema

The `response_model=list[AuditLogOut]` declaration tells FastAPI to serialize the return value as a list of `AuditLogOut` objects. This schema (a Pydantic model) defines the shape of the outgoing data, ensuring only the intended fields are exposed and validating the response structure automatically.

## How It Works

When a client sends a `GET /api/audit` request, the following sequence occurs:

1. **Query parameter parsing.** FastAPI reads the optional `action` filter and the `limit` parameter from the query string. If omitted, `action` defaults to `None` and `limit` defaults to `100`.

2. **Dependency resolution.** Before the handler body runs, FastAPI resolves the declared dependencies:
   - It obtains a database session via `get_db`.
   - It runs `require_permission(Permission.AUDIT_READ.value)`, which authenticates the caller and verifies they have the `AUDIT_READ` permission. If the check fails, the request is short-circuited with an appropriate error response, and the handler never executes.

3. **Delegation to the service layer.** With all dependencies satisfied, the handler calls:

   ```python
   audit_service.list_entries(db, action=action, limit=limit)
   ```

   The router itself contains no query logic—it simply forwards the session and filter arguments to the audit service.

4. **Response serialization.** The service returns audit entries, which FastAPI serializes according to the `AuditLogOut` schema before sending them back to the client as JSON.

The `action` and `limit` parameters give callers control over the result set: `action` narrows results to a specific action type, while `limit` caps the number of returned entries (defaulting to the 100 most recent).

## Usage Examples

Retrieve the most recent audit entries (up to the default of 100):

```
GET /api/audit
```

Retrieve entries for a specific action, limited to 25 results:

```
GET /api/audit?action=user.login&limit=25
```

Both requests require an authenticated caller with the `AUDIT_READ` permission. A request from an unauthorized user is rejected before any data is queried.

## Integration

This module sits at the intersection of several parts of the system:

- **`app.database`** — Supplies the `get_db` dependency that provides a per-request SQLAlchemy `Session`.
- **`app.security`** — Provides `require_permission`, which integrates authentication and role-based access control. This ties the endpoint into the broader permission model defined in `app.constants.Permission`.
- **`app.services.audit`** — Contains the actual retrieval logic in `list_entries`. By delegating here, the router stays decoupled from data-access details, and the same service logic can be reused or tested independently of the HTTP layer.
- **`app.schemas.AuditLogOut`** — Defines the serialized output contract, shared with any other part of the system that needs to represent audit entries.
- **`app.models.User`** — The authenticated actor type returned by the permission dependency.

To become active, the `router` defined here must be included in the main FastAPI application (typically via `app.include_router(...)`). Once mounted, the `/api/audit` endpoint becomes part of the application's public API surface and appears in the generated documentation under the "audit" tag.

This design reflects a consistent layered architecture: **routers** handle HTTP concerns and access control, **services** encapsulate business and data logic, and **schemas** govern the data contracts between them.