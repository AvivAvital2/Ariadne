---
id: d3fb9683-593f-5029-a334-59d417bcfda6
type: explanation
title: "Constants Module"
created_at: 2026-07-30T17:30:14.590379+00:00
updated_at: 2026-07-30T17:30:14.590392+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js
metadata:
  module_name: "frontend.src.constants"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js`

# `frontend.src.constants` — Module Documentation

## Overview

This module defines a set of shared **contract constants** for the frontend application. These are string values that must precisely match corresponding values defined on the backend (in `app/constants.py`). The module centralizes user status codes, permission identifiers, and human-readable labels for audit actions.

The primary purpose of this module is to give the frontend a single, authoritative place to reference values that are agreed upon between the client and server. Rather than scattering raw string literals like `"deactivated"` or `"users:read"` throughout the codebase, developers import these named constants, reducing the risk of typos and making the intended values explicit.

## Key Concepts

### Contract-by-convention

The most important concept to understand about this module is captured in its header comment:

> there is no shared type across the HTTP boundary, so keep the two in sync when either side changes.

The frontend (JavaScript) and backend (Python) communicate over HTTP using JSON, which does not carry a shared type system. The two sides agree on string values **by convention only**. This module is one half of that agreement; the other half lives in the backend's `app/constants.py`. If a value changes on one side, it must be updated on the other manually — there is no compiler or shared schema enforcing consistency.

### Plain object "enums"

JavaScript has no built-in enum type, so this module uses the common pattern of a frozen-in-spirit object literal to emulate one. Each exported object maps a symbolic key (e.g. `ACTIVE`) to the literal string the system actually uses (e.g. `"active"`). Consumers reference the symbolic key, keeping call sites readable and the underlying string in one place.

### Three distinct concerns

The module exports three constant groups, each serving a different role:

- **`USER_STATUS`** — the lifecycle states a user account can be in.
- **`PERMISSIONS`** — the permission strings used for authorization checks.
- **`AUDIT_ACTION_LABELS`** — a lookup table converting backend audit action codes into display text.

## How It Works

### `USER_STATUS`

```javascript
export const USER_STATUS = {
  ACTIVE: "active",
  INVITED: "invited",
  DEACTIVATED: "deactivated",
};
```

This object enumerates the possible states of a user account. The frontend compares a user's status field against these constants rather than hardcoding the raw strings. The values (`"active"`, `"invited"`, `"deactivated"`) are exactly what the backend sends and expects.

### `PERMISSIONS`

```javascript
export const PERMISSIONS = {
  USERS_READ: "users:read",
  // ...
  ROLES_MANAGE: "roles:manage",
  AUDIT_READ: "audit:read",
};
```

Each permission is expressed as a colon-delimited string of the form `resource:action` (for example, `users:deactivate`). This naming scheme communicates both the resource being protected and the operation being permitted. The frontend uses these values to determine whether the current user is allowed to perform an action or view a section of the UI — typically by checking whether a permission string is present in the user's granted permissions.

### `AUDIT_ACTION_LABELS`

```javascript
export const AUDIT_ACTION_LABELS = {
  "user.created": "Created",
  "user.updated": "Updated",
  // ...
};
```

Unlike the other two objects, this one is a **lookup map**, not an enum. Its keys are the raw audit action codes emitted by the backend (dot-delimited, in the form `resource.action`), and its values are the human-friendly labels displayed in the audit view. When the frontend renders an audit log entry, it looks up the incoming action code in this map to obtain the text to show the user.

Note the two different string conventions in play:
- Permissions use colons: `users:deactivate`
- Audit actions use dots: `user.deactivated`

These are separate naming schemes for separate concepts, and both must match the backend exactly.

## Usage Examples

Importing and comparing a user status:

```javascript
import { USER_STATUS } from "./constants";

if (user.status === USER_STATUS.DEACTIVATED) {
  // render a "reactivate" button, etc.
}
```

Checking a permission:

```javascript
import { PERMISSIONS } from "./constants";

const canDeactivate = currentUser.permissions.includes(PERMISSIONS.USERS_DEACTIVATE);
```

Rendering an audit action label:

```javascript
import { AUDIT_ACTION_LABELS } from "./constants";

// entry.action might be "user.role_assigned"
const label = AUDIT_ACTION_LABELS[entry.action];
// label === "Roles assigned"
```

When looking up audit labels, be aware that an unrecognized action code will yield `undefined`, so consuming code may need a fallback for action values not present in the map.

## Integration

This module sits at the boundary between the frontend and backend and is depended upon by any frontend code that needs to:

- Interpret or display a user's account status.
- Perform authorization checks based on permissions.
- Present audit log entries in a readable form.

Its counterpart is the backend's `app/constants.py`, with which it shares no code or type definition — only agreed-upon string values. The critical integration responsibility, emphasized in the module's own header comment, is **manual synchronization**: whenever a status, permission, or audit action is added, removed, or renamed on either side of the HTTP boundary, both this file and `app/constants.py` must be updated together to keep client and server in agreement.

Because no automated mechanism enforces this consistency, treating these two files as a linked pair is essential to avoid subtle bugs where the frontend and backend disagree on a value.