---
id: 413058e9-c02c-5cd7-8ea7-c243ac496c76
type: explanation
title: "Alembic migration environment."
created_at: 2026-07-30T17:20:57.928165+00:00
updated_at: 2026-07-30T17:20:57.928179+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  module_name: "backend.alembic.env"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Alembic migration environment.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

# Alembic Migration Environment (`backend.alembic.env`)

## Overview

This module is the **entry point that Alembic executes every time you run a migration command** (such as `alembic upgrade head` or `alembic revision --autogenerate`). Alembic is the schema-migration tool that ships with SQLAlchemy, and by convention it looks for a file named `env.py` inside its migration directory. That file is expected to configure the database connection, wire up the ORM metadata, and actually drive the migration run.

The core responsibility of this module is to bridge two worlds:

1. **Your application's ORM models** — the tables defined in `app.models` and registered against `app.database.Base`.
2. **Alembic's migration machinery** — which needs to know both the current *target* schema (from your models) and how to talk to the database.

Because this file runs as a script rather than being imported as a library, its top-level code executes immediately when invoked. There are no classes here; the logic is expressed as module-level configuration plus two functions that handle the two ways Alembic can operate.

## Key Concepts

### The Alembic `context`

`context` (from `alembic import context`) is a global object provided by Alembic that carries the state of the current migration run. The module configures it and then instructs it to execute migrations. All communication with Alembic — supplying a connection, providing metadata, opening a transaction — flows through this object.

### `config` and the INI file

```python
config = context.config
```

`config` exposes the settings from Alembic's configuration file (typically `alembic.ini`). This is where values like `sqlalchemy.url` (the database connection string) live. The module also uses it to bootstrap Python's logging system:

```python
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
```

This reads the logging configuration defined in the same INI file, so Alembic's log output is formatted according to project conventions.

### `target_metadata` and autogeneration

```python
target_metadata = Base.metadata
```

This is the pivotal line described in the module docstring. `Base.metadata` is a SQLAlchemy `MetaData` object that holds a record of every table registered against the ORM `Base`. By pointing `target_metadata` at it, Alembic's `--autogenerate` feature can compare the *desired* schema (your models) against the *actual* schema (the live database) and produce a migration script for the difference.

### The side-effect import

```python
from app import models  # noqa: F401 - imported for its side effect of registering tables
```

This import looks unused, and the `# noqa: F401` comment silences the linter warning that would otherwise flag it. The import is deliberate and important: **importing `app.models` runs the module-level code that defines the ORM classes**, and defining those classes is what registers their tables on `Base.metadata`. Without this import, `target_metadata` would be empty and autogeneration would incorrectly conclude that every table should be dropped.

### Offline vs. online mode

Alembic can run in two modes, and this module provides a function for each:

- **Offline mode** generates raw SQL scripts *without* connecting to a database.
- **Online mode** connects to a live database and applies migrations directly.

## How It Works

### Startup sequence

When Alembic invokes this file, the following happens at the top level, in order:

1. The `config` object is fetched from the Alembic context.
2. Logging is configured from the INI file (if one is present).
3. `app.models` is imported, which registers all tables on `Base.metadata`.
4. `target_metadata` is set to that metadata.
5. Alembic is asked which mode it is in, and the appropriate function is called.

The mode dispatch happens at the very bottom:

```python
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
```

### Offline migrations

```python
def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()
```

In offline mode, no database connection is opened. Instead, Alembic is given just the connection **URL string**, which it uses to determine the SQL dialect. Two settings tailor the emitted SQL:

- `literal_binds=True` causes parameter values to be rendered inline in the SQL text, rather than as bound parameters — necessary because there's no live connection to bind against.
- `dialect_opts={"paramstyle": "named"}` controls how any remaining parameters are formatted.

The migrations then run inside a transaction, producing SQL statements as output rather than executing them.

### Online migrations

```python
def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()
```

In online mode, the module builds a real SQLAlchemy `Engine`:

- `engine_from_config` constructs the engine from the INI section, reading all keys that begin with the `sqlalchemy.` prefix.
- `poolclass=pool.NullPool` disables connection pooling. This is a deliberate and common choice for migrations: a migration is a short-lived, one-off operation, so there is no benefit to maintaining a pool of reusable connections, and `NullPool` ensures connections are closed cleanly afterward.

The engine opens a connection, hands it to Alembic via `context.configure(connection=connection, ...)`, and runs the migrations inside a transaction. Using a context manager (`with connectable.connect()`) guarantees the connection is released even if a migration fails.

## Usage Examples

You do not call the functions in this module directly. Instead, you invoke Alembic from the command line, and Alembic loads and runs this file for you.

**Apply all pending migrations to the database (online mode):**

```bash
alembic upgrade head
```

**Generate a new migration by comparing models to the database (relies on `target_metadata`):**

```bash
alembic revision --autogenerate -m "add users table"
```

**Emit SQL without touching the database (offline mode):**

```bash
alembic upgrade head --sql
```

The `--sql` flag is what triggers `context.is_offline_mode()` to return `True`, routing execution through `run_migrations_offline`.

## Integration

This module sits at the intersection of several parts of the system:

- **`app.database`** provides the `Base` declarative class, whose `metadata` is the single source of truth for the schema Alembic should target.
- **`app.models`** defines the actual table classes. Importing it for its side effect is what populates `Base.metadata` — making this the crucial link between the application's data model and the migration tooling.
- **`sqlalchemy`** supplies the engine-construction (`engine_from_config`) and pooling (`pool.NullPool`) primitives used to connect to the database.
- **`alembic`** provides the `context` that drives the migrations, and reads its settings from the INI configuration file.
- **`logging`** is configured from the same INI file so migration runs produce consistent, formatted output.

In short, this file is the glue that lets Alembic "see" your ORM models and connect to your database, enabling both automatic migration generation and safe schema changes.