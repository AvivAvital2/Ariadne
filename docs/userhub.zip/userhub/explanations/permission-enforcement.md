---
id: 1bbb8cc6-7083-51a3-b766-200cd2026d9b
type: explanation
title: "Permission enforcement."
created_at: 2026-07-30T17:24:44.782445+00:00
updated_at: 2026-07-30T17:24:44.782459+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  module_name: "backend.app.security"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Permission enforcement.

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

# `backend.app.security` — Permission Enforcement

## Overview

The `backend.app.security` module is the server-side gatekeeper for the application's authorization system. Its job is to determine *who* is making a request and *whether* they are allowed to perform the requested action.

The module operates on a simple but important principle stated in its docstring: **the server enforces permissions regardless of what the client shows**. The frontend may hide buttons and controls that a user cannot use, but that is purely a convenience for the user experience. This module ensures that even if a client bypasses the UI and sends a request directly, the server rejects unauthorized actions.

To enforce permissions, endpoints declare their requirements declaratively, for example:

```python
require_permission("users:deactivate")
```

This produces a FastAPI dependency that FastAPI runs before the endpoint's handler, admitting or rejecting the request based on the caller's permissions.

## Key Concepts

### The Acting User (Actor)

Every protected request must identify the user performing the action. This module resolves the actor from an HTTP header, **`X-Actor-Id`**, which carries the numeric ID of the requesting user. The term "actor" is used throughout to refer to this acting user.

Note that this is an identity-by-header scheme rather than a token-based authentication system. The header value is looked up directly against the user store to resolve a `User` object.

### Permission Strings

Permissions are represented as plain strings such as `"users:deactivate"`. This string-based, colon-namespaced convention allows the same permission identifiers to be shared across the backend and the frontend. Because both sides refer to permissions by the same string, the frontend can hide controls using the exact permission names the backend enforces.

### FastAPI Dependencies

The module leans heavily on FastAPI's dependency injection system. Rather than writing permission checks inside every endpoint handler, this module produces reusable *dependencies* — callables that FastAPI resolves before invoking the handler. A dependency can:

- Extract data from the request (here, a header via `Header`)
- Pull in other dependencies (here, a database session via `Depends(get_db)`)
- Raise an `HTTPException` to short-circuit the request

This pattern keeps authorization logic centralized and out of the endpoint bodies.

### The Dependency Factory Pattern

`require_permission` is not a dependency itself — it is a *factory* that builds one. Because each endpoint may require a different permission string, the module uses a closure to capture the required permission and return a customized dependency (`checker`). This is the central design pattern of the module.

## How It Works

### Resolving the actor without a permission gate: `current_actor`

`current_actor` is a FastAPI dependency that identifies the requesting user but performs **no permission check**.

Its flow is:

1. Read the `X-Actor-Id` header. FastAPI enforces its presence because it is declared as required (`Header(...)`).
2. Look up the user through `user_service.get_user(db, x_actor_id)`.
3. If no matching user is found, raise `HTTPException(status_code=401, detail="unknown actor")`.
4. Otherwise, return the resolved `User`.

This dependency exists primarily so an endpoint like `/api/me` can tell the frontend who it is and what permissions it holds — information the frontend needs in order to decide which controls to show. Because this is a self-inspection endpoint, no specific permission is required beyond being a known user.

### Building a permission-gated dependency: `require_permission` and `checker`

`require_permission(permission)` returns the inner `checker` function, which is the actual dependency attached to protected endpoints. The `permission` argument is captured by the closure and used inside `checker`.

When FastAPI resolves `checker` for an incoming request, it performs:

1. Read the `X-Actor-Id` header (required).
2. Resolve the acting user via `user_service.get_user(db, x_actor_id)`.
3. If the user is unknown, raise `401 Unauthorized` with detail `"unknown actor"`.
4. Check whether the actor holds the required permission via `user_service.actor_has_permission(actor, permission)`.
5. If the permission is missing, raise `403 Forbidden` with detail `"missing permission: {permission}"`.
6. If all checks pass, return the `User` so the endpoint handler can use it.

The distinction between the two error codes is meaningful:

- **401 (unknown actor)** — the caller could not be identified at all.
- **403 (missing permission)** — the caller is known but not allowed to perform this action.

## Usage Examples

### Protecting an endpoint

A router declares the required permission when wiring up the dependency. The dependency both enforces the permission and provides the resolved actor to the handler:

```python
from fastapi import APIRouter, Depends
from app.security import require_permission
from app.models import User

router = APIRouter()

@router.post("/api/users/{user_id}/deactivate")
def deactivate_user(
    user_id: int,
    actor: User = Depends(require_permission("users:deactivate")),
):
    # `actor` is guaranteed to be a known user with the
    # "users:deactivate" permission at this point.
    ...
```

If the caller lacks `users:deactivate`, FastAPI never invokes `deactivate_user`; the request is rejected with a `403` first.

### Identifying the caller without gating

For self-inspection endpoints, `current_actor` is used directly:

```python
@router.get("/api/me")
def read_me(actor: User = Depends(current_actor)):
    return actor
```

## Integration

This module sits at the intersection of several parts of the system:

- **`app.database`** — Both dependencies acquire a database session through `Depends(get_db)`, so actor resolution and permission checks run against the live data store within the request's session.

- **`app.models`** — The resolved actor is returned as a `User` model instance, which both dependencies expose to endpoint handlers.

- **`app.services.users`** — The module delegates all domain logic to the user service:
  - `get_user(db, id)` performs the lookup that identifies the actor.
  - `actor_has_permission(actor, permission)` encapsulates how a user's permissions are determined. This module does not know *how* permissions are stored or computed; it only asks the service whether a given permission is held.

- **`fastapi`** — Provides the `Depends`, `Header`, and `HTTPException` machinery that makes the declarative, dependency-based enforcement possible.

- **The frontend** — Consumes the shared permission strings. It uses `/api/me` (backed by `current_actor`) to learn its own permissions and hides controls accordingly, while this module ensures those same permissions are enforced on the server.

By concentrating actor resolution and permission checks in one place and exposing them as reusable dependencies, the module keeps authorization consistent across endpoints and decouples the enforcement mechanism from the underlying permission logic in the user service.