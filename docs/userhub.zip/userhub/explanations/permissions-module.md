---
id: 4ed2ada3-561d-53ea-b438-07f04c16e92b
type: explanation
title: "Permissions Module"
created_at: 2026-07-30T17:26:49.271160+00:00
updated_at: 2026-07-30T17:26:49.271174+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js
metadata:
  module_name: "frontend.src.auth.permissions"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Permissions Module

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js`

# `frontend.src.auth.permissions`

## Overview

This module provides a single, focused utility for **client-side permission checking**. Its purpose is to answer a simple question: *does the current user (the "actor") have a specific permission?*

The module exposes one function, `hasPermission`, which compares a named permission (such as `"users:deactivate"`) against the set of permissions the backend has assigned to the current user. This enables the frontend to conditionally render UI elements—hiding buttons, disabling actions, or gating routes—based on what the user is actually allowed to do.

A critical design point, made explicit in the source comment, is that **this check is not a security boundary**. The authoritative enforcement of permissions happens server-side in `security.require_permission`. The client-side check exists purely to improve the user experience by not showing options the user cannot use.

## Key Concepts

### The Actor

The `actor` represents the currently authenticated user. It is expected to be an object retrieved from the `GET /api/me` endpoint. The relevant part of its shape is:

```javascript
{
  permissions: ["users:deactivate", "reports:view", ...]
}
```

The `permissions` field is an array of permission literals—strings that name specific capabilities.

### Permission Literals

Permissions are represented as string constants (e.g. `"users:deactivate"`). The comment notes these literals originate from `constants.js`. The naming convention follows a `resource:action` pattern, which groups permissions by the object they act upon (`users`) and the operation being performed (`deactivate`). Using shared constants rather than raw string literals reduces the risk of typos and keeps the frontend and backend vocabulary aligned.

### Defensive Access

The function is built to tolerate missing or incomplete data. It uses optional chaining and a boolean coercion to guarantee a safe, predictable return value regardless of the input's completeness.

## How It Works

The entire logic lives in a single expression:

```javascript
return Boolean(actor?.permissions?.includes(permission));
```

Reading this from the inside out:

1. **`actor?.permissions`** — Optional chaining first checks whether `actor` is defined. If `actor` is `null` or `undefined`, the expression short-circuits and evaluates to `undefined` rather than throwing an error.

2. **`?.includes(permission)`** — If `actor.permissions` exists, `includes` checks whether the array contains the requested permission string. Because optional chaining is used again, a missing `permissions` field also results in `undefined` instead of a runtime error.

3. **`Boolean(...)`** — The result of the above may be `true`, `false`, or `undefined`. Wrapping it in `Boolean()` normalizes any falsy outcome (including `undefined`) to `false`, ensuring the function always returns a strict boolean.

This layered defensiveness means the function behaves correctly in all common edge cases:

- `hasPermission(undefined, "x")` → `false`
- `hasPermission({}, "x")` → `false`
- `hasPermission({ permissions: [] }, "x")` → `false`
- `hasPermission({ permissions: ["x"] }, "x")` → `true`

## Usage Examples

### Basic check

```javascript
import { hasPermission } from "./permissions";

if (hasPermission(currentUser, "users:deactivate")) {
  // Show the deactivate button
}
```

### Conditional rendering in a UI component

```javascript
{hasPermission(actor, "reports:view") && (
  <ReportsPanel />
)}
```

### Handling an unauthenticated state

Because the function safely handles `null`/`undefined`, it can be called before the actor has loaded without special guarding:

```javascript
// actor may still be null while /api/me is loading
const canEdit = hasPermission(actor, "posts:edit"); // false until loaded
```

## Integration

This module sits at the intersection of several parts of the system:

- **`GET /api/me`** — Supplies the `actor` object, including its `permissions` array. Callers are responsible for fetching this data and passing it in; the module itself performs no network requests.

- **`constants.js`** — Defines the permission literals that should be passed as the `permission` argument. Using these shared constants keeps permission names consistent across the codebase.

- **`security.require_permission` (backend)** — Enforces the *same* permissions on the server. The client-side `hasPermission` mirrors this backend logic to keep the UI consistent with what the server will allow, but the backend remains the true authority. Any action the UI permits will still be independently validated server-side.

Because the module has no dependencies and a pure, side-effect-free signature, it is trivial to test and can be imported anywhere a permission decision needs to be made in the frontend.