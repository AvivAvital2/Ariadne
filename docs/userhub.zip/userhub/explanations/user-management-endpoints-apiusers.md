---
id: 0c1be996-9f57-5c22-b465-0dfa0fab80fa
type: explanation
title: "User management endpoints (``/api/users``)."
created_at: 2026-07-30T17:24:05.842171+00:00
updated_at: 2026-07-30T17:24:05.842184+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  module_name: "backend.app.routers.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# User management endpoints (``/api/users``).

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

# User Management Router (`backend.app.routers.users`)

## Overview

This module defines the HTTP endpoints for user management in a FastAPI application, all served under the `/api/users` path (plus a related `/api/me` endpoint). It exposes a full set of CRUD-style operations for managing users: identifying the current user, listing and retrieving users, creating and updating them, changing their active status, assigning roles, and deleting them.

The module is intentionally thin. Each endpoint function does three things: declare its dependencies (database session, authorization requirements), unpack the validated request payload, and delegate the actual work to the `app.services.users` service layer. This keeps HTTP concerns (routing, status codes, request/response shapes) cleanly separated from business logic (persistence, validation rules, audit trails).

## Key Concepts

### The router as a routing layer, not a logic layer

The endpoints contain almost no business logic. All meaningful operations are forwarded to functions in the `user_service` module (imported as `from app.services import users as user_service`). The router's job is to translate between the HTTP world and the service world.

### Explicit full paths on each decorator

A notable design choice, documented in the module docstring, is that every route decorator specifies its complete path — for example, `@router.get("/api/users/{user_id}")` — rather than using `APIRouter(prefix="/api/users")`. The stated reason is that the route templates then appear verbatim in the source and match the frontend's fetch URLs exactly. This trades a small amount of repetition for a direct, searchable correspondence between backend routes and client calls.

### Dependency injection for cross-cutting concerns

FastAPI's `Depends` mechanism supplies two recurring dependencies:

- **`get_db`** provides a SQLAlchemy `Session` for database access.
- **`require_permission(...)`** and **`current_actor`** handle authentication and authorization.

`current_actor` resolves the authenticated user making the request. `require_permission(Permission.X.value)` is a dependency *factory* — it returns a dependency that both authenticates the caller and verifies they hold a specific permission, then yields the acting `User` object. Because it returns the actor, endpoints receive the caller identity "for free" while enforcing access control as a side effect.

### Permission-gated endpoints

Each mutating or sensitive operation is guarded by a distinct permission drawn from the `Permission` enum in `app.constants`:

| Endpoint | Permission required |
|----------|--------------------|
| `list_users`, `get_user` | `USERS_READ` |
| `create_user` | `USERS_CREATE` |
| `update_user` | `USERS_EDIT` |
| `set_user_status` | `USERS_DEACTIVATE` |
| `assign_roles` | `ROLES_MANAGE` |
| `delete_user` | `USERS_DELETE` |

The `/api/me` endpoint uses `current_actor` instead of a specific permission — any authenticated user may query their own identity.

### Pydantic schemas for input and output

Request bodies and response shapes are defined by schemas from `app.schemas`:

- **Input**: `UserCreate`, `UserUpdate`, `UserStatusUpdate`, `RoleAssignment`
- **Output**: `UserOut`, `CurrentUser`

The `response_model` argument on each decorator ensures responses are serialized and filtered through the declared schema, so internal `User` model attributes not present in `UserOut` are never leaked to clients.

## How It Works

### Identifying the current user (`/api/me`)

The `whoami` endpoint depends only on `current_actor`. It constructs a `CurrentUser` response by copying identity fields from the actor (`id`, `username`, `full_name`, `status`) and computing the actor's effective permissions via `user_service.effective_permissions(actor)`. This lets the frontend discover what the logged-in user is allowed to do, which typically drives UI decisions like showing or hiding controls.

### Reading users

`list_users` accepts an optional `status` query parameter and passes it to `user_service.list_users(db, status=status)`, allowing callers to filter by user status (for example, only active users). `get_user` fetches a single user by ID and raises a `404 Not Found` `HTTPException` when the service returns `None`. Notably, the 404 handling lives in the router rather than the service, since "not found" is an HTTP-level concern.

### Creating a user

`create_user` returns HTTP `201 Created`. It unpacks the validated `UserCreate` payload into explicit keyword arguments (`username`, `email`, `full_name`, `role_ids`) and forwards them to the service. Crucially, it also passes `actor_id=actor.id` — the identity of the caller performing the creation.

### Passing `actor_id` through mutations

Every write operation (`create_user`, `update_user`, `set_user_status`, `assign_roles`, `delete_user`) forwards `actor_id=actor.id` to the service layer. This pattern gives the service the identity of who performed each action, which is the raw material for audit logging or ownership tracking. The router captures *who* is acting; the service decides what to *do* with that information.

### Updating, status changes, and role assignment

- `update_user` (HTTP `PUT`) edits mutable profile fields (`email`, `full_name`).
- `set_user_status` (HTTP `PATCH`) toggles a user between active and inactive states. Its docstring notes it is called by the frontend's `deactivateUser` client function and requires `users:deactivate`. The use of `PATCH` reflects that it modifies a single aspect of the resource rather than replacing it.
- `assign_roles` (HTTP `POST`) attaches a set of `role_ids` to a user and is gated by the `ROLES_MANAGE` permission rather than a user-specific one, since it concerns role administration.

### Deleting a user

`delete_user` returns HTTP `204 No Content` and has a return type of `None` — no response body is sent. It delegates to `user_service.delete_user`, again passing `actor_id`.

## Usage Examples

These endpoints are consumed over HTTP. Representative requests:

**Fetch the current user's identity and permissions**
```
GET /api/me
```

**List only active users**
```
GET /api/users?status=active
```

**Deactivate a user (frontend `deactivateUser`)**
```
PATCH /api/users/42/status
Content-Type: application/json

{"status": "inactive"}
```

**Assign roles to a user**
```
POST /api/users/42/roles
Content-Type: application/json

{"role_ids": [1, 3]}
```

All requests must carry whatever credentials `current_actor` / `require_permission` expect (for example, an authentication token), and the caller must hold the permission required by the targeted endpoint.

## Integration

This module sits at the boundary between the HTTP interface and the application's internal layers:

- **`app.services.users`** — The router delegates all business logic here. This service layer owns persistence, validation, permission computation (`effective_permissions`), and any audit handling implied by the `actor_id` argument.
- **`app.security`** — Supplies `current_actor` (authentication) and `require_permission` (authorization). These dependencies enforce access control uniformly across endpoints.
- **`app.database`** — Provides `get_db`, the SQLAlchemy `Session` dependency scoped to each request.
- **`app.models.User`** — The ORM model returned from service calls and injected as the acting user. Response models re-serialize these into safe output schemas.
- **`app.schemas`** — Defines the validated input and output contracts.
- **`app.constants.Permission`** — The enum of permission strings that tie endpoints to the authorization system.

The `router` object itself is registered with the main FastAPI application (typically via `app.include_router(router)`), at which point these routes become live. The frontend interacts exclusively with the declared URL templates, which — by the module's deliberate design — match the decorator paths verbatim.