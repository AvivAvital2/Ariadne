---
id: 4a27a179-04f3-50be-b1d6-e0e66f8cb106
type: architecture
title: "Models Architecture"
created_at: 2026-07-30T17:22:32.005420+00:00
updated_at: 2026-07-30T17:22:32.005435+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  module_name: "backend.app.models"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Models Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

# Architecture Document: `backend.app.models`

## 1. Component Overview

The `backend.app.models` module defines the persistence layer for an identity and
access management (IAM) domain using **SQLAlchemy 2.0** declarative ORM style. It
maps Python classes onto the underlying SQLite schema and encodes the core domain
relationships: users, their roles, the permissions granted to those roles, and an
audit trail of significant actions.

### Responsibilities
- Define the ORM entities: `User`, `Role`, `Permission`, and `AuditLog`.
- Declare the many-to-many association tables (`user_roles`, `role_permissions`).
- Establish bidirectional relationships enabling RBAC (Role-Based Access Control)
  traversal (user → roles → permissions).
- Provide auditable event storage decoupled from the core entities.

### Non-Responsibilities
- No business logic (validation, authorization decisions, or state transitions).
- No session/transaction management (owned by callers via `app.database`).
- No enum definitions — string columns reference external enum *values*
  (`UserStatus`, `Permission`, `AuditAction`) documented in comments only.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **SQLAlchemy 2.0 declarative + `Mapped[]` typing** | Provides static type hints and modern, IDE-friendly mapping. Avoids the legacy `Column`-only attribute style except where required (association tables). |
| **String columns for enumerated values** (`status`, `Permission.name`, `AuditLog.action`) | Keeps the schema flexible and decoupled from Python enum classes. The enum semantics live in the application layer; the DB stores plain strings. This trades DB-level constraint enforcement for evolvability. |
| **RBAC via two association tables** | `user_roles` and `role_permissions` implement a classic many-to-many RBAC model. Permissions are never assigned directly to users; they are always mediated by roles, centralizing access policy. |
| **`AuditLog.actor_id` nullable + no relationship** | The audit log is intentionally loosely coupled. A `nullable` `actor_id` supports system-generated events (no human actor). Using a `ForeignKey` without a mapped `relationship` keeps audit writes lightweight and avoids cascade complications. |
| **Polymorphic-lite `target_type` / `target_id`** | Rather than a strict FK per target, the audit log uses a `(target_type, target_id)` pair, defaulting to `"user"`. This lets one table log actions against multiple entity types. |
| **UTC-aware timestamps via `_utcnow()`** | Centralizes timezone handling. All `created_at`/`updated_at` values are timezone-aware UTC, avoiding naive-datetime ambiguity. |
| **Selective indexing** | `username`, `AuditLog.action`, and `AuditLog.created_at` are indexed to support login lookups and time/action-based audit queries. |

---

## 3. Component Diagram

```dot
digraph models {
    rankdir=LR;
    node [shape=record, fontname="Helvetica", fontsize=10];
    edge [fontname="Helvetica", fontsize=9];

    Base [label="app.database.Base\n(Declarative Base)", shape=box, style=filled, fillcolor="#eeeeee"];

    User [label="{User (users)|id: int PK\lusername: str UQ, IDX\lemail: str UQ\lfull_name: str\lstatus: str\lcreated_at: datetime\lupdated_at: datetime\l}"];

    Role [label="{Role (roles)|id: int PK\lname: str UQ\ldescription: str\l}"];

    Permission [label="{Permission (permissions)|id: int PK\lname: str UQ\ldescription: str\l}"];

    AuditLog [label="{AuditLog (audit_log)|id: int PK\lactor_id: int? FK\laction: str IDX\ltarget_type: str\ltarget_id: int?\ldetail: text\lcreated_at: datetime IDX\l}"];

    user_roles [label="user_roles\n(assoc table)", shape=box, style="dashed"];
    role_permissions [label="role_permissions\n(assoc table)", shape=box, style="dashed"];

    // Inheritance from declarative base
    User -> Base [arrowhead=onormal, style=dotted, label="maps"];
    Role -> Base [arrowhead=onormal, style=dotted];
    Permission -> Base [arrowhead=onormal, style=dotted];
    AuditLog -> Base [arrowhead=onormal, style=dotted];

    // Many-to-many relationships
    User -> user_roles [dir=both, label="roles / users"];
    Role -> user_roles [dir=both];

    Role -> role_permissions [dir=both, label="permissions / roles"];
    Permission -> role_permissions [dir=both];

    // Loose FK reference (no ORM relationship)
    AuditLog -> User [style=dashed, label="actor_id (FK, nullable)"];
}
```

**Legend:** solid boxes = mapped entities, dashed boxes = association tables,
dotted arrows = declarative-base mapping, dashed arrow = FK with no ORM relationship.

---

## 4. Interfaces

### Mapped Entity Classes
All four classes inherit from `app.database.Base` and are discoverable via
`Base.metadata`. They are the primary integration surface for repositories,
services, and Alembic-style migrations.

| Class | Table | Key Access Points |
|-------|-------|-------------------|
| `User` | `users` | `.roles` (list of `Role`), unique `.username`, `.email` |
| `Role` | `roles` | `.users`, `.permissions`, unique `.name` |
| `Permission` | `permissions` | `.roles`, unique `.name` |
| `AuditLog` | `audit_log` | `.actor_id`, `.action`, `.target_type`, `.target_id` |

### Relationship Contracts (bidirectional)
- `User.roles` ↔ `Role.users` (via `user_roles`)
- `Role.permissions` ↔ `Permission.roles` (via `role_permissions`)

Mutating either side of a relationship updates the association table on flush.

### Integration Points
- **`app.database.Base`** — the shared declarative base and `metadata` registry.
  Schema creation (`Base.metadata.create_all`) and migrations depend on these
  models being imported.
- **String-valued enums** — callers are expected to persist values from external
  enum types:
  - `User.status` ← `UserStatus` (`"invited"` default, `"active"`, `"deactivated"`)
  - `Permission.name` ← `Permission` enum (e.g. `"users:deactivate"`)
  - `AuditLog.action` ← `AuditAction` enum (e.g. `"user.deactivated"`)

---

## 5. Data Flow

```dot
digraph dataflow {
    rankdir=TB;
    node [shape=box, fontname="Helvetica", fontsize=10];

    Service [label="Service / Repository layer", style=filled, fillcolor="#dbe9ff"];
    Session [label="SQLAlchemy Session\n(app.database)"];
    ORM [label="ORM Models\n(User/Role/Permission/AuditLog)"];
    DB [label="SQLite\n(users, roles, permissions,\nuser_roles, role_permissions, audit_log)", shape=cylinder];

    Service -> Session [label="add / query / commit"];
    Session -> ORM [label="identity map / instances"];
    ORM -> DB [label="INSERT / UPDATE / SELECT"];
    DB -> ORM [label="hydrate rows"];
}
```

### Typical Flows

1. **Read RBAC chain (authorization check):**
   `User` is loaded → `.roles` traverses `user_roles` → `Role.permissions`
   traverses `role_permissions` → the union of `Permission.name` values yields
   the user's effective permission set.

2. **Write with timestamps:**
   On `INSERT`, `created_at`/`updated_at` default to `_utcnow()`. On `UPDATE`,
   `User.updated_at` is automatically refreshed via `onupdate=_utcnow`.

3. **Audit event capture:**
   A service creates an `AuditLog` row with `actor_id`, `action`,
   `target_type`/`target_id`, and optional `detail`. This is written
   independently — no relationship traversal or cascade is triggered.

---

## 6. Extension Points

### Adding a New Entity
Create a class inheriting `Base` with a `__tablename__`. Use `Mapped[...]` +
`mapped_column(...)` for typed columns. It will automatically register in
`Base.metadata` for schema creation.

### Extending RBAC
- **New permissions:** add rows to `permissions` using the external `Permission`
  enum value as `name`. No schema change required.
- **Direct user permissions (if ever needed):** introduce a `user_permissions`
  association table mirroring `role_permissions`, plus a `User.permissions`
  relationship. Prefer keeping permissions role-mediated unless a strong case
  exists.

### Auditing New Target Types
The `(target_type, target_id)` pattern already supports arbitrary targets.
Persist a new `target_type` string (e.g. `"role"`) — no schema change needed.
If strict referential integrity per target is required later, consider
polymorphic FK modeling, at the cost of coupling.

### Timestamp / Timezone Behavior
Override or wrap `_utcnow()` to change the timestamp source (e.g. for testing
via a clock abstraction). Because all timestamp defaults route through this
single function, it is the intended customization hook.

### Enum Enforcement
The current design stores enum *values* as strings. To harden at the DB level,
migrate columns to `sqlalchemy.Enum(...)` bound to the Python enum classes.
This trades flexibility for validation and should be a deliberate decision.

### Migration Considerations
Because indexes exist on `username`, `AuditLog.action`, and
`AuditLog.created_at`, any renaming or type changes to these columns should be
accompanied by index-preserving migrations to avoid query-performance regressions.