---
id: c87d47f1-0480-5c91-bb35-60b854d51f2e
type: architecture
title: "Icons Architecture"
created_at: 2026-07-30T17:27:42.736800+00:00
updated_at: 2026-07-30T17:27:42.736815+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx
metadata:
  module_name: "frontend.src.components.Icons"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Icons Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx`

# Icons Component Architecture

**Module:** `frontend.src.components.Icons`

---

## 1. Component Overview

The `Icons` module is a self-contained, dependency-free SVG icon set for the frontend application. It provides a collection of named, reusable React icon components (e.g., `IconDashboard`, `IconUsers`, `IconBell`) built on top of a shared internal `Svg` wrapper.

**Primary responsibilities:**

- Render vector icons inline as React components (no external icon-library dependency).
- Provide a consistent visual baseline (viewBox, stroke behavior, line caps/joins) across all icons.
- Delegate color and sizing control to the consuming context via CSS and props.

The module deliberately avoids runtime dependencies, reducing bundle size and eliminating version coupling to third-party icon packages.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Inline SVG, no icon library** | Removes a dependency, avoids tree-shaking pitfalls, and keeps full control over markup. |
| **`stroke="currentColor"`** | Lets CSS `color` cascade determine icon color, so icons theme automatically with surrounding text. |
| **Shared `Svg` wrapper** | Centralizes common attributes (viewBox, stroke width, line joins) so individual icons only define geometry. |
| **`size` prop defaulting to `20`** | Provides sensible default while allowing per-usage overrides; applies to both `width` and `height` for square icons. |
| **`aria-hidden="true"` default** | Treats icons as decorative by default; accessible labels are expected to come from the parent element (or an overriding prop). |
| **`{...rest}` / `{...p}` spread** | Enables prop pass-through (e.g., `className`, `onClick`, `style`, ARIA overrides) without wrapping every icon in bespoke prop logic. |
| **24×24 coordinate system** | Standard SVG grid consistent with common icon design tooling, ensuring uniform proportions. |

---

## 3. Component Diagram

```dot
digraph IconsModule {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_icons {
    label="Icons Module (exported)";
    style=dashed;

    IconDashboard;
    IconUsers;
    IconShield;
    IconActivity;
    IconUserCheck;
    IconUserX;
    IconClock;
    IconPlus;
    IconSearch;
    IconBell;
  }

  Svg [label="Svg (internal wrapper)\nsize, children, ...rest", style="rounded,filled", fillcolor="#eef4ff"];

  IconDashboard -> Svg;
  IconUsers     -> Svg;
  IconShield    -> Svg;
  IconActivity  -> Svg;
  IconUserCheck -> Svg;
  IconUserX     -> Svg;
  IconClock     -> Svg;
  IconPlus      -> Svg;
  IconSearch    -> Svg;
  IconBell      -> Svg;

  Svg -> DOM [label="renders <svg>"];
  DOM [label="Rendered SVG DOM\n(inherits CSS color/size)", shape=note];

  Consumer [label="Consuming Components\n(navbars, buttons, lists)", shape=component];
  Consumer -> IconDashboard [style=dotted, label="import & render"];
  Consumer -> IconBell      [style=dotted, label="import & render"];
}
```

---

## 4. Interfaces

### 4.1 `Svg` (internal, not exported)

```jsx
Svg({ size = 20, children, ...rest })
```

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `size` | `number` | `20` | Sets both `width` and `height` in pixels. |
| `children` | `ReactNode` | — | SVG geometry (paths, shapes) supplied by each icon. |
| `...rest` | any SVG/DOM props | — | Forwarded to the root `<svg>` (e.g., `className`, `style`, `onClick`, `aria-label`). |

**Fixed attributes** applied by the wrapper: `viewBox="0 0 24 24"`, `fill="none"`, `stroke="currentColor"`, `strokeWidth="2"`, `strokeLinecap="round"`, `strokeLinejoin="round"`, `aria-hidden="true"`.

### 4.2 Exported Icon Components

Each exported icon shares the same signature and forwards all props to `Svg`:

```jsx
IconName(props) => <Svg {...props}>{/* geometry */}</Svg>
```

| Icon | Typical Semantic Use |
|------|----------------------|
| `IconDashboard` | Dashboard / grid overview |
| `IconUsers` | User groups / team |
| `IconShield` | Security / roles / permissions |
| `IconActivity` | Activity feed / metrics |
| `IconUserCheck` | Approve / verify user |
| `IconUserX` | Reject / deactivate user |
| `IconClock` | Time / recency / pending |
| `IconPlus` | Create / add action |
| `IconSearch` | Search input / filter |
| `IconBell` | Notifications |

**Usage examples:**

```jsx
import { IconSearch, IconBell } from 'components/Icons';

<IconSearch />                                  // default 20px, current color
<IconBell size={28} className="text-red-500" /> // larger, custom color via CSS
<IconUserX aria-hidden={false} aria-label="Remove user" /> // override decorative default
```

---

## 5. Data Flow

Icons are stateless presentational components; the "data" is purely props flowing downward into rendered SVG markup.

```dot
digraph IconDataFlow {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Parent [label="Consumer component\n(passes size, className, handlers)"];
  Icon   [label="IconX component\n(defines geometry)"];
  Svg    [label="Svg wrapper\n(merges defaults + rest props)"];
  Render [label="<svg> DOM element", shape=note];
  CSS    [label="CSS cascade\n(color, font-size context)", shape=ellipse];

  Parent -> Icon   [label="props {size, ...rest}"];
  Icon   -> Svg    [label="props + geometry children"];
  Svg    -> Render [label="attributes applied"];
  CSS    -> Render [label="currentColor resolves", style=dashed];
}
```

**Flow summary:**

1. A consumer imports and renders an icon, optionally passing `size`, `className`, `style`, event handlers, or ARIA overrides.
2. The icon component injects its unique geometry as `children` and forwards all incoming props to `Svg`.
3. `Svg` applies shared defaults, allowing `...rest` to override any of them (last-write-wins in JSX spread order — note that explicit attributes appear *before* `{...rest}`, so `rest` can override them).
4. The browser renders the `<svg>`; `stroke="currentColor"` resolves against the inherited CSS `color`, so color and contextual sizing derive from styling rather than props.

There is **no internal state, no side effects, and no external I/O** in this module.

---

## 6. Extension Points

### 6.1 Adding a New Icon

Follow the established pattern — define geometry only, and let `Svg` provide the frame:

```jsx
export const IconStar = (p) => (
  <Svg {...p}>
    <polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9" />
  </Svg>
);
```

Guidelines for consistency:
- Design geometry within the `0 0 24 24` viewBox.
- Always spread `{...p}` to preserve prop pass-through.
- Prefer stroke-based shapes (matching `fill="none"` + `stroke="currentColor"`); if a filled shape is needed, override `fill` on the specific element.

### 6.2 Customizing Appearance

- **Color:** Set CSS `color` on the icon or an ancestor; `currentColor` inherits it.
- **Size:** Pass `size={n}` per usage, or override with `width`/`height` / `className` via `...rest`.
- **Stroke weight:** Pass `strokeWidth` through props to override the default `2`.

### 6.3 Overriding Wrapper Defaults

Because explicit `Svg` attributes are declared before `{...rest}`, consumers can override any default:

```jsx
<IconShield fill="currentColor" strokeWidth={1.5} aria-hidden={false} aria-label="Security" />
```

### 6.4 Recommended Future Extensions

- **Barrel-level accessibility helper:** an optional `title` prop that injects an `<title>` element for labeled (non-decorative) icons.
- **Variant map / registry:** if dynamic icon selection by name is needed, introduce an `iconMap` object keyed by string to avoid conditional import logic in consumers.
- **Size token integration:** map `size` to design-system tokens (`sm`/`md`/`lg`) if the app adopts a spacing scale.

---

*This module is intentionally minimal and side-effect-free. Keep new icons purely presentational and route all styling concerns through CSS and props to preserve its dependency-free, theme-friendly design.*