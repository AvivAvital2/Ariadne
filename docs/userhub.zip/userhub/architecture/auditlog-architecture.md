---
id: b1c5be83-a32d-510a-af97-1a7d10ed0862
type: architecture
title: "Auditlog Architecture"
created_at: 2026-07-30T17:27:09.120530+00:00
updated_at: 2026-07-30T17:27:09.120543+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx
metadata:
  module_name: "frontend.src.components.AuditLog"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Auditlog Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx`

# AuditLog Component Architecture

## 1. Component Overview

The `AuditLog` component is a self-contained React presentation component responsible for displaying a chronological table of system audit events. It answers the operational question: *"who did what, to which entity, and when?"*

**Responsibilities:**
- Fetch audit entries from the backend on mount
- Render entries in a tabular format (timestamp, action, actor, target, detail)
- Map raw action codes to human-readable labels
- Provide visual severity cues (color-coded status dots)
- Surface fetch errors to the user

**Non-responsibilities:**
- No pagination, filtering, or sorting logic (renders whatever the API returns)
- No write operations — it is a read-only view
- No route/navigation concerns — it is a leaf UI card

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Fetch-on-mount via `useEffect`** | Audit data is a snapshot at view time; a one-shot fetch keeps the component simple. Runs once (empty dependency array). |
| **Local component state (`useState`)** | The component owns its data and error state; no global store dependency keeps it decoupled and portable. |
| **`dotClass` as a pure helper** | Severity classification (good/bad/neutral) is derived from action string content, isolating the mapping in one testable function. |
| **Label lookup with fallback (`?? action`)** | Unknown/new action codes degrade gracefully by showing the raw code rather than breaking the UI. |
| **Error rendered inline, table always present** | Users still see the table structure; errors are additive, not blocking. |
| **CSS-class–driven styling** | Presentation (`card`, `dot`, `muted`) is externalized to stylesheets, keeping the component logic-focused. |

---

## 3. Component Diagram

```dot
digraph AuditLog {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_component {
    label="AuditLog Component";
    style=dashed;

    mount      [label="useEffect\n(on mount)"];
    stateE     [label="entries\n(useState)", shape=cylinder];
    stateErr   [label="error\n(useState)", shape=cylinder];
    dotClass   [label="dotClass(action)\n→ good/bad/neutral", shape=component];
    label_fn   [label="label(action)\n→ readable text", shape=component];
    render     [label="render\n<section.card> table"];
  }

  api        [label="api.listAudit()", shape=box, style="rounded,filled", fillcolor="#e6f0ff"];
  labels     [label="AUDIT_ACTION_LABELS", shape=folder, fillcolor="#fff5e6", style=filled];
  css        [label="Stylesheet\n(.card .dot .muted)", shape=note];

  mount   -> api        [label="calls"];
  api     -> stateE     [label="resolve → setEntries"];
  api     -> stateErr   [label="reject → setError"];
  stateE  -> render;
  stateErr-> render;
  render  -> dotClass   [label="per entry"];
  render  -> label_fn   [label="per entry"];
  label_fn-> labels     [label="lookup"];
  render  -> css        [label="classNames", style=dotted];
}
```

---

## 4. Interfaces

### Inbound (Props)
- **None.** The component takes no props and is fully self-initializing.

### Outbound Dependencies

| Dependency | Signature / Shape | Purpose |
|------------|-------------------|---------|
| `api.listAudit()` | `() => Promise<AuditEntry[]>` | Retrieves audit entries |
| `AUDIT_ACTION_LABELS` | `Record<string, string>` | Maps action codes → display labels |

### Expected `AuditEntry` Shape
```ts
interface AuditEntry {
  id: string | number;      // unique key
  created_at: string;       // ISO timestamp
  action: string;           // action code, e.g. "user_created"
  actor_id?: string | null; // who performed the action
  target_type: string;      // entity type acted upon
  target_id?: string | null;// entity id acted upon
  detail: string;           // free-text detail
}
```

### Integration Point
- Consumed by parent views by importing the default export and placing `<AuditLog />` anywhere within an admin/dashboard layout. It renders as a `.card` section, designed to be composed into card-grid layouts.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  mount   [label="1. Component mounts"];
  fetch   [label="2. api.listAudit() invoked"];
  resolve [label="3a. Promise resolves\n→ setEntries(data)"];
  reject  [label="3b. Promise rejects\n→ setError(e.message)"];
  rerender[label="4. Re-render triggered"];
  transform[label="5. Per-entry transform:\ndotClass() + label()"];
  dom     [label="6. Rendered table / error banner"];

  mount -> fetch -> resolve -> rerender;
  fetch -> reject -> rerender;
  rerender -> transform -> dom;
}
```

**Flow narrative:**
1. On mount, `useEffect` triggers a single async fetch.
2. On success, entries populate state; the count in `card-sub` updates automatically.
3. On failure, the error message is stored and displayed above the table.
4. During render, each entry is transformed on-the-fly:
   - `dotClass(action)` derives a severity class for the status dot.
   - `label(action)` resolves a friendly label with raw-code fallback.
   - `created_at` is localized via `toLocaleString()`.
   - Null actor/target ids are shown as `—`.

---

## 6. Extension Points

### Adding New Action Types
Extend `AUDIT_ACTION_LABELS` in `constants.js` to add readable labels. No component change needed — unknown actions already fall back to the raw code.

### Adjusting Severity Coloring
Modify `dotClass()` to change the good/bad/neutral classification rules. Consider promoting this to a lookup map or moving it into `constants.js` if the rule set grows, keeping the classification declarative:
```js
// Potential future refactor
const ACTION_SEVERITY = { user_deleted: "bad", user_created: "good", /* ... */ };
```

### Adding Filtering / Pagination
The current fetch-on-mount model would need to evolve:
- Introduce query state (e.g., `filters`, `page`) and add them to the `useEffect` dependency array.
- Extend `api.listAudit()` to accept query parameters.

### Styling / Theming
All visual concerns are class-driven (`card`, `dot good/bad/neutral`, `muted`, `nowrap`). Override or extend these classes in the stylesheet to re-theme without touching component logic.

### Testability Hooks
- `dotClass` and the inline `label` logic are pure and can be unit-tested in isolation (recommend exporting `dotClass` for direct testing).
- The `api.listAudit` dependency is mockable, enabling render tests for loading, success, and error states.

---

## Maintenance Notes
- The component assumes a stable `entry.id` for React keys; ensure the API guarantees uniqueness.
- Timestamp formatting is locale-dependent (`toLocaleString()`); if consistent formatting is required across environments, inject a formatter.
- Because there is no loading state, an empty table momentarily displays before data arrives — consider a skeleton/loading indicator if perceived latency becomes an issue.