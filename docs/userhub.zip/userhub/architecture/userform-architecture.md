---
id: c4614eb7-2468-5629-b42c-82a9270a68c0
type: architecture
title: "Userform Architecture"
created_at: 2026-07-30T17:29:07.333499+00:00
updated_at: 2026-07-30T17:29:07.333514+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx
metadata:
  module_name: "frontend.src.components.UserForm"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userform Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx`

# UserForm Component Architecture

## 1. Component Overview

`UserForm` is a React presentational/container hybrid component that renders a modal form for **creating** and **editing** user records. It is a dual-mode component whose behavior is driven by the presence (edit) or absence (create) of a `user` prop.

**Core responsibilities:**
- Render a modal form for user data entry (username, full name, email, roles).
- Load the available roles catalog for selection.
- Distinguish between *create* and *edit* workflows and issue the appropriate API calls.
- Surface API/validation errors to the user.
- Notify the parent when a save succeeds (`onSaved`) or the user cancels (`onClose`).

The component is intentionally self-contained: it owns its form state and side effects rather than delegating them to a parent or global store.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Mode inferred from `user === null`** | A single component handles both create and edit, reducing duplication. `isNew` gates fields (username is immutable after creation) and branches the submit logic. |
| **Local `useState` for all fields** | The form is short-lived (modal) and its state is transient. Local state avoids coupling to a global store and keeps the component portable. |
| **Roles fetched on mount via `useEffect`** | The available roles list is dynamic server data and must be fresh. The empty dependency array (`[]`) ensures a single fetch per mount. |
| **Graceful role-fetch fallback (`.catch(() => setRoles([]))`)** | A failed roles fetch degrades to an empty checklist rather than crashing the form, prioritizing form availability. |
| **Username hidden and immutable in edit mode** | Reflects a domain constraint: usernames are identity keys and not editable after creation. The update path omits `username` entirely. |
| **Separate calls for update + role assignment on edit** | The backend exposes `updateUser` and `assignRoles` as distinct endpoints; the create endpoint accepts `role_ids` inline. The component adapts to these two integration shapes. |
| **Callback props (`onClose`, `onSaved`)** | Inversion of control: the component does not know how the modal is dismissed or how the parent refreshes; it only signals lifecycle events. |

---

## 3. Component Diagram

```dot
digraph UserForm {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_parent {
    label="Parent Component";
    style=dashed;
    Parent [label="Parent\n(provides user, onClose, onSaved)"];
  }

  subgraph cluster_userform {
    label="UserForm";
    style=rounded;
    color="#3366cc";

    State [label="Local State\nusername, email, fullName,\nroles, roleIds, error", shape=note];
    ModeFlag [label="isNew = (user === null)", shape=diamond];
    Effect [label="useEffect\n(load roles on mount)", shape=ellipse];
    Submit [label="submit(event)\nhandler", shape=ellipse];
    View [label="Modal Form (JSX)\nfields + roles checklist + actions"];
  }

  subgraph cluster_api {
    label="api/client.js";
    style=dashed;
    ListRoles [label="listRoles()"];
    CreateUser [label="createUser()"];
    UpdateUser [label="updateUser()"];
    AssignRoles [label="assignRoles()"];
  }

  Backend [label="Backend REST API", shape=cylinder];

  Parent -> State [label="props: user"];
  ModeFlag -> View [label="gates username field\n& button labels"];
  Effect -> ListRoles;
  ListRoles -> State [label="setRoles"];
  State -> View [label="controlled inputs"];
  View -> Submit [label="onSubmit"];
  View -> Parent [label="onClose (cancel)"];

  Submit -> CreateUser [label="if isNew"];
  Submit -> UpdateUser [label="if edit"];
  Submit -> AssignRoles [label="if edit"];
  Submit -> Parent [label="onSaved (success)"];
  Submit -> State [label="setError (failure)"];

  ListRoles -> Backend;
  CreateUser -> Backend;
  UpdateUser -> Backend;
  AssignRoles -> Backend;
}
```

---

## 4. Interfaces

### Props (inbound contract)

| Prop | Type | Description |
|------|------|-------------|
| `user` | `object \| null` | The user to edit; `null` triggers create mode. Expected shape: `{ id, username, email, full_name, roles: [{ id, name }] }`. |
| `onClose` | `() => void` | Invoked when the user cancels. Parent is responsible for unmounting/hiding the modal. |
| `onSaved` | `() => void` | Invoked after a successful create or update. Parent typically closes the modal and refreshes its list. |

### API Client Integration (`../api/client.js`)

| Function | Used In | Payload |
|----------|---------|---------|
| `listRoles()` | mount effect | — → `Role[]` |
| `createUser(payload)` | create mode | `{ username, email, full_name, role_ids }` |
| `updateUser(id, payload)` | edit mode | `(user.id, { email, full_name })` |
| `assignRoles(id, roleIds)` | edit mode | `(user.id, roleIds)` |

All API functions are expected to return Promises. Errors are expected to carry a `.message` string, which is rendered in the error banner.

---

## 5. Data Flow

**Initialization**
1. Props arrive; state is seeded from `user` (or empty defaults for create).
2. `useEffect` fires once on mount, calling `listRoles()`; results populate the roles checklist, or fall back to `[]` on failure.

**User interaction**
3. Controlled inputs bind each field to state via `onChange`.
4. Role checkboxes call `toggleRole(id)`, which adds/removes the id from `roleIds` immutably.

**Submission**
5. `submit` prevents default, clears prior error, and branches on `isNew`:
   - **Create:** single `createUser` call with inline `role_ids`.
   - **Edit:** `updateUser` (profile fields) followed by `assignRoles` (role membership).
6. On success → `onSaved()`. On failure → `setError(err.message)` renders the error banner without closing the form.

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Props -> LocalState [label="seed"];
  Mount -> listRoles -> Roles -> Checklist;
  Input -> LocalState [label="onChange"];
  Checkbox -> roleIds [label="toggleRole"];
  LocalState -> Submit;
  roleIds -> Submit;
  Submit -> Success [label="await ok"];
  Submit -> ErrorBanner [label="catch"];
  Success -> onSaved;
}
```

---

## 6. Extension Points

- **Additional fields:** Add new `useState` entries seeded from `user`, render controlled inputs, and include them in the create/update payloads. Keep the `isNew` gating pattern for immutable fields.
- **Custom validation:** Insert client-side checks at the top of `submit` before the API calls, using `setError` for feedback. Currently only HTML5 `required`/`type="email"` validation is applied.
- **Alternative persistence:** The component is decoupled from transport via `../api/client.js`. Swapping the client module (e.g., to GraphQL or a mock) requires no component changes as long as the function signatures and Promise contracts hold.
- **Styling/layout:** Presentation relies on CSS classes (`modal`, `error`, `checkbox`, `modal-actions`, `btn ghost`, `btn primary`). Theming is achieved externally via stylesheet overrides.
- **Lifecycle hooks:** Behavior around dismissal and refresh is fully delegated to `onClose` and `onSaved`, allowing parents to compose the form into different modal frameworks or workflows.

### Known Constraints / Notes
- **No loading/disabled state** during submission; rapid double-submits are possible. A `submitting` flag guarding the submit button is a natural hardening extension.
- **Role assignment on edit is a second network round-trip** and is not transactional with `updateUser`; a partial failure could update the profile but not the roles. Consider consolidating server-side if atomicity is required.