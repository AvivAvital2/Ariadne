---
id: 7ed46fd9-a11a-5f0f-bd30-b89e15d7be08
type: architecture
title: "Statcard Architecture"
created_at: 2026-07-30T17:28:24.966829+00:00
updated_at: 2026-07-30T17:28:24.966841+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx
metadata:
  module_name: "frontend.src.components.StatCard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Statcard Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx`

# StatCard Component Architecture

**Module**: `frontend.src.components.StatCard`

---

## 1. Component Overview

`StatCard` is a **presentational (stateless) React component** designed to render a single statistic in a compact, visually-consistent card format. It is a leaf-level UI primitive intended for use in dashboards, summary panels, and metric overviews.

### Responsibilities
- Render a labeled statistic (value + label) in a standardized card layout.
- Display an optional icon with tone-based styling.
- Display an optional supplementary hint/description.
- Delegate all styling to external CSS via well-known class names.

### Non-Responsibilities
- **No data fetching** — values are provided by the parent via props.
- **No internal state** — it is a pure function of its props.
- **No business logic** — formatting and computation belong to the caller.

This clean separation makes `StatCard` highly reusable and trivially testable.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Stateless functional component** | The card is purely display-oriented; keeping it stateless simplifies reasoning, testing, and re-rendering behavior. |
| **Injection of icon via `icon` prop** | Accepting a component (rendered as `Icon`) rather than a string/URL allows consumers to use any icon library (e.g., lucide-react, react-icons) without coupling StatCard to a specific dependency. |
| **`tone` prop with CSS class mapping** | Visual theming (`tone-primary`, `tone-danger`, etc.) is expressed as a class suffix, delegating color/style concerns to a CSS layer. This keeps the component logic-free and design-system friendly. |
| **Optional fields (`hint`, `icon`)** | Conditional rendering (`Icon && ...`, `hint && ...`) allows the same component to serve both minimal and rich use cases. |
| **Default `tone = "primary"`** | Provides a safe, sensible default so `tone` can be omitted for the common case. |
| **CSS class-based styling (no inline styles)** | Centralizes theming in stylesheets, supports consistency across the app, and enables easy overrides. |

---

## 3. Component Diagram

```dot
digraph StatCard {
  rankdir=TB;
  node [shape=box, style="rounded,filled", fillcolor="#f5f5f5", fontname="Helvetica"];

  Parent [label="Parent Component\n(Dashboard / Panel)", fillcolor="#dbeafe"];

  subgraph cluster_statcard {
    label="StatCard (.stat-card)";
    style="rounded";
    color="#888888";

    Icon    [label="stat-icon\n(tone-{tone})", fillcolor="#fef9c3"];
    Body    [label="stat-body", fillcolor="#e0e7ff"];
    Value   [label="stat-value"];
    Label   [label="stat-label"];
    Hint    [label="stat-hint\n(optional)", style="rounded,filled,dashed"];
  }

  IconComp [label="Injected Icon\nComponent", shape=component, fillcolor="#fde68a"];

  Parent -> Icon    [label="label, value, hint,\ntone, icon (props)"];
  Icon   -> IconComp [label="renders <Icon size=20 />", style=dashed];
  Icon   -> Body    [style=invis];
  Body   -> Value;
  Body   -> Label;
  Body   -> Hint    [style=dashed, label="if hint"];
}
```

---

## 4. Interfaces

### Props API

| Prop    | Type                  | Required | Default     | Description |
|---------|-----------------------|----------|-------------|-------------|
| `label` | `string \| ReactNode` | Yes      | —           | Descriptive caption shown beneath the value. |
| `value` | `string \| number \| ReactNode` | Yes | — | The primary statistic to display. |
| `hint`  | `string \| ReactNode` | No       | `undefined` | Supplementary text; rendered only when truthy. |
| `tone`  | `string`              | No       | `"primary"` | Theme variant, mapped to a CSS class `tone-{tone}`. |
| `icon`  | `React.ComponentType<{ size?: number }>` | No | `undefined` | Icon component; receives `size={20}`. Rendered only when provided. |

### CSS Contract (Integration Point)

The component relies on the following class names being defined in the application's stylesheet:

- `.stat-card` — outer container layout.
- `.stat-icon` — icon wrapper.
- `.tone-{tone}` — tone-specific styling (e.g., `.tone-primary`, `.tone-success`, `.tone-danger`).
- `.stat-body` — text container.
- `.stat-value`, `.stat-label`, `.stat-hint` — text styling.

> **Note:** Because `tone` maps directly to a class name, the set of valid tone values is governed by the CSS layer, not the component. Callers must supply a `tone` for which a corresponding `.tone-*` class exists.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style="rounded,filled", fontname="Helvetica"];

  Source   [label="Data Source\n(API / State / Store)", fillcolor="#bbf7d0"];
  Parent   [label="Parent Component\n(formats & selects tone)", fillcolor="#dbeafe"];
  StatCard [label="StatCard\n(pure render)", fillcolor="#fde68a"];
  DOM      [label="Rendered DOM\n(styled card)", fillcolor="#e5e7eb"];

  Source -> Parent [label="raw metrics"];
  Parent -> StatCard [label="label, value,\nhint, tone, icon"];
  StatCard -> DOM [label="markup"];
}
```

1. **Upstream** — A data source (API response, global state, etc.) provides raw metrics.
2. **Parent transformation** — The parent component formats values (e.g., currency, percentages), selects the appropriate `tone`, and picks an `icon`.
3. **Props delivery** — Fully-prepared values flow into `StatCard` as props.
4. **Rendering** — `StatCard` deterministically renders markup; `icon` and `hint` are conditionally included.
5. **Presentation** — External CSS applies visual styling based on class names.

Data flow is strictly **unidirectional (top-down)**; the component emits no events and holds no state.

---

## 6. Extension Points

### a. Visual Themes via `tone`
Add new tones by defining additional `.tone-*` CSS classes. No component change is required:

```css
.tone-warning { background: #fbbf24; }
.tone-info    { background: #38bdf8; }
```

```jsx
<StatCard label="Pending" value={12} tone="warning" />
```

### b. Icon Injection
Any icon component conforming to `{ size?: number }` can be supplied:

```jsx
import { Users } from "lucide-react";
<StatCard label="Active Users" value={1420} icon={Users} tone="success" />
```

### c. Rich Content via `ReactNode` Props
Because `value`, `label`, and `hint` accept `ReactNode`, callers can embed formatted or interactive content:

```jsx
<StatCard
  label={<span>Revenue <sup>USD</sup></span>}
  value={<strong>$42.3k</strong>}
  hint={<a href="/report">View report</a>}
/>
```

### d. Recommended Enhancement Patterns
- **Icon size customization**: Currently hardcoded to `size={20}`. To make configurable, add an `iconSize` prop defaulting to `20`.
- **Tone validation**: Introduce PropTypes or TypeScript typing to constrain `tone` to a known enum, improving safety.
- **Composition wrapper**: For clickable cards, wrap `StatCard` in a parent `<button>`/`<a>` rather than adding interaction logic here, preserving its presentational purity.

---

## Summary

`StatCard` is a deliberately minimal, stateless UI primitive that separates **content** (props), **structure** (JSX), and **presentation** (CSS classes). Its dependency-injection approach to icons and class-based theming make it a flexible, reusable building block for metric displays while keeping the component itself free of business logic and external coupling.