---
id: 74e58a8c-1b76-5dc1-b83e-88bf02ccb377
type: architecture
title: "0001 Initial Architecture"
created_at: 2026-07-30T17:20:56.166720+00:00
updated_at: 2026-07-30T17:20:56.166738+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  module_name: "backend.alembic.versions.0001_initial"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# 0001 Initial Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

# Architecture Document: Initial Schema Migration (`0001_initial`)

## 1. Component Overview

The `backend.alembic.versions.0001_initial` module is the **foundational database migration** for the application. As the first revision in the Alembic migration chain (`down_revision = None`), it establishes the baseline schema from which all subsequent migrations build.

### Responsibilities
- Create the core identity and access management (IAM) tables: `users`, `roles`, and `permissions`.
- Establish many-to-many relationships via two association tables: `user_roles` and `role_permissions`.
- Provide an `audit_log` table for tracking actor-driven actions across the system.
- Define supporting indexes for common query patterns.
- Provide a clean, order-safe `downgrade` path to reverse the schema creation.

This migration implements a classic **Role-Based Access Control (RBAC)** data model.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **RBAC via association tables** | Users connect to Roles (`user_roles`), and Roles connect to Permissions (`role_permissions`). This decouples permission grants from individual users, enabling scalable authorization management. |
| **Composite primary keys on association tables** | Prevents duplicate `(user_id, role_id)` and `(role_id, permission_id)` pairs at the database level, enforcing referential integrity without extra unique constraints. |
| **`server_default` for non-null string columns** | Ensures backward-compatible inserts and avoids null-handling complexity in the application layer (e.g., `full_name`, `status`, `description`). |
| **`status` default of `"invited"`** | Reflects an onboarding-oriented user lifecycle where users begin in a pending state before activation. |
| **Nullable `actor_id` in `audit_log`** | Supports system-generated events that have no human actor, and preserves audit records even if the referenced user is later handled specially. |
| **Indexes on `ix_users_username`, `ix_audit_log_action`, `ix_audit_log_created_at`** | Optimizes the most likely lookup patterns: user login by username and audit queries filtered/sorted by action or time. |
| **Reverse-order `downgrade`** | Tables are dropped in dependency-safe order (children before parents) to avoid foreign-key constraint violations. |

---

## 3. Component Diagram

### Migration Structure

```dot
digraph MigrationStructure {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_alembic {
        label="Alembic Framework";
        style=dashed;
        op   [label="alembic.op\n(operations proxy)"];
        env  [label="Migration Environment\n(env.py)"];
    }

    subgraph cluster_migration {
        label="0001_initial";
        style=dashed;
        upgrade   [label="upgrade()", shape=ellipse];
        downgrade [label="downgrade()", shape=ellipse];
        meta      [label="revision = 0001_initial\ndown_revision = None"];
    }

    db [label="Target Database", shape=cylinder];

    env -> upgrade   [label="apply"];
    env -> downgrade [label="rollback"];
    upgrade   -> op  [label="create_table / create_index"];
    downgrade -> op  [label="drop_table"];
    op -> db         [label="emit DDL"];
}
```

### Resulting Schema (Entity Relationships)

```dot
digraph Schema {
    rankdir=TB;
    node [shape=record, fontname="Helvetica"];

    users [label="{users|id (PK)\l username (UQ)\l email (UQ)\l full_name\l status\l created_at\l updated_at\l}"];
    roles [label="{roles|id (PK)\l name (UQ)\l description\l}"];
    permissions [label="{permissions|id (PK)\l name (UQ)\l description\l}"];

    user_roles [label="{user_roles|user_id (PK,FK)\l role_id (PK,FK)\l}"];
    role_permissions [label="{role_permissions|role_id (PK,FK)\l permission_id (PK,FK)\l}"];

    audit_log [label="{audit_log|id (PK)\l actor_id (FK, null)\l action\l target_type\l target_id\l detail\l created_at\l}"];

    user_roles -> users        [label="user_id"];
    user_roles -> roles        [label="role_id"];
    role_permissions -> roles       [label="role_id"];
    role_permissions -> permissions [label="permission_id"];
    audit_log -> users         [label="actor_id (nullable)"];
}
```

---

## 4. Interfaces

### Migration Contract (Alembic)
The module conforms to the standard Alembic revision interface:

| Symbol | Type | Purpose |
|--------|------|---------|
| `revision` | `str` | Unique identifier `"0001_initial"`. |
| `down_revision` | `None` | Marks this as the root migration. |
| `branch_labels` | `None` | No branching. |
| `depends_on` | `None` | No cross-branch dependencies. |
| `upgrade()` | function | Applies the schema (forward migration). |
| `downgrade()` | function | Reverses the schema (rollback). |

### Integration Points
- **`alembic.op`** — The operations proxy used to emit DDL (`create_table`, `create_index`, `drop_table`). This abstracts the underlying dialect-specific SQL.
- **`sqlalchemy` (`sa`)** — Provides column types (`Integer`, `String`, `DateTime`, `Text`) and constraint constructs (`ForeignKey`).
- **Alembic Migration Chain** — Downstream migrations reference this via their own `down_revision = "0001_initial"`.

---

## 5. Data Flow

This component operates at **deploy/migration time**, not request time.

```dot
digraph DataFlow {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    cli   [label="alembic CLI\n(upgrade head / downgrade)"];
    env   [label="env.py\ncontext + engine"];
    rev   [label="0001_initial\nupgrade()/downgrade()"];
    op    [label="op proxy"];
    dial  [label="SQLAlchemy Dialect\n(DDL compiler)"];
    db    [label="Database", shape=cylinder];

    cli -> env  [label="1. invoke"];
    env -> rev  [label="2. dispatch"];
    rev -> op   [label="3. table/index ops"];
    op  -> dial [label="4. compile DDL"];
    dial -> db  [label="5. execute SQL"];
}
```

**Upgrade path (order of creation):**
1. `users` (+ `ix_users_username`)
2. `roles`
3. `permissions`
4. `user_roles` (depends on `users`, `roles`)
5. `role_permissions` (depends on `roles`, `permissions`)
6. `audit_log` (+ `ix_audit_log_action`, `ix_audit_log_created_at`)

Parent tables are created before child (association/FK) tables to satisfy foreign-key constraints.

**Downgrade path (reverse order):**
`audit_log` → `role_permissions` → `user_roles` → `permissions` → `roles` → `users`

The reverse ordering guarantees dependent tables are dropped before the tables they reference.

---

## 6. Extension Points

Because this is a versioned migration, **the file itself is immutable once deployed** — Alembic migrations must never be edited after they have run in any shared environment. Extension follows these patterns:

### Adding New Schema Changes
Create a new migration file with `down_revision = "0001_initial"` (or the current head):
```python
revision = "0002_add_something"
down_revision = "0001_initial"
```

### Common Extension Scenarios
| Goal | Approach |
|------|----------|
| Add a column to `users` | New migration using `op.add_column("users", ...)`. |
| Introduce a new indexed lookup | New migration with `op.create_index(...)`. |
| Add cascading FK behavior | New migration to drop/recreate the FK with `ondelete`/`onupdate`. |
| Extend the audit model | Add columns via new migration; keep `actor_id` nullable to preserve system-event compatibility. |
| Enforce additional user status values | Handled in the application/domain layer or via a new `CHECK` constraint migration. |

### Customization Hooks in This Migration
- **`status` default (`"invited"`)** — Change the user lifecycle entry state through a follow-up migration altering the server default.
- **`target_type` default (`"user"`)** — The `audit_log` is designed to be polymorphic across target types; extend by writing new `target_type` values from the application without schema changes.

---

## Notes & Caveats
- **`created_at` / `updated_at` have no `server_default`** — timestamps are expected to be supplied by the application layer (e.g., ORM defaults or service code), not the database.
- **No `ON DELETE` behavior is specified** on foreign keys — deletion of referenced rows (e.g., a `user`) will be restricted or must be handled explicitly by the application/subsequent migrations.
- **`audit_log.actor_id` is nullable** — code consuming audit records must handle absent actors gracefully.