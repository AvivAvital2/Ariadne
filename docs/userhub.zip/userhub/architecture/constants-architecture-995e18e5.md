---
id: 995e18e5-bdc6-5650-9961-9523d7d995de
type: architecture
title: "Constants Architecture"
created_at: 2026-07-30T17:30:12.815742+00:00
updated_at: 2026-07-30T17:30:12.815757+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js
metadata:
  module_name: "frontend.src.constants"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js`

# Architecture Document: `frontend.src.constants`

## 1. Component Overview

The `frontend.src.constants` module is a **contract definition layer** for the frontend application. Its sole responsibility is to centralize the string literals that the frontend and backend agree upon across the HTTP boundary.

It exposes three constant groups:

| Export | Purpose |
|--------|---------|
| `USER_STATUS` | Enumerates the lifecycle states a user account can occupy (`active`, `invited`, `deactivated`). |
| `PERMISSIONS` | Enumerates the permission scopes used for authorization checks (e.g. `users:read`, `roles:manage`). |
| `AUDIT_ACTION_LABELS` | Maps backend audit action codes to human-readable labels for display in the audit view. |

The module contains **no logic** — it is a pure data/contract module with zero runtime dependencies. Its value lies in eliminating magic strings scattered throughout the codebase and providing a single point of truth for values shared with the backend.

---

## 2. Design Decisions

### 2.1 Convention-based cross-boundary contract
The most important design decision is documented directly in the source header: there is **no shared type system** across the HTTP boundary. The frontend `constants.js` and the backend `app/constants.py` must be kept in sync **by convention**. Both sides agree on the exact string values (e.g. `"deactivated"`, `"users:deactivate"`, `"user.deactivated"`).

**Rationale:** A common pattern in polyglot stacks (JavaScript frontend + Python backend). Rather than generating shared types via a code-gen pipeline or an IDL (e.g. OpenAPI/Protobuf), the team opted for the simplest possible approach — mirrored constant files. This trades automated safety for zero build tooling overhead.

**Trade-off / risk:** Drift between the two files is possible if only one side is updated. This is a deliberate accepted risk, mitigated by discipline and the explicit warning comment.

### 2.2 Separation of concerns per domain
Each concern (status, permissions, audit labels) is a distinct named export rather than a single monolithic object. This keeps import surfaces narrow and makes tree-shaking / usage tracing easier.

### 2.3 Presentation mapping kept alongside contract values
`AUDIT_ACTION_LABELS` mixes a contract concern (the backend action keys) with a presentation concern (the display labels). This is a pragmatic choice: keeping the key→label mapping next to the authoritative key list reduces the chance of a label referencing a stale action key.

---

## 3. Component Diagram

```dot
digraph constants {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_frontend {
        label="Frontend";
        style=dashed;
        color="#4a90d9";

        constants [label="frontend.src.constants\n(USER_STATUS,\nPERMISSIONS,\nAUDIT_ACTION_LABELS)", style="rounded,filled", fillcolor="#e8f0fe"];
        ui [label="UI Components\n(user views, guards, audit view)"];
        api_client [label="API Client\n(HTTP requests)"];

        constants -> ui   [label="imports"];
        constants -> api_client [label="imports"];
    }

    subgraph cluster_backend {
        label="Backend";
        style=dashed;
        color="#7ba05b";

        py_constants [label="app/constants.py\n(mirrored values)", style="rounded,filled", fillcolor="#eef7e8"];
    }

    api_client -> py_constants [label="HTTP\n(string values on the wire)", style=dashed];
    constants  -> py_constants [label="MUST match\n(by convention)", style=dotted, color="red", dir=both, constraint=false];
}
```

**Legend:**
- **Solid arrows** — compile-time `import` relationships within the frontend.
- **Dashed arrow** — runtime HTTP data flow carrying the string values.
- **Red dotted arrow** — the manual synchronization contract between the two files.

---

## 4. Interfaces

This module exposes a **static ES module interface** — three named exports. There is no runtime API, protocol handler, or lifecycle.

### 4.1 Exported constants

```javascript
import { USER_STATUS, PERMISSIONS, AUDIT_ACTION_LABELS } from "./constants";
```

| Export | Type | Shape |
|--------|------|-------|
| `USER_STATUS` | `object` (frozen-by-convention enum) | `{ ACTIVE, INVITED, DEACTIVATED }` → status strings |
| `PERMISSIONS` | `object` (enum) | `{ USERS_READ, ..., AUDIT_READ }` → scope strings |
| `AUDIT_ACTION_LABELS` | `object` (lookup map) | action-key string → display-label string |

### 4.2 Integration points

1. **Backend HTTP contract** — The string *values* (not the JS key names) are the integration surface. Any consumer serializing or deserializing user status, checking permissions, or rendering audit actions relies on these values matching what the backend emits/expects.

2. **Backend counterpart file** — `app/constants.py` is the authoritative sibling. Changes here **must** be replicated there and vice versa.

3. **Frontend consumers** — UI components (permission guards, status badges, audit views) import these constants instead of hard-coding strings.

---

## 5. Data Flow

The module participates in a request/response cycle as the shared vocabulary:

```dot
digraph dataflow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    backend   [label="Backend response\n{ status: \"deactivated\",\n  permissions: [\"users:edit\"] }"];
    apiclient [label="API Client"];
    consts    [label="constants module\n(value comparison / label lookup)", style="rounded,filled", fillcolor="#e8f0fe"];
    view      [label="UI View\n(renders status badge,\n applies permission guard,\n shows audit label)"];

    backend   -> apiclient [label="HTTP response (raw strings)"];
    apiclient -> view      [label="parsed data"];
    consts    -> view      [label="reference values / labels"];
    view      -> consts    [label="e.g. status === USER_STATUS.DEACTIVATED", style=dotted];
}
```

**Flow narrative:**
1. The backend emits raw string values (`"deactivated"`, `"users:edit"`, `"user.reactivated"`) in HTTP responses.
2. Frontend code compares/consumes those values against the constants (e.g. `user.status === USER_STATUS.DEACTIVATED`).
3. For audit records, `AUDIT_ACTION_LABELS[action]` translates the wire value into a display string.
4. Outbound requests (e.g. a deactivate action) send permission/status values that also originate from these constants.

The module itself is **read-only and stateless** — data flows *through* consumers that reference it, never through the module directly.

---

## 6. Extension Points

### 6.1 Adding a new user status
1. Add the value to `USER_STATUS`.
2. **Mirror the change** in `app/constants.py`.
3. Update any status-rendering UI to handle the new state.

### 6.2 Adding a new permission scope
1. Add the `RESOURCE_ACTION: "resource:action"` entry to `PERMISSIONS`.
2. Mirror in the backend permission definitions.
3. Wire the scope into the relevant permission guard(s).

### 6.3 Adding a new audit action
1. Add the backend action key + human label to `AUDIT_ACTION_LABELS`.
2. Ensure the backend `AuditAction` enum emits the same key.
3. No UI change needed if the audit view already does a generic `AUDIT_ACTION_LABELS[action]` lookup.

### 6.4 Recommended hardening (customization hooks)
The current implementation exposes plain mutable objects. Extension safety can be improved without changing the public shape:

- **Freeze the exports** with `Object.freeze(...)` to prevent accidental runtime mutation.
- **Introduce a contract test** that asserts parity between the frontend constants and the backend `app/constants.py` (e.g. via a generated JSON fixture from the backend), converting the "keep in sync by convention" risk into an automated check.
- **Fallback label handling** — consumers of `AUDIT_ACTION_LABELS` should default to the raw action key when a label is missing, so new backend actions degrade gracefully rather than rendering `undefined`.

---

## Maintenance Note

> ⚠️ **This module is one half of a two-file contract.** Every string value here is coupled to `app/constants.py`. When editing either file, update both in the same change set and, where possible, verify parity with an automated test.