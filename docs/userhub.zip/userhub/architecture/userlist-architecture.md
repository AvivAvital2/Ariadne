---
id: 0eaa361a-4b0f-5221-9834-4758e7afef6e
type: architecture
title: "Userlist Architecture"
created_at: 2026-07-30T17:29:15.883108+00:00
updated_at: 2026-07-30T17:29:15.883122+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx
metadata:
  module_name: "frontend.src.components.UserList"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userlist Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx`

# UserList Component Architecture

**Module**: `frontend.src.components.UserList`

---

## 1. Component Overview

`UserList` is a React presentational-container component responsible for rendering and managing the administrative view of all users in the system. It serves as the primary CRUD entry point for user management, coordinating between:

- **Data retrieval** from the backend API
- **Permission-gated UI** rendering based on the current `actor`
- **User lifecycle operations** (create, edit, deactivate/reactivate, delete)
- **Modal editing** delegated to the `UserForm` child component

The component is designed to be self-contained: it owns its data-loading lifecycle, error state, and edit-mode state, requiring only an `actor` prop to determine permissions.

### Core Responsibilities

| Responsibility | Description |
|----------------|-------------|
| Data loading | Fetches the user list on mount and after mutations |
| Permission enforcement | Conditionally renders action controls based on `actor` permissions |
| Action orchestration | Runs mutations and refreshes the list via `runAction` |
| Error surfacing | Captures and displays operation errors inline |
| Edit delegation | Hands off create/edit workflows to `UserForm` |

---

## 2. Design Decisions

### 2.1 Client-Side Permission Gating
Permissions are resolved once per render via `hasPermission(actor, ...)` and cached in local booleans (`canCreate`, `canEdit`, etc.). This keeps the JSX readable and centralizes permission logic near the top of the component.

> **Note**: This is a UX affordance, not a security boundary. The backend API remains the authoritative enforcement point; hiding a button does not prevent a crafted request.

### 2.2 Optimistic-Free Refresh Pattern
Rather than mutating local state after each operation, the component follows a **"mutate then reload"** pattern via `runAction`. Every mutation is followed by a full `load()` call. This trades a bit of network efficiency for guaranteed consistency with server state — appropriate for a low-frequency admin screen.

### 2.3 Tri-State Edit Model
The `editing` state uses a single variable with three meanings:
- `null` — no modal open
- `"new"` — create mode (no existing user)
- `<user object>` — edit mode

This collapses two boolean states (`isOpen`, `isCreating`) into one variable, simplifying conditional rendering while remaining explicit.

### 2.4 Centralized Error Handling
A single `error` state and `runAction` wrapper ensure all mutation errors are surfaced uniformly. Errors are cleared at the start of each action to avoid stale messages.

### 2.5 Thin API Layer Boundary
All backend interaction is routed through the `api/client.js` module, decoupling the component from transport concerns (URLs, HTTP method, serialization).

---

## 3. Component Diagram

```dot
digraph UserList {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_component {
        label="UserList Component";
        style=dashed;
        color=gray;

        UserList [label="UserList\n(actor prop)", style="rounded,filled", fillcolor="#e3f2fd"];
        state_users   [label="state: users[]", shape=ellipse, fillcolor="#fff3e0", style=filled];
        state_editing [label="state: editing\n(null | 'new' | user)", shape=ellipse, fillcolor="#fff3e0", style=filled];
        state_error   [label="state: error", shape=ellipse, fillcolor="#fff3e0", style=filled];
        load          [label="load()", shape=box, fillcolor="#f1f8e9", style=filled];
        runAction     [label="runAction(fn)", shape=box, fillcolor="#f1f8e9", style=filled];

        UserList -> state_users;
        UserList -> state_editing;
        UserList -> state_error;
        UserList -> load;
        UserList -> runAction;
        runAction -> load [label="on success", style=dotted];
    }

    // External dependencies
    apiClient   [label="api/client.js\n(listUsers, deactivateUser,\nreactivateUser, deleteUser)", fillcolor="#ede7f6", style=filled];
    permissions [label="auth/permissions.js\n(hasPermission)", fillcolor="#ede7f6", style=filled];
    constants   [label="constants.js\n(PERMISSIONS, USER_STATUS)", fillcolor="#ede7f6", style=filled];
    icons       [label="Icons.jsx\n(IconPlus)", fillcolor="#ede7f6", style=filled];
    userForm    [label="UserForm.jsx", style="rounded,filled", fillcolor="#e8f5e9"];
    backend     [label="Backend API", shape=cylinder, fillcolor="#ffebee", style=filled];

    load      -> apiClient [label="listUsers()"];
    runAction -> apiClient [label="mutations"];
    apiClient -> backend   [label="HTTP"];
    UserList  -> permissions [label="hasPermission()"];
    UserList  -> constants   [label="reads"];
    UserList  -> icons       [label="renders"];
    UserList  -> userForm    [label="renders modal\n(user, onClose, onSaved)"];
    userForm  -> UserList    [label="onSaved → load()", style=dashed];
}
```

---

## 4. Interfaces

### 4.1 Props (Inbound)

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `actor` | `User` object | Yes | The currently authenticated user, used to evaluate permissions |

### 4.2 API Client Integration

The component consumes the following functions from `../api/client.js`:

| Function | Purpose | Trigger |
|----------|---------|---------|
| `listUsers()` | Fetch all users | Mount + after every mutation |
| `deactivateUser(id)` | Deactivate a user | "Deactivate" action |
| `reactivateUser(id)` | Reactivate a user | "Reactivate" action |
| `deleteUser(id)` | Permanently delete a user | "Delete" action |

All functions are expected to return Promises; rejections propagate a `.message` property for display.

### 4.3 Permission Interface

```
hasPermission(actor, permission) → boolean
```

Evaluated against these `PERMISSIONS` constants:
`USERS_CREATE`, `USERS_EDIT`, `USERS_DEACTIVATE`, `USERS_DELETE`

### 4.4 Child Component Contract — `UserForm`

| Prop | Type | Description |
|------|------|-------------|
| `user` | `User \| null` | `null` for create, user object for edit |
| `onClose` | `() => void` | Closes the modal without reload |
| `onSaved` | `() => void` | Closes the modal and triggers a reload |

### 4.5 Data Model (User)

The component reads the following user fields:
`id`, `username`, `full_name`, `email`, `status`, `roles[].name`

---

## 5. Data Flow

### 5.1 Initial Load
```
Mount → useEffect → load() → api.listUsers()
     → setUsers(data)   [success]
     → setError(msg)    [failure]
```

### 5.2 Mutation Flow (Deactivate / Reactivate / Delete)
```
Button click → runAction(fn)
     ├─ setError(null)          (clear prior error)
     ├─ await fn()              (api mutation)
     ├─ await load()            (refresh list)
     └─ catch → setError(msg)   (surface failure)
```

### 5.3 Create / Edit Flow
```
"New user"  → setEditing("new")  ──┐
"Edit" btn  → setEditing(user)   ──┤
                                    ▼
                              <UserForm> renders
                                    │
        ┌──── onClose ──────────────┤
        │  setEditing(null)         │
        │                           │
        └──── onSaved ──────────────┘
           setEditing(null) + load()
```

### 5.4 State Transition Summary

```dot
digraph editingState {
    rankdir=LR;
    node [shape=circle, fontname="Helvetica"];

    null   [label="null\n(closed)"];
    new    [label="'new'\n(create)"];
    edit   [label="user\n(edit)"];

    null -> new  [label="New user"];
    null -> edit [label="Edit"];
    new  -> null [label="onClose /\nonSaved"];
    edit -> null [label="onClose /\nonSaved"];
}
```

---

## 6. Extension Points

### 6.1 Adding New Row Actions
New per-user actions follow the established pattern:
1. Add a permission constant to `PERMISSIONS`.
2. Add an API function to `api/client.js`.
3. Gate the button with `hasPermission(actor, ...)`.
4. Wrap the call in `runAction()` for automatic error handling and refresh.

```jsx
{canResetPassword && (
  <button className="btn ghost sm"
          onClick={() => runAction(() => api.resetPassword(user.id))}>
    Reset password
  </button>
)}
```

### 6.2 Customizing Columns
The table structure is declaratively defined in `<thead>`/`<tbody>`. New columns are added by extending both the header row and the mapped row cells. Consider extracting the row rendering into a `<UserRow>` subcomponent if column logic grows.

### 6.3 Replacing the Edit Experience
The `UserForm` contract (`user`, `onClose`, `onSaved`) is stable. An alternative editor (e.g., a drawer or full-page route) can be swapped in without changing `UserList`'s state management, as long as it honors the same three-prop contract.

### 6.4 Data Source Substitution
Because all data access flows through `api/client.js`, the backend can be swapped (e.g., GraphQL, mocked in tests) without touching the component, provided the returned shape and Promise semantics are preserved.

### 6.5 Recommended Refactors for Scale
| Concern | Suggested Extension |
|---------|---------------------|
| Large user lists | Introduce pagination / virtualization in `load()` |
| Repeated fetch logic | Extract a `useUsers()` hook wrapping `load`, `users`, `error` |
| Row complexity | Extract `<UserRow>` presentational component |
| Optimistic UX | Replace "mutate-then-reload" with local state patching where latency matters |

---

## Appendix: Terminology

| Term | Meaning |
|------|---------|
| **actor** | The authenticated user performing actions in the UI |
| **runAction** | The mutation wrapper providing error handling + auto-refresh |
| **editing** | Tri-state variable controlling the create/edit modal |
| **mutate-then-reload** | The consistency pattern of refetching after every mutation |