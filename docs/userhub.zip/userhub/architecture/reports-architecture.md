---
id: 0eb4c2d0-1ab8-5a59-a7dc-30a161f5b220
type: architecture
title: "Reports Architecture"
created_at: 2026-07-30T17:23:16.595068+00:00
updated_at: 2026-07-30T17:23:16.595083+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  module_name: "backend.app.routers.reports"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Reports Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

# Architecture Documentation: `backend.app.routers.reports`

## 1. Component Overview

The `reports` router exposes read-only reporting endpoints under the `/api/reports` path prefix. Unlike the application's CRUD routers, which operate through the SQLAlchemy ORM, this component executes **hand-written SQL** directly against the underlying tables (`users` and `audit_log`).

**Primary responsibilities:**
- Serve aggregated, cross-table reporting data that is awkward or inefficient to express through the ORM.
- Enforce access control on sensitive audit-derived data.
- Map raw SQL result rows onto typed response schemas.

Currently the component contains a single endpoint, `user_activity`, which returns per-user activity derived by joining user records against the audit log.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Raw SQL over ORM** | Reporting queries frequently involve joins, aggregations, and window functions that map poorly to ORM entity graphs. A curated SQL statement (`USER_ACTIVITY_SQL`) is clearer, more performant, and easier to tune than an equivalent ORM expression. |
| **SQL stored in `app.reports.queries`** | Query text is isolated in a dedicated module rather than inlined in the router. This keeps handlers thin, makes SQL reviewable/testable in isolation, and allows queries to be shared or version-controlled independently of endpoint logic. |
| **Typed response via `UserActivityRow`** | Even though rows come from raw SQL (untyped `RowMapping` objects), each row is validated and coerced through a Pydantic schema. This preserves a stable, self-documenting API contract and shields consumers from raw column naming. |
| **Permission-gated access** | The endpoint requires `Permission.AUDIT_READ`. Reporting data is derived from the audit log, which is sensitive; access control is applied at the route boundary. |
| **`mappings().all()` result form** | Retrieving results as dict-like mappings allows straightforward `**row` unpacking into the schema, decoupling the handler from positional column ordering. |

---

## 3. Component Diagram

```dot
digraph reports_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_router {
        label="app.routers.reports";
        style=dashed;
        endpoint [label="user_activity()\nGET /api/reports/user-activity"];
    }

    subgraph cluster_deps {
        label="Injected Dependencies";
        style=dotted;
        get_db      [label="get_db\n(Session provider)"];
        require_perm [label="require_permission\n(AUDIT_READ)"];
    }

    subgraph cluster_support {
        label="Supporting Modules";
        style=dotted;
        query   [label="reports.queries\nUSER_ACTIVITY_SQL"];
        schema  [label="schemas.UserActivityRow"];
        perm    [label="constants.Permission"];
    }

    db      [label="Database\n(users, audit_log)", shape=cylinder];

    endpoint -> get_db        [label="Depends"];
    endpoint -> require_perm  [label="Depends"];
    endpoint -> query         [label="reads SQL"];
    endpoint -> schema        [label="serializes rows"];
    require_perm -> perm      [label="checks"];
    get_db -> db              [label="provides Session"];
    endpoint -> db            [label="execute(text(SQL))"];
}
```

---

## 4. Interfaces

### HTTP Endpoint

| Attribute | Value |
|-----------|-------|
| Method | `GET` |
| Path | `/api/reports/user-activity` |
| Tags | `reports` |
| Auth | Requires `Permission.AUDIT_READ` |
| Response Model | `list[UserActivityRow]` |

### Dependency Contracts (FastAPI `Depends`)

- **`get_db`** → yields a SQLAlchemy `Session`. Lifecycle (open/close) is managed by the provider.
- **`require_permission(Permission.AUDIT_READ.value)`** → resolves to the authenticated `User` (the `actor`) only if the permission check passes; otherwise short-circuits with an authorization error before the handler body executes.

### Internal Contracts

- **`USER_ACTIVITY_SQL`** (`app.reports.queries`) — a SQL string whose selected column names must align with the fields of `UserActivityRow`.
- **`UserActivityRow`** (`app.schemas`) — the Pydantic model defining the public shape of each returned row. This is the **coupling contract**: SQL column aliases and schema field names must remain in sync.

---

## 5. Data Flow

```dot
digraph reports_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    client   [label="HTTP Client"];
    auth     [label="require_permission\n(AUDIT_READ check)"];
    handler  [label="user_activity()"];
    session  [label="DB Session\n(get_db)"];
    sql      [label="USER_ACTIVITY_SQL"];
    dbnode   [label="Database", shape=cylinder];
    mapper   [label="UserActivityRow\nvalidation"];

    client  -> auth      [label="1. GET request"];
    auth    -> handler   [label="2. authorized actor"];
    handler -> sql       [label="3. load SQL text"];
    handler -> session   [label="4. execute(text(SQL))"];
    session -> dbnode    [label="5. run query"];
    dbnode  -> session   [label="6. result rows"];
    session -> handler   [label="7. .mappings().all()"];
    handler -> mapper    [label="8. **row -> schema"];
    mapper  -> client    [label="9. JSON list response"];
}
```

**Step-by-step:**
1. A client issues `GET /api/reports/user-activity`.
2. `require_permission` verifies the caller holds `AUDIT_READ`; on failure the request is rejected before any query runs.
3. The handler references the static `USER_ACTIVITY_SQL` statement.
4–7. The injected `Session` executes the raw SQL and returns rows as dict-like `RowMapping` objects.
8. Each mapping is unpacked (`**row`) into a `UserActivityRow` instance, applying validation and type coercion.
9. FastAPI serializes the list of schema instances to a JSON response.

---

## 6. Extension Points

### Adding a new report
1. Define the SQL statement in `app.reports.queries` (e.g., `LOGIN_HISTORY_SQL`).
2. Define a matching response schema in `app.schemas` (e.g., `LoginHistoryRow`), ensuring field names match the SQL column aliases.
3. Add a new handler on `router` following the established pattern:
   ```python
   @router.get("/api/reports/login-history", response_model=list[LoginHistoryRow])
   def login_history(db=Depends(get_db),
                     actor=Depends(require_permission(Permission.AUDIT_READ.value))):
       rows = db.execute(text(LOGIN_HISTORY_SQL)).mappings().all()
       return [LoginHistoryRow(**row) for row in rows]
   ```

### Customization hooks
- **Access control** — swap the permission passed to `require_permission` to scope each report to a different capability (e.g., `REPORTS_READ` vs `AUDIT_READ`).
- **Parameterization** — extend handlers to accept query/path parameters and bind them safely using SQLAlchemy `text(...).bindparams()` or `execute(text(SQL), {...})`. **Avoid string interpolation** into SQL to prevent injection.
- **Result shaping** — introduce post-processing between the SQL result and schema mapping (e.g., aggregation, enrichment) for reports that require computed fields not expressible in SQL.

### Boundaries to preserve
- Keep SQL text in `app.reports.queries`, not inline in handlers.
- Keep the SQL column set and the response schema fields synchronized; this is the most fragile coupling in the component and the most likely source of runtime errors when either side changes.
- Continue routing all reporting reads through this module rather than the ORM CRUD layer, to preserve the intended separation between transactional and analytical access paths.