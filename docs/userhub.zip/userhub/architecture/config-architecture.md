---
id: 70a088a9-e52a-5d9d-95e4-815738f03da3
type: architecture
title: "Config Architecture"
created_at: 2026-07-30T17:31:05.917121+00:00
updated_at: 2026-07-30T17:31:05.917136+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js
metadata:
  module_name: "frontend.vite.config"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Config Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js`

# Architecture Documentation: `frontend.vite.config`

## 1. Component Overview

The `vite.config.js` module defines the build and development-server configuration for the frontend React application. It is the single source of truth for how the Vite toolchain compiles, serves, and integrates the frontend with backend services during local development.

Its primary responsibilities are:

- **Plugin registration** — enables React support (JSX transform, Fast Refresh) via `@vitejs/plugin-react`.
- **Dev server configuration** — fixes the local development port to `5173`.
- **Backend integration** — proxies API requests from the frontend origin to the FastAPI backend, enabling a same-origin request model during development.

This configuration only affects the **development environment** and the **build pipeline**. It does not participate in production request routing (which is typically handled by a reverse proxy or static hosting layer).

---

## 2. Design Decisions

### 2.1 Same-Origin API Model via Proxy
The frontend issues **relative** URLs (e.g., `/api/users/{id}/status`) rather than absolute URLs pointing at `http://127.0.0.1:8000`. The dev-server proxy rewrites these to the backend transparently.

**Rationale:**
- Eliminates CORS complexity in development — requests appear same-origin.
- Frontend code remains environment-agnostic; the same relative paths work in production behind a reverse proxy without code changes.
- Route templates on the frontend map 1:1 onto FastAPI route templates.

### 2.2 Explicit `127.0.0.1` Instead of `localhost`
The proxy target is hard-coded to `http://127.0.0.1:8000`.

**Rationale (documented inline):**
`localhost` may resolve to IPv6 (`::1`) on some systems. The IPv4-only backend refuses IPv6 connections, causing a slow connection-fallback penalty on **every request**. Forcing IPv4 avoids this latency.

### 2.3 Fixed Dev Port (`5173`)
Pinning the port produces a stable, predictable local URL, which simplifies documentation, tooling integration, and any backend CORS/CSRF allow-lists.

---

## 3. Component Diagram

```dot
digraph vite_config {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_config {
    label = "vite.config.js";
    style = dashed;
    color = gray;

    react_plugin [label="@vitejs/plugin-react\n(JSX / Fast Refresh)"];
    server_cfg   [label="server\nport: 5173"];
    proxy_cfg    [label="proxy rule\n/api → 127.0.0.1:8000"];
  }

  browser  [label="Browser\n(React App)", shape=component];
  devserver [label="Vite Dev Server\n:5173", shape=component];
  backend  [label="FastAPI Backend\n127.0.0.1:8000", shape=component];

  react_plugin -> devserver [label="configures", style=dotted];
  server_cfg   -> devserver [label="configures", style=dotted];
  proxy_cfg    -> devserver [label="configures", style=dotted];

  browser  -> devserver [label="GET /api/... (relative)"];
  devserver -> backend  [label="proxied GET\nhttp://127.0.0.1:8000/api/..."];
  backend  -> devserver [label="response"];
  devserver -> browser  [label="response"];
}
```

---

## 4. Interfaces

### 4.1 Exported Configuration
| Interface | Type | Description |
|-----------|------|-------------|
| `default export` | `UserConfig` (via `defineConfig`) | The Vite configuration object consumed by the Vite CLI at build/serve time. |

### 4.2 Integration Points
| Point | Value | Protocol | Notes |
|-------|-------|----------|-------|
| Dev server bind | `:5173` | HTTP | The origin served to the browser. |
| Proxy match prefix | `/api` | HTTP | All matching paths are forwarded. |
| Backend target | `http://127.0.0.1:8000` | HTTP (IPv4) | FastAPI service; path is preserved (no rewrite). |

### 4.3 Path Contract
Because no path rewrite is configured, the frontend `/api/*` path segment **must** match the backend's route prefix exactly. Any change to the backend's route prefix requires a corresponding change here (or in frontend request paths).

---

## 5. Data Flow

```dot
digraph data_flow {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  a [label="1. React component\nfetch('/api/users/42/status')"];
  b [label="2. Browser resolves to\nhttp://localhost:5173/api/..."];
  c [label="3. Vite dev server\nmatches '/api' proxy rule"];
  d [label="4. Forward to\nhttp://127.0.0.1:8000/api/users/42/status"];
  e [label="5. FastAPI route handler\nprocesses request"];
  f [label="6. Response streamed back\nthrough proxy to browser"];

  a -> b -> c -> d -> e -> f;
}
```

**Summary:**
1. Application code makes a same-origin relative request.
2. The request hits the Vite dev server on port `5173`.
3. Paths beginning with `/api` are matched by the proxy rule.
4. Vite forwards the request to the FastAPI backend over IPv4, preserving the full path.
5. The backend processes the request and returns a response.
6. Vite pipes the response back to the browser transparently.

Requests **not** matching `/api` are served by Vite itself (static assets, module bundles, HMR).

---

## 6. Extension Points

### 6.1 Adding New Proxy Routes
Add additional keys to the `server.proxy` object for other backend prefixes:

```javascript
proxy: {
  "/api": "http://127.0.0.1:8000",
  "/ws":  { target: "ws://127.0.0.1:8000", ws: true }, // WebSocket support
}
```

### 6.2 Path Rewriting
If frontend and backend prefixes diverge, use the object form with `rewrite`:

```javascript
"/api": {
  target: "http://127.0.0.1:8000",
  rewrite: (path) => path.replace(/^\/api/, ""),
}
```

### 6.3 Environment-Driven Configuration
To parameterize the backend target across environments, switch to the function form of `defineConfig`:

```javascript
export default defineConfig(({ mode }) => ({
  plugins: [react()],
  server: {
    port: Number(process.env.VITE_DEV_PORT) || 5173,
    proxy: {
      "/api": process.env.VITE_API_TARGET || "http://127.0.0.1:8000",
    },
  },
}));
```

### 6.4 Additional Plugins
Register further Vite plugins (e.g., SVG, testing, PWA) by appending to the `plugins` array. Order can matter — consult individual plugin docs.

### 6.5 Build Configuration
Currently only dev-server behavior is configured. Production output can be tuned by adding a `build` block (`outDir`, `sourcemap`, `rollupOptions`, chunking strategy) as the project matures.

---

## Maintenance Notes

- **Do not replace `127.0.0.1` with `localhost`** — this reintroduces the IPv6 fallback latency described in Section 2.2.
- Keep the `/api` prefix synchronized with the backend's FastAPI route prefix; there is an implicit contract with no rewrite layer to absorb drift.
- This file governs development only; verify that production routing (reverse proxy / CDN) mirrors the `/api → backend` mapping to preserve the same-origin contract.