---
id: 43cf24ed-7501-5a18-a4d3-f545821ad0e5
type: architecture
title: "Audit Architecture"
created_at: 2026-07-30T17:23:10.212400+00:00
updated_at: 2026-07-30T17:23:10.212415+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  module_name: "backend.app.routers.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

# Architecture Documentation: Audit Router

**Module:** `backend.app.routers.audit`
**Endpoint Prefix:** `/api/audit`

---

## 1. Component Overview

The Audit Router is a thin HTTP presentation layer that exposes read-only access to the system's audit log. Its sole responsibility is to translate authenticated HTTP requests into calls against the audit service and serialize the results back to clients.

**Responsibilities:**
- Expose the `GET /api/audit` endpoint.
- Enforce authorization via the `AUDIT_READ` permission.
- Accept optional filtering (`action`) and pagination (`limit`) parameters.
- Delegate all business logic to the `audit` service.
- Serialize results through the `AuditLogOut` schema.

**Explicit non-responsibilities:**
- Persisting or querying audit records directly (handled by `audit_service`).
- Managing database session lifecycle (handled by `get_db`).
- Implementing authentication/authorization logic (handled by `security.require_permission`).

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Thin router / fat service** | The router contains no business logic; it only wires HTTP concerns to `audit_service.list_entries`. This keeps the endpoint testable and lets audit logic be reused outside HTTP contexts. |
| **Dependency injection for DB and auth** | `Depends(get_db)` and `Depends(require_permission(...))` decouple the endpoint from session management and security enforcement, following FastAPI's DI conventions. |
| **Permission gate via `require_permission`** | Audit logs are sensitive; access is guarded by the `AUDIT_READ` permission rather than mere authentication. The dependency both authenticates and authorizes, resolving to the acting `User`. |
| **Read-only interface** | Only `GET` is exposed — audit records are immutable from the API surface, preserving log integrity. |
| **Server-side default `limit=100`** | Prevents unbounded result sets by default while allowing callers to adjust. |
| **`response_model=list[AuditLogOut]`** | Enforces output contract and hides internal ORM model fields from clients. |

---

## 3. Component Diagram

```dot
digraph AuditRouter {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    Client [label="HTTP Client", shape=ellipse];

    subgraph cluster_router {
        label="app.routers.audit";
        style=dashed;
        Router [label="APIRouter\n(tags=['audit'])"];
        ListAudit [label="list_audit()\nGET /api/audit"];
    }

    subgraph cluster_deps {
        label="Injected Dependencies";
        style=dashed;
        GetDB [label="get_db\n(Session)"];
        RequirePerm [label="require_permission\n(AUDIT_READ)"];
    }

    subgraph cluster_service {
        label="Service Layer";
        style=dashed;
        AuditService [label="audit_service\n.list_entries()"];
    }

    Schema [label="AuditLogOut\n(schema)"];
    DB [label="Database", shape=cylinder];

    Client -> Router -> ListAudit;
    ListAudit -> GetDB [label="Depends"];
    ListAudit -> RequirePerm [label="Depends"];
    ListAudit -> AuditService [label="delegate\n(db, action, limit)"];
    AuditService -> DB [label="query"];
    ListAudit -> Schema [label="serialize"];
    Schema -> Client [label="list[AuditLogOut]"];
    RequirePerm -> DB [label="lookup user/perms"];
}
```

---

## 4. Interfaces

### HTTP Interface

```
GET /api/audit
```

**Query Parameters:**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `action` | `str \| None` | `None` | Optional filter matching an audit action string. |
| `limit` | `int` | `100` | Maximum number of entries to return. |

**Authorization:** Requires the `AUDIT_READ` permission (`Permission.AUDIT_READ`).

**Response:** `200 OK` with body `list[AuditLogOut]`.

### Internal Integration Points

| Dependency | Source | Purpose |
|------------|--------|---------|
| `get_db` | `app.database` | Provides a scoped SQLAlchemy `Session`. |
| `require_permission(...)` | `app.security` | Authenticates the request and enforces `AUDIT_READ`; yields the acting `User`. |
| `audit_service.list_entries` | `app.services.audit` | Retrieves audit records. Contract: `list_entries(db, action=..., limit=...)`. |
| `AuditLogOut` | `app.schemas` | Output serialization contract. |
| `Permission.AUDIT_READ` | `app.constants` | Enum value naming the required permission. |

---

## 5. Data Flow

1. **Request arrival** — A client issues `GET /api/audit` with optional `action` and `limit` query parameters.
2. **Dependency resolution** — FastAPI resolves:
   - `get_db` → an active `Session`.
   - `require_permission(AUDIT_READ)` → validates the caller and returns the `User` (`actor`). If the permission check fails, the request is rejected before the handler body executes.
3. **Delegation** — `list_audit` calls `audit_service.list_entries(db, action=action, limit=limit)`.
4. **Data retrieval** — The service queries the audit store via the session, applying the optional action filter and limit.
5. **Serialization** — Results are validated/serialized against `list[AuditLogOut]`.
6. **Response** — The serialized list is returned to the client.

```dot
digraph DataFlow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    A [label="1. GET /api/audit\n(action?, limit)"];
    B [label="2. Resolve get_db\n+ require_permission"];
    C [label="3. list_audit handler"];
    D [label="4. audit_service.list_entries"];
    E [label="5. Serialize to\nlist[AuditLogOut]"];
    F [label="6. HTTP 200 response"];

    A -> B -> C -> D -> E -> F;
    B -> X [label="permission denied", style=dashed];
    X [label="403 / 401", shape=box, style="rounded,dashed"];
}
```

---

## 6. Extension Points

- **Additional filters:** Extend the handler signature with new query parameters (e.g., `actor_id`, `date_from`) and pass them through to `audit_service.list_entries`. Keep filtering logic in the service, not the router.
- **New output fields:** Modify `AuditLogOut` in `app.schemas`. The router requires no change as long as the service returns compatible objects.
- **Alternative authorization:** Swap the permission by changing `Permission.AUDIT_READ` to a different value, or compose additional dependencies (e.g., tenant scoping) via more `Depends(...)` parameters.
- **Pagination strategy:** Replace the simple `limit` with cursor- or offset-based pagination by evolving the service contract and adding parameters here.
- **New endpoints:** Register further audit-related routes (e.g., single-entry lookup) on the same `router` to keep them grouped under the `audit` tag.

**Extension guardrails:**
- Preserve the read-only nature — do not add mutating endpoints that alter audit history.
- Keep the router thin; business logic and query composition belong in `audit_service`.
- Retain permission enforcement on every audit-related route.