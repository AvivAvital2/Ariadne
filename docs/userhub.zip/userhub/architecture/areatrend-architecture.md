---
id: f6125616-5933-5853-9c10-aea040f9499e
type: architecture
title: "Areatrend Architecture"
created_at: 2026-07-30T17:29:26.798127+00:00
updated_at: 2026-07-30T17:29:26.798142+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx
metadata:
  module_name: "frontend.src.components.charts.AreaTrend"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Areatrend Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx`

# AreaTrend Component Architecture

**Module**: `frontend.src.components.charts.AreaTrend`

---

## 1. Component Overview

`AreaTrend` is a self-contained, presentational React component that renders a **single-series time-series visualization**. It combines three visual layers into one SVG canvas:

- A **filled area** beneath the trend line (low-opacity fill for magnitude context)
- A **polyline** tracing the actual data values
- An **interactive hover layer** — crosshair, enlarged data point, and tooltip

Its primary responsibility is transforming an array of `{ label, value }` data points into a coordinate-mapped, distortion-free SVG chart with lightweight interactivity. It holds no business logic, performs no data fetching, and manages only one piece of transient UI state (the hovered index).

**Key characteristics:**
- Zero external dependencies (React only)
- Pure function of props plus a single hover state
- Responsive via a fixed `viewBox` scaled to 100% width

---

## 2. Design Decisions

### Fixed `viewBox` with proportional width
The SVG uses a fixed internal coordinate system (`640 × height`) exposed via `viewBox="0 0 W H"`. The DOM element is styled to fill the container width (via CSS class `area-svg`). This decouples layout math from actual pixel dimensions:

- **Rationale**: All coordinate arithmetic (`xAt`, `yAt`, padding, tick positions) operates on stable numbers. Distortion is avoided because the browser scales the whole viewBox uniformly. Adding/removing points never requires re-measuring the DOM.

### "Nice" axis ceiling (`niceCeil`)
Rather than scaling the Y-axis to the raw max value, `niceCeil` rounds up to a visually pleasant boundary (1, 2, 5 × power of 10, with a floor of 5).

- **Rationale**: Produces clean, human-readable axis labels (e.g., `0 / 25 / 50`) and prevents the top data point from touching the plot ceiling.

### Nearest-point hover detection
`onMove` converts the mouse's client X into viewBox space, then linearly scans all points to find the closest X-position.

- **Rationale**: A linear scan is trivially cheap for typical series lengths and avoids the complexity of binary search or spatial indices. Snapping to the nearest point gives a predictable, "sticky" tooltip experience.

### Dual tooltip strategy
Data points carry native `<title>` elements (browser tooltips) **and** the component renders a custom styled HTML tooltip positioned proportionally.

- **Rationale**: The custom HTML tooltip allows richer styling than SVG permits; the native `<title>` provides an accessible, always-available fallback.

### Coordinate helpers as closures
`xAt`, `yAt`, and `baseY` are defined inside the render body as closures over layout constants.

- **Rationale**: Keeps geometry logic colocated and readable; recomputation per render is negligible.

---

## 3. Component Diagram

```dot
digraph AreaTrend {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_props {
    label="Props (Input Interface)";
    style=dashed;
    Props [label="{ points[], color, height }"];
  }

  subgraph cluster_state {
    label="Local State";
    style=dashed;
    Hover [label="hover: number | null"];
  }

  subgraph cluster_pure {
    label="Pure Geometry Layer";
    style=dashed;
    NiceCeil [label="niceCeil(v)\n(module scope)"];
    Scales   [label="xAt / yAt / baseY\n(closures)"];
    Paths    [label="line, area, ticks\n(derived strings)"];
  }

  subgraph cluster_render {
    label="SVG Render Layers";
    style=dashed;
    Grid      [label="Gridlines + Y labels"];
    AreaFill  [label="Area <path>"];
    Trend     [label="Trend <polyline>"];
    Crosshair [label="Crosshair <line>"];
    Points    [label="Data <circle> + <title>"];
    XLabels   [label="X-axis labels"];
  }

  Tooltip [label="HTML .chart-tooltip", shape=box, style="rounded,filled", fillcolor="#eef"];
  Handlers [label="onMove / onMouseLeave", shape=ellipse];

  Props -> NiceCeil;
  Props -> Scales;
  NiceCeil -> Scales;
  Scales -> Paths;
  Paths -> Grid;
  Paths -> AreaFill;
  Paths -> Trend;

  Handlers -> Hover [label="setHover"];
  Hover -> Crosshair;
  Hover -> Points [label="radius"];
  Hover -> Tooltip [label="show/position"];

  Scales -> Crosshair;
  Scales -> Points;
  Scales -> XLabels;
  Scales -> Tooltip;
}
```

---

## 4. Interfaces

### Props (Input Contract)

| Prop     | Type                              | Default     | Description                                          |
|----------|-----------------------------------|-------------|------------------------------------------------------|
| `points` | `Array<{ label: string, value: number }>` | *required* | Ordered data series; index defines X-position.       |
| `color`  | `string`                          | `"#2a78d6"` | Stroke/fill color for line, area, and data points.   |
| `height` | `number`                          | `220`       | SVG viewBox height (`H`); width is fixed at `640`.   |

**Point shape expectations:**
- `label` — displayed on the X-axis and in tooltips.
- `value` — numeric; drives Y-position and axis scaling.

### CSS Contract (Styling Interface)
The component emits class names but ships no styles. Consumers **must** provide CSS for:

| Class              | Applies To                              |
|--------------------|-----------------------------------------|
| `.area-chart`      | Outer wrapper (positioning context)     |
| `.area-svg`        | SVG element (should set `width: 100%`)  |
| `.grid`            | Gridline strokes                        |
| `.axis-label`      | Numeric and X-axis text labels          |
| `.crosshair`       | Vertical hover indicator                |
| `.chart-tooltip`   | Custom HTML tooltip                     |

> **Integration note:** `.area-chart` should be `position: relative` and `.chart-tooltip` `position: absolute`, since the tooltip is positioned via an inline `left` percentage.

### Output
A single DOM subtree: `<div.area-chart>` containing the `<svg>` and an optional tooltip `<div>`.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Parent [label="Parent Component\n(passes points)"];
  Derive [label="Derive scales\n(niceCeil, xAt, yAt)"];
  Build  [label="Build path strings\n(line, area, ticks)"];
  SVG    [label="Render SVG layers"];
  Mouse  [label="Mouse move over SVG", shape=ellipse];
  Snap   [label="onMove: px -> nearest index"];
  State  [label="setHover(index)"];
  Rerender [label="Re-render\ncrosshair + tooltip"];

  Parent -> Derive -> Build -> SVG;
  Mouse -> Snap -> State -> Rerender;
  Rerender -> SVG [style=dashed, label="highlight"];
}
```

### Render-time flow
1. `points` and `height` arrive as props.
2. `niceCeil` computes the Y-axis ceiling from the max value (min floor of 5, and `Math.max(1, ...)` guards empty/zero series).
3. `xAt`/`yAt` closures map each point index/value into viewBox coordinates.
4. Derived strings (`line`, `area`, `ticks`) are computed and injected into SVG primitives.

### Interaction flow
1. `onMouseMove` fires → `onMove` reads the SVG bounding rect.
2. Client X is normalized into viewBox space (`px`).
3. A linear scan finds the point with the smallest `|xAt(i) - px|`.
4. `setHover(best)` updates state → re-render.
5. On re-render, the crosshair line, enlarged data circle, and positioned HTML tooltip appear for `points[hover]`.
6. `onMouseLeave` resets `hover` to `null`, hiding interactive marks.

### Edge-case handling
- **Empty series (`n === 0`)**: `area` becomes `""` (empty path); the `Math.max(1, ...)` guard keeps `niceMax ≥ 1`.
- **Single point (`n <= 1`)**: `xAt` centers the point at `plotW / 2` to avoid division by zero.

---

## 6. Extension Points

Because the component is intentionally minimal, most customization happens at the **prop**, **CSS**, and **fork** levels rather than through formal plugin hooks.

### Non-invasive (recommended)
- **Theming via `color` + CSS**: Swap the series color through the `color` prop; restyle grid, labels, and tooltip entirely via the class contract.
- **Sizing via `height`**: Adjust vertical extent without touching layout math.
- **Tooltip content**: Restyle `.chart-tooltip`; its DOM structure (`<strong>{value}</strong> {label}`) is stable.

### Requires code changes (fork/enhance)
- **Multi-series support**: Currently single-series. Extending would require mapping over an array of series and rendering multiple `area`/`polyline` layers — likely a new `series[]` prop replacing `points`.
- **Custom axis formatting**: The Y ticks use `Math.round(t)` and X labels use `p.label` verbatim. Introduce `formatY` / `formatX` props to inject custom formatters.
- **Alternate scaling**: Replace `niceCeil` (linear scale) with a log scale or a fixed-domain override prop (e.g., `yMax`).
- **Interaction model**: The nearest-point snap in `onMove` could be extended to emit an `onHover(index)` callback, letting parents react to hover events.
- **Layout constants**: `W`, `padL/R/T/B` are hardcoded. Promote to props if configurable margins are needed (e.g., for long axis labels).

### Suggested minimal API extensions
If broader reuse is anticipated, the lowest-risk additions are:

```
formatY?: (n: number) => string
formatX?: (label: string) => string
yMax?:    number          // override niceCeil
onHover?: (index: number | null) => void
```

These preserve the current pure-presentational contract while unlocking the most common customization requests.