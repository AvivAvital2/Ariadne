---
id: 2875f0d5-1c0f-5199-a30e-6243351f2683
type: architecture
title: "Permissions Architecture"
created_at: 2026-07-30T17:26:47.372357+00:00
updated_at: 2026-07-30T17:26:47.372372+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js
metadata:
  module_name: "frontend.src.auth.permissions"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Permissions Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js`

# Architecture Documentation: `frontend.src.auth.permissions`

## 1. Component Overview

The `permissions` module provides **client-side permission checking** for the frontend application. Its sole responsibility is to answer a single question: *does the current actor hold a given permission?*

The module exposes one pure function, `hasPermission`, which performs a membership test of a permission literal against the actor's permission set. This is used primarily to drive UI behavior — showing, hiding, enabling, or disabling elements based on what the current user is authorized to do.

> **Important:** This is a *presentation-layer convenience*, not a security boundary. The authoritative enforcement occurs server-side in `security.require_permission`. Client-side checks improve UX by preventing users from attempting actions they cannot perform, but they must never be relied upon as the sole gatekeeper.

### Responsibilities
- Evaluate whether an actor possesses a specific permission literal.
- Provide a null-safe, deterministic boolean result for UI conditionals.

### Non-Responsibilities
- Fetching the actor (handled by whatever calls `GET /api/me`).
- Enforcing security (handled by the backend).
- Defining permission literals (owned by `constants.js`).

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Single pure function** | `hasPermission` has no side effects, no I/O, and no hidden state. This makes it trivially testable and safe to call anywhere in the render path. |
| **Optional chaining + `Boolean()` coercion** | Guards against `undefined`/`null` actors (e.g., before `/api/me` resolves) and always returns a strict boolean, avoiding leaking `undefined` into JSX conditionals. |
| **String-literal permissions from `constants.js`** | Centralizing permission names (e.g., `"users:deactivate"`) prevents typos and keeps the client contract aligned with the backend. The `resource:action` naming convention is human-readable and mirrors backend semantics. |
| **Mirrors backend enforcement** | The same permission literal drives both the client check (`hasPermission`) and the server check (`security.require_permission`), ensuring UX and security stay logically consistent. |
| **No dependencies** | Keeping the module dependency-free makes it reusable and prevents coupling to fetching or state-management concerns. |

---

## 3. Component Diagram

```dot
digraph permissions_architecture {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];
  edge [fontname="Helvetica", fontsize=10];

  subgraph cluster_frontend {
    label = "Frontend (client)";
    style = dashed;
    color = "#4a90d9";

    constants   [label="constants.js\n(permission literals)"];
    permissions [label="auth/permissions.js\nhasPermission(actor, permission)", style="rounded,filled", fillcolor="#e6f2ff"];
    ui          [label="UI Components\n(buttons, menus, routes)"];
    meState     [label="Actor State\n(from GET /api/me)"];
  }

  subgraph cluster_backend {
    label = "Backend (server)";
    style = dashed;
    color = "#d9534f";

    api_me       [label="GET /api/me\n(returns actor.permissions)"];
    require_perm [label="security.require_permission\n(authoritative enforcement)"];
  }

  // Frontend wiring
  ui -> permissions        [label="calls"];
  constants -> ui          [label="supplies literal"];
  meState -> permissions   [label="provides actor"];
  api_me -> meState        [label="hydrates", style=dashed];

  // Contract alignment (shared literal semantics)
  constants -> require_perm [label="same permission\ncontract", style=dotted, color="#888888"];

  // Real security path
  ui -> require_perm       [label="action request\n(enforced)", color="#d9534f"];
}
```

---

## 4. Interfaces

### Public API

```javascript
export function hasPermission(actor, permission): boolean
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `actor` | `object \| null \| undefined` | The current user object, typically sourced from `GET /api/me`. Expected shape: `{ permissions: string[] }`. |
| `permission` | `string` | A permission literal (e.g., `"users:deactivate"`), sourced from `constants.js`. |
| **returns** | `boolean` | `true` if `actor.permissions` contains `permission`; `false` otherwise (including when `actor` or `permissions` is absent). |

### Integration Points

- **`constants.js`** — Provides the permission literal string arguments. Callers should reference constants rather than inlining strings.
- **`GET /api/me`** — Upstream data source producing the `actor.permissions` array. This module does not call the endpoint; callers must supply an already-resolved actor.
- **`security.require_permission` (backend)** — The security counterpart. Both sides key off the same permission literal, forming an implicit shared contract.

---

## 5. Data Flow

```dot
digraph data_flow {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica", fontsize=10];
  edge [fontname="Helvetica", fontsize=9];

  step1 [label="1. Session bootstrap\nGET /api/me → { permissions: [...] }"];
  step2 [label="2. Actor stored in\nclient state"];
  step3 [label="3. Component reads permission literal\nfrom constants.js"];
  step4 [label="4. hasPermission(actor, literal)\nnull-safe includes() check"];
  step5 [label="5. Boolean result drives\nrender / enable / route guard"];

  step1 -> step2 -> step3 -> step4 -> step5;
}
```

**Narrative:**
1. At session start, the app fetches the actor via `GET /api/me`, which includes a `permissions` array.
2. The actor is held in client state (context, store, etc.).
3. A UI component needs to decide whether to render a privileged control and pulls the appropriate literal from `constants.js`.
4. `hasPermission(actor, literal)` performs a safe `Array.prototype.includes` check.
5. The boolean drives the UI decision. If the user proceeds with a privileged action, the backend independently re-validates via `security.require_permission`.

Data flow is **read-only and unidirectional** — the module never mutates the actor or permissions.

---

## 6. Extension Points

The module is intentionally minimal. Extensions should preserve its **pure, side-effect-free** contract.

### Recommended extension patterns

- **Composite checks (`hasAnyPermission` / `hasAllPermissions`)**
  Add sibling helpers for common patterns without altering `hasPermission`:
  ```javascript
  export function hasAnyPermission(actor, permissions) {
    return permissions.some((p) => hasPermission(actor, p));
  }

  export function hasAllPermissions(actor, permissions) {
    return permissions.every((p) => hasPermission(actor, p));
  }
  ```

- **React hook wrapper**
  Wrap `hasPermission` in a hook (e.g., `usePermission`) that binds it to the actor from context, keeping the pure function reusable outside of React.

- **Guard component / HOC**
  Build a `<RequirePermission permission={...}>` wrapper that renders children only when `hasPermission` returns `true`.

- **Wildcard / hierarchical permissions**
  If permission semantics evolve (e.g., `"users:*"` implying all `users:` actions), extend the matching logic here — but ensure the backend `security.require_permission` adopts the **identical** interpretation to avoid divergence.

### Extension constraints

- **Keep it pure.** Do not introduce fetching, caching, or global-state reads inside `hasPermission` — supply the actor from the caller.
- **Do not treat client checks as authoritative.** Any new capability must remain UX-only; the backend must independently enforce every permission.
- **Keep literals centralized.** New permissions belong in `constants.js` and must be mirrored in the backend permission set.

---

*Last aligned with: `constants.js` permission literals and backend `security.require_permission`. When permission naming or matching semantics change on either side, update both to preserve the shared contract.*