---
id: a0004b75-c282-500d-9192-4240a3923ed1
type: architecture
title: "Database Architecture"
created_at: 2026-07-30T17:21:40.802968+00:00
updated_at: 2026-07-30T17:21:40.802982+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  module_name: "backend.app.database"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Database Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

# Architecture Document: `backend.app.database`

## 1. Component Overview

The `backend.app.database` module is the **data access foundation** for the application. It centralizes all SQLAlchemy configuration into a single, importable location and exposes three primary artifacts:

| Artifact | Type | Responsibility |
|----------|------|----------------|
| `engine` | Module-level singleton | Manages the underlying connection pool to the database |
| `SessionLocal` | Session factory (`sessionmaker`) | Produces new ORM `Session` instances bound to the engine |
| `Base` | Declarative base class | Serves as the parent class for all ORM models and holds shared metadata |
| `get_db` | Generator function | FastAPI dependency that yields a request-scoped session with guaranteed cleanup |

Its core responsibility is to **decouple database connectivity concerns from application logic**. Models inherit from `Base`, route handlers acquire sessions via `get_db`, and neither needs knowledge of connection strings or pooling details.

---

## 2. Design Decisions

### SQLite with thread-safety override
```python
DATABASE_URL = "sqlite:///./userhub.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
```
- **SQLite** is used as a lightweight, zero-configuration store—appropriate for development or small deployments.
- The `check_same_thread=False` flag disables SQLite's default single-thread restriction. This is **required because FastAPI serves requests from a thread pool**, and a session created in one thread may be operated on from another.

### Explicit session semantics
```python
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
```
- **`autocommit=False`** and **`autoflush=False`** give application code deterministic control over when data is flushed and committed. This avoids surprising implicit writes and makes transaction boundaries explicit at the call site.

### Modern declarative base
```python
class Base(DeclarativeBase): ...
```
- Uses SQLAlchemy 2.0's `DeclarativeBase` subclassing style rather than the legacy `declarative_base()` factory, enabling better type checking and IDE support.

### Dependency-injection-friendly session lifecycle
- `get_db` follows the **generator-based dependency pattern**. The `try/finally` block guarantees `db.close()` runs even if the request handler raises, preventing connection leaks.

---

## 3. Component Diagram

```dot
digraph database_module {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_module {
        label="backend.app.database";
        style=dashed;

        URL     [label="DATABASE_URL\n(sqlite:///./userhub.db)", shape=note];
        engine  [label="engine\n(Engine / connection pool)"];
        Session [label="SessionLocal\n(sessionmaker factory)"];
        Base    [label="Base\n(DeclarativeBase)"];
        get_db  [label="get_db()\n(FastAPI dependency)", shape=ellipse];
    }

    SQLAlchemy [label="SQLAlchemy\n(external)", shape=cylinder];
    DB         [label="SQLite file\nuserhub.db", shape=cylinder];
    Models     [label="ORM Models\n(inherit Base)", shape=box, style="rounded,filled", fillcolor="#eef"];
    Routes     [label="FastAPI Route Handlers", shape=box, style="rounded,filled", fillcolor="#efe"];

    URL     -> engine   [label="configures"];
    engine  -> DB       [label="connects to"];
    Session -> engine   [label="bound to"];
    get_db  -> Session  [label="instantiates"];
    Base    -> engine   [label="metadata used by\ncreate_all / migrations", style=dashed];

    SQLAlchemy -> engine  [style=dotted, label="provides"];
    SQLAlchemy -> Session [style=dotted];
    SQLAlchemy -> Base    [style=dotted];

    Models -> Base   [label="subclass"];
    Routes -> get_db [label="Depends()"];
}
```

---

## 4. Interfaces

### Exported Symbols

| Symbol | Signature / Type | Consumers |
|--------|------------------|-----------|
| `engine` | `sqlalchemy.Engine` | Migration scripts, `Base.metadata.create_all(engine)` |
| `SessionLocal` | `sessionmaker[Session]` | Background tasks, scripts needing a session outside a request |
| `Base` | `type[DeclarativeBase]` | All ORM model modules (as a base class) |
| `get_db()` | `Iterator[Session]` | FastAPI route handlers via `Depends(get_db)` |

### Integration Point: FastAPI Dependency

```python
from fastapi import Depends
from backend.app.database import get_db
from sqlalchemy.orm import Session

@router.get("/users")
def list_users(db: Session = Depends(get_db)):
    return db.query(User).all()
```

FastAPI resolves `get_db`, advances the generator to obtain the yielded `Session`, injects it into the handler, and re-enters the generator after the response to trigger the `finally` cleanup.

### Integration Point: Model Definition

```python
from backend.app.database import Base
from sqlalchemy.orm import Mapped, mapped_column

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
```

---

## 5. Data Flow

**Per-request session lifecycle:**

```dot
digraph request_flow {
    rankdir=TB;
    node [shape=box, fontname="Helvetica"];

    req    [label="Incoming HTTP request"];
    fastapi[label="FastAPI resolves Depends(get_db)"];
    create [label="SessionLocal() creates Session\n(acquires connection from pool)"];
    yield  [label="Session yielded to handler"];
    logic  [label="Handler executes queries\n(explicit commit/rollback)"];
    close  [label="finally: db.close()\n(returns connection to pool)"];
    resp   [label="Response returned"];

    req -> fastapi -> create -> yield -> logic -> close -> resp;
}
```

1. A request arrives and the handler declares `Depends(get_db)`.
2. `get_db` calls `SessionLocal()`, which checks out a connection from the `engine`'s pool.
3. The active `Session` is yielded to the handler.
4. The handler runs queries. Because `autocommit=False`, the developer must explicitly call `db.commit()` to persist writes; otherwise, the transaction is rolled back on close.
5. Whether the handler succeeds or raises, the `finally` block calls `db.close()`, returning the connection to the pool.

---

## 6. Extension Points

### Switching Databases
Replace `DATABASE_URL` with a different backend. When moving off SQLite, remove the SQLite-specific `connect_args`:
```python
DATABASE_URL = "postgresql+psycopg://user:pass@host/dbname"
engine = create_engine(DATABASE_URL)  # drop check_same_thread
```

### Externalizing Configuration
The hardcoded `DATABASE_URL` should be sourced from environment/settings for production:
```python
from backend.app.config import settings
engine = create_engine(settings.database_url, ...)
```
This is the recommended first customization, isolating environment-specific values from code.

### Connection Pool Tuning
Pass pool parameters to `create_engine` (ignored by SQLite but relevant for server-based databases):
```python
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20, pool_pre_ping=True)
```

### Session Behavior Customization
Adjust the `sessionmaker` configuration (e.g., `expire_on_commit=False` to keep objects usable after commit) without touching consumers, since they depend only on `get_db`.

### Testing Override
Because `get_db` is a FastAPI dependency, tests can substitute an alternate session (e.g., bound to an in-memory database with a rolling-back transaction) via `app.dependency_overrides[get_db] = override_get_db`.

### Schema Management
`Base.metadata` is the registry of all model tables. Extend schema creation logic elsewhere via:
```python
Base.metadata.create_all(bind=engine)   # quick bootstrap
```
For evolving schemas, integrate a migration tool (e.g., Alembic) pointed at `Base.metadata` and `engine`.

---

### Maintenance Notes
- Keep this module **free of model imports** to avoid circular dependencies; models import `Base`, not the reverse.
- Any change to session defaults (`autoflush`, `autocommit`) affects all consumers—review transaction handling across route handlers before altering them.