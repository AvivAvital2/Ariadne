---
id: 2ed94cfd-29e5-51ec-b4a4-758de506c7ad
type: architecture
title: "Client Architecture"
created_at: 2026-07-30T17:26:54.852380+00:00
updated_at: 2026-07-30T17:26:54.852393+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js
metadata:
  module_name: "frontend.src.api.client"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Client Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js`

# API Client Architecture

**Module:** `frontend.src.api.client`

---

## 1. Component Overview

The API client is the **single integration boundary** between the frontend application and the backend HTTP API. Its core responsibility is to centralize all network communication so that:

- Every backend call flows through one shared `request` helper.
- There is exactly one `fetch` call site per endpoint.
- Concerns such as headers, JSON serialization, error handling, and actor identity are handled uniformly.

The module exports a flat set of named functions, one per backend operation (users, roles, permissions, audit, reports). Consumers (UI components, stores, hooks) import these functions rather than issuing `fetch` calls directly.

### Responsibilities

| Responsibility | Description |
|----------------|-------------|
| Endpoint mapping | Maps each backend route to a named JS function |
| Request construction | Sets method, headers, and body consistently |
| Serialization | JSON-encodes request bodies, parses JSON responses |
| Error normalization | Converts non-2xx responses into thrown `Error`s |
| Actor identity | Attaches the current actor ID header to every request |

---

## 2. Design Decisions

### Single funnel through `request`
All endpoint functions delegate to a private `request(method, url, body)` helper. This guarantees consistent behavior for headers, error handling, and empty-body (`204`) responses. Changing cross-cutting behavior (e.g., adding auth tokens, retries, logging) requires editing only one function.

### Actor identity instead of authentication
The system has **no authentication layer**. Instead, a mutable module-level `currentActorId` (defaulting to the seeded admin, id `1`) is sent in the `X-Actor-Id` header. This models "who is acting" for authorization and audit purposes without a login flow. Actor switching is done through the exported `setActor(id)` — useful for admin impersonation or development.

> **Rationale:** Keeps the frontend simple in a system where identity is trusted (internal tool / demo). The header-based approach mirrors how a real auth token would eventually be injected, making a future migration low-risk.

### Relative URLs
All endpoints use relative paths (`/api/...`) that mirror the backend's route definitions. This assumes the frontend is served same-origin (or behind a proxy) and avoids hardcoding hosts.

### Shared constants
Status values come from `../constants.js` (`USER_STATUS`), ensuring the frontend and its API calls agree on the same status strings used by the backend.

### Convenience wrappers
`deactivateUser` / `reactivateUser` wrap the generic `setUserStatus`, encoding domain intent at the call site while reusing the single PATCH endpoint.

---

## 3. Component Diagram

```dot
digraph ApiClient {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_consumers {
    label="Frontend Consumers";
    style=dashed;
    UI [label="UI Components /\nStores / Hooks"];
  }

  subgraph cluster_client {
    label="api/client.js";
    style=filled;
    color=lightgrey;

    setActor    [label="setActor(id)"];
    actorState  [label="currentActorId\n(module state)", shape=ellipse, style=filled, color=lightyellow];

    subgraph cluster_endpoints {
      label="Endpoint Functions";
      style=dotted;
      users   [label="getCurrentUser\nlistUsers / getUser\ncreateUser / updateUser\nsetUserStatus\ndeactivateUser / reactivateUser\nassignRoles / deleteUser"];
      roles   [label="listRoles\ncreateRole"];
      perms   [label="listPermissions"];
      audit   [label="listAudit\nuserActivityReport"];
    }

    request [label="request(method, url, body)", shape=box, style="rounded,filled", color=lightblue];
  }

  constants [label="constants.js\n(USER_STATUS)", shape=note];
  backend   [label="Backend HTTP API\n(/api/*)", shape=cylinder];

  UI -> users;
  UI -> roles;
  UI -> perms;
  UI -> audit;
  UI -> setActor;

  setActor -> actorState [label="writes"];

  users -> request;
  roles -> request;
  perms -> request;
  audit -> request;

  users -> constants [label="uses", style=dashed];
  request -> actorState [label="reads", style=dashed];
  request -> backend [label="fetch()"];
}
```

---

## 4. Interfaces

### Actor Management

| Function | Description |
|----------|-------------|
| `setActor(id)` | Sets the active actor whose ID is sent in `X-Actor-Id` on all subsequent requests. |

### User Endpoints

| Function | HTTP | Route |
|----------|------|-------|
| `getCurrentUser()` | GET | `/api/me` |
| `listUsers(status?)` | GET | `/api/users?status=…` |
| `getUser(userId)` | GET | `/api/users/{id}` |
| `createUser(payload)` | POST | `/api/users` |
| `updateUser(userId, payload)` | PUT | `/api/users/{id}` |
| `setUserStatus(userId, status)` | PATCH | `/api/users/{id}/status` |
| `deactivateUser(userId)` | PATCH | `/api/users/{id}/status` (status = `DEACTIVATED`) |
| `reactivateUser(userId)` | PATCH | `/api/users/{id}/status` (status = `ACTIVE`) |
| `assignRoles(userId, roleIds)` | POST | `/api/users/{id}/roles` |
| `deleteUser(userId)` | DELETE | `/api/users/{id}` |

### Role / Permission Endpoints

| Function | HTTP | Route |
|----------|------|-------|
| `listRoles()` | GET | `/api/roles` |
| `createRole(payload)` | POST | `/api/roles` |
| `listPermissions()` | GET | `/api/permissions` |

### Audit / Reporting Endpoints

| Function | HTTP | Route |
|----------|------|-------|
| `listAudit(action?)` | GET | `/api/audit?action=…` |
| `userActivityReport()` | GET | `/api/reports/user-activity` |

### Protocol Contract

- **Request headers (always):**
  - `Content-Type: application/json`
  - `X-Actor-Id: <currentActorId>`
- **Request body:** JSON-serialized when a `body` argument is provided; omitted otherwise.
- **Success:** Returns parsed JSON, or `null` for `204 No Content`.
- **Failure:** Throws `Error`. Message is taken from the response body's `detail` field, falling back to `"{METHOD} {url} failed ({status})"`.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  call    [label="Endpoint fn called\n(e.g. createUser(payload))"];
  build   [label="request() builds options:\nmethod, headers, JSON body"];
  actor   [label="Inject X-Actor-Id\nfrom currentActorId", shape=ellipse, color=lightyellow, style=filled];
  fetch   [label="fetch(url, options)"];
  check   [label="response.ok?", shape=diamond];
  ok      [label="204 → null\nelse → response.json()"];
  err     [label="Parse detail →\nthrow Error"];
  caller  [label="Returns Promise\nto caller"];

  call -> build -> actor -> fetch -> check;
  check -> ok  [label="yes"];
  check -> err [label="no"];
  ok -> caller;
  err -> caller [label="rejects"];
}
```

**Outbound path:** A consumer calls a named function → `request` assembles the HTTP options (method, standard headers, actor header, optional JSON body) → `fetch` sends the request to the backend.

**Inbound path:** The response is inspected. On `!response.ok`, the body is parsed for a `detail` message and an `Error` is thrown. Otherwise a `204` yields `null` and any other success yields the parsed JSON body.

**State read:** The actor header value is read from module-level `currentActorId` at request time — so changes via `setActor` take effect on the next call, not retroactively.

---

## 6. Extension Points

### Adding a new endpoint
Add a new exported function that delegates to `request`. Follow the existing pattern of relative URLs matching backend routes:

```javascript
export function archiveUser(userId) {
  return request("PATCH", `/api/users/${userId}/archive`);
}
```

No other changes are needed — serialization, headers, and error handling are inherited.

### Cross-cutting behavior (auth, retries, logging)
Modify the single `request` helper. This is the intended extension seam for concerns that apply to all calls:

- **Auth token:** Add an `Authorization` header alongside `X-Actor-Id`.
- **Retries / timeouts:** Wrap the `fetch` call.
- **Telemetry:** Log method/url/status before returning or throwing.

### Identity / actor strategy
`currentActorId` and `setActor` isolate the identity concern. Replacing header-based actor identity with real authentication involves:
1. Adding token storage/state.
2. Injecting the token in `request` (single edit point).
3. The header name `ACTOR_HEADER` and default id can be updated or removed.

### Status vocabulary
Domain status values are sourced from `constants.js` (`USER_STATUS`). Adding new lifecycle states (e.g., a `SUSPENDED` status) means extending that constant and, optionally, adding a convenience wrapper like `suspendUser(userId)` around `setUserStatus`.

### Error handling customization
The error-normalization logic (`payload.detail || …`) is centralized in `request`. To surface structured errors (status codes, error codes) to the UI, extend the thrown object here rather than at each call site.

---

## Terminology

| Term | Meaning |
|------|---------|
| **Actor** | The user whose identity is asserted for a request via `X-Actor-Id`; defaults to seeded admin (id 1). |
| **Endpoint function** | An exported function mapping 1:1 to a backend route. |
| **`request` helper** | The private, single fetch call site all endpoints route through. |