---
id: 4831fcc6-d16e-5db9-aea3-a9c5ccf142d0
type: architecture
title: "Barchart Architecture"
created_at: 2026-07-30T17:29:50.572086+00:00
updated_at: 2026-07-30T17:29:50.572100+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx
metadata:
  module_name: "frontend.src.components.charts.BarChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Barchart Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx`

# BarChart Component Architecture

**Module:** `frontend.src.components.charts.BarChart`

---

## 1. Component Overview

`BarChart` is a presentational React component that renders a **horizontal bar chart** (magnitude bars). Each data point is displayed as a labeled horizontal bar whose fill width is proportional to its value relative to a maximum, with the numeric value rendered directly alongside each bar.

Its responsibilities are intentionally narrow:

- **Normalize** raw values against a maximum to compute relative bar widths.
- **Render** one row per data point, each with a label, a proportional fill track, and a value readout.
- **Provide accessibility/affordance cues** via `title` attributes on labels and fills.

The component is **stateless** and **side-effect free**: it derives all of its rendered output purely from its props.

> **Accessibility note (from source comment):** The direct value labels are intentional. They double as a "relief rule" mechanism — ensuring values remain readable even when the categorical bar color (`d.color`) has low contrast against the background.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Pure functional component** | The chart is purely a function of `(data, max)`. No internal state or lifecycle is required, keeping it easy to test and reason about. |
| **Caller-supplied `max` with a fallback** | `max ?? Math.max(1, ...values)` lets callers align multiple charts to a shared scale (pass explicit `max`) while defaulting to a self-scaling view. |
| **`Math.max(1, ...)` floor** | Prevents division-by-zero and degenerate `NaN`/`Infinity` widths when all values are `0` or the dataset is empty. |
| **Direct value labels** | Satisfies contrast/relief requirements so information is not solely encoded by color — improving accessibility and clarity. |
| **CSS-driven layout** | Widths are inline (dynamic), but structure/typography live in CSS classes (`hbars`, `hbar-row`, etc.), separating data-driven styling from static presentation. |
| **`d.label` as React `key`** | Uses a stable, meaningful identifier for list reconciliation rather than array index. Assumes labels are unique. |

---

## 3. Component Diagram

```dot
digraph BarChart {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Caller [label="Parent Component\n(supplies props)", shape=ellipse, style=filled, fillcolor="#eef"];

  subgraph cluster_barchart {
    label="BarChart";
    style=dashed;

    Props   [label="Props\n{ data[], max? }"];
    Derive  [label="Derive scale\ntop = max ?? Math.max(1, ...values)"];
    Render  [label="Render <div.hbars>"];
    RowMap  [label="map(data) → hbar-row", shape=parallelogram];
  }

  subgraph cluster_row {
    label="hbar-row (per data point)";
    style=dotted;

    Label [label="hbar-label\n(d.label, title)"];
    Track [label="hbar-track"];
    Fill  [label="hbar-fill\nwidth = value/top * 100%\nbackground = d.color"];
    Value [label="hbar-value\n(d.value)"];

    Track -> Fill [label="contains"];
  }

  Caller  -> Props;
  Props   -> Derive;
  Derive  -> Render;
  Render  -> RowMap;
  RowMap  -> Label;
  RowMap  -> Track;
  RowMap  -> Value;

  CSS [label="Stylesheet\n(.hbars, .hbar-*)", shape=note, style=filled, fillcolor="#ffe"];
  CSS -> Render [style=dashed, label="styles", dir=none];
}
```

---

## 4. Interfaces

### Props (Input API)

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `data` | `Array<DataPoint>` | Yes | The series to render. One row per element. |
| `max`  | `number`           | No  | Explicit upper bound for scaling. Defaults to the largest value in `data` (floored at `1`). |

### `DataPoint` shape

| Field   | Type     | Description |
|---------|----------|-------------|
| `label` | `string` | Row identifier and displayed label. Used as the React `key` (must be unique). |
| `value` | `number` | Magnitude driving the bar's fill width and value readout. |
| `color` | `string` | CSS color applied to the bar fill (any valid `background` value). |

### DOM / CSS Contract (Output API)

The component emits a fixed class structure that the host stylesheet must define:

```
.hbars
  .hbar-row
    .hbar-label
    .hbar-track
      .hbar-fill   (inline width + background)
    .hbar-value
```

Consumers integrate primarily by **supplying props** and **providing the CSS** for these classes.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  In    [label="props.data\nprops.max"];
  Scale [label="Compute top\n(scale ceiling)"];
  Iter  [label="Iterate data[]"];
  Calc  [label="Per row:\nwidth% = value/top*100"];
  Out   [label="Rendered rows\n(label · fill · value)"];

  In -> Scale -> Iter -> Calc -> Out;
}
```

1. **Input:** The parent passes `data` and optionally `max`.
2. **Scale derivation:** `top` is computed once as `max ?? Math.max(1, ...values)`.
3. **Iteration:** `data.map(...)` produces one `hbar-row` per data point.
4. **Per-row computation:** Each fill width is `(d.value / top) * 100%`; the fill background is `d.color`.
5. **Output:** A DOM tree of rows, each combining label, proportional fill, and direct value label.

Data is **unidirectional and read-only** — the component never mutates props and emits no events.

---

## 6. Extension Points

Because the component is small and presentational, extension is achieved primarily through **props, styling, and composition** rather than internal configuration.

### Styling / Theming
- Override the `.hbars`, `.hbar-row`, `.hbar-label`, `.hbar-track`, `.hbar-fill`, and `.hbar-value` classes to change spacing, height, typography, or track background.
- Per-bar color is data-driven via `d.color`, allowing categorical palettes to be injected upstream.

### Scaling Behavior
- Pass an explicit `max` to synchronize scale across multiple `BarChart` instances (e.g., dashboards comparing series).
- Omit `max` for auto-scaling to each dataset independently.

### Potential Enhancement Hooks
If the component needs to grow, the following are natural, low-risk extension seams:

| Extension | Suggested Approach |
|-----------|--------------------|
| **Custom value formatting** | Add an optional `format?: (value) => string` prop applied where `{d.value}` is rendered. |
| **Click / hover interactions** | Add an optional `onSelect?: (dataPoint) => void` handler on `hbar-row`. |
| **Accessibility roles** | Wrap in ARIA roles (`role="img"` / `role="list"`) and add `aria-label` derived from `title` values. |
| **Non-unique labels** | Introduce an explicit `id` field to replace `label` as the React `key`. |
| **Empty state** | Guard rendering when `data` is empty to display a placeholder. |

### Composition
- The component is a **default export** and can be dropped into any layout container. Its self-contained DOM structure makes it safe to embed in cards, tables, or grid cells without layout leakage, provided the host stylesheet defines the `hbar-*` classes.

---

### Assumptions & Constraints
- `d.label` values are assumed **unique** (used as React keys).
- `d.value` is assumed **non-negative**; negative values would produce negative widths (clamped to `0` by the browser but not visually meaningful).
- The consuming application is responsible for providing the CSS contract; the component ships structure and inline dynamic styles only.