---
id: 3fa80c32-aa26-5dc5-8b49-5a4fc6df0858
type: architecture
title: "Schemas Architecture"
created_at: 2026-07-30T17:24:05.881789+00:00
updated_at: 2026-07-30T17:24:05.881804+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  module_name: "backend.app.schemas"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Schemas Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

# Architecture Documentation: `backend.app.schemas`

## 1. Component Overview

The `backend.app.schemas` module defines the **data contract layer** of the backend application. It provides a collection of [Pydantic](https://docs.pydantic.dev/) models that govern the shape, validation, and serialization of data crossing the API boundary.

These schemas serve three primary responsibilities:

- **Request validation** — Incoming HTTP payloads (create/update/assignment operations) are parsed and validated against strict type definitions.
- **Response serialization** — Domain/ORM objects are converted into stable, JSON-serializable output shapes.
- **Contract stabilization** — The schemas decouple the internal persistence model (SQLAlchemy entities, raw SQL rows) from the external API surface consumed by the React frontend and other clients.

The module is intentionally logic-free: it contains no business rules, database access, or side effects. It is a declarative boundary definition.

---

## 2. Design Decisions

### 2.1 Separation of Input and Output Schemas
Input schemas (`RoleCreate`, `UserCreate`, `UserUpdate`, `UserStatusUpdate`, `RoleAssignment`) are distinct from output schemas (`RoleOut`, `UserOut`, `AuditLogOut`, etc.). This enables:
- Independent evolution of what a client may **send** vs. what the server will **return**.
- Server-managed fields (`id`, `created_at`, `updated_at`, `status`) to be excluded from input payloads, preventing clients from setting them.

### 2.2 ORM Attribute Mapping via `from_attributes`
Output schemas set `model_config = ConfigDict(from_attributes=True)`. This lets Pydantic construct instances directly from ORM objects (attribute access) rather than dictionaries. Schemas without this config (`UserActivityRow`, `CurrentUser`, and all input schemas) are constructed from plain data structures.

### 2.3 "Brief" vs. "Full" Projections
`RoleBrief` (id + name) exists alongside `RoleOut` (id + name + description + permissions). This avoids over-fetching: nested relationships in `UserOut` embed the lightweight `RoleBrief` rather than the full role graph, reducing payload size and preventing deep nesting.

### 2.4 String-Encoded Enums at the Boundary
`status` and `permissions` fields are typed as `str` / `list[str]` rather than Python enums. As documented in the source:
- `UserStatusUpdate.status` carries raw `UserStatus` values like `"deactivated"`.
- `CurrentUser.permissions` carries flattened strings like `"users:deactivate"` that the frontend checks directly.

This keeps the wire format simple and stable for the frontend, at the cost of validation strictness. Enum semantics are enforced elsewhere in the domain layer.

### 2.5 Dedicated Report Schema
`UserActivityRow` is explicitly documented as a projection of a **raw-SQL report**. It does not map to an ORM entity, so it omits `from_attributes` and is composed from query result rows.

---

## 3. Component Diagram

```dot
digraph schemas {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_output {
        label="Output Schemas (from_attributes=True)";
        style=dashed;
        color="#3366cc";
        PermissionOut;
        RoleBrief;
        RoleOut;
        UserOut;
        AuditLogOut;
    }

    subgraph cluster_input {
        label="Input Schemas (request bodies)";
        style=dashed;
        color="#cc6633";
        RoleCreate;
        UserCreate;
        UserUpdate;
        UserStatusUpdate;
        RoleAssignment;
    }

    subgraph cluster_derived {
        label="Derived / Report Schemas";
        style=dashed;
        color="#339966";
        CurrentUser;
        UserActivityRow;
    }

    // Composition relationships
    RoleOut  -> PermissionOut [label="permissions[]"];
    UserOut  -> RoleBrief     [label="roles[]"];

    // Conceptual references (string-encoded IDs, not object links)
    RoleCreate    -> PermissionOut [style=dotted, label="permission_ids"];
    UserCreate    -> RoleBrief     [style=dotted, label="role_ids"];
    RoleAssignment-> RoleBrief     [style=dotted, label="role_ids"];
}
```

**Legend**
- Solid arrows: direct schema composition (nested model embedding).
- Dotted arrows: conceptual references via ID lists resolved server-side.

---

## 4. Interfaces

All classes subclass `pydantic.BaseModel` and expose the standard Pydantic v2 interface:

| Method | Purpose |
|--------|---------|
| `Model(**data)` | Validate and construct from a dict / keyword args (input schemas). |
| `Model.model_validate(obj)` | Construct from an ORM object or dict (output schemas with `from_attributes`). |
| `instance.model_dump()` | Serialize to a Python dict. |
| `instance.model_dump_json()` | Serialize to a JSON string. |

### Integration Points

| Schema | Typical Direction | Bound To |
|--------|-------------------|----------|
| `RoleCreate` | Request | `POST /roles` |
| `RoleOut` | Response | Role read endpoints |
| `PermissionOut` | Response (nested) | Embedded in `RoleOut` |
| `RoleBrief` | Response (nested) | Embedded in `UserOut` |
| `UserCreate` | Request | `POST /users` |
| `UserUpdate` | Request (partial) | `PATCH /users/{id}` |
| `UserStatusUpdate` | Request (partial) | `PATCH /users/{id}/status` (deactivate/reactivate) |
| `RoleAssignment` | Request | Role assignment endpoint |
| `UserOut` | Response | User read endpoints |
| `CurrentUser` | Response | Authenticated-user / session endpoint |
| `AuditLogOut` | Response | Audit log read endpoints |
| `UserActivityRow` | Response (report) | User-activity report endpoint |

`UserUpdate` uses `str | None` defaults, signaling **partial update (PATCH)** semantics — omitted fields remain unchanged.

---

## 5. Data Flow

### Inbound (Request) Flow
```dot
digraph inbound {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    client   [label="Client / Frontend"];
    router   [label="API Route Handler"];
    schema   [label="Input Schema\n(e.g. UserCreate)"];
    service  [label="Service / Domain Layer"];

    client -> router [label="JSON body"];
    router -> schema [label="parse + validate"];
    schema -> service [label="validated model"];
}
```
1. A client sends a JSON request body.
2. The framework binds the body to the relevant input schema, raising validation errors on malformed data.
3. The validated model is handed to the service/domain layer, which resolves ID references (e.g. `role_ids`, `permission_ids`) into entities.

### Outbound (Response) Flow
```dot
digraph outbound {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];
    orm      [label="ORM Entity /\nSQL Row"];
    schema   [label="Output Schema\n(model_validate)"];
    json     [label="JSON Response"];
    client   [label="Client / Frontend"];

    orm -> schema [label="from_attributes"];
    schema -> json [label="model_dump_json"];
    json -> client;
}
```
1. The service returns an ORM entity (or raw SQL row for reports).
2. The output schema is populated via `model_validate` (leveraging `from_attributes`), embedding nested projections (`RoleBrief`, `PermissionOut`) as needed.
3. Pydantic serializes the model to JSON for the client.

---

## 6. Extension Points

### Adding a New Endpoint Contract
Define a new `BaseModel` subclass in this module. Choose configuration based on data source:
- Constructing from an **ORM object** → add `model_config = ConfigDict(from_attributes=True)`.
- Constructing from a **dict / raw row / computed values** → omit `from_attributes`.

### Extending Existing Schemas
- **New response fields**: Add optional fields with defaults (e.g. `field: str | None = None`) to preserve backward compatibility for existing clients.
- **New partial-update fields**: Follow the `UserUpdate` pattern (`Type | None = None`) so PATCH semantics are preserved.

### Nested Projection Pattern
When embedding related resources, prefer a lightweight `*Brief` schema (like `RoleBrief`) over the full `*Out` schema to control payload size. Reuse existing brief schemas where possible.

### Enum-at-the-Boundary Convention
When introducing new status/permission-like fields, continue using `str` at the boundary to keep the wire format frontend-friendly, and enforce enum validity in the domain layer. Document the accepted values in the schema docstring (as done for `UserStatusUpdate` and `CurrentUser`).

### Reporting Schemas
For raw-SQL report endpoints, model each result row as a standalone schema (following `UserActivityRow`). Keep these decoupled from ORM-mapped schemas since the underlying query shape may not correspond to any entity.

---

### Maintenance Notes
- This module should remain **free of business logic and I/O**. Keep validation declarative.
- Because these schemas define the public API contract, treat field renames and type changes as **breaking changes** requiring client coordination (notably with the React frontend that reads `permissions` and `status` strings directly).