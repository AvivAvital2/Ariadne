---
id: 20274bf9-3d25-59df-9641-8eb92993f0d3
type: architecture
title: "Queries Architecture"
created_at: 2026-07-30T17:22:34.533347+00:00
updated_at: 2026-07-30T17:22:34.533362+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  module_name: "backend.app.reports.queries"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Queries Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`

# Architecture Documentation: `backend.app.reports.queries`

## 1. Component Overview

The `backend.app.reports.queries` module is a **SQL query repository** for the reporting subsystem. It contains hand-written, raw SQL statements used to generate reporting data that summarizes user activity across the application.

### Responsibilities
- Define reusable, read-only SQL queries for reporting workloads.
- Serve as a **single source of truth** for the SQL used by the reporting layer.
- Aggregate data across the `users` and `audit_log` tables.

### Non-Responsibilities
- The module does **not** execute queries — it only declares them as string constants.
- It does **not** manage database connections, sessions, or transactions.
- It does **not** perform ORM mapping or result serialization.

Currently the module exposes a single query, `USER_ACTIVITY_SQL`, which produces a per-user activity summary (action count and last action timestamp).

---

## 2. Design Decisions

### 2.1 Raw SQL Instead of ORM
The module documentation explicitly notes that these queries **bypass the ORM** and read directly from the `users` and `audit_log` tables.

**Rationale:**
- **Performance for aggregation:** Reporting queries typically involve `GROUP BY`, aggregate functions (`COUNT`, `MAX`), and joins across large tables. Raw SQL avoids ORM overhead and produces predictable, tunable execution plans.
- **Read model separation:** Reporting is a distinct read concern from the transactional write model. Keeping the query hand-written decouples reporting from ORM entity changes.
- **Explicit control:** Column aliases (`user_id`, `action_count`, etc.) provide a stable, documented result contract independent of ORM column naming.

### 2.2 Queries as Module-Level Constants
Queries are defined as plain string constants rather than functions or builders.

**Rationale:**
- **Simplicity and reviewability:** SQL is fully visible in one place, making it easy to review, lint, and audit.
- **Reusability:** Any execution layer can import and run the same query string.
- **Immutability:** As constants, the queries cannot be accidentally mutated at runtime.

### 2.3 Trade-offs
| Benefit | Cost |
| --- | --- |
| Tunable, high-performance reporting SQL | Manual maintenance if the schema changes |
| Decoupled from ORM model churn | No compile-time schema validation |
| Clear, auditable query text | Parameterization must be handled by the caller |

---

## 3. Component Diagram

```dot
digraph reports_queries {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_module {
        label="backend.app.reports.queries";
        style=dashed;
        color=gray;

        USER_ACTIVITY_SQL [label="USER_ACTIVITY_SQL\n(str constant)", shape=note, style=filled, fillcolor="#eef6ff"];
    }

    subgraph cluster_db {
        label="Database (read-only, no ORM)";
        style=dashed;
        color=gray;

        users     [label="users\n(table)", shape=cylinder, fillcolor="#f0fff0", style=filled];
        audit_log [label="audit_log\n(table)", shape=cylinder, fillcolor="#f0fff0", style=filled];
    }

    executor [label="Query Executor\n(caller / reporting service)", shape=component];

    executor -> USER_ACTIVITY_SQL [label="imports"];
    executor -> users            [label="executes SQL", style=dashed];
    USER_ACTIVITY_SQL -> users    [label="SELECT / GROUP BY"];
    USER_ACTIVITY_SQL -> audit_log [label="LEFT JOIN"];
}
```

---

## 4. Interfaces

### 4.1 Exposed API
The module's public interface is a set of importable string constants.

| Symbol | Type | Description |
| --- | --- | --- |
| `USER_ACTIVITY_SQL` | `str` | Aggregated per-user activity report query. |

**Import example:**
```python
from backend.app.reports.queries import USER_ACTIVITY_SQL
```

### 4.2 Query Result Contract: `USER_ACTIVITY_SQL`
The query returns one row per user with the following columns:

| Column | Source | Type (logical) | Description |
| --- | --- | --- | --- |
| `user_id` | `users.id` | integer | Unique user identifier. |
| `username` | `users.username` | string | User's login/display name. |
| `status` | `users.status` | string/enum | Account status. |
| `action_count` | `COUNT(audit_log.id)` | integer | Number of audit events attributed to the user (0 if none). |
| `last_action_at` | `MAX(audit_log.created_at)` | timestamp / null | Most recent action time (`NULL` if no actions). |

**Ordering:** Rows are sorted by `action_count DESC` (most active users first).

### 4.3 Integration Points
- **Upstream (schema dependency):** Relies on the `users` (`id`, `username`, `status`) and `audit_log` (`id`, `actor_id`, `created_at`) table shapes.
- **Downstream (execution dependency):** A caller — typically a reporting service or DB access layer — is responsible for executing the query and mapping its result set.

---

## 5. Data Flow

The module is passive; it supplies the SQL that drives the flow. Actual data movement occurs when a caller executes the query.

```dot
digraph data_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    caller   [label="1. Reporting caller\nimports USER_ACTIVITY_SQL"];
    db       [label="2. Database engine\nexecutes SQL", shape=component];
    users    [label="users", shape=cylinder];
    audit    [label="audit_log", shape=cylinder];
    result   [label="3. Result set\n(user_id, username, status,\naction_count, last_action_at)", shape=note];
    consumer [label="4. Report / API / export"];

    caller -> db      [label="send SQL text"];
    db -> users       [label="scan + group"];
    db -> audit       [label="left join on actor_id"];
    users -> result;
    audit -> result;
    result -> consumer [label="rows sorted by action_count DESC"];
}
```

### Flow Description
1. A caller imports `USER_ACTIVITY_SQL`.
2. The database engine executes the query, joining `users` to `audit_log` via `audit_log.actor_id = users.id`.
3. Rows are aggregated per user and sorted by activity volume.
4. The result set is consumed by the reporting layer (e.g., serialized to an API response or exported).

The `LEFT JOIN` guarantees that users with **no** audit activity still appear, with `action_count = 0` and `last_action_at = NULL`.

---

## 6. Extension Points

### 6.1 Adding New Reports
The primary extension pattern is to add new query constants alongside the existing one:

```python
TOP_USERS_LAST_30_DAYS_SQL = """
SELECT u.id AS user_id, COUNT(a.id) AS action_count
FROM users u
JOIN audit_log a ON a.actor_id = u.id
WHERE a.created_at >= NOW() - INTERVAL '30 days'
GROUP BY u.id
ORDER BY action_count DESC
"""
```

**Convention:** Name constants with a descriptive `<SUBJECT>_SQL` suffix to signal their role and keep the module scannable.

### 6.2 Parameterization
The current query is static. When adding filtered reports (e.g., by date range or status), introduce **bind parameters** rather than string interpolation to preserve safety:

```python
USER_ACTIVITY_BY_STATUS_SQL = """
SELECT u.id AS user_id, COUNT(a.id) AS action_count
FROM users u
LEFT JOIN audit_log a ON a.actor_id = u.id
WHERE u.status = :status
GROUP BY u.id
"""
```

Callers bind `:status` at execution time. This keeps the module free of runtime logic while supporting dynamic filters.

### 6.3 Recommended Boundaries
To keep the module focused and maintainable:
- **Keep:** SQL text, column aliasing, and query-level documentation.
- **Do not add:** connection handling, result mapping, or business logic — these belong in the executing service/repository layer.

### 6.4 Schema Change Awareness
Because these queries bypass the ORM, they are **not** automatically validated against schema migrations. When the `users` or `audit_log` schema changes:
- Review affected constants in this module.
- Update column references and aliases as needed.
- Add integration tests that execute each query against a representative database to catch drift early.

---

*This document reflects the current single-query state of the module. Update the Interfaces and Component Diagram sections as new report queries are introduced.*