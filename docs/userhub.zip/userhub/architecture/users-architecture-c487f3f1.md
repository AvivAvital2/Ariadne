---
id: c487f3f1-08b9-529d-80ec-64882567435e
type: architecture
title: "Users Architecture"
created_at: 2026-07-30T17:24:04.059038+00:00
updated_at: 2026-07-30T17:24:04.059053+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  module_name: "backend.app.routers.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

# User Management Router — Architecture Documentation

**Module**: `backend.app.routers.users`
**Route Prefix**: `/api/users` (plus the standalone `/api/me` endpoint)

---

## 1. Component Overview

The `users` router is the HTTP-facing layer for user administration in the backend. It exposes a set of REST endpoints under `/api/users` (with the `/api/me` identity endpoint as a sibling) and delegates all business logic to the `app.services.users` service module.

Its responsibilities are deliberately narrow and follow a **thin controller** pattern:

- **Request routing** — map HTTP verbs/paths to handler functions.
- **Authorization enforcement** — gate each endpoint behind a specific permission via FastAPI dependencies.
- **Request/response serialization** — validate inbound payloads and shape outbound responses using Pydantic schemas.
- **Error translation** — convert domain-level absence (e.g. missing user) into HTTP status codes.

It does **not** contain persistence logic, permission-resolution logic, or audit logic — all of which live in the service layer.

### Endpoint Summary

| Function | Method & Path | Permission Required | Purpose |
|---|---|---|---|
| `whoami` | `GET /api/me` | *authenticated only* | Return acting user + effective permissions |
| `list_users` | `GET /api/users` | `users:read` | List users, optionally filtered by status |
| `get_user` | `GET /api/users/{user_id}` | `users:read` | Fetch a single user |
| `create_user` | `POST /api/users` | `users:create` | Create a user |
| `update_user` | `PUT /api/users/{user_id}` | `users:edit` | Update profile fields |
| `set_user_status` | `PATCH /api/users/{user_id}/status` | `users:deactivate` | Deactivate/reactivate |
| `assign_roles` | `POST /api/users/{user_id}/roles` | `roles:manage` | Replace role assignments |
| `delete_user` | `DELETE /api/users/{user_id}` | `users:delete` | Delete a user |

---

## 2. Design Decisions

### 2.1 Full paths in decorators (no `APIRouter(prefix=...)`)
Routes declare their **complete path** in each decorator (e.g. `/api/users/{user_id}/status`) rather than composing them from a router-level prefix. As documented in the module docstring, this keeps route templates **verbatim** so they match the frontend's `fetch` URLs exactly. The trade-off is minor repetition in exchange for grep-ability and 1:1 alignment with the client.

### 2.2 Thin router, fat service
Every handler is a short adapter that unpacks the validated payload and forwards it to `user_service`. This isolates FastAPI/HTTP concerns from domain logic, enabling the service to be unit-tested independently of the web framework and reused across other entry points.

### 2.3 Permission-per-endpoint via dependency injection
Authorization is expressed declaratively through `Depends(require_permission(...))`. Each endpoint names the exact permission it requires (from the `Permission` enum), so the access-control surface is auditable by reading the router alone. The `/api/me` endpoint uses `current_actor` (authentication only), since a user must always be able to inspect their own identity.

### 2.4 Actor propagation for auditability
Mutating endpoints pass `actor_id=actor.id` into the service. This gives the domain layer the identity of the caller, presumably for audit trails and authorization sub-checks that the router does not perform.

### 2.5 Schema-driven contracts
Inbound and outbound shapes are governed by Pydantic schemas (`UserCreate`, `UserUpdate`, `UserOut`, etc.). Response models are declared on the decorators (`response_model=...`), so serialization and field-filtering happen automatically and consistently.

---

## 3. Component Diagram

```dot
digraph users_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_client {
        label="Frontend API Client";
        style=dashed;
        client [label="fetch() calls\n/api/users/*"];
    }

    subgraph cluster_router {
        label="app.routers.users";
        style=filled; color="#eef";
        whoami        [label="whoami\nGET /api/me"];
        list_users    [label="list_users\nGET /api/users"];
        get_user      [label="get_user\nGET /api/users/{id}"];
        create_user   [label="create_user\nPOST /api/users"];
        update_user   [label="update_user\nPUT /api/users/{id}"];
        set_status    [label="set_user_status\nPATCH .../status"];
        assign_roles  [label="assign_roles\nPOST .../roles"];
        delete_user   [label="delete_user\nDELETE /api/users/{id}"];
    }

    subgraph cluster_deps {
        label="Injected Dependencies";
        style=dashed;
        security  [label="app.security\ncurrent_actor /\nrequire_permission"];
        get_db    [label="app.database\nget_db (Session)"];
        schemas   [label="app.schemas\nPydantic models"];
    }

    service [label="app.services.users\n(business logic)", shape=box3d];
    db      [label="Database\n(SQLAlchemy models)", shape=cylinder];

    client -> whoami;
    client -> list_users;
    client -> get_user;
    client -> create_user;
    client -> update_user;
    client -> set_status;
    client -> assign_roles;
    client -> delete_user;

    // Cross-cutting dependency wiring (representative)
    security -> create_user [style=dotted, label="authz"];
    security -> whoami      [style=dotted, label="auth"];
    get_db   -> list_users  [style=dotted, label="session"];
    schemas  -> create_user [style=dotted, label="validate"];

    // All handlers delegate to the service
    whoami       -> service;
    list_users   -> service;
    get_user     -> service;
    create_user  -> service;
    update_user  -> service;
    set_status   -> service;
    assign_roles -> service;
    delete_user  -> service;

    service -> db [label="ORM queries"];
}
```

---

## 4. Interfaces

### 4.1 Inbound HTTP Interface
The router exposes REST endpoints consumed by the frontend API client. Path templates are stable contracts (see §2.1). Request bodies and responses are typed:

- **Request schemas**: `UserCreate`, `UserUpdate`, `UserStatusUpdate`, `RoleAssignment`
- **Response schemas**: `UserOut` (single/list), `CurrentUser` (identity)
- **Status codes**: `201` on create, `204` on delete, `404` for a missing user (via explicit `HTTPException`), `403` implicitly from `require_permission`.

### 4.2 Dependency Injection Interface
Handlers integrate with framework and infrastructure via FastAPI `Depends`:

| Dependency | Source | Provides |
|---|---|---|
| `get_db` | `app.database` | A per-request SQLAlchemy `Session` |
| `current_actor` | `app.security` | The authenticated `User` |
| `require_permission(perm)` | `app.security` | A dependency factory returning the actor iff they hold `perm`; otherwise raises |

### 4.3 Service Interface (downstream)
The router calls into `app.services.users`:

- `effective_permissions(actor)`
- `list_users(db, status=...)`
- `get_user(db, user_id)`
- `create_user(db, actor_id, username, email, full_name, role_ids)`
- `update_user(db, actor_id, user_id, email, full_name)`
- `set_status(db, actor_id, user_id, status)`
- `assign_roles(db, actor_id, user_id, role_ids)`
- `delete_user(db, actor_id, user_id)`

The presence of `db` and `actor_id` in these signatures defines the integration contract: the router owns session acquisition and identity, the service owns the transaction/logic.

---

## 5. Data Flow

A representative mutating request (`create_user`) flows as follows:

```dot
digraph flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    req      [label="1. HTTP POST /api/users\n(JSON body)"];
    validate [label="2. Pydantic validates\nbody -> UserCreate"];
    authz    [label="3. require_permission('users:create')\nresolves actor or 403"];
    session  [label="4. get_db yields Session"];
    handler  [label="5. create_user() handler\nunpacks payload + actor.id"];
    service  [label="6. user_service.create_user(...)\napplies business rules"];
    persist  [label="7. SQLAlchemy commits\nnew User row"];
    respond  [label="8. UserOut serialization\n201 Created"];

    req -> validate -> authz -> session -> handler -> service -> persist -> respond;
}
```

Key characteristics:

- **Authorization precedes logic** — the permission dependency runs before the handler body, so unauthorized requests never reach the service or database.
- **Read paths** (`list_users`, `get_user`) skip `actor_id` propagation and return ORM objects directly; `get_user` adds an explicit `404` guard when the service returns `None`.
- **Identity path** (`whoami`) does not touch the database via `get_db`; it derives effective permissions from the already-resolved actor through the service helper.
- **Serialization boundary** — ORM `User` instances returned by handlers are transparently mapped to `UserOut`/`CurrentUser` by FastAPI's `response_model`.

---

## 6. Extension Points

### 6.1 Adding a new user endpoint
Follow the established pattern:
1. Declare the full path in the decorator to preserve frontend URL alignment.
2. Attach the appropriate `require_permission(Permission.X.value)` dependency.
3. Inject `db` and (for mutations) forward `actor_id` to a new service function.
4. Bind request/response Pydantic schemas.

### 6.2 Changing authorization requirements
Access control is centralized in the `require_permission` dependency and the `Permission` enum. To re-gate an endpoint, swap the permission constant — no handler-body changes needed. New permissions are introduced in `app.constants.Permission` and enforced by referencing them here.

### 6.3 Evolving request/response contracts
Extend or version the schemas in `app.schemas`. Because the router declares `response_model`, output shape changes are driven from the schema layer without editing handler logic.

### 6.4 Business-rule customization
All domain behavior (validation beyond schema, audit logging, role reconciliation, cascade rules) belongs in `app.services.users`. The router should remain a thin adapter; extend the service rather than adding logic to handlers.

### 6.5 Cross-cutting concerns
Authentication (`current_actor`) and session management (`get_db`) are injected, so alternate implementations (e.g. a mock actor in tests, a read-replica session) can be substituted via FastAPI dependency overrides without modifying router code.

---

*Terminology note: throughout this document, **actor** refers to the authenticated caller resolved by `current_actor`, and **service layer** refers to `app.services.users`, consistent with the source code.*