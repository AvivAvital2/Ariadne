---
id: cd7b4f16-4231-59ab-ad13-bb7f83414977
type: architecture
title: "Security Architecture"
created_at: 2026-07-30T17:24:43.295081+00:00
updated_at: 2026-07-30T17:24:43.295094+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  module_name: "backend.app.security"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Security Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

# Architecture: `backend.app.security`

## 1. Component Overview

The `backend.app.security` module is the **server-side permission enforcement point** for the application's HTTP API. It provides FastAPI dependencies that:

- Resolve the *acting user* from an incoming request.
- Optionally gate access to an endpoint based on a required permission string.

The module embodies a key security principle: **the server enforces permissions authoritatively, regardless of what the client UI chooses to show or hide.** The frontend may use the same permission strings to hide controls, but that is purely cosmetic — this module is the enforcement boundary.

### Responsibilities

| Responsibility | Function |
|----------------|----------|
| Resolve the acting user (no gate) | `current_actor` |
| Build a permission-gated dependency | `require_permission` |
| Enforce the gate at request time | `checker` (closure returned by `require_permission`) |

---

## 2. Design Decisions

### Header-based actor identity (`X-Actor-Id`)
The acting user is identified via the `X-Actor-Id` HTTP header rather than a session token. This keeps the security surface simple and delegates identity resolution to a single service call (`user_service.get_user`). It is a deliberately thin mechanism — the actor identity comes from a trusted header supplied by an upstream layer.

### Dependency-factory pattern (`require_permission`)
Rather than a single decorator, `require_permission(permission)` is a **factory** that returns a fresh FastAPI dependency (`checker`) bound to a specific permission string. This allows routers to declare intent declaratively:

```python
@router.post("/users/{id}/deactivate",
             dependencies=[Depends(require_permission("users:deactivate"))])
```

Each endpoint gets its own closure capturing its required permission, keeping the check self-documenting at the route definition.

### Separation of authentication vs. authorization
- `current_actor` performs **authentication only** (who are you?) — returns `401` on unknown actor.
- `checker` performs **authentication + authorization** (who are you, *and* may you do this?) — returns `401` on unknown actor, `403` on missing permission.

This split lets endpoints like `/api/me` learn a user's own identity/permissions without needing a specific permission, while protected endpoints enforce a gate.

### String-based permissions
Permissions are opaque strings (e.g. `"users:deactivate"`). The **same strings are shared with the frontend**, keeping a single vocabulary across the stack. Authorization logic itself lives in `user_service.actor_has_permission`, keeping this module focused on request-plumbing rather than permission-modeling.

---

## 3. Component Diagram

```dot
digraph security {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_security {
        label="backend.app.security";
        style=dashed;

        current_actor    [label="current_actor()\n(auth only)"];
        require_permission [label="require_permission(perm)\n(dependency factory)"];
        checker          [label="checker()\n(auth + authz)", style="rounded,filled", fillcolor="#eef"];
    }

    subgraph cluster_deps {
        label="Dependencies";
        style=dotted;

        get_db           [label="app.database.get_db"];
        user_service     [label="app.services.users\n(get_user,\nactor_has_permission)"];
        User             [label="app.models.User", shape=note];
        fastapi          [label="fastapi\n(Depends, Header,\nHTTPException)", shape=component];
    }

    router  [label="API Routers\n(callers)", shape=folder];

    // structure
    require_permission -> checker [label="returns"];

    // runtime calls
    current_actor -> get_db       [label="Depends"];
    current_actor -> user_service [label="get_user"];
    checker       -> get_db       [label="Depends"];
    checker       -> user_service [label="get_user\nactor_has_permission"];

    current_actor -> User [label="returns", style=dashed];
    checker       -> User [label="returns", style=dashed];

    current_actor -> fastapi [style=dotted];
    checker       -> fastapi [style=dotted];

    // usage
    router -> current_actor     [label="Depends", color="#337"];
    router -> require_permission [label="Depends(require_permission(...))", color="#337"];
}
```

---

## 4. Interfaces

### `current_actor(x_actor_id, db) -> User`
FastAPI dependency for authenticated-but-ungated endpoints.

| Aspect | Detail |
|--------|--------|
| **Input** | `X-Actor-Id` header (int, required) |
| **Injected** | `db: Session` via `Depends(get_db)` |
| **Returns** | `User` — the resolved acting user |
| **Errors** | `401 unknown actor` if `get_user` returns `None` |
| **Typical use** | `/api/me` — lets the frontend discover its own identity/permissions |

### `require_permission(permission: str) -> Callable`
Factory producing a permission-gated dependency.

| Aspect | Detail |
|--------|--------|
| **Input** | `permission` — permission string (e.g. `"users:deactivate"`) |
| **Returns** | `checker`, a FastAPI dependency callable |

### `checker(x_actor_id, db) -> User` (returned closure)
The enforcement dependency.

| Aspect | Detail |
|--------|--------|
| **Input** | `X-Actor-Id` header (int, required) |
| **Injected** | `db: Session` via `Depends(get_db)` |
| **Captured** | `permission` from the enclosing factory |
| **Returns** | `User` — the acting user (usable downstream) |
| **Errors** | `401 unknown actor`; `403 missing permission: <permission>` |

### Integration points
- **Upstream:** API routers attach these via `Depends(...)`.
- **Downstream:** `app.services.users.get_user` and `app.services.users.actor_has_permission` implement the actual data lookup and permission logic.
- **Data:** `app.database.get_db` supplies a request-scoped SQLAlchemy `Session`.

---

## 5. Data Flow

**Gated endpoint (via `require_permission`):**

```dot
digraph flow {
    rankdir=TB;
    node [shape=box, fontname="Helvetica", style=rounded];

    req    [label="Incoming request\n+ X-Actor-Id header"];
    fastapi[label="FastAPI resolves\nDepends(checker)"];
    lookup [label="user_service.get_user(db, actor_id)"];
    a401   [label="401 unknown actor", shape=box, color=red];
    perm   [label="user_service.actor_has_permission(actor, permission)"];
    a403   [label="403 missing permission", shape=box, color=red];
    ok     [label="Endpoint runs\n(actor available)", color="#080"];

    req -> fastapi -> lookup;
    lookup -> a401  [label="actor is None"];
    lookup -> perm  [label="actor found"];
    perm  -> a403   [label="false"];
    perm  -> ok     [label="true"];
}
```

1. A request arrives carrying the `X-Actor-Id` header.
2. FastAPI resolves the dependency and injects a DB session.
3. The actor is looked up. If unknown → **401**.
4. `actor_has_permission` is evaluated against the captured permission string.
   - Missing permission → **403 missing permission: `<permission>`**.
   - Granted → the `User` object is returned and passed into the endpoint handler.

`current_actor` follows the same path but skips step 4 (no permission gate).

---

## 6. Extension Points

### Adding permission checks to new endpoints
Attach a gate declaratively — no changes to this module required:

```python
@router.delete(
    "/projects/{id}",
    dependencies=[Depends(require_permission("projects:delete"))],
)
def delete_project(...): ...
```

To also *use* the actor inside the handler, capture the return value:

```python
def deactivate_user(actor: User = Depends(require_permission("users:deactivate"))):
    ...  # actor is the enforced, authenticated caller
```

### Customizing permission semantics
Permission evaluation is delegated to `user_service.actor_has_permission`. New permission models (roles, hierarchies, wildcard matching) can be introduced **entirely within the service layer** without touching `security.py`. This is the primary extension seam.

### Changing the identity mechanism
The actor is resolved from the `X-Actor-Id` header inside both `current_actor` and `checker`. To adopt tokens/sessions:
- Introduce a shared resolver (e.g. `resolve_actor(request, db) -> User`) and call it from both functions to avoid duplicating the lookup/`401` logic — currently that logic is repeated in the two entry points.

### Suggested refactor for maintainability
`current_actor` and the first half of `checker` are identical (header read → lookup → `401`). Extracting a shared helper would reduce drift as the identity mechanism evolves:

```python
def _resolve_actor(db, actor_id) -> User:
    actor = user_service.get_user(db, actor_id)
    if actor is None:
        raise HTTPException(status_code=401, detail="unknown actor")
    return actor
```

Both entry points could then delegate to it, keeping enforcement behavior consistent.