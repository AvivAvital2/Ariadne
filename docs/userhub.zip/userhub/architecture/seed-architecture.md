---
id: a8743bea-1b6b-5cec-ae9c-a6d87278820f
type: architecture
title: "Seed Architecture"
created_at: 2026-07-30T17:24:51.723707+00:00
updated_at: 2026-07-30T17:24:51.723722+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  module_name: "backend.app.seed"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Seed Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

# Architecture Documentation: `backend.app.seed`

## 1. Component Overview

The `backend.app.seed` module provides **first-run database bootstrapping** for the application. Its single public entry point, `seed_if_empty`, populates a fresh database with the minimum baseline data required for the application to be usable on first launch:

- **Permissions** — the full permission catalog derived from the `Permission` enum.
- **Roles** — three canonical roles (`admin`, `editor`, `viewer`) with distinct permission sets.
- **Users** — three illustrative users (`root`, `alice`, `bob`) mapped to those roles.
- **Audit history** — roughly a week of synthetic audit log entries so dashboards and reporting views have realistic data to render immediately.

The module's core responsibility is to guarantee that a fresh checkout works with **zero manual setup steps**, while remaining safe to run repeatedly.

---

## 2. Design Decisions

### Idempotency via presence check
The function short-circuits if any `Permission` rows exist (`db.query(Permission).count() > 0`). This makes seeding safe to call on every startup — the first run populates data, subsequent runs are no-ops. The `Permission` table is used as the sentinel because permissions are always the first thing inserted, so their presence reliably indicates a populated database.

**Rationale:** Avoids requiring migration state tracking or a separate "seeded" flag; the data itself is the source of truth.

### Startup-time invocation
Seeding is triggered from the app's lifespan hook in `app/main.py` rather than a separate CLI command. This ensures the guarantee "fresh checkout runs immediately" holds without operator intervention.

**Trade-off:** Seeding logic runs inside the application process. Because it is idempotent and fast, the startup cost is negligible after the first run.

### Explicit `flush()` staging
The function uses `db.flush()` at three points to assign primary keys before dependent records are created:
1. After permissions — so roles can reference permission objects.
2. After roles — so users can reference role objects.
3. After users — so their generated `id`s are available for building audit history.

A single `db.commit()` at the end wraps the entire seed operation in one transaction.

**Rationale:** All-or-nothing seeding — if any insert fails, the whole bootstrap rolls back, preventing a partially seeded (and therefore inconsistent) database.

### Data-driven audit history
`_seed_audit_history` encodes events as a list of tuples (`days_ago`, `hour`, `action`, `actor_idx`, `target_idx`, `detail`). Actor and target indices reference into the `actors`/`targets` lists using modular indexing (`% len(...)`), making the event table resilient to changes in list length.

**Rationale:** Keeps the illustrative timeline compact and easy to edit as a lookup table rather than repeated object construction.

---

## 3. Component Diagram

```dot
digraph seed_architecture {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_seed {
        label = "app.seed";
        style = dashed;
        seed_if_empty [label="seed_if_empty()\n(public entry point)"];
        seed_audit [label="_seed_audit_history()\n(private helper)"];
    }

    subgraph cluster_deps {
        label = "app dependencies";
        style = dashed;
        constants [label="app.constants\n(Permission, UserStatus,\nAuditAction)"];
        models [label="app.models\n(Permission, Role,\nUser, AuditLog)"];
    }

    caller [label="app.main\n(lifespan startup)", shape=box, style="rounded,bold"];
    db [label="SQLAlchemy Session\n(Database)", shape=cylinder];

    caller -> seed_if_empty [label="invokes on startup"];
    seed_if_empty -> seed_audit [label="calls"];
    seed_if_empty -> constants [label="reads enums"];
    seed_if_empty -> models [label="constructs ORM objects"];
    seed_audit -> constants [label="reads AuditAction"];
    seed_audit -> models [label="constructs AuditLog"];
    seed_if_empty -> db [label="query / add / commit"];
    seed_audit -> db [label="add"];
}
```

---

## 4. Interfaces

### Public API

| Function | Signature | Returns | Description |
|----------|-----------|---------|-------------|
| `seed_if_empty` | `seed_if_empty(db: Session) -> bool` | `True` if seeding occurred, `False` if already populated | Idempotent bootstrap of baseline data. |

### Private API

| Function | Signature | Description |
|----------|-----------|-------------|
| `_seed_audit_history` | `_seed_audit_history(db, *, actors: list[int], targets: list[int]) -> None` | Inserts the illustrative audit timeline. Keyword-only `actors`/`targets` are lists of user IDs referenced by index in the internal event table. |

### Integration Points

- **Input:** A live SQLAlchemy `Session` (`db`) is injected by the caller. The module does not own session lifecycle or connection setup.
- **Caller:** `app/main.py` lifespan startup. This is the sole documented invocation site.
- **Enum contracts:** Depends on `app.constants` for `Permission`, `UserStatus`, and `AuditAction` enums. Permission names are derived from enum members (`p.value` for `name`, humanized `p.name` for `description`).
- **ORM contracts:** Depends on `app.models` for the `Permission`, `Role`, `User`, and `AuditLog` mapped classes and their relationships (`Role.permissions`, `User.roles`).

---

## 5. Data Flow

```dot
digraph seed_dataflow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    start [label="seed_if_empty(db)", shape=ellipse];
    check [label="Permission count > 0?", shape=diamond];
    noop [label="return False\n(no-op)", shape=ellipse];

    perms [label="1. Build Permission objects\nfrom Permission enum\n-> flush"];
    roles [label="2. Build admin / editor / viewer\nRoles referencing permissions\n-> flush"];
    users [label="3. Build root / alice / bob\nUsers referencing roles\n-> flush (assigns ids)"];
    audit [label="4. _seed_audit_history()\nbuild ~1 week of AuditLog rows"];
    commit [label="db.commit()\nreturn True", shape=ellipse];

    start -> check;
    check -> noop [label="yes (already seeded)"];
    check -> perms [label="no (empty)"];
    perms -> roles;
    roles -> users;
    users -> audit;
    audit -> commit;
}
```

**Narrative:**
1. The caller passes an active session.
2. `seed_if_empty` checks the sentinel (`Permission` count). If non-empty, it returns `False` immediately.
3. Permissions are created for every member of the `Permission` enum and staged with `flush`.
4. Three roles are created, each holding a subset of the permission objects. Staged with `flush`.
5. Three users are created, each assigned one role. `flush` assigns their database IDs.
6. `_seed_audit_history` uses the newly assigned user IDs (via `actors`/`targets`) to build a fixed timeline of audit events spanning the last 7 days.
7. A single `commit` persists all of the above atomically, and the function returns `True`.

---

## 6. Extension Points

The module is intentionally simple and edited directly rather than configured externally. Common customizations:

### Adding permissions
No change needed here. Permissions are generated from the `Permission` enum in `app.constants`. Adding a new enum member automatically includes it in the `admin` role (which receives *all* permissions). To grant it to `editor` or `viewer`, add the corresponding `perms[...]` entry to those roles.

### Adding or modifying roles
Extend the block that constructs `admin`, `editor`, and `viewer`. Each `Role` takes a `name`, `description`, and an explicit `permissions` list selected from the `perms` dict. Remember to add new roles to the `db.add_all([...])` call.

### Adding seed users
Extend the user construction block. Each `User` references one or more roles. New users must be included in `db.add_all([...])` and, if they should appear in the audit timeline, their IDs added to the `actors`/`targets` arguments passed to `_seed_audit_history`.

### Customizing audit history
Edit the `events` list in `_seed_audit_history`. Each tuple follows the schema:

```
(days_ago, hour, action, actor_idx, target_idx, detail)
```

- `actor_idx` / `target_idx` index into the `actors` / `targets` lists (modular, so out-of-range values wrap safely).
- `action` must be an `AuditAction` enum member.
- Timestamps are computed as UTC `now - days_ago` normalized to the given `hour`.

### Changing the idempotency sentinel
If the seeding order changes such that permissions are no longer inserted first, update the presence check in `seed_if_empty` to test whichever table is guaranteed to be populated by a successful seed.

---

### Notes & Caveats
- **Not a migration tool:** This component only *populates* data; it does not create or alter schema. Table creation is expected to be handled elsewhere (migrations or `create_all`) before `seed_if_empty` runs.
- **Development/demo orientation:** The `root@userhub.dev` credentials, illustrative users, and synthetic audit history are intended for development and demonstration environments. Production deployments should review whether these baseline records are appropriate.