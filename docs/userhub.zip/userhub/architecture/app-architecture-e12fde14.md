---
id: e12fde14-2880-50b8-ba09-78f4ca24cb8b
type: architecture
title: "App Architecture"
created_at: 2026-07-30T17:26:28.128776+00:00
updated_at: 2026-07-30T17:26:28.128790+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx
metadata:
  module_name: "frontend.src.App"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# App Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx`

# Architecture Documentation: `App` Component

## 1. Component Overview

`App` is the **root component and application shell** for the frontend administration interface. It orchestrates the top-level layout, manages global navigation state, and bootstraps the current user session.

### Responsibilities

- **Layout composition**: Assembles the persistent chrome (`Sidebar`, `Topbar`) around a swappable content area.
- **Navigation state**: Owns the active view selection and routes between feature panels.
- **Session bootstrapping**: Loads the current authenticated user (`actor`) on mount and propagates it to descendant components.
- **Global error surfacing**: Displays initialization errors (e.g., failure to load the current user).

The `App` component is intentionally thin — it delegates all domain logic to child components and the API client. It functions as a **container/orchestrator** rather than a feature implementation.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Client-side view switching via `useState`** instead of a router library | The application has a small, fixed set of top-level views (`NAV`). A lightweight state-based switch avoids router dependency and configuration overhead. Trade-off: no URL-based deep linking or browser history support. |
| **`actor` fetched once at the root and passed down as props** | Provides a single source of truth for the authenticated user. Prop drilling to feature components (`UserList`, `RoleManager`) keeps the auth context explicit and avoids a global store for a shallow tree. |
| **Declarative `NAV` config array** | Navigation items and their labels are defined in one place, decoupling the `Sidebar` (which renders items) from the content switch (which resolves the title and active view). |
| **Conditional rendering per view** | Only the active view is mounted, so inactive feature components do not run effects or hold state. Trade-off: view state is not preserved across navigation. |
| **Error state at the shell level** | Bootstrapping errors are shown in a consistent location regardless of the active view. |

---

## 3. Component Diagram

```dot
digraph AppArchitecture {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  App [label="App\n(root shell)", style="rounded,filled", fillcolor="#e8f0fe"];

  subgraph cluster_chrome {
    label="Persistent Chrome";
    style=dashed;
    Sidebar [label="Sidebar\n(navigation)"];
    Topbar  [label="Topbar\n(title + actor)"];
  }

  subgraph cluster_views {
    label="Content Views (one active at a time)";
    style=dashed;
    Dashboard   [label="Dashboard"];
    UserList    [label="UserList"];
    RoleManager [label="RoleManager"];
    AuditLog    [label="AuditLog"];
  }

  api [label="api/client.js\n(getCurrentUser)", shape=cylinder, fillcolor="#fef7e0", style=filled];

  App -> Sidebar   [label="items, active,\nonNavigate, actor"];
  App -> Topbar    [label="title, actor"];
  App -> Dashboard   [label="view=dashboard"];
  App -> UserList    [label="view=users\n(actor)"];
  App -> RoleManager [label="view=roles\n(actor)"];
  App -> AuditLog    [label="view=audit"];

  App -> api [label="getCurrentUser()", style=dashed];
  Sidebar -> App [label="onNavigate(key)", style=dotted, constraint=false];
}
```

**Legend**
- Solid arrows: prop-based rendering relationships.
- Dashed arrow: asynchronous API call.
- Dotted arrow: callback (event flows upward).

---

## 4. Interfaces

### Inbound

`App` is the top-level component and takes **no props**.

### Outbound — Child Component Props

| Child | Props | Purpose |
|-------|-------|---------|
| `Sidebar` | `items`, `active`, `onNavigate`, `actor` | Renders navigation; reports selection via `onNavigate(key)`. |
| `Topbar` | `title`, `actor` | Displays the active view label and current user. |
| `Dashboard` | *(none)* | Landing view. |
| `UserList` | `actor` | User management, scoped by acting user. |
| `RoleManager` | `actor` | Role management, scoped by acting user. |
| `AuditLog` | *(none)* | Audit trail view. |

### Integration Points — API Client

| Function | Contract | Consumer |
|----------|----------|----------|
| `api.getCurrentUser()` | Returns a `Promise` resolving to the actor object; rejects with an `Error` having a `.message` field. | Called once in the mount effect. |

### Navigation Contract

The `NAV` array defines the navigation model:

```js
{ key: string, label: string }
```

- `key` — unique view identifier used by the content switch and `active` state.
- `label` — human-readable text used by the `Sidebar` and `Topbar` title.

---

## 5. Data Flow

### Initialization Flow

```dot
digraph InitFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  mount  [label="App mounts"];
  effect [label="useEffect fires"];
  call   [label="api.getCurrentUser()"];
  ok     [label="setActor(user)", fillcolor="#e6f4ea", style=filled];
  fail   [label="setError(e.message)", fillcolor="#fce8e6", style=filled];
  render [label="Re-render:\nchrome + views\nreceive actor/error"];

  mount -> effect -> call;
  call -> ok   [label="resolve"];
  call -> fail [label="reject"];
  ok -> render;
  fail -> render;
}
```

1. On mount, the effect calls `api.getCurrentUser()`.
2. On success, `actor` is set and flows down to `Sidebar`, `Topbar`, `UserList`, and `RoleManager`.
3. On failure, `error` is set and rendered as a banner in the content area.

### Navigation Flow

1. `Sidebar` invokes `onNavigate(key)` → `setView(key)`.
2. `App` re-renders; `title` is recomputed from `NAV` and the content switch mounts the matching view.
3. The previous view unmounts (losing its local state).

### Data Ownership

- **`actor`** — owned by `App`, read-only downstream.
- **`view`** — owned by `App`, mutated only via the `Sidebar` callback.
- **`error`** — owned by `App`, set on bootstrap failure only.

---

## 6. Extension Points

### Adding a New View

1. Add an entry to the `NAV` array:
   ```js
   { key: "settings", label: "Settings" }
   ```
2. Import the new component and add a conditional branch:
   ```js
   {view === "settings" && <Settings actor={actor} />}
   ```

The `Sidebar` and `Topbar` require no changes — they consume `NAV` and the resolved `title` automatically.

### Customization Hooks

| Extension | Approach |
|-----------|----------|
| **Global user context** | Replace prop drilling of `actor` with a React Context provider wrapping the layout if the tree deepens. |
| **URL routing** | Swap the `useState(view)` + conditional switch for a router (e.g., React Router) while retaining `NAV` as the route table. |
| **Additional session data** | Extend the mount effect (or add effects) to load further global state; store alongside `actor`. |
| **Error handling strategy** | The current shell-level `error` banner can be replaced with a toast system or error boundary for richer handling. |

### Recommended Guardrails

- Keep `App` free of domain logic — new features belong in dedicated view components.
- Preserve the `NAV`-driven pattern so navigation remains config-driven and consistent across `Sidebar`/`Topbar`.
- If view state must persist across navigation, prefer lifting that state into `App` or a store rather than keeping mounts alive.