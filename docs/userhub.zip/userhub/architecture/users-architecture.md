---
id: 9dee2533-5b5d-524e-acfe-721ed12742a1
type: architecture
title: "Users Architecture"
created_at: 2026-07-30T17:25:47.090418+00:00
updated_at: 2026-07-30T17:25:47.090432+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  module_name: "backend.app.services.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

# User Lifecycle Service — Architecture Documentation

**Module:** `backend.app.services.users`
**Layer:** Service / Domain logic

---

## 1. Component Overview

The `users` service module encapsulates all **user lifecycle operations** for the backend. It sits in the service layer between the HTTP route handlers (FastAPI) and the persistence layer (SQLAlchemy ORM), providing a coherent, transaction-aware API for creating, reading, updating, and deprovisioning users, as well as managing their roles and permissions.

### Responsibilities

| Concern | Functions |
|---|---|
| **Read/query** | `get_user`, `list_users` |
| **Authorization introspection** | `actor_has_permission`, `effective_permissions` |
| **Mutation (write + audit)** | `create_user`, `update_user`, `set_status`, `delete_user`, `assign_roles` |
| **Internal invariants** | `_require`, `_validate_transition`, `_status_action` |

Every mutating operation is paired with an **audit log entry** and committed as a single transaction, making this module the authoritative write path for the `users` and `audit_log` tables.

> **Flagship trace:** `set_status` is the terminal endpoint of a documented cross-language flow:
> React "Deactivate" button → `deactivateUser` (API client) → `PATCH /api/users/{user_id}/status` route → `set_status` → DB writes.

---

## 2. Design Decisions

### 2.1 Service-layer transaction ownership
Each mutating function owns its full transaction lifecycle (`db.flush` / `db.commit` / `db.refresh`). Routes remain thin and delegate all business rules and persistence to the service. This keeps transactional boundaries explicit and predictable at the point where the domain change occurs.

### 2.2 Audit-as-a-side-effect, in the same transaction
Audit records are written via `audit.record(...)` **before** `db.commit()`. This guarantees the state change and its audit trail are committed atomically — a user can never be mutated without a corresponding audit entry (or vice versa).

### 2.3 Errors expressed as `HTTPException`
The service raises `fastapi.HTTPException` directly (404, 409, 422) rather than domain-specific exceptions. This couples the service to FastAPI but eliminates a translation layer, letting routes stay minimal. Status codes carry semantic meaning:
- **404** — target user not found (`_require`)
- **409** — conflict (duplicate username, illegal status transition)
- **422** — unknown status value

### 2.4 Explicit state machine for status transitions
`_validate_transition` enforces `ALLOWED_STATUS_TRANSITIONS` (from `app.constants`). Status changes are not free-form; they must follow a declared graph. Idempotent no-op transitions (`current == target`) are permitted silently.

### 2.5 Roles/permissions computed, not stored
`actor_has_permission` and `effective_permissions` derive permissions on-the-fly by flattening `user.roles → role.permissions`. There is no denormalized permission cache, keeping authorization always consistent with role assignments.

### 2.6 Keyword-only mutation arguments
All mutating functions use `*` to force keyword arguments (`actor_id=`, `user_id=`, etc.), reducing accidental argument transposition for security-sensitive calls.

---

## 3. Component Diagram

```dot
digraph users_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_routes {
        label="HTTP Layer (FastAPI routes)";
        style=dashed;
        route_status [label="PATCH /api/users/{id}/status"];
        route_crud   [label="Users CRUD routes"];
    }

    subgraph cluster_service {
        label="backend.app.services.users";
        style=solid;

        get_user      [label="get_user"];
        list_users    [label="list_users"];
        has_perm      [label="actor_has_permission"];
        eff_perm      [label="effective_permissions"];
        create_user   [label="create_user"];
        update_user   [label="update_user"];
        set_status    [label="set_status", color=crimson, penwidth=2];
        delete_user   [label="delete_user"];
        assign_roles  [label="assign_roles"];

        require       [label="_require", shape=ellipse, style=dotted];
        validate      [label="_validate_transition", shape=ellipse, style=dotted];
        status_action [label="_status_action", shape=ellipse, style=dotted];
    }

    subgraph cluster_deps {
        label="Dependencies";
        style=dashed;
        audit    [label="app.services.audit\n(record)"];
        models   [label="app.models\n(User, Role)"];
        consts   [label="app.constants\n(UserStatus, AuditAction,\nALLOWED_STATUS_TRANSITIONS)"];
        db       [label="SQLAlchemy Session", shape=cylinder];
    }

    // Route wiring
    route_status -> set_status [color=crimson, penwidth=2];
    route_crud -> {create_user update_user delete_user assign_roles get_user list_users};

    // Internal helper usage
    update_user  -> require;
    set_status   -> require;
    set_status   -> validate;
    set_status   -> status_action;
    delete_user  -> require;
    assign_roles -> require;

    // Dependency usage
    {create_user update_user set_status delete_user assign_roles} -> audit;
    {get_user list_users create_user update_user set_status delete_user assign_roles require} -> db;
    {create_user assign_roles} -> models [label="Role"];
    {validate status_action} -> consts;
    {has_perm eff_perm} -> models [label="roles/permissions"];
}
```

---

## 4. Interfaces

### 4.1 Public API

| Function | Signature (abbreviated) | Returns | Errors |
|---|---|---|---|
| `get_user` | `(db, user_id)` | `User \| None` | — |
| `list_users` | `(db, *, status=None)` | `list[User]` | — |
| `actor_has_permission` | `(actor, permission)` | `bool` | — |
| `effective_permissions` | `(user)` | `list[str]` (sorted, deduped) | — |
| `create_user` | `(db, *, actor_id, username, email, full_name, role_ids)` | `User` | 409 duplicate username |
| `update_user` | `(db, *, actor_id, user_id, email, full_name)` | `User` | 404 |
| `set_status` | `(db, *, actor_id, user_id, status)` | `User` | 404, 409, 422 |
| `delete_user` | `(db, *, actor_id, user_id)` | `None` | 404 |
| `assign_roles` | `(db, *, actor_id, user_id, role_ids)` | `User` | 404 |

### 4.2 Integration Points

- **Inbound:** FastAPI route handlers pass a request-scoped `Session` and validated payload fields. `actor_id` is expected to be resolved from the authenticated principal upstream.
- **Persistence:** `app.models.User` and `app.models.Role`, accessed via the SQLAlchemy `Session`.
- **Audit:** `app.services.audit.record(db, actor_id, action, target_id, detail=...)` — participates in the caller's transaction (no independent commit).
- **Constants contract:** `UserStatus`, `AuditAction`, and `ALLOWED_STATUS_TRANSITIONS` from `app.constants` define the valid vocabulary and state graph.

---

## 5. Data Flow

### 5.1 Mutation flow (general shape)

```dot
digraph mutation_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    call     [label="Route calls service fn\n(db, actor_id, target, payload)"];
    resolve  [label="_require(db, user_id)\n→ 404 if missing"];
    validate [label="Business validation\n(uniqueness / transition)"];
    mutate   [label="Mutate ORM object\n(fields / roles / status)"];
    audit    [label="audit.record(...)\n(same transaction)"];
    commit   [label="db.commit()"];
    refresh  [label="db.refresh(user)"];
    ret      [label="return User"];

    call -> resolve -> validate -> mutate -> audit -> commit -> refresh -> ret;
}
```

### 5.2 `set_status` (flagship path) in detail

1. `_require` loads the target `User`, raising **404** if absent.
2. `_validate_transition(current, target)`:
   - unknown status → **422**
   - identical status → allowed (no-op passthrough)
   - not in `ALLOWED_STATUS_TRANSITIONS[current]` → **409**
3. `user.status = status` mutates the ORM entity.
4. `_status_action(status)` maps the target status to a specific `AuditAction`:
   - `DEACTIVATED` → `USER_DEACTIVATED`
   - `ACTIVE` → `USER_REACTIVATED`
   - otherwise → `USER_UPDATED`
5. `audit.record(...)` writes the audit row.
6. `db.commit()` atomically persists the `users` and `audit_log` writes.
7. `db.refresh(user)` reloads state; the refreshed `User` is returned.

### 5.3 Read flow
`get_user` and `list_users` are pure reads (no commit, no audit). `list_users` optionally filters by `status` and always orders by `username`. Permission helpers (`actor_has_permission`, `effective_permissions`) operate purely in memory on already-loaded `roles`/`permissions` relationships.

---

## 6. Extension Points

### 6.1 Adding a new status
1. Add the value to `UserStatus` in `app.constants`.
2. Declare its legal transitions in `ALLOWED_STATUS_TRANSITIONS`.
3. If it needs a distinct audit action, add a branch in `_status_action` and a corresponding `AuditAction` member. Otherwise it defaults to `USER_UPDATED`.

No changes to `set_status` itself are required — it is driven entirely by these constants.

### 6.2 Adding a new lifecycle operation
Follow the established mutation template:
```python
def new_op(db, *, actor_id, user_id, ...):
    user = _require(db, user_id)
    # validate + mutate
    audit.record(db, actor_id=actor_id, action=AuditAction.X.value, target_id=user.id, ...)
    db.commit()
    db.refresh(user)
    return user
```
This preserves the atomic *(mutate + audit)* invariant.

### 6.3 Customizing authorization
Permission resolution logic is centralized in `actor_has_permission` / `effective_permissions`. To introduce role hierarchies, permission caching, or deny rules, modify these two functions; callers depend only on their contracts (`bool` / sorted `list[str]`).

### 6.4 Audit routing
Because all audit writes funnel through `audit.record`, the audit sink can be swapped or enriched (e.g., emitting events, adding metadata) inside `app.services.audit` without touching this module.

---

### Notes & Cautions for Maintainers
- **Transaction ownership:** Callers must **not** wrap these functions in their own commit — the service commits internally. Composing multiple mutations in one transaction is not currently supported without refactoring the commit boundary.
- **`HTTPException` coupling:** The service is intentionally coupled to FastAPI's exception type. If reuse outside HTTP contexts becomes necessary, introduce a domain-exception + translation layer at the route boundary.
- **`actor_id` trust:** The service does not verify that `actor_id` corresponds to an authorized principal; authentication/authorization must be enforced upstream in the route layer (potentially using `actor_has_permission`).