---
id: 37c3bc99-003c-5f5a-ae02-018ea82a9f2f
type: architecture
title: "Sidebar Architecture"
created_at: 2026-07-30T17:28:22.647612+00:00
updated_at: 2026-07-30T17:28:22.647626+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx
metadata:
  module_name: "frontend.src.components.Sidebar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Sidebar Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx`

# Sidebar Component Architecture

**Module**: `frontend.src.components.Sidebar`

---

## 1. Component Overview

The `Sidebar` component is a stateless, presentational React component that renders the primary navigation panel for the **UserHub** application. It fulfills three core responsibilities:

- **Branding**: Displays the fixed application identity (logo mark + name).
- **Navigation**: Renders a configurable list of navigation items and reports user selections to a parent via callback.
- **Actor Identity**: Displays the currently authenticated user (the "actor") in a footer, when available.

The component owns no internal state. All rendering is derived from props, and all behavior is delegated upward through callbacks. This positions it as a "dumb" view component in a container/presenter architecture.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Stateless / prop-driven** | Navigation state (`active`) and item definitions (`items`) are owned by a parent container. This keeps the Sidebar reusable and testable without state management concerns. |
| **Icon lookup via static map (`ICONS`)** | Decouples icon rendering from the navigation data. `items` need only supply a `key` string; the visual icon is resolved locally. Missing keys degrade gracefully (`Icon && <Icon />`). |
| **Callback-based navigation (`onNavigate`)** | The Sidebar does not know how routing works; it emits intent (`item.key`) and lets the parent decide how to act. This inverts the dependency on the router. |
| **Defensive `initials()` helper** | Handles `null`/`undefined` usernames without crashing, producing a safe fallback (`?`). |
| **Conditional footer rendering** | The actor footer only renders when `actor` is truthy, supporting unauthenticated or loading states. |
| **CSS-class-driven styling** | Styling is externalized to class names (`sidebar`, `nav-item active`, etc.), keeping the component logic-free of presentation details. |

---

## 3. Component Diagram

```dot
digraph Sidebar {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_parent {
    label = "Parent Container (owner of state)";
    style = dashed;
    Parent [label="Container Component\n(items, active, actor, onNavigate)"];
  }

  subgraph cluster_sidebar {
    label = "Sidebar Component";
    style = solid;

    Sidebar   [label="Sidebar(props)"];
    Brand     [label="Brand Block\n(static UH / UserHub)"];
    Nav       [label="Nav\n(maps items -> buttons)"];
    Footer    [label="Sidebar Footer\n(conditional on actor)"];
    Initials  [label="initials()\nhelper", shape=ellipse];
    IconMap   [label="ICONS map\n{dashboard,users,roles,audit}", shape=note];
  }

  subgraph cluster_icons {
    label = "Icons.jsx";
    style = dotted;
    Icons [label="IconDashboard\nIconUsers\nIconShield\nIconActivity"];
  }

  Parent -> Sidebar [label="props"];
  Sidebar -> Brand;
  Sidebar -> Nav;
  Sidebar -> Footer;

  Nav -> IconMap [label="lookup by item.key"];
  IconMap -> Icons [label="references"];
  Footer -> Initials [label="actor.username"];

  Nav -> Parent [label="onNavigate(item.key)", style=dashed, color=blue];
}
```

---

## 4. Interfaces

### Props (Input API)

| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `items` | `Array<{ key: string, label: string }>` | Yes | Navigation entries. `key` must match an `ICONS` entry to render an icon; `label` is the visible text. |
| `active` | `string` | Yes | The `key` of the currently active item; used to apply the `active` CSS class. |
| `onNavigate` | `(key: string) => void` | Yes | Callback fired when a nav button is clicked. Receives the selected item's `key`. |
| `actor` | `{ username: string, full_name?: string } \| null` | No | The authenticated user. When falsy, the footer is not rendered. |

### Internal Interfaces

- **`ICONS` map** — Maps a navigation `key` to an icon component from `Icons.jsx`. Serves as the extension point for available navigation categories.
- **`initials(name)`** — Pure function returning up to 2 uppercase characters, defaulting to `"?"`.

### Integration Points

- **Upstream**: A parent container supplies all data and handles the `onNavigate` intent (e.g., updating a router or view state).
- **Downstream**: `./Icons.jsx` provides icon components consumed via the `ICONS` registry.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Container [label="Parent Container"];
  Props     [label="Props\n{items, active, actor, onNavigate}", shape=note];
  Render    [label="Sidebar render"];
  User      [label="User", shape=ellipse];

  Container -> Props [label="1. supplies"];
  Props -> Render [label="2. drives"];
  User -> Render [label="3. clicks nav-item"];
  Render -> Container [label="4. onNavigate(key)", color=blue];
  Container -> Props [label="5. updates active", style=dashed];
}
```

**Flow narrative:**

1. The parent container passes `items`, `active`, `actor`, and `onNavigate` as props.
2. During render, `Sidebar` maps `items` to buttons, resolving icons via `ICONS[item.key]` and highlighting the button whose `key` matches `active`.
3. If `actor` is present, the footer renders `initials(actor.username)` and identity text.
4. On click, the button invokes `onNavigate(item.key)`, emitting the selection upward.
5. The parent typically updates its own `active` state, triggering a re-render — a **unidirectional data flow** loop.

---

## 6. Extension Points

### Adding a New Navigation Category
1. Add a new icon export in `Icons.jsx`.
2. Register it in the `ICONS` map keyed by the desired navigation `key`.
3. Include a corresponding entry in the `items` prop passed by the parent.

```javascript
const ICONS = {
  dashboard: IconDashboard,
  users: IconUsers,
  roles: IconShield,
  audit: IconActivity,
  settings: IconSettings, // new category
};
```

### Customizing Behavior Without Modifying the Component
- **Navigation logic**: Fully controlled by the parent's `onNavigate` handler — swap routing strategies (SPA router, hash-based, external links) without touching the Sidebar.
- **Item set / ordering**: Driven entirely by the `items` prop; can be filtered by permission or role upstream.
- **Actor display**: Provide or omit `actor` to toggle the footer; supply `full_name` to control the primary display line.

### Styling Customization
All visual concerns are keyed to CSS classes (`sidebar`, `brand`, `nav`, `nav-item`, `active`, `sidebar-footer`, `avatar`, `who`). Themes can be applied by overriding these classes externally.

### Recommended Guardrails for Extension
- Keep the component **stateless** — resist adding internal state; push it to the container.
- Preserve the **graceful-degradation** pattern (`Icon && <Icon />`, `initials()` fallback) when introducing new dynamic fields.
- Any icon added to `ICONS` should accept a `size` prop, matching the existing icon contract (`<Icon size={18} />`).