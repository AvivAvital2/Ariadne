---
id: 18458970-31c2-5223-bac9-249ccaade450
type: architecture
title: "Roles Architecture"
created_at: 2026-07-30T17:23:57.497247+00:00
updated_at: 2026-07-30T17:23:57.497262+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  module_name: "backend.app.routers.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

# Architecture Documentation: `backend.app.routers.roles`

## 1. Component Overview

The `roles` router is a FastAPI routing module that exposes HTTP endpoints for managing **roles** and querying **permissions** within the application's Role-Based Access Control (RBAC) subsystem.

It is a thin **presentation/transport layer** whose responsibilities are deliberately narrow:

- Declare HTTP routes and bind them to handler functions.
- Enforce authorization on each route via permission dependencies.
- Validate and serialize request/response payloads through Pydantic schemas.
- Delegate all business logic and persistence concerns to the `roles` service.

It **does not** contain business rules, database queries, or authorization logic itself — these are all injected or delegated.

| Endpoint | Method | Purpose | Required Permission |
|---|---|---|---|
| `/api/roles` | `GET` | List all roles | `USERS_READ` |
| `/api/roles` | `POST` | Create a new role | `ROLES_MANAGE` |
| `/api/permissions` | `GET` | List all permissions | `ROLES_MANAGE` |

---

## 2. Design Decisions

### Thin Router, Fat Service
The router contains no persistence or business logic — every handler forwards to `app.services.roles`. This keeps HTTP concerns (routing, status codes, serialization) separate from domain logic, enabling the service layer to be tested and reused independently of FastAPI.

### Dependency Injection for Cross-Cutting Concerns
Two `Depends(...)` injections appear on every route:
- `get_db` supplies a scoped SQLAlchemy `Session`, so lifecycle management (open/commit/close) lives outside the handler.
- `require_permission(...)` performs authentication + authorization and yields the acting `User`. This centralizes access control and makes each endpoint's permission requirement explicit and declarative.

### Permission Granularity via Constants
Permissions are referenced through the `Permission` enum (`app.constants`) rather than string literals. This provides a single source of truth and compile-time-safe references. Note the asymmetry:
- **Reading roles** requires only `USERS_READ` (roles are needed to display/assign users).
- **Creating roles** and **listing permissions** require the elevated `ROLES_MANAGE` privilege.

This reflects a least-privilege intent: viewing role names is a lower-risk operation than mutating them or enumerating the full permission catalog.

### Schema-Driven Contracts
`response_model` and typed `payload` parameters bind the endpoints to Pydantic schemas (`RoleOut`, `RoleCreate`, `PermissionOut`), giving automatic validation, serialization filtering, and OpenAPI documentation.

---

## 3. Component Diagram

```dot
digraph roles_router {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_router {
        label="app.routers.roles";
        style=dashed;
        list_roles       [label="GET /api/roles\nlist_roles"];
        create_role      [label="POST /api/roles\ncreate_role"];
        list_permissions [label="GET /api/permissions\nlist_permissions"];
    }

    subgraph cluster_deps {
        label="Injected Dependencies";
        style=dotted;
        get_db            [label="get_db\n(Session provider)"];
        require_permission[label="require_permission\n(authz guard)"];
    }

    subgraph cluster_contracts {
        label="Schemas (app.schemas)";
        style=dotted;
        RoleOut       [label="RoleOut"];
        RoleCreate    [label="RoleCreate"];
        PermissionOut [label="PermissionOut"];
    }

    service [label="app.services.roles\n(business logic)", shape=box, style="rounded,filled", fillcolor="#e8f0fe"];
    db      [label="Database\n(SQLAlchemy)", shape=cylinder];
    perms   [label="Permission enum\n(app.constants)", shape=note];

    // route -> dependencies
    list_roles       -> get_db;
    list_roles       -> require_permission;
    create_role      -> get_db;
    create_role      -> require_permission;
    list_permissions -> get_db;
    list_permissions -> require_permission;

    // authz uses permission constants
    require_permission -> perms [style=dashed, label="checks"];

    // route -> service delegation
    list_roles       -> service;
    create_role      -> service;
    list_permissions -> service;

    // route -> contracts
    create_role      -> RoleCreate    [style=dashed, label="in"];
    list_roles       -> RoleOut       [style=dashed, label="out"];
    create_role      -> RoleOut       [style=dashed, label="out"];
    list_permissions -> PermissionOut [style=dashed, label="out"];

    // service -> db
    service -> db;
}
```

---

## 4. Interfaces

### Inbound HTTP API

**`GET /api/roles`**
- Auth: requires `USERS_READ`.
- Response: `200 OK`, body = `list[RoleOut]`.

**`POST /api/roles`**
- Auth: requires `ROLES_MANAGE`.
- Request body: `RoleCreate` → `{ name, description, permission_ids }`.
- Response: `201 Created`, body = `RoleOut`.

**`GET /api/permissions`**
- Auth: requires `ROLES_MANAGE`.
- Response: `200 OK`, body = `list[PermissionOut]`.

### Outbound Service Interface (`app.services.roles`)
The router depends on the following service functions:

| Function | Signature (as used) |
|---|---|
| `list_roles` | `list_roles(db) -> list[Role]` |
| `create_role` | `create_role(db, *, name, description, permission_ids) -> Role` |
| `list_permissions` | `list_permissions(db) -> list[Permission]` |

### Integration Points
- **`get_db`** (`app.database`): provides the request-scoped `Session`.
- **`require_permission`** (`app.security`): a dependency **factory** returning a guard; returns the authenticated `User` as `actor`.
- **Schemas** (`app.schemas`): validation/serialization contracts.
- **`Permission`** (`app.constants`): enum of permission identifiers.

---

## 5. Data Flow

Example: **creating a role** (`POST /api/roles`).

```dot
digraph create_role_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    client   [label="Client\n(HTTP request)"];
    fastapi  [label="FastAPI\n(routing + validation)"];
    authz    [label="require_permission(ROLES_MANAGE)"];
    session  [label="get_db\n(SQLAlchemy Session)"];
    handler  [label="create_role handler"];
    service  [label="role_service.create_role"];
    db       [label="Database", shape=cylinder];

    client  -> fastapi        [label="JSON body"];
    fastapi -> fastapi        [label="parse -> RoleCreate"];
    fastapi -> authz          [label="resolve dep"];
    authz   -> handler        [label="actor: User"];
    fastapi -> session        [label="resolve dep"];
    session -> handler        [label="db: Session"];
    handler -> service        [label="name, description,\npermission_ids"];
    service -> db             [label="persist"];
    db      -> service        [label="Role row"];
    service -> handler        [label="Role"];
    handler -> fastapi        [label="Role"];
    fastapi -> client         [label="201 + RoleOut JSON"];
}
```

**Flow summary:**
1. Request arrives; FastAPI resolves dependencies in order.
2. `require_permission` authenticates the caller and asserts they hold the required permission (raising `403`/`401` otherwise), yielding the `actor`.
3. `get_db` opens a session bound to the request lifecycle.
4. The handler unpacks the validated payload and calls the service function.
5. The service performs persistence and returns a domain/ORM object.
6. FastAPI serializes the result through the declared `response_model` and returns the HTTP response.

Read endpoints (`list_roles`, `list_permissions`) follow the same path minus the request-body parsing.

---

## 6. Extension Points

### Adding a New Endpoint
Add a handler decorated with `@router.<method>(...)`, declaring:
- a `response_model` from `app.schemas`,
- a `get_db` dependency,
- a `require_permission(Permission.X.value)` dependency,
and delegate to a new or existing function in `app.services.roles`.

### Adjusting Authorization
Permission requirements are changed by swapping the `Permission` enum value passed to `require_permission`. Because permissions come from `app.constants`, adding a new permission there and referencing it here is the standard extension path. No logic change is needed in the router.

### Changing Business Behavior
Modify `app.services.roles` rather than the router. The router's delegation pattern means new fields, validation, or persistence rules can be added in the service and reflected through updated schemas without touching route definitions.

### Evolving Contracts
Request/response shape changes are made in `app.schemas` (`RoleCreate`, `RoleOut`, `PermissionOut`). FastAPI automatically propagates these to OpenAPI docs and runtime validation.

### Mounting the Router
The `APIRouter` is tagged `"roles"` and defines full paths (`/api/roles`, `/api/permissions`) inline. It is intended to be included in the main application via `app.include_router(router)`. Note that paths are absolute in the decorators rather than relying on a `prefix`, so callers should include it without an additional `/api` prefix to avoid path duplication.

---

*This document reflects the router as implemented. Keep authorization mappings and the service interface table in sync with `app.services.roles` and `app.constants.Permission` as they evolve.*