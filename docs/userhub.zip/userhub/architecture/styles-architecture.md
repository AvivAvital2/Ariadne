---
id: 0a2a8658-f6ff-5ae3-8944-3c6539f40094
type: architecture
title: "Styles Architecture"
created_at: 2026-07-30T17:31:13.414758+00:00
updated_at: 2026-07-30T17:31:13.414772+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css
metadata:
  module_name: "frontend.src.styles"
  language: "css"
  provenance: "code-derived"
  source_name: "userhub"
---
# Styles Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css`

# Architecture Documentation: `frontend.src.styles`

## 1. Component Overview

The `frontend.src.styles` module is the **global stylesheet** for the frontend application. It defines the complete visual design system for a dashboard/admin-style single-page application, covering:

- **Design tokens** — a centralized set of CSS custom properties (colors, radii, shadows) exposed on `:root`.
- **Layout primitives** — the top-level page scaffold (`.layout`, `.sidebar`, `.main`, `.content`).
- **Chrome components** — sidebar navigation, topbar, and avatars.
- **Content components** — cards, stat cards, dashboard panels, data-visualizations (donut, horizontal bars, area chart), activity feeds, tables, badges, buttons, tags, forms, modals, and error banners.
- **Responsive behavior** — a single breakpoint at `980px` that collapses multi-column grids.

This is a **presentation-only layer**. It has no JavaScript logic, no runtime dependencies, and no cross-source calls. It contracts with the application purely through **class names** and **CSS custom property names**, which markup (presumably React components, given the `#root` selector) opts into.

### Responsibilities

| Responsibility | Mechanism |
|---|---|
| Establish a single source of truth for theming | CSS variables on `:root` |
| Normalize baseline browser behavior | `* { box-sizing }`, `html/body/#root` sizing, font stack |
| Provide reusable, composable UI classes | BEM-adjacent flat class naming |
| Encode status/semantic meaning visually | Tone/status modifier classes (`.good`, `.critical`, `.badge.active`) |
| Adapt to viewport size | Media query overrides |

---

## 2. Design Decisions

### 2.1 Token-first theming
All meaningful colors and structural constants are declared once in `:root` and referenced via `var(...)` throughout. This is the single most important architectural choice:

- The palette is split into three semantic groups: **dark sidebar**, **light content**, and **data-viz + status**. The comment `/* validated data-viz + status palette */` signals these colors were deliberately chosen for accessibility/contrast in charts.
- A single change to `--primary` cascades to the brand mark, active nav, avatars, buttons, focus rings, and chart accents.

### 2.2 Flat, composable class naming
Classes follow a flat, utility-plus-component hybrid convention rather than nested selectors:
- **Component root**: `.card`, `.stat-card`, `.btn`, `.badge`
- **Modifiers**: `.btn.primary`, `.btn.ghost`, `.stat-icon.tone-good`, `.badge.active`
- **Utilities**: `.muted`, `.nowrap`, `.stack`

This keeps specificity low and predictable — nearly everything is a single class selector, avoiding specificity wars.

### 2.3 Semantic tone/status mapping
Status is expressed through a consistent, repeated pattern: a translucent tinted background paired with a solid foreground of the corresponding status color (`--good`, `--warning`, `--critical`). This appears across `.stat-icon.tone-*`, `.badge.*`, `.dot.*`, and `.error`, ensuring visual consistency for the same underlying meaning.

### 2.4 Layout via Flexbox + CSS Grid
- **Macro layout** (sidebar + main region) uses Flexbox with a fixed-basis sidebar (`flex: 0 0 240px`) and a flexible main region (`min-width: 0` to prevent overflow of flex children).
- **Content grids** (`.stat-row`, `.panel-grid`, `.hbar-row`, `.check-grid`) use CSS Grid for column control.
- **Sticky chrome** — both `.sidebar` and `.topbar` are `position: sticky` to keep navigation persistent while content scrolls.

### 2.5 SVG-aware styling
Chart classes (`.donut`, `.area-svg .grid`, `.donut-total`) style SVG properties (`fill`, `stroke`), indicating charts are rendered as inline SVG and themed through the same token system rather than a separate charting theme.

---

## 3. Component Diagram

```dot
digraph styles {
  rankdir=TB;
  node [shape=box, style="rounded,filled", fillcolor="#f4f6f9", fontname="Helvetica"];
  edge [color="#64748b", fontname="Helvetica", fontsize=10];

  tokens [label=":root design tokens\n(colors, --radius, --shadow)", fillcolor="#e6f0fb"];
  base   [label="Base reset\n(*, html, body, #root)"];

  subgraph cluster_layout {
    label="Layout primitives";
    style=dashed; color="#94a3b8";
    layout  [label=".layout"];
    sidebar [label=".sidebar"];
    main    [label=".main"];
    content [label=".content"];
    topbar  [label=".topbar"];
  }

  subgraph cluster_chrome {
    label="Chrome components";
    style=dashed; color="#94a3b8";
    nav    [label=".nav / .nav-item"];
    brand  [label=".brand"];
    avatar [label=".avatar"];
    search [label=".search"];
  }

  subgraph cluster_content {
    label="Content components";
    style=dashed; color="#94a3b8";
    card   [label=".card / .stat-card"];
    viz    [label="data-viz\n.donut .hbars .area-chart"];
    feed   [label=".feed"];
    table  [label="table / th / td"];
    forms  [label="forms / .form-grid"];
    modal  [label=".modal"];
  }

  subgraph cluster_atoms {
    label="Atoms";
    style=dashed; color="#94a3b8";
    btn    [label=".btn (.primary/.ghost/.danger)"];
    badge  [label=".badge (.active/.invited/...)"];
    tag    [label=".tag"];
    dot    [label=".dot (.good/.bad/.neutral)"];
    error  [label=".error"];
  }

  responsive [label="@media (max-width: 980px)", fillcolor="#fdf3d8"];

  // token consumption
  tokens -> base;
  tokens -> layout;
  tokens -> nav;
  tokens -> brand;
  tokens -> avatar;
  tokens -> card;
  tokens -> viz;
  tokens -> feed;
  tokens -> table;
  tokens -> forms;
  tokens -> modal;
  tokens -> btn;
  tokens -> badge;
  tokens -> tag;
  tokens -> dot;
  tokens -> error;
  tokens -> search;

  // structural composition
  layout -> sidebar;
  layout -> main;
  main -> topbar;
  main -> content;
  sidebar -> brand;
  sidebar -> nav;
  sidebar -> avatar [label="footer"];
  topbar -> search;
  topbar -> avatar;
  content -> card;
  content -> viz;
  content -> feed;
  content -> table;
  content -> forms;
  content -> modal;
  card -> btn;
  card -> badge;
  card -> tag;
  feed -> dot;

  // responsive overrides
  responsive -> viz [style=dotted, label="grid cols"];
}
```

---

## 4. Interfaces

Because this is a stylesheet, its "API surface" is the set of names that consuming markup depends on. There are two interface classes:

### 4.1 CSS Custom Property interface (theming contract)

| Token group | Variables |
|---|---|
| Sidebar | `--sidebar-bg`, `--sidebar-fg`, `--sidebar-muted` |
| Content surfaces | `--page`, `--card`, `--line`, `--track`, `--grid` |
| Text/ink | `--ink`, `--ink-2`, `--muted`, `--faint` |
| Brand/status | `--primary`, `--primary-ink`, `--good`, `--warning`, `--critical` |
| Structure | `--radius`, `--shadow` |

These are the **stable override points**. Any consumer (or a theme layer) can redefine them on `:root` or a scoped ancestor.

### 4.2 Class-name interface (markup contract)

Consumers must attach the correct classes to produce styled elements. Key contracts include:

- **Layout scaffold** requires the nesting: `.layout > .sidebar` and `.layout > .main > (.topbar, .content)`.
- **Modifier composition** — base + modifier on the same element:
  - Buttons: `class="btn primary"`, `btn ghost`, `btn danger`, add `sm` for compact.
  - Stat icons: `stat-icon tone-{primary|good|critical|warning}`.
  - Badges: `badge {active|invited|deactivated}`.
  - Status dots: `dot {good|bad|neutral}`.
- **SVG hooks** — inline charts must apply `.grid`, `.axis-label`, `.crosshair` classes to SVG elements to inherit theme colors.
- **Element selectors** — `table`, `th`, `td`, `input`, `label`, `fieldset`, `legend` are styled by tag; these apply globally without opt-in classes. Consumers rely on this for form and table rendering.

### 4.3 Environmental contract
- Requires an element with `id="root"` (React mount point) sized to full height.
- Assumes a modern browser supporting CSS custom properties, Grid, Flexbox, `position: sticky`, and `inset`.

---

## 5. Data Flow

There is no runtime data flow in the traditional sense; the "flow" is a **styling resolution cascade**:

```dot
digraph dataflow {
  rankdir=LR;
  node [shape=box, style="rounded,filled", fillcolor="#ffffff", fontname="Helvetica"];
  edge [fontname="Helvetica", fontsize=10];

  app    [label="Application markup\n(class + id attributes)", fillcolor="#e6f0fb"];
  root   [label=":root token\ndefinitions"];
  rules  [label="Component rules\n(var() references)"];
  render [label="Rendered UI", fillcolor="#dff0df"];
  media  [label="@media 980px\noverrides", fillcolor="#fdf3d8"];

  root -> rules   [label="resolve var()"];
  app  -> rules   [label="match selectors"];
  rules -> render [label="computed styles"];
  media -> render [label="viewport <= 980px"];
}
```

1. **Token definitions** are resolved first — `var(--x)` references throughout the sheet pull values from `:root`.
2. **Selector matching** — the browser matches element classes/tags against rules.
3. **Cascade & specificity** — flat single-class selectors keep resolution predictable; modifiers (`.btn.primary`) win by having one extra class.
4. **Responsive override** — below 980px, `.stat-row` and `.panel-grid` collapse to fewer columns. This is the only conditional branch in the flow.

---

## 6. Extension Points

### 6.1 Re-theming (recommended primary extension)
Override any `:root` variable in a stylesheet loaded **after** this one, or on a scoped container:

```css
/* Dark-mode content example */
.theme-dark {
  --page: #0b1220;
  --card: #111a2e;
  --ink: #e2e8f0;
  --line: #22304a;
}
```
Because virtually every component reads from tokens, this rethemes the entire UI without touching component rules. **This is the intended low-risk customization path.**

### 6.2 Adding component variants
Follow the established base + modifier pattern. New variants should reference existing tokens for consistency:

```css
.btn.subtle {
  background: var(--track);
  color: var(--ink-2);
}
.badge.pending {
  background: rgba(250, 178, 25, 0.18);
  color: #a06c05;
}
```

### 6.3 Adding status tones
The tinted-background/solid-foreground pattern is the canonical way to introduce a new semantic tone. Add a `--<name>` token, then create `.stat-icon.tone-<name>`, `.badge.<name>`, and `.dot.<name>` for full coverage.

### 6.4 New chart types
Inline SVG charts inherit theming through classes. Reuse `.grid`, `.axis-label`, and `.crosshair`, or add SVG-targeted rules that use `fill`/`stroke` with existing tokens so charts stay palette-consistent.

### 6.5 Additional breakpoints
Currently only one breakpoint (`980px`) exists. Additional media queries should follow the same pattern of overriding only grid-column counts, keeping the mobile-adaptation logic isolated in the responsive section rather than scattered across components.

---

### Maintenance Notes / Caveats

- **Hard-coded status colors exist** in a few places (`.stat-icon.tone-warning` uses `#b5790a`; `.badge.active` uses `#0a7d0a`; `.error` uses `#b02f2f`). These are darker "text-safe" shades of the token colors, not the tokens themselves. When retheming status colors, these literals must be updated in tandem — they are a known deviation from the token-first principle.
- **Global element selectors** (`input`, `table`, `label`) are unscoped, so third-party or embedded content will be affected. Scope these if the stylesheet is ever embedded in a larger host page.
- The layout assumes a fixed **240px sidebar**; the `980px` breakpoint collapses content grids but does **not** collapse or hide the sidebar — a potential future extension point for small screens.