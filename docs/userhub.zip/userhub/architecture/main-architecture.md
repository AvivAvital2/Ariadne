---
id: 7e7c216e-2674-57d1-9cae-80746c37531e
type: architecture
title: "Main Architecture"
created_at: 2026-07-30T17:21:50.618147+00:00
updated_at: 2026-07-30T17:21:50.618160+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  module_name: "backend.app.main"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Main Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`

# `backend.app.main` — Architecture Documentation

## 1. Component Overview

`app.main` is the **application entrypoint** for the UserHub backend. It is a thin composition layer whose sole responsibility is to assemble the running FastAPI application from independently-defined parts. It does not contain business logic; instead it:

- **Instantiates** the FastAPI application object (`app`).
- **Wires middleware** (CORS) required for browser-based clients.
- **Mounts feature routers** (`users`, `roles`, `audit`, `reports`).
- **Manages application lifecycle** via a `lifespan` handler that performs first-run schema creation and idempotent data seeding.
- **Exposes a health check** (`GET /api/health`) for liveness monitoring.

This is the module referenced by the ASGI server command:

```
uv run uvicorn app.main:app --reload
```

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Lifespan-based bootstrap** instead of a separate migration/seed script | Keeps first-run setup zero-config for development. Both `create_all` and `seed_if_empty` are idempotent, so re-running is safe. Trades production migration rigor for developer convenience. |
| **`Base.metadata.create_all` for schema** | Suitable for a small app / dev workflow. Note: this bypasses a migration tool (e.g. Alembic), so schema evolution beyond the initial version is not handled here. |
| **Seed on empty only** (`seed_if_empty`) | Guarantees baseline permissions/roles/users exist without clobbering existing data. The boolean return drives a one-time log message. |
| **CORS locked to `http://localhost:5173`** | The Vite dev server proxies `/api` to this backend, making normal browser calls same-origin. CORS is only opened for *direct* calls (e.g. Swagger UI at `/docs`), keeping the surface intentionally narrow. |
| **Router aggregation** | Each domain (`users`, `roles`, `audit`, `reports`) owns its own router module. `main` merely includes them, keeping concerns separated and the entrypoint stable as features grow. |
| **Explicit `title`/`version`** on FastAPI | Feeds OpenAPI metadata / `/docs`. |

## 3. Component Diagram

```dot
digraph UserHubMain {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_main {
        label = "app.main (entrypoint)";
        style = dashed;
        app       [label="FastAPI app\n(title=UserHub v0.1.0)", style="rounded,filled", fillcolor="#e6f2ff"];
        lifespan  [label="lifespan()\n(async context manager)"];
        health    [label="health()\nGET /api/health"];
        cors      [label="CORSMiddleware\n(origin :5173)"];
    }

    subgraph cluster_routers {
        label = "app.routers";
        style = dashed;
        users   [label="users.router"];
        roles   [label="roles.router"];
        audit   [label="audit.router"];
        reports [label="reports.router"];
    }

    subgraph cluster_infra {
        label = "app infrastructure";
        style = dashed;
        database [label="app.database\n(Base, engine,\nSessionLocal)"];
        seed     [label="app.seed\nseed_if_empty()"];
    }

    // Composition
    app -> lifespan   [label="lifespan="];
    app -> cors       [label="add_middleware"];
    app -> health     [label="@app.get"];
    app -> users      [label="include_router"];
    app -> roles      [label="include_router"];
    app -> audit      [label="include_router"];
    app -> reports    [label="include_router"];

    // Bootstrap flow
    lifespan -> database [label="create_all(engine)\nSessionLocal()"];
    lifespan -> seed     [label="seed_if_empty(db)"];

    // Routers depend on infra (implied)
    users   -> database [style=dotted];
    roles   -> database [style=dotted];
    audit   -> database [style=dotted];
    reports -> database [style=dotted];
}
```

## 4. Interfaces

### Exposed ASGI Object
- **`app`** — the `FastAPI` instance. This is the public integration point for the ASGI server (Uvicorn).

### HTTP Endpoints
| Method | Path | Handler | Purpose |
|--------|------|---------|---------|
| `GET` | `/api/health` | `health()` | Liveness probe. Returns `{"status": "ok"}`. |
| — | (various) | `users.router` | User management endpoints. |
| — | (various) | `roles.router` | Role/permission endpoints. |
| — | (various) | `audit.router` | Audit log endpoints. |
| — | (various) | `reports.router` | Reporting endpoints. |
| `GET` | `/docs` | (FastAPI built-in) | Swagger UI (relies on open CORS). |

### Lifecycle Interface
- **`lifespan(app: FastAPI)`** — async context manager invoked by FastAPI/Uvicorn on startup (code before `yield`) and shutdown (code after `yield`). Currently only startup logic is implemented.

### Upstream Integration
- **Vite dev server (`:5173`)** — proxies `/api/*` to this backend; also the single allowed CORS origin.

### Internal Dependencies (from `app`)
- `app.database`: `Base`, `engine`, `SessionLocal`.
- `app.seed`: `seed_if_empty`.
- `app.routers`: `users`, `roles`, `audit`, `reports`.

## 5. Data Flow

### Startup / Bootstrap Flow
```dot
digraph Startup {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    uvicorn  [label="Uvicorn\n(server start)"];
    lifespan [label="lifespan()\nstartup phase"];
    schema   [label="Base.metadata\n.create_all(engine)"];
    session  [label="SessionLocal()\ndb"];
    seed     [label="seed_if_empty(db)"];
    log      [label="print seed message\n(if seeded)"];
    ready    [label="yield → app ready"];

    uvicorn -> lifespan -> schema -> session -> seed;
    seed -> log [label="returns True"];
    seed -> ready [label="returns False"];
    log  -> ready;
    session -> ready [label="db.close()", style=dotted];
}
```

1. Uvicorn loads `app.main:app` and enters the `lifespan` context.
2. `Base.metadata.create_all(engine)` ensures tables exist (idempotent).
3. A DB session is opened via `SessionLocal()`.
4. `seed_if_empty(db)` inserts baseline permissions/roles/users **only if** the DB is empty; returns `True` when seeding occurred.
5. If seeded, a one-time log line is printed.
6. The session is closed in a `finally` block regardless of outcome.
7. `yield` hands control back to FastAPI; the app now serves requests.

### Request Flow
1. Browser call hits `/api/*` — either same-origin (via Vite proxy) or cross-origin (subject to CORS).
2. `CORSMiddleware` evaluates the origin.
3. FastAPI routing dispatches to the matching router (`users`/`roles`/`audit`/`reports`) or the `health` handler.
4. Handlers use `app.database` sessions (dotted lines in the component diagram) to read/write persisted data.

## 6. Extension Points

### Adding a New Feature Domain
1. Create a new router module under `app.routers` exposing a `router` object.
2. Register it in `main`:
   ```python
   from app.routers import newfeature
   app.include_router(newfeature.router)
   ```
Keep endpoint prefixes under `/api` for consistency with the Vite proxy convention.

### Extending the Lifecycle
- Add **startup** logic before `yield` in `lifespan` (e.g. cache warming, connection pool priming).
- Add **shutdown** logic after `yield` (currently none) for graceful teardown.
- Keep any bootstrap steps **idempotent**, matching the existing `create_all` / `seed_if_empty` contract, so restarts remain safe.

### Adjusting CORS / Clients
- Add allowed origins to `allow_origins` when introducing additional frontends or environments (e.g. a production domain).
- Tighten `allow_methods` / `allow_headers` from the current `["*"]` for production hardening.

### Migrating Away from `create_all`
- For production schema evolution, replace `Base.metadata.create_all(engine)` with an external migration tool (e.g. Alembic) and reduce `lifespan` to seed-only (or remove seeding entirely).

### Observability Hooks
- The `health` endpoint can be extended (e.g. DB connectivity check) or supplemented with a readiness endpoint.
- Replace the `print` in `lifespan` with structured logging as the app matures.

---

**Terminology note:** Throughout this document, *router* refers to a `fastapi.APIRouter` module under `app.routers`; *lifespan* refers to the ASGI startup/shutdown context manager; *bootstrap* refers to the first-run schema creation + seeding sequence.