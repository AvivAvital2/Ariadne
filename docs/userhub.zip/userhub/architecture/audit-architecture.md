---
id: 03684c34-d67c-59f2-bd9b-b0e1b3c5269b
type: architecture
title: "Audit Architecture"
created_at: 2026-07-30T17:25:24.842271+00:00
updated_at: 2026-07-30T17:25:24.842285+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py
metadata:
  module_name: "backend.app.services.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py`

# Audit Service Architecture

**Module**: `backend.app.services.audit`

---

## 1. Component Overview

The audit service provides a centralized mechanism for recording and retrieving audit-log entries. It acts as the single write path for capturing mutating operations on users and roles, and the single read path for the frontend audit view.

**Core Responsibilities:**

- **Write path** (`record`): Append a single, immutable audit entry describing who did what to which target.
- **Read path** (`list_entries`): Return audit entries in reverse-chronological order, with optional filtering by action type.

The service is intentionally thin—it wraps the `AuditLog` ORM model and delegates persistence to the caller-provided SQLAlchemy `Session`. It contains no business logic beyond record construction and query composition.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Session injected by caller** | Both functions accept a `Session` rather than opening their own. This lets audit writes participate in the same transaction as the operation being audited, ensuring the audit entry and the mutation commit (or roll back) atomically. |
| **`flush()` instead of `commit()`** | `record` flushes to populate generated fields (e.g. `id`, `created_at`) and surface constraint errors early, but leaves the commit decision to the caller/transaction owner. This preserves atomicity with the surrounding operation. |
| **Keyword-only arguments (`*`)** | Forces explicit, self-documenting call sites (`actor_id=...`, `action=...`), reducing the risk of positional argument confusion given several `int | None` parameters. |
| **`action` as a plain string** | The `action` field carries an `AuditAction` *value* (a string), not the enum type. This keeps the persistence layer decoupled from the enum definition while the frontend maps action strings to human labels. |
| **Generic `target_type` / `target_id`** | Defaulting `target_type="user"` while allowing overrides makes the log extensible to other entity types (e.g. roles) without schema changes. |
| **Default `limit=100`** | Bounds read queries by default to protect against unbounded result sets in the audit view. |

---

## 3. Component Diagram

```dot
digraph audit_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_service {
        label="app.services.audit";
        style=dashed;
        record       [label="record()\n(write path)"];
        list_entries [label="list_entries()\n(read path)"];
    }

    subgraph cluster_callers {
        label="Callers";
        style=dashed;
        user_ops [label="User/Role\nmutation handlers"];
        audit_ui [label="Audit view\n(API endpoint)"];
    }

    AuditLog [label="AuditLog\n(ORM model)", shape=box3d];
    Session  [label="SQLAlchemy Session", shape=cylinder];

    user_ops -> record        [label="AuditAction"];
    audit_ui -> list_entries  [label="filter/limit"];

    record       -> AuditLog  [label="construct + add + flush"];
    list_entries -> AuditLog  [label="query + order + filter"];

    AuditLog     -> Session   [label="persist / read"];
    record       -> Session   [label="db.add / db.flush", style=dotted];
    list_entries -> Session   [label="db.query", style=dotted];
}
```

---

## 4. Interfaces

### `record(db, *, actor_id, action, target_id, target_type="user", detail="") -> AuditLog`

Appends one audit entry.

| Parameter | Type | Description |
|-----------|------|-------------|
| `db` | `Session` | Active SQLAlchemy session; the entry joins its transaction. |
| `actor_id` | `int \| None` | ID of the user performing the action; `None` for system/anonymous actions. |
| `action` | `str` | An `AuditAction` value describing the operation. |
| `target_id` | `int \| None` | ID of the affected entity; `None` where not applicable. |
| `target_type` | `str` | Entity kind, defaults to `"user"`. |
| `detail` | `str` | Free-form context string. |

**Returns:** the flushed `AuditLog` instance (with generated fields populated).

**Integration point:** Called by every mutating user/role operation. Callers own the transaction lifecycle.

### `list_entries(db, *, action=None, limit=100) -> list[AuditLog]`

Reads back audit entries in reverse-chronological order (`created_at desc`).

| Parameter | Type | Description |
|-----------|------|-------------|
| `db` | `Session` | Active SQLAlchemy session. |
| `action` | `str \| None` | Optional filter on a specific `AuditAction` value. |
| `limit` | `int` | Maximum entries returned; defaults to 100. |

**Returns:** a list of `AuditLog` rows.

**Integration point:** Consumed by the frontend audit view, which maps each `action` string to a human-readable label.

---

## 5. Data Flow

### Write Flow

```dot
digraph write_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    op   [label="Mutating operation\n(user/role change)"];
    rec  [label="record(db, actor_id, action, ...)"];
    ctor [label="AuditLog(...) constructed"];
    add  [label="db.add(entry)"];
    flush[label="db.flush()\n(populate id/created_at)"];
    ret  [label="return AuditLog"];
    commit[label="Caller commits transaction", shape=note];

    op -> rec -> ctor -> add -> flush -> ret;
    ret -> commit [style=dashed, label="later, by caller"];
}
```

1. A user/role mutation handler invokes `record` with the relevant `AuditAction` and target metadata.
2. An `AuditLog` instance is constructed from the arguments.
3. `db.add` stages the entry; `db.flush` writes it to the DB (within the open transaction) and populates generated columns.
4. The entry is returned to the caller. **Commit is deferred to the caller**, keeping audit + mutation atomic.

### Read Flow

1. The audit view endpoint calls `list_entries`, optionally passing an `action` filter and a `limit`.
2. A query ordered by `created_at desc` is built; the filter is applied only when `action` is provided.
3. The bounded result set is returned; the frontend maps each `action` string to a display label.

---

## 6. Extension Points

- **New audited entity types:** Pass a different `target_type` (e.g. `"role"`) to `record`. No schema or code change required in this module.
- **New action types:** Add values to the `AuditAction` enum (defined outside this module) and pass them through `record`. The frontend label map is the corresponding extension surface for human-readable rendering.
- **Richer filtering:** `list_entries` currently filters only by `action`. Additional filters (by `actor_id`, `target_id`, date range) can be added following the same conditional query-composition pattern without breaking the existing signature.
- **Alternative read shapes:** Because entries are returned as ORM objects, callers/serializers control projection. Pagination beyond a simple `limit` (e.g. offset or cursor) can be layered on the existing query builder.
- **Transaction strategy:** Callers integrate audit writes into their own transaction boundaries. To change commit semantics, adjust the caller—not this service—preserving the module's transaction-agnostic design.

---

## Notes for Maintainers

- Keep `record` free of business logic; it is a persistence primitive relied on by many call sites.
- Preserve the `flush`-not-`commit` contract—changing it would break the atomicity guarantee that audit entries share the transaction of the operation they describe.
- The `action` field's string values are a shared contract with the frontend label map; changes must be coordinated on both sides.