---
id: cd9f089f-a6ba-5885-86ec-ff3eb89a78b6
type: architecture
title: "Dashboard Architecture"
created_at: 2026-07-30T17:27:42.809534+00:00
updated_at: 2026-07-30T17:27:42.809549+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx
metadata:
  module_name: "frontend.src.components.Dashboard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Dashboard Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx`

# Dashboard Component Architecture

**Module:** `frontend.src.components.Dashboard`

---

## 1. Component Overview

The `Dashboard` component is the primary administrative overview surface for the application. It aggregates data from multiple backend endpoints (users, roles, audit log, and a SQL-backed activity report) and renders a set of summary statistics and visualizations that communicate the health and activity of the user-management system.

### Responsibilities

- **Data acquisition**: Fetches four independent datasets in parallel on mount.
- **Data transformation**: Derives all display metrics (counts, percentages, time series, top-N rankings) from the raw datasets via a single pure `computeStats` function.
- **Presentation orchestration**: Composes reusable chart and card primitives (`StatCard`, `AreaTrend`, `DonutChart`, `BarChart`) into a grid layout.
- **Error surfacing**: Displays a single error banner if any of the underlying fetches fail.

The component is intentionally a **read-only, self-contained view** — it holds no mutation logic and exposes no props, making it a drop-in route/page component.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Parallel fetch with `Promise.all`** | The four datasets are independent; fetching them concurrently minimizes time-to-first-render. A single `.catch` collapses all failures into one error banner, keeping error handling simple. |
| **Pure `computeStats` function** | All derivation logic is extracted from the render path into a stateless, testable pure function. This isolates business/aggregation logic from React lifecycle concerns and makes the component easier to reason about and unit test. |
| **`useMemo` around `computeStats`** | Aggregation over the audit log and user list can be non-trivial; memoization ensures re-computation only occurs when source datasets change, not on every render. |
| **Presentational chart primitives** | Charts (`AreaTrend`, `BarChart`, `DonutChart`) receive plain data arrays with `{ label, value, color }` shapes. This decouples the Dashboard from any specific charting library and standardizes the data contract across visualizations. |
| **Color/label constants centralized** | `STATUS_COLOR`, `SERIES_BLUE`, `USER_STATUS`, and `AUDIT_ACTION_LABELS` provide a single source of truth for theming and vocabulary, keeping visual semantics consistent. |
| **Client-side time bucketing** | The 7-day activity trend is computed client-side from the raw audit list rather than requesting a pre-aggregated series, reducing backend surface area at the cost of transferring raw events. |
| **Graceful empty states** | Each panel independently checks for empty data and renders an "empty" fallback, so partial data availability never breaks the layout. |

---

## 3. Component Diagram

```dot
digraph Dashboard {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_component {
    label="Dashboard (React Component)";
    style=dashed;

    state       [label="Local State\n(users, roles, audit,\nreport, error)"];
    effect      [label="useEffect\n(mount fetch)"];
    computeStats[label="computeStats()\n(pure aggregation)", shape=box, style="rounded,filled", fillcolor="#eef6ff"];
    memo        [label="useMemo\n(stats)"];
    render      [label="render()\nstat-row + panel-grid"];
  }

  subgraph cluster_api {
    label="API Layer (../api/client.js)";
    style=dashed;
    listUsers   [label="listUsers()"];
    listRoles   [label="listRoles()"];
    listAudit   [label="listAudit()"];
    report_ep   [label="userActivityReport()"];
  }

  subgraph cluster_ui {
    label="Presentational Primitives";
    style=dashed;
    StatCard  [label="StatCard"];
    AreaTrend [label="AreaTrend"];
    DonutChart[label="DonutChart"];
    BarChart  [label="BarChart"];
    Icons     [label="Icons.jsx"];
  }

  subgraph cluster_const {
    label="constants.js";
    style=dashed;
    USER_STATUS         [label="USER_STATUS"];
    AUDIT_ACTION_LABELS [label="AUDIT_ACTION_LABELS"];
  }

  // Data acquisition
  effect -> listUsers;
  effect -> listRoles;
  effect -> listAudit;
  effect -> report_ep;
  listUsers   -> state;
  listRoles   -> state;
  listAudit   -> state;
  report_ep   -> state;

  // Derivation
  state -> memo;
  memo  -> computeStats [dir=both, style=dotted];
  memo  -> render;

  // Rendering
  render -> StatCard;
  render -> AreaTrend;
  render -> DonutChart;
  render -> BarChart;
  StatCard -> Icons;

  // Constants usage
  USER_STATUS         -> computeStats [style=dotted];
  AUDIT_ACTION_LABELS -> render       [style=dotted];
}
```

---

## 4. Interfaces

### 4.1 Public Interface

- **Component signature:** `export default function Dashboard()` — takes **no props**, renders a complete dashboard view. Intended as a route-level page.

### 4.2 Consumed API Endpoints (`../api/client.js`)

| Call | Expected Shape | Used For |
|------|----------------|----------|
| `listUsers()` | `Array<{ status, roles: [{ id }] }>` | Totals, status breakdown, per-role counts |
| `listRoles()` | `Array<{ id, name }>` | Role labels, per-role bar chart |
| `listAudit()` | `Array<{ id, action, target_id, created_at }>` | 7-day trend, recent activity feed |
| `userActivityReport()` | `Array<{ username, action_count }>` | Most-active-users ranking |

All four are invoked once, in parallel, on mount.

### 4.3 Child Component Contracts

| Component | Prop Contract |
|-----------|---------------|
| `StatCard` | `{ icon, tone, label, value, hint }` |
| `AreaTrend` | `{ points: [{ label, value }], color }` |
| `DonutChart` | `{ data: [{ label, value, color }] }` |
| `BarChart` | `{ data: [{ label, value, color }] }` |

The `{ label, value, color }` shape is the shared datum contract for bar/donut charts.

### 4.4 Constant Dependencies (`../constants.js`)

- `USER_STATUS` — enum of user states (`ACTIVE`, `INVITED`, `DEACTIVATED`).
- `AUDIT_ACTION_LABELS` — human-readable labels keyed by audit action code.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  backend [label="Backend API", shape=cylinder];
  raw     [label="Raw datasets\n(users, roles,\naudit, report)"];
  stats   [label="Derived stats\nobject"];

  subgraph cluster_derived {
    label="computeStats outputs";
    style=dashed;
    kpis     [label="total / active /\ndeactivated / events7d"];
    activity [label="activity[]\n(7-day series)"];
    status   [label="statusData[]"];
    roleData [label="roleData[]"];
    top5     [label="activeUsers[] (top 5)"];
    recent   [label="recent[] (last 7)"];
  }

  backend -> raw   [label="Promise.all fetch"];
  raw     -> stats [label="useMemo(computeStats)"];
  stats   -> kpis;
  stats   -> activity;
  stats   -> status;
  stats   -> roleData;
  stats   -> top5;
  stats   -> recent;

  kpis     -> "StatCard row";
  activity -> "AreaTrend";
  status   -> "DonutChart";
  roleData -> "BarChart (roles)";
  top5     -> "BarChart (active users)";
  recent   -> "Activity feed <ul>";
}
```

### Flow Summary

1. **Mount** → `useEffect` fires a single parallel fetch.
2. **Resolve** → Each dataset is stored in its own `useState` slot; a failure populates `error`.
3. **Derive** → `useMemo` recomputes `stats` whenever any raw dataset changes, delegating to the pure `computeStats`.
4. **Transform** (inside `computeStats`):
   - Status counts are tallied via a `byStatus` map.
   - `roleData` is computed by counting users whose `roles` include each role id.
   - A 7-element day array is built and audit events are bucketed by `sameDay`.
   - `activeUsers` sorts the report by `action_count`, takes the top 5, and drops zero-activity rows.
   - `recent` sorts the audit log descending by timestamp and takes the last 7.
5. **Render** → Each derived slice feeds exactly one visual panel; empty slices render fallback text.

---

## 6. Extension Points

### 6.1 Adding a New Metric / Panel

1. Extend `computeStats` to return a new derived field from the existing (or a newly fetched) dataset.
2. Add a corresponding `<section className="card">` in the `panel-grid`, wiring the field to an existing or new chart primitive.
3. Guard with an empty-state check to preserve layout resilience.

### 6.2 Adding a New Data Source

1. Add an API call to the `Promise.all` array and destructure its result.
2. Introduce a `useState` slot and include it in the `computeStats` dependency array.
3. Pass it into `computeStats` and consume within the aggregation.

### 6.3 Theming & Vocabulary

- **Colors:** Adjust `STATUS_COLOR` and `SERIES_BLUE` (module-level constants) to re-theme charts without touching render logic.
- **Action labels:** Extend `AUDIT_ACTION_LABELS` in `constants.js`; the feed automatically falls back to the raw action code for unmapped actions.
- **Feed dot semantics:** The `dotClass` helper classifies actions into `good` / `bad` / `neutral` via substring matching — extend the matching rules here to reflect new audit action categories.

### 6.4 Swapping Chart Implementations

Because chart primitives consume the stable `{ label, value, color }` / `{ label, value }` contracts, individual chart components (`BarChart`, `DonutChart`, `AreaTrend`) can be replaced or re-implemented with a different library without changing Dashboard logic.

### 6.5 Time Helpers

The pure helpers (`pct`, `sameDay`, `fmtDay`, `timeAgo`) are self-contained and candidates for extraction into a shared utilities module if reused elsewhere; `timeAgo` in particular defines the relative-time formatting policy for the activity feed.

---

### Notes & Considerations

- **Client-side aggregation cost:** The 7-day trend and recent feed iterate the full audit log on the client. If the audit dataset grows large, consider a server-side pre-aggregated endpoint (mirroring the pattern already used by `userActivityReport()`).
- **No refetch/polling:** Data is fetched once on mount. Real-time freshness would require adding an interval, a manual refresh trigger, or a subscription mechanism.
- **Single error channel:** A failure in any of the four fetches surfaces one generic banner and leaves all panels empty. For finer resilience, fetches could be settled independently (`Promise.allSettled`) so partial data still renders.