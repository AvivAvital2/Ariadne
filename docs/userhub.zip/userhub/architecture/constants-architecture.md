---
id: 61e27c61-51d8-50d6-a592-f53058a29ee3
type: architecture
title: "Constants Architecture"
created_at: 2026-07-30T17:21:40.751040+00:00
updated_at: 2026-07-30T17:21:40.751055+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  module_name: "backend.app.constants"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

# Architecture Documentation: `backend.app.constants`

## 1. Component Overview

The `backend.app.constants` module defines the **domain vocabulary** shared across the backend and, by convention, mirrored in the frontend. It is a foundational, dependency-light module that establishes the canonical string values forming the **HTTP API contract** between client and server.

### Responsibilities

| Concern | Provided By |
|---|---|
| User account lifecycle states | `UserStatus` |
| Permission strings gating API actions | `Permission` |
| Audit log action verbs | `AuditAction` |
| Valid lifecycle state transitions | `ALLOWED_STATUS_TRANSITIONS` |

This module is intentionally **pure** — it contains no logic beyond enum definitions and a static transition map. It is imported broadly by the service, security, and API layers, so it must remain free of heavy dependencies to avoid import cycles.

---

## 2. Design Decisions

### 2.1 `str`-backed Enums

All three enums subclass `(str, Enum)`. This is deliberate:

- **Direct serialization**: Instances compare equal to and serialize as their raw string value (e.g. `UserStatus.DEACTIVATED == "deactivated"`), so they cross the HTTP boundary without custom encoding.
- **Type safety on the backend**: Server code references symbolic members (`Permission.USERS_DELETE`) instead of magic strings, catching typos at import time.

### 2.2 String Values as the Cross-Boundary Contract

There is **no shared type system across the HTTP boundary**. The frontend (`frontend/src/constants.js`) mirrors these string values by convention. The values themselves — `"deactivated"`, `"users:deactivate"`, `"user.deactivated"` — are the contract.

> **Maintenance rule:** When a value changes here, the mirrored frontend constant **must** be updated in lockstep. The symbolic names may differ; only the string values are binding.

### 2.3 Dual, Independent Enforcement of Permissions

Permission strings serve two enforcement points that share no symbol:

- **Frontend**: hides/disables a UI control when the user lacks the permission.
- **Backend**: independently enforces via `security.require_permission`.

The frontend behavior is a UX affordance only; the backend is the authority. This defense-in-depth posture means a bypassed or stale frontend cannot escalate access.

### 2.4 Transitions as Data, Not Code

`ALLOWED_STATUS_TRANSITIONS` encodes the permitted lifecycle graph as a plain `dict[str, set[str]]` keyed on `.value` strings. This keeps transition policy declarative and inspectable, letting the service layer validate a requested state change with a single membership test rather than branching logic.

---

## 3. Component Diagram

```dot
digraph constants {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_constants {
        label="backend.app.constants";
        style=dashed;

        UserStatus     [label="UserStatus\n(str, Enum)\nactive / invited / deactivated"];
        Permission     [label="Permission\n(str, Enum)\nusers:*, roles:manage, audit:read"];
        AuditAction    [label="AuditAction\n(str, Enum)\nuser.created / user.updated / ..."];
        Transitions    [label="ALLOWED_STATUS_TRANSITIONS\ndict[str, set[str]]", shape=note];
    }

    enum [label="enum (stdlib)", shape=cylinder];

    UserStatus  -> enum [label="subclasses", style=dotted];
    Permission  -> enum [label="subclasses", style=dotted];
    AuditAction -> enum [label="subclasses", style=dotted];
    Transitions -> UserStatus [label="keys/values\nderived from", style=dashed];

    // Consumers (illustrative)
    subgraph cluster_consumers {
        label="Consumers (import site)";
        style=dashed;
        security [label="security.require_permission"];
        service  [label="service layer\n(lifecycle, mutations)"];
        api      [label="API / router layer"];
        audit    [label="audit log writer"];
    }

    security -> Permission  [label="reads"];
    service  -> Transitions [label="validates against"];
    service  -> UserStatus  [label="reads/writes"];
    audit    -> AuditAction [label="writes"];
    api      -> Permission  [label="guards routes"];
}
```

```dot
digraph transitions {
    rankdir=LR;
    label="ALLOWED_STATUS_TRANSITIONS (lifecycle graph)";
    node [shape=circle, fontname="Helvetica"];

    invited     [label="invited"];
    active      [label="active"];
    deactivated [label="deactivated"];

    invited     -> active;
    invited     -> deactivated;
    active      -> deactivated;
    deactivated -> active;
}
```

---

## 4. Interfaces

### 4.1 Public Symbols

| Symbol | Type | Purpose |
|---|---|---|
| `UserStatus` | `str` Enum | Account lifecycle state |
| `Permission` | `str` Enum | Permission identifiers for authz |
| `AuditAction` | `str` Enum | Verbs recorded in the audit log |
| `ALLOWED_STATUS_TRANSITIONS` | `dict[str, set[str]]` | Permitted lifecycle edges |

### 4.2 Integration Points

- **`security.require_permission`** — consumes `Permission` members to gate API actions on the backend.
- **Service layer** — consults `ALLOWED_STATUS_TRANSITIONS` before applying a status change; reads/writes `UserStatus`.
- **Audit log writer** — persists `AuditAction` values.
- **Frontend `frontend/src/constants.js`** — mirrors the string values (out-of-band contract, not a code dependency).

### 4.3 Contract Guarantees

- Every enum member's **value** is a stable string constituting the wire format.
- `ALLOWED_STATUS_TRANSITIONS` keys and values are guaranteed to be members of `UserStatus` (derived via `.value`).

---

## 5. Data Flow

### 5.1 Permission Check Flow
```
Request → API/router → security.require_permission(Permission.X)
                          ├─ granted  → handler proceeds
                          └─ denied   → 403 (backend authority)

(In parallel, decoupled) Frontend reads permission string → shows/hides control
```

### 5.2 Status Transition Flow
```
Client PATCH { status: "active" }
        │
        ▼
Service layer:
   current = user.status                     (UserStatus value)
   requested = "active"
   if requested in ALLOWED_STATUS_TRANSITIONS[current]:
        apply change
        emit AuditAction (e.g. USER_REACTIVATED)
   else:
        reject (invalid transition)
```

### 5.3 Audit Flow
```
Mutation succeeds → audit writer records AuditAction.value ("user.deactivated")
        │
        ▼
Frontend audit view maps string → human label + icon
```

---

## 6. Extension Points

### 6.1 Adding a New Permission
1. Add a member to `Permission` with its `resource:action` string value.
2. Reference it at the backend enforcement site via `security.require_permission`.
3. **Mirror the string** in `frontend/src/constants.js` and wire the UI affordance.

### 6.2 Adding a New Audit Action
1. Add a member to `AuditAction` following the `entity.verb` convention (e.g. `user.reactivated`).
2. Emit it from the service layer where the action occurs.
3. Add the string → label/icon mapping in the frontend audit view.

### 6.3 Adding a New User Status
1. Add a member to `UserStatus`.
2. **Critically**, update `ALLOWED_STATUS_TRANSITIONS` to define inbound and outbound edges — otherwise the service layer will reject all transitions to/from the new state.
3. Mirror the value on the frontend.

### 6.4 Modifying Lifecycle Rules
`ALLOWED_STATUS_TRANSITIONS` is the single source of truth for permitted state changes. Adjusting the graph (adding/removing edges) changes service-layer behavior without touching enforcement code.

### Conventions to Preserve

| Enum | Value convention | Example |
|---|---|---|
| `Permission` | `resource:action` | `users:deactivate` |
| `AuditAction` | `entity.verb` | `user.deactivated` |
| `UserStatus` | lowercase noun | `deactivated` |

> ⚠️ **Cross-boundary invariant:** Any change to an enum **value** is a breaking API change. Update the mirrored frontend constant and coordinate the release. Renaming an enum **member** (not its value) is backend-internal and safe.