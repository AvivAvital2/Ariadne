---
id: f8ba527b-5cf5-5940-ae88-c560c2064e04
type: architecture
title: "Donutchart Architecture"
created_at: 2026-07-30T17:30:03.031877+00:00
updated_at: 2026-07-30T17:30:03.031891+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx
metadata:
  module_name: "frontend.src.components.charts.DonutChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Donutchart Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx`

# DonutChart Component Architecture

**Module**: `frontend.src.components.charts.DonutChart`

---

## 1. Component Overview

`DonutChart` is a presentational (stateless) React component that renders a **part-to-whole ring visualization** with a centered total value and an accompanying labelled legend. It is designed for displaying categorical breakdowns — for example, status distributions (open/closed/pending) or resource allocation.

Its core responsibilities are:

- **Aggregate** a set of labelled values into a total.
- **Render** each value as a proportional arc segment on an SVG ring.
- **Communicate** each segment's meaning through a text legend (label + value), rather than relying on color alone.
- **Display** the aggregate total in the center of the ring.

The component is intentionally self-contained: it has no external dependencies, holds no internal state, performs no data fetching, and delegates all styling to CSS custom properties and class names.

---

## 2. Design Decisions

### Accessibility-first: color is never the sole signal
The header comment states the guiding principle: *"Status colors are never shown alone — the legend carries label + value."* Each ring segment includes an SVG `<title>` (tooltip) with label, value, and percentage, and the parallel legend list restates label + value in text. This makes the chart usable for color-blind users and screen readers. The `role="img"` on the SVG groups it as a single semantic image.

### SVG stroke-dash technique for arcs
Rather than computing complex SVG path `d` attributes, segments are drawn as full `<circle>` elements using `strokeDasharray` and `strokeDashoffset` to reveal only the arc portion. This is a simpler, well-understood pattern:

- `strokeDasharray = "{segmentLength} {remainder}"` draws a visible arc followed by an invisible gap.
- `strokeDashoffset = -offset` rotates each subsequent segment to start where the previous one ended.
- `transform="rotate(-90 ...)"` shifts the start point to the top (12 o'clock) instead of the default 3 o'clock.

### Visual gaps between segments
A fixed `GAP = 2` (px surface gap) is subtracted from each segment's arc length, producing clean visual separation between adjacent segments. `Math.max(..., 0)` guards against negative lengths for very small segments.

### Guard against empty/zero data
Segment rendering is gated behind `total > 0`. When there is no data, only the background track (`var(--track)`) and a `0` total are shown, avoiding division-by-zero artifacts.

### Theming via CSS variables
The track color uses `var(--track)`, and typography/spacing are controlled through class names (`donut`, `donut-total`, `legend`, etc.). This keeps theming and layout concerns outside the component logic.

### Stateless & pure
Given the same `data`, `size`, and `thickness`, the output is deterministic. This makes the component trivial to test, memoize, and reuse.

---

## 3. Component Diagram

```dot
digraph DonutChart {
  rankdir=TB;
  node [shape=box, style=rounded, fontname="Helvetica"];

  Props   [label="Props\n{ data, size, thickness }", shape=note];
  Derived [label="Derived Geometry\ntotal, r, c,\ncircumference, offset"];

  subgraph cluster_render {
    label="Rendered Output (div.donut)";
    style=dashed;

    subgraph cluster_svg {
      label="SVG (role=img)";
      Track   [label="Track Circle\n(var(--track))"];
      Segments[label="Segment Circles\n(strokeDasharray arcs)\n+ <title> tooltips"];
      TotalTxt[label="Center Text\n(total + 'total' label)"];
    }

    Legend [label="Legend (ul)\ndot + label + value\nper data item"];
  }

  Props   -> Derived;
  Props   -> Segments   [label="data.map"];
  Props   -> Legend     [label="data.map"];
  Derived -> Track;
  Derived -> Segments   [label="geometry"];
  Derived -> TotalTxt   [label="total"];
}
```

---

## 4. Interfaces

### Props API

| Prop        | Type     | Default | Description                                                     |
|-------------|----------|---------|-----------------------------------------------------------------|
| `data`      | `Array`  | —       | List of segment descriptors (see shape below). **Required.**    |
| `size`      | `number` | `190`   | Overall width/height of the SVG in pixels.                      |
| `thickness` | `number` | `22`    | Ring stroke width in pixels.                                    |

#### `data` item shape
```ts
interface DonutSegment {
  label: string;  // legend text + tooltip; also used as React key
  value: number;  // magnitude contributing to the total
  color: string;  // stroke/legend-dot color (any CSS color)
}
```

> **Note:** `label` is used as the React `key` for both segments and legend items. Labels must therefore be unique within a single chart.

### Styling contract (integration points)

| Selector             | Role                                              |
|----------------------|---------------------------------------------------|
| `.donut`             | Root container (layout of svg + legend).          |
| `.donut-total`       | Center numeric total styling.                     |
| `.donut-total-label` | Center "total" caption styling.                   |
| `.legend`            | Legend list container.                            |
| `.legend-dot`        | Color swatch (inline `background` set by `color`).|
| `.legend-label`      | Segment label text.                               |
| `.legend-value`      | Segment value text.                               |
| `--track`            | CSS variable for the background ring color.       |

The consuming application **must** provide CSS for these classes and define `--track` for the component to render correctly.

---

## 5. Data Flow

```dot
digraph DataFlow {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  data [label="data[]", shape=cylinder];
  reduce [label="reduce() -> total"];
  geom [label="compute r, c,\ncircumference"];
  loop [label="per-segment loop\nfrac, len, offset"];
  svg [label="SVG arcs +\ncenter total"];
  legend [label="legend rows"];

  data -> reduce -> geom;
  geom -> loop;
  data -> loop;
  loop -> svg;
  data -> legend;
  reduce -> svg [label="total"];
}
```

**Step-by-step:**

1. **Aggregate** — `data.reduce()` computes `total` (sum of all values).
2. **Geometry** — Compute radius `r`, center `c`, and `circumference` from `size` and `thickness`.
3. **Guard** — If `total > 0`, proceed to segment rendering; otherwise render only the track.
4. **Per-segment accumulation** — A running `offset` accumulator tracks the cumulative arc position. For each item:
   - `frac = d.value / total` → the segment's share.
   - `len = max(frac * circumference - GAP, 0)` → visible arc length.
   - `strokeDashoffset = -offset` positions the segment.
   - `offset += frac * circumference` advances the cursor for the next segment.
5. **Center label** — Renders `total` and the caption `"total"`.
6. **Legend** — Independently maps `data` to legend rows (dot + label + value).

> The `offset` variable is a **mutable accumulator local to the render pass**. Because the component is pure and re-created on each render, this mutation is safe and side-effect free.

---

## 6. Extension Points

### Styling & theming
The primary customization surface is CSS. Override the documented class selectors or redefine `--track` to re-skin the chart per theme (light/dark, brand palettes) without touching component code.

### Sizing
`size` and `thickness` props allow the ring to be scaled and thinned/thickened for different layout contexts (compact cards vs. hero panels).

### Recommended enhancements (not yet implemented)
These are natural extension points a maintainer might add while preserving the current design principles:

- **Empty-state slot**: A prop (e.g., `emptyLabel`) to override the center display when `total === 0`.
- **Value formatting**: A `formatValue` function prop to render currency, percentages, or abbreviated numbers in the center and legend.
- **Center content override**: A `centerLabel` prop to replace the hardcoded `"total"` caption.
- **Interaction callbacks**: An `onSegmentClick(segment)` handler to make segments/legend rows interactive for drill-down.
- **Segment ordering / minimum arc**: Configurable `GAP` or a minimum visible arc length so very small segments remain perceivable.

### Constraints to preserve when extending
- **Never rely on color alone** — any new visual encoding must be mirrored by textual/legend information (core accessibility invariant).
- **Keep it pure/stateless** — new behavior should be driven by props, not internal state, to retain testability and predictability.
- **Unique `label`s** — since labels serve as React keys, any extension must maintain uniqueness or introduce an explicit `id` field.