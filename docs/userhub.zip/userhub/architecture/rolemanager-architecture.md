---
id: a1e7cb25-ee37-5950-a361-65f6af76d919
type: architecture
title: "Rolemanager Architecture"
created_at: 2026-07-30T17:27:50.361615+00:00
updated_at: 2026-07-30T17:27:50.361628+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx
metadata:
  module_name: "frontend.src.components.RoleManager"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Rolemanager Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx`

# RoleManager Component Architecture

## 1. Component Overview

`RoleManager` is a React functional component responsible for the presentation and management of **role-based access control (RBAC)** entities within the frontend application. It serves two primary responsibilities:

1. **Display** — Lists all existing roles along with their descriptions and associated permissions (available to any authenticated actor).
2. **Management** — Provides a form to create new roles with selectable permissions (gated behind the `ROLES_MANAGE` permission).

The component is self-contained: it owns its local state, fetches its own data on mount, and renders a complete UI section. It receives the current user context via a single `actor` prop.

---

## 2. Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Permission-gated rendering** | The "New role" form and the fetch of the full permissions catalog only occur when `canManage` is true. This prevents unauthorized users from seeing management controls and avoids unnecessary API calls (`listPermissions`). |
| **Self-fetching component** | The component triggers `load()` in a `useEffect` keyed on `actor`. This keeps data loading co-located with rendering, reducing coupling to parent components at the cost of not being a pure presentational component. |
| **Local component state via hooks** | Form fields (`name`, `description`, `permIds`) and fetched data (`roles`, `permissions`) are held in `useState`. No global store dependency keeps the component portable and easy to reason about. |
| **Centralized permission check** | `hasPermission` combined with the `PERMISSIONS` constants ensures a single source of truth for authorization logic rather than hard-coded strings. |
| **Optimistic reset + reload pattern** | After a successful `createRole`, the form is reset and `load()` re-runs to reflect the new server state. This favors correctness (server-truth) over perceived speed (no optimistic UI insertion). |
| **Error surfaced via single `error` state** | All async failures funnel into one `error` state rendered as an inline banner, keeping error handling uniform. |

---

## 3. Component Diagram

```dot
digraph RoleManager {
  rankdir=LR;
  node [shape=box, style=rounded, fontname="Helvetica"];

  subgraph cluster_component {
    label="RoleManager (React Component)";
    style=dashed;

    actor    [label="prop: actor", shape=note];
    state    [label="Local State\n(roles, permissions,\nname, description,\npermIds, error)", shape=folder];
    load     [label="load()"];
    create   [label="createRole()"];
    toggle   [label="togglePerm()"];
    canManage[label="canManage\n(derived)", shape=ellipse];
    render   [label="Render\n(Roles table +\nNew role form)"];
  }

  subgraph cluster_deps {
    label="Dependencies";
    style=dashed;

    api        [label="api/client.js\n(listRoles, listPermissions,\ncreateRole)", shape=component];
    permMod    [label="auth/permissions.js\n(hasPermission)", shape=component];
    constants  [label="constants.js\n(PERMISSIONS)", shape=component];
  }

  backend [label="Backend REST API", shape=cylinder];

  actor -> canManage;
  actor -> load;
  constants -> canManage;
  permMod -> canManage;

  load -> api;
  create -> api;
  api -> backend [dir=both, label="HTTP"];

  load -> state;
  create -> state;
  toggle -> state;
  canManage -> render;
  state -> render;
}
```

---

## 4. Interfaces

### Inbound (Props)

| Prop | Type | Description |
|------|------|-------------|
| `actor` | object | The authenticated user context. Used to (a) trigger initial data load and (b) evaluate management permissions. When falsy, no fetch occurs. |

### Outbound (API Client — `../api/client.js`)

| Function | Signature | Purpose |
|----------|-----------|---------|
| `listRoles()` | `() => Promise<Role[]>` | Fetches all roles with nested `permissions`. |
| `listPermissions()` | `() => Promise<Permission[]>` | Fetches the full permission catalog (management only). |
| `createRole(payload)` | `({ name, description, permission_ids }) => Promise<Role>` | Persists a new role. |

### Authorization Interface (`../auth/permissions.js`, `../constants.js`)

| Symbol | Purpose |
|--------|---------|
| `hasPermission(actor, permission)` | Boolean check controlling management capability. |
| `PERMISSIONS.ROLES_MANAGE` | Constant identifying the required permission. |

### Data Contracts (inferred)

```text
Role       = { id, name, description, permissions: Permission[] }
Permission = { id, name }
```

---

## 5. Data Flow

### Load Flow (on mount / actor change)
```
actor set → useEffect fires → load()
  ├─ api.listRoles()        → setRoles(...)
  └─ if canManage:
       api.listPermissions() → setPermissions(...)
  └─ on failure → setError(message)
```

### Create Flow (form submission)
```
user fills form → togglePerm() updates permIds
submit → createRole(event)
  ├─ event.preventDefault()
  ├─ api.createRole({ name, description, permission_ids: permIds })
  ├─ reset name/description/permIds
  ├─ load()  ← re-fetch to reflect new state
  └─ on failure → setError(message)
```

### Render Flow
```
roles          → Roles table (always shown)
error          → inline error banner (conditional)
canManage      → gates the "New role" section
permissions    → checkbox grid inside form (management only)
permIds        → controls checkbox checked state
```

---

## 6. Extension Points

The component is intentionally minimal; the following are natural seams for extension or customization:

1. **Additional Role Operations**
   Edit/delete are not implemented. Add columns/action buttons to the roles table and corresponding `api.updateRole` / `api.deleteRole` calls, following the existing `createRole → load` pattern.

2. **Permission Model Swap**
   Authorization is fully delegated to `hasPermission` + `PERMISSIONS`. New capability gates (e.g., `ROLES_VIEW`) can be added by introducing further derived booleans without touching render logic structure.

3. **API Client Abstraction**
   All backend interaction routes through `../api/client.js`. Redirecting to a different backend, adding request interceptors, or mocking in tests is done at that boundary — the component requires no changes.

4. **State Management Migration**
   Should shared role state become necessary across the app, the local `roles`/`permissions` state and `load()` could be lifted into a context provider or global store, with `RoleManager` consuming rather than fetching.

5. **UI Theming / Layout**
   Presentation relies on CSS class names (`card`, `stack`, `tag`, `form-grid`, etc.). Styling is externalized, so visual customization requires no logic changes.

6. **Validation & Error Presentation**
   The single `error` state and inline banner can be extended into field-level validation or a shared toast/notification system by expanding the catch handlers and error-rendering block.

---

### Maintenance Notes
- **Actor dependency**: The `useEffect` dependency array is `[actor]`. Ensure the parent passes a stable reference to avoid redundant fetches on every render.
- **Reload cost**: `createRole` triggers a full `load()`. For large role sets, consider optimistic insertion or paginated fetching.
- **Permission fetch gating**: `listPermissions` is skipped for non-managers by design — do not move it outside the `canManage` guard without reconsidering authorization exposure.