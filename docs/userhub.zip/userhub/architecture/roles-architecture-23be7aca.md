---
id: 23be7aca-1198-519f-9a4c-6c30ba056bca
type: architecture
title: "Roles Architecture"
created_at: 2026-07-30T17:25:36.680148+00:00
updated_at: 2026-07-30T17:25:36.680163+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  module_name: "backend.app.services.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles Architecture

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

# Architecture Documentation: Roles Service

**Module**: `backend.app.services.roles`

---

## 1. Component Overview

The Roles Service is a **domain service layer** module responsible for encapsulating role and permission data operations for the application's Role-Based Access Control (RBAC) subsystem. It sits between the HTTP transport layer (API routes) and the persistence layer (SQLAlchemy models), providing a focused, reusable set of query and mutation operations.

### Responsibilities

| Function | Responsibility |
|----------|----------------|
| `list_roles` | Retrieve all roles, alphabetically ordered by name |
| `get_role` | Fetch a single role by ID, raising a 404 if absent |
| `create_role` | Create a new role with optional permission associations, enforcing name uniqueness |
| `list_permissions` | Retrieve all permissions, alphabetically ordered by name |

The service does **not** own its own database session; instead it operates on an injected `Session`, keeping it agnostic to transaction and connection lifecycle management.

---

## 2. Design Decisions

### 2.1 Session Injection (Dependency Inversion)
Every function accepts a `db: Session` parameter rather than creating its own session. This enables:
- Consistent request-scoped transaction boundaries (typically managed by a FastAPI dependency).
- Simplified testing via session mocking or in-memory databases.
- Reuse across multiple callers within the same unit of work.

### 2.2 HTTP-Aware Error Handling
The service raises `fastapi.HTTPException` directly (404 for missing roles, 409 for duplicate names). This is a deliberate trade-off:

- **Benefit**: Concise error propagation with correct HTTP semantics, avoiding a separate exception-translation layer.
- **Cost**: Couples the service to the FastAPI framework, reducing portability if the persistence logic were reused outside an HTTP context.

This is acceptable for a web-first application where the service layer exists specifically to back REST endpoints.

### 2.3 Keyword-Only Mutation Arguments
`create_role` uses `*` to enforce keyword-only arguments (`name`, `description`, `permission_ids`). This improves call-site readability and guards against positional-argument mistakes for a multi-field mutation.

### 2.4 Explicit Commit on Write
`create_role` performs `add → commit → refresh` internally, ensuring the returned entity reflects the persisted state (including DB-generated fields). Read operations remain side-effect free.

### 2.5 Stateless, Function-Based Design
The module uses plain functions rather than a class. There is no per-instance state to preserve; all context flows through parameters. This keeps the surface area minimal and testable.

---

## 3. Component Diagram

```dot
digraph roles_service {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_transport {
        label="Transport Layer";
        style=dashed;
        api_routes [label="API Routes\n(FastAPI endpoints)"];
    }

    subgraph cluster_service {
        label="Service Layer\n(app.services.roles)";
        style=filled;
        fillcolor="#eef6ff";
        list_roles      [label="list_roles(db)"];
        get_role        [label="get_role(db, role_id)"];
        create_role     [label="create_role(db, *, name,\ndescription, permission_ids)"];
        list_permissions[label="list_permissions(db)"];
    }

    subgraph cluster_persistence {
        label="Persistence Layer";
        style=dashed;
        session [label="SQLAlchemy Session", shape=cylinder];
        Role    [label="Role model", shape=component];
        Permission [label="Permission model", shape=component];
        db_store [label="Database", shape=cylinder, style=filled, fillcolor="#f0f0f0"];
    }

    # Inbound calls
    api_routes -> list_roles;
    api_routes -> get_role;
    api_routes -> create_role;
    api_routes -> list_permissions;

    # Service to persistence
    list_roles       -> session;
    get_role         -> session;
    create_role      -> session;
    list_permissions -> session;

    session -> Role;
    session -> Permission;
    session -> db_store [dir=both];

    # Error propagation
    get_role    -> api_routes [label="404 HTTPException", style=dotted, constraint=false];
    create_role -> api_routes [label="409 HTTPException", style=dotted, constraint=false];
}
```

---

## 4. Interfaces

### 4.1 Public API

```python
def list_roles(db: Session) -> list[Role]
def get_role(db: Session, role_id: int) -> Role
def create_role(db: Session, *, name: str, description: str,
                permission_ids: list[int]) -> Role
def list_permissions(db: Session) -> list[Permission]
```

### 4.2 Integration Points

| Integration Point | Contract |
|-------------------|----------|
| **Inbound** — Callers (API routes) | Must supply a valid, request-scoped `Session`. Callers should be prepared for `HTTPException` propagation. |
| **Outbound** — `app.models` | Depends on `Role` and `Permission` ORM models. Assumes a many-to-many relationship exposed via `Role.permissions`. |
| **Outbound** — SQLAlchemy | Uses the `Session` query API (`query`, `get`, `filter`, `order_by`, `add`, `commit`, `refresh`). |

### 4.3 Error Contract

| Condition | Status | Detail |
|-----------|--------|--------|
| Role ID not found (`get_role`) | 404 | `"role not found"` |
| Duplicate role name (`create_role`) | 409 | `"role already exists"` |

---

## 5. Data Flow

### 5.1 Read Flow (`list_roles`, `get_role`, `list_permissions`)

```dot
digraph read_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    caller [label="Caller (route)"];
    fn     [label="Service function"];
    q      [label="SQLAlchemy Query\n(order_by / get / filter)"];
    dbn    [label="Database", shape=cylinder];

    caller -> fn      [label="db + params"];
    fn     -> q       [label="build query"];
    q      -> dbn     [label="SELECT"];
    dbn    -> q       [label="rows"];
    q      -> fn      [label="ORM objects"];
    fn     -> caller  [label="Role[] / Role / Permission[]"];
}
```

Reads are pure lookups. `get_role` adds a null-check that converts an absent record into a 404.

### 5.2 Write Flow (`create_role`)

1. **Uniqueness check** — query `Role` by `name`; if a match exists, raise **409**.
2. **Instantiate** — construct a new `Role(name, description)`.
3. **Associate permissions** — if `permission_ids` provided, resolve them via `Permission.id.in_(...)` and assign to `role.permissions`.
4. **Persist** — `add` → `commit` → `refresh` to return a fully populated entity.

```dot
digraph write_flow {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    start   [label="create_role(db, name,\ndescription, permission_ids)"];
    check   [label="Name exists?", shape=diamond];
    conflict[label="raise 409", shape=box, style="rounded,filled", fillcolor="#ffdddd"];
    build   [label="new Role(name, description)"];
    hasperm [label="permission_ids provided?", shape=diamond];
    resolve [label="query Permission\nWHERE id IN (...)"];
    assign  [label="role.permissions = [...]"];
    persist [label="add + commit + refresh"];
    done    [label="return Role", shape=box, style="rounded,filled", fillcolor="#ddffdd"];

    start   -> check;
    check   -> conflict [label="yes"];
    check   -> build    [label="no"];
    build   -> hasperm;
    hasperm -> resolve  [label="yes"];
    hasperm -> persist  [label="no"];
    resolve -> assign -> persist;
    persist -> done;
}
```

---

## 6. Extension Points

### 6.1 Adding New Role Operations
New role/permission queries should follow the established conventions:
- Accept `db: Session` as the first parameter.
- Use keyword-only arguments for multi-field writes.
- Raise `HTTPException` with appropriate status codes for domain errors.

### 6.2 Update / Delete Support
The module currently exposes create and read operations. Natural extensions include:
- `update_role(db, role_id, *, name, description, permission_ids)` — reuse `get_role` for lookup, then re-check name uniqueness against *other* roles.
- `delete_role(db, role_id)` — fetch via `get_role`, then `db.delete(role)` + `commit`.

### 6.3 Filtering & Pagination
`list_roles` and `list_permissions` return unbounded result sets. To scale, extend signatures with optional `limit`, `offset`, or filter parameters while preserving default behavior.

### 6.4 Decoupling from FastAPI (Optional)
If the persistence logic must be reused outside HTTP contexts, replace `HTTPException` with domain-specific exceptions (e.g., `RoleNotFoundError`, `RoleAlreadyExistsError`) and translate them at the transport boundary. This trades conciseness for portability.

### 6.5 Permission Validation
`create_role` silently ignores `permission_ids` that do not correspond to existing `Permission` rows (the `IN` filter simply omits them). A stricter extension could compare the requested count against the resolved count and raise a validation error on mismatch.

---

## Summary

The `roles` service is a thin, stateless data-access layer for RBAC entities. Its key architectural characteristics are **session injection** for transaction flexibility, **HTTP-aware error handling** for concise route integration, and **function-based statelessness** for testability. The main trade-off is a deliberate coupling to FastAPI's exception model, which is appropriate for its role as a web-backing service.