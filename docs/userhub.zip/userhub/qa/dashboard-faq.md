---
id: f744c931-29aa-571e-9b33-a4bac4569dcd
type: qa
title: "Dashboard FAQ"
created_at: 2026-07-30T17:27:46.403196+00:00
updated_at: 2026-07-30T17:27:46.403211+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx
metadata:
  module_name: "frontend.src.components.Dashboard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Dashboard FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx`

# Dashboard Component — FAQ

## Question
What does the `Dashboard` component do and what data does it need?

## Answer
`Dashboard` is a self-contained React component that renders an admin analytics view: stat cards, an activity trend chart, status/role breakdowns, a "most active users" chart, and a recent-activity feed.

It fetches all of its own data on mount from the API client — you don't pass any props:

```jsx
import Dashboard from "./components/Dashboard.jsx";

function App() {
  return <Dashboard />;
}
```

On mount it calls four endpoints in parallel:

```javascript
Promise.all([
  api.listUsers(),
  api.listRoles(),
  api.listAudit(),
  api.userActivityReport(),
])
```

Each result is stored in its own piece of state (`users`, `roles`, `audit`, `report`), and the derived analytics are computed by `computeStats`.

---

## Question
Where does the analytics logic live, and how is it kept from recomputing on every render?

## Answer
All aggregation happens in the pure helper `computeStats(users, roles, audit, report)`. The component wraps it in `useMemo` so it only re-runs when one of its dependencies changes:

```javascript
const stats = useMemo(
  () => computeStats(users, roles, audit, report),
  [users, roles, audit, report],
);
```

Because the four state values only change once (after the initial fetch resolves), `computeStats` typically runs once per data load. If you add more re-render triggers (e.g. a filter), keep `computeStats` pure and dependency-driven so the memoization stays correct.

---

## Question
How is the 7-day activity trend calculated?

## Answer
`computeStats` builds an array of the last 7 `Date` objects (oldest first), then buckets each audit event into the matching day using a `sameDay` comparison:

```javascript
const counts = days.map(() => 0);
audit.forEach((e) => {
  const t = new Date(e.created_at);
  const idx = days.findIndex((d) => sameDay(d, t));
  if (idx >= 0) counts[idx] += 1;
});
```

The result is exposed as `stats.activity` (an array of `{ label, value }`, labeled with the weekday short name), and `stats.events7d` is the total count. Events older than 7 days are ignored (`findIndex` returns `-1`).

**Gotcha:** `sameDay` compares using the browser's local timezone (`getFullYear/getMonth/getDate`). If your audit timestamps are UTC and your users span timezones, events near midnight may land in a different bucket than expected.

---

## Question
How do the status colors and audit-action styling get configured?

## Answer
Two things drive the visual encoding:

1. **Status colors** for the donut chart come from the `STATUS_COLOR` map keyed by `USER_STATUS`:

```javascript
const STATUS_COLOR = {
  [USER_STATUS.ACTIVE]: "#0ca30c",
  [USER_STATUS.INVITED]: "#fab219",
  [USER_STATUS.DEACTIVATED]: "#d03b3b",
};
```

2. **Feed dot styling** is derived from the action string by `dotClass`:

```javascript
function dotClass(action) {
  if (action.includes("deactivated") || action.includes("deleted")) return "bad";
  if (action.includes("created") || action.includes("reactivated")) return "good";
  return "neutral";
}
```

To change colors, edit `STATUS_COLOR` and `SERIES_BLUE`. To change how actions map to dot classes, update the substring checks in `dotClass`. Note this matching is substring-based, so a new action containing `"created"` will automatically be styled "good".

---

## Question
How does the "Most active users" chart differ from "Users per role"?

## Answer
They use different data sources:

- **Users per role** (`roleData`) is computed client-side by counting how many users hold each role:

```javascript
const roleData = roles.map((r) => ({
  label: r.name,
  value: users.filter((u) => u.roles.some((x) => x.id === r.id)).length,
  color: SERIES_BLUE,
}));
```

- **Most active users** (`activeUsers`) comes from a server-side SQL report (`api.userActivityReport()`), sorted by `action_count`, limited to the top 5, and filtered to non-zero counts:

```javascript
const activeUsers = report
  .slice()
  .sort((a, b) => b.action_count - a.action_count)
  .slice(0, 5)
  .filter((r) => r.action_count > 0)
  .map((r) => ({ label: r.username, value: r.action_count, color: SERIES_BLUE }));
```

Note the use of `report.slice()` before sorting — this avoids mutating the original `report` state array in place, which is important because `Array.prototype.sort` mutates.

---

## Question
How are errors from the API surfaced?

## Answer
The `Promise.all` chain has a single `.catch` that stores the message in `error` state:

```javascript
.catch((e) => setError(e.message));
```

If any of the four requests fails, the whole batch rejects and an error banner renders at the top:

```jsx
{error && <div className="error">{error}</div>}
```

**Pitfalls to be aware of:**
- It's **all-or-nothing** — one failed endpoint blocks all data, and the dashboard renders with empty stats plus the error banner.
- Only `e.message` is captured, so non-`Error` rejections (e.g. a rejected string) may show `undefined`.
- There's **no loading state**. Before the fetch resolves, everything renders with empty arrays (zeros and "No activity yet." messages). If you want a spinner, add an `isLoading` flag.

---

## Question
Why do the empty states render even when there's no error?

## Answer
Because all state starts as empty arrays (`useState([])`), `computeStats` runs against empty data and produces `0` values and empty chart data. The JSX guards each section:

```jsx
{stats.roleData.length ? <BarChart data={stats.roleData} /> : <p className="empty">No roles yet.</p>}
```

```jsx
{stats.recent.length === 0 && <li className="feed-empty">No activity yet.</li>}
```

This means the "empty" and "No activity yet." states show both during the initial (pre-fetch) render **and** when data legitimately comes back empty. If you need to distinguish "still loading" from "genuinely empty," track a separate loaded flag.

---

## Question
How does the `timeAgo` helper work, and are there edge cases?

## Answer
`timeAgo` converts an ISO timestamp into a relative string with second/minute/hour/day granularity:

```javascript
function timeAgo(iso) {
  const secs = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (secs < 60) return "just now";
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}
```

Edge cases:
- It **does not update live** — the string is computed at render time. A "2m ago" event won't tick to "3m ago" unless the component re-renders.
- Future timestamps produce negative `secs`, which still falls under `< 60` and returns `"just now"`.
- It maxes out at days (no weeks/months), so a 90-day-old event reads `"90d ago"`.

---

## Question
What's the safest way to extend the dashboard with a new stat card or chart?

## Answer
Follow the existing pattern:

1. **Add the derived value** inside `computeStats` and return it in the stats object (keep the function pure).
2. **Render it** using the shared `StatCard` or chart components.

For example, to add an "Invited" stat card (the `invited` count is already computed):

```jsx
<StatCard
  icon={IconUsers}
  tone="warning"
  label="Invited"
  value={stats.invited}
  hint={pct(stats.invited, stats.total)}
/>
```

Best practices:
- Do computation in `computeStats`, not inline in JSX, so it benefits from `useMemo`.
- Use the `pct(n, total)` helper for percentages — it safely returns `"0%"` when `total` is `0`, avoiding `NaN%`.
- When sorting arrays from state, always `.slice()` first to avoid mutating React state.
- Reuse `SERIES_BLUE` and `STATUS_COLOR` for consistent theming rather than hardcoding new hex values.