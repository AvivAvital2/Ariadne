---
id: 42636674-b35a-5416-b934-ab7a6be988b9
type: qa
title: "Client FAQ"
created_at: 2026-07-30T17:26:58.836167+00:00
updated_at: 2026-07-30T17:26:58.836181+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js
metadata:
  module_name: "frontend.src.api.client"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Client FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js`

# API Client FAQ

The `frontend.src.api.client` module is the single interface between the frontend and backend. This FAQ covers common questions about using it.

---

## How do I make my first API call?

## Answer
Import the function you need and call it. Every function returns a `Promise` that resolves to the parsed JSON response (or `null` for empty responses).

```javascript
import { getCurrentUser, listUsers } from "./api/client.js";

// Fetch the current logged-in user
const me = await getCurrentUser();

// Fetch all users
const users = await listUsers();
```

You never call `fetch` directly—every request is routed through the internal `request` helper, which sets headers, serializes the body, and handles errors consistently.

---

## What is the actor ID, and how do I change who is "logged in"?

## Answer
Because there is no authentication layer, the client sends an `X-Actor-Id` header identifying the acting user. It defaults to the seeded admin (`id 1`). Use `setActor` to switch users:

```javascript
import { setActor, getCurrentUser } from "./api/client.js";

setActor(5);              // All subsequent requests act as user 5
const me = await getCurrentUser(); // Returns user 5

setActor(1);              // Back to the admin
```

**Note:** `setActor` mutates a module-level variable, so the change is global and persists across all future calls until changed again. There is no per-request override.

---

## How do I filter results, such as listing only active users?

## Answer
Functions that support filtering accept an optional argument that becomes a query-string parameter. Passing nothing (or a falsy value) returns the unfiltered list.

```javascript
import { listUsers, listAudit } from "./api/client.js";
import { USER_STATUS } from "./constants.js";

const activeUsers = await listUsers(USER_STATUS.ACTIVE);  // /api/users?status=active
const allUsers    = await listUsers();                    // /api/users

const loginEvents = await listAudit("login");             // /api/audit?action=login
const allAudit    = await listAudit();                    // /api/audit
```

The filter value is passed through `encodeURIComponent`, so special characters are safely escaped.

---

## How do I create or update a user?

## Answer
Use `createUser` for new records and `updateUser` for existing ones. Both take a payload object that is JSON-serialized into the request body.

```javascript
import { createUser, updateUser } from "./api/client.js";

// Create
const newUser = await createUser({
  name: "Ada Lovelace",
  email: "ada@example.com",
});

// Update (PUT — send the full representation)
const updated = await updateUser(newUser.id, {
  name: "Ada L.",
  email: "ada@example.com",
});
```

Since `updateUser` uses `PUT`, follow your backend's expectations for whether partial or full payloads are accepted.

---

## What's the difference between `setUserStatus`, `deactivateUser`, and `reactivateUser`?

## Answer
`setUserStatus` is the low-level function that `PATCH`es the status route with any status string. `deactivateUser` and `reactivateUser` are convenience wrappers around it using the shared `USER_STATUS` constants.

```javascript
import {
  setUserStatus,
  deactivateUser,
  reactivateUser,
} from "./api/client.js";
import { USER_STATUS } from "./constants.js";

await deactivateUser(3);   // status: USER_STATUS.DEACTIVATED
await reactivateUser(3);   // status: USER_STATUS.ACTIVE

// Equivalent to deactivateUser, but explicit:
await setUserStatus(3, USER_STATUS.DEACTIVATED);
```

Prefer the wrappers for readability. Reach for `setUserStatus` directly only if you need a status value not covered by a helper.

---

## How do I assign roles to a user?

## Answer
Call `assignRoles` with the user ID and an array of role IDs. Internally this maps to a `{ role_ids: [...] }` body.

```javascript
import { assignRoles } from "./api/client.js";

await assignRoles(7, [1, 2, 5]);  // POST /api/users/7/roles
```

To discover which role IDs are available, use `listRoles()`. To see all assignable permissions, use `listPermissions()`.

---

## How does error handling work?

## Answer
The `request` helper checks `response.ok`. On a non-2xx status it throws an `Error`, preferring the backend's `detail` field and falling back to a generic message. Wrap calls in `try/catch`:

```javascript
import { getUser } from "./api/client.js";

try {
  const user = await getUser(999);
} catch (err) {
  // err.message is either the backend's `detail`
  // or "GET /api/users/999 failed (404)"
  console.error(err.message);
}
```

Key points:
- Rejections are thrown as `Error` objects—always `await` inside `try/catch` or attach `.catch()`.
- If the backend returns an error body without valid JSON, the `.catch(() => ({}))` guard prevents a parse crash, and you get the generic fallback message.

---

## Why do some calls return `null` instead of data?

## Answer
When the backend responds with `204 No Content`, `request` returns `null` rather than attempting to parse an empty body. This commonly happens with `deleteUser`:

```javascript
import { deleteUser } from "./api/client.js";

const result = await deleteUser(4);
// result === null on a 204 response
```

Don't assume every call resolves to an object—check for `null` when the endpoint may return no content.

---

## Can I use this client outside async/await?

## Answer
Yes. Every function returns a `Promise`, so you can chain with `.then()`/`.catch()` if you prefer:

```javascript
import { listRoles } from "./api/client.js";

listRoles()
  .then((roles) => console.log(roles))
  .catch((err) => console.error(err.message));
```

`async/await` is generally cleaner, but the client works with either style.

---

## What are the common pitfalls to watch out for?

## Answer
1. **Global actor state:** `setActor` affects *all* subsequent requests. In concurrent scenarios (e.g., switching actors mid-flight), the active actor at the moment `fetch` runs is what's sent—be careful in parallel code.
2. **Forgetting to `await`:** Since functions return Promises, forgetting `await` (or `.then`) means you won't catch errors and will work with a pending Promise instead of data.
3. **Relative URLs:** All URLs are relative (e.g., `/api/users`). The client relies on the frontend being served from the same origin as the backend, or on a dev proxy. Cross-origin setups need proxy/CORS configuration.
4. **`null` responses:** As noted above, `204` responses return `null`—handle this explicitly for delete/status operations.
5. **PUT semantics:** `updateUser` uses `PUT`; confirm whether your backend expects the full resource representation to avoid unintentionally clearing fields.