---
id: b341c4af-999e-5b73-9bc3-8ed9f7998e84
type: qa
title: "Styles FAQ"
created_at: 2026-07-30T17:31:17.839294+00:00
updated_at: 2026-07-30T17:31:17.839309+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css
metadata:
  module_name: "frontend.src.styles"
  language: "css"
  provenance: "code-derived"
  source_name: "userhub"
---
# Styles FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css`

# FAQ: Dashboard Stylesheet (`frontend.src.styles`)

This stylesheet provides a complete design system for an admin dashboard layout, including a dark sidebar, light content area, data visualization components, tables, forms, and modals. Below are common questions developers may have when working with it.

---

## Question
How do I set up the basic page layout with a sidebar and main content area?

## Answer
The stylesheet uses a flex-based layout. Wrap your app in a `.layout` container, then place a `.sidebar` and a `.main` column inside it. The `.main` column typically contains a `.topbar` and a `.content` area.

```html
<div class="layout">
  <aside class="sidebar">
    <!-- brand, nav, footer -->
  </aside>
  <div class="main">
    <header class="topbar">...</header>
    <main class="content">...</main>
  </div>
</div>
```

Key details:
- `.sidebar` is fixed at `240px` wide (`flex: 0 0 240px`) and sticky at the top with `height: 100vh`.
- `.main` uses `flex: 1` and `min-width: 0` (important to prevent flex overflow issues with wide tables/charts).
- `.content` provides the inner padding (`24px 28px`).

Remember to set `#root`, `html`, and `body` to `height: 100%` — the stylesheet already does this, so mounting into `#root` works out of the box.

---

## Question
How do I customize the color theme?

## Answer
All colors are defined as CSS custom properties on `:root`. Override them in your own stylesheet (loaded after this one) or on `:root` directly. You don't need to touch individual component rules.

```css
:root {
  --primary: #7c3aed;      /* change the accent color */
  --primary-ink: #6d28d9;  /* darker hover variant */
  --page: #fafafa;         /* content background */
  --sidebar-bg: #1e1b4b;   /* sidebar background */
}
```

The palette is grouped into:
- **Sidebar tokens**: `--sidebar-bg`, `--sidebar-fg`, `--sidebar-muted`
- **Content tokens**: `--page`, `--card`, `--ink`, `--ink-2`, `--muted`, `--faint`, `--line`, `--track`, `--grid`
- **Status/data-viz palette**: `--primary`, `--primary-ink`, `--good`, `--warning`, `--critical`
- **Shape tokens**: `--radius` (12px), `--shadow`

**Gotcha:** Some status colors are *not* fully tokenized. Tinted backgrounds use hardcoded `rgba()` values (e.g. `rgba(42, 120, 214, 0.12)` for `tone-primary`), and some text colors are hardcoded hex (e.g. `#b5790a` for warning icons, `#0a7d0a` for active badges). If you change `--primary` or `--critical`, you'll also need to update those matching rgba/hex values manually.

---

## Question
How do I build a row of stat/KPI cards, and how do I color them?

## Answer
Use `.stat-row` (a 4-column grid) containing `.stat-card` elements. Each card has an icon, a value, a label, and an optional hint.

```html
<div class="stat-row">
  <div class="stat-card">
    <div class="stat-icon tone-primary"><!-- icon svg --></div>
    <div>
      <div class="stat-value">1,204</div>
      <div class="stat-label">Total Users</div>
      <div class="stat-hint">+12% this month</div>
    </div>
  </div>
</div>
```

Apply a **tone modifier** to `.stat-icon` to set the icon color and its tinted background:
- `.tone-primary` — blue accent
- `.tone-good` — green
- `.tone-critical` — red
- `.tone-warning` — amber

`.stat-row` is fixed at 4 columns but automatically collapses to 2 columns below `980px` (see the responsive section).

---

## Question
What status badges are available and how do I use them?

## Answer
`.badge` renders a pill-shaped label. Add a status modifier to control its colors:

```html
<span class="badge active">active</span>
<span class="badge invited">invited</span>
<span class="badge deactivated">deactivated</span>
```

| Modifier | Meaning | Colors |
|----------|---------|--------|
| `.active` | Enabled/live | Green tint |
| `.invited` | Pending | Amber tint |
| `.deactivated` | Disabled | Red tint |

The base `.badge` uses `text-transform: capitalize`, so you can pass lowercase text (`active`) and it will display as `Active`. Only these three status variants exist — adding a new status requires defining a new modifier class.

---

## Question
What button styles are available?

## Answer
Use `.btn` as the base class plus a variant modifier. Add `.sm` for a smaller size.

```html
<button class="btn primary">Save</button>
<button class="btn ghost">Cancel</button>
<button class="btn danger">Delete</button>
<button class="btn primary sm">Add</button>
```

| Variant | Use case | Appearance |
|---------|----------|------------|
| `.primary` | Main action | Filled with `--primary`, darkens on hover |
| `.ghost` | Secondary action | White with border |
| `.danger` | Destructive action | White with red border/text |

All buttons inherit the app font (`font-family: inherit`) and use `inline-flex` with a `6px` gap, so you can place an icon and text side by side.

---

## Question
How do the data visualization components (donut, bars, area chart) work?

## Answer
These components rely on you supplying the SVG markup; the CSS styles the surrounding structure and SVG elements via class hooks.

**Donut** — a flex container pairing an SVG with a `.legend` list:
```html
<div class="donut">
  <svg>...
    <text class="donut-total">842</text>
    <text class="donut-total-label">Total</text>
  </svg>
  <ul class="legend">
    <li>
      <span class="legend-dot" style="background:#2a78d6"></span>
      <span class="legend-label">Active</span>
      <span class="legend-value">620</span>
    </li>
  </ul>
</div>
```

**Horizontal bars** — `.hbar-row` is a 3-column grid (label / track / value). Set the fill width and color inline:
```html
<div class="hbars">
  <div class="hbar-row">
    <span class="hbar-label">Chrome</span>
    <div class="hbar-track">
      <div class="hbar-fill" style="width:72%; background:var(--primary)"></div>
    </div>
    <span class="hbar-value">72</span>
  </div>
</div>
```

**Area chart** — style SVG internals with the provided class hooks: `.grid`, `.axis-label`, `.crosshair`. A positioned `.chart-tooltip` can be absolutely placed inside the `.area-chart` container.

**Note:** Bar/legend colors and SVG geometry are *not* provided by CSS — you must set `fill`, `stroke`, `width`, and `background` from your rendering code (inline styles or JS).

---

## Question
How do I create tables that match the design system?

## Answer
Just use plain semantic table markup — the stylesheet targets `table`, `th`, and `td` globally.

```html
<table>
  <thead>
    <tr><th>Name</th><th>Status</th><th class="col-actions">Actions</th></tr>
  </thead>
  <tbody>
    <tr>
      <td class="cell-user">
        <span class="avatar sm">JD</span>
        <div>
          <div class="cell-name">Jane Doe</div>
          <div class="cell-sub">jane@example.com</div>
        </div>
      </td>
      <td><span class="badge active">active</span></td>
      <td class="col-actions">
        <button class="btn ghost sm">Edit</button>
      </td>
    </tr>
  </tbody>
</table>
```

Helpful utility classes:
- `.cell-user` / `.cell-name` / `.cell-sub` — a user cell with avatar and secondary text.
- `.col-actions` — right-aligns and prevents wrapping for action columns.
- `.muted` / `.nowrap` — text color and no-wrap utilities.

Rows get a `--page` hover background automatically, and the last row's bottom border is removed.

**Gotcha:** These are *global* element selectors — every `<table>` in your app will be styled. Scope your own tables accordingly if you need a different look somewhere.

---

## Question
How do I build a modal dialog?

## Answer
The `.modal` element is a full-screen overlay (fixed, `inset: 0`) with a dark backdrop. Put a `<form>` directly inside it — the form is the actual dialog card.

```html
<div class="modal">
  <form>
    <h3>Invite user</h3>
    <label>
      Email
      <input type="email" />
    </label>
    <div class="modal-actions">
      <button type="button" class="btn ghost">Cancel</button>
      <button type="submit" class="btn primary">Send invite</button>
    </div>
  </form>
</div>
```

Details:
- The dialog is `380px` wide, capped at `90vh` with `overflow: auto` for long content.
- `.modal-actions` right-aligns your buttons.
- `z-index: 50` places it above the topbar (`z-index: 5`).

**Note:** The CSS specifically styles `.modal form`, so the dialog card *must* be a `<form>` element. A plain `<div>` inside `.modal` won't get the white card styling.

---

## Question
Why do form inputs inside my modal look correct but inputs elsewhere behave unexpectedly?

## Answer
The stylesheet styles the bare `input`, `label`, `fieldset`, and `legend` elements **globally**, not via classes. This gives you styled forms with zero markup effort:

```html
<div class="form-grid">
  <label>
    Full name
    <input type="text" />
  </label>
</div>
```

Because `label` defaults to `flex-direction: column` (label text stacked above the field), checkbox rows need the `.checkbox` modifier to sit inline:

```html
<label class="checkbox">
  <input type="checkbox" /> Send welcome email
</label>
```

Common pitfalls:
- `input` is full-width with a fixed style; a rule `input[type="checkbox"] { width: auto }` prevents checkboxes from stretching. Other custom input types (e.g. `range`, `color`) are **not** exempted and may look wrong.
- Focus styles are global: inputs get a `--primary` border and a blue focus ring. This overrides browser defaults everywhere.
- Because these are global selectors, third-party widgets rendering their own inputs/labels will inherit these styles.

---

## Question
Is the layout responsive, and what breakpoints exist?

## Answer
There is a single breakpoint at `max-width: 980px`:

```css
@media (max-width: 980px) {
  .stat-row   { grid-template-columns: repeat(2, 1fr); }  /* 4 → 2 columns */
  .panel-grid { grid-template-columns: 1fr; }             /* 2 → 1 column */
}
```

**Important limitation:** The `.sidebar` is *not* responsive — it stays a fixed `240px` and remains visible on small screens. There is no mobile drawer/hamburger behavior built in. If you need mobile support, you'll have to add media queries to collapse or hide `.sidebar` yourself.

Also note `.panel-wide` uses `grid-column: 1 / -1` to span the full width of `.panel-grid`, which continues to work correctly at both breakpoints.

---

## Question
The dashboard scrolls oddly or the topbar/sidebar don't stay in place. What's going on?

## Answer
Both `.sidebar` and `.topbar` use `position: sticky; top: 0`. For sticky positioning to work:

1. The scrolling ancestor must not have `overflow: hidden` that clips them.
2. Their containers must be tall enough to allow scrolling.

The stacking order matters: `.topbar` has `z-index: 5` and `.modal` has `z-index: 50`, so modals always cover the topbar. If you add custom overlays (dropdowns, tooltips), keep their `z-index` between these values or above `50` as needed.

Also, `.main` sets `min-width: 0` — **don't remove this**. Without it, wide content like tables or the full-width `.area-svg` chart can force the flex column to overflow horizontally and break the layout.