---
id: 2266a2c7-f5c5-5cd6-b1e9-611ddbedb628
type: qa
title: "Users FAQ"
created_at: 2026-07-30T17:24:07.864095+00:00
updated_at: 2026-07-30T17:24:07.864109+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  module_name: "backend.app.routers.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

# User Management API — FAQ

Documentation for `backend.app.routers.users`, which exposes the `/api/users` endpoints for managing users, roles, and account status.

---

## Question
How do I find out who the current authenticated user is and what they can do?

## Answer
Call the `GET /api/me` endpoint. Unlike the other routes, it doesn't require a specific permission — it only needs a valid actor (resolved via the `current_actor` dependency). It returns a `CurrentUser` object that includes the user's **effective permissions**, which is useful for driving frontend authorization (e.g. hiding buttons the user can't use).

```bash
curl -H "Authorization: Bearer <token>" https://host/api/me
```

Example response:

```json
{
  "id": 42,
  "username": "jsmith",
  "full_name": "Jane Smith",
  "status": "active",
  "permissions": ["users:read", "users:create"]
}
```

The permissions are computed server-side by `user_service.effective_permissions(actor)`, so they reflect the user's roles at request time.

---

## Question
Why are the full paths (`/api/users/...`) written in each decorator instead of using `APIRouter(prefix=...)`?

## Answer
This is a deliberate design choice documented in the module docstring. Writing the full path in each route decorator means the route templates appear **verbatim** in the source, matching the exact URLs the frontend calls (e.g. `/api/users/{user_id}/status`).

The tradeoff: if you use a `prefix`, the full path is split across the router config and the decorator, which can make it harder to grep for a URL. Here you can search the codebase for the literal path and land directly on the handler. If you add new routes, follow the same convention and include the full path.

---

## Question
What permission does each endpoint require?

## Answer
Every endpoint except `whoami` is guarded by `require_permission(...)`. Here's the mapping:

| Endpoint | Method | Permission |
|---|---|---|
| `/api/me` | GET | *(any authenticated actor)* |
| `/api/users` | GET | `users:read` |
| `/api/users/{user_id}` | GET | `users:read` |
| `/api/users` | POST | `users:create` |
| `/api/users/{user_id}` | PUT | `users:edit` |
| `/api/users/{user_id}/status` | PATCH | `users:deactivate` |
| `/api/users/{user_id}/roles` | POST | `roles:manage` |
| `/api/users/{user_id}` | DELETE | `users:delete` |

The permission strings come from the `Permission` enum (`Permission.USERS_READ.value`, etc.). If a caller lacks the required permission, `require_permission` rejects the request before the handler body runs.

---

## Question
How do I create a new user, and can I assign roles at the same time?

## Answer
Send a `POST /api/users` with a `UserCreate` payload. You can include `role_ids` to assign roles during creation, so you don't need a separate call to `assign_roles`.

```bash
curl -X POST https://host/api/users \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "jsmith",
    "email": "jane@example.com",
    "full_name": "Jane Smith",
    "role_ids": [1, 2]
  }'
```

On success it returns `201 Created` with the new user (`UserOut`). Requires `users:create`. Note that assigning roles this way falls under user creation — but standalone role changes on an existing user require the separate `roles:manage` permission (see below).

---

## Question
How do I filter the user list, for example to show only active users?

## Answer
The `GET /api/users` endpoint accepts an optional `status` query parameter:

```bash
curl -H "Authorization: Bearer <token>" \
  "https://host/api/users?status=active"
```

If `status` is omitted (`None`), all users are returned. The filtering is delegated to `user_service.list_users(db, status=status)`, so the exact accepted values depend on how statuses are defined in your model. Common values are `active` and `inactive`.

---

## Question
What's the difference between updating a user, changing their status, and assigning roles?

## Answer
These are intentionally separate endpoints with distinct permissions, because they represent different administrative actions:

- **`PUT /api/users/{user_id}`** — edits profile fields (`email`, `full_name`). Requires `users:edit`. Note that `username` is **not** editable here.
- **`PATCH /api/users/{user_id}/status`** — deactivates or reactivates a user. Requires `users:deactivate`. This is what the frontend's `deactivateUser` calls.
- **`POST /api/users/{user_id}/roles`** — replaces/assigns roles. Requires `roles:manage`.

Keeping them separate means you can grant, say, a helpdesk role the ability to deactivate accounts without also granting them role-management power.

```bash
# Deactivate a user
curl -X PATCH https://host/api/users/42/status \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"status": "inactive"}'
```

---

## Question
Why does `get_user` raise a 404 manually, but the other endpoints don't check for a missing user?

## Answer
`get_user` explicitly checks the service result and raises `HTTPException(404)` when the user isn't found:

```python
user = user_service.get_user(db, user_id)
if user is None:
    raise HTTPException(status_code=404, detail="user not found")
return user
```

The other endpoints (`update_user`, `set_user_status`, `assign_roles`, `delete_user`) delegate entirely to the service layer and don't do their own not-found checks. This implies the corresponding service functions are responsible for handling missing users (typically by raising an appropriate error). If you're extending the service layer, be consistent: either raise from the service, or check in the router — but don't assume a missing user silently succeeds.

---

## Question
What does a successful delete return?

## Answer
`DELETE /api/users/{user_id}` returns `204 No Content` with an empty body — the handler's return type is `None`. Don't expect a JSON body back:

```bash
curl -X DELETE https://host/api/users/42 \
  -H "Authorization: Bearer <token>" -i
# HTTP/1.1 204 No Content
```

Requires the `users:delete` permission. The actual deletion (and any cascade/soft-delete behavior) is handled by `user_service.delete_user`, which also receives `actor_id` for auditing.

---

## Question
Why is `actor_id` passed to service functions on write operations?

## Answer
Every mutating endpoint (`create_user`, `update_user`, `set_user_status`, `assign_roles`, `delete_user`) passes `actor_id=actor.id` into the service call. This gives the service layer the identity of the user performing the action, which is typically used for **audit logging** or attribution ("who created/modified this user?").

Read endpoints (`list_users`, `get_user`) don't pass `actor_id` because they don't change state. When adding new write endpoints, follow this pattern so the actor is always recorded.

---

## Question
Why do the handlers return the SQLAlchemy `User` model while the response is a schema like `UserOut`?

## Answer
Each route declares a `response_model` (e.g. `response_model=UserOut`) but returns the raw ORM `User` object. FastAPI automatically serializes/filters the ORM object through the Pydantic schema before sending the response. This means:

- Only fields defined in `UserOut` are exposed — sensitive fields on `User` won't leak.
- The handler's Python return type annotation (`-> User`) reflects what's returned internally, while `response_model` controls the wire format.

A common pitfall: if a field exists on `User` but not in `UserOut`, it will be silently dropped from the response. Make sure your schema includes everything the client needs.