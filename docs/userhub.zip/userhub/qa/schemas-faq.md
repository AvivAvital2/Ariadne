---
id: 769d5884-302f-5965-83cd-4bd85bc8cb59
type: qa
title: "Schemas FAQ"
created_at: 2026-07-30T17:24:10.285540+00:00
updated_at: 2026-07-30T17:24:10.285555+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  module_name: "backend.app.schemas"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Schemas FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

# `backend.app.schemas` — FAQ

## Question
What is the purpose of `model_config = ConfigDict(from_attributes=True)` and which schemas use it?

## Answer
`from_attributes=True` (formerly `orm_mode` in Pydantic v1) tells Pydantic to populate a model from arbitrary object attributes, not just dicts. This lets you pass an ORM instance (e.g. a SQLAlchemy row) directly and have Pydantic read its attributes.

The **output** schemas use it: `RoleBrief`, `PermissionOut`, `RoleOut`, `UserOut`, and `AuditLogOut`.

```python
# Given a SQLAlchemy User object `db_user`
user_out = UserOut.model_validate(db_user)   # reads db_user.id, db_user.username, ...
return user_out
```

The **input** schemas (`RoleCreate`, `UserCreate`, `UserUpdate`, etc.) don't need it because they're constructed from incoming JSON request bodies, which arrive as dicts.

---

## Question
How do I create a new user, and what fields are required?

## Answer
Use `UserCreate`. Only `username` and `email` are required — the rest have defaults.

```python
from backend.app.schemas import UserCreate

# Minimal
new_user = UserCreate(username="jdoe", email="jdoe@example.com")

# With optional fields
new_user = UserCreate(
    username="jdoe",
    email="jdoe@example.com",
    full_name="Jane Doe",
    role_ids=[1, 2],
)
```

`full_name` defaults to `""` and `role_ids` defaults to `[]` (no roles assigned at creation).

**Pitfall:** `email` is typed as a plain `str`, so it is *not* validated as an email address. If you need format validation, switch to `pydantic.EmailStr` and install `email-validator`.

---

## Question
What's the difference between `UserCreate`, `UserUpdate`, and `UserStatusUpdate`?

## Answer
They cover three distinct flows:

| Schema | Use case | Notable behavior |
|--------|----------|------------------|
| `UserCreate` | Creating a user (POST) | Requires `username`/`email`; can assign roles |
| `UserUpdate` | Editing profile fields (PATCH) | All fields optional/nullable |
| `UserStatusUpdate` | Deactivate/reactivate (PATCH) | Carries just a `status` string |

`UserUpdate` uses `str | None = None` so a PATCH can send only the fields being changed:

```python
# Update only the email
UserUpdate(email="new@example.com")   # full_name stays None
```

**Gotcha:** because unset fields default to `None`, use `model_dump(exclude_unset=True)` when applying an update, so you don't overwrite existing values with `None`:

```python
data = update.model_dump(exclude_unset=True)
for field, value in data.items():
    setattr(db_user, field, value)
```

---

## Question
Why is `status` just a `str` instead of an enum?

## Answer
`UserStatusUpdate.status` and `UserOut.status` are typed as `str` and carry raw `UserStatus` values like `"deactivated"` or `"active"`. This keeps the schema decoupled from the enum definition and simplifies JSON serialization.

```python
UserStatusUpdate(status="deactivated")
```

**Pitfall:** since it's a plain string, Pydantic won't reject invalid values like `"foo"`. Validate against your `UserStatus` enum in the service/route layer, or tighten the schema:

```python
from backend.app.models import UserStatus  # example

class UserStatusUpdate(BaseModel):
    status: UserStatus
```

---

## Question
How do `RoleOut`, `RoleBrief`, and `PermissionOut` relate to each other?

## Answer
They form a nested hierarchy for reading role/permission data:

- **`RoleBrief`** — minimal role reference (`id`, `name`). Used inside `UserOut.roles` to avoid returning full permission lists per user.
- **`RoleOut`** — full role detail, including a nested `list[PermissionOut]`.
- **`PermissionOut`** — a single permission (`id`, `name`, `description`).

```python
role = RoleOut(
    id=1,
    name="admin",
    description="Full access",
    permissions=[
        PermissionOut(id=10, name="users:deactivate", description="Disable users"),
    ],
)
```

Use `RoleBrief` when you just need labels (like in a user list) and `RoleOut` when you need the permission breakdown (like a role-management screen).

---

## Question
What's the difference between `UserOut` and `CurrentUser`?

## Answer
- **`UserOut`** represents any user record for admin/list views. It includes `roles` (as `RoleBrief`), timestamps, and status — but **not** flattened permission strings.
- **`CurrentUser`** represents the *authenticated acting user*. It replaces `roles` with a flattened `permissions: list[str]` (e.g. `"users:deactivate"`) — exactly the strings the frontend checks before rendering controls.

```python
current = CurrentUser(
    id=1,
    username="jdoe",
    full_name="Jane Doe",
    status="active",
    permissions=["users:read", "users:deactivate"],
)
```

**Pattern:** flatten roles→permissions server-side so the frontend does a simple `permissions.includes("users:deactivate")` check rather than walking a role graph.

---

## Question
How do I assign roles to an existing user?

## Answer
Use `RoleAssignment`, which carries a required list of role IDs:

```python
from backend.app.schemas import RoleAssignment

RoleAssignment(role_ids=[1, 2, 3])
```

Note `role_ids` has **no default** here — it's required, unlike `UserCreate.role_ids` which defaults to `[]`. This makes the intent explicit for a dedicated role-assignment endpoint.

To clear all roles, pass an empty list explicitly:

```python
RoleAssignment(role_ids=[])
```

---

## Question
What is `UserActivityRow` and why doesn't it use `from_attributes`?

## Answer
`UserActivityRow` models one row of a **raw-SQL** user-activity report — aggregated columns like `action_count` and `last_action_at` that don't map to a single ORM model.

Because it comes from a raw query result (typically dict-like rows), it doesn't need `from_attributes`. Note `last_action_at` is `datetime | None` to handle users who have no recorded actions:

```python
rows = [UserActivityRow(**dict(r)) for r in db.execute(query).mappings()]
```

**Pitfall:** if a user has never acted, `last_action_at` will be `None` — handle that in your UI/formatting layer rather than assuming a valid timestamp.

---

## Question
How do I serialize these schemas to JSON for an API response?

## Answer
Use Pydantic v2 methods:

```python
user_out = UserOut.model_validate(db_user)

user_out.model_dump()        # -> dict (datetimes stay as datetime objects)
user_out.model_dump_json()   # -> JSON string (datetimes become ISO 8601)
```

If you're using FastAPI, just declare the schema as the `response_model` and return the ORM object — FastAPI calls `model_validate` and serialization for you:

```python
@router.get("/users/{id}", response_model=UserOut)
def get_user(id: int):
    return repo.get(id)   # ORM object; from_attributes handles conversion
```

---

## Question
Why do `AuditLogOut.actor_id` and `target_id` allow `None`?

## Answer
Both are typed `int | None` to represent audit events that lack a specific actor or target:

- `actor_id = None` — a system-generated action with no human actor.
- `target_id = None` — an action not tied to a specific entity (e.g. a bulk or global operation).

```python
AuditLogOut(
    id=1,
    actor_id=None,        # system action
    action="cleanup",
    target_type="system",
    target_id=None,
    detail="Scheduled purge",
    created_at=datetime.utcnow(),
)
```

Always guard against `None` before using these IDs (e.g. don't blindly join to a users table on `actor_id`).