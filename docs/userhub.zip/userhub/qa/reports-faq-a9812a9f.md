---
id: a9812a9f-de87-567d-9074-060a3adc316f
type: qa
title: "Reports FAQ"
created_at: 2026-07-30T17:22:29.430632+00:00
updated_at: 2026-07-30T17:22:29.430647+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py
metadata:
  module_name: "backend.app.reports"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Reports FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/__init__.py`

# FAQ: `backend.app.reports`

> **Note:** As of this documentation, the `backend.app.reports` module contains only a module-level docstring (`"""Reporting queries."""`) and no implemented code. The Q&A below reflects the current state of the module and provides guidance for when you begin implementing reporting queries here.

---

## Question
What is the current state of the `backend.app.reports` module?

## Answer
The module is currently a **stub**. It contains a single docstring describing its intended purpose ("Reporting queries.") but no functions, classes, or query logic yet.

```python
"""Reporting queries."""
```

Importing it will succeed, but there is nothing to call:

```python
from backend.app import reports  # works, but the module is empty
```

If you're looking for a specific reporting function, it has not been implemented yet. This module is a placeholder intended to hold data-aggregation and reporting query logic.

---

## Question
What is this module intended to be used for?

## Answer
Based on its name (`reports`) and docstring (`"Reporting queries."`), this module is meant to house **read-only queries that aggregate or summarize data** for reporting purposes—things like totals, counts, time-series rollups, and dashboards.

A typical convention is to keep reporting/analytics queries separate from your CRUD/business logic so they can be optimized independently. Once implemented, you would expect functions such as:

```python
def get_daily_signups(db, start_date, end_date):
    """Return signup counts grouped by day."""
    ...

def get_revenue_summary(db, period="month"):
    """Return aggregated revenue for the given period."""
    ...
```

---

## Question
How should I add a new reporting query to this module?

## Answer
Follow the reporting-query pattern: accept a database session/connection, keep the function read-only, and return plain, serializable data (dicts, lists, or DTOs) rather than ORM objects tied to a session.

```python
"""Reporting queries."""

from datetime import date


def get_orders_by_status(db) -> dict[str, int]:
    """Return a count of orders grouped by their status."""
    rows = db.execute(
        "SELECT status, COUNT(*) FROM orders GROUP BY status"
    ).fetchall()
    return {status: count for status, count in rows}
```

**Best practices:**
- Keep each function focused on one report.
- Pass in the DB session rather than creating one inside (easier to test).
- Return serializable data so callers/APIs don't depend on ORM internals.

---

## Question
Should reporting queries modify data?

## Answer
**No.** Reporting queries should be strictly **read-only** (`SELECT`/aggregation only). Mixing writes into a reporting module makes behavior unpredictable and harder to cache or run against read replicas.

If you need to write data, put that logic in a separate service/repository module. Keeping `reports` read-only lets you safely:
- Route these queries to a **read replica**.
- Apply **caching** without correctness concerns.
- Run them in reporting/analytics contexts without side effects.

---

## Question
How do I test reporting queries in this module?

## Answer
Because the current module is empty, there is nothing to test yet. Once you add functions, design them to accept a DB session so you can inject a test database:

```python
def test_get_orders_by_status(test_db):
    seed_orders(test_db, statuses=["open", "open", "closed"])

    result = reports.get_orders_by_status(test_db)

    assert result == {"open": 2, "closed": 1}
```

Use a transactional test database (rolled back after each test) so reporting queries run against realistic, isolated data.

---

## Question
Where should heavy/slow reports live if a single query becomes a performance problem?

## Answer
Keep the query definition in `backend.app.reports`, but address performance separately:

- **Add indexes** to columns used in `GROUP BY`, `WHERE`, and joins.
- **Cache** results if the data can be slightly stale.
- **Precompute** with materialized views or scheduled aggregation tables for expensive reports.
- **Route to a read replica** for large scans.

This keeps `reports` as the single source of truth for report logic while offloading the expensive execution concerns to infrastructure.

---

## Question
Why does importing `backend.app.reports` succeed but I can't find any functions?

## Answer
This is expected. The module currently defines only its docstring, so the import works but exposes no callable members. Common gotchas:

- **`AttributeError` on a report call** — the function hasn't been implemented yet:
  ```python
  reports.get_revenue_summary(db)
  # AttributeError: module 'backend.app.reports' has no attribute 'get_revenue_summary'
  ```
  You'll need to implement it first.

- **`dir()` shows nothing useful** — confirm the module is truly empty:
  ```python
  from backend.app import reports
  print([name for name in dir(reports) if not name.startswith("_")])
  # []  -> module has no public members yet
  ```

If you expected functions here, check whether they were planned but not yet written, or whether they live in a different module.