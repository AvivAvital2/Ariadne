---
id: 6802cf0f-bbed-5206-9e5f-39c54fe16873
type: qa
title: "Security FAQ"
created_at: 2026-07-30T17:24:46.915854+00:00
updated_at: 2026-07-30T17:24:46.915873+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  module_name: "backend.app.security"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Security FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

# `backend.app.security` — FAQ

Permission enforcement for FastAPI endpoints. Routers declare the permission an endpoint requires, and the server enforces it regardless of what the client UI shows.

---

## Question
How do I protect an endpoint so only users with a specific permission can call it?

## Answer
Add `require_permission(...)` as a FastAPI dependency on the route. The dependency resolves the acting user from the `X-Actor-Id` header and rejects the request if that user lacks the permission.

```python
from fastapi import APIRouter, Depends
from app.security import require_permission

router = APIRouter()

@router.post("/api/users/{user_id}/deactivate")
def deactivate_user(
    user_id: int,
    actor=Depends(require_permission("users:deactivate")),
):
    # If we reach here, `actor` is guaranteed to hold "users:deactivate".
    ...
```

If the actor is missing or unknown, the request fails before your handler runs. When permitted, the resolved `User` is injected as the parameter's value, so you can use it directly.

---

## Question
What's the difference between `current_actor` and `require_permission`?

## Answer
Both resolve the acting user from the `X-Actor-Id` header, but they differ in gating:

- **`current_actor`** — resolves the user with **no permission check**. Use it when you just need to know *who* is calling, e.g. the `/api/me` endpoint that returns the caller's own identity and permissions.
- **`require_permission(perm)`** — returns a dependency that resolves the user **and** requires them to hold `perm`, raising `403` otherwise.

```python
# No permission gate — anyone with a valid actor ID can call.
@router.get("/api/me")
def me(actor=Depends(current_actor)):
    return actor

# Gated — requires the "reports:view" permission.
@router.get("/api/reports")
def reports(actor=Depends(require_permission("reports:view"))):
    ...
```

---

## Question
Why does `require_permission` return a nested function instead of being a dependency itself?

## Answer
`require_permission` is a **dependency factory**. It takes the permission string as an argument and returns a `checker` function that FastAPI uses as the actual dependency. This lets you parameterize the check per-endpoint:

```python
Depends(require_permission("users:deactivate"))  # returns checker bound to that permission
Depends(require_permission("users:delete"))      # a different checker
```

You **must call** `require_permission(...)` inside `Depends(...)` — passing the factory itself (`Depends(require_permission)`) would be wrong, since FastAPI would try to inject `permission` as a request parameter.

---

## Question
What HTTP status codes can these dependencies raise, and what do they mean?

## Answer
| Status | When it happens | Detail message |
|--------|-----------------|----------------|
| `401 Unauthorized` | The `X-Actor-Id` header points to a user that doesn't exist | `"unknown actor"` |
| `403 Forbidden` | The actor exists but lacks the required permission | `"missing permission: <permission>"` |
| `422 Unprocessable Entity` | The `X-Actor-Id` header is missing or not an integer (raised by FastAPI's header validation) | Standard FastAPI validation error |

Note the semantic distinction: **401** means "we don't know who you are," while **403** means "we know who you are, but you're not allowed."

---

## Question
How does the client tell the server who is making the request?

## Answer
By sending the `X-Actor-Id` HTTP header with the acting user's integer ID:

```bash
curl -X POST https://api.example.com/api/users/42/deactivate \
     -H "X-Actor-Id: 7"
```

The header is declared as required (`Header(...)`), so omitting it returns a `422` from FastAPI's request validation before any of this code runs.

> ⚠️ **Security note:** This scheme trusts the caller-supplied `X-Actor-Id` header outright — there is no authentication proving the caller *is* that actor. This is fine for an internal/trusted deployment, but for public-facing use you'd typically resolve the actor from an authenticated token/session instead.

---

## Question
Why enforce permissions on the server if the frontend already hides controls the user can't use?

## Answer
The frontend hiding controls is a **UX convenience**, not a security boundary. A malicious or buggy client can call any endpoint directly (via `curl`, scripts, etc.), so hidden buttons provide no real protection.

The server enforces permissions here **regardless of what the client chooses to show**. The frontend and backend share the same permission strings (e.g. `"users:deactivate"`) so they stay in sync, but the server is the source of truth.

---

## Question
Where do the permission strings come from, and how is a user's permission actually checked?

## Answer
The check is delegated to the service layer via `user_service.actor_has_permission(actor, permission)`. This code doesn't define the permission model itself — it only enforces the answer that service gives.

```python
if not user_service.actor_has_permission(actor, permission):
    raise HTTPException(status_code=403, detail=f"missing permission: {permission}")
```

Permission strings are conventionally `"<resource>:<action>"` (e.g. `"users:deactivate"`). To understand how a user *acquires* permissions (roles, direct grants, etc.), look at `app.services.users`.

---

## Question
Can I use the resolved actor inside my endpoint after the permission check passes?

## Answer
Yes. Both `current_actor` and the `checker` returned by `require_permission` **return the `User` object**, so FastAPI injects it as the value of your dependency parameter:

```python
@router.post("/api/users/{user_id}/deactivate")
def deactivate_user(
    user_id: int,
    actor: User = Depends(require_permission("users:deactivate")),
):
    log.info("%s deactivated %s", actor.id, user_id)
    ...
```

This avoids a second lookup — you get authorization *and* the actor object in one dependency.

---

## Question
How can I test an endpoint that uses `require_permission`?

## Answer
Provide the `X-Actor-Id` header for a user that holds the permission, and assert on the status codes for the failure paths.

```python
def test_deactivate_requires_permission(client):
    # Actor without permission -> 403
    resp = client.post("/api/users/42/deactivate", headers={"X-Actor-Id": "1"})
    assert resp.status_code == 403
    assert "missing permission" in resp.json()["detail"]

    # Unknown actor -> 401
    resp = client.post("/api/users/42/deactivate", headers={"X-Actor-Id": "9999"})
    assert resp.status_code == 401

    # Missing header -> 422 (FastAPI validation)
    resp = client.post("/api/users/42/deactivate")
    assert resp.status_code == 422
```

For unit tests, you can also override `get_db` via `app.dependency_overrides` to point at a test session with seeded users and permissions.

---

## Question
Can I require multiple permissions on a single endpoint?

## Answer
`require_permission` checks exactly one permission. To require several, stack multiple dependencies. Because each `checker` resolves the actor independently, use the plain `dependencies=[...]` argument (which ignores return values) to avoid parameter name collisions:

```python
@router.post(
    "/api/admin/action",
    dependencies=[
        Depends(require_permission("admin:read")),
        Depends(require_permission("admin:write")),
    ],
)
def admin_action():
    ...
```

This enforces an **AND** relationship (all permissions required). For **OR** semantics or role-based logic, you'd write a custom dependency that calls `user_service.actor_has_permission` for each candidate — this module doesn't provide that out of the box.