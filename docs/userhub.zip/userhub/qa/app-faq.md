---
id: 4c8fac94-e948-5c4f-994e-7528c13da09f
type: qa
title: "App FAQ"
created_at: 2026-07-30T17:26:32.472698+00:00
updated_at: 2026-07-30T17:26:32.472715+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx
metadata:
  module_name: "frontend.src.App"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# App FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx`

# App Component FAQ

## Question
What does the `App` component do and how is it structured?

## Answer
`App` is the root component of the frontend. It renders a persistent layout consisting of a `Sidebar`, a `Topbar`, and a `content` area that swaps between four views: Dashboard, Users, Roles, and Audit log.

The layout structure is:

```jsx
<div className="layout">
  <Sidebar ... />        {/* navigation */}
  <div className="main">
    <Topbar ... />       {/* page title + actor info */}
    <div className="content">
      {/* one view rendered based on `view` state */}
    </div>
  </div>
</div>
```

It manages three pieces of state:
- `actor` — the currently logged-in user
- `view` — which page is active
- `error` — an error message string, if any

---

## Question
How does navigation between views work?

## Answer
Navigation is driven by the `view` state and the `NAV` array. The `Sidebar` receives `onNavigate={setView}`, so clicking a nav item updates `view`. The content area then conditionally renders the matching component:

```jsx
{view === "dashboard" && <Dashboard />}
{view === "users" && <UserList actor={actor} />}
{view === "roles" && <RoleManager actor={actor} />}
{view === "audit" && <AuditLog />}
```

Note this is client-side view switching using state — **not** URL-based routing. There's no `react-router`, so views don't have distinct URLs and won't survive a page refresh or support browser back/forward navigation.

---

## Question
How do I add a new view/page to the app?

## Answer
Three steps:

1. **Add an entry to `NAV`** so it appears in the sidebar:

```jsx
const NAV = [
  { key: "dashboard", label: "Dashboard" },
  { key: "users", label: "Users" },
  { key: "roles", label: "Roles" },
  { key: "audit", label: "Audit log" },
  { key: "settings", label: "Settings" }, // new
];
```

2. **Import the component:**

```jsx
import Settings from "./components/Settings.jsx";
```

3. **Add a conditional render** in the content area:

```jsx
{view === "settings" && <Settings actor={actor} />}
```

The `key` in `NAV` must match the string you compare against in the render logic.

---

## Question
How is the current user (`actor`) loaded, and what is it used for?

## Answer
The actor is fetched once on mount via `useEffect`:

```jsx
useEffect(() => {
  api.getCurrentUser().then(setActor).catch((e) => setError(e.message));
}, []);
```

The empty dependency array `[]` ensures it runs only once. The resolved user is passed down to `Sidebar`, `Topbar`, `UserList`, and `RoleManager` so those components can display or permission-check based on who's logged in.

**Gotcha:** `actor` starts as `null`, so any child component receiving it must handle the `null` case during the initial render before the promise resolves.

---

## Question
How does the page title get set?

## Answer
The title is derived from the `NAV` array by matching the active `view` key:

```jsx
const title = NAV.find((n) => n.key === view)?.label ?? "";
```

The optional chaining (`?.`) and nullish coalescing (`?? ""`) protect against an invalid `view` value — if no match is found, the title falls back to an empty string rather than throwing. The result is passed to `<Topbar title={title} ... />`.

---

## Question
How are errors handled and displayed?

## Answer
Currently the app only captures errors from the initial `getCurrentUser` call:

```jsx
api.getCurrentUser().then(setActor).catch((e) => setError(e.message));
```

If it fails, `error` is set to the message string and rendered above the active view:

```jsx
{error && <div className="error">{error}</div>}
```

**Limitations to be aware of:**
- Only the user-fetch error is captured here. Errors inside `UserList`, `RoleManager`, etc. are **not** handled by `App` — each child manages its own errors.
- The error banner is not cleared automatically. Once set, it stays until `setError(null)` is called (which currently never happens). Consider clearing it on navigation if that's not desired.

---

## Question
Why isn't my new view showing up even though I added it to `NAV`?

## Answer
Adding to `NAV` only makes the item appear in the sidebar — it does **not** automatically render anything. The content area uses explicit conditional checks, so you must also add:

```jsx
{view === "yourkey" && <YourComponent />}
```

Double-check that the `key` string in `NAV` exactly matches the string in the `view === "..."` comparison (case-sensitive). A mismatch results in a clickable nav item that shows a blank content area.

---

## Question
Should I fetch data for each view inside `App`?

## Answer
No. `App` deliberately only fetches the `actor`. Each view component (`Dashboard`, `UserList`, `RoleManager`, `AuditLog`) is responsible for its own data fetching. This keeps `App` lightweight and ensures data is only loaded when a view is actually displayed.

If you find yourself adding many `useEffect` fetches to `App`, that's a sign the logic belongs in the individual view component instead. Pass `actor` down as a prop when the child needs to know who's acting, as is done for `UserList` and `RoleManager`.

---

## Question
Why do only some views receive the `actor` prop?

## Answer
Only components that need the current user get it:

```jsx
{view === "users" && <UserList actor={actor} />}   // needs actor
{view === "roles" && <RoleManager actor={actor} />} // needs actor
{view === "dashboard" && <Dashboard />}             // doesn't
{view === "audit" && <AuditLog />}                  // doesn't
```

`UserList` and `RoleManager` likely use `actor` for permission checks or to attribute actions. `Dashboard` and `AuditLog` don't require it. When adding a new view, only pass `actor` if the component actually uses it — avoid prop drilling unnecessary data.

---

## Question
How could I make views survive a page refresh?

## Answer
Because `view` is component state, it resets to `"dashboard"` on every reload. To persist the active view you have two common options:

**1. Persist to `localStorage`:**

```jsx
const [view, setView] = useState(() => localStorage.getItem("view") ?? "dashboard");

useEffect(() => {
  localStorage.setItem("view", view);
}, [view]);
```

**2. Adopt a router** (e.g. `react-router`) so each view maps to a URL, enabling bookmarks, deep links, and browser back/forward support. This is the more robust long-term approach if the app grows.