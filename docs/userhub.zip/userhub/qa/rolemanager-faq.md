---
id: 21d5cc6b-465e-5ebe-90de-a7d0e04328cf
type: qa
title: "Rolemanager FAQ"
created_at: 2026-07-30T17:27:54.475685+00:00
updated_at: 2026-07-30T17:27:54.475699+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx
metadata:
  module_name: "frontend.src.components.RoleManager"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Rolemanager FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx`

# RoleManager Component — FAQ

## Question
What does the `RoleManager` component do and how do I use it?

## Answer
`RoleManager` is a React component that displays a list of roles (with their descriptions and permissions) and — for users with the right permission — provides a form to create new roles. It requires a single `actor` prop representing the current authenticated user.

```jsx
import RoleManager from "./components/RoleManager.jsx";

function AdminPage({ currentUser }) {
  return <RoleManager actor={currentUser} />;
}
```

The `actor` is used both to trigger data loading and to determine whether the "New role" form is shown. Without a truthy `actor`, no data is loaded.

---

## Question
Why isn't any data loading when the component mounts?

## Answer
Data loading is gated behind the `actor` prop inside the `useEffect`:

```javascript
useEffect(() => {
  if (actor) load();
}, [actor]);
```

If `actor` is `null`, `undefined`, or otherwise falsy, `load()` is never called and the roles table stays empty. Make sure you pass a valid `actor` object. Loading will automatically re-run whenever the `actor` reference changes.

---

## Question
How does the component decide whether to show the role creation form?

## Answer
It checks the actor's permissions using the `hasPermission` helper:

```javascript
const canManage = hasPermission(actor, PERMISSIONS.ROLES_MANAGE);
```

The `canManage` flag controls two things:
1. Whether the list of available permissions is fetched (`api.listPermissions()`).
2. Whether the "New role" form section is rendered (`{canManage && (...)}`).

Users without the `ROLES_MANAGE` permission can still view existing roles but cannot create new ones — and the extra permissions API call is skipped for them, which is a nice optimization.

---

## Question
How does selecting permissions for a new role work?

## Answer
Selected permission IDs are stored in the `permIds` state array. The `togglePerm` function adds or removes an ID depending on whether it's already selected:

```javascript
const togglePerm = (id) =>
  setPermIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]));
```

Each checkbox is controlled via `checked={permIds.includes(perm.id)}` and calls `togglePerm(perm.id)` on change. Using the functional updater form (`ids => ...`) ensures toggles work correctly even with rapid successive clicks.

---

## Question
How are errors handled and displayed?

## Answer
Both `load()` and `createRole()` wrap their API calls in `try/catch` and store the error message in state:

```javascript
try {
  // ... api call
} catch (e) {
  setError(e.message);
}
```

The error is rendered near the top of the Roles card:

```jsx
{error && <div className="error">{error}</div>}
```

Note that `setError(null)` is called at the start of each operation, so a previous error is cleared before a new attempt. A gotcha: the error `<div>` lives in the **Roles** section, so errors from creating a role appear at the top of the list, not next to the form.

---

## Question
What happens after a role is successfully created?

## Answer
On success, the form fields are reset and the data is reloaded:

```javascript
await api.createRole({ name, description, permission_ids: permIds });
setName("");
setDescription("");
setPermIds([]);
load();
```

This clears the form and re-fetches roles so the new role appears in the table. Note that `load()` is intentionally **not** awaited here — the form clears immediately while the reload happens in the background.

---

## Question
What API methods does this component depend on?

## Answer
The component imports the API client with `import * as api` and uses three methods:

| Method | Purpose | When called |
|--------|---------|-------------|
| `api.listRoles()` | Fetch all roles | On load |
| `api.listPermissions()` | Fetch available permissions | On load, only if `canManage` |
| `api.createRole({ name, description, permission_ids })` | Create a new role | On form submit |

Note the payload shape for creation uses `permission_ids` (snake_case), while the local state variable is `permIds`. Watch this naming boundary when debugging failed requests.

---

## Question
Why does `createRole` call `event.preventDefault()`?

## Answer
The form uses an `onSubmit` handler rather than a button click handler:

```jsx
<form className="form-grid" onSubmit={createRole}>
```

`event.preventDefault()` stops the browser's default form submission behavior (a full-page reload). This is essential — without it, the page would refresh and the async API call would be interrupted. This is a common pitfall when using `<form onSubmit>` in React.

---

## Question
What are the expected shapes of the `role` and `permission` objects?

## Answer
Based on how they're rendered, the component expects:

```javascript
// role
{
  id: string | number,
  name: string,
  description: string,
  permissions: [{ id, name }]  // nested array of permission objects
}

// permission (from listPermissions)
{
  id: string | number,
  name: string
}
```

If `role.permissions` is missing or `undefined`, the `.map()` call will throw. Ensure your API always returns `permissions` as an array (even if empty) to avoid render crashes.

---

## Question
Is the component's state kept in sync across multiple instances or clients?

## Answer
No. All state (`roles`, `permissions`, form fields) is local to the component instance via `useState`. It only refreshes when:
- The `actor` prop changes (triggering the `useEffect`), or
- A role is successfully created (which calls `load()`).

There's no polling, websocket, or global store. If another user creates a role elsewhere, this instance won't see it until the next `load()`. For real-time updates, you'd need to add a refresh mechanism or integrate with a shared state/subscription layer.