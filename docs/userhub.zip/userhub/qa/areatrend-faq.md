---
id: 153a2caf-dab4-5df6-845c-c4b862ed0b74
type: qa
title: "Areatrend FAQ"
created_at: 2026-07-30T17:29:31.343554+00:00
updated_at: 2026-07-30T17:29:31.343569+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx
metadata:
  module_name: "frontend.src.components.charts.AreaTrend"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Areatrend FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx`

# AreaTrend Component — FAQ

## Question
How do I render a basic area chart with `AreaTrend`?

## Answer
Import the component and pass an array of `points`, where each point has a `label` (x-axis category) and a `value` (y-axis magnitude).

```jsx
import AreaTrend from "@/components/charts/AreaTrend";

function ActivityCard() {
  const data = [
    { label: "Mon", value: 12 },
    { label: "Tue", value: 30 },
    { label: "Wed", value: 22 },
    { label: "Thu", value: 45 },
    { label: "Fri", value: 38 },
  ];

  return <AreaTrend points={data} />;
}
```

The component renders a filled area, a line connecting the points, dots on each data point, y-axis grid lines/labels, and x-axis labels. Hovering shows a crosshair and tooltip.

---

## Question
What props does `AreaTrend` accept and what are the defaults?

## Answer
| Prop     | Type                              | Default     | Description                                        |
|----------|-----------------------------------|-------------|----------------------------------------------------|
| `points` | `Array<{ label: string, value: number }>` | **required** | The data series to plot.                     |
| `color`  | `string`                          | `"#2a78d6"` | Stroke/fill color for the line, area, and dots.    |
| `height` | `number`                          | `220`       | Chart height in SVG units (the width is fixed at 640 via viewBox but scales to 100%). |

Example with customization:

```jsx
<AreaTrend points={data} color="#e0245e" height={300} />
```

---

## Question
Why does the chart scale to fit its container even though width is hard-coded to 640?

## Answer
The SVG uses a fixed `viewBox="0 0 640 H"` but no explicit `width`/`height` attributes. This means the internal coordinate system stays constant (keeping labels and marks undistorted), while CSS controls the rendered size. The SVG scales to 100% of its parent's width.

To control the displayed size, style the container or the `.area-svg` class in CSS:

```css
.area-chart { width: 100%; max-width: 720px; }
.area-svg { width: 100%; }
```

The `onMove` handler accounts for scaling by mapping mouse coordinates back into viewBox space using `getBoundingClientRect()`.

---

## Question
How is the y-axis maximum determined? What does `niceCeil` do?

## Answer
`niceCeil` rounds the maximum data value up to a "nice" round number so axis labels read cleanly (e.g., 5, 10, 20, 50, 100) instead of arbitrary values.

```javascript
niceCeil(7);   // → 10
niceCeil(23);  // → 50 (n = 2.3 → step 5, pow 10)
niceCeil(4);   // → 5  (values ≤ 5 always return 5)
niceCeil(150); // → 200
```

The chart computes `niceCeil(Math.max(1, ...values))`, guaranteeing a floor of 1 so an all-zero series still renders a valid axis. Ticks are placed at `0`, `niceMax / 2`, and `niceMax`.

---

## Question
How does the hover tooltip and crosshair work?

## Answer
The `onMouseMove` handler converts the cursor's screen position into viewBox coordinates, then finds the nearest data point by comparing horizontal distances:

```javascript
const px = ((e.clientX - rect.left) / rect.width) * W;
// finds index with the smallest |xAt(i) - px|
setHover(best);
```

The nearest index is stored in the `hover` state. When set, the component:
- Draws a vertical `.crosshair` line at that point
- Enlarges the hovered dot (`r = 5` instead of `3.5`)
- Renders an HTML `.chart-tooltip` positioned with `left: %` relative to the point

On `onMouseLeave`, `hover` resets to `null`, hiding these elements.

---

## Question
The tooltip position looks off — how do I fix its alignment and styling?

## Answer
The tooltip's `left` is a percentage of the chart width, but the component doesn't set `position` or handle vertical placement — that's up to your CSS. A common setup:

```css
.area-chart { position: relative; }
.chart-tooltip {
  position: absolute;
  top: 0;
  transform: translateX(-50%); /* centers on the point */
  pointer-events: none;
  background: #fff;
  padding: 4px 8px;
  border-radius: 4px;
  box-shadow: 0 1px 4px rgba(0,0,0,0.2);
}
```

Without `position: relative` on `.area-chart` and `translateX(-50%)`, the tooltip will not center over the data point.

---

## Question
What happens if I pass an empty array or a single point?

## Answer
Both edge cases are handled gracefully:

- **Empty array (`points = []`)**: `area` becomes `""`, the line/dots/labels render nothing, and `niceCeil(Math.max(1))` produces a valid axis. The chart shows only grid lines.
- **Single point (`n === 1`)**: `xAt` centers the single point horizontally (`plotW / 2`) instead of dividing by zero. The area and line still render correctly.

```jsx
<AreaTrend points={[]} />                          // grid only
<AreaTrend points={[{ label: "Now", value: 8 }]} /> // centered single dot
```

---

## Question
Why does each point need a `key` and are there any React warnings to watch for?

## Answer
The `.map()` calls for circles and labels use `key={i}` (the array index). This is acceptable here because the data set is static per render and points aren't reordered. However, if your data can be reordered or filtered, prefer a stable identifier:

```jsx
// If points have unique labels/ids:
<circle key={p.label} ... />
```

Using index keys with dynamic reordering can cause React to reuse the wrong DOM nodes, leading to subtle visual glitches.

---

## Question
How do I make the dots accessible or show native browser tooltips?

## Answer
Each dot already includes an SVG `<title>` element, which the browser renders as a native tooltip on hover:

```jsx
<circle ...>
  <title>{p.label}: {p.value}</title>
</circle>
```

This provides a basic accessibility/hover fallback independent of the custom HTML tooltip. For fuller accessibility, consider adding `role="img"` and an `aria-label` to the `<svg>` summarizing the trend, since screen readers won't interpret the visual marks otherwise.

---

## Question
Can I plot multiple series with this component?

## Answer
No — `AreaTrend` is explicitly single-series (see the header comment). It maps directly over one `points` array for the line, area, dots, and labels. To display multiple series, you'd need to render several `AreaTrend` instances (visually stacked/overlaid via CSS) or extend the component to accept an array of series and loop over each for the `<polyline>`, `<path>`, and dots. Note the hover logic and `niceMax` calculation would also need to account for all series.