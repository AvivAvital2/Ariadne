---
id: 51f74a67-ff80-5975-80a0-5648a507cc87
type: qa
title: "Users FAQ"
created_at: 2026-07-30T17:25:51.360183+00:00
updated_at: 2026-07-30T17:25:51.360197+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  module_name: "backend.app.services.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

# `backend.app.services.users` — FAQ

This service module handles user lifecycle operations: creation, updates, status changes, role assignment, deletion, and permission checks. All mutating functions write an audit-log entry alongside the change.

---

## Question
How do I fetch a user, and what's the difference between `get_user` and the internal `_require` helper?

## Answer
Use `get_user` when a missing user is an acceptable, non-error outcome — it returns `None` if the user doesn't exist:

```python
user = get_user(db, user_id=42)
if user is None:
    ...  # handle absence yourself
```

Internally, the mutating functions (`update_user`, `set_status`, `delete_user`, `assign_roles`) use the private `_require` helper, which raises `HTTPException(404, "user not found")` instead of returning `None`. That's why you never have to null-check inside those calls — a missing user automatically becomes a 404.

---

## Question
How do I create a new user, and what status does a new user start with?

## Answer
Call `create_user` with keyword arguments. New users always start in the `INVITED` state — you cannot create a user directly in `ACTIVE`:

```python
user = create_user(
    db,
    actor_id=current_user.id,
    username="jdoe",
    email="jdoe@example.com",
    full_name="Jane Doe",
    role_ids=[1, 3],
)
```

Notes:
- `role_ids` may be an empty list if the user should start with no roles.
- If the `username` already exists, a `409 Conflict` (`"username already taken"`) is raised. Uniqueness is only enforced on `username`, **not** on `email`.
- The function flushes to obtain the new `user.id` before writing the audit record, then commits and refreshes.

---

## Question
How do status transitions work? Can I move a user to any status?

## Answer
No. `set_status` enforces a transition table via the private `_validate_transition` helper, driven by `ALLOWED_STATUS_TRANSITIONS`. There are three failure modes:

| Condition | Result |
|-----------|--------|
| Target isn't a valid `UserStatus` value | `422` — `"unknown status: <target>"` |
| Current == target | No-op (allowed, still records audit) |
| Transition not in `ALLOWED_STATUS_TRANSITIONS[current]` | `409` — `"illegal transition: <current> -> <target>"` |

```python
# Deactivate an active user
set_status(db, actor_id=admin.id, user_id=42, status=UserStatus.DEACTIVATED.value)
```

**Gotcha:** Setting a user to its *current* status is treated as valid and short-circuits the transition check — but it still records an audit entry and commits. If you want to avoid redundant audit noise, check `user.status` before calling.

This is the endpoint of the flagship cross-language trace: React "Deactivate" button → `deactivateUser` API client → `PATCH /api/users/{user_id}/status` → `set_status`.

---

## Question
Why does the audit action for a status change vary, and how is it chosen?

## Answer
`set_status` derives the audit action from the target status via `_status_action`:

- `DEACTIVATED` → `USER_DEACTIVATED`
- `ACTIVE` → `USER_REACTIVATED`
- anything else → `USER_UPDATED`

So a deactivation and a reactivation appear as distinct, searchable actions in the audit log, while other status changes fall back to a generic `USER_UPDATED`. If you add a new `UserStatus` that deserves its own audit action, extend `_status_action` accordingly.

---

## Question
What's the difference between `actor_has_permission` and `effective_permissions`?

## Answer
Both flatten a user's roles into permissions, but serve different purposes:

- **`actor_has_permission(actor, permission)`** — a boolean check for a single permission. Use it for authorization guards.
- **`effective_permissions(user)`** — returns a *sorted, de-duplicated* list of all permission names. Use it for display, debugging, or returning the full permission set to a client.

```python
if not actor_has_permission(current_user, "users:write"):
    raise HTTPException(403, "forbidden")

perms = effective_permissions(current_user)  # ["users:read", "users:write", ...]
```

Note: neither function touches the database — they walk the already-loaded `roles`/`permissions` relationships. Make sure those relationships are loaded (or eagerly loaded) to avoid extra lazy-load queries per role.

---

## Question
How do I update a user's email or name, and how are partial updates handled?

## Answer
`update_user` supports partial updates: pass `None` for any field you don't want to change.

```python
# Change only the email
update_user(db, actor_id=admin.id, user_id=42, email="new@example.com", full_name=None)
```

Only non-`None` values are applied. **Pitfall:** because `None` means "leave unchanged," you cannot use this function to *clear* a field back to null. Also note that `update_user` records a `USER_UPDATED` audit entry unconditionally — even if both arguments are `None` and nothing actually changed.

---

## Question
How do I assign roles, and does `assign_roles` add to existing roles or replace them?

## Answer
It **replaces** the user's entire role set — it is not additive:

```python
# User now has EXACTLY roles 2 and 5, regardless of prior roles
assign_roles(db, actor_id=admin.id, user_id=42, role_ids=[2, 5])
```

Passing an empty list removes all roles. If a supplied role ID doesn't exist, it's silently dropped (the query simply returns fewer rows), so the user may end up with fewer roles than IDs you passed. Validate role IDs upstream if that matters.

---

## Question
Do these functions manage their own transactions, or should I commit myself?

## Answer
The mutating functions (`create_user`, `update_user`, `set_status`, `delete_user`, `assign_roles`) each call `db.commit()` internally and then `db.refresh()` the returned object (except `delete_user`, which returns `None`). You should **not** call `commit()` yourself afterward.

Implication: each of these is its own transaction boundary. You cannot compose several of them into a single atomic operation as written — if you need "create user + assign extra roles atomically," you'd have to refactor to defer commits.

The read functions (`get_user`, `list_users`, `actor_has_permission`, `effective_permissions`) never write and never commit.

---

## Question
How do I list users, optionally filtered by status?

## Answer
`list_users` returns all users ordered by `username`. Pass `status` to filter:

```python
all_users     = list_users(db)
active_users  = list_users(db, status=UserStatus.ACTIVE.value)
```

The `status` argument is keyword-only and expects a raw string (use `UserStatus.<X>.value`, not the enum member). There is no pagination — for large user tables you'll want to add limit/offset before using this in production.

---

## Question
Every mutating function requires `actor_id`. What is it for?

## Answer
`actor_id` identifies *who performed the action* and is written into the `audit_log` table via `audit.record`, separate from `target_id` (the user being acted upon). This gives you an accountability trail.

```python
# admin (actor) deactivates employee 42 (target)
set_status(db, actor_id=admin.id, user_id=42, status=UserStatus.DEACTIVATED.value)
```

Always pass the authenticated caller's ID — typically resolved from the request's auth context — not the target user's ID. Confusing the two produces misleading audit records.