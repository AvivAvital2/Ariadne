---
id: eb60e6c3-8fcf-531d-b4e9-bfef09afba05
type: qa
title: "Donutchart FAQ"
created_at: 2026-07-30T17:30:06.975514+00:00
updated_at: 2026-07-30T17:30:06.975528+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx
metadata:
  module_name: "frontend.src.components.charts.DonutChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Donutchart FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx`

# DonutChart FAQ

## Question
How do I use the `DonutChart` component and what data format does it expect?

## Answer
Import the component and pass it a `data` array where each item has a `label`, `value`, and `color`:

```jsx
import DonutChart from 'frontend/src/components/charts/DonutChart';

const data = [
  { label: 'Active',   value: 42, color: '#22c55e' },
  { label: 'Pending',  value: 18, color: '#eab308' },
  { label: 'Failed',   value: 7,  color: '#ef4444' },
];

<DonutChart data={data} />
```

Each object requires all three fields:
- `label` — display name (also used as the React `key`)
- `value` — numeric amount contributing to the total
- `color` — CSS color string for the segment and legend dot

The component computes the total, renders proportional ring segments, and displays a legend below the chart.

---

## Question
How do I customize the size and thickness of the donut?

## Answer
Use the `size` and `thickness` props. Both are in pixels:

```jsx
<DonutChart data={data} size={260} thickness={30} />
```

- `size` (default `190`) — the width/height of the SVG square
- `thickness` (default `22`) — the width of the ring stroke

The radius is derived internally as `(size - thickness) / 2` so the ring stays fully inside the SVG bounds. If you set `thickness` too close to `size`, the radius approaches zero and the ring will collapse — keep `thickness` well below `size / 2`.

---

## Question
What happens when the total value is zero or the data array is empty?

## Answer
The chart handles this gracefully. Segments are only rendered when `total > 0`:

```jsx
{total > 0 &&
  data.map((d) => { /* ... */ })}
```

If all values are `0` (or the array is empty), you'll see:
- The background track circle (`var(--track)`)
- A centered total of `0`
- An empty or value-only legend

This avoids division-by-zero errors from `d.value / total`. No crash occurs — you just get an empty ring.

---

## Question
How are the segments positioned and why is there a gap between them?

## Answer
Segments are drawn as SVG circles using `strokeDasharray` and `strokeDashoffset`:

```jsx
const frac = d.value / total;
const len = Math.max(frac * circumference - GAP, 0);
// ...
strokeDasharray={`${len} ${circumference - len}`}
strokeDashoffset={-offset}
transform={`rotate(-90 ${c} ${c})`}
```

- `frac` is each item's share of the total.
- `len` is the arc length for that segment. `GAP` (2px) is subtracted to create a small visual separation between adjacent segments.
- `offset` accumulates each segment's full arc length so the next one starts where the previous ended.
- `rotate(-90 ...)` shifts the start point to the top (12 o'clock) instead of the default 3 o'clock.
- `Math.max(..., 0)` ensures very small segments never produce a negative length.

---

## Question
Is this chart accessible? How do screen readers and hover interactions work?

## Answer
The chart includes basic accessibility support:

- The `<svg>` has `role="img"`.
- Each segment has an SVG `<title>` providing label, value, and percentage on hover / to assistive tech:

```jsx
<title>
  {d.label}: {d.value} ({Math.round(frac * 100)}%)
</title>
```

Importantly, the design principle noted in the source is that **color is never the sole carrier of meaning** — the legend always shows the label and value alongside the color dot. This keeps the chart understandable for colorblind users.

For stronger accessibility, consider adding an `aria-label` to the `<svg>` summarizing the overall data.

---

## Question
Why is `d.label` used as the React key, and what pitfall does this create?

## Answer
Both the segments and legend items use `key={d.label}`:

```jsx
data.map((d) => (
  <li key={d.label}> ... </li>
))
```

**Pitfall:** if two data items share the same `label`, React will emit duplicate-key warnings and may render incorrectly. Ensure all labels are unique. If your data can contain duplicate labels, add a distinct identifier and use it as the key instead:

```jsx
const data = [
  { id: 'a', label: 'Active', value: 10, color: '#22c55e' },
  { id: 'b', label: 'Active', value: 5,  color: '#3b82f6' },
];
// key={d.id}
```

---

## Question
How do I style the component (track color, total text, legend)?

## Answer
The component relies on CSS classes and a CSS custom property. You need to provide styles for:

- `var(--track)` — the color of the background ring. Define it in your CSS:
  ```css
  .donut { --track: #e5e7eb; }
  ```
- `.donut` — the wrapper container
- `.donut-total` / `.donut-total-label` — the centered number and "total" caption
- `.legend`, `.legend-dot`, `.legend-label`, `.legend-value` — the legend list

Example:

```css
.donut-total { font-size: 24px; font-weight: 700; }
.donut-total-label { font-size: 11px; fill: #6b7280; }
.legend { list-style: none; padding: 0; }
.legend-dot { display: inline-block; width: 10px; height: 10px; border-radius: 50%; }
```

Note the segment colors come from your `data` (`d.color`), not CSS.

---

## Question
Can I display percentages instead of raw values in the legend?

## Answer
The legend currently renders raw values (`d.value`). The component doesn't expose a prop for this, so you'd either pre-format your data or modify the component. To show percentages without editing the component, compute them into the label or value beforehand:

```jsx
const total = raw.reduce((s, d) => s + d.value, 0);
const data = raw.map((d) => ({
  ...d,
  label: `${d.label} (${Math.round((d.value / total) * 100)}%)`,
}));

<DonutChart data={data} />
```

Note the segment `<title>` tooltips already include percentages automatically, so hovering shows them regardless.

---

## Question
Why do the numbers in the center display correctly but my segments look wrong?

## Answer
Common causes when segments render incorrectly:

1. **Non-numeric `value`** — if `value` is a string, `sum + d.value` will concatenate instead of add, corrupting the total. Ensure values are numbers:
   ```jsx
   { label: 'A', value: Number(rawValue), color: '#000' }
   ```
2. **Missing `color`** — a segment with `undefined` color won't be visible; only the track shows through.
3. **Thickness too large** — if `thickness` nears `size`, the radius shrinks and segments overlap or vanish.
4. **Negative values** — the math assumes non-negative values; negatives will produce incorrect arc lengths and offsets.

The centered total uses the same `reduce`, so if the total looks right but segments don't, suspect per-item `color` or `value` type issues.