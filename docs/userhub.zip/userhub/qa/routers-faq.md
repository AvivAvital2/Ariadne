---
id: 4572ef5a-af45-5d46-aa2f-d7e0c376ba44
type: qa
title: "Routers FAQ"
created_at: 2026-07-30T17:23:13.857271+00:00
updated_at: 2026-07-30T17:23:13.857285+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py
metadata:
  module_name: "backend.app.routers"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Routers FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py`

# `backend.app.routers` — FAQ

> **Note:** The `backend.app.routers` module is currently an empty package initializer. Its docstring states its intended purpose: *"HTTP routers, one module per resource."* The Q&A below reflects both what the code currently contains and the conventions its docstring establishes for developers adding new routers to this package.

---

## Question
What is the purpose of the `backend.app.routers` package?

## Answer
It's a package meant to hold your application's HTTP routers, organized so that **each resource gets its own module**. The docstring makes this convention explicit:

```python
"""HTTP routers, one module per resource."""
```

At present the package only contains this docstring — there are no routers defined yet. You add routers by creating new modules inside this package (for example `users.py`, `orders.py`), one per resource.

---

## Question
How do I add a new router for a resource?

## Answer
Following the "one module per resource" convention, create a new file named after the resource inside `backend/app/routers/`. If you're using FastAPI (the most common framework using this pattern), it would look like this:

```python
# backend/app/routers/users.py
from fastapi import APIRouter

router = APIRouter(prefix="/users", tags=["users"])

@router.get("/")
def list_users():
    return [{"id": 1, "name": "Ada"}]

@router.get("/{user_id}")
def get_user(user_id: int):
    return {"id": user_id}
```

Then register it in your app's entry point:

```python
# backend/app/main.py
from fastapi import FastAPI
from backend.app.routers import users

app = FastAPI()
app.include_router(users.router)
```

---

## Question
Why organize routers as "one module per resource"?

## Answer
This convention keeps the codebase navigable and scalable:

- **Discoverability** — a developer looking for order-related endpoints goes straight to `orders.py`.
- **Isolation** — changes to one resource's routes don't touch unrelated files, reducing merge conflicts.
- **Clear ownership** — each module maps to a bounded slice of the API surface.

Avoid dumping all endpoints into a single file; that scales poorly as the API grows.

---

## Question
Can I import from `backend.app.routers` right now?

## Answer
You can import the package itself, but there is nothing to import *from* it yet:

```python
import backend.app.routers  # works — it's a valid package

from backend.app.routers import users  # fails until users.py exists
```

If you get a `ModuleNotFoundError` or `ImportError`, it's almost certainly because the resource module hasn't been created yet. Add the module first, then import it.

---

## Question
Should this package have an `__init__.py` that re-exports routers?

## Answer
That's optional and depends on your preference. Two common patterns:

**1. Explicit per-module imports (simplest, matches the current empty state):**
```python
from backend.app.routers import users, orders
app.include_router(users.router)
app.include_router(orders.router)
```

**2. Aggregate registration helper in `__init__.py`:**
```python
# backend/app/routers/__init__.py
"""HTTP routers, one module per resource."""
from fastapi import FastAPI
from . import users, orders

def register_routers(app: FastAPI) -> None:
    app.include_router(users.router)
    app.include_router(orders.router)
```
```python
# backend/app/main.py
from backend.app.routers import register_routers
register_routers(app)
```

Pattern 2 centralizes wiring but requires you to remember to add each new module. Pick one and apply it consistently.

---

## Question
What's a good structure for a router module beyond the basics?

## Answer
Keep routers thin — delegate business logic to a service layer and use dependency injection for shared concerns:

```python
# backend/app/routers/orders.py
from fastapi import APIRouter, Depends, HTTPException
from backend.app.services import order_service
from backend.app.dependencies import get_current_user

router = APIRouter(prefix="/orders", tags=["orders"])

@router.get("/{order_id}")
def get_order(order_id: int, user=Depends(get_current_user)):
    order = order_service.find(order_id)
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return order
```

The router handles HTTP concerns (routing, status codes, validation); the service handles domain logic. This keeps modules focused and testable.

---

## Question
How should I handle errors inside a router?

## Answer
Raise framework-native exceptions for HTTP responses rather than returning raw error dicts, so status codes and error shapes stay consistent:

```python
from fastapi import HTTPException

@router.get("/{item_id}")
def get_item(item_id: int):
    item = repo.get(item_id)
    if item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return item
```

For cross-cutting error handling (logging, uniform error envelopes), register exception handlers at the app level instead of repeating `try/except` in every route.

---

## Question
What are common pitfalls when working with this package?

## Answer
- **Circular imports** — if a router imports the main app which imports the router, you'll get an `ImportError`. Import routers *into* the app, never the app into routers.
- **Forgetting to register** — creating a router module isn't enough; you must `include_router` (or call your aggregate helper). A "missing endpoint" 404 is often just an unregistered router.
- **Duplicate prefixes/tags** — two resources sharing the same `prefix` will cause route collisions. Give each resource a distinct prefix.
- **Fat routers** — putting DB queries and business rules directly in route handlers makes them hard to test. Delegate to a service layer.
- **Breaking the convention** — mixing multiple resources into one module defeats the "one module per resource" rule stated in the docstring.