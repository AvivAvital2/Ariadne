---
id: 642312d0-944a-5f98-ba83-7391a990e1e5
type: qa
title: "Barchart FAQ"
created_at: 2026-07-30T17:29:53.744971+00:00
updated_at: 2026-07-30T17:29:53.744986+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx
metadata:
  module_name: "frontend.src.components.charts.BarChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Barchart FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx`

# BarChart Q&A Documentation

## Question
How do I render a basic horizontal bar chart with this component?

## Answer
Import the component and pass it an array of data objects. Each object needs a `label`, a `value`, and optionally a `color`.

```jsx
import BarChart from './frontend/src/components/charts/BarChart';

function Dashboard() {
  const data = [
    { label: 'Chrome', value: 64, color: '#4285F4' },
    { label: 'Safari', value: 19, color: '#34A853' },
    { label: 'Firefox', value: 10, color: '#FBBC05' },
  ];

  return <BarChart data={data} />;
}
```

Each entry becomes a row with the label on the left, a proportional filled bar in the middle, and the numeric value on the right.

---

## Question
What is the `max` prop and when should I use it?

## Answer
`max` sets the value that represents a full-width (100%) bar. If you omit it, the component derives the maximum automatically from your data:

```javascript
const top = max ?? Math.max(1, ...data.map((d) => d.value));
```

Use an explicit `max` when:

- You want bars to reflect a fixed scale (e.g., percentages that always max at `100`).
- You render **multiple charts** that should share the same scale for visual comparison.

```jsx
// Both charts use the same scale
<BarChart data={dataA} max={100} />
<BarChart data={dataB} max={100} />
```

Without a shared `max`, each chart normalizes to its own largest value, making cross-chart comparison misleading.

---

## Question
Why does the auto-calculated maximum include `Math.max(1, ...)`?

## Answer
The `1` guards against two edge cases:

1. **Empty data** — `Math.max()` with no arguments returns `-Infinity`, which would break width calculations. Falling back to `1` keeps things safe.
2. **All-zero values** — if every `value` is `0`, dividing by `0` produces `NaN` widths. Using `1` as the floor prevents division-by-zero.

So even with degenerate input, `top` is always at least `1`, and bar widths compute to valid `0%` values.

---

## Question
How are the bar widths calculated?

## Answer
Each bar's width is the value expressed as a percentage of `top`:

```javascript
style={{ width: `${(d.value / top) * 100}%`, background: d.color }}
```

For example, with `top = 100` and `value = 64`, the fill is `64%` wide. The `background` comes directly from your data's `color` field.

---

## Question
What happens if I don't provide a `color` for a data item?

## Answer
The `background` style is set to `d.color` directly. If `color` is `undefined`, the inline `background` is effectively unset, and the bar falls back to whatever your CSS defines for `.hbar-fill`.

To ensure consistent rendering, either always provide a color or define a default in your stylesheet:

```css
.hbar-fill {
  background: #888; /* fallback when no color is passed */
}
```

---

## Question
Why do the bars use both `title` attributes and visible value labels?

## Answer
This is intentional for accessibility and usability, as noted in the source comment:

- The visible `.hbar-value` (`{d.value}`) provides a **direct value label** so users can read exact numbers without hovering.
- The `title` attributes provide native browser tooltips on hover for the label and the bar.
- The direct labels also satisfy a **"relief rule"** — a technique that reduces reliance on color alone for lower-contrast categorical hues, improving readability for users who can't easily distinguish similar colors.

Avoid removing the visible value labels, as this would weaken accessibility.

---

## Question
Why is `d.label` used as the React `key`?

## Answer
The component keys each row by its label:

```jsx
<div className="hbar-row" key={d.label}>
```

This works well **only if labels are unique**. If you have duplicate labels, React will warn about duplicate keys and may render incorrectly.

**Pitfall:** For datasets that can contain repeated labels, add a unique `id` to your data and key by that instead:

```jsx
// If you can modify the component, prefer:
<div className="hbar-row" key={d.id}>
```

Otherwise, ensure your labels are always distinct.

---

## Question
What CSS classes does this component rely on?

## Answer
The component is unstyled by itself and expects the following classes to be defined in your stylesheet:

| Class | Element |
|-------|---------|
| `.hbars` | Outer container |
| `.hbar-row` | One row per data item |
| `.hbar-label` | The left-side text label |
| `.hbar-track` | The background track that holds the fill |
| `.hbar-fill` | The proportional colored bar |
| `.hbar-value` | The right-side numeric value |

A minimal example:

```css
.hbars { display: flex; flex-direction: column; gap: 8px; }
.hbar-row { display: flex; align-items: center; gap: 8px; }
.hbar-label { width: 100px; overflow: hidden; text-overflow: ellipsis; }
.hbar-track { flex: 1; background: #eee; height: 16px; }
.hbar-fill { height: 100%; }
.hbar-value { width: 40px; text-align: right; }
```

Without these classes, the chart will render but appear unstyled.

---

## Question
How do I display formatted or non-numeric values (e.g., "1.2k" or "$50")?

## Answer
The component renders `d.value` directly for both the label text and width calculation, so `value` must be a **number** for the width math to work.

If you need formatted display text, this component doesn't currently support a separate display field. Your options are:

1. Pre-format outside and extend the component to accept a `displayValue`.
2. Keep `value` numeric and handle formatting in a wrapper.

As written, passing a non-numeric `value` (like `"$50"`) will cause `(d.value / top)` to evaluate to `NaN`, breaking the bar width. Always keep `value` numeric.

---

## Question
Why don't the bars animate or update smoothly when data changes?

## Answer
This component is purely presentational and applies widths via inline styles with no transitions. To add smooth resizing when data updates, add a CSS transition to the fill:

```css
.hbar-fill {
  transition: width 0.3s ease;
}
```

Because widths are driven by inline `style`, the browser will animate between old and new percentages automatically once the transition is defined.