---
id: 69b97f3b-5825-5cdf-92a4-8b149c93c800
type: qa
title: "Icons FAQ"
created_at: 2026-07-30T17:27:45.941581+00:00
updated_at: 2026-07-30T17:27:45.941596+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx
metadata:
  module_name: "frontend.src.components.Icons"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Icons FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx`

# Icons Component — Q&A Documentation

## Question
How do I use these icons in my components?

## Answer
Each icon is a named export you import and render like any React component. No icon-library setup is required—they're inline SVGs.

```jsx
import { IconDashboard, IconSearch, IconBell } from "@/components/Icons";

function Toolbar() {
  return (
    <nav>
      <IconDashboard />
      <IconSearch />
      <IconBell />
    </nav>
  );
}
```

Rendering an icon with no props gives you a `20×20` SVG that draws in the current text color.

---

## Question
How do I change the size of an icon?

## Answer
Pass the `size` prop (a number, in pixels). It sets both `width` and `height`, since all icons use a square `24 24` viewBox.

```jsx
<IconShield size={32} />   // 32×32
<IconClock size={16} />    // 16×16
<IconPlus />               // defaults to 20×20
```

There's no separate width/height option—`size` controls both to keep icons square and undistorted.

---

## Question
How do I control the icon's color?

## Answer
Icons use `stroke="currentColor"`, so they inherit the CSS `color` of their parent element. Set the color via CSS or inline style—there's no `color` prop.

```jsx
// Inline style on a wrapper
<span style={{ color: "tomato" }}>
  <IconBell />
</span>
```

```css
/* Or via a CSS class on the icon or an ancestor */
.danger { color: #e11d48; }
```

```jsx
<IconUserX className="danger" />
```

This design lets one icon adapt to hover states, dark mode, and theme variables automatically.

---

## Question
Can I pass extra SVG attributes like `className`, `style`, or event handlers?

## Answer
Yes. Every icon spreads its props (`{...p}`) onto the underlying `<Svg>`, which spreads them onto the `<svg>` element via `{...rest}`. So any valid SVG/DOM prop works.

```jsx
<IconSearch
  className="search-icon"
  style={{ cursor: "pointer" }}
  onClick={handleSearch}
/>
```

Note: props are applied *after* the defaults, so you can also override defaults like `strokeWidth`:

```jsx
<IconShield strokeWidth={1} />   // thinner outline
```

---

## Question
Are these icons accessible to screen readers?

## Answer
By default each icon has `aria-hidden="true"`, meaning it's treated as decorative and ignored by assistive technology. This is correct when the icon sits next to a visible text label.

If an icon conveys meaning on its own (e.g., an icon-only button), make it accessible by overriding the ARIA attributes and adding a label:

```jsx
// Icon-only button — give it an accessible name
<button aria-label="Notifications">
  <IconBell />
</button>
```

You can also override `aria-hidden` directly if you want the SVG itself labeled:

```jsx
<IconBell aria-hidden={false} role="img" aria-label="Notifications" />
```

---

## Question
What's the purpose of the internal `Svg` wrapper component?

## Answer
`Svg` is a private helper (not exported) that holds the shared SVG boilerplate—`viewBox`, `fill`, `stroke`, `strokeWidth`, line caps/joins, and the default size. Each exported icon only supplies its unique path/shape children:

```jsx
export const IconPlus = (p) => (
  <Svg {...p}>
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </Svg>
);
```

This keeps every icon consistent and avoids repeating markup. Because it's not exported, use it only through the provided icons.

---

## Question
How do I add a new icon to this set?

## Answer
Follow the same pattern: export a function that renders `<Svg>` with your SVG shapes as children. Make sure your paths fit a `0 0 24 24` viewBox and rely on `stroke` (not `fill`) so they inherit color correctly.

```jsx
export const IconHome = (p) => (
  <Svg {...p}>
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <polyline points="9 22 9 12 15 12 15 22" />
  </Svg>
);
```

Always spread `{...p}` first so callers can pass `size`, `className`, etc.

---

## Question
Why does my icon appear as a solid black shape instead of an outline?

## Answer
These icons are **stroke-based**, not fill-based—the `<Svg>` sets `fill="none"` and `stroke="currentColor"`. If a shape appears solid/filled, you likely overrode `fill`, or added a child element that relies on fill. To fix, keep `fill="none"` and let `stroke` do the drawing.

```jsx
// ❌ This fills the shape with the current color
<IconShield fill="currentColor" />

// ✅ Correct: outline drawn by stroke
<IconShield />
```

If you *want* a filled icon, set `fill` and remove/override the stroke intentionally—but that departs from the set's outline style.

---

## Question
Can I animate or style these icons on hover?

## Answer
Yes—since color comes from `currentColor` and props pass through, standard CSS transitions on the parent or the icon work well.

```css
.icon-btn {
  color: #64748b;
  transition: color 0.2s ease;
}
.icon-btn:hover {
  color: #2563eb;
}
```

```jsx
<button className="icon-btn">
  <IconActivity />
</button>
```

For size/stroke animation, you can animate the SVG element directly via a `className`. Because there's no fill, hover effects reliably recolor the outline.

---

## Question
Do these icons require any dependencies or build configuration?

## Answer
No. As noted in the source comment, this is an "inline SVG icon set (no icon-library dependency)." The only requirement is a JSX-capable environment (React + your bundler). There's nothing to install and no runtime icon fonts or sprite sheets to load, which avoids flash-of-unstyled-icon issues and keeps the bundle lean.