---
id: 921e03fd-e02c-5618-aea3-2f7bf88bfba1
type: qa
title: "Constants FAQ"
created_at: 2026-07-30T17:30:16.704149+00:00
updated_at: 2026-07-30T17:30:16.704164+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js
metadata:
  module_name: "frontend.src.constants"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js`

# FAQ: `frontend.src.constants`

## Question
What does this module provide and when should I use it?

## Answer
This module exports three constant objects that define contract values shared between the frontend and backend:

- **`USER_STATUS`** — the possible states of a user account (`active`, `invited`, `deactivated`).
- **`PERMISSIONS`** — permission strings used for authorization checks (e.g., `users:read`).
- **`AUDIT_ACTION_LABELS`** — a map from backend audit action keys to human-readable labels for display.

Use these constants anywhere you need to reference these string values, instead of hardcoding raw strings. This centralizes the values and reduces typos.

```javascript
import { USER_STATUS, PERMISSIONS, AUDIT_ACTION_LABELS } from "./constants";

if (user.status === USER_STATUS.DEACTIVATED) {
  // ...
}
```

---

## Question
How do I check whether a user has a specific permission?

## Answer
Compare the user's permission list against a value from the `PERMISSIONS` object rather than typing the string manually:

```javascript
import { PERMISSIONS } from "./constants";

function canDeactivateUsers(userPermissions) {
  return userPermissions.includes(PERMISSIONS.USERS_DEACTIVATE);
}
```

Using the constant (`PERMISSIONS.USERS_DEACTIVATE`) instead of `"users:deactivate"` means your editor can autocomplete it and a typo becomes a runtime `undefined` you can catch, rather than a silently-failing string comparison.

---

## Question
How do I display a friendly label for an audit action?

## Answer
Look up the raw backend action key in `AUDIT_ACTION_LABELS`:

```javascript
import { AUDIT_ACTION_LABELS } from "./constants";

function getAuditLabel(action) {
  return AUDIT_ACTION_LABELS[action] ?? action;
}

getAuditLabel("user.role_assigned"); // "Roles assigned"
getAuditLabel("user.unknown_event"); // "user.unknown_event" (fallback)
```

Always provide a fallback (as shown with `?? action`). If the backend adds a new audit action that isn't yet in this map, the lookup returns `undefined`, which would render as empty text without a fallback.

---

## Question
Why are these just plain string values instead of shared types or enums?

## Answer
As the module comment explains, there is **no shared type across the HTTP boundary**. The frontend (JavaScript) and backend (Python, in `app/constants.py`) communicate over HTTP using plain strings. Both sides must agree on values like `"deactivated"`, `"users:deactivate"`, and `"user.deactivated"` **by convention**.

That means:
- These constants are a mirror of the backend's constants.
- There is no compiler or tooling that enforces the two stay in sync.
- Keeping them aligned is a manual responsibility.

---

## Question
What's the biggest pitfall to watch out for when editing this file?

## Answer
**Drift between frontend and backend values.** If you change a string here without changing the corresponding value in `app/constants.py` (or vice versa), the two sides will silently disagree. For example, a permission check would fail or an audit label would never match.

Rules of thumb:
- Never rename a **value** (the right-hand side string) without updating the backend.
- The **keys** (left-hand side, e.g., `USERS_DEACTIVATE`) are frontend-only and can be renamed freely as long as you update usages in the frontend.
- When either side adds a new status, permission, or audit action, add it to both files in the same change.

---

## Question
Can I add a new permission or audit action?

## Answer
Yes, but coordinate with the backend. To add a permission:

```javascript
export const PERMISSIONS = {
  // ...existing...
  REPORTS_EXPORT: "reports:export", // must match app/constants.py
};
```

To add an audit action label:

```javascript
export const AUDIT_ACTION_LABELS = {
  // ...existing...
  "user.password_reset": "Password reset", // key must match backend AuditAction
};
```

The **string value/key must exactly match** what the backend emits or checks. The frontend label text (`"Password reset"`) is display-only and can be worded however you like.

---

## Question
Can I mutate these constants at runtime?

## Answer
You can, but you shouldn't. These objects are exported as plain objects and are **not frozen**, so JavaScript won't stop you from doing something like:

```javascript
PERMISSIONS.USERS_READ = "oops"; // technically allowed, but breaks the contract
```

Treat them as read-only. If you want to enforce immutability, you can wrap them with `Object.freeze`:

```javascript
export const USER_STATUS = Object.freeze({
  ACTIVE: "active",
  INVITED: "invited",
  DEACTIVATED: "deactivated",
});
```

This would throw in strict mode on any attempted reassignment, catching accidental mutations early.

---

## Question
How do I iterate over all possible statuses or permissions?

## Answer
Use `Object.values` (for the string values) or `Object.keys` / `Object.entries`:

```javascript
import { USER_STATUS, PERMISSIONS } from "./constants";

Object.values(USER_STATUS);   // ["active", "invited", "deactivated"]
Object.values(PERMISSIONS);   // ["users:read", "users:create", ...]

// Validate an incoming status
function isValidStatus(value) {
  return Object.values(USER_STATUS).includes(value);
}
```

This is useful for building dropdowns, validating input, or rendering permission checkboxes without duplicating the list.

---

## Question
Why don't the `AUDIT_ACTION_LABELS` keys follow the same style as `PERMISSIONS`?

## Answer
They come from different backend value formats:

- **Permissions** use a colon convention: `"resource:action"` (e.g., `"users:deactivate"`).
- **Audit actions** use a dotted convention: `"entity.action"` (e.g., `"user.deactivated"`).

Both are defined by the backend, so the frontend simply mirrors whatever format each system uses. When adding entries, match the backend's existing format for that category exactly rather than normalizing them.