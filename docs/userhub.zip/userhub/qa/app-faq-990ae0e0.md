---
id: 990ae0e0-300a-596a-9610-e80d32426f3e
type: qa
title: "App FAQ"
created_at: 2026-07-30T17:21:09.859772+00:00
updated_at: 2026-07-30T17:21:09.859786+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py
metadata:
  module_name: "backend.app"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# App FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py`

# UserHub Backend — Developer FAQ

> **Note:** The provided source for `backend.app` contains only a module docstring and no implemented symbols. The Q&A below is written against the documented intent of the module (*"a FastAPI + SQLAlchemy user management service"*). Where specific functions, models, or routes are referenced, they represent expected/conventional patterns — verify against your actual implementation, as the current module body is empty.

---

## Question
What is `backend.app` and what does it provide?

## Answer
`backend.app` is the top-level module for **UserHub**, a user management service built on **FastAPI** (web framework) and **SQLAlchemy** (ORM/database layer). Its role is to expose HTTP endpoints for managing users while persisting data through SQLAlchemy models.

Important caveat: as currently committed, the module contains only its docstring:

```python
"""UserHub backend — a FastAPI + SQLAlchemy user management service."""
```

There is no `app` instance, route, or model defined yet. If you're expecting importable objects, you'll need to implement them (see the questions below for the conventional structure).

---

## Question
How do I create and run the FastAPI application?

## Answer
Since the module is currently empty, you'll define the FastAPI app instance yourself. The conventional pattern is to expose a module-level `app` object:

```python
# backend/app.py
from fastapi import FastAPI

app = FastAPI(title="UserHub", version="0.1.0")

@app.get("/health")
def health_check():
    return {"status": "ok"}
```

Run it locally with Uvicorn:

```bash
uvicorn backend.app:app --reload
```

The `backend.app:app` syntax means "import the `app` object from the `backend.app` module." The `--reload` flag auto-restarts the server on code changes (development only).

---

## Question
How should I wire up SQLAlchemy for this service?

## Answer
The docstring names SQLAlchemy as the persistence layer. A typical setup separates the engine/session from your app module:

```python
# backend/db.py
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

engine = create_engine("sqlite:///userhub.db")  # swap for Postgres in prod
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

Then inject the session into routes via FastAPI's `Depends`:

```python
from fastapi import Depends
from sqlalchemy.orm import Session
from backend.db import get_db

@app.get("/users")
def list_users(db: Session = Depends(get_db)):
    return db.query(User).all()
```

**Pitfall:** Always close sessions. The `try/finally` in `get_db` guarantees cleanup even if the request raises.

---

## Question
How do I define a User model?

## Answer
Define an ORM model that inherits from your `Base`. A minimal user model:

```python
# backend/models.py
from sqlalchemy import Column, Integer, String, Boolean
from backend.db import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)
```

Create the tables during startup or via a migration tool:

```python
from backend.db import Base, engine
Base.metadata.create_all(bind=engine)
```

**Best practice:** For anything beyond prototyping, use **Alembic** for migrations rather than `create_all`, which cannot alter existing schemas.

---

## Question
How do I validate request and response data?

## Answer
Use **Pydantic** schemas (bundled with FastAPI) to separate your API contract from your database model. Never expose raw ORM objects containing sensitive fields like passwords.

```python
from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class UserRead(BaseModel):
    id: int
    email: EmailStr
    is_active: bool

    class Config:
        from_attributes = True  # allows returning ORM objects directly
```

```python
@app.post("/users", response_model=UserRead)
def create_user(payload: UserCreate, db: Session = Depends(get_db)):
    user = User(email=payload.email, hashed_password=hash_pw(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
```

Using `response_model=UserRead` ensures `hashed_password` is never serialized in the response.

---

## Question
How should I handle errors like a missing user or duplicate email?

## Answer
Raise `HTTPException` with an appropriate status code instead of returning `None` or letting a raw exception surface:

```python
from fastapi import HTTPException, status

@app.get("/users/{user_id}", response_model=UserRead)
def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="User not found")
    return user
```

For duplicate emails, catch the database `IntegrityError` and translate it:

```python
from sqlalchemy.exc import IntegrityError

try:
    db.commit()
except IntegrityError:
    db.rollback()
    raise HTTPException(status_code=409, detail="Email already registered")
```

**Pitfall:** Always `db.rollback()` after a failed commit before reusing the session, otherwise subsequent queries fail with a "PendingRollbackError."

---

## Question
How do I configure database credentials and secrets?

## Answer
Never hardcode connection strings or secrets. Read them from the environment, ideally via Pydantic's settings management:

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str = "sqlite:///userhub.db"
    secret_key: str

    class Config:
        env_file = ".env"

settings = Settings()
engine = create_engine(settings.database_url)
```

With a `.env` file:

```
DATABASE_URL=postgresql://user:pass@localhost/userhub
SECRET_KEY=change-me-in-production
```

**Best practice:** Keep `.env` out of version control (`.gitignore`) and inject real values via your deployment platform's secret manager.

---

## Question
Why does importing from `backend.app` fail to find `app`, `User`, or my routes?

## Answer
Because the current module body is empty — it contains only the docstring. Any `ImportError` like:

```python
from backend.app import app   # ImportError: cannot import name 'app'
```

means the symbol has not been defined yet. To debug:

1. Confirm the file actually contains the code you expect (`cat backend/app.py`).
2. Ensure you're editing the same file Python imports (`python -c "import backend.app; print(backend.app.__file__)"`).
3. Implement the missing `app` instance, models, and routes as shown in the questions above.

This is the most common "gotcha" for a scaffolded-but-unimplemented module.

---

## Question
How do I test the endpoints?

## Answer
Use FastAPI's `TestClient`, which wraps your `app` and lets you make requests without running a live server:

```python
from fastapi.testclient import TestClient
from backend.app import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

**Best practice:** Override `get_db` with a test session (e.g., an in-memory SQLite database) using `app.dependency_overrides` so tests don't touch your real database:

```python
app.dependency_overrides[get_db] = override_get_db
```

Remember to clear overrides after the test suite to avoid leaking state between tests.