---
id: 0c5af49b-517e-5649-8899-949f33e0b31c
type: qa
title: "Env FAQ"
created_at: 2026-07-30T17:21:00.360804+00:00
updated_at: 2026-07-30T17:21:00.360822+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  module_name: "backend.alembic.env"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Env FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

# Alembic Migration Environment — FAQ

This FAQ covers the `backend.alembic.env` module, which configures the Alembic migration environment for the project.

---

## Question
What is the purpose of this `env.py` file?

## Answer
`env.py` is Alembic's migration environment script. It's executed every time you run an Alembic command (like `alembic upgrade` or `alembic revision --autogenerate`). Its main responsibilities are:

1. Loading logging configuration from the Alembic `.ini` file.
2. Pointing `target_metadata` at your ORM's `Base.metadata` so `--autogenerate` can detect schema changes.
3. Choosing between **offline** and **online** migration modes and running the migrations accordingly.

The bottom of the file decides which mode to run:

```python
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
```

---

## Question
Why is `from app import models` imported but seemingly never used?

## Answer
It's imported for its **side effect**, not for direct use — which is why it's tagged with `# noqa: F401` to silence linters that flag unused imports.

Importing `app.models` ensures every ORM model class is registered against `Base.metadata`. Without this import, `target_metadata` would be empty (or partial), and `alembic revision --autogenerate` would fail to see your tables, producing empty or incorrect migrations.

```python
from app import models  # noqa: F401 - registers tables on Base.metadata
from app.database import Base

target_metadata = Base.metadata
```

**Pitfall:** If you split models across multiple files, make sure they're all imported (directly or transitively) via `app.models`, otherwise Alembic won't detect them.

---

## Question
What's the difference between offline and online migration modes?

## Answer
- **Online mode** (`run_migrations_online`) connects to a live database via a SQLAlchemy engine and runs migrations directly against it. This is the default for most workflows.
- **Offline mode** (`run_migrations_offline`) does *not* connect to a database. Instead, it emits raw SQL by using the configured URL string and `literal_binds=True`, which inlines parameter values into the SQL.

You trigger offline mode with the `--sql` flag:

```bash
# Online (connects to DB and applies changes)
alembic upgrade head

# Offline (prints SQL instead of executing it)
alembic upgrade head --sql > migration.sql
```

Offline mode is useful when a DBA must review or run the SQL manually, or when the CI/deploy pipeline doesn't have direct DB access.

---

## Question
Where does the database URL come from?

## Answer
The URL is read from your Alembic configuration (typically `alembic.ini`) under the `sqlalchemy.url` key.

In **offline** mode it's fetched explicitly:

```python
url = config.get_main_option("sqlalchemy.url")
```

In **online** mode it's read as part of the config section passed to `engine_from_config`:

```python
connectable = engine_from_config(
    config.get_section(config.config_ini_section, {}),
    prefix="sqlalchemy.",
    poolclass=pool.NullPool,
)
```

**Tip:** To avoid hardcoding credentials in `alembic.ini`, override the URL at runtime in `env.py`, for example from an environment variable:

```python
import os
config.set_main_option("sqlalchemy.url", os.environ["DATABASE_URL"])
```

---

## Question
Why is `poolclass=pool.NullPool` used for the online engine?

## Answer
`NullPool` disables connection pooling — each connection is opened and closed on demand rather than being reused from a pool. This is a common choice for migration scripts because:

- Migrations are short-lived, one-off operations that don't benefit from a persistent pool.
- It avoids leaving idle connections open after the migration finishes.
- It sidesteps pooling-related issues (e.g., stale connections) that can occur in CLI contexts.

If you have special connection requirements, you can swap this out, but `NullPool` is the recommended default for Alembic.

---

## Question
How do I generate a new migration with autogenerate?

## Answer
Because `target_metadata = Base.metadata` is configured here, Alembic can diff your ORM models against the current database schema:

```bash
alembic revision --autogenerate -m "add users table"
```

**Requirements for autogenerate to work correctly:**
1. All models must be imported so they register on `Base.metadata` (handled by `from app import models`).
2. The database must be reachable (autogenerate connects to compare against live schema).
3. Always **review the generated migration** — autogenerate can miss certain changes (e.g., column renames, some constraint changes, server defaults).

---

## Question
Why doesn't autogenerate detect my new table/column?

## Answer
The most common causes:

1. **Model not imported.** If the model file isn't imported through `app.models`, its table never registers on `Base.metadata`. Ensure it's included:
   ```python
   # in app/models/__init__.py
   from .user import User
   from .order import Order
   ```
2. **Wrong `Base`.** Your model must inherit from the same `Base` referenced here (`app.database.Base`). Two different `Base` instances = two separate metadata registries.
3. **Autogenerate limitations.** Column renames appear as drop+add, and some things (like server-side defaults or check constraints) require manual edits or extra config.

---

## Question
Why is `fileConfig` guarded by an `if` check?

## Answer
```python
if config.config_file_name is not None:
    fileConfig(config.config_file_name)
```

`config.config_file_name` may be `None` — for example, when Alembic's environment is invoked programmatically without an `.ini` file, or in certain testing scenarios. Calling `fileConfig(None)` would raise an error. The guard ensures logging is only configured when a config file actually exists.

---

## Question
How can I run migrations programmatically from Python instead of the CLI?

## Answer
You can drive Alembic through its API using the same `Config` this env relies on:

```python
from alembic.config import Config
from alembic import command

alembic_cfg = Config("alembic.ini")
# Optionally override the URL:
alembic_cfg.set_main_option("sqlalchemy.url", "postgresql://...")

command.upgrade(alembic_cfg, "head")
```

Alembic will still execute this `env.py`, so the metadata registration and mode-selection logic all apply. This is handy for test setup/teardown or app bootstrapping.

---

## Question
Is each migration wrapped in a transaction?

## Answer
Yes. Both modes wrap `run_migrations()` in `context.begin_transaction()`:

```python
with context.begin_transaction():
    context.run_migrations()
```

This means the migration runs within a transaction (where the database supports transactional DDL, such as PostgreSQL), so a failure rolls back cleanly.

**Pitfall:** Some databases (notably MySQL) don't support transactional DDL — a partially applied migration can't be rolled back automatically. Keep individual migrations small and test them before running against production.