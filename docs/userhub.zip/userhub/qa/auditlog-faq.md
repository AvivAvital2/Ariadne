---
id: d25ab36a-b36f-5d30-82b5-72ed7f30d65b
type: qa
title: "Auditlog FAQ"
created_at: 2026-07-30T17:27:13.017147+00:00
updated_at: 2026-07-30T17:27:13.017162+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx
metadata:
  module_name: "frontend.src.components.AuditLog"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Auditlog FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx`

# AuditLog Component — FAQ

## Question
What does the `AuditLog` component do and how do I use it?

## Answer
`AuditLog` is a self-contained React component that fetches a list of audit entries from the API and renders them in a table. It manages its own state and data fetching, so you can drop it into any page without passing props:

```jsx
import AuditLog from "./components/AuditLog.jsx";

function AdminPage() {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <AuditLog />
    </div>
  );
}
```

On mount, it calls `api.listAudit()` and displays each entry with a timestamp, action label, actor, target, and detail.

---

## Question
When and how is audit data loaded?

## Answer
Data is loaded once when the component mounts, using a `useEffect` with an empty dependency array:

```jsx
useEffect(() => {
  api.listAudit().then(setEntries).catch((e) => setError(e.message));
}, []);
```

Because the dependency array is `[]`, the fetch runs only on the initial render and will **not** re-run automatically. If you need to refresh the data (e.g., after a user performs an action), you would need to add a manual refresh trigger — see the question below about refetching.

---

## Question
How can I add a "refresh" capability so the log reloads on demand?

## Answer
The current code only fetches on mount. To support manual refreshes, extract the fetch into a function and expose a trigger:

```jsx
export default function AuditLog() {
  const [entries, setEntries] = useState([]);
  const [error, setError] = useState(null);

  const load = () => {
    api.listAudit().then(setEntries).catch((e) => setError(e.message));
  };

  useEffect(() => { load(); }, []);

  return (
    <section className="card">
      <button onClick={load}>Refresh</button>
      {/* ...table... */}
    </section>
  );
}
```

You could also add polling with `setInterval` inside the `useEffect` (remember to clear it on unmount).

---

## Question
How are action types displayed, and what is the `dotClass` function for?

## Answer
Each action gets a human-readable label and a colored status dot.

The label comes from a lookup in `AUDIT_ACTION_LABELS`, falling back to the raw action string if no mapping exists:

```jsx
const label = (action) => AUDIT_ACTION_LABELS[action] ?? action;
```

The `dotClass` function assigns a CSS class based on keywords in the action string:

```jsx
function dotClass(action) {
  if (action.includes("deactivated") || action.includes("deleted")) return "bad";   // red
  if (action.includes("created") || action.includes("reactivated")) return "good";  // green
  return "neutral"; // default/gray
}
```

To style these, define `.dot.bad`, `.dot.good`, and `.dot.neutral` in your CSS.

---

## Question
How do I add support for a new action type?

## Answer
There are two places to consider:

1. **Label** — add an entry to `AUDIT_ACTION_LABELS` in `constants.js` so it renders a friendly name. If you skip this, the raw action string is shown as a fallback.

2. **Dot color** — if the new action should be colored, add a keyword check to `dotClass`. For example, to make `"suspended"` show red:

```js
function dotClass(action) {
  if (action.includes("deactivated") || action.includes("deleted") || action.includes("suspended")) return "bad";
  if (action.includes("created") || action.includes("reactivated")) return "good";
  return "neutral";
}
```

Note that `dotClass` uses substring matching, so be careful with keywords that could unintentionally match other actions.

---

## Question
How are missing or null fields handled in the table?

## Answer
The component uses the nullish coalescing operator (`??`) and an em dash (`—`) placeholder for potentially empty fields:

```jsx
<td className="muted">{entry.actor_id ?? "—"}</td>
<td className="muted">{entry.target_type} #{entry.target_id ?? "—"}</td>
```

- `actor_id` shows `—` when it's `null`/`undefined` (e.g., system-generated events).
- `target_id` shows `—` similarly.

Note that `entry.detail` is rendered directly without a fallback, so if it's `null` the cell will simply be empty.

---

## Question
How does error handling work, and what happens on a failed request?

## Answer
If `api.listAudit()` rejects, the error message is stored in state and rendered above the table:

```jsx
.catch((e) => setError(e.message));
```

```jsx
{error && <div className="error">{error}</div>}
```

**Gotchas to be aware of:**
- The error is displayed *above* the table, but the table (with empty body) still renders. The user sees both the error and an empty table.
- `error` is never reset, so if you add a retry mechanism, remember to call `setError(null)` before refetching.
- Only `e.message` is captured — if the API throws non-Error values, this could show `undefined`.

---

## Question
Why is `entry.id` used as the React `key`, and what if entries don't have unique IDs?

## Answer
The list uses `entry.id` as the key:

```jsx
{entries.map((entry) => (
  <tr key={entry.id}>...</tr>
))}
```

This is the recommended practice — keys should be stable and unique. Audit log entries typically have a unique database ID, making this ideal.

Avoid falling back to the array index as a key. Since audit logs may be re-sorted or filtered, index-based keys can cause React to incorrectly reuse DOM nodes. If your entries lack an `id`, generate a stable composite key (e.g., `${entry.created_at}-${entry.action}`).

---

## Question
Why are timestamps sometimes displayed differently across users?

## Answer
Timestamps are formatted with `toLocaleString()`:

```jsx
<td className="muted nowrap">{new Date(entry.created_at).toLocaleString()}</td>
```

This renders the date/time in the **viewer's local timezone and locale format**. This means the same audit entry may appear differently for users in different regions. For consistent, unambiguous timestamps (common in audit contexts), consider:

```jsx
new Date(entry.created_at).toLocaleString("en-US", {
  timeZone: "UTC",
  timeZoneName: "short",
});
```

Also ensure `entry.created_at` is a format the `Date` constructor can parse (ISO 8601 strings are safest). An unparseable value will render as `Invalid Date`.