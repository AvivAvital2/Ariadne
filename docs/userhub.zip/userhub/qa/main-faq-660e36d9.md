---
id: 660e36d9-f46a-5b34-a227-fe3083a25dfd
type: qa
title: "Main FAQ"
created_at: 2026-07-30T17:21:54.712685+00:00
updated_at: 2026-07-30T17:21:54.712699+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  module_name: "backend.app.main"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Main FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`

# UserHub FastAPI Application — FAQ

## Question
How do I run the UserHub application locally?

## Answer
Run the app with Uvicorn from the `backend/` directory:

```bash
uv run uvicorn app.main:app --reload
```

The `--reload` flag enables auto-reloading during development. This starts the FastAPI app defined as `app` in `app.main`. On the very first launch, the app will automatically create the database schema and seed baseline data (see the lifespan handler for details).

---

## Question
What happens on the first launch versus subsequent launches?

## Answer
The `lifespan` handler runs a **first-run bootstrap** every time the app starts, but the operations are idempotent:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)   # creates tables only if missing
    db = SessionLocal()
    try:
        if seed_if_empty(db):          # seeds only if DB is empty
            print("UserHub: seeded baseline permissions, roles, and users (first run).")
    finally:
        db.close()
    yield
```

- **First launch:** `create_all` builds the schema, and `seed_if_empty` inserts baseline permissions, roles, and users. You'll see the "seeded baseline..." message in the console.
- **Later launches:** `create_all` sees existing tables and does nothing; `seed_if_empty` finds data already present and skips seeding.

Because both steps are safe to repeat, you never need to manually gate them behind a "first run" flag.

---

## Question
How can I verify the service is up and running?

## Answer
Use the health-check endpoint:

```bash
curl http://localhost:8000/api/health
```

Response:

```json
{"status": "ok"}
```

This is a lightweight endpoint that only confirms the app is responding — it does **not** check database connectivity or downstream dependencies. If you need deeper checks (e.g. DB reachability), extend the `health` function accordingly.

---

## Question
Why is CORS configured, and when does it actually matter?

## Answer
CORS is configured to allow the Vite dev server:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)
```

In normal development the Vite dev server on `:5173` proxies `/api` requests to this backend, so browser calls are effectively **same-origin** and CORS doesn't come into play. CORS matters for **direct cross-origin calls**, such as:

- Requests made from the browser to a different origin (e.g. testing from another host/port).
- Tools that call the API directly.

Note the Swagger UI at `/docs` is served from the same origin as the API, so it doesn't rely on this CORS config for its own requests.

---

## Question
How do I add support for another frontend origin (e.g. a production domain)?

## Answer
Add the origin to the `allow_origins` list:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "https://userhub.example.com",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)
```

**Pitfall:** Avoid `allow_origins=["*"]` combined with credentialed requests — the CORS spec forbids using the wildcard with `allow_credentials=True`. For production, prefer an explicit list of trusted origins. Consider driving this list from an environment variable rather than hard-coding it.

---

## Question
Where are the actual endpoints defined?

## Answer
The main module only defines the `/api/health` endpoint directly. All other functionality lives in routers that are mounted via `include_router`:

```python
app.include_router(users.router)
app.include_router(roles.router)
app.include_router(audit.router)
app.include_router(reports.router)
```

To find the users, roles, audit, or reports endpoints, look in the corresponding modules under `app.routers`. To add a new feature area, create a new router module and include it here in the same way.

---

## Question
How do I add a new router to the application?

## Answer
1. Create a router module under `app/routers/`, e.g. `app/routers/teams.py`:

```python
from fastapi import APIRouter

router = APIRouter(prefix="/api/teams", tags=["teams"])

@router.get("/")
def list_teams():
    return []
```

2. Import and include it in `app.main`:

```python
from app.routers import audit, reports, roles, teams, users

app.include_router(teams.router)
```

Keep the `/api` prefix consistent with existing routers so the Vite proxy continues to forward requests correctly.

---

## Question
Can I run initialization code that needs to run once on startup?

## Answer
Yes — put it in the `lifespan` handler. Code before `yield` runs at startup; code after `yield` runs at shutdown:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup work
    Base.metadata.create_all(engine)
    db = SessionLocal()
    try:
        seed_if_empty(db)
    finally:
        db.close()
    yield
    # shutdown work would go here (e.g. closing pools, flushing caches)
```

**Best practice:** Make startup logic idempotent so restarts (including `--reload` restarts) remain safe. Always close resources you open — note how the `db` session is closed in a `finally` block to avoid leaks even if seeding raises.

---

## Question
The seed message never appears — is something wrong?

## Answer
Not necessarily. The message:

```
UserHub: seeded baseline permissions, roles, and users (first run).
```

only prints when `seed_if_empty(db)` returns a truthy value, which happens **only when the database was empty**. If you've already run the app once, the data persists, and seeding is skipped silently on subsequent runs.

If you want to re-trigger seeding for testing, drop or delete the underlying database so `seed_if_empty` sees an empty state again. Be careful doing this against any database you don't want to reset.

---

## Question
How is the app's metadata (title/version) set, and where does it show up?

## Answer
Title and version are passed to the `FastAPI` constructor:

```python
app = FastAPI(title="UserHub", version="0.1.0", lifespan=lifespan)
```

These appear in the auto-generated OpenAPI schema and the interactive docs. Visit:

- **Swagger UI:** `http://localhost:8000/docs`
- **ReDoc:** `http://localhost:8000/redoc`
- **OpenAPI JSON:** `http://localhost:8000/openapi.json`

Bump `version` as you release changes so clients and docs reflect the current API version.