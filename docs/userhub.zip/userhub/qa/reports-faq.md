---
id: 1fa25bfb-a9ba-547c-95de-617eaa96e582
type: qa
title: "Reports FAQ"
created_at: 2026-07-30T17:23:20.322134+00:00
updated_at: 2026-07-30T17:23:20.322148+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  module_name: "backend.app.routers.reports"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Reports FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

# Reports Router FAQ (`backend.app.routers.reports`)

## Question
What does the `/api/reports/user-activity` endpoint do?

## Answer
It returns a user activity report built from a raw SQL query that joins the `users` and `audit_log` tables. Unlike the CRUD routes (which use the ORM), this endpoint executes hand-written SQL directly for reporting purposes.

The response is a list of `UserActivityRow` objects:

```bash
curl -H "Authorization: Bearer <token>" \
  https://your-host/api/reports/user-activity
```

The response model is `list[UserActivityRow]`, so each row is validated and serialized according to that schema.

---

## Question
Why does this route use raw SQL instead of the ORM?

## Answer
Reporting queries often involve aggregations, joins, and calculations that are awkward or inefficient to express through the ORM. Writing SQL by hand (stored in `app.reports.queries.USER_ACTIVITY_SQL`) gives you full control over the query shape and performance.

The trade-off: you lose the ORM's type safety and must manually map result rows into schema objects:

```python
rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
return [UserActivityRow(**row) for row in rows]
```

Use raw SQL for read-only reporting; keep using the ORM for standard CRUD operations.

---

## Question
What permission is required to call this endpoint?

## Answer
The caller must have the `AUDIT_READ` permission. This is enforced via a dependency:

```python
actor: User = Depends(require_permission(Permission.AUDIT_READ.value))
```

If the authenticated user lacks this permission, `require_permission` will reject the request (typically with a `403 Forbidden`) before any SQL runs. If the user isn't authenticated at all, expect a `401 Unauthorized`.

Note that the `actor` parameter is bound but not used in the function body—its purpose is purely to trigger the permission check as a side effect of dependency resolution.

---

## Question
Why is `.mappings()` used on the query result?

## Answer
`.mappings()` makes each result row behave like a dictionary keyed by column name, rather than a positional tuple. This lets you unpack rows directly into the Pydantic schema:

```python
rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
return [UserActivityRow(**row) for row in rows]
```

**Gotcha:** The column names/aliases returned by `USER_ACTIVITY_SQL` **must exactly match** the field names defined in `UserActivityRow`. If a column is named differently, `UserActivityRow(**row)` will fail with a validation error (missing or unexpected field). Use SQL aliases (`AS`) to align names.

---

## Question
How do I customize or extend the report query?

## Answer
The SQL lives in `app.reports.queries.USER_ACTIVITY_SQL`, separated from the route logic. Edit it there to change the report:

```python
# app/reports/queries.py
USER_ACTIVITY_SQL = """
    SELECT
        u.id           AS user_id,
        u.email        AS email,
        COUNT(a.id)    AS action_count,
        MAX(a.created_at) AS last_action_at
    FROM users u
    LEFT JOIN audit_log a ON a.user_id = u.id
    GROUP BY u.id, u.email
"""
```

If you add or remove columns, update the `UserActivityRow` schema to match, or the row-mapping step will break. Keeping the SQL in a dedicated module makes it easy to test and review independently of the router.

---

## Question
How can I safely add parameters or filters to the query?

## Answer
Never build SQL by string concatenation—that risks SQL injection. Use bound parameters with `text()` and pass values to `execute()`:

```python
# In queries.py
USER_ACTIVITY_SQL = """
    SELECT u.id AS user_id, COUNT(a.id) AS action_count
    FROM users u
    LEFT JOIN audit_log a ON a.user_id = u.id
    WHERE a.created_at >= :since
    GROUP BY u.id
"""

# In the router
def user_activity(
    since: datetime,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission(Permission.AUDIT_READ.value)),
):
    rows = db.execute(text(USER_ACTIVITY_SQL), {"since": since}).mappings().all()
    return [UserActivityRow(**row) for row in rows]
```

The `:name` placeholders are parameterized and escaped by SQLAlchemy.

---

## Question
Why is the `db` session injected as a dependency instead of created directly?

## Answer
`db: Session = Depends(get_db)` uses FastAPI's dependency injection to obtain a database session. The `get_db` dependency typically manages the session lifecycle (opening it per-request and closing/rolling back afterward via a generator).

This ensures the session is properly cleaned up even if an error occurs, and makes the endpoint easy to test by overriding the dependency:

```python
app.dependency_overrides[get_db] = lambda: test_session
```

Avoid creating sessions manually inside the route—you'd lose this lifecycle management.

---

## Question
What happens if the query returns no rows?

## Answer
The endpoint returns an empty list `[]`, since `.all()` yields an empty result set and the list comprehension produces nothing. This is a valid `200 OK` response—not an error. Clients should handle an empty array as "no activity found."

---

## Question
How do I debug a validation error when mapping rows to `UserActivityRow`?

## Answer
If `UserActivityRow(**row)` raises a Pydantic `ValidationError`, the cause is almost always a mismatch between SQL column names/types and the schema fields. To diagnose:

1. Inspect a raw row before mapping:
   ```python
   rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
   print(rows[0].keys())  # actual column names
   ```
2. Compare those keys against `UserActivityRow`'s field names.
3. Check types—e.g., a `NULL` column mapped to a non-`Optional` field will fail. Mark it `Optional` in the schema or use `COALESCE` in SQL.

Add explicit `AS alias` clauses in the SQL to guarantee names line up with the schema.

---

## Question
Can I add pagination to this report?

## Answer
Yes, but since this is raw SQL, you must add `LIMIT`/`OFFSET` yourself using bound parameters:

```python
USER_ACTIVITY_SQL = """
    SELECT ...
    FROM users u ...
    ORDER BY u.id
    LIMIT :limit OFFSET :offset
"""

def user_activity(
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission(Permission.AUDIT_READ.value)),
):
    rows = db.execute(
        text(USER_ACTIVITY_SQL),
        {"limit": limit, "offset": offset},
    ).mappings().all()
    return [UserActivityRow(**row) for row in rows]
```

Always include an `ORDER BY` when paginating, otherwise row ordering across pages is not guaranteed.