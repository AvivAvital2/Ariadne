---
id: 6d9394a4-2e6e-5ef4-af1d-956ba7dd9f50
type: qa
title: "Topbar FAQ"
created_at: 2026-07-30T17:28:35.918931+00:00
updated_at: 2026-07-30T17:28:35.918944+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx
metadata:
  module_name: "frontend.src.components.Topbar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Topbar FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx`

# Topbar Component — FAQ

## Question
How do I use the `Topbar` component in my app?

## Answer
Import the default export and render it with a `title` prop. The `actor` prop is optional.

```jsx
import Topbar from "./components/Topbar.jsx";

function Dashboard() {
  return (
    <Topbar
      title="Dashboard"
      actor={{ username: "jsmith", full_name: "Jane Smith" }}
    />
  );
}
```

At minimum, you only need `title`:

```jsx
<Topbar title="Settings" />
```

---

## Question
What props does `Topbar` accept, and what shape should `actor` have?

## Answer
`Topbar` accepts two props:

- **`title`** (string) — Rendered as the header's `<h1>`.
- **`actor`** (object, optional) — Represents the current user. It's read for two fields:
  - `username` (string) — Used for the avatar initials and as a fallback display name.
  - `full_name` (string, optional) — Preferred display name shown next to the avatar.

```jsx
const actor = {
  username: "jsmith",
  full_name: "Jane Smith",
};
```

If `actor` is falsy (`null`, `undefined`, etc.), the user chip is simply not rendered thanks to the `{actor && (...)}` guard.

---

## Question
How are the avatar initials generated?

## Answer
The internal `initials` helper takes the first two characters of the name and uppercases them:

```javascript
function initials(name) {
  return (name || "?").slice(0, 2).toUpperCase();
}
```

Examples:

| Input        | Output |
|--------------|--------|
| `"jsmith"`   | `"JS"` |
| `"a"`        | `"A"`  |
| `""` / `null`/ `undefined` | `"?"` |

Note that initials are derived from `actor.username`, **not** `full_name`. So `full_name: "Jane Smith"` with `username: "jsmith"` still shows `JS`, not `JS` from "Jane Smith". Keep this in mind if you expected first-and-last-name initials.

---

## Question
Why doesn't my user chip appear even though I passed an `actor`?

## Answer
The chip only renders when `actor` is truthy:

```jsx
{actor && (
  <div className="actor-chip">...</div>
)}
```

Common causes:

- You passed `actor={null}` or `actor={undefined}`.
- You passed an empty string or `0` (both falsy).
- The object exists but you expected a name to show even without one — in that case the display name falls back to `username`, and if `username` is also missing you'll get an empty `<span>` plus `"?"` initials.

Verify the prop is a non-empty object:

```jsx
<Topbar title="Home" actor={currentUser} /> // ensure currentUser is set
```

---

## Question
Is the search input functional out of the box?

## Answer
No. The search field is presentational only — it renders an icon and an `<input>` with a placeholder, but there is no `value`, `onChange`, or submit handler wired up:

```jsx
<div className="search">
  <IconSearch size={16} />
  <input placeholder="Search…" aria-label="Search" />
</div>
```

To make it interactive, you'd need to extend the component to accept and forward handlers, for example:

```jsx
export default function Topbar({ title, actor, onSearch }) {
  // ...
  <input
    placeholder="Search…"
    aria-label="Search"
    onChange={(e) => onSearch?.(e.target.value)}
  />
}
```

The same applies to the notifications button — it has an accessible label but no `onClick` handler yet.

---

## Question
Where do `IconBell` and `IconSearch` come from, and can I resize them?

## Answer
They are imported from a sibling `Icons.jsx` module:

```javascript
import { IconBell, IconSearch } from "./Icons.jsx";
```

Both accept a `size` prop (a number). In this component they're set to `16` (search) and `18` (bell):

```jsx
<IconSearch size={16} />
<IconBell size={18} />
```

If you need different sizes, adjust those values. Make sure `Icons.jsx` actually exports named `IconBell` and `IconSearch`, or you'll get an undefined-component error.

---

## Question
How do I style the Topbar?

## Answer
The component uses fixed CSS class names and relies on external stylesheets. Target these classes:

- `.topbar` — the outer `<header>`
- `.topbar-title` — the `<h1>`
- `.topbar-actions` — the right-side action group
- `.search` — the search wrapper
- `.icon-btn` — the notifications button
- `.actor-chip` — the user chip container
- `.avatar.sm` — the initials avatar

Since class names aren't configurable via props, all customization happens in your CSS:

```css
.topbar { display: flex; justify-content: space-between; align-items: center; }
.avatar.sm { width: 24px; height: 24px; border-radius: 50%; }
```

---

## Question
Is this component accessible?

## Answer
It includes some accessibility features but has gaps:

**Present:**
- `aria-label="Search"` on the input.
- `aria-label="Notifications"` on the icon button.
- A semantic `<header>` and `<h1>`.

**Potential concerns:**
- Multiple `<h1>` elements per page can harm the heading hierarchy — ensure only one Topbar (and one page-level `<h1>`) is rendered at a time.
- The search input is not associated with a `<form>` or submit action, so screen-reader users get no feedback on searching.
- Ensure icons inside `Icons.jsx` are marked decorative (`aria-hidden`) since the buttons already carry labels.

---

## Question
Can I render multiple Topbars, or reuse it across pages?

## Answer
Yes — the component is stateless and takes all its data via props, so it's safe to reuse across routes:

```jsx
<Topbar title="Dashboard" actor={user} />
// on another page
<Topbar title="Reports" actor={user} />
```

**Pitfall:** avoid rendering two Topbars simultaneously in the same viewport, since each emits an `<h1>`, which is bad for document structure. Render one per page/layout.