---
id: 00d1b38d-1692-564d-8f5b-8f7cdf7d54d3
type: qa
title: "Sidebar FAQ"
created_at: 2026-07-30T17:28:26.234811+00:00
updated_at: 2026-07-30T17:28:26.234830+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx
metadata:
  module_name: "frontend.src.components.Sidebar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Sidebar FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx`

# Sidebar Component FAQ

## How do I render the Sidebar component?

## Answer
The `Sidebar` is a default export that expects four props: `items` (navigation entries), `active` (the currently selected key), `onNavigate` (callback fired on click), and `actor` (the current user, optional).

```jsx
import Sidebar from "./components/Sidebar.jsx";

function App() {
  const [active, setActive] = useState("dashboard");

  const items = [
    { key: "dashboard", label: "Dashboard" },
    { key: "users", label: "Users" },
    { key: "roles", label: "Roles" },
    { key: "audit", label: "Audit Log" },
  ];

  const actor = { username: "jdoe", full_name: "Jane Doe" };

  return (
    <Sidebar
      items={items}
      active={active}
      onNavigate={setActive}
      actor={actor}
    />
  );
}
```

Each item requires a `key` and a `label`. The `key` is used both as the React list key and to look up the icon.

---

## What shape does each `items` entry need?

## Answer
Every entry is an object with two fields:

```js
{ key: "users", label: "Users" }
```

- `key` — a string that must match a property in the internal `ICONS` map to display an icon, and is passed to `onNavigate`.
- `label` — the visible text rendered next to the icon.

There is no runtime validation. If an item omits `label`, you'll get an empty `<span>`; if it omits `key`, React will warn about missing list keys and no icon will render.

---

## How does the sidebar decide which icon to show?

## Answer
Icons are resolved through the internal `ICONS` lookup table keyed by `item.key`:

```js
const ICONS = {
  dashboard: IconDashboard,
  users: IconUsers,
  roles: IconShield,
  audit: IconActivity,
};
```

For each item, `const Icon = ICONS[item.key]` is looked up. The icon is only rendered when a match exists (`{Icon && <Icon size={18} />}`). If you use a `key` not in this map — say `"settings"` — the item still renders, but **without an icon**. To add a new icon, import it and extend the `ICONS` object:

```js
import { IconSettings } from "./Icons.jsx";

const ICONS = {
  // ...existing
  settings: IconSettings,
};
```

---

## How do I highlight the active navigation item?

## Answer
Pass the currently active key via the `active` prop. The component compares `item.key === active` and appends the `active` CSS class:

```jsx
className={`nav-item ${item.key === active ? "active" : ""}`}
```

Style the highlight in your CSS:

```css
.nav-item.active {
  background: #eef;
  font-weight: 600;
}
```

The comparison is a strict string equality, so make sure the value you store in `active` exactly matches the item's `key`.

---

## What happens when a nav item is clicked?

## Answer
Clicking a button calls `onNavigate(item.key)` with that item's key. The component itself does **not** manage active state — it is fully controlled, so you must update `active` yourself in the parent:

```jsx
const [active, setActive] = useState("dashboard");

<Sidebar
  items={items}
  active={active}
  onNavigate={(key) => {
    setActive(key);
    // e.g. also update routing
    navigate(`/${key}`);
  }}
/>
```

If you forget to update state in `onNavigate`, the highlight will never change even though your callback fires.

---

## Is the `actor` prop required? What renders in the footer?

## Answer
No — the footer is conditionally rendered with `{actor && (...)}`, so omitting `actor` (or passing `null`/`undefined`) simply hides the footer without errors.

When provided, the footer shows:
- An avatar with the user's initials, derived from `username` via the `initials()` helper.
- A display name: `actor.full_name` if present, otherwise falling back to `actor.username`.
- A handle: `@{actor.username}`.

```jsx
// full_name shown
<Sidebar actor={{ username: "jdoe", full_name: "Jane Doe" }} ... />

// falls back to username as the name
<Sidebar actor={{ username: "jdoe" }} ... />
```

---

## How are the avatar initials generated?

## Answer
The `initials()` helper takes the first two characters of the username and uppercases them:

```js
function initials(name) {
  return (name || "?").slice(0, 2).toUpperCase();
}
```

- `"jdoe"` → `"JD"`
- `"a"` → `"A"` (single character usernames work fine)
- `undefined` / empty → `"?"` (safe fallback)

Note it slices the raw username, **not** the full name — so it takes the first two letters of `jdoe`, not `Jane Doe`. If you want name-based initials, you'd need to modify the component to pass `actor.full_name`.

---

## Why isn't my icon showing up even though the item renders?

## Answer
The most common cause is a `key` that isn't present in the `ICONS` map. The icon render is guarded:

```jsx
{Icon && <Icon size={18} />}
```

If `ICONS[item.key]` is `undefined`, the guard short-circuits and no icon appears — while the label still renders. Double-check that:

1. Your `item.key` exactly matches an `ICONS` property (case-sensitive).
2. The icon is imported and added to the `ICONS` object.
3. The icon component accepts a `size` prop, since it's called as `<Icon size={18} />`.

---

## Can I customize the icon size or brand text?

## Answer
Both are currently hardcoded. The icon size is fixed at `18`:

```jsx
<Icon size={18} />
```

And the brand block is static markup:

```jsx
<div className="brand">
  <span className="brand-mark">UH</span>
  <span className="brand-name">UserHub</span>
</div>
```

To make these configurable, you'd extend the component's props (e.g. add `iconSize` and `brand` props) — the current version does not expose them. Styling, however, is fully controllable via the `sidebar`, `brand`, `nav`, `nav-item`, `sidebar-footer`, `avatar`, and `who` CSS classes.

---

## Best practices when using this component

## Answer
- **Keep `items` stable** — define it outside render or memoize it to avoid unnecessary re-renders.
- **Keep `active` in sync** with your router so the highlight matches the current page.
- **Match keys to icons** — any custom `key` should be added to the `ICONS` map to avoid iconless items.
- **Handle missing user data gracefully** — the component already falls back for missing `full_name` and `username`, so it's safe to pass a partially populated `actor`.
- **Treat it as controlled** — this component never mutates its own props; all state (active item, navigation) lives in the parent.