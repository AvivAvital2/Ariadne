---
id: d0bff478-c776-5d6d-bf83-c21b0bfa0bf5
type: qa
title: "Services FAQ"
created_at: 2026-07-30T17:24:53.032876+00:00
updated_at: 2026-07-30T17:24:53.032890+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py
metadata:
  module_name: "backend.app.services"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Services FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py`

# FAQ: `backend.app.services`

> **Note:** The `backend.app.services` module is currently a placeholder. It contains only a module-level docstring and no implemented functions, classes, or configuration. The Q&A below explains the module's *intended* role in the architecture and how to work with it as you build it out. Code examples show recommended patterns, not existing implementations.

---

## Question
What is the purpose of the `backend.app.services` module?

## Answer
This module is the **service layer** of the application. Its job is to hold business logic that sits *between the routers (HTTP layer) and the ORM (database layer)*.

The intended separation of concerns is:

- **Routers** — handle HTTP concerns: parsing requests, validating input, returning responses.
- **Services** — handle business logic: orchestration, rules, and coordination of data operations.
- **ORM / Models** — handle persistence: reading and writing to the database.

By keeping business logic here, your routers stay thin and your data-access code stays reusable and testable.

---

## Question
The module is empty. How do I start adding a service?

## Answer
Since the module currently only contains a docstring, you add your first service by defining functions or classes that encapsulate a unit of business logic. A common pattern is to write functions that receive a database session and any needed inputs:

```python
"""Service layer: business logic between the routers and the ORM."""

from sqlalchemy.orm import Session

from backend.app import models


def get_user(db: Session, user_id: int) -> models.User | None:
    """Fetch a single user by ID."""
    return db.query(models.User).filter(models.User.id == user_id).first()


def create_user(db: Session, *, email: str, name: str) -> models.User:
    """Create and persist a new user."""
    user = models.User(email=email, name=name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user
```

Then call these from your routers rather than putting query logic directly in the route handlers.

---

## Question
How should a router use a service function?

## Answer
The router should delegate to the service and stay focused on HTTP concerns. For example, with FastAPI:

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from backend.app import services
from backend.app.database import get_db

router = APIRouter()


@router.get("/users/{user_id}")
def read_user(user_id: int, db: Session = Depends(get_db)):
    user = services.get_user(db, user_id)
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user
```

Notice the service returns plain data (or `None`), and the *router* decides how to translate that into an HTTP response.

---

## Question
Should services be functions or classes?

## Answer
Both are valid; choose based on state and complexity:

- **Functions** are simplest and work well when each operation is independent and takes a `db` session as a parameter. This keeps things explicit and easy to test.
- **Classes** help when you want to group related operations, inject shared dependencies once, or maintain configuration.

```python
class UserService:
    def __init__(self, db: Session):
        self.db = db

    def get(self, user_id: int) -> models.User | None:
        return self.db.query(models.User).filter_by(id=user_id).first()

    def create(self, *, email: str, name: str) -> models.User:
        user = models.User(email=email, name=name)
        self.db.add(user)
        self.db.commit()
        self.db.refresh(user)
        return user
```

Pick one style and stay consistent across the module.

---

## Question
Where should the database session (`Session`) come from?

## Answer
The service layer should **not** create or own the database session. Instead, accept it as a parameter so the caller (usually the router, via dependency injection) controls its lifecycle. This keeps services decoupled from framework-specific session management and makes them easy to test with a mock or in-memory session.

```python
# Good: session passed in
def list_users(db: Session) -> list[models.User]:
    return db.query(models.User).all()
```

Avoid importing and instantiating a global session inside a service function, which makes testing and transaction control harder.

---

## Question
How should errors be handled in the service layer?

## Answer
Keep services **framework-agnostic**: don't raise HTTP exceptions here. Instead:

- Return `None` or empty collections for "not found" cases, and let the router decide the status code, **or**
- Raise domain-specific exceptions that routers translate into HTTP responses.

```python
class UserNotFoundError(Exception):
    """Raised when a user cannot be found."""


def get_user_or_raise(db: Session, user_id: int) -> models.User:
    user = db.query(models.User).filter_by(id=user_id).first()
    if user is None:
        raise UserNotFoundError(user_id)
    return user
```

```python
# In the router:
try:
    user = services.get_user_or_raise(db, user_id)
except services.UserNotFoundError:
    raise HTTPException(status_code=404, detail="User not found")
```

This keeps the service reusable outside of HTTP contexts (e.g., background jobs, CLI tools).

---

## Question
How do I test service functions?

## Answer
Because services take the DB session as a parameter and avoid HTTP concerns, they are easy to test in isolation. Provide a test session (often an in-memory SQLite database or a transactional test database):

```python
def test_create_user(db_session):
    user = services.create_user(db_session, email="a@example.com", name="Ann")
    assert user.id is not None
    assert services.get_user(db_session, user.id).email == "a@example.com"
```

Use a fixture to supply `db_session` with rollback after each test so tests stay isolated.

---

## Question
What are common pitfalls to avoid in the service layer?

## Answer
- **Leaking HTTP concerns:** Don't import or raise `HTTPException` in services—keep them framework-neutral.
- **Owning the session:** Don't create global sessions inside services; accept them as arguments.
- **Putting business logic in routers:** If you find query or rule logic in a route handler, move it here.
- **Mixing persistence into models excessively:** Services orchestrate; models represent data. Keep responsibilities clear.
- **Inconsistent transaction handling:** Decide whether the service or the caller commits, and apply it consistently to avoid partial writes.

---

## Question
How does this module relate to the rest of the app?

## Answer
The service layer is the middle tier in a three-layer flow:

```
Request → Router (HTTP) → Service (business logic) → ORM/Models (database) → Response
```

Related modules you'll typically interact with:

- **Routers** — call into `services` to perform work.
- **`models`** — the ORM entities that services read and write.
- **Schemas / DTOs** — validation and serialization objects passed between routers and services.
- **Database/session module** — provides the `Session` that gets passed into services.

Keeping this module focused on business logic makes each layer independently testable and reusable.