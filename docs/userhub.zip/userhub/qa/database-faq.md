---
id: a702556f-237d-50f9-af36-4dc9771329fc
type: qa
title: "Database FAQ"
created_at: 2026-07-30T17:21:45.785206+00:00
updated_at: 2026-07-30T17:21:45.785218+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  module_name: "backend.app.database"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Database FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

# `backend.app.database` — FAQ

This module sets up the core SQLAlchemy plumbing: the database engine, a session factory (`SessionLocal`), a declarative `Base` for ORM models, and a `get_db` dependency for FastAPI.

---

## Question
How do I use `get_db` in a FastAPI route?

## Answer
`get_db` is a generator-based dependency that yields a request-scoped session and closes it automatically when the request finishes. Inject it with `Depends`:

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from backend.app.database import get_db
from backend.app.models import User

router = APIRouter()

@router.get("/users/{user_id}")
def read_user(user_id: int, db: Session = Depends(get_db)):
    return db.query(User).filter(User.id == user_id).first()
```

You never call `get_db()` yourself—FastAPI resolves the dependency, hands you the `Session`, and the `finally: db.close()` block runs after the response is sent.

---

## Question
How do I define an ORM model using `Base`?

## Answer
Subclass the exported `Base` (a `DeclarativeBase`) and use SQLAlchemy's declarative mapping:

```python
from sqlalchemy.orm import Mapped, mapped_column

from backend.app.database import Base

class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(unique=True)
    name: Mapped[str]
```

All models must inherit from the *same* `Base` so they share one metadata registry, which is what makes table creation and relationship resolution work.

---

## Question
The tables don't exist. How do I create them?

## Answer
Importing the module does **not** create tables—it only defines the engine and metadata. You must explicitly call `create_all`, and you must import your models first so they register with `Base.metadata`:

```python
from backend.app.database import Base, engine
import backend.app.models  # noqa: F401  ensures models are registered

Base.metadata.create_all(bind=engine)
```

**Common pitfall:** if you forget to import the models before calling `create_all`, no tables are created because `Base.metadata` is empty. For production, prefer a migration tool like Alembic instead of `create_all`.

---

## Question
What does `connect_args={"check_same_thread": False}` do, and why is it here?

## Answer
It's SQLite-specific. By default SQLite forbids using a connection across threads. FastAPI serves requests from a threadpool, so a connection created in one thread may be reused in another. Setting `check_same_thread=False` disables that safety check so SQLite works under FastAPI.

**Gotcha:** this arg is only valid for SQLite. If you switch to PostgreSQL or MySQL, remove it:

```python
engine = create_engine("postgresql+psycopg://user:pass@localhost/userhub")
```

---

## Question
How do I switch from SQLite to another database like PostgreSQL?

## Answer
Change `DATABASE_URL` and drop the SQLite-only `connect_args`:

```python
DATABASE_URL = "postgresql+psycopg://user:password@localhost:5432/userhub"

engine = create_engine(DATABASE_URL)  # no check_same_thread
```

Ideally read the URL from an environment variable so it isn't hard-coded:

```python
import os
DATABASE_URL = os.environ["DATABASE_URL"]
```

The rest of the code (`SessionLocal`, `Base`, `get_db`) stays the same.

---

## Question
Why are `autoflush=False` and `autocommit=False` set on the session factory?

## Answer
- **`autocommit=False`** means changes are held in a transaction until you explicitly call `db.commit()`. This is the modern, expected behavior and gives you control over transaction boundaries.
- **`autoflush=False`** means SQLAlchemy won't automatically flush pending changes to the DB before queries. This avoids surprising implicit writes, but means you must call `db.flush()` yourself if you need a query to see uncommitted objects (e.g., to get an auto-generated ID before commit).

Remember to commit your writes:

```python
def create_user(name: str, db: Session):
    user = User(name=name)
    db.add(user)
    db.commit()      # persist
    db.refresh(user) # reload DB-generated fields like id
    return user
```

---

## Question
Do I need to close the session manually?

## Answer
Not when you use `get_db` as a dependency—the `finally: db.close()` block handles it. But if you create a session directly outside of FastAPI (scripts, background jobs), always close it, ideally with a context manager:

```python
from backend.app.database import SessionLocal

with SessionLocal() as db:
    db.add(some_object)
    db.commit()
# session closed automatically
```

Forgetting to close sessions leaks connections and can exhaust the connection pool.

---

## Question
How should I handle errors and rollbacks in a request?

## Answer
`get_db` closes the session but does **not** roll back on exceptions. If a commit fails or you raise midway, wrap your write logic and roll back explicitly:

```python
@router.post("/users")
def create_user(name: str, db: Session = Depends(get_db)):
    try:
        user = User(name=name)
        db.add(user)
        db.commit()
    except Exception:
        db.rollback()
        raise
    db.refresh(user)
    return user
```

Because sessions aren't auto-committed, an uncommitted transaction is simply discarded when the session closes—but an explicit `rollback()` is the safest way to reset session state after a failed operation.

---

## Question
Can I use `get_db` outside of FastAPI (e.g., in tests)?

## Answer
Yes, but since it's a generator you must drive it manually, or just use `SessionLocal` directly (simpler for tests):

```python
# Simplest: use the factory directly
from backend.app.database import SessionLocal

def test_something():
    with SessionLocal() as db:
        ...

# Or override the dependency in FastAPI tests
from backend.app.main import app
from backend.app.database import get_db

def override_get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
```

Dependency overrides are the standard way to swap in a test database session.

---

## Question
Is a single global `engine` and `SessionLocal` safe to share across requests?

## Answer
Yes. The `engine` is designed to be a long-lived, module-level singleton—it manages an internal connection pool and is thread-safe. `SessionLocal` is a *factory*; each call (`SessionLocal()`) produces a fresh, independent session. 

**Pitfall:** never share a single `Session` instance across requests or threads. Always create a new one per request—which is exactly what `get_db` does.