---
id: 8c9f0ccf-98d1-5313-aced-05fcb3470eeb
type: qa
title: "Constants FAQ"
created_at: 2026-07-30T17:21:43.980230+00:00
updated_at: 2026-07-30T17:21:43.980245+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  module_name: "backend.app.constants"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

# `backend.app.constants` — FAQ

## Question
What is the purpose of this module, and why do the enums inherit from `str`?

## Answer
This module centralizes the domain constants shared across the backend: user lifecycle states, permission names, and audit action verbs. The string *values* form an implicit API contract with the frontend, which mirrors them in `frontend/src/constants.js`.

All three enums inherit from `str` (making them "string enums"), which means each member **is** a string. This lets them serialize transparently to JSON and compare directly against raw strings coming from the frontend:

```python
from backend.app.constants import UserStatus

# The member IS a string
assert UserStatus.ACTIVE == "active"          # True
assert UserStatus.ACTIVE.value == "active"    # True
import json
json.dumps({"status": UserStatus.ACTIVE})     # '{"status": "active"}'
```

Because there is no shared type across the HTTP boundary, the client and server agree on values by convention only. **If you change a value here, update `frontend/src/constants.js` too.**

---

## Question
How do I check or enforce a permission?

## Answer
Reference the `Permission` enum member instead of hard-coding the string. The backend enforces permissions via `security.require_permission` (defined elsewhere), and the frontend independently hides controls based on the same string.

```python
from backend.app.constants import Permission
from backend.app import security

@router.delete("/users/{user_id}")
def delete_user(user_id: int, _=Depends(security.require_permission(Permission.USERS_DELETE))):
    ...
```

Using the enum member (`Permission.USERS_DELETE`) rather than the literal `"users:delete"` gives you autocomplete, refactoring safety, and a single source of truth.

---

## Question
How do I validate whether a user status change is allowed?

## Answer
Use the `ALLOWED_STATUS_TRANSITIONS` dictionary. It maps each current status to the set of statuses it may transition into:

```python
from backend.app.constants import UserStatus, ALLOWED_STATUS_TRANSITIONS

def can_transition(current: str, target: str) -> bool:
    return target in ALLOWED_STATUS_TRANSITIONS.get(current, set())

can_transition(UserStatus.INVITED.value, UserStatus.ACTIVE.value)       # True
can_transition(UserStatus.ACTIVE.value, UserStatus.INVITED.value)       # False
```

The permitted transitions are:

| From          | To (allowed)             |
|---------------|--------------------------|
| `invited`     | `active`, `deactivated`  |
| `active`      | `deactivated`            |
| `deactivated` | `active`                 |

Note there is no way to return a user to `invited` once they've moved past it, and you cannot self-transition (e.g. `active` → `active`).

---

## Question
The dictionary uses `.value` as keys. Do I need to pass string values or enum members when looking up transitions?

## Answer
The keys and set members in `ALLOWED_STATUS_TRANSITIONS` are the raw string **values** (`UserStatus.INVITED.value`), not the enum members themselves. However, because `UserStatus` is a `str` enum, lookups work with **either** form:

```python
# Both work, because the enum member equals and hashes like its string value
ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE]         # works
ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE.value]   # works
ALLOWED_STATUS_TRANSITIONS["active"]                  # works
```

For consistency, prefer passing `.value` (or a plain string coming from the request body) since that's what the data structure was built with.

---

## Question
How do I record an audit log entry?

## Answer
Pick the matching `AuditAction` member for the operation you performed. The frontend audit view maps these exact strings to human-readable labels and icons.

```python
from backend.app.constants import AuditAction

audit_log.record(
    action=AuditAction.USER_DEACTIVATED,  # serializes to "user.deactivated"
    user_id=user.id,
    actor_id=current_user.id,
)
```

Watch the naming convention: most values start with `user.` — including role changes (`ROLE_ASSIGNED` → `"user.role_assigned"`, `ROLE_REVOKED` → `"user.role_revoked"`), since they are actions performed *on a user*, not on a role entity.

---

## Question
How do I safely convert an incoming string from the frontend back into an enum?

## Answer
Call the enum with the string value. Invalid values raise `ValueError`, so guard accordingly:

```python
from backend.app.constants import UserStatus

def parse_status(raw: str) -> UserStatus:
    try:
        return UserStatus(raw)
    except ValueError:
        raise HTTPException(status_code=422, detail=f"Unknown status: {raw!r}")

parse_status("active")       # UserStatus.ACTIVE
parse_status("archived")     # raises ValueError -> 422
```

Note that lookup by **value** uses `UserStatus(raw)`, while lookup by **member name** uses `UserStatus["ACTIVE"]`. The frontend sends values (`"active"`), so use the calling form.

---

## Question
Why don't the audit actions perfectly line up with the permissions or statuses?

## Answer
The three enums serve different concerns and are intentionally decoupled:

- **`Permission`** gates whether an action is *allowed* (e.g. `USERS_DEACTIVATE`).
- **`UserStatus`** describes the resulting *state* (e.g. `DEACTIVATED`).
- **`AuditAction`** records that the action *happened* (e.g. `USER_DEACTIVATED`).

A single operation typically touches all three. For example, deactivating a user requires `Permission.USERS_DEACTIVATE`, transitions status to `UserStatus.DEACTIVATED`, and logs `AuditAction.USER_DEACTIVATED`. Don't assume a 1:1 mapping — there is no `AuditAction` for reading users, and there's a `USER_REACTIVATED` audit action even though reactivation reuses the `USERS_EDIT`/`USERS_DEACTIVATE` permissions rather than having its own.

---

## Question
What's the biggest pitfall when modifying this module?

## Answer
**Silently breaking the frontend contract.** Because there is no shared type across the HTTP boundary, the frontend hard-codes these same strings in `frontend/src/constants.js`. Changing a value here will not cause a compile-time error anywhere — it will just cause the frontend to stop recognizing statuses, hide the wrong controls, or fail to map audit actions to labels.

Best practices:
- **Rename the member freely, but change the string value only in lockstep with the frontend.**
- When adding a new `UserStatus`, remember to also add its entry to `ALLOWED_STATUS_TRANSITIONS`, or transitions to/from it will be silently rejected.
- When adding a new `Permission`, wire it into `security.require_permission` at the endpoint *and* into the frontend's control-hiding logic.
- Keep the `str`-enum inheritance — dropping it would break JSON serialization and all the direct string comparisons throughout the codebase.