---
id: 286c9a66-b6be-5b1b-8485-93a21e45d701
type: qa
title: "Main FAQ"
created_at: 2026-07-30T17:30:32.258532+00:00
updated_at: 2026-07-30T17:30:32.258546+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx
metadata:
  module_name: "frontend.src.main"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Main FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx`

# FAQ: `frontend.src.main`

This module is the entry point for the React application. It bootstraps the app by mounting the root `App` component into the DOM.

---

## What does this file do?

## Answer
This is the entry point of the React application. It performs three key tasks:

1. Finds the DOM element with `id="root"` in your HTML.
2. Creates a React root using `createRoot` from React 18's client API.
3. Renders the `<App />` component tree into that root, wrapped in `<React.StrictMode>`.

```javascript
createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
```

Everything you see in the browser starts here.

---

## Where is the `root` element defined?

## Answer
It's not in this file—it lives in your HTML template, typically `index.html`. You need a matching element:

```html
<body>
  <div id="root"></div>
  <script type="module" src="/src/main.jsx"></script>
</body>
```

If the element ID here doesn't match the one in your HTML, mounting will fail (see the error-handling question below).

---

## Why is the app wrapped in `<React.StrictMode>`?

## Answer
`StrictMode` is a development-only helper that activates additional checks and warnings for its descendants. It helps you catch common bugs by:

- Warning about deprecated APIs and unsafe lifecycle methods.
- **Intentionally double-invoking** certain functions (component bodies, effects, reducers) in development to surface side-effect bugs.

Important: `StrictMode` has **no effect in production builds**—it does not slow down or alter your production app. The double-rendering only happens in development.

---

## Why do my `useEffect` hooks (or component logic) run twice?

## Answer
This is caused by `<React.StrictMode>` in development. React deliberately mounts, unmounts, and remounts components once to help you detect effects that aren't properly cleaned up.

The fix is usually to write cleanup functions, not to remove StrictMode:

```javascript
useEffect(() => {
  const subscription = subscribe();
  return () => subscription.unsubscribe(); // cleanup prevents double-subscription bugs
}, []);
```

If you truly want to disable it, remove the wrapper (not recommended):

```javascript
createRoot(document.getElementById("root")).render(<App />);
```

---

## Why is `createRoot` used instead of `ReactDOM.render`?

## Answer
`createRoot` is the React 18+ API and replaces the legacy `ReactDOM.render`. It enables **concurrent features** like automatic batching, transitions, and Suspense improvements.

```javascript
// React 18+ (current)
import { createRoot } from "react-dom/client";
createRoot(document.getElementById("root")).render(<App />);

// Legacy (React 17 and earlier — deprecated)
import ReactDOM from "react-dom";
ReactDOM.render(<App />, document.getElementById("root"));
```

Note the import path: `react-dom/client`, not `react-dom`.

---

## How do I add global providers (Router, Redux, Theme, etc.)?

## Answer
Wrap `<App />` with the provider components here in `main.jsx`. Providers should sit inside `StrictMode` so the whole tree has access:

```javascript
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { store } from "./store";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>,
);
```

This keeps app-wide configuration centralized at the entry point.

---

## What happens if `document.getElementById("root")` returns `null`?

## Answer
`createRoot(null)` throws an error like:

```
Target container is not a DOM element.
```

This usually means:
- Your HTML is missing `<div id="root"></div>`.
- The ID is misspelled or mismatched.
- The script runs before the DOM element exists (rare with module scripts, which defer by default).

For safer debugging, you can guard it:

```javascript
const container = document.getElementById("root");
if (!container) {
  throw new Error("Root element #root not found in the DOM.");
}
createRoot(container).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
```

---

## Where should I import global styles?

## Answer
Global CSS is imported here, and this file is the recommended place for app-wide styles:

```javascript
import "./styles.css";
```

The bundler (e.g., Vite/webpack) injects these styles into the page. Import order matters—styles imported later can override earlier ones. Keep component-scoped styles inside their respective components/CSS modules, and reserve `main.jsx` for truly global styles (resets, variables, typography).

---

## Why does the JSX use a `.jsx` extension in the import?

## Answer
The import explicitly includes the extension:

```javascript
import App from "./App.jsx";
```

This is common in Vite-based projects, where explicit extensions are encouraged for clarity and can be required depending on configuration. If you prefer extensionless imports (`./App`), you may need to configure `resolve.extensions` in your bundler. Being explicit avoids ambiguity when multiple files share a name.

---

## Can I render into multiple root elements?

## Answer
Yes. Each independent DOM node can host its own React root. This is useful for embedding React into an existing (non-React) page.

```javascript
const widget = document.getElementById("sidebar-widget");
if (widget) {
  createRoot(widget).render(<SidebarWidget />);
}

createRoot(document.getElementById("root")).render(<App />);
```

Each root manages its own tree independently. For a standard single-page app, though, one root is all you need.