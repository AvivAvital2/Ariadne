---
id: cc220326-88f5-591c-a6a7-ac55d5310b63
type: qa
title: "Roles FAQ"
created_at: 2026-07-30T17:24:01.692291+00:00
updated_at: 2026-07-30T17:24:01.692304+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  module_name: "backend.app.routers.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

# Roles & Permissions API — FAQ

FAQ-style documentation for the `backend.app.routers.roles` module, which exposes role and permission management endpoints under `/api/roles` and `/api/permissions`.

---

## Question
What endpoints does this module provide, and what does each one do?

## Answer
This router registers three endpoints:

| Method | Path | Function | Purpose |
|--------|------|----------|---------|
| `GET`  | `/api/roles` | `list_roles` | Returns all roles |
| `POST` | `/api/roles` | `create_role` | Creates a new role |
| `GET`  | `/api/permissions` | `list_permissions` | Returns all available permissions |

All three are protected by permission checks and delegate their business logic to the `app.services.roles` service module. The router itself only handles HTTP concerns (routing, request/response models, dependency injection).

---

## Question
What permissions do I need to call each endpoint?

## Answer
Each endpoint declares its required permission through the `require_permission(...)` dependency:

- `GET /api/roles` → requires `USERS_READ`
- `POST /api/roles` → requires `ROLES_MANAGE`
- `GET /api/permissions` → requires `ROLES_MANAGE`

Note the asymmetry: **listing roles** only needs the read-level `USERS_READ` permission (a role is a common attribute of users), while **creating roles** and **listing all permissions** require the elevated `ROLES_MANAGE` permission. If the authenticated user lacks the required permission, `require_permission` will reject the request before your handler runs.

---

## Question
How do I create a new role?

## Answer
Send a `POST` request to `/api/roles` with a JSON body matching the `RoleCreate` schema. Based on how the payload is unpacked in the handler, the body includes a `name`, a `description`, and a list of `permission_ids`:

```python
create_role(
    db,
    name=payload.name,
    description=payload.description,
    permission_ids=payload.permission_ids,
)
```

Example request:

```bash
curl -X POST https://your-host/api/roles \
  -H "Authorization: Bearer <token-with-ROLES_MANAGE>" \
  -H "Content-Type: application/json" \
  -d '{
        "name": "editor",
        "description": "Can edit content",
        "permission_ids": [1, 3, 5]
      }'
```

On success the endpoint returns HTTP `201 Created` with the new role serialized as a `RoleOut` object.

---

## Question
Why does the create endpoint return `201` instead of `200`?

## Answer
The `status_code=201` argument in the route decorator explicitly sets the success status to `201 Created`, which is the correct semantic response for creating a new resource:

```python
@router.post("/api/roles", response_model=RoleOut, status_code=201)
```

The other two endpoints (`list_roles`, `list_permissions`) are `GET` requests and use FastAPI's default `200 OK`. Keep this in mind when writing client tests—asserting `== 200` for role creation will fail.

---

## Question
How do I discover which permissions exist so I can assign them to a role?

## Answer
Call `GET /api/permissions`, which returns a list of `PermissionOut` objects. This is the typical workflow before creating a role:

1. `GET /api/permissions` → get the available permissions and their IDs.
2. `POST /api/roles` → pass the desired IDs in `permission_ids`.

Note that both endpoints require the same `ROLES_MANAGE` permission, so anyone able to create roles can also enumerate permissions.

```bash
# Step 1: discover permissions
curl https://your-host/api/permissions \
  -H "Authorization: Bearer <token-with-ROLES_MANAGE>"

# Step 2: use returned IDs when creating the role
```

---

## Question
Where does the database session come from, and do I need to manage it manually?

## Answer
No—the database session is injected automatically via FastAPI's dependency system:

```python
db: Session = Depends(get_db),
```

`get_db` (from `app.database`) is responsible for creating and cleaning up the SQLAlchemy `Session` per request. You should not open, commit, or close sessions inside these handlers manually; that lifecycle is owned by `get_db` and the service layer. Within the endpoint, you simply pass `db` along to the service functions.

---

## Question
Why is business logic delegated to `role_service` instead of being written in the endpoints?

## Answer
This is a deliberate separation of concerns. The router handles only:

- URL routing
- Request/response validation (`RoleCreate`, `RoleOut`, `PermissionOut`)
- Authorization (`require_permission`)
- Dependency injection (`get_db`)

The actual work—querying, creating, and validating roles/permissions—lives in `app.services.roles`:

```python
return role_service.list_roles(db)
return role_service.create_role(db, name=..., description=..., permission_ids=...)
return role_service.list_permissions(db)
```

**Benefit:** the service functions can be unit-tested independently of HTTP, and reused elsewhere (e.g., in CLI commands or background jobs). When adding new behavior, put the logic in the service, not the router.

---

## Question
What happens if a client requests a role without authentication, or with insufficient permissions?

## Answer
The `actor` dependency drives authorization:

```python
actor: User = Depends(require_permission(Permission.ROLES_MANAGE.value)),
```

`require_permission` resolves the authenticated `User` and verifies they hold the required permission. If authentication fails or the permission check fails, the request is rejected before your handler body executes—so you never receive an unauthorized `actor`. The exact status codes (typically `401 Unauthorized` for missing/invalid credentials and `403 Forbidden` for insufficient permissions) are defined inside `require_permission`, not in this module.

The `actor` variable is injected but not referenced in the handler bodies; its purpose is purely to enforce the permission gate.

---

## Question
Can I change the permission required for an endpoint?

## Answer
Yes—swap the permission passed to `require_permission`. For example, to require `ROLES_MANAGE` for listing roles instead of `USERS_READ`:

```python
@router.get("/api/roles", response_model=list[RoleOut])
def list_roles(
    db: Session = Depends(get_db),
    actor: User = Depends(require_permission(Permission.ROLES_MANAGE.value)),
):
    return role_service.list_roles(db)
```

Always reference permissions through the `Permission` enum and pass `.value`—avoid hardcoding raw permission strings. This keeps permission usage consistent and refactor-safe across the codebase.

---

## Question
Why don't the routes appear under a common prefix like `/api/roles/...`?

## Answer
The router is created without a `prefix`:

```python
router = APIRouter(tags=["roles"])
```

Instead, each route spells out its full path (`/api/roles`, `/api/permissions`). This is why `/api/permissions` can live in the same router as `/api/roles` even though it isn't a sub-path of roles. If you later add a `prefix="/api"` to the `APIRouter`, remember to remove `/api` from each individual route path to avoid double-prefixing (`/api/api/roles`).

The `tags=["roles"]` argument groups all these endpoints together in the auto-generated OpenAPI/Swagger docs.