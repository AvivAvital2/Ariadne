---
id: c3952936-47ef-5f3d-802a-78591ef1db1e
type: qa
title: "Audit FAQ"
created_at: 2026-07-30T17:23:13.407896+00:00
updated_at: 2026-07-30T17:23:13.407909+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  module_name: "backend.app.routers.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

# Audit-Log Endpoint FAQ (`backend.app.routers.audit`)

## Question
How do I retrieve recent audit-log entries?

## Answer
Send a `GET` request to the `/api/audit` endpoint. By default it returns the 100 most recent entries, serialized according to the `AuditLogOut` schema.

```bash
curl -X GET "https://your-host/api/audit" \
  -H "Authorization: Bearer <your-token>"
```

The response is a JSON array of audit-log objects:

```json
[
  { "id": 1, "action": "user.login", "actor": "alice", "timestamp": "..." },
  ...
]
```

---

## Question
How do I filter the audit log by a specific action?

## Answer
Pass the `action` query parameter. Only entries matching that action string are returned.

```bash
curl -X GET "https://your-host/api/audit?action=user.login" \
  -H "Authorization: Bearer <your-token>"
```

If `action` is omitted (or `null`), no action filter is applied and all recent entries are returned. The exact matching semantics (exact match vs. partial/substring) are determined by `audit_service.list_entries`, so check that implementation if you need precise behavior.

---

## Question
How do I control how many entries are returned?

## Answer
Use the `limit` query parameter, which defaults to `100`.

```bash
curl -X GET "https://your-host/api/audit?limit=25" \
  -H "Authorization: Bearer <your-token>"
```

You can combine it with `action`:

```bash
curl -X GET "https://your-host/api/audit?action=user.delete&limit=10" \
  -H "Authorization: Bearer <your-token>"
```

**Pitfall:** The endpoint does not enforce an upper bound on `limit`. A very large value could pull a large result set and impact performance. If you need a hard cap, enforce it in `audit_service.list_entries` or add validation (e.g., `limit: int = Query(100, le=500)`).

---

## Question
What permission is required to access this endpoint?

## Answer
The caller must have the `AUDIT_READ` permission. This is enforced by the dependency:

```python
actor: User = Depends(require_permission(Permission.AUDIT_READ.value))
```

If the authenticated user lacks `AUDIT_READ`, `require_permission` will reject the request (typically with a `403 Forbidden`). Unauthenticated requests are rejected before reaching the handler. The authorized `User` is injected as `actor`, though it is not used further in this particular handler.

---

## Question
Where does the actual data-fetching logic live?

## Answer
The route is intentionally thin. It delegates to the service layer:

```python
return audit_service.list_entries(db, action=action, limit=limit)
```

This separation keeps the router responsible only for HTTP concerns (routing, validation, auth), while `app.services.audit.list_entries` handles the query logic. To change how entries are queried, filtered, or ordered, modify `list_entries` rather than the router.

---

## Question
How is the database session provided?

## Answer
Through FastAPI's dependency injection using `get_db`:

```python
db: Session = Depends(get_db)
```

You don't manage the session manually—`get_db` yields a session per request and handles cleanup (commit/rollback/close) according to its own implementation. In tests, you can override this dependency:

```python
app.dependency_overrides[get_db] = lambda: test_session
```

---

## Question
How do I write a test for this endpoint?

## Answer
Override the auth and database dependencies, then use FastAPI's `TestClient`:

```python
from fastapi.testclient import TestClient
from app.database import get_db
from app.security import require_permission
from app.constants import Permission
from app.main import app

def test_list_audit(monkeypatch):
    app.dependency_overrides[get_db] = lambda: fake_session
    app.dependency_overrides[
        require_permission(Permission.AUDIT_READ.value)
    ] = lambda: fake_user

    client = TestClient(app)
    resp = client.get("/api/audit?action=user.login&limit=5")

    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
```

**Note:** `require_permission(...)` returns a dependency callable, so the override key must match the exact callable used in the route. If overriding is awkward, consider factoring the permission dependency into a module-level variable.

---

## Question
Why does the response use `response_model=list[AuditLogOut]`?

## Answer
It ensures the returned data is validated and serialized through the `AuditLogOut` Pydantic schema. This provides two benefits:

1. **Output filtering** – only fields declared on `AuditLogOut` are exposed, preventing accidental leakage of internal ORM fields.
2. **Automatic docs** – FastAPI generates an accurate OpenAPI schema for the endpoint's response.

If you add fields to the audit model that should be exposed, remember to also add them to `AuditLogOut`; otherwise they will be silently omitted from the response.

---

## Question
The endpoint returns `422 Unprocessable Entity`. What went wrong?

## Answer
This usually means a query parameter failed type coercion. The most common cause is passing a non-integer `limit`:

```bash
# Fails with 422 — limit must be an integer
curl "https://your-host/api/audit?limit=abc"
```

Use a valid integer instead:

```bash
curl "https://your-host/api/audit?limit=50"
```

Authentication/authorization failures, by contrast, return `401` or `403`—not `422`.