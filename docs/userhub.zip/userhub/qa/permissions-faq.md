---
id: c2c3886e-85d1-5505-b58a-3c1e6408b431
type: qa
title: "Permissions FAQ"
created_at: 2026-07-30T17:26:51.417261+00:00
updated_at: 2026-07-30T17:26:51.417276+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js
metadata:
  module_name: "frontend.src.auth.permissions"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Permissions FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js`

# `frontend.src.auth.permissions` — FAQ

## Question
What does `hasPermission` do and how do I use it?

## Answer
`hasPermission` performs a simple client-side check to see whether a given actor holds a specific permission. It takes two arguments — the `actor` (typically the user object from `GET /api/me`) and a `permission` string literal — and returns a boolean.

```javascript
import { hasPermission } from "frontend/src/auth/permissions";

const me = await fetch("/api/me").then((r) => r.json());

if (hasPermission(me, "users:deactivate")) {
  // Show the "Deactivate" button
}
```

It returns `true` only if `actor.permissions` is an array that includes the exact permission string.

---

## Question
Where do permission strings like `"users:deactivate"` come from?

## Answer
Permission literals are defined in `constants.js`. You should import and reference them from there rather than hardcoding raw strings, which reduces the risk of typos.

```javascript
import { PERMISSIONS } from "frontend/src/auth/constants";

hasPermission(me, PERMISSIONS.USERS_DEACTIVATE);
```

The same permission names are enforced on the backend via `security.require_permission`, so the client and server must agree on the exact string values.

---

## Question
Is this check secure? Can I rely on it for authorization?

## Answer
**No.** `hasPermission` is a *client-side convenience* only. It is intended to improve UX — for example, hiding buttons or menu items the user cannot use. It does **not** provide security.

The real authorization boundary is on the backend in `security.require_permission`, which independently enforces the same permission. Never assume that hiding a UI element prevents a malicious user from calling the underlying API. Always let the backend be the source of truth.

---

## Question
What happens if `actor` is `null` or `undefined`?

## Answer
The function handles this gracefully using optional chaining. If `actor` is `null`, `undefined`, or has no `permissions` property, it returns `false` rather than throwing.

```javascript
hasPermission(null, "users:deactivate");        // false
hasPermission(undefined, "users:deactivate");    // false
hasPermission({}, "users:deactivate");           // false
hasPermission({ permissions: null }, "x");       // false
```

This makes it safe to call before the current user has loaded (e.g. during initial render).

---

## Question
How do I check for multiple permissions at once?

## Answer
The function only checks a single permission, so compose it for AND/OR logic:

```javascript
// Requires ALL permissions
const canManage =
  hasPermission(me, "users:deactivate") &&
  hasPermission(me, "users:edit");

// Requires ANY permission
const canView =
  hasPermission(me, "users:read") ||
  hasPermission(me, "users:admin");

// Reusable helpers
const hasAll = (actor, perms) => perms.every((p) => hasPermission(actor, p));
const hasAny = (actor, perms) => perms.some((p) => hasPermission(actor, p));
```

---

## Question
Why does it use `Boolean(...)` instead of just returning the `.includes()` result?

## Answer
Because of the optional chaining, the expression can short-circuit to `undefined` when `actor` or `actor.permissions` is missing. `Boolean(...)` normalizes the result so the function always returns a true boolean (`true`/`false`) rather than `undefined`.

```javascript
undefined?.includes("x");        // undefined
Boolean(undefined);              // false
```

This gives callers a predictable return type, which is friendlier for TypeScript and strict equality checks.

---

## Question
Is the permission match case-sensitive or partial?

## Answer
It's an exact, case-sensitive match because `Array.prototype.includes` uses strict equality (`===`). There is no wildcard or prefix matching.

```javascript
const me = { permissions: ["users:deactivate"] };

hasPermission(me, "users:deactivate"); // true
hasPermission(me, "Users:Deactivate"); // false (case mismatch)
hasPermission(me, "users:");           // false (no partial match)
```

If you need namespace/wildcard behavior (e.g. `"users:*"`), you'll have to build that logic yourself on top of this function.

---

## Question
My check returns `false` even though the user should have the permission. How do I debug it?

## Answer
Work through these common causes:

1. **The actor hasn't loaded yet** — the `GET /api/me` request may still be pending, so `actor` is `null`. Guard your UI on a loading state.
2. **String mismatch** — verify the exact literal, including the namespace and case. Prefer constants from `constants.js`.
3. **`permissions` isn't an array** — inspect the shape of the object:

```javascript
console.log(me?.permissions); // should be an array of strings
console.log(hasPermission(me, "users:deactivate"));
```

4. **Client/server drift** — confirm the backend's `require_permission` uses the identical string; a rename on one side breaks the match.

---

## Question
Can I use this in a React component to conditionally render UI?

## Answer
Yes — that's a primary use case. Fetch the current user once (often via context or a hook), then gate rendering:

```jsx
function DeactivateButton({ user, onDeactivate }) {
  const me = useCurrentUser(); // your app's hook wrapping GET /api/me

  if (!hasPermission(me, "users:deactivate")) {
    return null;
  }

  return <button onClick={() => onDeactivate(user)}>Deactivate</button>;
}
```

Remember: hiding the button is a UX affordance only. The `onDeactivate` API call must still be authorized server-side.