---
id: 6546fa10-242f-5ea1-90b1-d030c2f2770d
type: qa
title: "Userform FAQ"
created_at: 2026-07-30T17:29:11.241772+00:00
updated_at: 2026-07-30T17:29:11.241785+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx
metadata:
  module_name: "frontend.src.components.UserForm"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userform FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx`

# UserForm Component — FAQ

## Question
How do I use the `UserForm` component for both creating and editing users?

## Answer
The `UserForm` component switches between "create" and "edit" modes based on the `user` prop. Pass `null` to create a new user, or pass an existing user object to edit it.

```jsx
// Create mode
<UserForm
  user={null}
  onClose={() => setShowForm(false)}
  onSaved={() => { setShowForm(false); refreshUsers(); }}
/>

// Edit mode
<UserForm
  user={{ id: 42, username: "jdoe", email: "jdoe@example.com", full_name: "Jane Doe", roles: [{ id: 1, name: "admin" }] }}
  onClose={() => setEditing(null)}
  onSaved={() => { setEditing(null); refreshUsers(); }}
/>
```

Internally, `isNew = user === null` determines which API calls run and whether the username field is editable.

---

## Question
What props does `UserForm` accept and which are required?

## Answer
The component accepts three props:

| Prop | Type | Description |
|------|------|-------------|
| `user` | `object \| null` | The user to edit, or `null` to create a new one. Reads `username`, `email`, `full_name`, and `roles`. |
| `onClose` | `function` | Called when the Cancel button is clicked. Typically closes the modal. |
| `onSaved` | `function` | Called after a successful create/update. Use it to close the modal and refresh data. |

All three are effectively required for correct behavior. Note that `onSaved` is only invoked on success — if the API call throws, an error is displayed instead and the form stays open.

---

## Question
What shape does the `user` prop need to have?

## Answer
The component reads the following fields using optional chaining, so partial objects won't crash:

```js
user?.username        // string
user?.email           // string
user?.full_name       // string (note snake_case)
user?.roles           // array of { id, name }
user.id               // used in edit mode for update/assignRoles
```

Watch the naming: the form uses **`full_name`** (snake_case) from the API but stores it in a `fullName` (camelCase) state variable. When editing, `user.id` **must** exist because it's used directly in `updateUser(user.id, ...)` and `assignRoles(user.id, ...)`.

---

## Question
Why can't I edit the username when updating an existing user?

## Answer
By design, the username field is only rendered in create mode:

```jsx
{isNew && (
  <label>
    Username
    <input value={username} onChange={...} required />
  </label>
)}
```

This reflects the API: `createUser` accepts `username`, but `updateUser` only sends `email` and `full_name`. Usernames are treated as immutable identifiers after creation. In edit mode the username is shown read-only in the heading (`Edit @{user.username}`).

---

## Question
How are roles loaded and how does role selection work?

## Answer
Available roles are fetched once on mount via `useEffect`:

```jsx
useEffect(() => {
  api.listRoles().then(setRoles).catch(() => setRoles([]));
}, []);
```

If the request fails, `roles` falls back to an empty array (no roles are shown, but the form still works). The currently selected role IDs are tracked in `roleIds`, initialized from the user's existing roles.

Toggling a checkbox adds or removes the ID immutably:

```jsx
const toggleRole = (id) =>
  setRoleIds((ids) =>
    ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id],
  );
```

This functional update pattern avoids stale state when toggling multiple checkboxes quickly.

---

## Question
How does saving differ between create and edit modes?

## Answer
The `submit` handler branches on `isNew`:

```jsx
if (isNew) {
  await api.createUser({ username, email, full_name: fullName, role_ids: roleIds });
} else {
  await api.updateUser(user.id, { email, full_name: fullName });
  await api.assignRoles(user.id, roleIds);
}
```

- **Create**: a single call that includes `role_ids` in the payload.
- **Edit**: two sequential calls — first updating profile fields, then assigning roles.

A gotcha in edit mode: if `updateUser` succeeds but `assignRoles` fails, you'll be left in a partially-saved state (profile updated, roles not). The error will show, but the profile change is already persisted.

---

## Question
How are errors handled and displayed?

## Answer
Errors are caught in the `submit` handler and stored in state:

```jsx
try {
  // ... API calls
  onSaved();
} catch (err) {
  setError(err.message);
}
```

The message is rendered at the top of the form:

```jsx
{error && <div className="error">{error}</div>}
```

`setError(null)` is called at the start of each submit, clearing stale errors. Note that only `err.message` is displayed — make sure your API client throws `Error` objects (or objects with a `.message`), otherwise you'll show `undefined`.

---

## Question
The form doesn't update when I pass a new `user` prop — why?

## Answer
This is a common pitfall. The state (`username`, `email`, `fullName`, `roleIds`) is initialized from `user` **only on the initial render** via `useState`. Changing the `user` prop later will **not** re-initialize those fields, because there's no `useEffect` syncing them.

The recommended fix is to force a remount by giving the component a `key` tied to the user:

```jsx
<UserForm key={user?.id ?? "new"} user={user} onClose={...} onSaved={...} />
```

Changing the `key` unmounts and remounts the component, re-running `useState` initializers with the new `user`.

---

## Question
Are the form fields validated before submission?

## Answer
Validation is minimal and relies on native HTML constraints:

- **Username** (create mode only): `required`
- **Email**: `type="email"` and `required` — the browser enforces both presence and basic email format.
- **Full name**: no validation; it's optional.

Since the form uses `<form onSubmit={submit}>` with a `type="submit"` button, the browser blocks submission until required fields are valid. For stricter or custom validation (e.g., username format, uniqueness), add your own checks in `submit` before the API call, or handle validation errors returned by the server via the `error` state.

---

## Question
Why does clicking Cancel use `type="button"` instead of a plain button?

## Answer
Because the Cancel button lives inside a `<form>`, it must explicitly declare `type="button"`:

```jsx
<button type="button" className="btn ghost" onClick={onClose}>
  Cancel
</button>
```

Without `type="button"`, browsers default `<button>` inside a form to `type="submit"`, which would trigger form submission (and the API call) instead of just closing. This is an easy-to-miss bug — always set `type="button"` for non-submit buttons in forms.