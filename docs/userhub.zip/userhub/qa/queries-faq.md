---
id: 83c710b9-7898-5781-a811-713e8f550df1
type: qa
title: "Queries FAQ"
created_at: 2026-07-30T17:22:37.865657+00:00
updated_at: 2026-07-30T17:22:37.865671+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  module_name: "backend.app.reports.queries"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Queries FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`

# FAQ: `backend.app.reports.queries`

Hand-written SQL for reporting that reads directly from the `users` and `audit_log` tables, bypassing the ORM.

---

## Question
What does `USER_ACTIVITY_SQL` return?

## Answer
It returns one row per user, summarizing their activity in the audit log. Each row contains:

| Column | Source | Description |
|--------|--------|-------------|
| `user_id` | `users.id` | The user's unique identifier |
| `username` | `users.username` | The user's login name |
| `status` | `users.status` | The user's account status |
| `action_count` | `COUNT(audit_log.id)` | Total number of audit-log actions the user performed |
| `last_action_at` | `MAX(audit_log.created_at)` | Timestamp of the user's most recent action |

Results are ordered by `action_count` descending, so the most active users appear first.

---

## Question
How do I execute this query in my application?

## Answer
`USER_ACTIVITY_SQL` is just a string constant, so you pass it to whatever database driver or connection you use. With SQLAlchemy, for example:

```python
from sqlalchemy import text
from backend.app.reports.queries import USER_ACTIVITY_SQL

def get_user_activity(session):
    result = session.execute(text(USER_ACTIVITY_SQL))
    return result.mappings().all()  # list of dict-like rows
```

Using `.mappings()` lets you access columns by name (e.g. `row["action_count"]`), which matches the aliases defined in the SQL.

With a raw DB-API connection (e.g. psycopg2):

```python
with conn.cursor() as cur:
    cur.execute(USER_ACTIVITY_SQL)
    rows = cur.fetchall()
```

---

## Question
Why does it use a `LEFT JOIN` instead of an inner join?

## Answer
The `LEFT JOIN` ensures that **every user appears in the result**, even users who have never performed any action. For those users:

- `action_count` will be `0` (because `COUNT` ignores the `NULL` values produced by the missing join rows)
- `last_action_at` will be `NULL`

If you switched to an `INNER JOIN`, users with no audit-log entries would silently disappear from the report. Keep the `LEFT JOIN` if you want a complete roster of users.

---

## Question
Why does `COUNT(a.id)` return 0 for inactive users instead of 1?

## Answer
This is a common gotcha with `LEFT JOIN` + `COUNT`. When a user has no matching `audit_log` rows, the join fills the `a.*` columns with `NULL`. Since `COUNT(a.id)` counts **non-NULL values only**, it correctly returns `0`.

Be careful **not** to write `COUNT(*)` here:

```sql
COUNT(*)      -- WRONG: counts the joined row, returns 1 for inactive users
COUNT(a.id)   -- CORRECT: counts actual actions, returns 0 for inactive users
```

Always count a column from the *right* side of the `LEFT JOIN`.

---

## Question
Why is this written as raw SQL instead of using the ORM?

## Answer
Reporting queries often involve aggregations, grouping, and joins that are simpler and more performant to express directly in SQL. The module docstring makes this intentional decision explicit:

> These queries read from the `users` and `audit_log` tables directly, without going through the ORM.

Keeping report SQL in one place (as named constants) makes it easy to review, test, and tune independently of the ORM models. The tradeoff is that changes to the underlying schema won't be caught by ORM refactoring tools, so you must keep the SQL in sync manually.

---

## Question
How can I filter the report to a date range or specific status?

## Answer
The base query has no `WHERE` clause. You'll typically add a parameterized filter. **Never** use string formatting to inject values (SQL injection risk); use bind parameters instead.

For example, to only count actions in the last 30 days:

```python
from sqlalchemy import text

FILTERED_ACTIVITY_SQL = """
SELECT
    u.id              AS user_id,
    u.username        AS username,
    u.status          AS status,
    COUNT(a.id)       AS action_count,
    MAX(a.created_at) AS last_action_at
FROM users u
LEFT JOIN audit_log a
    ON a.actor_id = u.id
    AND a.created_at >= :since        -- filter goes in the JOIN, not WHERE
GROUP BY u.id, u.username, u.status
ORDER BY action_count DESC
"""

session.execute(text(FILTERED_ACTIVITY_SQL), {"since": start_date})
```

**Important:** Put date filters on the `audit_log` table in the `ON` clause, not the `WHERE` clause. If you put `a.created_at >= :since` in a `WHERE`, it turns the `LEFT JOIN` into an effective `INNER JOIN` and drops users who have no recent actions.

Status filtering on the `users` table is safe in a `WHERE` clause, since it applies to the left side:

```sql
WHERE u.status = :status
```

---

## Question
How do I paginate or limit the results?

## Answer
Append a `LIMIT`/`OFFSET` (or database-specific equivalent). Since results are already ordered by `action_count DESC`, this is handy for a "top N most active users" view:

```python
TOP_USERS_SQL = USER_ACTIVITY_SQL + "\nLIMIT :limit OFFSET :offset"

session.execute(text(TOP_USERS_SQL), {"limit": 20, "offset": 0})
```

For deterministic pagination, add a tie-breaker to the ordering (e.g. `ORDER BY action_count DESC, u.id`), otherwise users with equal action counts may reorder between pages.

---

## Question
What are the performance considerations for large tables?

## Answer
This query scans and aggregates the entire `audit_log`, which can be expensive as the table grows. Recommendations:

- **Index the join column:** ensure `audit_log.actor_id` is indexed so the join is efficient.
- **Index `created_at`:** helps when you add date-range filters (see the filtering question above).
- **Consider materialized views** if you run this report frequently and can tolerate slightly stale data.
- **Watch `GROUP BY` cost:** the group is on `u.id, u.username, u.status`. Grouping by the primary key `u.id` is the driver; the other columns are included because they're in the `SELECT`.

---

## Question
How should I test this query?

## Answer
Because it's plain SQL, you can test it against a real (or test) database with known fixtures rather than mocking the ORM:

```python
def test_user_activity_counts(session, seed_data):
    rows = session.execute(text(USER_ACTIVITY_SQL)).mappings().all()
    by_user = {r["username"]: r for r in rows}

    # user with 3 actions
    assert by_user["alice"]["action_count"] == 3
    # user with no actions still appears, with 0 and NULL
    assert by_user["dormant"]["action_count"] == 0
    assert by_user["dormant"]["last_action_at"] is None
```

Test against the same database engine you use in production (e.g. Postgres vs SQLite), since SQL dialects differ in aggregate and date behavior.

---

## Question
What happens if the schema changes (e.g. a column is renamed)?

## Answer
Since this SQL is hand-written and bypasses the ORM, schema changes are **not** automatically detected. If `audit_log.actor_id` or `users.status` is renamed or removed, the query will fail at runtime with a database error rather than at import or ORM-migration time.

Best practices to guard against this:
- Keep integration tests that execute the query against the real schema.
- Search for these query constants when altering the referenced tables.
- Document the table/column dependencies (the module docstring already names `users` and `audit_log`).