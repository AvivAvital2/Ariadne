---
id: e0729037-3374-5cce-8205-d860427e8766
type: qa
title: "Seed FAQ"
created_at: 2026-07-30T17:24:55.143246+00:00
updated_at: 2026-07-30T17:24:55.143260+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  module_name: "backend.app.seed"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Seed FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

# FAQ: `backend.app.seed`

First-run database bootstrap for initializing baseline permissions, roles, users, and audit history.

---

## Question
What does `seed_if_empty` do, and when is it called?

## Answer
`seed_if_empty` bootstraps a fresh database with a baseline dataset so the app is usable on first launch with no manual setup. It inserts:

- **Permissions** — one for each member of the `Permission` enum
- **Roles** — `admin` (full access), `editor` (user management), `viewer` (read-only)
- **Users** — `root` (admin), `alice` (editor), `bob` (invited viewer)
- **Audit history** — a week of illustrative entries so the dashboard isn't empty

It's invoked automatically from the app's lifespan on startup (see `app/main.py`), so you generally don't call it yourself. If you do, pass an active SQLAlchemy `Session`:

```python
from app.seed import seed_if_empty

seeded = seed_if_empty(db)
if seeded:
    print("Database was empty — seeded baseline data.")
else:
    print("Database already populated — nothing to do.")
```

---

## Question
Is it safe to call `seed_if_empty` more than once?

## Answer
Yes. The function is **idempotent**. On entry it checks whether any `Permission` rows exist:

```python
if db.query(Permission).count() > 0:
    return False
```

If any permissions are found, it returns `False` immediately and makes no changes. Seeding only happens when the permissions table is empty, in which case it returns `True`. This is why every startup after the first is a no-op.

**Gotcha:** The emptiness check is based *only* on the `Permission` table. If you manually delete permissions but leave roles/users behind, a re-run will attempt to re-seed and likely fail on unique constraints or create duplicates. Treat the seed as an all-or-nothing baseline.

---

## Question
What's the difference between the return values?

## Answer
| Return value | Meaning |
|--------------|---------|
| `True` | The database was empty and seeding was performed (committed). |
| `False` | Data already existed; nothing was inserted or committed. |

Use the return value to log or branch on first-run behavior:

```python
if seed_if_empty(db):
    logger.info("First run detected — baseline data seeded.")
```

---

## Question
Which permissions do each of the default roles get?

## Answer
Roles are wired to permissions from the `Permission` enum:

- **admin** — *all* permissions (`list(perms.values())`)
- **editor** — `USERS_READ`, `USERS_CREATE`, `USERS_EDIT`, `USERS_DEACTIVATE`
- **viewer** — `USERS_READ`, `AUDIT_READ`

The default users map to roles like so:

```python
root  -> admin   (ACTIVE)
alice -> editor  (ACTIVE)
bob   -> viewer  (INVITED)
```

Note the `bob` user's status is `UserStatus.INVITED`, which is useful for exercising invite/activation flows in a fresh environment.

---

## Question
How is the audit history generated and dated?

## Answer
`_seed_audit_history` inserts ~18 `AuditLog` entries spanning the last 7 days. Each event is defined as a tuple:

```python
(days_ago, hour, action, actor_idx, target_idx, detail)
```

Timestamps are computed relative to the current UTC time, then pinned to a whole hour:

```python
now = datetime.datetime.now(datetime.timezone.utc)
ts = (now - datetime.timedelta(days=days_ago)).replace(
    hour=hour, minute=0, second=0, microsecond=0
)
```

Because `now` is captured at seed time, the exact dates shift depending on when you first run the app — the entries always look like "the past week" relative to first launch.

The `actor_idx`/`target_idx` are indexed modulo the list lengths (`actors[actor_idx % len(actors)]`), so out-of-range indices wrap safely rather than raising.

---

## Question
Why are there multiple `db.flush()` calls before `db.commit()`?

## Answer
`db.flush()` sends pending inserts to the database and populates auto-generated columns (like primary keys) **without committing the transaction**. The seed relies on this ordering:

```python
db.add_all(perms.values())
db.flush()          # permissions need IDs before roles reference them

db.add_all([admin, editor, viewer])
db.flush()          # roles need IDs before users reference them

db.add_all([root, alice, bob])
db.flush()          # <-- assigns user IDs used by the audit history

_seed_audit_history(db, actors=[root.id, alice.id], ...)

db.commit()         # single atomic commit at the end
```

The final `db.flush()` before `_seed_audit_history` is essential — the audit entries reference `root.id`, `alice.id`, etc., which only exist after the flush. Everything is committed once at the end, so if any step fails the whole seed rolls back.

---

## Question
How do I customize the seeded users, roles, or audit events?

## Answer
Edit the definitions directly in `seed_if_empty` / `_seed_audit_history`:

- **Add a user:** create another `User(...)`, include it in the `db.add_all([...])` list, and (if it should appear in history) add its `.id` to the `actors`/`targets` lists.
- **Change role permissions:** adjust the `permissions=[...]` list for the relevant role.
- **Add audit events:** append a new tuple to the `events` list in `_seed_audit_history`.

```python
carol = User(
    username="carol",
    email="carol@userhub.dev",
    full_name="Carol Kim",
    status=UserStatus.ACTIVE.value,
    roles=[viewer],
)
db.add_all([root, alice, bob, carol])
db.flush()

_seed_audit_history(
    db,
    actors=[root.id, alice.id, carol.id],
    targets=[alice.id, bob.id, root.id, carol.id],
)
```

Since seeding runs only when the DB is empty, re-seed against a fresh/reset database to see your changes take effect.

---

## Question
How do I reset and re-seed during development?

## Answer
Because the check is `Permission.count() > 0`, the simplest reliable approach is to drop/recreate the schema (or delete the database file) so *all* tables are empty, then restart the app:

```bash
# e.g. for a SQLite dev DB
rm dev.db
# restart the app — lifespan calls seed_if_empty on an empty DB
```

**Avoid** partial deletes (e.g. clearing only the users table). The seed's emptiness gate looks solely at permissions, so a partial reset either short-circuits to `False` or triggers integrity errors from leftover rows referencing new IDs.

---

## Question
Why does the code use `p.value` for `name` but `p.name` for the description?

## Answer
This maps the `Permission` enum's two attributes onto separate database columns:

```python
Permission(name=p.value, description=p.name.replace("_", " ").title())
```

- `p.value` — the machine-readable permission string stored in `name` (used for lookups and role wiring, e.g. `perms[Perm.USERS_READ.value]`).
- `p.name` — the enum member identifier (e.g. `USERS_READ`), transformed into a human-friendly `description` (`"Users Read"`).

The `perms` dict is keyed by `p.value`, which is what lets the role definitions reference permissions cleanly via `perms[Perm.USERS_READ.value]`.