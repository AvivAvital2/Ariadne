---
id: 12155192-3a9f-59b3-ae24-bc7d181bffac
type: qa
title: "Userlist FAQ"
created_at: 2026-07-30T17:29:19.891061+00:00
updated_at: 2026-07-30T17:29:19.891077+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx
metadata:
  module_name: "frontend.src.components.UserList"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userlist FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx`

# UserList Component — FAQ

## Question
How do I use the `UserList` component?

## Answer
`UserList` is a default export that renders a table of all users with permission-gated actions (create, edit, deactivate/reactivate, delete). It requires a single prop, `actor`, which represents the currently authenticated user and is used to evaluate permissions.

```jsx
import UserList from "./components/UserList.jsx";

function AdminPage({ currentUser }) {
  return <UserList actor={currentUser} />;
}
```

The component fetches users automatically when it mounts, so no additional setup is needed to populate the table.

---

## Question
What is the `actor` prop, and why is it required?

## Answer
The `actor` is the currently logged-in user. It is passed to `hasPermission()` to decide which UI actions to expose:

```jsx
const canCreate = hasPermission(actor, PERMISSIONS.USERS_CREATE);
const canEdit = hasPermission(actor, PERMISSIONS.USERS_EDIT);
const canDeactivate = hasPermission(actor, PERMISSIONS.USERS_DEACTIVATE);
const canDelete = hasPermission(actor, PERMISSIONS.USERS_DELETE);
```

Each capability controls whether a button (New user, Edit, Deactivate/Reactivate, Delete) is rendered. If `actor` lacks a permission, the corresponding control is simply not shown.

**Gotcha:** The component does **not** guard against a missing `actor`. If `actor` is `undefined`, the behavior depends entirely on how `hasPermission` handles a null actor — make sure `hasPermission` returns `false` (denies access) in that case, or wrap `UserList` so it only renders once the actor is loaded.

---

## Question
How does the component load user data, and when does it refresh?

## Answer
Data loading is handled by the `load` function, which calls `api.listUsers()` and stores the result in state:

```jsx
const load = () =>
  api.listUsers().then(setUsers).catch((e) => setError(e.message));

useEffect(() => {
  load();
}, []);
```

- On **mount**, `useEffect` runs `load()` once (empty dependency array).
- After **any successful action** (deactivate, reactivate, delete), `runAction` calls `load()` again to keep the table in sync.
- After a **save** in the `UserForm`, the `onSaved` callback also re-runs `load()`.

There is no polling or automatic re-fetch beyond these triggers. If the underlying data changes elsewhere, you'll need to remount or add your own refresh mechanism.

---

## Question
How are create and edit handled with the `editing` state?

## Answer
A single `editing` state variable drives the `UserForm` modal. It can hold three values:

| Value        | Meaning                          |
|--------------|----------------------------------|
| `null`       | Form closed                      |
| `"new"`      | Creating a brand-new user        |
| user object  | Editing that existing user       |

```jsx
{editing && (
  <UserForm
    user={editing === "new" ? null : editing}
    onClose={() => setEditing(null)}
    onSaved={() => {
      setEditing(null);
      load();
    }}
  />
)}
```

- Clicking **New user** sets `editing` to `"new"`, which passes `user={null}` to the form.
- Clicking **Edit** sets `editing` to the row's user object.
- `onClose` closes the form without reloading; `onSaved` closes it **and** reloads the list.

---

## Question
How are errors surfaced to the user?

## Answer
Errors from both the initial load and any action are stored in a single `error` state and rendered near the top of the card:

```jsx
{error && <div className="error">{error}</div>}
```

The `runAction` helper clears the previous error before each action and captures any thrown message:

```jsx
const runAction = async (fn) => {
  setError(null);
  try {
    await fn();
    await load();
  } catch (e) {
    setError(e.message);
  }
};
```

**Note:** Only `e.message` is displayed, so your API client should throw `Error` objects with meaningful messages. Non-`Error` rejections (e.g., a rejected string) would render `undefined`.

---

## Question
Why do Deactivate and Reactivate appear conditionally?

## Answer
The two buttons are mutually exclusive based on the user's current status, and both require the `USERS_DEACTIVATE` permission:

```jsx
{canDeactivate && user.status !== USER_STATUS.DEACTIVATED && (
  <button ... onClick={() => runAction(() => api.deactivateUser(user.id))}>
    Deactivate
  </button>
)}
{canDeactivate && user.status === USER_STATUS.DEACTIVATED && (
  <button ... onClick={() => runAction(() => api.reactivateUser(user.id))}>
    Reactivate
  </button>
)}
```

- Active users show **Deactivate**.
- Deactivated users show **Reactivate**.
- A single permission (`canDeactivate`) governs both directions — there is no separate "reactivate" permission.

---

## Question
Why does the Delete button not ask for confirmation?

## Answer
It doesn't — clicking Delete immediately calls the API:

```jsx
<button className="btn danger sm" onClick={() => runAction(() => api.deleteUser(user.id))}>
  Delete
</button>
```

This is a **potential pitfall**, since deletion is destructive and irreversible. If you want a safety net, wrap the call in a confirmation:

```jsx
onClick={() => {
  if (window.confirm(`Delete ${user.username}?`)) {
    runAction(() => api.deleteUser(user.id));
  }
}}
```

Consider extracting this into a reusable confirm dialog for consistency across destructive actions.

---

## Question
How are the avatar initials and display name computed?

## Answer
The avatar shows the first two characters of the username (uppercased), with a fallback to `"?"`. The display name prefers `full_name`, falling back to `username`:

```jsx
<span className="avatar sm">
  {(user.username || "?").slice(0, 2).toUpperCase()}
</span>
...
<div className="cell-name">{user.full_name || user.username}</div>
<div className="cell-sub">@{user.username}</div>
```

Roles are joined by commas, with an em dash for users with no roles:

```jsx
{user.roles.map((r) => r.name).join(", ") || "—"}
```

**Gotcha:** `user.roles` is assumed to always be an array. If the API can return `null`/`undefined` for `roles`, `.map` will throw. Guard against it (`(user.roles || [])`) if that's possible in your data.

---

## Question
What shape does a user object need to have?

## Answer
Based on the render logic, each user in the list should provide:

| Field       | Type    | Used for                                      |
|-------------|---------|-----------------------------------------------|
| `id`        | string/number | React `key` and action target             |
| `username`  | string  | Avatar initials, `@username`, name fallback   |
| `full_name` | string  | Primary display name (optional)               |
| `email`     | string  | Email column                                  |
| `status`    | string  | Status badge and deactivate/reactivate logic (compared against `USER_STATUS.DEACTIVATED`) |
| `roles`     | array of `{ name }` | Roles column                       |

Make sure `api.listUsers()` returns objects matching this shape so the table renders correctly.

---

## Question
Can I customize the styling or replace the icons?

## Answer
Styling is driven entirely by CSS class names (`card`, `btn primary`, `btn ghost sm`, `btn danger sm`, `badge ${user.status}`, `avatar sm`, etc.), so you customize appearance by editing the corresponding CSS rather than the component. Note that the status badge class is dynamic:

```jsx
<span className={`badge ${user.status}`}>{user.status}</span>
```

This means you should define a CSS class for **every** possible status value (e.g., `.badge.active`, `.badge.deactivated`).

The "New user" icon comes from `IconPlus`:

```jsx
import { IconPlus } from "./Icons.jsx";
...
<IconPlus size={16} /> New user
```

To swap it, replace the import with a different icon component that accepts a `size` prop.