---
id: cb26d071-68a7-5fbd-b326-a345601405ad
type: qa
title: "Models FAQ"
created_at: 2026-07-30T17:22:35.832599+00:00
updated_at: 2026-07-30T17:22:35.832612+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  module_name: "backend.app.models"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Models FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

# `backend.app.models` — FAQ

## Question
How is the RBAC (role-based access control) model structured in this module?

## Answer
The module implements a classic three-tier RBAC pattern connected by two many-to-many association tables:

- **`User`** ↔ **`Role`** via the `user_roles` table
- **`Role`** ↔ **`Permission`** via the `role_permissions` table

A user's effective permissions are derived transitively: a `User` has `Role`s, and each `Role` grants `Permission`s. The `AuditLog` model is separate and records who did what.

```
User  <--(user_roles)-->  Role  <--(role_permissions)-->  Permission
```

To collect a user's permissions in code:

```python
def permissions_for(user: User) -> set[str]:
    return {perm.name for role in user.roles for perm in role.permissions}
```

---

## Question
How do I create a user and assign roles?

## Answer
Because the relationships are defined with `relationship(secondary=...)`, you assign related objects directly to the Python attributes — SQLAlchemy manages the association tables for you.

```python
from app.models import User, Role
from app.database import SessionLocal  # your session factory

with SessionLocal() as session:
    admin_role = session.query(Role).filter_by(name="admin").one()

    user = User(
        username="alice",
        email="alice@example.com",
        full_name="Alice Smith",
        status="active",
        roles=[admin_role],          # assign roles at creation
    )
    session.add(user)
    session.commit()
```

To modify roles later, just mutate the list:

```python
user.roles.append(some_role)
user.roles.remove(admin_role)
session.commit()
```

---

## Question
Why aren't `created_at` / `updated_at` being set — do I have to pass them manually?

## Answer
No. They're populated automatically via the `default` and `onupdate` callbacks:

```python
created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=_utcnow)
updated_at: Mapped[datetime.datetime] = mapped_column(
    DateTime, default=_utcnow, onupdate=_utcnow
)
```

- `created_at` is set once, when the row is first inserted.
- `updated_at` is set on insert **and** refreshed on every `UPDATE`.

**Gotcha:** These defaults are applied at *flush* time, not at object construction. If you read `user.created_at` before `session.flush()`/`commit()`, it will still be `None`. Call `session.flush()` or `session.refresh(user)` to populate them.

---

## Question
Why does `_utcnow` use `datetime.timezone.utc`, and what should I watch out for?

## Answer
`_utcnow()` produces a **timezone-aware** UTC timestamp:

```python
def _utcnow() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc)
```

This is preferred over the deprecated `datetime.utcnow()`, which returns a naive datetime.

**Pitfall with SQLite:** The columns use the plain `DateTime` type, which does **not** store timezone information in SQLite. When you read the value back, you may get a *naive* datetime even though you stored an aware one. Don't rely on `.tzinfo` being present after a round-trip — treat all stored timestamps as UTC by convention and attach tzinfo explicitly if you need arithmetic:

```python
ts = user.created_at.replace(tzinfo=datetime.timezone.utc)
```

---

## Question
What are the uniqueness and indexing constraints I should know about?

## Answer
The following constraints are enforced at the database level:

| Model | Column | Constraint |
|-------|--------|-----------|
| `User` | `username` | `unique=True`, `index=True` |
| `User` | `email` | `unique=True` |
| `Role` | `name` | `unique=True` |
| `Permission` | `name` | `unique=True` |
| `AuditLog` | `action` | `index=True` |
| `AuditLog` | `created_at` | `index=True` |

Inserting a duplicate `username`, `email`, `role.name`, or `permission.name` raises an `IntegrityError` on commit. Handle it explicitly:

```python
from sqlalchemy.exc import IntegrityError

try:
    session.add(User(username="alice", email="alice@example.com"))
    session.commit()
except IntegrityError:
    session.rollback()
    # username or email already taken
```

Note that `email` is unique but **not** indexed for lookups; if you frequently query by email, consider adding `index=True`.

---

## Question
What are the valid values for `status`, `action`, and `permission.name`?

## Answer
These are stored as free-form strings, but the comments indicate they're meant to hold values from external enums:

- `User.status` — a `UserStatus` value such as `"active"`, `"deactivated"`, `"invited"` (the default is `"invited"`).
- `Permission.name` — a `Permission` value such as `"users:deactivate"`.
- `AuditLog.action` — an `AuditAction` value such as `"user.deactivated"`.

**Important:** The database does **not** enforce these enums. Validate at the application layer (e.g., using Python `Enum` types and `.value`) before persisting to avoid silently storing invalid values:

```python
from enum import Enum

class UserStatus(str, Enum):
    invited = "invited"
    active = "active"
    deactivated = "deactivated"

user.status = UserStatus.active.value
```

---

## Question
How do I write an audit log entry, and why are some fields nullable?

## Answer
`AuditLog` records an actor performing an action on a target:

```python
from app.models import AuditLog

session.add(AuditLog(
    actor_id=current_user.id,
    action="user.deactivated",
    target_type="user",
    target_id=target_user.id,
    detail="Deactivated via admin console",
))
session.commit()
```

Two fields are nullable by design:

- **`actor_id`** (`int | None`) — allows logging system-initiated or anonymous actions where there is no user actor.
- **`target_id`** (`int | None`) — allows actions that don't target a specific record.

Note that `actor_id` is a foreign key to `users.id`, but `target_id` is a plain `Integer` (not a foreign key), since `target_type` may point at different tables. This means there's **no referential integrity** on the target — validate it yourself if needed.

---

## Question
Why are the relationship type hints written as strings like `list["Role"]`?

## Answer
The forward references (`Mapped[list["Role"]]`, `Mapped[list["Permission"]]`) let you reference classes that are defined **later** in the file. Since `User` is declared before `Role`, quoting `"Role"` avoids a `NameError` at class-definition time.

The `back_populates` argument keeps both sides of each relationship in sync:

```python
# On User:
roles: Mapped[list["Role"]] = relationship(secondary=user_roles, back_populates="users")
# On Role:
users: Mapped[list[User]] = relationship(secondary=user_roles, back_populates="roles")
```

Because of `back_populates`, appending a role to `user.roles` automatically makes that user appear in `role.users` within the same session — no need to update both sides manually.

---

## Question
How do I efficiently load a user with all their roles and permissions?

## Answer
By default the relationships are **lazily loaded**, which can trigger the N+1 query problem when iterating over many users' permissions. Use eager loading for read-heavy paths:

```python
from sqlalchemy.orm import selectinload
from sqlalchemy import select
from app.models import User, Role

stmt = (
    select(User)
    .options(selectinload(User.roles).selectinload(Role.permissions))
    .where(User.username == "alice")
)
user = session.scalars(stmt).one()

# No extra queries when accessing:
perms = {p.name for r in user.roles for p in r.permissions}
```

`selectinload` issues a small, fixed number of queries regardless of how many users/roles are involved, making it well suited to many-to-many chains like this one.

---

## Question
How are these tables actually created in the database?

## Answer
All four models inherit from `Base` (imported from `app.database`), and the two association tables are attached to `Base.metadata`. That means creating the schema is a single call:

```python
from app.database import Base, engine

Base.metadata.create_all(engine)
```

This creates all six tables: `users`, `roles`, `permissions`, `role_permissions`, `user_roles`, and `audit_log`.

**Best practice:** `create_all` is fine for tests and prototyping, but it won't alter existing tables. For evolving schemas in production, use a migration tool like **Alembic** so you can version and apply incremental changes safely.