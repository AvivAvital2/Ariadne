---
id: ce300624-9faf-59f8-b62b-12d76fb859a4
type: qa
title: "Config FAQ"
created_at: 2026-07-30T17:31:09.917440+00:00
updated_at: 2026-07-30T17:31:09.917454+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js
metadata:
  module_name: "frontend.vite.config"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Config FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js`

# Vite Config FAQ

## Question
What does this Vite configuration do?

## Answer
This is a Vite configuration for a React frontend that runs on port `5173` and proxies API requests to a FastAPI backend. The key features are:

1. **React plugin** — enables React support (JSX, Fast Refresh, etc.) via `@vitejs/plugin-react`.
2. **Dev server on port 5173** — the standard Vite default port, made explicit here.
3. **API proxy** — any request starting with `/api` is forwarded to `http://127.0.0.1:8000` (the FastAPI backend).

```javascript
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": "http://127.0.0.1:8000",
    },
  },
});
```

---

## Question
How do I make API calls from the frontend using this setup?

## Answer
Because the proxy forwards `/api` to the backend, you should use **same-origin relative URLs** in your frontend code. Don't hardcode the backend's host or port.

```javascript
// ✅ Correct — relative URL, gets proxied to the backend
const res = await fetch(`/api/users/${id}/status`);

// ❌ Avoid — bypasses the proxy and can cause CORS issues
const res = await fetch(`http://127.0.0.1:8000/api/users/${id}/status`);
```

The relative path `/api/users/{id}/status` maps directly onto the backend's route templates, so what you write in the frontend mirrors the backend routes.

---

## Question
Why does the proxy target use `127.0.0.1` instead of `localhost`?

## Answer
This is a deliberate choice to avoid a common performance pitfall. `localhost` can resolve to both IPv4 (`127.0.0.1`) and IPv6 (`::1`). If the backend only listens on IPv4, an initial connection attempt to `::1` will be refused, and Node.js retries over IPv4 — adding a slow fallback on *every request*.

```javascript
// ✅ Explicit IPv4 — no ambiguity, no fallback delay
"/api": "http://127.0.0.1:8000",

// ⚠️ May cause slow per-request IPv6 fallback if backend is IPv4-only
"/api": "http://localhost:8000",
```

Using `127.0.0.1` guarantees the connection goes straight to the IPv4 address the backend is listening on.

---

## Question
How do I start the dev server and confirm the proxy is working?

## Answer
Start the Vite dev server (typically via your `package.json` script):

```bash
npm run dev
```

The frontend will be available at `http://localhost:5173`. To confirm proxying works:

1. Make sure the FastAPI backend is running on `127.0.0.1:8000`.
2. From the frontend, request a relative URL like `/api/...`.

If you see a proxy error such as `ECONNREFUSED`, the backend isn't running or isn't listening on the expected address/port.

---

## Question
Can I proxy more than one path prefix, or use advanced proxy options?

## Answer
Yes. The shorthand string form (`"/api": "http://127.0.0.1:8000"`) is convenient, but you can expand any entry to an object for finer control, and add additional prefixes:

```javascript
server: {
  proxy: {
    "/api": "http://127.0.0.1:8000",

    // Object form with extra options
    "/ws": {
      target: "ws://127.0.0.1:8000",
      ws: true,               // enable WebSocket proxying
    },

    // Rewrite the path before forwarding
    "/legacy": {
      target: "http://127.0.0.1:8000",
      rewrite: (path) => path.replace(/^\/legacy/, "/api"),
    },
  },
}
```

Common options include `changeOrigin`, `secure`, `ws`, and `rewrite`.

---

## Question
The proxy target port is hardcoded to 8000. How can I make it configurable?

## Answer
Use environment variables and Vite's config function form, which receives the mode and lets you load `.env` values:

```javascript
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const backendPort = env.BACKEND_PORT || "8000";

  return {
    plugins: [react()],
    server: {
      port: 5173,
      proxy: {
        "/api": `http://127.0.0.1:${backendPort}`,
      },
    },
  };
});
```

Then set `BACKEND_PORT` in a `.env` file. Keep using `127.0.0.1` for the same IPv6-fallback reason described above.

---

## Question
Does this proxy configuration apply to the production build?

## Answer
No. The `server.proxy` setting **only affects the Vite dev server** (`vite dev`). It has no effect on the output of `vite build` or the static files served by `vite preview` in the same way.

In production, your relative `/api` requests must be routed to the backend by your actual deployment infrastructure — for example, a reverse proxy like Nginx, or serving the built frontend from the FastAPI app itself. Plan your production routing separately so that `/api/...` still resolves correctly.

---

## Question
What happens if I get a CORS error even with this proxy set up?

## Answer
If the proxy is working correctly, you generally **won't** hit CORS errors, because the browser sees all requests as same-origin (`localhost:5173`). CORS errors usually indicate one of these:

- You used an **absolute URL** (e.g., `http://127.0.0.1:8000/api/...`) instead of a relative one, bypassing the proxy.
- The dev server isn't actually running, or the request path doesn't start with `/api`.
- A misconfigured proxy prefix.

**Fix:** switch to relative URLs so requests flow through the proxy:

```javascript
fetch("/api/users/42/status"); // stays same-origin
```

If you must call the backend directly, you'd need to configure CORS on the FastAPI side instead — but using the proxy is the intended, simpler approach here.