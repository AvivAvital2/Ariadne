---
id: ece23bd0-b538-59cc-a2f9-dc87d97cc19f
type: qa
title: "Statcard FAQ"
created_at: 2026-07-30T17:28:28.483945+00:00
updated_at: 2026-07-30T17:28:28.483958+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx
metadata:
  module_name: "frontend.src.components.StatCard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Statcard FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx`

# StatCard Component FAQ

## Question
How do I use the `StatCard` component in its simplest form?

## Answer
At minimum, `StatCard` requires a `label` and a `value`. All other props are optional.

```jsx
import StatCard from "@/components/StatCard";

function Dashboard() {
  return <StatCard label="Total Users" value="1,204" />;
}
```

This renders the value prominently with a label beneath it. The `tone` defaults to `"primary"`, and no icon or hint is shown.

---

## Question
What props does `StatCard` accept, and which are required?

## Answer
The component accepts five props:

| Prop | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| `label` | string/node | Yes | — | Descriptive text shown below the value |
| `value` | string/node | Yes | — | The main statistic displayed prominently |
| `hint` | string/node | No | — | Optional supplementary text below the label |
| `tone` | string | No | `"primary"` | Style variant applied to the icon (via `tone-${tone}` class) |
| `icon` | component | No | — | A React component rendered as the card's icon |

Note that while `label` and `value` are conceptually required, the code does not enforce this—omitting them renders empty elements.

---

## Question
How do I add an icon to a StatCard?

## Answer
Pass a React component (not a rendered element) to the `icon` prop. Note the destructuring alias `icon: Icon`, which lets the component render it as `<Icon />`.

```jsx
import { Users } from "lucide-react";

<StatCard label="Active Users" value="842" icon={Users} />
```

The icon is rendered with a fixed `size={20}`:

```jsx
{Icon && <Icon size={20} />}
```

**Gotcha:** Pass the component reference (`Users`), not JSX (`<Users />`). Passing `<Users />` will break because the code calls it as a component with a `size` prop.

---

## Question
What does the `tone` prop control?

## Answer
The `tone` prop sets a CSS class on the icon wrapper in the form `tone-${tone}`. It's used for theming/coloring the icon area.

```jsx
<StatCard label="Errors" value="3" tone="danger" icon={AlertIcon} />
// renders: <div className="stat-icon tone-danger">...</div>
```

The actual visual result depends on your CSS. You must define styles for each tone you use, for example:

```css
.stat-icon.tone-primary { color: #2563eb; }
.stat-icon.tone-danger  { color: #dc2626; }
.stat-icon.tone-success { color: #16a34a; }
```

If you pass a `tone` value with no matching CSS class, the icon simply falls back to default styling.

---

## Question
How does the `hint` prop work, and when is it displayed?

## Answer
The `hint` is optional supplementary text rendered below the label. It only appears when a truthy value is passed, thanks to conditional rendering:

```jsx
{hint && <div className="stat-hint">{hint}</div>}
```

Example:

```jsx
<StatCard
  label="Revenue"
  value="$12,430"
  hint="+8% from last month"
/>
```

**Gotcha:** Because of the `&&` check, passing `hint={0}` would render `0` (a truthy-in-JSX edge case is avoided since `0` is falsy—it renders nothing). But passing an empty string `""` renders nothing, which is usually the desired behavior.

---

## Question
Can I pass JSX or numbers as the `value` and `label`?

## Answer
Yes. Both `value` and `label` are rendered directly as children, so they accept strings, numbers, or full JSX nodes.

```jsx
<StatCard
  label={<span>Growth <em>rate</em></span>}
  value={<>42<small>%</small></>}
/>
```

This flexibility lets you format currency, add units, or emphasize parts of the display. Just be mindful that complex nodes may need additional CSS to align correctly.

---

## Question
The icon isn't showing up. What's wrong?

## Answer
Common causes:

1. **You passed rendered JSX instead of a component.**
   ```jsx
   // Wrong
   <StatCard icon={<Users />} label="x" value="1" />
   // Correct
   <StatCard icon={Users} label="x" value="1" />
   ```

2. **The icon component doesn't accept a `size` prop.** The code always passes `size={20}`. If your icon ignores or errors on `size`, it may not render as expected. Wrap it in an adapter if needed:
   ```jsx
   const MyIcon = () => <img src="/icon.svg" width={20} />;
   <StatCard icon={MyIcon} label="x" value="1" />
   ```

3. **No icon prop passed.** The icon area (`stat-icon`) still renders as an empty div due to `{Icon && ...}`, which may create visible spacing depending on your CSS.

---

## Question
How do I render a grid of StatCards?

## Answer
`StatCard` is a self-contained presentational component—compose multiple instances in a container and use CSS for layout.

```jsx
const stats = [
  { label: "Users", value: "1,204", tone: "primary", icon: Users },
  { label: "Revenue", value: "$12k", tone: "success", icon: DollarSign },
  { label: "Errors", value: "3", tone: "danger", icon: AlertIcon },
];

<div className="stat-grid">
  {stats.map((s) => (
    <StatCard key={s.label} {...s} />
  ))}
</div>
```

```css
.stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}
```

**Best practice:** Provide a stable `key` (like `label`) when mapping.

---

## Question
Is this component styled out of the box?

## Answer
No. `StatCard` provides only structure and semantic class names—it ships no styles. You must supply CSS for these classes:

- `.stat-card` — outer container
- `.stat-icon` and `.tone-*` — icon wrapper and tone variants
- `.stat-body` — text container
- `.stat-value` — the main statistic
- `.stat-label` — descriptive label
- `.stat-hint` — optional hint text

This separation keeps the component style-agnostic, letting it fit any design system. Without CSS, the card will render but appear unstyled.