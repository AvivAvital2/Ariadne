---
id: 4f996999-8334-5e8d-bf28-67a2147d3b1c
type: qa
title: "0001 Initial FAQ"
created_at: 2026-07-30T17:21:00.021585+00:00
updated_at: 2026-07-30T17:21:00.021600+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  module_name: "backend.alembic.versions.0001_initial"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# 0001 Initial FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

# FAQ: Initial Schema Migration (`0001_initial`)

## Question
What does this migration create, and how do I run it?

## Answer
This is the initial Alembic migration (`revision = "0001_initial"`, `down_revision = None`). It creates six tables:

- **`users`** — core user records
- **`roles`** — named roles
- **`permissions`** — named permissions
- **`user_roles`** — many-to-many association between users and roles
- **`role_permissions`** — many-to-many association between roles and permissions
- **`audit_log`** — records actions performed by users

To apply it, run:

```bash
# Apply all pending migrations up to the latest
alembic upgrade head

# Or apply just this revision explicitly
alembic upgrade 0001_initial
```

To roll it back (drops all six tables):

```bash
alembic downgrade base
```

---

## Question
Why is the `downgrade()` function dropping tables in a specific order?

## Answer
Tables are dropped in **reverse dependency order** so foreign key constraints don't block the drop:

```python
for table in (
    "audit_log",          # references users
    "role_permissions",   # references roles, permissions
    "user_roles",         # references users, roles
    "permissions",
    "roles",
    "users",              # dropped last (many tables reference it)
):
    op.drop_table(table)
```

A child table (one holding a foreign key) must be dropped before its parent. Since `user_roles`, `role_permissions`, and `audit_log` all reference `users`/`roles`/`permissions`, those parent tables come last. **Pitfall:** if you add a new table that references `users`, remember to drop it *before* `users` in this list, or the downgrade will fail on databases that enforce FK constraints.

---

## Question
Why do the timestamp columns (`created_at`, `updated_at`) not have a default value?

## Answer
Notice that unlike `full_name` or `status`, the timestamp columns are declared `nullable=False` with **no** `server_default`:

```python
sa.Column("created_at", sa.DateTime, nullable=False),
sa.Column("updated_at", sa.DateTime, nullable=False),
```

This means the database will **not** auto-populate them. Your application code is responsible for setting these values on every insert/update. If you insert a row without providing them, you'll get a `NOT NULL` violation. Two common approaches:

```python
from datetime import datetime, timezone

# Application-set (matches this schema)
user = User(username="alice", email="a@x.com",
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc))
```

If you'd prefer the DB to handle it, you'd need a later migration adding `server_default=sa.func.now()`.

---

## Question
What are the default values for optional-looking columns?

## Answer
Several columns are `nullable=False` but have `server_default` values, so you can omit them on insert and the database fills them in:

| Table | Column | Default |
|-------|--------|---------|
| `users` | `full_name` | `""` (empty string) |
| `users` | `status` | `"invited"` |
| `roles` | `description` | `""` |
| `permissions` | `description` | `""` |
| `audit_log` | `target_type` | `"user"` |
| `audit_log` | `detail` | `""` |

Note that new users start in the `"invited"` status by default. **Gotcha:** `server_default` is applied by the database, not by SQLAlchemy's Python layer. When you create an ORM object in memory without setting these fields, the attribute may be `None` until the row is flushed and refreshed from the DB.

---

## Question
How are the many-to-many relationships modeled?

## Answer
Through two association tables using **composite primary keys** made of two foreign keys:

```python
op.create_table(
    "user_roles",
    sa.Column("user_id", sa.Integer, sa.ForeignKey("users.id"), primary_key=True),
    sa.Column("role_id", sa.Integer, sa.ForeignKey("roles.id"), primary_key=True),
)
```

Because both columns form the primary key, the pair `(user_id, role_id)` must be unique — a user can't be assigned the same role twice. The same pattern applies to `role_permissions` with `(role_id, permission_id)`. This gives you a standard RBAC structure: **users → roles → permissions**.

---

## Question
Which columns are indexed, and why does that matter?

## Answer
The migration explicitly creates three indexes:

```python
op.create_index("ix_users_username", "users", ["username"])
op.create_index("ix_audit_log_action", "audit_log", ["action"])
op.create_index("ix_audit_log_created_at", "audit_log", ["created_at"])
```

These optimize common query patterns:
- **`ix_users_username`** — fast user lookups by username (e.g., login)
- **`ix_audit_log_action`** — filtering audit records by action type
- **`ix_audit_log_created_at`** — time-range queries and ordering the audit log

Note that `unique=True` columns (like `users.email`, `roles.name`, `permissions.name`) automatically get a backing unique index from the database, so no separate `create_index` call is needed for them.

---

## Question
Why is `actor_id` in `audit_log` nullable but `action` is not?

## Answer
```python
sa.Column("actor_id", sa.Integer, sa.ForeignKey("users.id"), nullable=True),
sa.Column("action", sa.String(64), nullable=False),
sa.Column("target_id", sa.Integer, nullable=True),
```

`actor_id` is nullable to represent **system-generated events** where no specific user performed the action (e.g., automated cleanup jobs). Similarly, `target_id` is nullable for actions that don't target a specific entity. `action`, however, is always required — every audit entry must record *what* happened. Note that `target_id` has no foreign key constraint since the target could be any entity type (indicated by `target_type`).

---

## Question
How do I add a new column or table on top of this schema?

## Answer
**Never edit this migration file** once it has been applied in any shared or production environment — Alembic tracks applied revisions by ID, and changing an applied migration causes drift. Instead, generate a new migration:

```bash
# Autogenerate based on model changes
alembic revision --autogenerate -m "add phone to users"

# Or create an empty migration to edit manually
alembic revision -m "add phone to users"
```

The new file will have `down_revision = "0001_initial"`, chaining it after this one. Inside its `upgrade()`:

```python
def upgrade() -> None:
    op.add_column("users", sa.Column("phone", sa.String(32), nullable=True))

def downgrade() -> None:
    op.drop_column("users", "phone")
```

---

## Question
The migration fails partway through — what happens to already-created tables?

## Answer
This depends on your database's DDL transaction support:

- **PostgreSQL** supports transactional DDL, so if `upgrade()` fails midway, the whole migration is rolled back and no tables persist. You can fix the issue and re-run cleanly.
- **MySQL/MariaDB** do **not** support transactional DDL. A failure partway through leaves earlier tables (e.g., `users`, `roles`) created while later ones aren't. You must manually drop the partial tables (or run `alembic downgrade` carefully) before retrying.

**Best practice:** always test migrations against the same database engine you use in production, and take a backup before running migrations in production.

---

## Question
How can I verify the schema was created correctly after running the migration?

## Answer
Check the current revision and inspect the tables:

```bash
# Confirm Alembic thinks 0001_initial is applied
alembic current
# -> 0001_initial (head)

# Inspect the actual database (example for PostgreSQL)
psql mydb -c "\dt"        # list tables
psql mydb -c "\d users"   # describe the users table
```

You should see all six tables plus the three named indexes. If `alembic current` shows nothing, the migration hasn't been applied — run `alembic upgrade head`.