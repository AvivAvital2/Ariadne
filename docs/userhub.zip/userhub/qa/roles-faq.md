---
id: c6e1d01f-226e-5e63-ada5-3f3b1086e707
type: qa
title: "Roles FAQ"
created_at: 2026-07-30T17:25:40.525041+00:00
updated_at: 2026-07-30T17:25:40.525054+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  module_name: "backend.app.services.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles FAQ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

# Role and Permission Queries — FAQ

This module (`backend.app.services.roles`) provides service-layer functions for querying and managing roles and permissions. Below are common questions developers ask when working with it.

---

## Question
How do I list all available roles?

## Answer
Use `list_roles`, passing a SQLAlchemy `Session`. Roles are returned sorted alphabetically by name.

```python
from app.services.roles import list_roles

def get_all_roles(db):
    roles = list_roles(db)
    for role in roles:
        print(role.name, role.description)
    return roles
```

The function returns a `list[Role]`. If there are no roles, it returns an empty list rather than raising an error.

---

## Question
How do I fetch a single role by its ID?

## Answer
Use `get_role` with the role's integer ID. Note that this function **raises an `HTTPException` with status 404** if no matching role exists — it does not return `None`.

```python
from app.services.roles import get_role

role = get_role(db, role_id=5)  # raises 404 if not found
```

Because it raises an `HTTPException`, this function is designed to be called directly inside a FastAPI route. If you need "look up but don't fail" behavior, use `db.get(Role, role_id)` directly and handle `None` yourself.

---

## Question
How do I create a new role and assign permissions to it?

## Answer
Use `create_role`. Note the arguments after `db` are **keyword-only** (due to the `*` in the signature), so you must pass them by name.

```python
from app.services.roles import create_role

role = create_role(
    db,
    name="editor",
    description="Can edit content",
    permission_ids=[1, 2, 3],
)
```

The function creates the role, associates the given permissions, commits the transaction, and returns the refreshed `Role` object.

---

## Question
What happens if I try to create a role with a name that already exists?

## Answer
`create_role` checks for an existing role with the same name and raises an `HTTPException` with status **409 Conflict**:

```python
if db.query(Role).filter(Role.name == name).first() is not None:
    raise HTTPException(status_code=409, detail="role already exists")
```

**Pitfall:** This check is not race-safe. Under concurrent requests, two callers could pass the check simultaneously and both attempt to insert. For guaranteed uniqueness, add a `UNIQUE` constraint on `Role.name` at the database level and catch the resulting `IntegrityError`.

---

## Question
Can I create a role without any permissions?

## Answer
Yes. Pass an empty list for `permission_ids`:

```python
role = create_role(
    db,
    name="viewer",
    description="Read-only access",
    permission_ids=[],
)
```

The permission assignment block is skipped when `permission_ids` is empty (`if permission_ids:`), so the role is created with no permissions attached.

---

## Question
What happens if I pass permission IDs that don't exist?

## Answer
Invalid IDs are **silently ignored**. The function fetches permissions using `Permission.id.in_(permission_ids)`, which only returns rows that actually exist:

```python
role.permissions = (
    db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
)
```

If you pass `[1, 2, 999]` and permission `999` doesn't exist, the role will be created with only permissions `1` and `2` — no error is raised.

**Best practice:** If you need to guarantee all requested permissions exist, validate the count before or after fetching:

```python
found = db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
if len(found) != len(set(permission_ids)):
    raise HTTPException(status_code=400, detail="one or more permissions not found")
```

---

## Question
How do I list all available permissions?

## Answer
Use `list_permissions`, which returns all permissions sorted by name:

```python
from app.services.roles import list_permissions

permissions = list_permissions(db)
```

This is commonly used to populate a selection UI so users can pick which permission IDs to pass into `create_role`.

---

## Question
How should I wire these functions into FastAPI routes?

## Answer
These are service-layer functions and expect a `Session` as the first argument. Inject the session via a dependency and pass it through:

```python
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.services import roles

router = APIRouter()

@router.get("/roles")
def read_roles(db: Session = Depends(get_db)):
    return roles.list_roles(db)

@router.get("/roles/{role_id}")
def read_role(role_id: int, db: Session = Depends(get_db)):
    return roles.get_role(db, role_id)  # 404 propagates automatically

@router.post("/roles")
def add_role(name: str, description: str, permission_ids: list[int],
             db: Session = Depends(get_db)):
    return roles.create_role(
        db, name=name, description=description, permission_ids=permission_ids
    )
```

Because `get_role` and `create_role` already raise `HTTPException`, those errors surface to clients as proper HTTP responses without extra handling.

---

## Question
Do I need to commit the transaction myself after calling these functions?

## Answer
It depends on the function:

- **`create_role`** commits internally (`db.commit()` and `db.refresh(role)`), so the change is persisted before it returns.
- **`list_roles`, `get_role`, `list_permissions`** are read-only and perform no commits.

**Pitfall:** Because `create_role` commits eagerly, you cannot easily bundle it into a larger transaction that you roll back later. If you need transactional composition (e.g. create a role *and* something else atomically), consider refactoring to remove the internal commit and let the caller control the transaction boundary.

---

## Question
Why does `get_role` raise an exception instead of returning `None`?

## Answer
This is a deliberate design choice for the service layer: raising `HTTPException(404)` lets FastAPI translate a missing resource into a proper HTTP 404 response automatically, keeping route handlers clean.

The trade-off is that these functions are **tightly coupled to the web layer**. If you want to reuse them in a non-HTTP context (background jobs, CLI tools), the `HTTPException` may be inappropriate. In that case, use lower-level queries (`db.get(Role, role_id)`) directly and apply your own error handling.