# Ariadne Library

This directory contains exported documentation from the Ariadne library.

## Contents

Total documents: 435

- **Architecture** (41): [architecture/](architecture/)
- **Catalog** (231): [other/](other/)
- **Diagram** (40): [diagrams/](diagrams/)
- **Explanation** (43): [explanations/](explanations/)
- **Gotcha** (40): [other/](other/)
- **Qa** (40): [qa/](qa/)

## Structure

- `manifest.yaml` - Index of all documents with metadata
- `INDEX.md` - Full document index with status info
- `explanations/` - How things work in the codebase
- `architecture/` - System design and component relationships
- `qa/` - Questions and answers about the codebase
- `diagrams/` - Visual diagrams (Graphviz DOT)
- `findings/` - Session discoveries and conclusions

## Usage

These documents can be read directly or searched using Ariadne.

```python
import ariadne

library = ariadne.Library(Path("ariadne.db"))
results = library.search(query_embedding, k=5)
```
