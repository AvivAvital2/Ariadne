---
id: 702ee9ad-e28b-5754-bd86-f639bd90e28c
type: catalog
title: "backend.app.seed.alice"
created_at: 2026-07-30T15:09:16.252865+00:00
updated_at: 2026-07-30T17:48:08.781527+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.alice"
  signature: "alice = User("
  location: {'line_start': 65, 'line_end': 71, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "898e2182df7efafd8412c9da11d19636f7f1068b71551a305123f68202d85e7b"
  description: "Creates a `User` instance named "alice" used as seed data for populating the database."
---
# backend.app.seed.alice

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.alice [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:65-71 :: alice = User(

Description: Creates a `User` instance named "alice" used as seed data for populating the database.

## Related Documents

- [backend.app.seed.bob](1c3620a3-bfc3-5c36-b44e-d470e854d85d.md) - Related (graph distance 1.34)
- [backend.app.seed.root](18365c02-cf65-5a40-bfe4-a549d2319780.md) - Related (graph distance 1.37)
- [backend.app.seed.admin](4041d0d9-ff75-570f-9dd0-77920e758db4.md) - Related (graph distance 2.89)
