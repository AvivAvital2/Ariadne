---
id: 9dd890a0-c2ff-5771-a45e-bd8921869fac
type: catalog
title: "backend.app.schemas.UserCreate.username"
created_at: 2026-07-30T15:09:16.667743+00:00
updated_at: 2026-07-30T17:48:08.793721+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserCreate.username"
  signature: "username: str"
  location: {'line_start': 36, 'line_end': 36, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "backend.app.schemas.UserCreate"
  sha_at_sync: "a3b20fa634e0641ba74db0d45453059c90e29c0cc808ed99ee785150a3a81b29"
  description: "Defines the required username field as a string for the `UserCreate` schema, used when creating a new user."
---
# backend.app.schemas.UserCreate.username

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserCreate.username in backend.app.schemas.UserCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:36-36 :: username: str

Description: Defines the required username field as a string for the `UserCreate` schema, used when creating a new user.

## Related Documents

- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.21)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 1.27)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 1.33)
- [backend.app.models.User.username](e6944542-0f4c-5b3c-854a-1b1143cba0f7.md) - Related (graph distance 1.35)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.42)
- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 2.50)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 2.50)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.51)
