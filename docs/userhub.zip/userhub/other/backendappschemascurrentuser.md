---
id: c9f0033d-65ba-5095-b1f7-46936148c59a
type: catalog
title: "backend.app.schemas.CurrentUser"
created_at: 2026-07-30T15:09:16.662797+00:00
updated_at: 2026-07-30T17:48:08.788391+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.CurrentUser"
  signature: "class CurrentUser(BaseModel):"
  location: {'line_start': 72, 'line_end': 83, 'col_start': 0, 'col_end': 31}
  parent_qualified_name: None
  sha_at_sync: "c7adcd47a052180780523e442c3e5050bed5e6cadf3d0a617a5fded0ef2b442d"
  description: "A Pydantic model representing the authenticated user's identity and authorization context, typically derived from a validated access token. It carries the essential user information (such as ID, roles, or permissions) used to enforce access control across request handlers."
---
# backend.app.schemas.CurrentUser

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.CurrentUser [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:72-83 :: class CurrentUser(BaseModel):

Description: A Pydantic model representing the authenticated user's identity and authorization context, typically derived from a validated access token. It carries the essential user information (such as ID, roles, or permissions) used to enforce access control across request handlers.

## Related Documents

- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.50)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 1.54)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 1.54)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.55)
- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.76)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.80)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 2.84)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.86)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 2.86)
