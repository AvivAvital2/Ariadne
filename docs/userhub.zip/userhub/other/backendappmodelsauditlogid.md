---
id: b0501eb7-823a-5277-8ef4-9b9ccac8b468
type: catalog
title: "backend.app.models.AuditLog.id"
created_at: 2026-07-30T15:09:15.725798+00:00
updated_at: 2026-07-30T17:48:08.771081+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.id"
  signature: "id: Mapped[int] = mapped_column(primary_key=True)"
  location: {'line_start': 85, 'line_end': 85, 'col_start': 4, 'col_end': 53}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "06b4f0bf94a32745f665ce92f1d2852aaa070fb664bc0d80af2423523af921b2"
  description: "Defines the primary key column for the `AuditLog` model, storing a unique integer identifier for each audit log record."
---
# backend.app.models.AuditLog.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.id in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:85-85 :: id: Mapped[int] = mapped_column(primary_key=True)

Description: Defines the primary key column for the `AuditLog` model, storing a unique integer identifier for each audit log record.

## Related Documents

- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.23)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 1.25)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 1.27)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 1.27)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.34)
- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.34)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.51)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.51)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 2.51)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 2.52)
