---
id: 8f481f9b-4fec-51be-a015-14ccd2d628c2
type: catalog
title: "backend.app.schemas.UserActivityRow"
created_at: 2026-07-30T15:09:16.663340+00:00
updated_at: 2026-07-30T17:48:08.789289+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.UserActivityRow"
  signature: "class UserActivityRow(BaseModel):"
  location: {'line_start': 97, 'line_end': 104, 'col_start': 0, 'col_end': 35}
  parent_qualified_name: None
  sha_at_sync: "8fc45e5c4866b72a98ec273ca5b1bb07663cd6c3ff66441c55f68d82f5ae2745"
  description: "A Pydantic model representing a single row of user activity data, used for validating and serializing user activity records."
---
# backend.app.schemas.UserActivityRow

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.UserActivityRow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:97-104 :: class UserActivityRow(BaseModel):

Description: A Pydantic model representing a single row of user activity data, used for validating and serializing user activity records.

## Related Documents

- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 1.54)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.60)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 1.61)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.81)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 2.84)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.84)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.86)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 2.86)
