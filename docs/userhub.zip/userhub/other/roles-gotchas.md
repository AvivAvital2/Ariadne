---
id: bff6f997-a6f6-5e46-8484-4c9f77721aa2
type: gotcha
title: "Roles Gotchas"
created_at: 2026-07-30T17:24:00.668875+00:00
updated_at: 2026-07-30T17:24:00.668888+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  module_name: "backend.app.routers.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

# Gotchas & Pitfalls: `backend.app.routers.roles`

### Permission mismatch: reading roles requires USERS_READ, not ROLES_READ
**Trigger:** `list_roles` is guarded by `Permission.USERS_READ`, while `list_permissions` and `create_role` use `ROLES_MANAGE`. A user granted user-read access can enumerate all roles, which is likely unintended and inconsistent with the other role endpoints.
**Affected Files:** `backend/app/routers/roles.py`
**Fix:** Use a dedicated permission (e.g. `ROLES_READ`) or at minimum align to `ROLES_MANAGE`. Audit the permission taxonomy so listing roles isn't tied to user-management scope.
**Category:** domain
**Example:**
```python
# list_roles allows anyone with USERS_READ
actor: User = Depends(require_permission(Permission.USERS_READ.value)),
# but list_permissions requires the stricter ROLES_MANAGE
actor: User = Depends(require_permission(Permission.ROLES_MANAGE.value)),
```

---

### `require_permission(...)` is called at import time, not per request
**Trigger:** `require_permission(Permission.X.value)` is a factory that runs *once* when the module is imported to produce the dependency callable. If `require_permission` accidentally captures request-specific or mutable state at construction time, every request shares it.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/security.py`
**Fix:** Ensure `require_permission` only closes over the immutable permission string and returns a fresh dependency callable. Never cache DB sessions or user state inside the factory closure.
**Category:** framework
**Example:**
```python
# Evaluated at import/definition time:
Depends(require_permission(Permission.ROLES_MANAGE.value))
# If require_permission held onto a Session, all requests would collide.
```

---

### `Permission.X.value` — silent failure if enum member renamed
**Trigger:** Passing `.value` (a raw string) decouples the guard from the enum. If someone renames the enum member or changes its value, there is no type check — a stale string silently grants/denies nothing until runtime.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/constants.py`
**Fix:** Prefer passing the enum member directly (`require_permission(Permission.ROLES_MANAGE)`) and normalize inside `require_permission`, so mypy/refactors catch mismatches.
**Category:** type-system
**Example:**
```python
require_permission("roles:manage")  # typo compiles fine, blocks everyone
require_permission(Permission.ROLES_MANAGE.value)  # still a bare str downstream
```

---

### Sync `def` endpoints run in the threadpool — Session thread-safety
**Trigger:** These are plain `def` (not `async def`) endpoints, so FastAPI runs each in a worker thread. The SQLAlchemy `Session` from `get_db` must not be shared across requests/threads. If `get_db` ever yields a module-global or singleton session, concurrent requests corrupt each other.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/database.py`
**Fix:** Confirm `get_db` yields a fresh `Session` per request (scoped/factory) and closes it in `finally`. Never store the session on a shared object.
**Category:** thread-safety
**Example:**
```python
# Safe: new session per request
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()
# Dangerous: reused global would break under threadpool concurrency
```

---

### `create_role` does not handle duplicate names / invalid permission_ids
**Trigger:** The router passes `permission_ids` straight to the service. If a name already exists (unique constraint) or a permission id doesn't exist (FK violation), an unhandled `IntegrityError` surfaces as a 500 rather than a 400/409.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/services/roles.py`
**Fix:** Validate `permission_ids` exist and catch/translate `IntegrityError` into `HTTPException(409/400)` in the service or an exception handler.
**Category:** domain
**Example:**
```python
role_service.create_role(db, name=payload.name, ...)
# duplicate name -> IntegrityError -> 500 Internal Server Error
```

---

### `response_model=RoleOut` triggers lazy-load serialization after session close
**Trigger:** `RoleOut` likely serializes `permissions` (a relationship). Because the endpoint returns the ORM object, FastAPI serializes it *after* the function returns — but the `get_db` generator may have already closed the session, causing `DetachedInstanceError` on lazy attributes.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/schemas.py`, `backend/app/services/roles.py`
**Fix:** Eager-load relationships (`selectinload`/`joinedload`) in the service query, or return already-hydrated Pydantic models. Ensure `from_attributes=True` and no lazy access happens post-close.
**Category:** framework
**Example:**
```python
return role_service.list_roles(db)  # returns ORM Role objects
# RoleOut tries role.permissions later -> DetachedInstanceError if lazy
```

---

### N+1 query on `list_roles` / `list_permissions`
**Trigger:** If `RoleOut` includes nested permissions and the service returns a plain `Role` query, serializing each role fires a separate query for its permissions.
**Affected Files:** `backend/app/routers/roles.py`, `backend/app/services/roles.py`
**Fix:** Use `selectinload(Role.permissions)` in the service listing query.
**Category:** performance
**Example:**
```python
# 1 query for roles + N queries for each role's permissions
db.query(Role).all()
```

---

### `actor` is injected but unused — no audit / ownership check
**Trigger:** `actor` is bound purely to enforce permission via the dependency side effect and never referenced. This is easy to misread as "actor is validated for ownership." There is no per-object authorization (e.g., tenant scoping).
**Affected Files:** `backend/app/routers/roles.py`
**Fix:** If multi-tenant, pass `actor` into the service to scope roles. Otherwise document that this is intentionally global. Consider marking with `# noqa` or naming `_actor` to signal intent.
**Category:** domain
**Example:**
```python
actor: User = Depends(require_permission(...))  # only used for its side effect
return role_service.list_roles(db)  # no actor scoping
```

---

### Missing trailing-slash / route ordering ambiguity
**Trigger:** Routes are declared with full absolute paths (`/api/roles`) instead of a prefixed router. Mixing this style with a prefixed `APIRouter` elsewhere can cause double prefixes (`/api/api/roles`) or 307 redirects on trailing slashes.
**Affected Files:** `backend/app/routers/roles.py`, wherever `router` is `include_router`-ed
**Fix:** Use `APIRouter(prefix="/api")` consistently, and be aware FastAPI issues 307 redirects for slash mismatches (which can drop auth headers on some clients).
**Category:** framework
**Example:**
```python
router = APIRouter(tags=["roles"])  # no prefix here
@router.get("/api/roles")           # hardcoded prefix; check include_router(prefix=...)
```