---
id: 1c3620a3-bfc3-5c36-b44e-d470e854d85d
type: catalog
title: "backend.app.seed.bob"
created_at: 2026-07-30T15:09:16.253238+00:00
updated_at: 2026-07-30T17:48:08.781748+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.bob"
  signature: "bob = User("
  location: {'line_start': 72, 'line_end': 78, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "21e7f4cc47b8b3cb243936050a2c85db90d9f49750222eeab329de450b3badce"
  description: "Creates a `User` instance named "bob" for seeding the database with initial user data."
---
# backend.app.seed.bob

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.bob [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:72-78 :: bob = User(

Description: Creates a `User` instance named "bob" for seeding the database with initial user data.

## Related Documents

- [backend.app.seed.root](18365c02-cf65-5a40-bfe4-a549d2319780.md) - Related (graph distance 1.29)
- [backend.app.seed.alice](702ee9ad-e28b-5754-bd86-f639bd90e28c.md) - Related (graph distance 1.34)
- [backend.app.seed.admin](4041d0d9-ff75-570f-9dd0-77920e758db4.md) - Related (graph distance 2.81)
