---
id: f696310c-6a08-502b-aedf-708a4e65f64b
type: gotcha
title: "Main Gotchas"
created_at: 2026-07-30T17:21:53.735602+00:00
updated_at: 2026-07-30T17:21:53.735621+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  module_name: "backend.app.main"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Main Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`

# Gotchas and Pitfalls: `backend.app.main`

### Blocking synchronous DB calls in async lifespan
**Trigger:** The `lifespan` handler is `async`, but `Base.metadata.create_all(engine)`, `SessionLocal()`, `seed_if_empty(db)`, and `db.close()` are all synchronous, blocking calls executed directly in the event loop coroutine.
**Affected Files:** `app/main.py`, `app/database.py`, `app/seed.py`
**Fix:** For startup this is usually acceptable (nothing else runs concurrently during boot), but if seeding is slow it stalls the loop. Wrap in `await anyio.to_thread.run_sync(...)` or use an async engine/session if the DB driver supports it. At minimum, be aware this is not actually async.
**Category:** async
**Example:**
```python
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)  # blocks the event loop
    db = SessionLocal()               # sync session in async context
```

### `create_all` silently skips changed schemas (false idempotency)
**Trigger:** The docstring claims "idempotent," but `create_all` only creates tables that **do not exist**. It never migrates. If you change a model's columns, the old table persists unmodified and the app silently runs against a stale schema.
**Affected Files:** `app/main.py`, `app/database.py`
**Fix:** Use Alembic migrations for anything beyond throwaway/first-run dev. Don't rely on `create_all` for schema evolution.
**Category:** framework
**Example:**
```python
# Add a column to a model, restart -> table unchanged, no error, no new column
Base.metadata.create_all(engine)
```

### Session leak if `seed_if_empty` raises before the try
**Trigger:** `db = SessionLocal()` is outside the `try`. It won't leak (assignment can't fail meaningfully), but any exception inside `seed_if_empty` propagates out of `lifespan`, which **aborts application startup entirely**. There's no logging/graceful handling.
**Affected Files:** `app/main.py`, `app/seed.py`
**Fix:** Wrap seeding in try/except with logging, and decide whether startup should fail hard. Also consider a transaction rollback on error.
**Category:** framework
**Example:**
```python
db = SessionLocal()
try:
    if seed_if_empty(db):  # raises -> whole app fails to boot
        ...
finally:
    db.close()  # rollback never called on partial seed
```

### No `commit`/`rollback` visible — depends on `seed_if_empty` internals
**Trigger:** The `finally` only calls `db.close()`. If `seed_if_empty` adds objects but doesn't commit, the changes are discarded silently on close. Conversely, if it commits and then partially fails, no rollback happens here.
**Affected Files:** `app/main.py`, `app/seed.py`
**Fix:** Ensure `seed_if_empty` owns its transaction fully, or add explicit `db.commit()`/`db.rollback()` in the lifespan `try/except/finally`.
**Category:** framework
**Example:**
```python
try:
    seed_if_empty(db)  # who commits? must verify
finally:
    db.close()  # SQLAlchemy default: uncommitted work rolled back
```

### `print` instead of structured logging
**Trigger:** The seed message uses `print(...)`. Under uvicorn/gunicorn with log configuration, `print` output may be buffered, unordered relative to log lines, or lost entirely in some deployment setups.
**Affected Files:** `app/main.py`
**Fix:** Use `logging.getLogger(__name__).info(...)`.
**Category:** framework
**Example:**
```python
print("UserHub: seeded ...")  # bypasses logging config, may be buffered
```

### CORS misconfiguration: no `allow_credentials` but comment implies open
**Trigger:** The comment says "CORS is left open," but `allow_origins` is restricted to a single origin and `allow_credentials` is unset (defaults to `False`). Cookie/auth-based cross-origin requests will silently fail. Also, `allow_methods=["*"]` combined with credentials would be rejected by browsers per spec.
**Affected Files:** `app/main.py`
**Fix:** Align the config with intent. If credentials are needed, set `allow_credentials=True` and list explicit origins (wildcard `*` is invalid with credentials).
**Category:** framework
**Example:**
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # only one origin, not "open"
    # allow_credentials defaults to False -> cookies dropped
)
```

### Router prefix inconsistency risk with `/api/health`
**Trigger:** `health` is hardcoded at `/api/health` while routers are included without a prefix here — meaning each router must independently define its `/api` prefix. Easy to end up with `/users` vs `/api/users` mismatches that the Vite proxy (`/api` → backend) won't route.
**Affected Files:** `app/main.py`, `app/routers/*.py`
**Fix:** Centralize the prefix: `app.include_router(users.router, prefix="/api")` or use an `APIRouter(prefix="/api")` mount for all routes including health.
**Category:** framework
**Example:**
```python
app.include_router(users.router)   # prefix defined inside router — must remember /api
@app.get("/api/health")            # prefix hardcoded here, inconsistent source of truth
```

### `SessionLocal()` thread/engine assumptions at startup
**Trigger:** If `engine` is SQLite with default connection args, `create_all` and the seed session run on the startup thread. Later request handlers run on different threads/tasks. SQLite requires `check_same_thread=False` for cross-thread use; a mismatch causes runtime errors only under load, not at boot.
**Affected Files:** `app/main.py`, `app/database.py`
**Fix:** Verify the engine's connection args in `app/database.py` (e.g. `connect_args={"check_same_thread": False}` for SQLite) and confirm the pooling strategy suits the deployment.
**Category:** thread-safety
**Example:**
```python
db = SessionLocal()  # created on startup thread; fine here,
                     # but reveals nothing about per-request thread safety
```

### Global `app` and `engine` shared across workers
**Trigger:** Running under `--workers N` (multiple processes) means the lifespan bootstrap runs once **per worker**, each racing to `create_all`/seed the same DB. `seed_if_empty`'s emptiness check is a classic check-then-act race.
**Affected Files:** `app/main.py`, `app/seed.py`
**Fix:** Make seeding safe under concurrency (advisory lock, `INSERT ... ON CONFLICT`, or run migrations/seeding as a separate one-shot step before starting workers).
**Category:** thread-safety
**Example:**
```python
if seed_if_empty(db):  # two workers both see "empty" -> double seed / IntegrityError
```

### Return type annotation is looser than reality
**Trigger:** `health` is annotated `-> dict[str, str]` but FastAPI serializes the return through a response model / JSON encoder; the annotation is not enforced as a Pydantic `response_model`. Returning a non-`str` value would pass type checkers loosely and only surface at serialization time.
**Affected Files:** `app/main.py`
**Fix:** If you want validation, set `response_model` explicitly; otherwise understand the annotation is documentation-only for FastAPI here.
**Category:** type-system
**Example:**
```python
@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}  # annotation not used as response_model validation
```