---
id: b77b11e2-3396-5864-bbf1-17a3948b6a1b
type: catalog
title: "backend.app.seed.events"
created_at: 2026-07-30T15:09:16.253978+00:00
updated_at: 2026-07-30T17:18:52.883909+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.events"
  signature: "events = ["
  location: {'line_start': 92, 'line_end': 111, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "c05edc4d9e88ed6eebd86674b6084bf576ab45fbe48951ff893912ad9ce726eb"
  description: "Defines a list of seed event records used to populate the database with initial event data."
---
# backend.app.seed.events

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.events [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:92-111 :: events = [

Description: Defines a list of seed event records used to populate the database with initial event data.