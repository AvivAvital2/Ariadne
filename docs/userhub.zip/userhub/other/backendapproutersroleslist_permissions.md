---
id: d5754e3b-76b3-5ef8-a07e-49c372b236d4
type: catalog
title: "backend.app.routers.roles.list_permissions"
created_at: 2026-07-30T15:09:16.759141+00:00
updated_at: 2026-07-30T17:48:08.847695+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.roles.list_permissions"
  signature: "def list_permissions("
  location: {'line_start': 39, 'line_end': 43, 'col_start': 0, 'col_end': 44}
  parent_qualified_name: None
  sha_at_sync: "2b90cc5ae2a5c8d82768ab1cadb837207a7ff8ec5036b21e4fa8425c8d0c5a1b"
  description: "Retrieves and returns a list of all available permissions in the system."
---
# backend.app.routers.roles.list_permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

function backend.app.routers.roles.list_permissions [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py:39-43 :: def list_permissions(

Description: Retrieves and returns a list of all available permissions in the system.

## Related Documents

- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 1.23)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 1.42)
- [backend.app.services.roles.list_permissions](c0635854-e157-5ed0-836c-3317d08ec451.md) - Related (graph distance 1.46)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.58)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 1.59)
- [backend.app.routers.audit.list_audit](de42e7ba-8f21-5ff2-840f-f27e74b6f36a.md) - Related (graph distance 1.66)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 2.63)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 2.79)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.83)
- [backend.app.routers.users.assign_roles](c95f5b82-4808-5a02-b583-176903208b03.md) - Related (graph distance 2.87)
