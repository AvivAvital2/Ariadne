---
id: 3b2b2394-420d-56e1-9e50-c1b720053ffc
type: catalog
title: "backend.app.constants.Permission.USERS_DELETE"
created_at: 2026-07-30T15:09:15.960240+00:00
updated_at: 2026-07-30T17:48:08.777292+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.USERS_DELETE"
  signature: "USERS_DELETE = "users:delete""
  location: {'line_start': 37, 'line_end': 37, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "10f18e4d6453af21f1e3426a32e8e2f280989969b037c8980c63a98a47674c11"
  description: "Defines the permission string `"users:delete"` that authorizes deletion of user accounts within the application's permission system."
---
# backend.app.constants.Permission.USERS_DELETE

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.USERS_DELETE in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:37-37 :: USERS_DELETE = "users:delete"

Description: Defines the permission string `"users:delete"` that authorizes deletion of user accounts within the application's permission system.

## Related Documents

- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 1.16)
- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 1.18)
- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.18)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 1.22)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 1.50)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 1.62)
- [backend.app.constants.Permission.ROLES_MANAGE](1b8a72cf-eac9-5394-a8f2-b232a254db18.md) - Related (graph distance 1.65)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.56)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.66)
- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 2.71)
