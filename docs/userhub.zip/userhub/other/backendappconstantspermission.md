---
id: 1fc5f016-d81b-5263-8c7c-ee091ce31d55
type: catalog
title: "backend.app.constants.Permission"
created_at: 2026-07-30T15:09:15.956882+00:00
updated_at: 2026-07-30T17:48:08.775214+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.constants.Permission"
  signature: "class Permission(str, Enum):"
  location: {'line_start': 24, 'line_end': 39, 'col_start': 0, 'col_end': 29}
  parent_qualified_name: None
  sha_at_sync: "ccaf4eea29e7faa57022328198e7cae2b1900f2fcd4a374940366f71d75933f7"
  description: "Defines an enumeration of permission constants as string values, used to represent distinct access rights within the application. Inherits from both `str` and `Enum` to allow permissions to be treated as string values while maintaining enumeration semantics."
---
# backend.app.constants.Permission

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

class backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:24-39 :: class Permission(str, Enum):

Description: Defines an enumeration of permission constants as string values, used to represent distinct access rights within the application. Inherits from both `str` and `Enum` to allow permissions to be treated as string values while maintaining enumeration semantics.

## Related Documents

- [backend.app.models.Permission](0e7843d6-44d3-5ac2-9d8c-ee08801cc3ed.md) - Related (graph distance 1.56)
- [backend.app.constants.AuditAction](966803e2-fceb-5ae6-8492-3ddfcff173ef.md) - Related (graph distance 1.59)
- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 2.81)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 2.81)
