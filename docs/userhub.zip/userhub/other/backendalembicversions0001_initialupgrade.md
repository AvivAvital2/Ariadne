---
id: fcf102e4-3068-5d60-bf34-46f2bb03e75a
type: catalog
title: "backend.alembic.versions.0001_initial.upgrade"
created_at: 2026-07-30T15:09:16.336066+00:00
updated_at: 2026-07-30T17:48:08.782629+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.alembic.versions.0001_initial.upgrade"
  signature: "def upgrade() -> None:"
  location: {'line_start': 21, 'line_end': 76, 'col_start': 0, 'col_end': 75}
  parent_qualified_name: None
  sha_at_sync: "8c37f68bdba6d2015645ce00e592681d016320948e9bc5c1a8d9ab2bba39fef4"
  description: "Creates the initial database schema by defining tables and their columns, constraints, and indexes as part of an Alembic migration's forward operation."
---
# backend.alembic.versions.0001_initial.upgrade

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

function backend.alembic.versions.0001_initial.upgrade [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py:21-76 :: def upgrade() -> None:

Description: Creates the initial database schema by defining tables and their columns, constraints, and indexes as part of an Alembic migration's forward operation.

## Related Documents

- [backend.alembic.versions.0001_initial.downgrade](7caa85ab-7d0d-5a76-9e44-bdbceab2069d.md) - Related (graph distance 1.35)
