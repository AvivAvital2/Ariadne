---
id: db47489a-8912-513c-80b2-0b4486e000f8
type: gotcha
title: "App Gotchas"
created_at: 2026-07-30T17:26:31.485579+00:00
updated_at: 2026-07-30T17:26:31.485594+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx
metadata:
  module_name: "frontend.src.App"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# App Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/App.jsx`

# Gotchas and Pitfalls: `frontend.src.App`

### Child components mount before `actor` is loaded
**Trigger:** `getCurrentUser()` is async, so `actor` is `null` on first render. `UserList` and `RoleManager` receive `actor={null}` and must handle it. If they assume `actor` is populated (e.g. `actor.id`, `actor.role`), they will crash or make requests with undefined identity.
**Affected Files:** `App.jsx`, `UserList.jsx`, `RoleManager.jsx`, `Sidebar.jsx`, `Topbar.jsx`
**Fix:** Gate the authenticated views behind a loading/auth check, or render a spinner until `actor` resolves.
**Category:** async
**Example:**
```jsx
// null on first render, then populated after fetch resolves
{view === "users" && <UserList actor={actor} />}  // actor may be null

// Fix:
if (actor === null && !error) return <div>Loading…</div>;
```

### Unhandled fetch failure leaves app in a permanently broken state
**Trigger:** If `getCurrentUser()` fails, `error` is set but `actor` stays `null` forever. There is no retry, and authenticated views still render with `actor={null}`. The error banner shows but the app remains usable in a half-broken way.
**Affected Files:** `App.jsx`
**Fix:** Distinguish "loading", "error", and "ready" states explicitly; block content rendering on auth failure.
**Category:** async
**Example:**
```jsx
const [status, setStatus] = useState("loading"); // loading | error | ready
// on catch: setStatus("error"); on success: setStatus("ready")
if (status === "error") return <FatalError msg={error} />;
```

### `e.message` may be undefined for non-Error rejections
**Trigger:** `.catch((e) => setError(e.message))` assumes the rejection is an `Error`. If `api.getCurrentUser()` rejects with a string, a Response object, or a plain object, `e.message` is `undefined` and the error banner renders empty.
**Affected Files:** `App.jsx`, `api/client.js`
**Fix:** Normalize errors: `setError(e?.message ?? String(e))`.
**Category:** type-system
**Example:**
```jsx
.catch((e) => setError(e.message)) // undefined if e is a string or {code: 500}
```

### Race condition / state update after unmount
**Trigger:** The `useEffect` fetch has no cleanup. In StrictMode (dev) the effect runs twice, and if `App` unmounts before the promise resolves, `setActor`/`setError` fire on an unmounted component (or set stale state from a superseded request).
**Affected Files:** `App.jsx`
**Fix:** Use an `AbortController` or an `ignore` flag in cleanup.
**Category:** async
**Example:**
```jsx
useEffect(() => {
  let ignore = false;
  api.getCurrentUser()
    .then((u) => { if (!ignore) setActor(u); })
    .catch((e) => { if (!ignore) setError(e.message); });
  return () => { ignore = true; };
}, []);
```

### Invalid `view` value silently renders blank content
**Trigger:** `view` is a free-form string set via `setView` (passed to `Sidebar.onNavigate`). If any code sets an unknown key, every `view === "..."` check fails, the content area renders nothing, and `title` falls back to `""` — no error, just an empty screen.
**Affected Files:** `App.jsx`, `Sidebar.jsx`
**Fix:** Validate against `NAV` keys, or add a fallback/default branch.
**Category:** type-system
**Example:**
```jsx
const title = NAV.find((n) => n.key === view)?.label ?? ""; // silently empty
// add: {!NAV.some(n => n.key === view) && <NotFound />}
```

### Stale error persists across view changes
**Trigger:** `error` is set once and never cleared. If the initial user fetch fails, the error banner stays visible while the user navigates between all views, giving the impression each view is broken.
**Affected Files:** `App.jsx`
**Fix:** Clear `error` on navigation, or scope error to the relevant view.
**Category:** framework
**Example:**
```jsx
onNavigate={(v) => { setError(null); setView(v); }}
```

### No memoization of `NAV` — harmless here but a trap if extended
**Trigger:** `NAV` is a module-level constant (fine). But `NAV.find(...)` runs on every render. Trivial now, but if `onNavigate={setView}` were replaced with an inline handler, child components (`Sidebar`) would re-render every time due to new function identity.
**Affected Files:** `App.jsx`, `Sidebar.jsx`
**Fix:** Keep passing the stable `setView` reference directly (as done), or wrap composed handlers in `useCallback`.
**Category:** performance
**Example:**
```jsx
onNavigate={setView}                       // stable ✓
onNavigate={(v) => setView(v)}             // new fn each render ✗ (breaks memo)
```

### `Dashboard` and `AuditLog` are fully remounted on every tab switch
**Trigger:** Conditional rendering (`view === "x" && <Comp />`) unmounts the previous view completely. Any in-progress fetches or local state in `Dashboard`/`AuditLog`/`UserList` are discarded and re-fetched on each navigation, which can be expensive and flicker-prone.
**Affected Files:** `App.jsx`, all view components
**Fix:** If preserving state matters, keep components mounted and toggle visibility with CSS, or lift/cache their data.
**Category:** performance
**Example:**
```jsx
{view === "audit" && <AuditLog />} // full remount + refetch each switch
```