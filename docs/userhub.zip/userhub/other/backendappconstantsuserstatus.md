---
id: db33830c-c05a-542f-b06e-c6a56d283c7a
type: catalog
title: "backend.app.constants.UserStatus"
created_at: 2026-07-30T15:09:15.956413+00:00
updated_at: 2026-07-30T17:48:08.774454+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.constants.UserStatus"
  signature: "class UserStatus(str, Enum):"
  location: {'line_start': 13, 'line_end': 21, 'col_start': 0, 'col_end': 31}
  parent_qualified_name: None
  sha_at_sync: "9c55f73e3a730e2504ba9f2055bb6a56b19d96aebd5ed1226dcf2d1dfb20b67b"
  description: "Defines an enumeration of possible user account states (such as active, inactive, or suspended) as string-based values by inheriting from both `str` and `Enum`."
---
# backend.app.constants.UserStatus

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

class backend.app.constants.UserStatus [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:13-21 :: class UserStatus(str, Enum):

Description: Defines an enumeration of possible user account states (such as active, inactive, or suspended) as string-based values by inheriting from both `str` and `Enum`.

## Related Documents

- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 1.29)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 1.43)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 1.44)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 1.47)
- [backend.app.constants.UserStatus.INVITED](311be302-09f8-5cba-8f71-b5116945a393.md) - Related (graph distance 1.54)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.60)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.62)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 2.66)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 2.74)
- [backend.app.models.User.status](d889c49c-87ed-5f94-a9dd-4f102349b418.md) - Related (graph distance 2.78)
