---
id: 966803e2-fceb-5ae6-8492-3ddfcff173ef
type: catalog
title: "backend.app.constants.AuditAction"
created_at: 2026-07-30T15:09:15.957244+00:00
updated_at: 2026-07-30T17:48:08.774983+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.constants.AuditAction"
  signature: "class AuditAction(str, Enum):"
  location: {'line_start': 42, 'line_end': 54, 'col_start': 0, 'col_end': 38}
  parent_qualified_name: None
  sha_at_sync: "0983f562c29f53993975f9d8c95cf048ff28db5746957437c31f4fd0e5591eb8"
  description: "Defines an enumeration of string-valued constants representing distinct audit actions (such as create, update, or delete operations) for use in audit logging. Inherits from both `str` and `Enum` to allow the members to be used directly as strings."
---
# backend.app.constants.AuditAction

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

class backend.app.constants.AuditAction [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:42-54 :: class AuditAction(str, Enum):

Description: Defines an enumeration of string-valued constants representing distinct audit actions (such as create, update, or delete operations) for use in audit logging. Inherits from both `str` and `Enum` to allow the members to be used directly as strings.

## Related Documents

- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 1.53)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 1.54)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 1.59)
- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 1.61)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.69)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 2.78)
- [backend.app.constants.AuditAction.ROLE_REVOKED](941c3822-94ac-5358-a3bf-3f1ce80016d7.md) - Related (graph distance 2.88)
- [backend.app.constants.AuditAction.ROLE_ASSIGNED](acc30db8-b69c-5f6f-88d4-de745f572998.md) - Related (graph distance 2.95)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 3.03)
