---
id: 8404cebc-c22c-5680-94d8-d4193032178f
type: catalog
title: "backend.app.services.users.set_status"
created_at: 2026-07-30T15:09:17.212692+00:00
updated_at: 2026-07-30T17:48:08.851130+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.set_status"
  signature: "def set_status(db: Session, *, actor_id: int, user_id: int, status: str) -> User:"
  location: {'line_start': 104, 'line_end': 118, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "a17a2bd20ce5d18f7c73bbbbc423025de1c623bfcf939f38d8dec83cbca18ac5"
  description: "Updates the status of the user identified by `user_id` to the given `status` value, performed on behalf of `actor_id`, and returns the updated User object."
---
# backend.app.services.users.set_status

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.set_status [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:104-118 :: def set_status(db: Session, *, actor_id: int, user_id: int, status: str) -> User:

Description: Updates the status of the user identified by `user_id` to the given `status` value, performed on behalf of `actor_id`, and returns the updated User object.

## Related Documents

- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 1.37)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 1.37)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 1.43)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.64)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.64)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 2.82)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 2.82)
- [backend.app.services.users.query](d9f0755a-497e-52a9-be2e-4103bced037f.md) - Related (graph distance 2.82)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.82)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 2.91)
