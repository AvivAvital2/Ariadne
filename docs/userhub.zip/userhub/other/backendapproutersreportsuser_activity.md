---
id: 492fc0bf-e17c-5850-9da1-69030030a77d
type: catalog
title: "backend.app.routers.reports.user_activity"
created_at: 2026-07-30T15:09:16.803021+00:00
updated_at: 2026-07-30T17:48:08.848463+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.reports.user_activity"
  signature: "def user_activity("
  location: {'line_start': 22, 'line_end': 27, 'col_start': 0, 'col_end': 51}
  parent_qualified_name: None
  sha_at_sync: "70e24d76fb52b5b616b91d652d169ae47d0d7b6382825b685e343f3c8a6cad59"
  description: "Retrieves and returns user activity report data through the reports router endpoint."
---
# backend.app.routers.reports.user_activity

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

function backend.app.routers.reports.user_activity [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py:22-27 :: def user_activity(

Description: Retrieves and returns user activity report data through the reports router endpoint.

## Related Documents

- [backend.app.routers.reports.rows](4b359aa5-d274-546c-91c8-7dedc3ea04e0.md) - Related (graph distance 1.55)
- [backend.app.reports.queries.USER_ACTIVITY_SQL](2b8ff6bd-7e2e-516d-b78c-1d495af079c3.md) - Related (graph distance 3.06)
