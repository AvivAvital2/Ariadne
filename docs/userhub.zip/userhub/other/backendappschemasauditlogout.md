---
id: 6e6767f4-fae6-512e-a9bf-fdd8f6b39d44
type: catalog
title: "backend.app.schemas.AuditLogOut"
created_at: 2026-07-30T15:09:16.663071+00:00
updated_at: 2026-07-30T17:48:08.788727+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.AuditLogOut"
  signature: "class AuditLogOut(BaseModel):"
  location: {'line_start': 86, 'line_end': 94, 'col_start': 0, 'col_end': 24}
  parent_qualified_name: None
  sha_at_sync: "62f1cf521d7d84014084f76496748bfd719741be18fa8cc0e52984172fa01589"
  description: "Pydantic response schema representing an audit log entry returned by the API. Serializes audit log data (such as recorded actions and metadata) for output in API responses."
---
# backend.app.schemas.AuditLogOut

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:86-94 :: class AuditLogOut(BaseModel):

Description: Pydantic response schema representing an audit log entry returned by the API. Serializes audit log data (such as recorded actions and metadata) for output in API responses.

## Related Documents

- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.41)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 1.41)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 1.46)
- [backend.app.models.AuditLog](9ed8286b-7e90-5043-bf34-7c16096cb903.md) - Related (graph distance 1.56)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 1.59)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 2.78)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.79)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 2.81)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 2.82)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.84)
