---
id: 19fd4467-07a0-5702-a5c6-2d45cdd2228b
type: gotcha
title: "Sidebar Gotchas"
created_at: 2026-07-30T17:28:25.573217+00:00
updated_at: 2026-07-30T17:28:25.573231+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx
metadata:
  module_name: "frontend.src.components.Sidebar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Sidebar Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Sidebar.jsx`

# Gotchas and Pitfalls: `Sidebar` Component

### Missing icons silently disappear
**Trigger:** An `item.key` doesn't match any key in the `ICONS` map (typo, new nav item without a registered icon, or backend-driven keys).
**Affected Files:** `frontend/src/components/Sidebar.jsx`, `frontend/src/components/Icons.jsx`
**Fix:** Provide a fallback icon, or log a dev warning when `ICONS[item.key]` is undefined so missing mappings are caught early.
**Category:** framework
**Example:**
```javascript
const Icon = ICONS[item.key]; // undefined for unknown keys
{Icon && <Icon size={18} />}  // no icon rendered, no error, no warning
```

### `initials()` breaks on non-string usernames
**Trigger:** `actor.username` is a number, object, or otherwise not a string. `.slice()` doesn't exist on numbers/objects, throwing a runtime error. Note that `name || "?"` only guards against falsy values, not wrong types.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Coerce to string first: `String(name || "?")`.
**Category:** type-system
**Example:**
```javascript
initials(12345);        // "12" — works accidentally? No: Number has no .slice → TypeError
initials("");           // "?" — falsy fallback works
initials(null);         // "?" — works
initials({ id: 1 });    // "[O" — [object Object] sliced, ugly but no crash
```

### Empty-string `active` matches empty `item.key`
**Trigger:** Both `active` and some `item.key` are `""` or both `undefined`. `undefined === undefined` is `true`, so an item with no key becomes "active" unexpectedly.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Validate that `item.key` is always a non-empty string, or guard the comparison: `active != null && item.key === active`.
**Category:** type-system
**Example:**
```javascript
// items = [{ key: undefined, label: "X" }], active = undefined
item.key === active // true → wrong item highlighted
```

### Non-unique or missing `item.key` causes React reconciliation bugs
**Trigger:** `key` is used both as the React list key AND as the navigation identifier. Duplicate keys cause React warnings and incorrect DOM reuse; missing keys break click routing.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Ensure `item.key` is guaranteed unique at the data source, or separate the React `key` (index/id) from the semantic nav key.
**Category:** framework
**Example:**
```javascript
key={item.key} // if two items share "users", React reuses wrong node & onNavigate collides
```

### `onNavigate` assumed to always exist
**Trigger:** Component is rendered without an `onNavigate` prop. Clicking a button calls `onNavigate(item.key)` → `undefined is not a function`.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Default the prop (`onNavigate = () => {}`) or guard the call (`onClick={() => onNavigate?.(item.key)}`).
**Category:** framework
**Example:**
```javascript
<Sidebar items={items} active="dashboard" /> // no onNavigate
// click → TypeError: onNavigate is not a function
```

### `items` assumed to be a non-null array
**Trigger:** `items` is `undefined`, `null`, or an object. `items.map` throws on the initial render before data loads (common in async data-fetch scenarios).
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Default the prop (`items = []`) or guard (`(items ?? []).map(...)`).
**Category:** framework
**Example:**
```javascript
// during loading: <Sidebar items={data?.nav} .../>  data undefined
items.map(...) // TypeError: Cannot read properties of undefined
```

### Buttons default to `type="submit"`
**Trigger:** If the Sidebar is ever nested inside a `<form>`, these `<button>` elements without an explicit `type` default to `type="submit"` and will submit/reload the form on click.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Add `type="button"` to each nav button.
**Category:** framework
**Example:**
```javascript
<button className="nav-item" onClick={...}> // defaults to submit inside a form
```

### `full_name` falsy fallback hides legitimate empty display intent
**Trigger:** `actor.full_name` is `""` or `0` → falls back to `username`. Usually fine, but a user with full_name intentionally blank or a numeric name (unlikely) silently changes displayed value.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Use nullish coalescing if you only want to fall back on null/undefined: `actor.full_name ?? actor.username`.
**Category:** type-system
**Example:**
```javascript
{actor.full_name || actor.username} // full_name="" shows username
```

### Missing accessibility state on active button
**Trigger:** The active nav item is styled with a CSS class only. Screen readers get no indication of the current page.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** Add `aria-current={item.key === active ? "page" : undefined}`.
**Category:** framework
**Example:**
```javascript
<button className={`nav-item ${item.key === active ? "active" : ""}`}> // no aria-current
```

### Inline arrow functions recreated each render
**Trigger:** `onClick={() => onNavigate(item.key)}` creates a new function per item on every render. Minor here, but if child buttons were memoized this defeats memoization.
**Affected Files:** `frontend/src/components/Sidebar.jsx`
**Fix:** For large/frequently re-rendered lists, hoist handler or use `useCallback` with data attributes. For a small sidebar, this is negligible—don't over-optimize.
**Category:** performance
**Example:**
```javascript
onClick={() => onNavigate(item.key)} // new closure per item, per render
```