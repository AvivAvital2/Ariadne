---
id: f7f21a19-f263-5fc9-acb5-6dff889c6b92
type: catalog
title: "backend.app.schemas.RoleCreate.permission_ids"
created_at: 2026-07-30T15:09:16.667473+00:00
updated_at: 2026-07-30T17:48:08.793959+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleCreate.permission_ids"
  signature: "permission_ids: list[int] = []"
  location: {'line_start': 32, 'line_end': 32, 'col_start': 4, 'col_end': 34}
  parent_qualified_name: "backend.app.schemas.RoleCreate"
  sha_at_sync: "1e3979d3c384f7d9ec9e2c7f33ef23cf15126a121779448f3e43748a0b9d8f5d"
  description: "Optional list of permission IDs to associate with the role being created, defaulting to an empty list."
---
# backend.app.schemas.RoleCreate.permission_ids

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleCreate.permission_ids in backend.app.schemas.RoleCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:32-32 :: permission_ids: list[int] = []

Description: Optional list of permission IDs to associate with the role being created, defaulting to an empty list.

## Related Documents

- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 1.19)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 1.30)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.44)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 1.55)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.73)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 2.79)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 2.88)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.92)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.93)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 2.97)
