---
id: e6944542-0f4c-5b3c-854a-1b1143cba0f7
type: catalog
title: "backend.app.models.User.username"
created_at: 2026-07-30T15:09:15.720430+00:00
updated_at: 2026-07-30T17:48:08.766017+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.username"
  signature: "username: Mapped[str] = mapped_column(String(64), unique=True, index=True)"
  location: {'line_start': 39, 'line_end': 39, 'col_start': 4, 'col_end': 78}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "c90f780226802631f92c987efda444b8efa6ccf46b4e45967220a23fc89eb9fa"
  description: "Defines the User model's unique username column as a required string of up to 64 characters, with a database index for efficient lookups."
---
# backend.app.models.User.username

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.username in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:39-39 :: username: Mapped[str] = mapped_column(String(64), unique=True, index=True)

Description: Defines the User model's unique username column as a required string of up to 64 characters, with a database index for efficient lookups.

## Related Documents

- [backend.app.models.User.email](16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.38)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 1.41)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 1.43)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 2.65)
- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 2.66)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.67)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 2.71)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.72)
