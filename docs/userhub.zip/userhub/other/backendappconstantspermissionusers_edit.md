---
id: 544cfbe1-b37c-5c95-a03e-945177198921
type: catalog
title: "backend.app.constants.Permission.USERS_EDIT"
created_at: 2026-07-30T15:09:15.959501+00:00
updated_at: 2026-07-30T17:48:08.777011+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.USERS_EDIT"
  signature: "USERS_EDIT = "users:edit""
  location: {'line_start': 35, 'line_end': 35, 'col_start': 4, 'col_end': 29}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "bcf5b9ae567d218d7bf5d89ad748918dddccbb2c365afda2740abe5e89ad05c1"
  description: "Defines the permission string `"users:edit"` that grants the ability to modify existing user accounts."
---
# backend.app.constants.Permission.USERS_EDIT

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.USERS_EDIT in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:35-35 :: USERS_EDIT = "users:edit"

Description: Defines the permission string `"users:edit"` that grants the ability to modify existing user accounts.

## Related Documents

- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.18)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.18)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 1.22)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 1.29)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 1.60)
- [backend.app.constants.Permission.ROLES_MANAGE](1b8a72cf-eac9-5394-a8f2-b232a254db18.md) - Related (graph distance 1.63)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.68)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 2.68)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 2.81)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 2.83)
