---
id: 1a4f2915-329d-5095-bbdf-8d62aeeba591
type: catalog
title: "backend.app.services.users.effective_permissions"
created_at: 2026-07-30T15:09:17.211738+00:00
updated_at: 2026-07-30T17:17:45.474290+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.effective_permissions"
  signature: "def effective_permissions(user: User) -> list[str]:"
  location: {'line_start': 42, 'line_end': 44, 'col_start': 0, 'col_end': 82}
  parent_qualified_name: None
  sha_at_sync: "991290a904b13c4f44b802b0ebb1ab4927169fae3a58e6d49e236020180fbc58"
  description: "Computes and returns the complete list of permission strings for a given user, combining permissions from all their assigned roles."
---
# backend.app.services.users.effective_permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.effective_permissions [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:42-44 :: def effective_permissions(user: User) -> list[str]:

Description: Computes and returns the complete list of permission strings for a given user, combining permissions from all their assigned roles.