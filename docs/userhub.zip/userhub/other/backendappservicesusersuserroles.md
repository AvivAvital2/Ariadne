---
id: 42507445-1c87-5d2c-bdbb-9160decb1217
type: catalog
title: "backend.app.services.users.user.roles"
created_at: 2026-07-30T15:09:17.214774+00:00
updated_at: 2026-07-30T17:48:08.853013+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.services.users.user.roles"
  signature: "user.roles = db.query(Role).filter(Role.id.in_(role_ids)).all()"
  location: {'line_start': 139, 'line_end': 139, 'col_start': 4, 'col_end': 67}
  parent_qualified_name: None
  sha_at_sync: "e46882711b0699ddeffbc6267a766aba38ce01355c97743d4f90548ca261b666"
  description: "Assigns the user's roles by querying the database for all Role records whose IDs match the provided list of role IDs."
---
# backend.app.services.users.user.roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

variable backend.app.services.users.user.roles [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:139-139 :: user.roles = db.query(Role).filter(Role.id.in_(role_ids)).all()

Description: Assigns the user's roles by querying the database for all Role records whose IDs match the provided list of role IDs.

## Related Documents

- [backend.app.services.users.assign_roles](baa9a5d5-9ff6-5849-893d-84c97d2d0006.md) - Related (graph distance 1.38)
- [backend.app.routers.users.assign_roles](c95f5b82-4808-5a02-b583-176903208b03.md) - Related (graph distance 1.41)
- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 1.60)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 1.61)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 1.61)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 1.63)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 1.66)
- [backend.app.models.Permission.roles](d0dd4ccf-ac79-5c30-b62c-acf02af231df.md) - Related (graph distance 2.72)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 2.79)
