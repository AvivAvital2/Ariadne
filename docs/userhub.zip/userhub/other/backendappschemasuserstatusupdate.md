---
id: 48093c25-ffa4-5f39-a638-63bdbf8594f4
type: catalog
title: "backend.app.schemas.UserStatusUpdate"
created_at: 2026-07-30T15:09:16.661865+00:00
updated_at: 2026-07-30T17:48:08.786541+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.UserStatusUpdate"
  signature: "class UserStatusUpdate(BaseModel):"
  location: {'line_start': 47, 'line_end': 53, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "af3b4963cd3721744057ec7cfb73be666ad3f23af421048a4b3abdd0020c100e"
  description: "A Pydantic model that validates and structures the request payload for updating a user's status. It defines the schema fields required to modify user account state."
---
# backend.app.schemas.UserStatusUpdate

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.UserStatusUpdate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:47-53 :: class UserStatusUpdate(BaseModel):

Description: A Pydantic model that validates and structures the request payload for updating a user's status. It defines the schema fields required to modify user account state.

## Related Documents

- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.22)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 1.46)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.50)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 1.54)
- [backend.app.schemas.CurrentUser](c9f0033d-65ba-5095-b1f7-46936148c59a.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 2.63)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.67)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 2.69)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 2.70)
