---
id: 87179fb4-2b36-5589-a70b-0aa36e49e217
type: catalog
title: "backend.app.constants.Permission.AUDIT_READ"
created_at: 2026-07-30T15:09:15.960917+00:00
updated_at: 2026-07-30T17:48:08.778310+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.AUDIT_READ"
  signature: "AUDIT_READ = "audit:read""
  location: {'line_start': 39, 'line_end': 39, 'col_start': 4, 'col_end': 29}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "05dc9343998268d1d9a311308cd40abd34256c51bddf7f4ce6a7dc44c5060cc6"
  description: "Defines a permission constant granting read access to audit logs, represented by the string value `"audit:read"`."
---
# backend.app.constants.Permission.AUDIT_READ

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.AUDIT_READ in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:39-39 :: AUDIT_READ = "audit:read"

Description: Defines a permission constant granting read access to audit logs, represented by the string value `"audit:read"`.

## Related Documents

- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.34)
- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 1.60)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.62)
- [backend.app.constants.Permission.ROLES_MANAGE](1b8a72cf-eac9-5394-a8f2-b232a254db18.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 2.57)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 2.64)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 3.12)
