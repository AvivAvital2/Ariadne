---
id: 5cd9c91d-65aa-5c8e-8758-e05d8da0fb24
type: catalog
title: "frontend.package.name"
created_at: 2026-07-30T15:09:15.304210+00:00
updated_at: 2026-07-30T17:48:08.758536+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.name"
  signature: ""name": "userhub-frontend""
  location: {'line_start': 2, 'line_end': 2, 'col_start': 2, 'col_end': 28}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "ea615cd2ec78dc92956c9a40919a51647e5995aeb6fd98a7be3ccb0c50afb796"
  description: "Specifies the package name identifier "userhub-frontend" for the frontend project in its package.json manifest."
---
# frontend.package.name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.name in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:2-2 :: "name": "userhub-frontend"

Description: Specifies the package name identifier "userhub-frontend" for the frontend project in its package.json manifest.

## Related Documents

- [frontend.package.version](81db2b01-295a-5d17-8690-921565d0f57f.md) - Related (graph distance 1.33)
- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.42)
- [frontend.package.scripts](d97dd893-81dd-5cf9-8da9-574a2350ea83.md) - Related (graph distance 1.49)
- [frontend.package.type](86b6bbb8-5d01-5248-b215-0af6c335ce3d.md) - Related (graph distance 1.50)
- [frontend.package.private](9984896f-c935-5cf4-a883-1ae0a7064a00.md) - Related (graph distance 1.52)
- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 2.65)
