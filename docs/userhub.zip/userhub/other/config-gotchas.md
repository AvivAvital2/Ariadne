---
id: 081598b2-1d00-5d0e-b62d-cd5258655acf
type: gotcha
title: "Config Gotchas"
created_at: 2026-07-30T17:31:09.068809+00:00
updated_at: 2026-07-30T17:31:09.068824+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js
metadata:
  module_name: "frontend.vite.config"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Config Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/vite.config.js`

# Gotchas & Pitfalls: `frontend.vite.config`

### Proxy config only applies to the dev server, not production builds
**Trigger:** Developer assumes `/api` routing works in production after running `vite build`. The `server.proxy` setting is a Vite dev-server-only feature and is completely ignored in the built static assets.
**Affected Files:** `frontend/vite.config.js`, any deployment/nginx config
**Fix:** Configure a reverse proxy (nginx, Caddy, etc.) in production to route `/api` to the backend. Never rely on this config beyond `vite dev`.
**Category:** framework
**Example:**
```javascript
// Works in `vite dev`
fetch("/api/users/1/status"); // proxied to :8000

// In production `dist/`, this hits your static host with no backend proxy → 404
```

---

### `localhost` vs `127.0.0.1` IPv6 fallback penalty (already mitigated, easily reverted)
**Trigger:** A future edit "cleans up" the hardcoded IP back to `localhost`. On dual-stack systems Node resolves `localhost` to `::1` first; an IPv4-only backend rejects the connection, forcing a retry on `127.0.0.1` and adding latency to every request.
**Affected Files:** `frontend/vite.config.js`
**Fix:** Keep `127.0.0.1`. The comment explains why—preserve it. If IPv6 backend support is added, revisit deliberately.
**Category:** performance
**Example:**
```javascript
// Slow: per-request ::1 refusal then IPv4 fallback
"/api": "http://localhost:8000",
// Fast: direct IPv4
"/api": "http://127.0.0.1:8000",
```

---

### Path prefix `/api` is passed through, not stripped
**Trigger:** Developer expects the proxy to rewrite `/api/users/1` → `/users/1` on the backend. The string-shorthand form does **not** strip the prefix; the backend receives the full `/api/...` path.
**Affected Files:** `frontend/vite.config.js`, FastAPI route definitions
**Fix:** Only correct if backend routes are actually mounted under `/api`. If not, use `rewrite`. The comment confirms routes "map directly onto the backend's route templates," so backend must include the `/api` prefix.
**Category:** framework
**Example:**
```javascript
// Current: backend sees "/api/users/1"
"/api": "http://127.0.0.1:8000",

// If backend routes are "/users/1", you need:
"/api": {
  target: "http://127.0.0.1:8000",
  rewrite: (path) => path.replace(/^\/api/, ""),
},
```

---

### WebSocket / SSE connections not proxied without `ws: true`
**Trigger:** Backend uses WebSockets or Server-Sent Events under `/api`. The string shorthand does not enable WebSocket proxying, so upgrade requests silently fail.
**Affected Files:** `frontend/vite.config.js`
**Fix:** Switch to object form with `ws: true` if any real-time endpoints exist.
**Category:** framework
**Example:**
```javascript
"/api": {
  target: "http://127.0.0.1:8000",
  ws: true, // required for /api/ws/... upgrades
},
```

---

### Hardcoded port 5173 collides silently; Vite auto-increments
**Trigger:** Another process already occupies 5173. Vite by default picks the next free port (5174, ...) unless `strictPort` is set, so the proxy contract and any hardcoded frontend URLs may drift.
**Affected Files:** `frontend/vite.config.js`, any docs/scripts referencing `:5173`
**Fix:** Add `strictPort: true` to fail loudly instead of silently changing ports, if a fixed port is required.
**Category:** framework
**Example:**
```javascript
server: {
  port: 5173,
  strictPort: true, // error instead of silently using 5174
  proxy: { "/api": "http://127.0.0.1:8000" },
}
```

---

### Backend port `8000` hardcoded—no env override
**Trigger:** Backend is run on a non-default port (e.g., via `UVICORN_PORT`), but the proxy target stays at `8000`. Requests silently fail with connection refused.
**Affected Files:** `frontend/vite.config.js`
**Fix:** Read the target from an environment variable using `loadEnv` / `process.env` so frontend and backend stay in sync.
**Category:** framework
**Example:**
```javascript
const backend = process.env.BACKEND_URL ?? "http://127.0.0.1:8000";
export default defineConfig({
  server: { proxy: { "/api": backend } },
});
```

---

### Proxy prefix matching can over-capture routes
**Trigger:** A frontend route or asset path begins with `/api` but is not a backend call (e.g., `/apiary`, `/api-docs`). Vite matches by prefix, so `/apiary` also gets proxied to the backend.
**Affected Files:** `frontend/vite.config.js`
**Fix:** Be aware prefix matching is not path-segment-aware for the string form. Ensure no non-API paths start with the literal string `api`.
**Category:** framework
**Example:**
```javascript
// "/apiary-guide" → proxied to backend → likely 404
"/api": "http://127.0.0.1:8000",
```

---

### No `changeOrigin` — Host header stays as dev server
**Trigger:** Backend inspects the `Host` header (virtual hosts, CSRF/Origin checks, redirect URL generation). Without `changeOrigin: true`, the proxied request carries the frontend's Host, which may confuse host-based logic.
**Affected Files:** `frontend/vite.config.js`, backend middleware
**Fix:** Add `changeOrigin: true` if the backend depends on Host/Origin headers.
**Category:** framework
**Example:**
```javascript
"/api": {
  target: "http://127.0.0.1:8000",
  changeOrigin: true,
},
```