---
id: 2cc1107a-d10c-52b7-b97e-22e92b702ae0
type: gotcha
title: "Userform Gotchas"
created_at: 2026-07-30T17:29:10.183611+00:00
updated_at: 2026-07-30T17:29:10.183625+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx
metadata:
  module_name: "frontend.src.components.UserForm"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userform Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserForm.jsx`

# Gotchas and Pitfalls: `UserForm`

### State does not reset when `user` prop changes
**Trigger:** `useState(user?.username ?? "")` only reads the prop on the first mount. If the same `UserForm` instance is reused with a different `user` (e.g. parent renders the same modal and swaps which user is edited), the form fields keep stale values.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Either force remount with a `key={user?.id ?? "new"}` on the parent, or add a `useEffect` that syncs state when `user` changes.
**Category:** framework
**Example:**
```jsx
// Parent reuses the component:
<UserForm user={selectedUser} .../>   // switching selectedUser keeps old form values

// Fix at parent:
<UserForm key={selectedUser?.id ?? "new"} user={selectedUser} .../>
```

---

### Partial-failure leaves user in inconsistent state on edit
**Trigger:** In the edit path, two awaited calls run sequentially: `updateUser` then `assignRoles`. If `assignRoles` throws, the profile update already succeeded but roles didn't, and the error message hides that the save was partial.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Prefer a single atomic backend endpoint, or clearly communicate partial success. At minimum, don't let the UI imply nothing was saved.
**Category:** async
**Example:**
```jsx
await api.updateUser(user.id, { email, full_name: fullName }); // succeeds
await api.assignRoles(user.id, roleIds); // throws -> user sees error, but profile changed
```

---

### `onSaved` never called if it throws; no submit guard against double-submit
**Trigger:** The submit button is not disabled during the async request. Rapid double-clicks fire multiple `createUser`/`updateUser` calls, potentially creating duplicate users or racing role assignments.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Add a `submitting` state, disable the button, and guard entry into `submit`.
**Category:** async
**Example:**
```jsx
const [submitting, setSubmitting] = useState(false);
const submit = async (e) => {
  e.preventDefault();
  if (submitting) return;
  setSubmitting(true);
  try { ... } finally { setSubmitting(false); }
};
<button type="submit" disabled={submitting}>...</button>
```

---

### `err.message` may be `undefined` or unhelpful
**Trigger:** `setError(err.message)` assumes every rejection is an `Error` with a meaningful `message`. Fetch/API layers often reject with response objects, strings, or a generic `"Failed to fetch"` that masks the real 4xx/5xx body.
**Affected Files:** `frontend/src/components/UserForm.jsx`, `frontend/src/api/client.js`
**Fix:** Normalize errors in the API client, and fall back defensively: `setError(err?.message ?? "Something went wrong")`.
**Category:** type-system
**Example:**
```jsx
catch (err) {
  setError(err.message); // renders "undefined" or nothing if err is a plain object
}
```

---

### Unmounted-component state update after async resolves
**Trigger:** `listRoles()`, `createUser`, etc. resolve after the modal is closed/unmounted. Calling `setRoles`/`setError` on an unmounted component is a wasted update (and historically a warning). More importantly, `onSaved()`/`onClose()` may run in an order that unmounts before `setError` fires.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Use an `AbortController`/mounted flag in the `useEffect`, and avoid setting state after `onSaved()`.
**Category:** async
**Example:**
```jsx
useEffect(() => {
  let active = true;
  api.listRoles().then((r) => active && setRoles(r)).catch(() => active && setRoles([]));
  return () => { active = false; };
}, []);
```

---

### Roles list race with pre-selected `roleIds`
**Trigger:** `roleIds` is initialized from `user.roles`, but `roles` (the checkbox source) loads asynchronously. If a role assigned to the user is missing/renamed in the fetched `roles`, its checkbox never appears—yet the id stays in `roleIds` and gets re-submitted silently.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Reconcile `roleIds` against fetched `roles`, or surface orphaned role ids to the user.
**Category:** domain
**Example:**
```jsx
// user.roles has id 7, but listRoles() omits it (deleted role)
roleIds = [7]           // no checkbox rendered
await api.assignRoles(user.id, [7]); // resubmits a possibly-invalid role
```

---

### `isNew` derived only from strict `=== null`
**Trigger:** `const isNew = user === null;` treats `undefined` as an existing user (not new). If a caller passes `user={undefined}` (common with optional props), `isNew` is `false`, then `user.username` in the header throws.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Use `!user` or default the prop: `function UserForm({ user = null, ... })`.
**Category:** type-system
**Example:**
```jsx
<UserForm user={undefined} .../>  // isNew=false -> `Edit @${user.username}` -> crash
```

---

### Email `full_name` not sent on create if empty vs backend expectations
**Trigger:** Empty `fullName` submits `full_name: ""`, which may differ from the backend's "not provided" (`null`). Silent string-vs-null mismatch can fail validation or overwrite a value with an empty string on update.
**Affected Files:** `frontend/src/components/UserForm.jsx`, `frontend/src/api/client.js`
**Fix:** Convert empty strings to `null`/omit before sending, matching backend semantics.
**Category:** type-system
**Example:**
```jsx
full_name: fullName || null,  // rather than always sending ""
```

---

### Browser email validation is not backend validation
**Trigger:** `<input type="email" required>` only enforces a loose client-side format. Devs may assume the email is validated; malformed-but-passing addresses (`a@b`) reach the API, and validation errors surface only via the catch block.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Rely on backend validation and display its errors; don't treat client validation as authoritative.
**Category:** framework
**Example:**
```
"a@b" passes type="email" but may fail server-side EmailStr validation
```

---

### Checkbox lookups are O(n²) via `includes`
**Trigger:** For each rendered role, `roleIds.includes(role.id)` scans the array; combined with `roles.map`, rendering is O(roles × roleIds). Fine for small lists, but a trap if role counts grow.
**Affected Files:** `frontend/src/components/UserForm.jsx`
**Fix:** Convert `roleIds` to a `Set` once per render for O(1) lookups.
**Category:** performance
**Example:**
```jsx
const selected = new Set(roleIds);
checked={selected.has(role.id)}
```