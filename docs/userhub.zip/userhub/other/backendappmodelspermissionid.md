---
id: ffa6c22f-1114-51e8-b4d3-7542899f8270
type: catalog
title: "backend.app.models.Permission.id"
created_at: 2026-07-30T15:09:15.724437+00:00
updated_at: 2026-07-30T17:48:08.769796+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Permission.id"
  signature: "id: Mapped[int] = mapped_column(primary_key=True)"
  location: {'line_start': 72, 'line_end': 72, 'col_start': 4, 'col_end': 53}
  parent_qualified_name: "backend.app.models.Permission"
  sha_at_sync: "06b4f0bf94a32745f665ce92f1d2852aaa070fb664bc0d80af2423523af921b2"
  description: "The primary key column for the Permission model, storing a unique integer identifier for each permission record."
---
# backend.app.models.Permission.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Permission.id in backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:72-72 :: id: Mapped[int] = mapped_column(primary_key=True)

Description: The primary key column for the Permission model, storing a unique integer identifier for each permission record.

## Related Documents

- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.23)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 1.24)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.24)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 1.27)
- [backend.app.models.Permission.name](138bf8d6-bae5-5c03-82d7-251391d53d05.md) - Related (graph distance 1.42)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.43)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.48)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.49)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 2.51)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 2.52)
