---
id: 5cdbe3f2-d28f-5da1-9661-0d42e75263ea
type: catalog
title: "backend.app.schemas.RoleBrief.id"
created_at: 2026-07-30T15:09:16.663886+00:00
updated_at: 2026-07-30T17:48:08.789586+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleBrief.id"
  signature: "id: int"
  location: {'line_start': 10, 'line_end': 10, 'col_start': 4, 'col_end': 11}
  parent_qualified_name: "backend.app.schemas.RoleBrief"
  sha_at_sync: "fa3ade80194044385719c8d9c727664fc73b21b0585020aa04e7b43bca70c957"
  description: "The integer primary key identifier for a role in the `RoleBrief` schema."
---
# backend.app.schemas.RoleBrief.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleBrief.id in backend.app.schemas.RoleBrief [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:10-10 :: id: int

Description: The integer primary key identifier for a role in the `RoleBrief` schema.

## Related Documents

- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 1.17)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 1.24)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 1.35)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 1.36)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 1.43)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.47)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 1.52)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 1.62)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 2.42)
