---
id: 0fbc27ec-0bb2-53a5-b19c-788816566132
type: catalog
title: "backend.app.schemas.RoleBrief"
created_at: 2026-07-30T15:09:16.660078+00:00
updated_at: 2026-07-30T17:48:08.785205+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.RoleBrief"
  signature: "class RoleBrief(BaseModel):"
  location: {'line_start': 8, 'line_end': 11, 'col_start': 0, 'col_end': 13}
  parent_qualified_name: None
  sha_at_sync: "9f5f594306a08e5b6af49cf8e1865975e06c7b8bccaa64c898349a8ccc941ff3"
  description: "A Pydantic model representing a condensed view of a role, containing only essential identifying fields for use in nested or summary responses."
---
# backend.app.schemas.RoleBrief

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.RoleBrief [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:8-11 :: class RoleBrief(BaseModel):

Description: A Pydantic model representing a condensed view of a role, containing only essential identifying fields for use in nested or summary responses.

## Related Documents

- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 1.38)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 1.40)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 1.43)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.52)
- [backend.app.schemas.RoleBrief.model_config](dc56a798-5157-5d98-8faf-c69a69f6bec0.md) - Related (graph distance 1.54)
- [backend.app.schemas.RoleOut.model_config](855b8538-1f7f-53a3-af63-94b320e0e796.md) - Related (graph distance 2.63)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 2.64)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.69)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 2.70)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 2.70)
