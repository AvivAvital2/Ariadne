---
id: 5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169
type: catalog
title: "frontend.package.dependencies"
created_at: 2026-07-30T15:09:15.306125+00:00
updated_at: 2026-07-30T17:48:08.759320+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.dependencies"
  signature: ""dependencies": {"
  location: {'line_start': 11, 'line_end': 14, 'col_start': 2, 'col_end': 3}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "b8c67ea2ab200e9b823cdb7c5180b0d41f46ade60369d6faa0bc05ffd71b0f73"
  description: "Specifies the runtime npm packages required by the frontend package, mapping each dependency name to its version constraint."
---
# frontend.package.dependencies

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.dependencies in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:11-14 :: "dependencies": {

Description: Specifies the runtime npm packages required by the frontend package, mapping each dependency name to its version constraint.

## Related Documents

- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 1.23)
- [frontend.package.version](81db2b01-295a-5d17-8690-921565d0f57f.md) - Related (graph distance 1.37)
- [frontend.package.name](5cd9c91d-65aa-5c8e-8758-e05d8da0fb24.md) - Related (graph distance 1.42)
- [frontend.package.scripts](d97dd893-81dd-5cf9-8da9-574a2350ea83.md) - Related (graph distance 1.51)
- [frontend.package.private](9984896f-c935-5cf4-a883-1ae0a7064a00.md) - Related (graph distance 1.58)
- [frontend.package.type](86b6bbb8-5d01-5248-b215-0af6c335ce3d.md) - Related (graph distance 1.59)
