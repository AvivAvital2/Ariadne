---
id: 535e53d2-ce6c-5494-889d-0018699cdf42
type: catalog
title: "backend.app.schemas.UserOut.created_at"
created_at: 2026-07-30T15:09:16.673176+00:00
updated_at: 2026-07-30T17:48:08.797886+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserOut.created_at"
  signature: "created_at: datetime"
  location: {'line_start': 68, 'line_end': 68, 'col_start': 4, 'col_end': 24}
  parent_qualified_name: "backend.app.schemas.UserOut"
  sha_at_sync: "2fa0900bd0d27444bb0c1e381b9e32951aafa5901f5eb634c67860aed2a58a09"
  description: "Stores the timestamp indicating when the user account was created, exposed as part of the `UserOut` response schema."
---
# backend.app.schemas.UserOut.created_at

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserOut.created_at in backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:68-68 :: created_at: datetime

Description: Stores the timestamp indicating when the user account was created, exposed as part of the `UserOut` response schema.

## Related Documents

- [backend.app.schemas.UserOut.updated_at](3acb81b3-77cb-588b-8b04-50eda470cb17.md) - Related (graph distance 1.19)
- [backend.app.schemas.AuditLogOut.created_at](31c07d5e-1e35-57f6-95c2-d550675c0883.md) - Related (graph distance 1.23)
- [backend.app.models.User.created_at](8ea6c38c-c021-5ac6-a555-1fd72c4a3136.md) - Related (graph distance 1.26)
- [backend.app.models.User.updated_at](d16fded0-b866-5b24-b3f4-c996ca1d98ea.md) - Related (graph distance 1.41)
- [backend.app.models.AuditLog.created_at](f84a7924-6247-540c-bf88-6538484215df.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserActivityRow.last_action_at](78bb4157-648a-5246-a4db-595d3c370f6d.md) - Related (graph distance 1.56)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 2.92)
