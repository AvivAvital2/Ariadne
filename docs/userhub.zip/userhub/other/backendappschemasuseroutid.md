---
id: 4ef51978-13b5-5dea-95b8-5e162474ad27
type: catalog
title: "backend.app.schemas.UserOut.id"
created_at: 2026-07-30T15:09:16.670248+00:00
updated_at: 2026-07-30T17:48:08.795852+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserOut.id"
  signature: "id: int"
  location: {'line_start': 62, 'line_end': 62, 'col_start': 4, 'col_end': 11}
  parent_qualified_name: "backend.app.schemas.UserOut"
  sha_at_sync: "fa3ade80194044385719c8d9c727664fc73b21b0585020aa04e7b43bca70c957"
  description: "Represents the unique integer identifier of a user in the `UserOut` response schema."
---
# backend.app.schemas.UserOut.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserOut.id in backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:62-62 :: id: int

Description: Represents the unique integer identifier of a user in the `UserOut` response schema.

## Related Documents

- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 1.16)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.19)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 1.21)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 1.26)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.30)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.36)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 2.43)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 2.44)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.51)
