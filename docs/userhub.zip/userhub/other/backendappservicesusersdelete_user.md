---
id: 5b5d80fb-054f-5873-9a99-b372617190c4
type: catalog
title: "backend.app.services.users.delete_user"
created_at: 2026-07-30T15:09:17.213002+00:00
updated_at: 2026-07-30T17:48:08.851435+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.delete_user"
  signature: "def delete_user(db: Session, *, actor_id: int, user_id: int) -> None:"
  location: {'line_start': 121, 'line_end': 132, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "48f9496f385f13366092b759421de6c55c756d85c0ebff7b7ae19d1517754f90"
  description: "Deletes the user identified by `user_id` from the database, with the operation performed on behalf of the actor specified by `actor_id`."
---
# backend.app.services.users.delete_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.delete_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:121-132 :: def delete_user(db: Session, *, actor_id: int, user_id: int) -> None:

Description: Deletes the user identified by `user_id` from the database, with the operation performed on behalf of the actor specified by `actor_id`.

## Related Documents

- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 1.39)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 1.43)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 1.48)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 1.54)
- [backend.app.security.actor](4e7167d7-c470-5237-89cd-129549d48c21.md) - Related (graph distance 1.54)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 2.73)
- [backend.app.services.users._require](9ed832d6-c01f-5651-aed5-9b72c915b9db.md) - Related (graph distance 2.74)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 2.75)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 2.76)
- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 2.80)
