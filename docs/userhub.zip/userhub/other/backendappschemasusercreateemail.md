---
id: 6a7dc860-10ed-51d0-b9eb-238eb9016eb4
type: catalog
title: "backend.app.schemas.UserCreate.email"
created_at: 2026-07-30T15:09:16.668020+00:00
updated_at: 2026-07-30T17:48:08.793198+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserCreate.email"
  signature: "email: str"
  location: {'line_start': 37, 'line_end': 37, 'col_start': 4, 'col_end': 14}
  parent_qualified_name: "backend.app.schemas.UserCreate"
  sha_at_sync: "073f2da50ead230d35475cc1f60c1154056d0d6cc56b8fa074cc638e6085c349"
  description: "Stores the email address for a new user being created, represented as a string."
---
# backend.app.schemas.UserCreate.email

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserCreate.email in backend.app.schemas.UserCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:37-37 :: email: str

Description: Stores the email address for a new user being created, represented as a string.

## Related Documents

- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 1.18)
- [backend.app.models.User.email](16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8.md) - Related (graph distance 1.31)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.33)
- [backend.app.services.users.email](c9d9526a-dd04-57c7-b212-845716fc2b78.md) - Related (graph distance 1.51)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.49)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.53)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.61)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 2.65)
- [backend.app.models.User.username](e6944542-0f4c-5b3c-854a-1b1143cba0f7.md) - Related (graph distance 2.66)
