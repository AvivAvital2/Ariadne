---
id: d8239755-e4e5-55e7-8d4e-4236a82bde79
type: catalog
title: "README.seeded_roles"
created_at: 2026-07-30T15:09:15.503993+00:00
updated_at: 2026-07-30T17:48:08.763199+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/README.md
metadata:
  kind: "element"
  source_name: "userhub"
  language: "markdown"
  subtype: "md_section"
  qualified_name: "README.seeded_roles"
  signature: "### Seeded roles"
  location: {'line_start': 151, 'line_end': 160, 'col_start': 0, 'col_end': 16}
  parent_qualified_name: "README"
  sha_at_sync: "697d398efb19143999aa0ccf9c04da4c5aa45610d201a8e13f4484ef3f7088ad"
  description: "Documents the default roles automatically created when the application initializes, listing each role's name and associated permissions or purpose."
---
# README.seeded_roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/README.md`

md_section README.seeded_roles in README [markdown] /Users/spark/git/Ariadne.orig/userhub/README.md:151-160 :: ### Seeded roles

Description: Documents the default roles automatically created when the application initializes, listing each role's name and associated permissions or purpose.

## Related Documents

- [README.permissions](9d1e2721-c169-5257-984c-482b51475fd9.md) - Related (graph distance 1.62)
- [README.license](42c1b599-5fd6-542c-85b6-8d671e619517.md) - Related (graph distance 3.14)
- [README.features](8c71f8b3-217a-5d4c-905b-0f641db15443.md) - Related (graph distance 3.25)
