---
id: 1b8a72cf-eac9-5394-a8f2-b232a254db18
type: catalog
title: "backend.app.constants.Permission.ROLES_MANAGE"
created_at: 2026-07-30T15:09:15.960581+00:00
updated_at: 2026-07-30T17:48:08.777529+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.ROLES_MANAGE"
  signature: "ROLES_MANAGE = "roles:manage""
  location: {'line_start': 38, 'line_end': 38, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "f360d030777772b3cad3fb0937ea81ba1c4f1f8eb2ca76d92bb345d63b650236"
  description: "A permission constant representing the authority to manage roles, with the string value `"roles:manage"`."
---
# backend.app.constants.Permission.ROLES_MANAGE

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.ROLES_MANAGE in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:38-38 :: ROLES_MANAGE = "roles:manage"

Description: A permission constant representing the authority to manage roles, with the string value `"roles:manage"`.

## Related Documents

- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 1.63)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.65)
- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.65)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 2.81)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 2.85)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 3.15)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 3.26)
