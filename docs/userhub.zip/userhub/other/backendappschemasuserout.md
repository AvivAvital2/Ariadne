---
id: 8b3c89e5-20aa-5902-94ff-eb90214f8440
type: catalog
title: "backend.app.schemas.UserOut"
created_at: 2026-07-30T15:09:16.662518+00:00
updated_at: 2026-07-30T17:48:08.787087+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.UserOut"
  signature: "class UserOut(BaseModel):"
  location: {'line_start': 60, 'line_end': 69, 'col_start': 0, 'col_end': 24}
  parent_qualified_name: None
  sha_at_sync: "8720d2fd422139c54200f9afcb5c777dc5933387bc4007f60e678cc800d2a76b"
  description: "A Pydantic response schema representing user data returned by the API, exposing safe public fields (such as ID, email, and username) while excluding sensitive information like passwords."
---
# backend.app.schemas.UserOut

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:60-69 :: class UserOut(BaseModel):

Description: A Pydantic response schema representing user data returned by the API, exposing safe public fields (such as ID, email, and username) while excluding sensitive information like passwords.

## Related Documents

- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 1.31)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 1.33)
- [backend.app.schemas.AuditLogOut](6e6767f4-fae6-512e-a9bf-fdd8f6b39d44.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 1.46)
- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 1.50)
- [backend.app.schemas.CurrentUser](c9f0033d-65ba-5095-b1f7-46936148c59a.md) - Related (graph distance 1.55)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 2.67)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.69)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 2.70)
