---
id: 8a9c8e56-45c0-5086-9767-491ef3cb6db1
type: catalog
title: "backend.app.schemas.UserCreate.role_ids"
created_at: 2026-07-30T15:09:16.668591+00:00
updated_at: 2026-07-30T17:48:08.794233+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserCreate.role_ids"
  signature: "role_ids: list[int] = []"
  location: {'line_start': 39, 'line_end': 39, 'col_start': 4, 'col_end': 28}
  parent_qualified_name: "backend.app.schemas.UserCreate"
  sha_at_sync: "2be3346edbe13b215e1f6b77dfbdc724e5d14d989ed58f2f2ba1c51621f852b0"
  description: "Optional list of role IDs to assign to the user upon creation, defaulting to an empty list."
---
# backend.app.schemas.UserCreate.role_ids

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserCreate.role_ids in backend.app.schemas.UserCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:39-39 :: role_ids: list[int] = []

Description: Optional list of role IDs to assign to the user upon creation, defaulting to an empty list.

## Related Documents

- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 1.19)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 1.20)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 1.54)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 1.60)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 2.64)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 2.74)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.82)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.83)
- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 2.93)
- [backend.app.services.users.assign_roles](baa9a5d5-9ff6-5849-893d-84c97d2d0006.md) - Related (graph distance 2.98)
