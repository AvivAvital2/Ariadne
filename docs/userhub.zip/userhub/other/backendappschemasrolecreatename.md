---
id: 36956015-e80e-5737-9b0b-189e09d3e3b5
type: catalog
title: "backend.app.schemas.RoleCreate.name"
created_at: 2026-07-30T15:09:16.666881+00:00
updated_at: 2026-07-30T17:48:08.792673+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleCreate.name"
  signature: "name: str"
  location: {'line_start': 30, 'line_end': 30, 'col_start': 4, 'col_end': 13}
  parent_qualified_name: "backend.app.schemas.RoleCreate"
  sha_at_sync: "919c21eb6c610117d05f4d2ccab283c85d79a73bb5e9b0661728f5f7be0b2cd2"
  description: "Defines the required string field for the name of a role in the `RoleCreate` schema, used when creating a new role."
---
# backend.app.schemas.RoleCreate.name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleCreate.name in backend.app.schemas.RoleCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:30-30 :: name: str

Description: Defines the required string field for the name of a role in the `RoleCreate` schema, used when creating a new role.

## Related Documents

- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 1.14)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 1.14)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 1.32)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.35)
- [backend.app.schemas.PermissionOut.name](2153ab49-fcf1-5e7c-9187-d798d625c592.md) - Related (graph distance 1.37)
- [backend.app.schemas.RoleOut.description](de00f3e4-a439-5e5f-a034-98d286d08613.md) - Related (graph distance 1.43)
- [backend.app.services.roles.role](98eb86d0-4da5-5101-afd6-50e807b8bc0d.md) - Related (graph distance 1.62)
- [backend.app.models.Permission.name](138bf8d6-bae5-5c03-82d7-251391d53d05.md) - Related (graph distance 2.55)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.56)
