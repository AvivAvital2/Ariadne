---
id: 81db2b01-295a-5d17-8690-921565d0f57f
type: catalog
title: "frontend.package.version"
created_at: 2026-07-30T15:09:15.305098+00:00
updated_at: 2026-07-30T17:48:08.758796+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.version"
  signature: ""version": "0.1.0""
  location: {'line_start': 4, 'line_end': 4, 'col_start': 2, 'col_end': 20}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "eb787f18253c54cd1075572e9489263ae9b0fcaef1b29d1cb848752ee5871da2"
  description: "Specifies the semantic version number of the frontend package, currently set to the initial release version 0.1.0."
---
# frontend.package.version

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.version in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:4-4 :: "version": "0.1.0"

Description: Specifies the semantic version number of the frontend package, currently set to the initial release version 0.1.0.

## Related Documents

- [frontend.package.name](5cd9c91d-65aa-5c8e-8758-e05d8da0fb24.md) - Related (graph distance 1.33)
- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.37)
- [frontend.package.private](9984896f-c935-5cf4-a883-1ae0a7064a00.md) - Related (graph distance 1.50)
- [frontend.package.type](86b6bbb8-5d01-5248-b215-0af6c335ce3d.md) - Related (graph distance 1.52)
- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 2.61)
