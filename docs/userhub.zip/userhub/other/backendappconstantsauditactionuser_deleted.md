---
id: da68919f-3944-5c27-a38d-283af40e2e66
type: catalog
title: "backend.app.constants.AuditAction.USER_DELETED"
created_at: 2026-07-30T15:09:16.000205+00:00
updated_at: 2026-07-30T17:48:08.779643+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.AuditAction.USER_DELETED"
  signature: "USER_DELETED = "user.deleted""
  location: {'line_start': 52, 'line_end': 52, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.AuditAction"
  sha_at_sync: "b5fbb4a8dfc60987d4a55b1cd610c624882caa030352e0cc622f344c848ca378"
  description: "Enum member of `AuditAction` representing the audit event logged when a user account is deleted, with the string value `"user.deleted"`."
---
# backend.app.constants.AuditAction.USER_DELETED

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.AuditAction.USER_DELETED in backend.app.constants.AuditAction [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:52-52 :: USER_DELETED = "user.deleted"

Description: Enum member of `AuditAction` representing the audit event logged when a user account is deleted, with the string value `"user.deleted"`.

## Related Documents

- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 1.16)
- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 1.22)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 1.24)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 1.25)
- [backend.app.constants.AuditAction.ROLE_REVOKED](941c3822-94ac-5358-a3bf-3f1ce80016d7.md) - Related (graph distance 1.35)
- [backend.app.constants.AuditAction.ROLE_ASSIGNED](acc30db8-b69c-5f6f-88d4-de745f572998.md) - Related (graph distance 1.41)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.50)
- [backend.app.constants.AuditAction](966803e2-fceb-5ae6-8492-3ddfcff173ef.md) - Related (graph distance 1.53)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.36)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 2.66)
