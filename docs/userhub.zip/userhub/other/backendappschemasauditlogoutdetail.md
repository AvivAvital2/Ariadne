---
id: a31c8116-37e1-5beb-bf8e-ea48591a1744
type: catalog
title: "backend.app.schemas.AuditLogOut.detail"
created_at: 2026-07-30T15:09:16.676506+00:00
updated_at: 2026-07-30T17:48:08.841648+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.detail"
  signature: "detail: str"
  location: {'line_start': 93, 'line_end': 93, 'col_start': 4, 'col_end': 15}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "07905688e7ecdbb334ed2a804ef581e1203a0bad6f911e370b5a3fb33149ccd8"
  description: "Holds a string containing descriptive details about the audit log entry, such as the specific action or context of the logged event."
---
# backend.app.schemas.AuditLogOut.detail

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.detail in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:93-93 :: detail: str

Description: Holds a string containing descriptive details about the audit log entry, such as the specific action or context of the logged event.

## Related Documents

- [backend.app.models.AuditLog.detail](3be4829c-8290-58c1-823e-c6fbdaff14ff.md) - Related (graph distance 1.27)
- [backend.app.schemas.AuditLogOut.action](bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d.md) - Related (graph distance 1.51)
- [backend.app.models.Permission.description](9fe1ddb1-931e-52dc-bec1-aa8b5cdbe620.md) - Related (graph distance 2.79)
- [backend.app.models.Role.description](05e42cb4-46a0-51af-998b-59dfc35bf5ff.md) - Related (graph distance 2.79)
- [backend.app.models.AuditLog.action](4e1645db-d364-5489-8771-5ec8b957913b.md) - Related (graph distance 2.89)
- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 3.01)
