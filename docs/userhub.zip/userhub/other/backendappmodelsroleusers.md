---
id: b9039759-eb64-5b55-b552-7022ea8b09f5
type: catalog
title: "backend.app.models.Role.users"
created_at: 2026-07-30T15:09:15.723580+00:00
updated_at: 2026-07-30T17:48:08.769041+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Role.users"
  signature: "users: Mapped[list[User]] = relationship("
  location: {'line_start': 61, 'line_end': 63, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "backend.app.models.Role"
  sha_at_sync: "de2092610c2a1c9ce2ed4a3cf1cd4586d151fb93dec6293228aad4b7b278c621"
  description: "Defines a SQLAlchemy ORM relationship mapping a Role to its associated list of User objects, enabling bidirectional access between roles and users."
---
# backend.app.models.Role.users

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Role.users in backend.app.models.Role [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:61-63 :: users: Mapped[list[User]] = relationship(

Description: Defines a SQLAlchemy ORM relationship mapping a Role to its associated list of User objects, enabling bidirectional access between roles and users.

## Related Documents

- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 1.36)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 1.48)
- [backend.app.models.Permission.roles](d0dd4ccf-ac79-5c30-b62c-acf02af231df.md) - Related (graph distance 1.48)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 1.63)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.76)
- [backend.app.models.role_permissions](2862ba3a-f04e-542f-b12e-006257f4a4d6.md) - Related (graph distance 2.89)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 2.91)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 2.94)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 3.03)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 3.11)
