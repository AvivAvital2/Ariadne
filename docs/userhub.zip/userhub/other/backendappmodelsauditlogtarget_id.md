---
id: 43d55f4b-0b92-51b9-87d9-3f8c481cb80c
type: catalog
title: "backend.app.models.AuditLog.target_id"
created_at: 2026-07-30T15:09:15.726952+00:00
updated_at: 2026-07-30T17:48:08.772084+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.target_id"
  signature: "target_id: Mapped[int | None] = mapped_column(Integer, nullable=True)"
  location: {'line_start': 90, 'line_end': 90, 'col_start': 4, 'col_end': 73}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "d65fca95f2e8e9f968d6f7d429877b97f98501f6f8d07d14dbd189ea7fe4d8f1"
  description: "Stores the optional integer identifier of the entity targeted by the audited action, allowing null when no specific target applies."
---
# backend.app.models.AuditLog.target_id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.target_id in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:90-90 :: target_id: Mapped[int | None] = mapped_column(Integer, nullable=True)

Description: Stores the optional integer identifier of the entity targeted by the audited action, allowing null when no specific target applies.

## Related Documents

- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 1.19)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.31)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 1.34)
- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 1.45)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 1.46)
- [backend.app.services.users.target_id](347260a2-8d58-556f-89b7-d9cc05ee6faa.md) - Related (graph distance 1.52)
- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 1.60)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 2.51)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 2.57)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 2.61)
