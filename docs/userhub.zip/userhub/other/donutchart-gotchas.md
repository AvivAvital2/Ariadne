---
id: 4e9604fe-e924-5a99-874a-3b2bfb8cb725
type: gotcha
title: "Donutchart Gotchas"
created_at: 2026-07-30T17:30:06.235439+00:00
updated_at: 2026-07-30T17:30:06.235454+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx
metadata:
  module_name: "frontend.src.components.charts.DonutChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Donutchart Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/DonutChart.jsx`

# DonutChart Gotchas & Pitfalls

### Mutable `offset` inside `.map()` couples rendering order to accumulation
**Trigger:** The `offset` variable is mutated as a side effect during `.map()`. If React ever reorders, memoizes, or partially re-renders this array (or if the map callback is refactored to run in a different order), segment positions break silently.
**Affected Files:** `DonutChart.jsx`
**Fix:** Precompute cumulative offsets in a separate pass (e.g., `reduce` producing an array) so `map` is pure.
**Category:** framework
**Example:**
```javascript
// Fragile: side-effect in render map
data.map((d) => {
  const frac = d.value / total;
  offset += frac * circumference; // mutation during render
});

// Safer: precompute
let acc = 0;
const segments = data.map((d) => {
  const start = acc;
  acc += (d.value / total) * circumference;
  return { ...d, offset: start };
});
```

### Duplicate or missing `label` corrupts React keys and `<title>`
**Trigger:** `key={d.label}` assumes labels are unique and defined. Two segments named `"Open"` cause React key collisions (dropped/merged DOM); an undefined label yields `key={undefined}`.
**Affected Files:** `DonutChart.jsx`
**Fix:** Use a guaranteed-unique key (index fallback or an `id` field).
**Category:** framework
**Example:**
```javascript
{data.map((d, i) => <circle key={d.id ?? `${d.label}-${i}`} ... />)}
```

### Negative or NaN `value` silently breaks the geometry
**Trigger:** `total` uses raw `d.value`. A negative value shrinks total; a `null`/`undefined`/string value makes `total` become `NaN`, so `total > 0` is false and *no segments render at all* — but the center still shows `NaN`.
**Affected Files:** `DonutChart.jsx`
**Fix:** Coerce and clamp: `sum + (Number(d.value) || 0)`, and guard non-finite totals.
**Category:** type-system
**Example:**
```javascript
const total = data.reduce((s, d) => s + (Number(d.value) || 0), 0);
// value: "5" → "05" style bug if string; value: null → NaN total
```

### `GAP` subtraction distorts small segments and total arc length
**Trigger:** `Math.max(frac * circumference - GAP, 0)` subtracts 2px per segment, but `offset` advances by the *full* `frac * circumference`. With many segments, accumulated gaps mean segments don't visually sum to the full ring, and tiny slices collapse to 0-length (invisible but still counted in legend).
**Affected Files:** `DonutChart.jsx`
**Fix:** Document that gaps are cosmetic, or distribute gaps proportionally; flag zero-length segments as visually hidden despite appearing in legend.
**Category:** domain
**Example:**
```javascript
// A segment with frac*circumference = 1.5px becomes len=0 → invisible
// but its legend row shows its value → user confusion
```

### Single 100% segment renders as a full ring with a phantom gap
**Trigger:** When one segment is 100%, `strokeDasharray = "circumference-2 2"`. The 2px "gap" appears at the start/12-o'clock even though there's only one segment — a gap with nothing to separate from.
**Affected Files:** `DonutChart.jsx`
**Fix:** Skip the GAP subtraction when `data.length === 1` (or when `frac === 1`).
**Category:** domain
**Example:**
```javascript
const len = data.length === 1 ? frac * circumference
                              : Math.max(frac * circumference - GAP, 0);
```

### `Math.round(frac * 100)` percentages don't sum to 100
**Trigger:** Rounding each percentage independently means displayed values can total 99% or 101%.
**Affected Files:** `DonutChart.jsx`
**Fix:** Use largest-remainder rounding if displayed percentages must sum to 100.
**Category:** domain
**Example:**
```javascript
// three segments at 33.33% each → "33% + 33% + 33% = 99%"
```

### Negative `strokeDashoffset` direction is fragile against CSS
**Trigger:** `strokeDashoffset={-offset}` combined with `rotate(-90)` assumes a specific stroke direction. If a parent sets `direction: rtl` or a CSS transform, the arc winds the wrong way.
**Affected Files:** `DonutChart.jsx`, parent stylesheets
**Fix:** Isolate the SVG from inherited `direction`/transform, or document the assumption.
**Category:** framework
**Example:**
```javascript
strokeDashoffset={-offset} // sign depends on rotate + dash direction
```

### `role="img"` without `aria-label` is an accessibility dead-end
**Trigger:** The SVG has `role="img"` but no accessible name; `<title>` on inner `<circle>` elements is not reliably announced as the image's label. Screen readers announce an unnamed image.
**Affected Files:** `DonutChart.jsx`
**Fix:** Add `aria-label` summarizing the chart, or use `<title>`/`<desc>` as a direct SVG child referenced by `aria-labelledby`.
**Category:** framework
**Example:**
```javascript
<svg role="img" aria-label={`Donut chart, total ${total}`} ...>
```

### `total > 0` guard hides valid empty/all-zero states poorly
**Trigger:** If all values are 0, `total` is 0, no segments render, and the center shows `0` over a bare track — acceptable, but if `data` is `[]`, `.reduce` gives 0 too and the legend is empty. Passing `data={undefined}` throws (`Cannot read reduce of undefined`).
**Affected Files:** `DonutChart.jsx`
**Fix:** Default `data = []` in props destructuring and handle the empty legend explicitly.
**Category:** type-system
**Example:**
```javascript
export default function DonutChart({ data = [], ... }) {
```

### Hardcoded text offsets (`c - 2`, `c + 16`) break at small sizes
**Trigger:** The center total/label positions use fixed pixel offsets, not relative to `size`. At `size={40}` the two text lines overlap or overflow the ring.
**Affected Files:** `DonutChart.jsx`
**Fix:** Scale offsets relative to `size` or font size.
**Category:** performance
**Example:**
```javascript
<text y={c - 2}> ... <text y={c + 16}> // fixed 18px apart regardless of size
```

### Re-render cost: full recompute every render, no memoization
**Trigger:** `total`, geometry, and both `.map()` passes recompute on every parent render even when `data` is unchanged. For large `data` arrays inside frequently-updating dashboards this is wasteful.
**Affected Files:** `DonutChart.jsx`
**Fix:** Wrap component in `React.memo` and/or `useMemo` the segment computation keyed on `data`.
**Category:** performance
**Example:**
```javascript
const segments = useMemo(() => computeSegments(data, ...), [data]);
```