---
id: b2d6c8c5-349a-59fe-a26d-74b87e899a1a
type: gotcha
title: "Client Gotchas"
created_at: 2026-07-30T17:26:57.822765+00:00
updated_at: 2026-07-30T17:26:57.822779+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js
metadata:
  module_name: "frontend.src.api.client"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Client Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/api/client.js`

# Gotchas and Pitfalls: `frontend.src.api.client`

### Module-level mutable actor state is a hidden global

**Trigger:** `currentActorId` is a module-scoped `let`. Any code that calls `setActor` mutates a shared global that every subsequent request reads. There's no scoping per-tab, per-request, or per-component.

**Affected Files:** `frontend/src/api/client.js`, plus any caller relying on the actor being stable across concurrent requests.

**Fix:** Pass the actor explicitly, or use a context/store with clear ownership. If you must keep the global, document that all requests share it and that changing actors mid-flight affects in-flight requests unpredictably.

**Category:** thread-safety

**Example:**
```javascript
setActor(5);
const p1 = listUsers();      // reads actor... but header is built inside request
setActor(9);
const p2 = getCurrentUser(); // both may end up sending X-Actor-Id: 9
```
Because the header is built synchronously inside `request` at call time, `p1` actually captures actor 5 here — but any refactor that defers header construction (interceptor, retry) will silently break this. The correctness is accidental, not guaranteed.

---

### `status` / `action` falsy filter drops legitimate values

**Trigger:** `listUsers(status)` and `listAudit(action)` use `status ? ... : ""`. Any falsy value (empty string `""`, `0`) is treated as "no filter." A caller passing `status=""` expecting to filter by an empty status gets *all* users instead.

**Affected Files:** `frontend/src/api/client.js`

**Fix:** Check `!= null` (or `status !== undefined`) instead of truthiness.

**Category:** type-system

**Example:**
```javascript
listUsers("");  // query = "" → GET /api/users (no filter, silently returns everything)
```

---

### `204` check ignores other empty-body responses

**Trigger:** `request` only special-cases `204` for skipping `response.json()`. Endpoints returning `200`/`201` with an empty body (or `text/plain`) will throw when `.json()` fails on empty content.

**Affected Files:** `frontend/src/api/client.js`. Notably `deleteUser` (`DELETE`) and `setUserStatus` (`PATCH`) — whether they return 204 depends entirely on the backend.

**Fix:** Guard on `Content-Length`/empty body, or inspect `Content-Type`, rather than hardcoding `204`.

**Category:** async

**Example:**
```javascript
// Backend returns 200 with empty body
await deleteUser(3); // response.json() → SyntaxError: Unexpected end of JSON input
```

---

### Error parsing assumes JSON error bodies with `.detail`

**Trigger:** On `!response.ok`, the code does `response.json().catch(() => ({}))` and reads `payload.detail`. If the backend returns an HTML error page (proxy 502, gateway timeout) or a different error schema, the user gets a generic `"METHOD url failed (status)"` message masking the real cause.

**Affected Files:** `frontend/src/api/client.js`

**Fix:** Fall back to `response.text()` or include the raw body when JSON parse fails; standardize the backend error envelope.

**Category:** framework

**Example:**
```javascript
// Backend proxy returns 502 with HTML
// User sees: "GET /api/users failed (502)" — no hint it was the proxy
```

---

### `fetch` does not reject on HTTP errors — but also not on all failures uniformly

**Trigger:** Developers often forget `fetch` only rejects on network failure. This code handles `!ok` correctly, but network errors (offline, CORS, DNS) throw a raw `TypeError: Failed to fetch` *before* reaching the `!ok` block, bypassing the friendly error message entirely.

**Affected Files:** `frontend/src/api/client.js`, all callers.

**Fix:** Wrap `await fetch(...)` in try/catch to normalize network errors into the same `Error` shape callers expect.

**Category:** async

**Example:**
```javascript
// offline
await getUser(1); // throws TypeError, not "GET /api/users/1 failed (...)"
```

---

### No URL encoding of path parameters

**Trigger:** `userId` and `roleIds` are interpolated directly into URLs (`/api/users/${userId}`). If `userId` is ever a string (from a text input, or a value containing `/`, spaces, or query chars), the path breaks or hits the wrong route.

**Affected Files:** `frontend/src/api/client.js` — `getUser`, `updateUser`, `setUserStatus`, `assignRoles`, `deleteUser`.

**Fix:** Use `encodeURIComponent(userId)` for path segments, as is already done for query strings.

**Category:** type-system

**Example:**
```javascript
getUser("1/roles"); // GET /api/users/1/roles — silently hits a different endpoint
```

---

### `body !== undefined` sends `null`/empty bodies

**Trigger:** The body guard checks `!== undefined`, so passing `null` explicitly (`createUser(null)`) serializes `"null"` as the request body. Functions like `deleteUser` and `listRoles` omit body correctly, but callers can accidentally send `null`.

**Affected Files:** `frontend/src/api/client.js`

**Fix:** Also skip serialization for `null`, or validate payloads before calling.

**Category:** type-system

**Example:**
```javascript
createUser(null); // options.body = "null", backend may 400 or misinterpret
```

---

### `Content-Type: application/json` sent even on bodiless GET/DELETE

**Trigger:** The header is always set, including for `GET`/`DELETE` requests with no body. Strict backends or CORS preflight rules may reject or add an unnecessary preflight `OPTIONS` request for every GET.

**Affected Files:** `frontend/src/api/client.js`

**Fix:** Only set `Content-Type` when a body is present.

**Category:** performance

**Example:**
```javascript
listUsers(); // triggers CORS preflight due to non-simple Content-Type header
```

---

### Actor ID `0` is coerced to string but conceptually falsy elsewhere

**Trigger:** `String(currentActorId)` handles `0` fine (`"0"`), but if any downstream logic treats actor `0` as "no actor" (falsy), you get inconsistent behavior. Also `setActor(undefined)` yields header `"undefined"`.

**Affected Files:** `frontend/src/api/client.js`, `setActor`

**Fix:** Validate the id in `setActor` (`Number.isInteger`) and reject invalid actors early.

**Category:** type-system

**Example:**
```javascript
setActor(undefined);
getCurrentUser(); // sends X-Actor-Id: "undefined"
```

---

### Silent dependency on `USER_STATUS` constant matching backend enum

**Trigger:** `deactivateUser`/`reactivateUser` send `USER_STATUS.DEACTIVATED`/`ACTIVE`. If the frontend constant drifts from the backend's accepted status strings, requests fail at runtime with no compile-time safety.

**Affected Files:** `frontend/src/api/client.js`, `frontend/src/constants.js`, backend status validation.

**Fix:** Generate the constants from a shared schema, or add integration tests asserting the values.

**Category:** domain

**Example:**
```javascript
// constants.js: DEACTIVATED = "inactive"
// backend expects "deactivated" → PATCH silently 400s
```