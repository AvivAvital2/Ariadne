---
id: 98eb86d0-4da5-5101-afd6-50e807b8bc0d
type: catalog
title: "backend.app.services.roles.role"
created_at: 2026-07-30T15:09:17.243573+00:00
updated_at: 2026-07-30T17:48:08.855038+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.services.roles.role"
  signature: "role = Role(name=name, description=description)"
  location: {'line_start': 25, 'line_end': 25, 'col_start': 4, 'col_end': 51}
  parent_qualified_name: None
  sha_at_sync: "238dbc41c391bb8ef336d3b63b91b0d8cc5b74aa19159e6c5ed6b43a0ac29908"
  description: "Instantiates a new `Role` object using the provided `name` and `description` values."
---
# backend.app.services.roles.role

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

variable backend.app.services.roles.role [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py:25-25 :: role = Role(name=name, description=description)

Description: Instantiates a new `Role` object using the provided `name` and `description` values.

## Related Documents

- [backend.app.services.roles.create_role](9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53.md) - Related (graph distance 1.39)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 1.53)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 1.62)
- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 2.76)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 2.76)
- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 2.83)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 2.91)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 2.94)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 2.96)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.97)
