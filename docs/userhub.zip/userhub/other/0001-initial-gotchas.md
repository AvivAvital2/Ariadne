---
id: bcbecc90-c8d6-549a-9661-21dabe59fb26
type: gotcha
title: "0001 Initial Gotchas"
created_at: 2026-07-30T17:20:59.353211+00:00
updated_at: 2026-07-30T17:20:59.353226+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  module_name: "backend.alembic.versions.0001_initial"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# 0001 Initial Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

# Gotchas & Pitfalls: `0001_initial` Migration

### No server-side default for `created_at`/`updated_at`
**Trigger:** `created_at` and `updated_at` are `nullable=False` but have **no** `server_default`. Any INSERT that omits these columns will fail at the DB level unless the application always supplies them.
**Affected Files:** `0001_initial.py`
**Fix:** Add `server_default=sa.func.now()` (or ensure ORM defaults always populate them). For `updated_at`, consider `onupdate` in the model layer since DDL can't express that portably.
**Category:** framework
**Example:**
```python
# INSERT INTO users (username, email) VALUES (...) -> IntegrityError
sa.Column("created_at", sa.DateTime, nullable=False,
          server_default=sa.func.now())
```

### `sa.DateTime` without timezone awareness
**Trigger:** `sa.DateTime` maps to a timezone-naive column. Storing UTC-aware datetimes silently strips tzinfo on some backends, causing off-by-hours bugs when comparing/serializing.
**Affected Files:** `0001_initial.py`
**Fix:** Use `sa.DateTime(timezone=True)` for `created_at`, `updated_at`, `audit_log.created_at`.
**Category:** type-system
**Example:**
```python
sa.Column("created_at", sa.DateTime(timezone=True), nullable=False)
```

### Foreign keys without explicit `ondelete` — orphan / restrict surprises
**Trigger:** `user_roles`, `role_permissions`, and `audit_log.actor_id` FKs default to `NO ACTION`/`RESTRICT`. Deleting a user with role assignments or audit rows will fail unexpectedly, or (on backends without FK enforcement) leave orphans.
**Affected Files:** `0001_initial.py`
**Fix:** Decide intent explicitly. Association tables usually want `ondelete="CASCADE"`; `audit_log.actor_id` typically wants `ondelete="SET NULL"` (it's already nullable).
**Category:** domain
**Example:**
```python
sa.ForeignKey("users.id", ondelete="CASCADE")   # user_roles
sa.ForeignKey("users.id", ondelete="SET NULL")  # audit_log.actor_id
```

### Unnamed constraints break future downgrades/alters
**Trigger:** No naming convention is set. Alembic autogenerates DB-dependent constraint names (unique, FK, index). A later migration that tries to `drop_constraint("users_email_key", ...)` may fail because the name differs across SQLite/Postgres/MySQL.
**Affected Files:** `0001_initial.py` (and `env.py` where the naming convention should live)
**Fix:** Configure a `naming_convention` on `MetaData` in `env.py`/models so all constraints have deterministic names.
**Category:** framework
**Example:**
```python
convention = {"uq": "uq_%(table_name)s_%(column_0_name)s",
              "fk": "fk_%(table_name)s_%(column_0_name)s"}
metadata = sa.MetaData(naming_convention=convention)
```

### Redundant `ix_users_username` index on a unique column
**Trigger:** `username` already declares `unique=True`, which creates a backing unique index. The extra `create_index("ix_users_username", ...)` produces a second, redundant B-tree — wasted write/storage overhead.
**Affected Files:** `0001_initial.py`
**Fix:** Drop the explicit index, or drop `unique=True` and make the index unique instead. Same duplication does *not* apply to `audit_log.action`/`created_at` (those columns aren't unique, so those indexes are legitimate).
**Category:** performance
**Example:**
```python
sa.Column("username", sa.String(64), nullable=False, unique=True)
# op.create_index("ix_users_username", ...)  # redundant, remove
```

### SQLite ignores string length limits — silent portability trap
**Trigger:** `sa.String(64)` etc. imply length constraints. SQLite ignores length entirely, so tests pass locally with over-length values while Postgres/MySQL truncate or raise. `String(255)` for email may also be too short for RFC-max emails (up to 254 is fine, but full_name/description at 255 can silently reject).
**Affected Files:** `0001_initial.py`
**Fix:** Validate lengths in the app layer regardless of DB; don't rely on DB truncation behavior being consistent.
**Category:** framework
**Example:**
```python
# Passes on SQLite, raises on Postgres:
insert(username="x" * 200)  # String(64) exceeded
```

### `downgrade()` drop order fragile w.r.t. FK enforcement
**Trigger:** The tuple order (`audit_log` → ... → `users`) works because children precede parents. But if the schema evolves (new FK added to `audit_log`), the hard-coded list won't be updated and drops may fail with FK violation on strict backends.
**Affected Files:** `0001_initial.py`
**Fix:** Keep the ordering, but this is a maintenance landmine — document the dependency, or use `op.drop_table` with cascade where supported. On SQLite the ordering doesn't matter (FKs off by default), masking the bug until Postgres.
**Category:** domain
**Example:**
```python
# If a future FK from audit_log -> roles is added and roles is dropped first:
# psycopg2.errors.DependentObjectsStillExist
```

### `server_default="invited"` couples domain enum to a migration
**Trigger:** `status` uses a free-form `String(32)` with a string default rather than an enum. Typos like `"invted"` are accepted silently; there's no DB-level guarantee of valid states.
**Affected Files:** `0001_initial.py`
**Fix:** Use `sa.Enum(...)` or a `CheckConstraint` to enforce the allowed status set. Note `sa.Enum` on Postgres creates a type object that must be dropped in `downgrade()`.
**Category:** type-system
**Example:**
```python
sa.Column("status", sa.String(32), nullable=False, server_default="invited")
# UPDATE users SET status='actve';  # accepted, breaks app logic
```

### No unique constraint on association-table pairs beyond composite PK — fine, but no covering index for reverse lookups
**Trigger:** `user_roles` composite PK `(user_id, role_id)` indexes leading `user_id` well, but queries filtering by `role_id` alone (e.g., "all users with this role") do a full scan.
**Affected Files:** `0001_initial.py`
**Fix:** Add a secondary index on `role_id` (and `permission_id` in `role_permissions`) if reverse lookups are common.
**Category:** performance
**Example:**
```python
op.create_index("ix_user_roles_role_id", "user_roles", ["role_id"])
```

### Migration not wrapped for non-transactional DDL backends
**Trigger:** MySQL (and some others) auto-commit DDL, so a failure midway through `upgrade()` leaves the schema half-created with no rollback. Alembic can't undo it automatically.
**Affected Files:** `0001_initial.py`
**Fix:** On such backends, ensure re-run safety or use `IF NOT EXISTS` patterns; on Postgres/SQLite transactional DDL protects you, hiding the risk during dev.
**Category:** framework
**Example:**
```python
# On MySQL: users+roles created, permissions fails -> partial schema persists
```