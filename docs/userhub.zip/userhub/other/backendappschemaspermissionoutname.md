---
id: 2153ab49-fcf1-5e7c-9187-d798d625c592
type: catalog
title: "backend.app.schemas.PermissionOut.name"
created_at: 2026-07-30T15:09:16.664995+00:00
updated_at: 2026-07-30T17:48:08.790883+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.PermissionOut.name"
  signature: "name: str"
  location: {'line_start': 17, 'line_end': 17, 'col_start': 4, 'col_end': 13}
  parent_qualified_name: "backend.app.schemas.PermissionOut"
  sha_at_sync: "919c21eb6c610117d05f4d2ccab283c85d79a73bb5e9b0661728f5f7be0b2cd2"
  description: "A required string field on the `PermissionOut` schema representing the permission's name."
---
# backend.app.schemas.PermissionOut.name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.PermissionOut.name in backend.app.schemas.PermissionOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:17-17 :: name: str

Description: A required string field on the `PermissionOut` schema representing the permission's name.

## Related Documents

- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 1.23)
- [backend.app.schemas.PermissionOut.description](7e1baaaf-7dae-50ef-aef6-81cdb4043b19.md) - Related (graph distance 1.31)
- [backend.app.models.Permission.name](138bf8d6-bae5-5c03-82d7-251391d53d05.md) - Related (graph distance 1.32)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 1.33)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 1.37)
- [backend.app.schemas.RoleOut.description](de00f3e4-a439-5e5f-a034-98d286d08613.md) - Related (graph distance 2.50)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 2.53)
- [backend.app.models.Permission.description](9fe1ddb1-931e-52dc-bec1-aa8b5cdbe620.md) - Related (graph distance 2.65)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 2.69)
