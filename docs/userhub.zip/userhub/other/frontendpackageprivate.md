---
id: 9984896f-c935-5cf4-a883-1ae0a7064a00
type: catalog
title: "frontend.package.private"
created_at: 2026-07-30T15:09:15.304679+00:00
updated_at: 2026-07-30T17:48:08.758189+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.private"
  signature: ""private": true"
  location: {'line_start': 3, 'line_end': 3, 'col_start': 2, 'col_end': 17}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "2d82b3042175f0695168156d5c73112c9b0fb5470452aea3341a7a830d1d6e64"
  description: "Marks the frontend package as private, preventing it from being accidentally published to the npm registry."
---
# frontend.package.private

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.private in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:3-3 :: "private": true

Description: Marks the frontend package as private, preventing it from being accidentally published to the npm registry.

## Related Documents

- [frontend.package.version](81db2b01-295a-5d17-8690-921565d0f57f.md) - Related (graph distance 1.50)
- [frontend.package.name](5cd9c91d-65aa-5c8e-8758-e05d8da0fb24.md) - Related (graph distance 1.52)
- [frontend.package.type](86b6bbb8-5d01-5248-b215-0af6c335ce3d.md) - Related (graph distance 1.57)
- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.58)
- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 1.60)
