---
id: 615f8eda-2904-584c-b40d-155209a9f94d
type: gotcha
title: "Rolemanager Gotchas"
created_at: 2026-07-30T17:27:53.521566+00:00
updated_at: 2026-07-30T17:27:53.521579+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx
metadata:
  module_name: "frontend.src.components.RoleManager"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Rolemanager Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/RoleManager.jsx`

# RoleManager Gotchas & Pitfalls

### Stale closure / missing dependency in useEffect
**Trigger:** `load` is called inside `useEffect` but depends on `canManage` (derived from `actor`), yet the dependency array only lists `[actor]`. `load` is also redefined on every render but not memoized.
**Affected Files:** `RoleManager.jsx`
**Fix:** Either include a stable `load` via `useCallback` and list it in deps, or inline the logic. Since `canManage` derives from `actor`, current code works by luck but ESLint `react-hooks/exhaustive-deps` will complain and future edits may break it.
**Category:** framework
**Example:**
```javascript
useEffect(() => {
  if (actor) load(); // load() captures canManage from this render
}, [actor]); // eslint warns: load missing from deps
```

### Race condition on concurrent loads / component unmount
**Trigger:** If `actor` changes rapidly, or the component unmounts while `api.listRoles()` is in flight, `setRoles` is called after unmount or an older response overwrites a newer one (out-of-order resolution).
**Affected Files:** `RoleManager.jsx`
**Fix:** Track an abort/ignore flag or use AbortController.
**Category:** async
**Example:**
```javascript
useEffect(() => {
  let active = true;
  const run = async () => {
    const r = await api.listRoles();
    if (active) setRoles(r); // guard
  };
  if (actor) run();
  return () => { active = false; };
}, [actor]);
```

### `createRole` calls `load()` without awaiting — unhandled rejection
**Trigger:** `load()` inside `createRole` is not awaited and returns a promise. If `load` throws (it won't, it catches internally, but the pattern is fragile), the error is silently dropped. Also `createRole` returns before the reload completes.
**Affected Files:** `RoleManager.jsx`
**Fix:** `await load();` for deterministic sequencing and error visibility.
**Category:** async
**Example:**
```javascript
setPermIds([]);
load(); // fire-and-forget; refresh may not be visible when function resolves
```

### Non-atomic double fetch clobbers error state
**Trigger:** In `load`, if `api.listRoles()` succeeds but `api.listPermissions()` fails, `roles` gets updated but then `catch` sets an error — leaving UI in a half-updated state (new roles shown alongside an error).
**Affected Files:** `RoleManager.jsx`
**Fix:** Fetch both in parallel with `Promise.all` and only commit state on full success.
**Category:** async
**Example:**
```javascript
const [r, p] = await Promise.all([
  api.listRoles(),
  canManage ? api.listPermissions() : Promise.resolve([]),
]);
setRoles(r); setPermissions(p);
```

### Assumes `role.permissions` is always an array
**Trigger:** `role.permissions.map(...)` will throw `Cannot read properties of undefined (reading 'map')` if the API returns a role without a `permissions` field or with `null`.
**Affected Files:** `RoleManager.jsx`, API response contract
**Fix:** Default with `(role.permissions ?? []).map(...)`.
**Category:** type-system
**Example:**
```javascript
{role.permissions.map((p) => ...)} // throws if permissions is null/undefined
```

### `permIds.includes(perm.id)` — type mismatch on IDs
**Trigger:** If checkbox `perm.id` is a number but `permIds` gets populated elsewhere with string IDs (or vice versa from serialization), `includes` uses strict equality (`===`) and will silently fail to match, showing unchecked boxes / wrong selections.
**Affected Files:** `RoleManager.jsx`
**Fix:** Normalize ID types consistently (e.g., coerce all to string) when storing.
**Category:** type-system
**Example:**
```javascript
permIds.includes(perm.id) // "5" !== 5 → box appears unchecked
```

### Permissions never load if `canManage` was false at first load, then becomes true
**Trigger:** `load` only fetches permissions when `canManage` is true. Since `canManage` derives from `actor` and `useEffect` triggers on `actor` change, this mostly works — but if permission grants change without an `actor` object change (e.g., token refresh with same actor ref), the form renders with an empty permissions list.
**Affected Files:** `RoleManager.jsx`, `permissions.js`
**Fix:** Make `canManage` a proper dependency or refetch when permission state changes.
**Category:** framework
**Example:**
```javascript
if (canManage) setPermissions(await api.listPermissions());
// actor unchanged but permission upgraded → permissions stay []
```

### Client-side `canManage` gate is not security
**Trigger:** Hiding the "New role" form when `!canManage` only affects UI. A user can still call `api.createRole` directly. Developers may assume this is an authorization boundary.
**Affected Files:** `RoleManager.jsx`, backend API
**Fix:** Enforce `ROLES_MANAGE` server-side; treat client gating as UX only.
**Category:** domain
**Example:**
```javascript
{canManage && (<section>...create form...</section>)} // cosmetic only
```

### Missing loading state — flash of "0 roles" and empty tables
**Trigger:** Initial state is `roles=[]`, so before the first fetch resolves the UI shows "0 roles" which is misleading (looks like empty vs. loading).
**Affected Files:** `RoleManager.jsx`
**Fix:** Add a `loading` boolean, render a spinner/skeleton until first fetch completes.
**Category:** framework
**Example:**
```javascript
<span className="card-sub">{roles.length} roles</span> // shows "0 roles" while loading
```

### Uncontrolled-to-controlled input risk if state initialized undefined
**Trigger:** Not an issue here (initialized to `""`), but note: if `name`/`description` ever became `undefined` (e.g., set from `role.description` which may be null), the input flips to uncontrolled and React warns.
**Affected Files:** `RoleManager.jsx`
**Fix:** Always coerce with `value={name ?? ""}`.
**Category:** framework
**Example:**
```javascript
<input value={description} ... /> // if description becomes null → warning
```

### Error message assumes `e.message` exists
**Trigger:** `setError(e.message)` — if the thrown value is a plain string, an object, or a network failure without `.message`, `error` becomes `undefined` and the `{error && ...}` block silently hides the failure.
**Affected Files:** `RoleManager.jsx`, `api/client.js`
**Fix:** `setError(e?.message ?? String(e) ?? "Unknown error")`.
**Category:** type-system
**Example:**
```javascript
catch (e) { setError(e.message); } // throw "boom" → error = undefined → no display
```

### No duplicate-submit protection on create
**Trigger:** The submit button stays enabled during the async `createRole`. Rapid double-clicks fire multiple `api.createRole` calls, potentially creating duplicate roles.
**Affected Files:** `RoleManager.jsx`
**Fix:** Disable the button / set a `submitting` flag while the request is in flight.
**Category:** async
**Example:**
```javascript
<button type="submit">Create role</button> // clickable during pending request
```