---
id: d9f0755a-497e-52a9-be2e-4103bced037f
type: catalog
title: "backend.app.services.users.query"
created_at: 2026-07-30T15:09:17.214495+00:00
updated_at: 2026-07-30T17:48:08.852248+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.services.users.query"
  signature: "query = query.filter(User.status == status)"
  location: {'line_start': 31, 'line_end': 31, 'col_start': 8, 'col_end': 51}
  parent_qualified_name: None
  sha_at_sync: "0b671c6bcd779df2bb4e5b50b2c2afbb08dcdc17e3c8f95665c1f0c9ba9640eb"
  description: "Reassigns the `query` variable to apply a filter on the `User.status` column, narrowing the query results to users matching the specified `status` value."
---
# backend.app.services.users.query

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

variable backend.app.services.users.query [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:31-31 :: query = query.filter(User.status == status)

Description: Reassigns the `query` variable to apply a filter on the `User.status` column, narrowing the query results to users matching the specified `status` value.

## Related Documents

- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 1.45)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.65)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 2.82)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.90)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 2.96)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 3.03)
- [backend.app.services.users._status_action](a100999f-8f51-5b17-8363-7b7149d8f7e6.md) - Related (graph distance 3.08)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 3.11)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 3.19)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 3.28)
