---
id: d6bb5654-5a74-5e11-9bff-dc35e616fcd9
type: catalog
title: "backend.alembic.env.url"
created_at: 2026-07-30T15:09:16.527345+00:00
updated_at: 2026-07-30T17:48:08.784694+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.alembic.env.url"
  signature: "url = config.get_main_option("sqlalchemy.url")"
  location: {'line_start': 23, 'line_end': 23, 'col_start': 4, 'col_end': 50}
  parent_qualified_name: None
  sha_at_sync: "ee7a0aeddabbc56163142c70bfa0629a4edce8cfd7c6728a5c7339e042a2a1ca"
  description: "Retrieves the SQLAlchemy database connection URL from the Alembic configuration's main options for use in offline migration mode."
---
# backend.alembic.env.url

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

variable backend.alembic.env.url [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py:23-23 :: url = config.get_main_option("sqlalchemy.url")

Description: Retrieves the SQLAlchemy database connection URL from the Alembic configuration's main options for use in offline migration mode.

## Related Documents

- [backend.app.database.DATABASE_URL](9ba29e4a-068b-551e-a77b-051f1c6cb555.md) - Related (graph distance 1.59)
