---
id: 0856b56a-a188-5f68-94b0-04d0fb662a8b
type: catalog
title: "backend.alembic.env.connectable"
created_at: 2026-07-30T15:09:16.527688+00:00
updated_at: 2026-07-30T17:48:08.784473+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.alembic.env.connectable"
  signature: "connectable = engine_from_config("
  location: {'line_start': 35, 'line_end': 39, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "1c8977edfc66dd5d77a98427d4ea111ecb1fc25fe2776f111bc3e18a772a6ea9"
  description: "Creates a SQLAlchemy engine from the Alembic configuration section, using a NullPool to manage database connections for running migrations."
---
# backend.alembic.env.connectable

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

variable backend.alembic.env.connectable [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py:35-39 :: connectable = engine_from_config(

Description: Creates a SQLAlchemy engine from the Alembic configuration section, using a NullPool to manage database connections for running migrations.

## Related Documents

- [backend.app.database.engine](ed8e621f-9040-53be-86ac-6991010428d6.md) - Related (graph distance 1.62)
