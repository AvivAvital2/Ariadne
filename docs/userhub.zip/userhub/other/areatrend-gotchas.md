---
id: edea04ec-4dc3-56e1-97f9-89ed1e5db7ea
type: gotcha
title: "Areatrend Gotchas"
created_at: 2026-07-30T17:29:30.227744+00:00
updated_at: 2026-07-30T17:29:30.227757+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx
metadata:
  module_name: "frontend.src.components.charts.AreaTrend"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Areatrend Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/AreaTrend.jsx`

# Gotchas and Pitfalls: `AreaTrend`

### Missing/undefined `points` prop crashes the component
**Trigger:** Rendering `<AreaTrend />` without a `points` prop, or passing `null`.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Default the prop and guard: `points = []` in the destructure, and early-return for empty arrays.
**Category:** type-system
**Example:**
```javascript
export default function AreaTrend({ points, color, height }) {
  const n = points.length; // TypeError: Cannot read properties of undefined
```
`points.map(...)` and `Math.max(1, ...points.map(...))` also throw. Default it:
```javascript
export default function AreaTrend({ points = [], ... }) {
```

### `niceCeil` returns `NaN`/`Infinity` for empty or non-numeric data
**Trigger:** Empty `points` array makes `Math.max(1, ...[])` = `1` (OK), but if any `p.value` is `undefined`/`NaN`, `Math.max` returns `NaN`. Then `Math.log10(NaN)` cascades into broken geometry.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Coerce/validate values: `points.map(p => Number(p.value) || 0)`.
**Category:** type-system
**Example:**
```javascript
const points = [{ label: "a", value: undefined }];
niceCeil(Math.max(1, NaN)); // Math.log10(NaN) -> NaN, yAt returns NaN
// SVG paths become "34,NaN" -> silently invisible marks, no error
```

### Silent invisible rendering when SVG coords are `NaN`
**Trigger:** Any `NaN` in path/polyline coordinates. SVG doesn't throw — it just draws nothing, so bugs are hard to spot.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Validate `niceMax > 0` and all values numeric before building `line`/`area`. Log a warning in dev.
**Category:** framework
**Example:**
```javascript
const yAt = (v) => padT + plotH - (v / niceMax) * plotH;
// niceMax=NaN => every yAt is NaN => empty chart with no console error
```

### `key={i}` (array index) causes React reconciliation bugs
**Trigger:** `points` array reorders, or items are inserted/removed. Three separate maps use `key={i}` (circles, labels). React reuses DOM nodes incorrectly.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Use a stable key like `p.label` (if unique) or a data id.
**Category:** framework
**Example:**
```javascript
{points.map((p, i) => <circle key={i} .../>)}
// If points prepends a new point, all circles get "wrong" identity;
// hover state (an index) now points to a different logical data point.
```

### `hover` is an index but data can change underneath it — stale index
**Trigger:** `points` prop changes while `hover` holds an old index. `points[hover]` may reference a different point or be out of bounds after shrinking.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Reset hover when `points` identity changes (`useEffect(() => setHover(null), [points])`), or store a stable id instead of an index.
**Category:** framework
**Example:**
```javascript
// hover=5, then parent passes a 3-item array
points[hover]      // undefined -> guard saves the render, but
xAt(hover)         // uses n=3, produces a misplaced crosshair before guard
```
Note `points[hover]` guard catches undefined, but the crosshair block also relies on it — consistent, but the coordinate math (`xAt(hover)`) computed before guard would be wrong if reached.

### Duplicate/non-unique `p.label` breaks x-axis and keys
**Trigger:** Two points with the same label. Both `<text>` keys collide (`key` isn't label here—it's index, so OK), but axis labels overlap visually and tooltip is ambiguous.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Ensure labels are unique or truncate/rotate on overlap; consider showing every k-th label for dense data.
**Category:** domain
**Example:**
```javascript
points = [{label:"Mon",value:1},{label:"Mon",value:2}]
// two "Mon" labels drawn at overlapping x if n small
```

### Label overcrowding with many points (performance + readability)
**Trigger:** Large `n` (e.g. 200+ points). Every point renders a `<circle>`, `<text>`, and `<title>`. Labels overlap into an unreadable smear and DOM node count explodes.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Downsample labels (`i % step === 0`), and/or render markers only near hover for large datasets.
**Category:** performance
**Example:**
```javascript
{points.map((p, i) => <text ...>{p.label}</text>)}
// n=365 -> 365 text nodes all at y=H-8, fully overlapping
```

### `xAt` requires `n >= 1` in the tooltip/crosshair path but `n=0` still renders text/paths
**Trigger:** Empty array: `area` is `""` (handled), but `ticks` uses `niceMax` from `Math.max(1)` = 1 (OK). However the `line` = `""` polyline is fine. No crash, but `n <= 1` centering path can surprise with a single-point line being invisible (polyline of one point draws nothing).
**Affected Files:** `AreaTrend.jsx`
**Fix:** For single point, render an explicit marker (already done via `<circle>`), and consider a fallback message for empty data.
**Category:** framework
**Example:**
```javascript
n === 1 => line = "34,100" // polyline with one point draws no line; only the circle shows
```

### Tooltip `left` percentage doesn't account for SVG padding/aspect scaling
**Trigger:** The div tooltip is positioned via `(xAt(hover)/W)*100%` of the *container* width, but the SVG's aspect-ratio scaling and the padL/padR offsets mean the tooltip may be misaligned relative to the actual mark, especially if CSS constrains the SVG height differently.
**Affected Files:** `AreaTrend.jsx`, chart CSS
**Fix:** Ensure the tooltip's containing `.area-chart` has the same width as the rendered SVG; use `transform: translateX(-50%)` to center on the point.
**Category:** framework
**Example:**
```javascript
style={{ left: `${(xAt(hover) / W) * 100}%` }}
// left edge of tooltip at the point, not centered; drifts if container != SVG width
```

### `onMouseMove` reads `getBoundingClientRect` on every mouse move (layout thrash)
**Trigger:** Rapid mouse movement over the SVG triggers `onMove` continuously; each call forces a synchronous layout read (`getBoundingClientRect`) plus a full `points.forEach` scan and a `setState`.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Cache the rect (recompute on resize), debounce/throttle hover updates, and skip `setState` when the index is unchanged.
**Category:** performance
**Example:**
```javascript
const onMove = (e) => {
  const rect = e.currentTarget.getBoundingClientRect(); // forced reflow each move
  ...
  setHover(best); // re-render even when best === hover
};
```
Add: `if (best !== hover) setHover(best);`

### Nearest-point search ignores when cursor is far outside all points
**Trigger:** Mouse anywhere in the SVG (even in padding regions far from any point) always snaps `hover` to the closest index — there's no "no hover" threshold.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Only set hover when `bestD` is within a reasonable pixel radius; else `setHover(null)`.
**Category:** domain
**Example:**
```javascript
// cursor at far right padding still highlights last point + tooltip
if (bestD > plotW / n) setHover(null); else setHover(best);
```

### `niceCeil(v)` assumes `v > 0`; `Math.log10(0)` = `-Infinity`
**Trigger:** Guarded by `Math.max(1, ...)` in usage, but the function is unsafe standalone. If reused elsewhere with `v <= 0` (and >5 branch reached differently), `Math.log10(0)` = `-Infinity` → `Math.pow(10,-Infinity)=0` → division by zero.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Add internal guard `if (v <= 0) return 5;` or document precondition.
**Category:** type-system
**Example:**
```javascript
niceCeil(0); // returns 5 via the v<=5 branch, OK — but the branch order hides it
niceCeil(-3); // also returns 5, silently ignoring negative data
```

### Negative values render below the baseline / outside plot
**Trigger:** A point with a negative `value`. `niceMax` ignores negatives (Math.max), and `yAt(negative)` produces a `y` greater than `baseY`, drawing below the axis and outside the viewBox area.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Either clamp to 0, or compute a proper min/max domain and shift the baseline.
**Category:** domain
**Example:**
```javascript
yAt(-10) // = padT + plotH + (10/niceMax)*plotH  -> below baseline, clipped/off-canvas
```

### `color` prop is injected directly into SVG attributes (no validation)
**Trigger:** Passing an untrusted/invalid color string. Invalid values silently render as black (SVG default) or nothing; there's no sanitization but also no XSS vector here since it's an attribute value, not markup.
**Affected Files:** `AreaTrend.jsx`
**Fix:** Validate color format if it comes from user input; provide a safe fallback.
**Category:** framework
**Example:**
```javascript
<path fill={color} .../> // color="not-a-color" -> fill ignored, area invisible
```