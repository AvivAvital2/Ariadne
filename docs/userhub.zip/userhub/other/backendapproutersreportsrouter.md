---
id: bad66bc7-e773-5982-a06f-097d09219abb
type: catalog
title: "backend.app.routers.reports.router"
created_at: 2026-07-30T15:09:16.803583+00:00
updated_at: 2026-07-30T17:48:08.847963+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.routers.reports.router"
  signature: "router = APIRouter(tags=["reports"])"
  location: {'line_start': 18, 'line_end': 18, 'col_start': 0, 'col_end': 36}
  parent_qualified_name: None
  sha_at_sync: "c2c7cd3ea2bda0031e05d7b625b212dde122135d11cebde34f394371a5aeb477"
  description: "Module-level FastAPI APIRouter instance tagged with "reports" that groups and registers the report-related HTTP endpoints defined in this router module."
---
# backend.app.routers.reports.router

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

variable backend.app.routers.reports.router [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py:18-18 :: router = APIRouter(tags=["reports"])

Description: Module-level FastAPI APIRouter instance tagged with "reports" that groups and registers the report-related HTTP endpoints defined in this router module.

## Related Documents

- [backend.app.routers.roles.router](3f73e456-0011-5a56-95f4-2a52726b2db7.md) - Related (graph distance 1.24)
- [backend.app.routers.audit.router](f6e3ecc8-46b5-5b7c-b973-bef6ba750d07.md) - Related (graph distance 1.28)
- [backend.app.routers.users.router](4234b282-fa44-59ed-a663-636c40c44d88.md) - Related (graph distance 1.30)
