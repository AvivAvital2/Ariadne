---
id: 4e1645db-d364-5489-8771-5ec8b957913b
type: catalog
title: "backend.app.models.AuditLog.action"
created_at: 2026-07-30T15:09:15.726356+00:00
updated_at: 2026-07-30T17:48:08.771605+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.action"
  signature: "action: Mapped[str] = mapped_column(String(64), index=True)"
  location: {'line_start': 88, 'line_end': 88, 'col_start': 4, 'col_end': 63}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "c7e1a8c03d79be8b92894e3efce0707b4afe1bec45ecea0d89cebef80dce1591"
  description: "Stores the type of action performed (e.g., create, update, delete) for an audit log entry, limited to 64 characters and indexed for efficient querying."
---
# backend.app.models.AuditLog.action

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.action in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:88-88 :: action: Mapped[str] = mapped_column(String(64), index=True)

Description: Stores the type of action performed (e.g., create, update, delete) for an audit log entry, limited to 64 characters and indexed for efficient querying.

## Related Documents

- [backend.app.schemas.AuditLogOut.action](bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d.md) - Related (graph distance 1.38)
- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 1.55)
