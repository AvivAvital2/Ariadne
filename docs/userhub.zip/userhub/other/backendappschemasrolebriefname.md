---
id: 7dbad144-b596-57d8-97be-5c819d401c07
type: catalog
title: "backend.app.schemas.RoleBrief.name"
created_at: 2026-07-30T15:09:16.664155+00:00
updated_at: 2026-07-30T17:48:08.789842+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleBrief.name"
  signature: "name: str"
  location: {'line_start': 11, 'line_end': 11, 'col_start': 4, 'col_end': 13}
  parent_qualified_name: "backend.app.schemas.RoleBrief"
  sha_at_sync: "919c21eb6c610117d05f4d2ccab283c85d79a73bb5e9b0661728f5f7be0b2cd2"
  description: "A required string field on the `RoleBrief` schema representing the role's name."
---
# backend.app.schemas.RoleBrief.name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleBrief.name in backend.app.schemas.RoleBrief [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:11-11 :: name: str

Description: A required string field on the `RoleBrief` schema representing the role's name.

## Related Documents

- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 1.14)
- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 1.17)
- [backend.app.schemas.PermissionOut.name](2153ab49-fcf1-5e7c-9187-d798d625c592.md) - Related (graph distance 1.33)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 1.35)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.43)
- [backend.app.schemas.RoleOut.description](de00f3e4-a439-5e5f-a034-98d286d08613.md) - Related (graph distance 2.46)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 2.46)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.50)
- [backend.app.models.Permission.name](138bf8d6-bae5-5c03-82d7-251391d53d05.md) - Related (graph distance 2.56)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.61)
