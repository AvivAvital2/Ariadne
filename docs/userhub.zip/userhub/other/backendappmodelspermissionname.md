---
id: 138bf8d6-bae5-5c03-82d7-251391d53d05
type: catalog
title: "backend.app.models.Permission.name"
created_at: 2026-07-30T15:09:15.724707+00:00
updated_at: 2026-07-30T17:48:08.770066+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Permission.name"
  signature: "name: Mapped[str] = mapped_column(String(64), unique=True)"
  location: {'line_start': 74, 'line_end': 74, 'col_start': 4, 'col_end': 62}
  parent_qualified_name: "backend.app.models.Permission"
  sha_at_sync: "03f74c4e07fde757cf3d1dd731606b02795c98c7cdd490f5cc6aeddec4e8ca42"
  description: "Defines the unique name identifier for a Permission, stored as a required string column with a maximum length of 64 characters."
---
# backend.app.models.Permission.name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Permission.name in backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:74-74 :: name: Mapped[str] = mapped_column(String(64), unique=True)

Description: Defines the unique name identifier for a Permission, stored as a required string column with a maximum length of 64 characters.

## Related Documents

- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 1.21)
- [backend.app.schemas.PermissionOut.name](2153ab49-fcf1-5e7c-9187-d798d625c592.md) - Related (graph distance 1.32)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 1.42)
- [backend.app.models.Permission.description](9fe1ddb1-931e-52dc-bec1-aa8b5cdbe620.md) - Related (graph distance 1.43)
- [backend.app.schemas.RoleOut.name](9c60447e-869d-558d-b062-9fa4de81726d.md) - Related (graph distance 2.55)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 2.55)
- [backend.app.schemas.RoleBrief.name](7dbad144-b596-57d8-97be-5c819d401c07.md) - Related (graph distance 2.56)
- [backend.app.models.Role.description](05e42cb4-46a0-51af-998b-59dfc35bf5ff.md) - Related (graph distance 2.56)
