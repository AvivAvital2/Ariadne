---
id: d97dd893-81dd-5cf9-8da9-574a2350ea83
type: catalog
title: "frontend.package.scripts"
created_at: 2026-07-30T15:09:15.305789+00:00
updated_at: 2026-07-30T17:48:08.759591+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.scripts"
  signature: ""scripts": {"
  location: {'line_start': 6, 'line_end': 10, 'col_start': 2, 'col_end': 3}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "74ee3c130f0acfd4f4502f0e94b7510df1e3a7fd4bc7e2927fcf82550c405b0b"
  description: "Defines npm-runnable command aliases for the frontend package, mapping script names to their corresponding shell commands for tasks like building, testing, and running the development server."
---
# frontend.package.scripts

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.scripts in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:6-10 :: "scripts": {

Description: Defines npm-runnable command aliases for the frontend package, mapping script names to their corresponding shell commands for tasks like building, testing, and running the development server.

## Related Documents

- [frontend.package.name](5cd9c91d-65aa-5c8e-8758-e05d8da0fb24.md) - Related (graph distance 1.49)
- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.51)
- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 1.54)
