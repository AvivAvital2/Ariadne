---
id: 4812f216-0e13-559b-a92b-775594d7d639
type: catalog
title: "backend.app.services.users._validate_transition"
created_at: 2026-07-30T15:09:17.213608+00:00
updated_at: 2026-07-30T17:17:40.882328+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users._validate_transition"
  signature: "def _validate_transition(current: str, target: str) -> None:"
  location: {'line_start': 152, 'line_end': 161, 'col_start': 0, 'col_end': 9}
  parent_qualified_name: None
  sha_at_sync: "b2bb469da90eddacd54cd07114086e1f4d1fe2954834f69b3e9da890977960e1"
  description: "Validates whether a user status change from `current` to `target` is permitted, raising an exception if the transition is not allowed."
---
# backend.app.services.users._validate_transition

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users._validate_transition [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:152-161 :: def _validate_transition(current: str, target: str) -> None:

Description: Validates whether a user status change from `current` to `target` is permitted, raising an exception if the transition is not allowed.