---
id: 068b4d0c-4d8a-544e-93e4-8e6677d000bf
type: catalog
title: "backend.app.services.users.full_name"
created_at: 2026-07-30T15:09:17.215359+00:00
updated_at: 2026-07-30T17:48:08.852760+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.services.users.full_name"
  signature: "user.full_name = full_name"
  location: {'line_start': 92, 'line_end': 92, 'col_start': 8, 'col_end': 34}
  parent_qualified_name: None
  sha_at_sync: "3ff8fdf587bc1dff111c5d789d4ba61bc69632ad036285d8c3e6fd07b2c33c3b"
  description: "Assigns the provided `full_name` value to the `full_name` attribute of the `user` object, updating the user's display name."
---
# backend.app.services.users.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

variable backend.app.services.users.full_name [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:92-92 :: user.full_name = full_name

Description: Assigns the provided `full_name` value to the `full_name` attribute of the `user` object, updating the user's display name.

## Related Documents

- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.40)
- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 1.46)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.48)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.53)
- [backend.app.services.users.email](c9d9526a-dd04-57c7-b212-845716fc2b78.md) - Related (graph distance 1.56)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.72)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 2.81)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.82)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 2.83)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.84)
