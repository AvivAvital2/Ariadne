---
id: 04a09dcb-bb0d-5e21-a970-8ac4fab9c749
type: catalog
title: "backend.app.schemas.UserUpdate"
created_at: 2026-07-30T15:09:16.661594+00:00
updated_at: 2026-07-30T17:48:08.786263+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.UserUpdate"
  signature: "class UserUpdate(BaseModel):"
  location: {'line_start': 42, 'line_end': 44, 'col_start': 0, 'col_end': 32}
  parent_qualified_name: None
  sha_at_sync: "9da4b51b31efcaae7a7cdbbe38fff2a9cfb4e797851d688053e5903adc174e7f"
  description: "Pydantic model defining the schema for updating an existing user, containing the fields that can be modified in a user update request."
---
# backend.app.schemas.UserUpdate

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.UserUpdate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:42-44 :: class UserUpdate(BaseModel):

Description: Pydantic model defining the schema for updating an existing user, containing the fields that can be modified in a user update request.

## Related Documents

- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 1.22)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 1.28)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.41)
- [backend.app.schemas.CurrentUser](c9f0033d-65ba-5095-b1f7-46936148c59a.md) - Related (graph distance 1.50)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.53)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 1.60)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 1.61)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.69)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 2.71)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.71)
