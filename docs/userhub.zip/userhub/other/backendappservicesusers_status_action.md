---
id: a100999f-8f51-5b17-8363-7b7149d8f7e6
type: catalog
title: "backend.app.services.users._status_action"
created_at: 2026-07-30T15:09:17.213907+00:00
updated_at: 2026-07-30T17:48:08.851730+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users._status_action"
  signature: "def _status_action(status: str) -> str:"
  location: {'line_start': 164, 'line_end': 169, 'col_start': 0, 'col_end': 41}
  parent_qualified_name: None
  sha_at_sync: "9ddcc49bf9bc8bf15ca9d169c31ad6470a4bf318a99e1914eff6c1bcac30f32c"
  description: "Maps a user status string to its corresponding human-readable action label, returning the mapped value or the original status if no mapping exists."
---
# backend.app.services.users._status_action

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users._status_action [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:164-169 :: def _status_action(status: str) -> str:

Description: Maps a user status string to its corresponding human-readable action label, returning the mapped value or the original status if no mapping exists.

## Related Documents

- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 1.64)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 1.64)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 1.65)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 1.65)
- [backend.app.models.User.status](d889c49c-87ed-5f94-a9dd-4f102349b418.md) - Related (graph distance 1.66)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 2.87)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 3.01)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 3.07)
- [backend.app.services.users.query](d9f0755a-497e-52a9-be2e-4103bced037f.md) - Related (graph distance 3.08)
- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 3.09)
