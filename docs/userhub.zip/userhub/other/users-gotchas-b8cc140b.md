---
id: b8cc140b-1153-5359-8bfa-b08ff16a5703
type: gotcha
title: "Users Gotchas"
created_at: 2026-07-30T17:25:50.400591+00:00
updated_at: 2026-07-30T17:25:50.400609+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  module_name: "backend.app.services.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

# Gotchas & Pitfalls: `backend.app.services.users`

### N+1 Query Explosion in Permission Checks
**Trigger:** Calling `actor_has_permission` or `effective_permissions` with lazy-loaded `roles`/`permissions` relationships.
**Affected Files:** `users.py` (`actor_has_permission`, `effective_permissions`)
**Fix:** Eager-load with `joinedload`/`selectinload` when fetching the user, or preload roles+permissions in the calling query.
**Category:** performance
**Example:**
```python
# Each `role.permissions` access fires a fresh SELECT per role.
any(perm.name == permission for role in actor.roles for perm in role.permissions)
# Prefer:
user = db.query(User).options(selectinload(User.roles).selectinload(Role.permissions)).get(uid)
```

---

### Missing Roles Silently Dropped in `assign_roles`/`create_user`
**Trigger:** Passing `role_ids` that contain IDs not present in the DB.
**Affected Files:** `users.py` (`assign_roles`, `create_user`)
**Fix:** Compare the count of returned rows to `len(role_ids)` and raise 422 on mismatch.
**Category:** domain
**Example:**
```python
roles = db.query(Role).filter(Role.id.in_(role_ids)).all()
if len(roles) != len(set(role_ids)):
    raise HTTPException(422, "unknown role id")
user.roles = roles
```

---

### `create_user` Username Uniqueness Has a TOCTOU Race
**Trigger:** Two concurrent requests creating the same username; both pass the pre-check before either commits.
**Affected Files:** `users.py` (`create_user`)
**Fix:** Rely on a DB unique constraint and catch `IntegrityError`, converting it to a 409. The pre-check alone is not atomic.
**Category:** thread-safety
**Example:**
```python
# Both requests see None here, both proceed to insert -> IntegrityError on one.
if db.query(User).filter(User.username == username).first() is not None: ...
```

---

### `assign_roles` Empty List Wipes All Roles
**Trigger:** Passing `role_ids=[]` (or the frontend omitting the field and defaulting to empty).
**Affected Files:** `users.py` (`assign_roles`)
**Fix:** Confirm the empty-list-clears-roles behavior is intended; if not, guard against empty input. Note it differs from `create_user`, which skips assignment entirely on empty list (`if role_ids:`).
**Category:** domain
**Example:**
```python
# create_user: skips on empty
if role_ids: user.roles = ...
# assign_roles: unconditionally overwrites, so [] removes everything
user.roles = db.query(Role).filter(Role.id.in_([])).all()  # -> []
```

---

### `set_status` Trusts Raw `status` String, Not the Enum
**Trigger:** Callers passing a raw string that happens to be a valid enum *value* but bypassing type-checking intent. Also `_status_action` returns a generic `USER_UPDATED` for any status other than active/deactivated, silently mislabeling audit entries.
**Affected Files:** `users.py` (`set_status`, `_status_action`)
**Fix:** Accept `UserStatus` enum in the signature; map every status to a dedicated audit action explicitly rather than falling through to `USER_UPDATED`.
**Category:** type-system
**Example:**
```python
# INVITED -> ACTIVE would log USER_REACTIVATED; SUSPENDED logs generic USER_UPDATED.
def _status_action(status): ...  # fallthrough hides real transition in audit
```

---

### Same-Status Transition Silently Succeeds and Emits Audit Noise
**Trigger:** `set_status` called with `status == user.status`.
**Affected Files:** `users.py` (`set_status`, `_validate_transition`)
**Fix:** `_validate_transition` returns early on `current == target`, but `set_status` still writes the row, records audit, and commits — creating a redundant audit event for a no-op. Short-circuit before recording.
**Category:** domain
**Example:**
```python
if current == target:
    return  # validation passes, but set_status keeps going and logs anyway
```

---

### `db.refresh` After Commit Can Blow Up on Deleted/Expired State
**Trigger:** Any exception between `flush` and `commit`, or refreshing an object whose row was deleted concurrently.
**Affected Files:** `users.py` (all mutating functions)
**Fix:** Wrap commits so failures roll back; be aware `refresh` on a concurrently-deleted row raises. Sessions are not thread-safe—never share a `Session` across threads/requests.
**Category:** thread-safety
**Example:**
```python
db.commit()
db.refresh(user)  # raises ObjectDeletedError if row gone; no rollback handling here
```

---

### `list_users` Accepts Arbitrary `status` String Without Validation
**Trigger:** Passing an invalid status filter (e.g. `?status=bogus`).
**Affected Files:** `users.py` (`list_users`)
**Fix:** Validate `status` against `UserStatus` values; otherwise it silently returns an empty list rather than a 422.
**Category:** type-system
**Example:**
```python
list_users(db, status="typo")  # returns [] silently, not an error
```

---

### Audit Record + Mutation Not Guaranteed Atomic Under Partial Failure
**Trigger:** `audit.record` flushes/queues rows, but if `commit` fails the whole unit rolls back — however if `audit.record` itself commits internally, you'd get orphaned audit entries.
**Affected Files:** `users.py` (all), `app/services/audit.py`
**Fix:** Ensure `audit.record` only stages rows (no internal commit) so the single outer `commit` is the atomic boundary.
**Category:** domain
**Example:**
```python
audit.record(db, ...)  # must NOT commit internally
db.commit()            # single atomic boundary for user + audit
```

---

### `get_user` Returns `None` but `_require` Raises — Inconsistent Contracts
**Trigger:** Callers assuming `get_user` never returns `None`, or mixing it with `_require`.
**Affected Files:** `users.py` (`get_user`, `_require`)
**Fix:** Document the divergence clearly; `get_user` is nullable (`User | None`), route handlers must null-check or use `_require`.
**Category:** type-system
**Example:**
```python
user = get_user(db, uid)   # may be None
user.email                 # AttributeError if caller forgets the check
```

---

### `delete_user` Relies on Cascade Behavior for Roles/Audit
**Trigger:** Deleting a user with associated audit rows referencing it as `target_id`, or association-table role links without proper cascade.
**Affected Files:** `users.py` (`delete_user`), `app/models.py`
**Fix:** Verify FK cascade / `ondelete` config; a dangling `audit_log.target_id` FK will raise `IntegrityError` on commit, and the recorded audit entry points to a now-deleted user.
**Category:** framework
**Example:**
```python
audit.record(db, target_id=target_id, ...)  # references user
db.delete(user)                              # audit row now dangles
db.commit()                                  # IntegrityError if FK enforced
```