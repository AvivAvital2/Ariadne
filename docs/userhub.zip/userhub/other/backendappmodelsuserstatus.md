---
id: d889c49c-87ed-5f94-a9dd-4f102349b418
type: catalog
title: "backend.app.models.User.status"
created_at: 2026-07-30T15:09:15.721301+00:00
updated_at: 2026-07-30T17:48:08.767022+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.status"
  signature: "status: Mapped[str] = mapped_column(String(32), default="invited")"
  location: {'line_start': 43, 'line_end': 43, 'col_start': 4, 'col_end': 70}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "0151cf34c804f769c72e5e1961c500728b6beb844e7f65035685fbf9ee722151"
  description: "Defines the User model's status column as a required 32-character string that tracks the account's state, defaulting to "invited" for newly created users."
---
# backend.app.models.User.status

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.status in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:43-43 :: status: Mapped[str] = mapped_column(String(32), default="invited")

Description: Defines the User model's status column as a required 32-character string that tracks the account's state, defaulting to "invited" for newly created users.

## Related Documents

- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 1.35)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 1.39)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 1.43)
- [backend.app.constants.UserStatus.INVITED](311be302-09f8-5cba-8f71-b5116945a393.md) - Related (graph distance 1.52)
- [backend.app.services.users._status_action](a100999f-8f51-5b17-8363-7b7149d8f7e6.md) - Related (graph distance 1.66)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 2.77)
- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 2.78)
- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 2.80)
- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 2.82)
