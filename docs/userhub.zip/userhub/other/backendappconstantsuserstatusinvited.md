---
id: 311be302-09f8-5cba-8f71-b5116945a393
type: catalog
title: "backend.app.constants.UserStatus.INVITED"
created_at: 2026-07-30T15:09:15.957977+00:00
updated_at: 2026-07-30T17:48:08.776007+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.UserStatus.INVITED"
  signature: "INVITED = "invited""
  location: {'line_start': 20, 'line_end': 20, 'col_start': 4, 'col_end': 23}
  parent_qualified_name: "backend.app.constants.UserStatus"
  sha_at_sync: "85d6e9f468aa9c47a41805795891c0dd6f3271cbc65cb3ff16c0b218d55dc2de"
  description: "Represents the status of a user who has been invited to the system but has not yet completed registration or accepted the invitation."
---
# backend.app.constants.UserStatus.INVITED

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.UserStatus.INVITED in backend.app.constants.UserStatus [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:20-20 :: INVITED = "invited"

Description: Represents the status of a user who has been invited to the system but has not yet completed registration or accepted the invitation.

## Related Documents

- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 1.50)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 1.50)
- [backend.app.models.User.status](d889c49c-87ed-5f94-a9dd-4f102349b418.md) - Related (graph distance 1.52)
- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 1.54)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.70)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 2.86)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 2.87)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.88)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 2.89)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 2.92)
