---
id: fe0aa8b5-eaf7-53b3-b29c-8db8b36c3328
type: catalog
title: "backend.app.services.audit.query"
created_at: 2026-07-30T15:09:16.967582+00:00
updated_at: 2026-07-30T17:17:48.751262+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.services.audit.query"
  signature: "query = query.filter(AuditLog.action == action)"
  location: {'line_start': 40, 'line_end': 40, 'col_start': 8, 'col_end': 55}
  parent_qualified_name: None
  sha_at_sync: "994c0ab0b776fd9e522f21ac943c212fe427f8f476d668780cdc271d1f5fffdb"
  description: "Applies a filter to the SQLAlchemy query to include only audit log records matching the specified action, reassigning the refined query back to the `query` variable."
---
# backend.app.services.audit.query

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py`

variable backend.app.services.audit.query [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py:40-40 :: query = query.filter(AuditLog.action == action)

Description: Applies a filter to the SQLAlchemy query to include only audit log records matching the specified action, reassigning the refined query back to the `query` variable.