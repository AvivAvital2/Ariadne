---
id: 1907bae2-f8e6-5bc5-9e90-088c66fa2119
type: catalog
title: "frontend/index.html#root"
created_at: 2026-07-30T15:09:14.636704+00:00
updated_at: 2026-07-30T17:20:02.071911+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/index.html
metadata:
  kind: "element"
  source_name: "userhub"
  language: "html"
  subtype: "html_element"
  qualified_name: "frontend/index.html#root"
  signature: "<html lang="en">"
  location: {'line_start': 2, 'line_end': 12, 'col_start': 0, 'col_end': 7}
  parent_qualified_name: None
  sha_at_sync: "352117258e310bcb096fdc105de61cf215319e35405edd819a3b963203e95118"
  description: "The root HTML document element for the frontend application, declaring English as the document language and containing the page's head and body structure."
---
# frontend/index.html#root

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/index.html`

html_element frontend/index.html#root [html] /Users/spark/git/Ariadne.orig/userhub/frontend/index.html:2-12 :: <html lang="en">

Description: The root HTML document element for the frontend application, declaring English as the document language and containing the page's head and body structure.