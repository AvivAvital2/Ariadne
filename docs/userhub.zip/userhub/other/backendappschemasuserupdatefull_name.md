---
id: d85e1f5d-085a-57bb-96c5-4027d7531232
type: catalog
title: "backend.app.schemas.UserUpdate.full_name"
created_at: 2026-07-30T15:09:16.669170+00:00
updated_at: 2026-07-30T17:48:08.794779+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserUpdate.full_name"
  signature: "full_name: str | None = None"
  location: {'line_start': 44, 'line_end': 44, 'col_start': 4, 'col_end': 32}
  parent_qualified_name: "backend.app.schemas.UserUpdate"
  sha_at_sync: "72d13995b1dcc57e0a997ea39cacb1690a22335b53f646b1b94b41f6c1c7aa1c"
  description: "Optional field in the `UserUpdate` schema for updating a user's full name, defaulting to `None` when not provided."
---
# backend.app.schemas.UserUpdate.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserUpdate.full_name in backend.app.schemas.UserUpdate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:44-44 :: full_name: str | None = None

Description: Optional field in the `UserUpdate` schema for updating a user's full name, defaulting to `None` when not provided.

## Related Documents

- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.16)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.31)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 1.37)
- [backend.app.services.users.full_name](068b4d0c-4d8a-544e-93e4-8e6677d000bf.md) - Related (graph distance 1.46)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.58)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 2.62)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.64)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.66)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.66)
