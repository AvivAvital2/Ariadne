---
id: f6e3ecc8-46b5-5b7c-b973-bef6ba750d07
type: catalog
title: "backend.app.routers.audit.router"
created_at: 2026-07-30T15:09:16.473659+00:00
updated_at: 2026-07-30T17:48:08.783783+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.routers.audit.router"
  signature: "router = APIRouter(tags=["audit"])"
  location: {'line_start': 13, 'line_end': 13, 'col_start': 0, 'col_end': 34}
  parent_qualified_name: None
  sha_at_sync: "1f59a2ef1aab2e13e32c9e4f26646c064796eae4e519f0b66ed5ec79b6aae231"
  description: "Module-level FastAPI APIRouter instance tagged with "audit" that groups and registers the audit-related route handlers defined in this module."
---
# backend.app.routers.audit.router

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

variable backend.app.routers.audit.router [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py:13-13 :: router = APIRouter(tags=["audit"])

Description: Module-level FastAPI APIRouter instance tagged with "audit" that groups and registers the audit-related route handlers defined in this module.

## Related Documents

- [backend.app.routers.reports.router](bad66bc7-e773-5982-a06f-097d09219abb.md) - Related (graph distance 1.28)
- [backend.app.routers.roles.router](3f73e456-0011-5a56-95f4-2a52726b2db7.md) - Related (graph distance 1.28)
- [backend.app.routers.users.router](4234b282-fa44-59ed-a663-636c40c44d88.md) - Related (graph distance 1.38)
- [backend.app.routers.audit.list_audit](de42e7ba-8f21-5ff2-840f-f27e74b6f36a.md) - Related (graph distance 1.65)
