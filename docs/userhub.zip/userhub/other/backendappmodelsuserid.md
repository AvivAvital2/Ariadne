---
id: a9e80af3-a787-5195-aa23-b9ce8d253c41
type: catalog
title: "backend.app.models.User.id"
created_at: 2026-07-30T15:09:15.720071+00:00
updated_at: 2026-07-30T17:48:08.766516+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.id"
  signature: "id: Mapped[int] = mapped_column(primary_key=True)"
  location: {'line_start': 38, 'line_end': 38, 'col_start': 4, 'col_end': 53}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "06b4f0bf94a32745f665ce92f1d2852aaa070fb664bc0d80af2423523af921b2"
  description: "Defines the `id` column as the primary key for the `User` model, mapped to an integer type."
---
# backend.app.models.User.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.id in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:38-38 :: id: Mapped[int] = mapped_column(primary_key=True)

Description: Defines the `id` column as the primary key for the `User` model, mapped to an integer type.

## Related Documents

- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 1.19)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 1.23)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 1.23)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 1.30)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 1.30)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.41)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.49)
- [backend.app.services.users.target_id](347260a2-8d58-556f-89b7-d9cc05ee6faa.md) - Related (graph distance 1.64)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.42)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.46)
