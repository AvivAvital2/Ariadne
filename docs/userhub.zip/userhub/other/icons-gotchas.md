---
id: 86aebacc-0f47-568a-b4a7-3995ccf4c81d
type: gotcha
title: "Icons Gotchas"
created_at: 2026-07-30T17:27:45.125889+00:00
updated_at: 2026-07-30T17:27:45.125907+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx
metadata:
  module_name: "frontend.src.components.Icons"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Icons Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Icons.jsx`

# Gotchas & Pitfalls: `frontend.src.components.Icons`

### Spread props can silently override critical SVG attributes
**Trigger:** Passing props like `stroke`, `fill`, `viewBox`, or `aria-hidden` through `{...p}` overrides the hardcoded defaults because `{...rest}` is spread *after* them.
**Affected Files:** `Icons.jsx` (all exported icons, `Svg`)
**Fix:** Decide intent explicitly. If defaults must win, spread `{...rest}` *before* the fixed attributes. If overrides are intended, document it clearly.
**Category:** framework
**Example:**
```jsx
// Attributes appear before {...rest}, so caller wins:
<IconBell stroke="red" fill="blue" viewBox="0 0 48 48" />
// -> stroke="currentColor" is overridden to "red", fill overridden too.
// The "inherits currentColor" contract silently breaks.
```

---

### `aria-hidden="true"` makes icons invisible to screen readers even when meaningful
**Trigger:** Using an icon as the *only* content of an interactive element (e.g., an icon-only button) while it's hardcoded `aria-hidden="true"`.
**Affected Files:** `Icons.jsx` (`Svg`)
**Fix:** Keep `aria-hidden` overridable (it is via `{...rest}`), but callers must remember to pass `aria-hidden={false}` + `role="img"` + `aria-label`. Better: expose a `title`/`label` prop pattern.
**Category:** framework
**Example:**
```jsx
// Icon-only button with no accessible name:
<button onClick={close}><IconUserX /></button>
// Screen reader announces "button" with no label. Needs aria-label on button
// or aria-hidden={false} + label on the icon.
```

---

### `size` prop only sets pixel dimensions, not CSS-driven sizing
**Trigger:** The comment claims "CSS controls color/size," but `width`/`height` are set as HTML attributes from `size`, which take precedence differently than the comment implies.
**Affected Files:** `Icons.jsx` (`Svg`)
**Fix:** For true CSS-driven sizing use `width="1em" height="1em"` or omit dimensions and control via CSS `width`/`height`. Attribute dimensions are overridden by CSS width/height but not by font-size.
**Category:** framework
**Example:**
```jsx
<IconClock />              // renders 20x20 via attributes
// CSS: .icon { font-size: 2rem } does NOT scale it (no em units).
// You must pass size={32} or override width/height in CSS.
```

---

### `size` accepts any type — string/NaN passed through unvalidated
**Trigger:** Passing a non-numeric or computed value to `size`.
**Affected Files:** `Icons.jsx` (`Svg`)
**Fix:** Coerce/validate: `const dim = Number(size) || 20;` or add PropTypes/TypeScript.
**Category:** type-system
**Example:**
```jsx
<IconPlus size={someUndefinedVar} />  // width="undefined" -> browser uses default/errors
<IconPlus size="2rem" />              // works, but inconsistent with default number 20
```

---

### Duplicated `viewBox` assumption across icons; mismatched paths won't warn
**Trigger:** All icons hardcode `viewBox="0 0 24 24"` inside `Svg`. `IconSearch` uses coordinates like `16.65` which are fine, but any new icon drawn on a different grid silently renders clipped/offset.
**Affected Files:** `Icons.jsx` (all icons)
**Fix:** Keep icon path authoring on a strict 24×24 grid; add a lint/visual test. No runtime error is ever thrown for out-of-viewBox paths.
**Category:** domain
**Example:**
```jsx
// If someone adds a path with coords up to 32, it gets clipped silently:
<Svg><rect x="0" y="0" width="30" height="30" /></Svg>  // no error, just clipped
```

---

### `key` prop and lists — icons rendered in `.map()` need keys on the icon, not children
**Trigger:** Rendering icons in a list; the fixed inner `<path>`/`<rect>` elements are static, but if you ever map children you'd hit React key warnings.
**Affected Files:** `Icons.jsx` (consumers)
**Fix:** Assign `key` to the icon element at the call site, not inside `Svg`.
**Category:** framework
**Example:**
```jsx
{items.map(i => <IconDashboard key={i.id} />)}  // key on the component, correct
```

---

### `strokeWidth` doesn't scale with `size`, causing thin/thick lines at extremes
**Trigger:** Rendering an icon at a much larger or smaller `size` than 20. `strokeWidth="2"` is in viewBox units so it scales, but visual weight at tiny sizes becomes muddy and at huge sizes too thin proportionally is fine — the trap is expecting a constant *pixel* stroke.
**Affected Files:** `Icons.jsx` (`Svg`)
**Fix:** For consistent pixel stroke use `vectorEffect="non-scaling-stroke"` on paths, or expose `strokeWidth` as a prop (currently only overridable via `{...rest}` on the `<svg>`, which does NOT propagate to children reliably).
**Category:** framework
**Example:**
```jsx
<IconSearch size={64} />   // stroke scales up too; may look heavy vs. text
```

---

### `stroke`/`fill` on the `<svg>` don't override per-shape attributes if children add their own
**Trigger:** Assuming setting `fill` on the parent fills all shapes. Icons like `IconShield` rely on inheriting `fill="none"`; passing `fill="currentColor"` fills them but stroke-only icons (`IconActivity` polyline) look wrong.
**Affected Files:** `Icons.jsx` (`IconShield`, `IconActivity`, etc.)
**Fix:** Understand each icon is authored stroke-only. Don't globally toggle `fill` expecting uniform results.
**Category:** domain
**Example:**
```jsx
<IconShield fill="currentColor" />  // becomes solid; other icons look broken with same prop
```

---

### No `displayName` — harder debugging and dev-tools display
**Trigger:** Arrow-function components assigned to consts sometimes lack readable names in older tooling/minified builds.
**Affected Files:** `Icons.jsx` (all exports)
**Fix:** Named consts usually infer displayName, but add explicit `IconX.displayName = 'IconX'` if minification strips names, for cleaner React DevTools and error boundaries.
**Category:** framework
**Example:**
```jsx
// In a stack trace after minification: <t /> instead of <IconBell />
```