---
id: 6d6d0d60-dede-576a-acb3-66433665d330
type: catalog
title: "backend.app.routers.users.whoami"
created_at: 2026-07-30T15:09:16.734382+00:00
updated_at: 2026-07-30T17:48:08.844356+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.whoami"
  signature: "def whoami(actor: User = Depends(current_actor)) -> CurrentUser:"
  location: {'line_start': 29, 'line_end': 37, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "32795e96e1c41170d53d7e6c7afae8ee8aa3405eaf8d23f35020bad0b60d25b5"
  description: "Returns the currently authenticated user's identity as a `CurrentUser` object, using the `current_actor` dependency to resolve the active `User`."
---
# backend.app.routers.users.whoami

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.whoami [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:29-37 :: def whoami(actor: User = Depends(current_actor)) -> CurrentUser:

Description: Returns the currently authenticated user's identity as a `CurrentUser` object, using the `current_actor` dependency to resolve the active `User`.

## Related Documents

- [backend.app.security.current_actor](eb699a26-2b07-5eeb-bb23-ba2a11bb6db2.md) - Related (graph distance 1.40)
- [backend.app.security.actor](4e7167d7-c470-5237-89cd-129549d48c21.md) - Related (graph distance 1.67)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 3.09)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 3.21)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 3.23)
