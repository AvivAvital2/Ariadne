---
id: 4e7167d7-c470-5237-89cd-129549d48c21
type: catalog
title: "backend.app.security.actor"
created_at: 2026-07-30T15:09:15.796542+00:00
updated_at: 2026-07-30T17:48:08.774715+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.security.actor"
  signature: "actor = user_service.get_user(db, x_actor_id)"
  location: {'line_start': 37, 'line_end': 37, 'col_start': 8, 'col_end': 53}
  parent_qualified_name: None
  sha_at_sync: "74e00aac68367b44af0b140af434dd224585032f2501ef2c1752a09bceb81a90"
  description: "Retrieves the user record corresponding to the `x_actor_id` header value from the database via the user service, identifying the actor performing the current request."
---
# backend.app.security.actor

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

variable backend.app.security.actor [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py:37-37 :: actor = user_service.get_user(db, x_actor_id)

Description: Retrieves the user record corresponding to the `x_actor_id` header value from the database via the user service, identifying the actor performing the current request.

## Related Documents

- [backend.app.security.current_actor](eb699a26-2b07-5eeb-bb23-ba2a11bb6db2.md) - Related (graph distance 1.35)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 1.42)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 1.54)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 1.57)
- [backend.app.routers.users.whoami](6d6d0d60-dede-576a-acb3-66433665d330.md) - Related (graph distance 1.67)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 2.71)
- [backend.app.services.users._require](9ed832d6-c01f-5651-aed5-9b72c915b9db.md) - Related (graph distance 2.77)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 2.77)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 2.93)
