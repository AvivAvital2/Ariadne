---
id: eb699a26-2b07-5eeb-bb23-ba2a11bb6db2
type: catalog
title: "backend.app.security.current_actor"
created_at: 2026-07-30T15:09:15.795311+00:00
updated_at: 2026-07-30T17:48:08.774196+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.security.current_actor"
  signature: "def current_actor("
  location: {'line_start': 17, 'line_end': 26, 'col_start': 0, 'col_end': 16}
  parent_qualified_name: None
  sha_at_sync: "fd935c886217369ca9e501e4f6018c91e7c23d2ba12cb5e14f60d805d0ac0d5c"
  description: "Retrieves the currently authenticated actor (user or service) associated with the incoming request, typically by resolving credentials or tokens from the request context."
---
# backend.app.security.current_actor

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

function backend.app.security.current_actor [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py:17-26 :: def current_actor(

Description: Retrieves the currently authenticated actor (user or service) associated with the incoming request, typically by resolving credentials or tokens from the request context.

## Related Documents

- [backend.app.security.actor](4e7167d7-c470-5237-89cd-129549d48c21.md) - Related (graph distance 1.35)
- [backend.app.routers.users.whoami](6d6d0d60-dede-576a-acb3-66433665d330.md) - Related (graph distance 1.40)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 2.77)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 2.89)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 2.91)
