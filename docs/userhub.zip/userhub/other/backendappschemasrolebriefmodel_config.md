---
id: dc56a798-5157-5d98-8faf-c69a69f6bec0
type: catalog
title: "backend.app.schemas.RoleBrief.model_config"
created_at: 2026-07-30T15:09:16.663618+00:00
updated_at: 2026-07-30T17:48:08.789032+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleBrief.model_config"
  signature: "model_config = ConfigDict(from_attributes=True)"
  location: {'line_start': 9, 'line_end': 9, 'col_start': 4, 'col_end': 51}
  parent_qualified_name: "backend.app.schemas.RoleBrief"
  sha_at_sync: "c68e00d245d4dbecf8ed44fb515545f6398d17fd04905803a46c6de1a0126eed"
  description: "Configures the `RoleBrief` Pydantic model to populate its fields from object attributes (ORM mode), enabling instantiation directly from ORM model instances."
---
# backend.app.schemas.RoleBrief.model_config

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleBrief.model_config in backend.app.schemas.RoleBrief [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:9-9 :: model_config = ConfigDict(from_attributes=True)

Description: Configures the `RoleBrief` Pydantic model to populate its fields from object attributes (ORM mode), enabling instantiation directly from ORM model instances.

## Related Documents

- [backend.app.schemas.RoleOut.model_config](855b8538-1f7f-53a3-af63-94b320e0e796.md) - Related (graph distance 1.08)
- [backend.app.schemas.PermissionOut.model_config](5f1f3c69-edd8-5b8d-b607-9c7b9d47feba.md) - Related (graph distance 1.19)
- [backend.app.schemas.UserOut.model_config](2680e71b-89f1-5e50-bbdc-adce1ba75529.md) - Related (graph distance 1.19)
- [backend.app.schemas.AuditLogOut.model_config](620f2e87-3d30-52f3-85c7-e7a7f98d0761.md) - Related (graph distance 1.20)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 1.54)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.68)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.92)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 2.97)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 3.06)
