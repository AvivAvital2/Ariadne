---
id: 3be4829c-8290-58c1-823e-c6fbdaff14ff
type: catalog
title: "backend.app.models.AuditLog.detail"
created_at: 2026-07-30T15:09:15.727238+00:00
updated_at: 2026-07-30T17:48:08.772865+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.detail"
  signature: "detail: Mapped[str] = mapped_column(Text, default="")"
  location: {'line_start': 91, 'line_end': 91, 'col_start': 4, 'col_end': 57}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "8904bdae61adec4b42dfc7071be89a7b73f0ec6798a0e260ef3f5ec6d5186db8"
  description: "Stores a textual description or additional context for an audit log entry, defaulting to an empty string."
---
# backend.app.models.AuditLog.detail

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.detail in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:91-91 :: detail: Mapped[str] = mapped_column(Text, default="")

Description: Stores a textual description or additional context for an audit log entry, defaulting to an empty string.

## Related Documents

- [backend.app.schemas.AuditLogOut.detail](a31c8116-37e1-5beb-bf8e-ea48591a1744.md) - Related (graph distance 1.27)
- [backend.app.models.Permission.description](9fe1ddb1-931e-52dc-bec1-aa8b5cdbe620.md) - Related (graph distance 1.52)
- [backend.app.models.Role.description](05e42cb4-46a0-51af-998b-59dfc35bf5ff.md) - Related (graph distance 1.52)
- [backend.app.schemas.AuditLogOut.action](bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d.md) - Related (graph distance 2.78)
- [backend.app.schemas.RoleOut.description](de00f3e4-a439-5e5f-a034-98d286d08613.md) - Related (graph distance 2.84)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 2.86)
- [backend.app.schemas.PermissionOut.description](7e1baaaf-7dae-50ef-aef6-81cdb4043b19.md) - Related (graph distance 2.86)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 2.88)
