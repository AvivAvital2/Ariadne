---
id: f33dac0b-49f6-5f66-80ef-bdb495fd1dd0
type: catalog
title: "backend.app.services.users.create_user"
created_at: 2026-07-30T15:09:17.212055+00:00
updated_at: 2026-07-30T17:48:08.850279+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.create_user"
  signature: "def create_user("
  location: {'line_start': 47, 'line_end': 77, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "84ffd875afdefd4378fe748fc465484ddfa6c601d8e81273c193df5987660882"
  description: "Creates a new user record in the database from the provided user data, typically handling password hashing and persistence. Returns the newly created user object."
---
# backend.app.services.users.create_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.create_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:47-77 :: def create_user(

Description: Creates a new user record in the database from the provided user data, typically handling password hashing and persistence. Returns the newly created user object.

## Related Documents

- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 1.19)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.44)
- [backend.app.services.roles.create_role](9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53.md) - Related (graph distance 1.44)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 1.63)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 1.66)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 2.76)
- [backend.app.services.roles.role](98eb86d0-4da5-5101-afd6-50e807b8bc0d.md) - Related (graph distance 2.83)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 2.97)
- [backend.app.services.roles.get_role](1ee43ae5-6edf-5b48-9b41-86136d1689ac.md) - Related (graph distance 3.02)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 3.05)
