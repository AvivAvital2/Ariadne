---
id: 61f64236-c76b-5f4d-b56e-273161cf20c2
type: catalog
title: "backend.app.services.users.get_user"
created_at: 2026-07-30T15:09:17.208772+00:00
updated_at: 2026-07-30T17:48:08.849439+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.get_user"
  signature: "def get_user(db: Session, user_id: int) -> User | None:"
  location: {'line_start': 17, 'line_end': 18, 'col_start': 0, 'col_end': 32}
  parent_qualified_name: None
  sha_at_sync: "3e4b619df74c16a0f657b2359f632266b29fdc2324bd197626a89b1ecb411f8f"
  description: "Retrieves a single user from the database by their ID, returning the matching User object or None if no user is found."
---
# backend.app.services.users.get_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.get_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:17-18 :: def get_user(db: Session, user_id: int) -> User | None:

Description: Retrieves a single user from the database by their ID, returning the matching User object or None if no user is found.

## Related Documents

- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 1.28)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 1.31)
- [backend.app.services.users._require](9ed832d6-c01f-5651-aed5-9b72c915b9db.md) - Related (graph distance 1.36)
- [backend.app.services.roles.get_role](1ee43ae5-6edf-5b48-9b41-86136d1689ac.md) - Related (graph distance 1.39)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 1.42)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 1.48)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.62)
- [backend.app.security.actor](4e7167d7-c470-5237-89cd-129549d48c21.md) - Related (graph distance 2.71)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 2.78)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 2.82)
