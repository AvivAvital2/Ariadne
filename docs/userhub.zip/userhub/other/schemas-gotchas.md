---
id: 05c22444-77c7-53e8-98f2-40b967f186fc
type: gotcha
title: "Schemas Gotchas"
created_at: 2026-07-30T17:24:09.342123+00:00
updated_at: 2026-07-30T17:24:09.342135+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  module_name: "backend.app.schemas"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Schemas Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

# Gotchas and Pitfalls: `backend.app.schemas`

### Mutable Default Arguments via Class Attributes
**Trigger:** Using `list[...] = []` as a field default. While Pydantic v2 actually deep-copies mutable defaults per-instance (unlike raw Python), developers assume all defaults are handled and may misremember this behavior, or copy the pattern into non-Pydantic code where it becomes a shared-state bug.
**Affected Files:** `schemas.py` (RoleOut, RoleCreate, UserCreate, UserOut, CurrentUser, and any list default)
**Fix:** Pydantic v2 is safe here (it copies), but be explicit for clarity with `Field(default_factory=list)`. The real danger is copy-pasting `= []` into a dataclass/attrs/plain class.
**Category:** framework
**Example:**
```python
# Safe in Pydantic v2 (auto-copied), DANGEROUS if copied to a plain class:
class Bad:
    role_ids: list = []  # shared across all instances!

# Prefer explicit:
from pydantic import Field
permissions: list[str] = Field(default_factory=list)
```

---

### `from_attributes` Silently Reads Attributes, Not Keys
**Trigger:** `model_config = ConfigDict(from_attributes=True)` only enables ORM-mode when you call `RoleOut.model_validate(orm_obj)`. Passing a dict still works via the normal path, but passing an ORM object to the default `RoleOut(**data)` will fail because it doesn't unpack. Developers mix `model_validate` and constructor calls.
**Affected Files:** `schemas.py` (RoleBrief, PermissionOut, RoleOut, UserOut, AuditLogOut)
**Fix:** Always use `Model.model_validate(orm_instance)` for ORM objects; never `Model(orm_instance)`. Note only classes *with* `from_attributes=True` support this—`CurrentUser`, `UserActivityRow` do NOT.
**Category:** framework
**Example:**
```python
RoleOut.model_validate(role_orm)   # correct
RoleOut(role_orm)                  # TypeError / validation error
```

---

### `status` is a Raw `str`, Not the `UserStatus` Enum
**Trigger:** `UserStatusUpdate.status: str` and `UserOut.status: str` accept **any string**. There is no validation that the value is a legal `UserStatus` (`"deactivated"`, etc.). A typo like `"deactivate"` vs `"deactivated"` passes schema validation and fails deep in business logic.
**Affected Files:** `schemas.py` (UserStatusUpdate, UserOut, CurrentUser, UserActivityRow)
**Fix:** Type as the enum: `status: UserStatus`. Pydantic then rejects invalid values at the boundary with a clear 422.
**Category:** type-system
**Example:**
```python
UserStatusUpdate(status="banana")  # passes! no error until the DB/logic layer
```

---

### `email` Fields Are Unvalidated Strings
**Trigger:** `email: str` in `UserCreate` and `UserUpdate` performs **no email format validation**. Malformed emails reach the persistence layer.
**Affected Files:** `schemas.py` (UserCreate, UserUpdate)
**Fix:** Use `pydantic.EmailStr` (requires `email-validator`). This enforces RFC-ish syntax at validation time.
**Category:** type-system
**Example:**
```python
UserCreate(username="x", email="not-an-email")  # accepted silently
```

---

### `None` vs "Not Provided" Ambiguity in `UserUpdate`
**Trigger:** `email: str | None = None` cannot distinguish "clear the field" (`None`) from "leave unchanged" (omitted). Both produce `None` after validation. A PATCH handler doing `if payload.email is not None` will never allow clearing the email.
**Affected Files:** `schemas.py` (UserUpdate)
**Fix:** Use `model_dump(exclude_unset=True)` in the handler to detect which fields were actually sent, rather than checking for `None`.
**Category:** framework
**Example:**
```python
# body: {}  and  body: {"email": null}  both give email=None
payload.model_dump(exclude_unset=True)  # {} vs {"email": None} — now distinguishable
```

---

### Missing `extra="forbid"` Allows Silent Typo'd Fields
**Trigger:** By default Pydantic **ignores** unknown fields on input models. A client sending `{"role_id": 5}` (singular) to `RoleAssignment` (which expects `role_ids`) gets silently dropped, defaulting to whatever's set—or a validation error only for the missing required field.
**Affected Files:** `schemas.py` (all request models: RoleCreate, UserCreate, UserUpdate, UserStatusUpdate, RoleAssignment)
**Fix:** Add `model_config = ConfigDict(extra="forbid")` to request schemas so typos surface as 422 errors.
**Category:** framework
**Example:**
```python
RoleAssignment(role_ids=[1], role_id=99)  # role_id silently ignored
```

---

### Naive vs Aware `datetime` Mismatch
**Trigger:** `created_at: datetime` / `updated_at: datetime` accept both naive and timezone-aware datetimes. If the DB returns naive UTC and the API contract implies UTC, downstream consumers (and JS `Date`) may misinterpret the timezone.
**Affected Files:** `schemas.py` (UserOut, AuditLogOut, UserActivityRow)
**Fix:** Standardize on `AwareDatetime` or enforce UTC serialization; ensure the ORM/DB layer returns tz-aware values. Document the contract.
**Category:** type-system
**Example:**
```python
UserOut(..., created_at=datetime.utcnow())  # naive → serialized without offset
# frontend `new Date("2024-01-01T00:00:00")` interpreted as LOCAL time
```

---

### `RoleAssignment.role_ids` Is Required but Unbounded/Undeduped
**Trigger:** `role_ids: list[int]` has no min/max length and no uniqueness constraint. An empty list `[]` passes (may mean "remove all roles" unintentionally), and duplicates `[1,1,1]` pass through.
**Affected Files:** `schemas.py` (RoleAssignment, RoleCreate.permission_ids, UserCreate.role_ids)
**Fix:** Constrain with `Field(min_length=1)` if empty is invalid, and dedupe/validate in a `field_validator`, or use `set[int]` if order doesn't matter and dupes are meaningless.
**Category:** domain
**Example:**
```python
RoleAssignment(role_ids=[])       # accepted — accidental full de-assignment?
RoleAssignment(role_ids=[3,3,3])  # duplicate IDs accepted
```

---

### `UserActivityRow` Has No `from_attributes` for Raw-SQL Rows
**Trigger:** The docstring says it maps "raw-SQL user-activity report" rows, but there is **no** `from_attributes=True`. Raw SQL drivers often return tuples or Row objects with attribute access. `UserActivityRow.model_validate(row)` on a Row object will fail without ORM mode.
**Affected Files:** `schemas.py` (UserActivityRow)
**Fix:** Add `model_config = ConfigDict(from_attributes=True)` if rows are attribute-accessible, or convert Row→dict (`row._asdict()` / `dict(row._mapping)`) before validation.
**Category:** framework
**Example:**
```python
row = conn.execute(sql).fetchone()          # sqlalchemy Row
UserActivityRow.model_validate(row)         # fails without from_attributes
UserActivityRow.model_validate(dict(row._mapping))  # works
```

---

### `int` Fields Accept Coercible Strings/Floats
**Trigger:** Pydantic v2 in lax mode coerces `"5"` → `5` and `5.0` → `5` for `int` fields (`id`, `actor_id`, `action_count`, etc.). Bad client data may silently coerce rather than error.
**Affected Files:** `schemas.py` (all `int`/`int | None` fields)
**Fix:** Use strict mode (`ConfigDict(strict=True)` or `Strict` types) where you require exact JSON number types, especially for IDs coming from external clients.
**Category:** type-system
**Example:**
```python
PermissionOut.model_validate({"id":"7","name":"x","description":"y"})  # id becomes int 7
```