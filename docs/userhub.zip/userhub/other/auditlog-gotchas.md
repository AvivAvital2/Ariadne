---
id: 4f2ec40a-32df-5b5f-b2e1-5eb0db9eda10
type: gotcha
title: "Auditlog Gotchas"
created_at: 2026-07-30T17:27:12.151213+00:00
updated_at: 2026-07-30T17:27:12.151227+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx
metadata:
  module_name: "frontend.src.components.AuditLog"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Auditlog Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/AuditLog.jsx`

# Gotchas & Pitfalls: `frontend.src.components.AuditLog`

### Substring matching in `dotClass` is fragile
**Trigger:** Classifying actions by `action.includes(...)` matches any substring, so an action like `"user_created_then_deleted"` or `"account_undeleted"` will match unexpected branches. Order also matters — `"deleted"` is checked before `"created"`, so a compound action containing both silently classifies as "bad".
**Affected Files:** `AuditLog.jsx`
**Fix:** Match on exact action tokens or a mapping table rather than substring inclusion.
**Category:** domain
**Example:**
```javascript
dotClass("account_undeleted"); // returns "bad" — the "deleted" substring wins
dotClass("recreated_deleted");  // "bad", not "good" — first branch matches
```

---

### Missing loading state causes "0 entries" flash
**Trigger:** `entries` starts as `[]`, so before the async `listAudit()` resolves, the UI shows "0 entries" and an empty table. Users can't distinguish "still loading" from "genuinely empty".
**Affected Files:** `AuditLog.jsx`
**Fix:** Add a `loading` state that starts `true` and gates rendering.
**Category:** async
**Example:**
```javascript
const [loading, setLoading] = useState(true);
// ...
api.listAudit().then(setEntries).catch(...).finally(() => setLoading(false));
```

---

### Unhandled non-Error rejections crash the `.catch`
**Trigger:** `.catch((e) => setError(e.message))` assumes the rejection is an `Error` with a `.message`. If `listAudit()` rejects with a string, an object, or `undefined`, `e.message` throws or renders `undefined`.
**Affected Files:** `AuditLog.jsx`, `../api/client.js`
**Fix:** Coerce defensively: `setError(e?.message ?? String(e))`.
**Category:** type-system
**Example:**
```javascript
Promise.reject("network down").catch((e) => e.message); // undefined
Promise.reject(null).catch((e) => e.message);           // TypeError
```

---

### Unmounted component setState (memory leak / warning)
**Trigger:** If the component unmounts before `listAudit()` resolves, `setEntries`/`setError` fire on an unmounted component. In React 18 this is a no-op with a leaked in-flight request; in strict mode the effect runs twice, triggering duplicate fetches.
**Affected Files:** `AuditLog.jsx`
**Fix:** Use an `ignore`/`AbortController` cleanup flag in the effect.
**Category:** async
**Example:**
```javascript
useEffect(() => {
  let active = true;
  api.listAudit().then((d) => active && setEntries(d))
                 .catch((e) => active && setError(e.message));
  return () => { active = false; };
}, []);
```

---

### `new Date(entry.created_at)` silently produces "Invalid Date"
**Trigger:** If `created_at` is null, a Unix epoch number, or a non-ISO string, `new Date(...)` yields `Invalid Date` and `.toLocaleString()` renders the literal string `"Invalid Date"` with no error.
**Affected Files:** `AuditLog.jsx`
**Fix:** Validate the date and provide a fallback.
**Category:** type-system
**Example:**
```javascript
new Date(undefined).toLocaleString(); // "Invalid Date"
new Date("2024-13-01").toLocaleString(); // "Invalid Date"
```

---

### `entry.detail` renders raw without null/type guard
**Trigger:** `{entry.detail}` renders whatever value is present. If `detail` is `null`/`undefined`, React renders nothing (fine), but if it's an object (e.g., JSON metadata), React throws `Objects are not valid as a React child`.
**Affected Files:** `AuditLog.jsx`
**Fix:** Stringify/format non-primitive detail values.
**Category:** framework
**Example:**
```javascript
// If detail = { old: "a", new: "b" }
<td>{entry.detail}</td> // Error: Objects are not valid as a React child
```

---

### Falsy `target_id` fallback misrenders valid IDs
**Trigger:** `entry.target_id ?? "—"` uses nullish coalescing, so `0` passes through (correct). But note `target_type` has *no* guard — if it's null, output is `" #123"` with a leading `#`. Also `0` as a legitimate target_id renders `#0` which may confuse.
**Affected Files:** `AuditLog.jsx`
**Fix:** Guard `target_type` too, or render the whole target cell conditionally.
**Category:** type-system
**Example:**
```javascript
// target_type = null, target_id = 5  =>  renders "null #5"... actually "#5" leading space
<td>{entry.target_type} #{entry.target_id ?? "—"}</td>
```

---

### `entry.id` assumed to be a stable unique key
**Trigger:** `key={entry.id}` assumes audit entries always have unique `id`s. If the API omits `id` or returns duplicates (e.g., composite-keyed events), React reuses DOM nodes incorrectly, causing rendering glitches and lost row state.
**Affected Files:** `AuditLog.jsx`, `../api/client.js`
**Fix:** Ensure the API guarantees `id`; never fall back to array index for mutable lists.
**Category:** framework
**Example:**
```javascript
// entries with id undefined => all keys are undefined => React warning + misrender
```

---

### `.toLocaleString()` locale/timezone non-determinism
**Trigger:** `toLocaleString()` renders in the browser's locale and timezone. Audit logs displayed across users/regions show different times for the same event, and there's no timezone indicator. This is a correctness/UX hazard for audit trails specifically.
**Affected Files:** `AuditLog.jsx`
**Fix:** Format with an explicit timezone (UTC) and show the tz label, e.g. via `Intl.DateTimeFormat` with `timeZone: "UTC"`.
**Category:** domain
**Example:**
```javascript
new Date(iso).toLocaleString(); // differs per client machine — bad for auditing
```

---

### No pagination — full audit log rendered at once
**Trigger:** `listAudit()` presumably returns the entire audit history, and every entry maps to a table row. Audit logs grow unbounded; a large table renders thousands of DOM nodes on the main thread, freezing the UI.
**Affected Files:** `AuditLog.jsx`, `../api/client.js`
**Fix:** Add server-side pagination/virtualization (windowing) for large lists.
**Category:** performance
**Example:**
```javascript
{entries.map(...)} // 50,000 rows => jank / OOM
```