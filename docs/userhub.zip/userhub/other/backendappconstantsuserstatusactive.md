---
id: 9a88757a-cd9b-5500-a873-81f082bce5d2
type: catalog
title: "backend.app.constants.UserStatus.ACTIVE"
created_at: 2026-07-30T15:09:15.957593+00:00
updated_at: 2026-07-30T17:48:08.775488+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.UserStatus.ACTIVE"
  signature: "ACTIVE = "active""
  location: {'line_start': 19, 'line_end': 19, 'col_start': 4, 'col_end': 21}
  parent_qualified_name: "backend.app.constants.UserStatus"
  sha_at_sync: "580b0fa415b0cfa7324e9dd96b87355bda45a700716bacfeaf0196469449abc2"
  description: "Enum member of `UserStatus` representing an active user account, with the string value `"active"`."
---
# backend.app.constants.UserStatus.ACTIVE

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.UserStatus.ACTIVE in backend.app.constants.UserStatus [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:19-19 :: ACTIVE = "active"

Description: Enum member of `UserStatus` representing an active user account, with the string value `"active"`.

## Related Documents

- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 1.29)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 1.42)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 1.45)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 1.45)
- [backend.app.constants.UserStatus.INVITED](311be302-09f8-5cba-8f71-b5116945a393.md) - Related (graph distance 1.50)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.52)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.59)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 2.65)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 2.70)
