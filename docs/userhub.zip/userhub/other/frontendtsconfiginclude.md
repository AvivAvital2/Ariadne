---
id: bac41dbf-1879-5299-8ae5-ff5c9c3575df
type: catalog
title: "frontend.tsconfig.include"
created_at: 2026-07-30T15:09:15.336206+00:00
updated_at: 2026-07-30T17:48:08.760532+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.tsconfig.include"
  signature: ""include": ["src"]"
  location: {'line_start': 15, 'line_end': 15, 'col_start': 2, 'col_end': 20}
  parent_qualified_name: "frontend.tsconfig"
  sha_at_sync: "9848079533ed8ce588e3e55705095fb64d94c813bea7b4580a153d2aff49f29b"
  description: "Specifies that TypeScript should compile files within the `src` directory when processing this configuration."
---
# frontend.tsconfig.include

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json`

json_key frontend.tsconfig.include in frontend.tsconfig [json] /Users/spark/git/Ariadne.orig/userhub/frontend/tsconfig.json:15-15 :: "include": ["src"]

Description: Specifies that TypeScript should compile files within the `src` directory when processing this configuration.

## Related Documents

- [frontend.tsconfig.compilerOptions](b444cd34-9edf-5dee-91bb-97e73dac7714.md) - Related (graph distance 1.45)
