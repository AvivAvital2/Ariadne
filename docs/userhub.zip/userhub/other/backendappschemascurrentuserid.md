---
id: 11d99716-318b-5673-9da7-657d86a04b8c
type: catalog
title: "backend.app.schemas.CurrentUser.id"
created_at: 2026-07-30T15:09:16.673715+00:00
updated_at: 2026-07-30T17:48:08.839797+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.CurrentUser.id"
  signature: "id: int"
  location: {'line_start': 79, 'line_end': 79, 'col_start': 4, 'col_end': 11}
  parent_qualified_name: "backend.app.schemas.CurrentUser"
  sha_at_sync: "fa3ade80194044385719c8d9c727664fc73b21b0585020aa04e7b43bca70c957"
  description: "Stores the unique integer identifier of the authenticated user in the CurrentUser schema."
---
# backend.app.schemas.CurrentUser.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.CurrentUser.id in backend.app.schemas.CurrentUser [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:79-79 :: id: int

Description: Stores the unique integer identifier of the authenticated user in the CurrentUser schema.

## Related Documents

- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 1.21)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.30)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.31)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.36)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.36)
- [backend.app.schemas.CurrentUser](c9f0033d-65ba-5095-b1f7-46936148c59a.md) - Related (graph distance 1.54)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.38)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 2.48)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 2.48)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.52)
