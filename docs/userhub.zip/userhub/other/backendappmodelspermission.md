---
id: 0e7843d6-44d3-5ac2-9d8c-ee08801cc3ed
type: catalog
title: "backend.app.models.Permission"
created_at: 2026-07-30T15:09:15.718546+00:00
updated_at: 2026-07-30T17:48:08.764690+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.models.Permission"
  signature: "class Permission(Base):"
  location: {'line_start': 69, 'line_end': 79, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "eda7cd20a9f9a684515e6318a2c25ced51564f4165bd8faee82f676fa105b2b2"
  description: "A SQLAlchemy ORM model representing a permission entity, mapping to a database table via the declarative `Base` class. It defines the structure for storing permission records used in authorization and access control."
---
# backend.app.models.Permission

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

class backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:69-79 :: class Permission(Base):

Description: A SQLAlchemy ORM model representing a permission entity, mapping to a database table via the declarative `Base` class. It defines the structure for storing permission records used in authorization and access control.

## Related Documents

- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 1.54)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 1.56)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 1.56)
- [backend.app.models.User](12309fd4-111e-542c-89a8-af5e3300ae89.md) - Related (graph distance 1.56)
- [backend.app.models.AuditLog](9ed8286b-7e90-5043-bf34-7c16096cb903.md) - Related (graph distance 1.62)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.84)
