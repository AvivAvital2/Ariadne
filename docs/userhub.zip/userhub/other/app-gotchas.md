---
id: 6c761e93-a2ca-5bf1-b763-ff674741f9a7
type: gotcha
title: "App Gotchas"
created_at: 2026-07-30T17:21:08.753013+00:00
updated_at: 2026-07-30T17:21:08.753028+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py
metadata:
  module_name: "backend.app"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# App Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/__init__.py`

The module you've provided contains only a docstring:

```python
"""UserHub backend — a FastAPI + SQLAlchemy user management service."""
```

There is **no actual source code** to analyze — no functions, classes, database models, route handlers, or configuration. As a result, I cannot identify concrete gotchas or pitfalls specific to this module, because none of the behaviors that would trigger them exist yet.

## What I Can Offer

Since the docstring describes a **FastAPI + SQLAlchemy user management service**, here are the categories of pitfalls I would look for *once the real code is provided*. These are anticipatory checklists, not findings:

### Anticipated: Sync SQLAlchemy in async routes
**Trigger:** Calling blocking SQLAlchemy session methods inside `async def` route handlers.
**Affected Files:** Route handlers, session/dependency code (not present here).
**Fix:** Use `AsyncSession` with `asyncpg`/`aiosqlite`, or run sync sessions via `run_in_threadpool`.
**Category:** async
**Example:**
```python
@app.get("/users")
async def list_users():
    return db.query(User).all()  # blocks the event loop
```

### Anticipated: Session-per-thread / thread safety
**Trigger:** Sharing a single SQLAlchemy `Session` across requests or threads.
**Affected Files:** DB session factory / dependencies (not present here).
**Fix:** Create a new session per request via a FastAPI dependency; use `scoped_session` carefully.
**Category:** thread-safety

### Anticipated: Pydantic/ORM null coercion surprises
**Trigger:** Optional columns returning `None` silently satisfying response models.
**Affected Files:** Pydantic schemas, ORM models (not present here).
**Fix:** Make nullability explicit in both ORM and schema; validate at boundaries.
**Category:** type-system

### Anticipated: N+1 query performance traps
**Trigger:** Lazy-loaded relationships accessed in loops/serialization.
**Affected Files:** Models with relationships, serializers (not present here).
**Fix:** Use `selectinload`/`joinedload` eager loading.
**Category:** performance

### Anticipated: Password/secret handling in a user service
**Trigger:** Storing plaintext passwords or leaking hashes in responses.
**Affected Files:** User model, auth logic (not present here).
**Fix:** Hash with bcrypt/argon2; exclude sensitive fields from response schemas.
**Category:** domain

---

**To get a real analysis**, please paste the actual module contents — e.g. the `models.py`, `main.py`/`app.py`, `schemas.py`, `database.py`, and route files. Once I can see the code, I'll produce concrete, file-specific gotchas in the requested format.