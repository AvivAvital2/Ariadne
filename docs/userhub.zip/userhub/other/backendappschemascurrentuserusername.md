---
id: 21ef1ade-124a-5c3f-94e7-ac924ecb6a6f
type: catalog
title: "backend.app.schemas.CurrentUser.username"
created_at: 2026-07-30T15:09:16.673984+00:00
updated_at: 2026-07-30T17:48:08.797399+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.CurrentUser.username"
  signature: "username: str"
  location: {'line_start': 80, 'line_end': 80, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "backend.app.schemas.CurrentUser"
  sha_at_sync: "a3b20fa634e0641ba74db0d45453059c90e29c0cc808ed99ee785150a3a81b29"
  description: "Stores the username of the currently authenticated user as a string."
---
# backend.app.schemas.CurrentUser.username

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.CurrentUser.username in backend.app.schemas.CurrentUser [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:80-80 :: username: str

Description: Stores the username of the currently authenticated user as a string.

## Related Documents

- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.23)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 1.24)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.27)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.32)
- [backend.app.models.User.username](e6944542-0f4c-5b3c-854a-1b1143cba0f7.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.50)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.54)
- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 2.61)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 2.61)
