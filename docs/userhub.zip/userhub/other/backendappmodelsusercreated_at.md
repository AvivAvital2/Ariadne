---
id: 8ea6c38c-c021-5ac6-a555-1fd72c4a3136
type: catalog
title: "backend.app.models.User.created_at"
created_at: 2026-07-30T15:09:15.721588+00:00
updated_at: 2026-07-30T17:48:08.767296+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.created_at"
  signature: "created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=_utcnow)"
  location: {'line_start': 44, 'line_end': 44, 'col_start': 4, 'col_end': 84}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "756e60f8254ccf6127b3a9ed36ff12e92a46651e13dcf145ad569975df9f7fdb"
  description: "Stores the timestamp when the User record was created, defaulting to the current UTC time via the `_utcnow` function."
---
# backend.app.models.User.created_at

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.created_at in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:44-44 :: created_at: Mapped[datetime.datetime] = mapped_column(DateTime, default=_utcnow)

Description: Stores the timestamp when the User record was created, defaulting to the current UTC time via the `_utcnow` function.

## Related Documents

- [backend.app.models.User.updated_at](d16fded0-b866-5b24-b3f4-c996ca1d98ea.md) - Related (graph distance 1.22)
- [backend.app.models.AuditLog.created_at](f84a7924-6247-540c-bf88-6538484215df.md) - Related (graph distance 1.25)
- [backend.app.schemas.UserOut.created_at](535e53d2-ce6c-5494-889d-0018699cdf42.md) - Related (graph distance 1.26)
- [backend.app.schemas.AuditLogOut.created_at](31c07d5e-1e35-57f6-95c2-d550675c0883.md) - Related (graph distance 1.39)
- [backend.app.schemas.UserOut.updated_at](3acb81b3-77cb-588b-8b04-50eda470cb17.md) - Related (graph distance 1.40)
- [backend.app.schemas.UserActivityRow.last_action_at](78bb4157-648a-5246-a4db-595d3c370f6d.md) - Related (graph distance 1.57)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 1.65)
