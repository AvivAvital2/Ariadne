---
id: f9d548bc-b026-5fd5-85ab-6023e5b3aa52
type: catalog
title: "backend.app.seed.seed_if_empty"
created_at: 2026-07-30T15:09:16.250271+00:00
updated_at: 2026-07-30T17:18:59.729442+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.seed.seed_if_empty"
  signature: "def seed_if_empty(db: Session) -> bool:"
  location: {'line_start': 20, 'line_end': 85, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "ce97c57aa8167a1336f258723323f7e06f743be8830fdd8a4d3d8468a0100f5c"
  description: "Populates the database with initial seed data only if it is currently empty, returning `True` if seeding was performed and `False` otherwise."
---
# backend.app.seed.seed_if_empty

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

function backend.app.seed.seed_if_empty [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:20-85 :: def seed_if_empty(db: Session) -> bool:

Description: Populates the database with initial seed data only if it is currently empty, returning `True` if seeding was performed and `False` otherwise.