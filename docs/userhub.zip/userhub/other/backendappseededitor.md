---
id: 6e2bd7b7-3ff8-58f4-9873-f0045a8b85d6
type: catalog
title: "backend.app.seed.editor"
created_at: 2026-07-30T15:09:16.251827+00:00
updated_at: 2026-07-30T17:48:08.780586+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.editor"
  signature: "editor = Role("
  location: {'line_start': 40, 'line_end': 49, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "745fa633fe7c39931be0f75ae5a1c8864bb63681c9bab81bc4b79bb50aac2645"
  description: "Defines a `Role` instance named "editor" used to seed the database with a predefined editor role and its associated permissions."
---
# backend.app.seed.editor

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.editor [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:40-49 :: editor = Role(

Description: Defines a `Role` instance named "editor" used to seed the database with a predefined editor role and its associated permissions.

## Related Documents

- [backend.app.seed.admin](4041d0d9-ff75-570f-9dd0-77920e758db4.md) - Related (graph distance 1.29)
- [backend.app.seed.viewer](97dec330-b5ac-57ef-af60-8400a71d11da.md) - Related (graph distance 1.36)
- [backend.app.seed.root](18365c02-cf65-5a40-bfe4-a549d2319780.md) - Related (graph distance 2.80)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 2.87)
