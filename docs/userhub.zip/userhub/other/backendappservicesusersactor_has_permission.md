---
id: 4a0c13f0-27bf-5e57-b7be-dc99ae913af0
type: catalog
title: "backend.app.services.users.actor_has_permission"
created_at: 2026-07-30T15:09:17.211420+00:00
updated_at: 2026-07-30T17:17:45.984316+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.actor_has_permission"
  signature: "def actor_has_permission(actor: User, permission: str) -> bool:"
  location: {'line_start': 35, 'line_end': 39, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "5525f3a7a080257c051ddb763e5222e5b1fb0f6722af0b40e6cbf759e9ab0f92"
  description: "Checks whether the given user (actor) has the specified permission, returning True if granted and False otherwise."
---
# backend.app.services.users.actor_has_permission

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.actor_has_permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:35-39 :: def actor_has_permission(actor: User, permission: str) -> bool:

Description: Checks whether the given user (actor) has the specified permission, returning True if granted and False otherwise.