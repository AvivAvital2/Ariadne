---
id: de42e7ba-8f21-5ff2-840f-f27e74b6f36a
type: catalog
title: "backend.app.routers.audit.list_audit"
created_at: 2026-07-30T15:09:16.473147+00:00
updated_at: 2026-07-30T17:48:08.783524+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.audit.list_audit"
  signature: "def list_audit("
  location: {'line_start': 17, 'line_end': 24, 'col_start': 0, 'col_end': 69}
  parent_qualified_name: None
  sha_at_sync: "1e8fc71879989c0f31d1092bb466eccfd6de88205e4b2d5b8e9ae2e0a170e869"
  description: "Retrieves and returns a list of audit log entries, exposed as an HTTP endpoint via the audit router."
---
# backend.app.routers.audit.list_audit

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

function backend.app.routers.audit.list_audit [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py:17-24 :: def list_audit(

Description: Retrieves and returns a list of audit log entries, exposed as an HTTP endpoint via the audit router.

## Related Documents

- [backend.app.services.audit.list_entries](a3001b30-5dd3-5847-a88a-26a5c75b8379.md) - Related (graph distance 1.34)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 1.54)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 1.54)
- [backend.app.routers.audit.router](f6e3ecc8-46b5-5b7c-b973-bef6ba750d07.md) - Related (graph distance 1.65)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.66)
- [backend.app.routers.reports.router](bad66bc7-e773-5982-a06f-097d09219abb.md) - Related (graph distance 2.93)
- [backend.app.routers.roles.router](3f73e456-0011-5a56-95f4-2a52726b2db7.md) - Related (graph distance 2.93)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 3.00)
- [backend.app.routers.users.router](4234b282-fa44-59ed-a663-636c40c44d88.md) - Related (graph distance 3.03)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 3.04)
