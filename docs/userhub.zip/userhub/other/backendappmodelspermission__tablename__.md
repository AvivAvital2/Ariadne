---
id: 4c6f0324-6589-5069-938c-4b0eec16aea3
type: catalog
title: "backend.app.models.Permission.__tablename__"
created_at: 2026-07-30T15:09:15.724164+00:00
updated_at: 2026-07-30T17:48:08.769313+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Permission.__tablename__"
  signature: "__tablename__ = "permissions""
  location: {'line_start': 70, 'line_end': 70, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.models.Permission"
  sha_at_sync: "39a6a0f5a1adbe760dc7ad95e3b0bc6fee573fc2ab8ee6c2bd56cb2e1f352bad"
  description: "Specifies the database table name as "permissions" for the SQLAlchemy `Permission` model."
---
# backend.app.models.Permission.__tablename__

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Permission.__tablename__ in backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:70-70 :: __tablename__ = "permissions"

Description: Specifies the database table name as "permissions" for the SQLAlchemy `Permission` model.

## Related Documents

- [backend.app.models.User.__tablename__](d2a6a7b3-ecb1-5671-9d6e-1dddc1d79573.md) - Related (graph distance 1.20)
- [backend.app.models.Role.__tablename__](37624afd-6108-5b4e-8e41-56008d592ced.md) - Related (graph distance 1.21)
- [backend.app.models.AuditLog.__tablename__](f7701d3c-d768-59a6-a353-5dc7d0dc27df.md) - Related (graph distance 1.26)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 2.82)
