---
id: c0635854-e157-5ed0-836c-3317d08ec451
type: catalog
title: "backend.app.services.roles.list_permissions"
created_at: 2026-07-30T15:09:17.243219+00:00
updated_at: 2026-07-30T17:48:08.854728+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.roles.list_permissions"
  signature: "def list_permissions(db: Session) -> list[Permission]:"
  location: {'line_start': 36, 'line_end': 37, 'col_start': 0, 'col_end': 63}
  parent_qualified_name: None
  sha_at_sync: "8d93dd5ca6c3786cc0285a61094ffbee003dc071a10ee97f63aec4583bca3513"
  description: "Retrieves and returns all Permission records from the database using the provided SQLAlchemy session."
---
# backend.app.services.roles.list_permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

function backend.app.services.roles.list_permissions [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py:36-37 :: def list_permissions(db: Session) -> list[Permission]:

Description: Retrieves and returns all Permission records from the database using the provided SQLAlchemy session.

## Related Documents

- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 1.18)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.46)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.66)
- [backend.app.services.roles.get_role](1ee43ae5-6edf-5b48-9b41-86136d1689ac.md) - Related (graph distance 2.61)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 2.68)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 2.84)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 2.88)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 3.04)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 3.04)
- [backend.app.routers.audit.list_audit](de42e7ba-8f21-5ff2-840f-f27e74b6f36a.md) - Related (graph distance 3.12)
