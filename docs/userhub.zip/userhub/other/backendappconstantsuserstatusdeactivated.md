---
id: 124dca39-7e4c-56e8-a63a-5e12d7ea3d9d
type: catalog
title: "backend.app.constants.UserStatus.DEACTIVATED"
created_at: 2026-07-30T15:09:15.958322+00:00
updated_at: 2026-07-30T17:48:08.775768+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.UserStatus.DEACTIVATED"
  signature: "DEACTIVATED = "deactivated""
  location: {'line_start': 21, 'line_end': 21, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "backend.app.constants.UserStatus"
  sha_at_sync: "8a4f5a0d8c26763f9cd8fb1cd0e55d023f3eb39fe76cfdf0c734c082c4477715"
  description: "Enum member of `UserStatus` representing a user account that has been deactivated, with the string value `"deactivated"`."
---
# backend.app.constants.UserStatus.DEACTIVATED

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.UserStatus.DEACTIVATED in backend.app.constants.UserStatus [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:21-21 :: DEACTIVATED = "deactivated"

Description: Enum member of `UserStatus` representing a user account that has been deactivated, with the string value `"deactivated"`.

## Related Documents

- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 1.20)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 1.32)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 1.36)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 1.39)
- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 1.43)
- [backend.app.constants.UserStatus.INVITED](311be302-09f8-5cba-8f71-b5116945a393.md) - Related (graph distance 1.50)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 2.36)
- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 2.50)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 2.53)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 2.56)
