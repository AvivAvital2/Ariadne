---
id: ec1d5c22-1443-5b53-b4de-19979e86393a
type: catalog
title: "backend.app.routers.users.create_user"
created_at: 2026-07-30T15:09:16.735584+00:00
updated_at: 2026-07-30T17:48:08.845170+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.create_user"
  signature: "def create_user("
  location: {'line_start': 62, 'line_end': 74, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "4cdbcc50018ff9d5ca7e182af8af5f34fdc22dbf0b2172d8c10963f9baa691dc"
  description: "Creates a new user record in the database from the provided user data, returning the created user. Typically handles a POST request to the users endpoint and may enforce constraints such as unique email or username."
---
# backend.app.routers.users.create_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.create_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:62-74 :: def create_user(

Description: Creates a new user record in the database from the provided user data, returning the created user. Typically handles a POST request to the users endpoint and may enforce constraints such as unique email or username.

## Related Documents

- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 1.19)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 1.45)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 1.50)
- [backend.app.services.roles.create_role](9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53.md) - Related (graph distance 1.51)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.52)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 1.56)
- [backend.app.services.roles.role](98eb86d0-4da5-5101-afd6-50e807b8bc0d.md) - Related (graph distance 2.91)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 2.92)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 2.95)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 2.96)
