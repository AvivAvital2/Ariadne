---
id: f0039981-57e6-54af-b99a-d32e1008d843
type: catalog
title: "backend.app.routers.users.set_user_status"
created_at: 2026-07-30T15:09:16.736191+00:00
updated_at: 2026-07-30T17:48:08.845983+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.set_user_status"
  signature: "def set_user_status("
  location: {'line_start': 94, 'line_end': 107, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "f6724bcb8b78e4e3c6f94da6175a3562c06b985fb487044aff736d6203e78aef"
  description: "Updates the active/inactive status of a specified user, typically restricted to administrative access. Returns the updated user record or an error if the user is not found."
---
# backend.app.routers.users.set_user_status

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.set_user_status [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:94-107 :: def set_user_status(

Description: Updates the active/inactive status of a specified user, typically restricted to administrative access. Returns the updated user record or an error if the user is not found.

## Related Documents

- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 1.37)
- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 1.46)
- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 1.51)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.61)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 1.62)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 2.80)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 2.88)
- [backend.app.services.users.query](d9f0755a-497e-52a9-be2e-4103bced037f.md) - Related (graph distance 2.96)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 2.96)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 2.96)
