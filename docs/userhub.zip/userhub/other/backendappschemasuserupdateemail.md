---
id: e7c526b2-7877-56cd-8d0c-efb5fdb089ad
type: catalog
title: "backend.app.schemas.UserUpdate.email"
created_at: 2026-07-30T15:09:16.668900+00:00
updated_at: 2026-07-30T17:48:08.794512+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserUpdate.email"
  signature: "email: str | None = None"
  location: {'line_start': 43, 'line_end': 43, 'col_start': 4, 'col_end': 28}
  parent_qualified_name: "backend.app.schemas.UserUpdate"
  sha_at_sync: "acd6b3ae8afd7cd7aa272ef8055a0cbf71d70b6126cb6dde6e09fc6b25109dea"
  description: "Optional email field for updating a user's email address, defaulting to `None` when not provided in the update request."
---
# backend.app.schemas.UserUpdate.email

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserUpdate.email in backend.app.schemas.UserUpdate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:43-43 :: email: str | None = None

Description: Optional email field for updating a user's email address, defaulting to `None` when not provided in the update request.

## Related Documents

- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 1.33)
- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 1.37)
- [backend.app.models.User.email](16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8.md) - Related (graph distance 1.43)
- [backend.app.services.users.email](c9d9526a-dd04-57c7-b212-845716fc2b78.md) - Related (graph distance 1.51)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 2.53)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.64)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.65)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.68)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 2.72)
