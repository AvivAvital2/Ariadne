---
id: 9e469310-a7d5-5b6e-80cb-23d58e340681
type: catalog
title: "backend.app.seed.ts"
created_at: 2026-07-30T15:09:16.254310+00:00
updated_at: 2026-07-30T17:48:08.782192+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.ts"
  signature: "ts = (now - datetime.timedelta(days=days_ago)).replace("
  location: {'line_start': 113, 'line_end': 115, 'col_start': 8, 'col_end': 9}
  parent_qualified_name: None
  sha_at_sync: "267fe21a064efb385eebb27f1d5cbc3379f006380570fd3208ed3ffd25d24a05"
  description: "Computes a timestamp by subtracting a specified number of days (`days_ago`) from the current time (`now`), used for seeding records with backdated timestamps."
---
# backend.app.seed.ts

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.ts [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:113-115 :: ts = (now - datetime.timedelta(days=days_ago)).replace(

Description: Computes a timestamp by subtracting a specified number of days (`days_ago`) from the current time (`now`), used for seeding records with backdated timestamps.

## Related Documents

- [backend.app.seed.now](c0d4b4d7-e036-5f8a-bb67-5a84a7345374.md) - Related (graph distance 1.45)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 3.09)
