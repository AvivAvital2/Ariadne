---
id: 33babfda-be6e-5c55-bab9-c54508201c03
type: catalog
title: "backend.app.schemas.PermissionOut"
created_at: 2026-07-30T15:09:16.660470+00:00
updated_at: 2026-07-30T17:48:08.784933+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.PermissionOut"
  signature: "class PermissionOut(BaseModel):"
  location: {'line_start': 14, 'line_end': 18, 'col_start': 0, 'col_end': 20}
  parent_qualified_name: None
  sha_at_sync: "8dbc789c371c4dcc24a2ab226023c55ca6107f0452cf72a3398b740d3cb8a7c8"
  description: "A Pydantic model representing the output/response schema for a permission, defining the fields returned when serializing permission data via the API."
---
# backend.app.schemas.PermissionOut

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.PermissionOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:14-18 :: class PermissionOut(BaseModel):

Description: A Pydantic model representing the output/response schema for a permission, defining the fields returned when serializing permission data via the API.

## Related Documents

- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 1.31)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.33)
- [backend.app.schemas.AuditLogOut](6e6767f4-fae6-512e-a9bf-fdd8f6b39d44.md) - Related (graph distance 1.46)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.52)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.53)
- [backend.app.models.Permission](0e7843d6-44d3-5ac2-9d8c-ee08801cc3ed.md) - Related (graph distance 1.54)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 1.66)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.69)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 2.70)
