---
id: dac812a4-c563-5117-b391-45770c7406de
type: catalog
title: "backend.app.models.Role.permissions"
created_at: 2026-07-30T15:09:15.723889+00:00
updated_at: 2026-07-30T17:48:08.769553+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Role.permissions"
  signature: "permissions: Mapped[list["Permission"]] = relationship("
  location: {'line_start': 64, 'line_end': 66, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "backend.app.models.Role"
  sha_at_sync: "95ddbcb8dbe841f7a435d75e6ee5443052041a0ec049233904563dd30f1f9387"
  description: "Defines a many-to-many ORM relationship mapping a Role to its associated Permission objects."
---
# backend.app.models.Role.permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Role.permissions in backend.app.models.Role [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:64-66 :: permissions: Mapped[list["Permission"]] = relationship(

Description: Defines a many-to-many ORM relationship mapping a Role to its associated Permission objects.

## Related Documents

- [backend.app.models.Permission.roles](d0dd4ccf-ac79-5c30-b62c-acf02af231df.md) - Related (graph distance 1.31)
- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 1.39)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.43)
- [backend.app.models.role_permissions](2862ba3a-f04e-542f-b12e-006257f4a4d6.md) - Related (graph distance 1.45)
- [backend.app.models.Role.users](b9039759-eb64-5b55-b552-7022ea8b09f5.md) - Related (graph distance 1.48)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 1.56)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 2.71)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 2.78)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.79)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 2.88)
