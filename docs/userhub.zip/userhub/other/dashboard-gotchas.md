---
id: d2a75bc8-35cf-5bba-a14e-e06874d60535
type: gotcha
title: "Dashboard Gotchas"
created_at: 2026-07-30T17:27:45.472557+00:00
updated_at: 2026-07-30T17:27:45.472572+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx
metadata:
  module_name: "frontend.src.components.Dashboard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Dashboard Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Dashboard.jsx`

# Gotchas & Pitfalls: `Dashboard`

### Missing loading state creates false "empty" flashes
**Trigger:** On first render (before the `Promise.all` resolves), all state arrays are empty `[]`. The UI renders "No roles yet.", "No activity yet.", stat values of 0, etc., then flashes to real data once the fetch completes.
**Affected Files:** `Dashboard.jsx`
**Fix:** Track a `loading` flag and render skeletons/spinners until data has arrived. Distinguish "loaded but empty" from "not yet loaded."
**Category:** async
**Example:**
```javascript
const [loading, setLoading] = useState(true);
// ...
.finally(() => setLoading(false));
// {loading ? <Skeleton /> : stats.roleData.length ? <BarChart/> : <p>No roles</p>}
```

---

### `setState` after unmount / stale promise
**Trigger:** If the component unmounts (or effect re-runs) before `Promise.all` resolves, the `.then` still calls `setUsers` etc. There is no cancellation. In StrictMode dev, the effect runs twice, firing two overlapping fetch batches.
**Affected Files:** `Dashboard.jsx`
**Fix:** Use an `ignore`/`AbortController` guard inside the effect.
**Category:** async
**Example:**
```javascript
useEffect(() => {
  let ignore = false;
  Promise.all([...]).then(([u, r, a, rep]) => {
    if (ignore) return;
    setUsers(u); /* ... */
  });
  return () => { ignore = true; };
}, []);
```

---

### `Promise.all` is all-or-nothing — one failed endpoint blanks the whole dashboard
**Trigger:** If any of the four API calls rejects, the entire `.then` is skipped and `error` is set. Three healthy datasets are discarded because a single endpoint (e.g. `userActivityReport`) failed.
**Affected Files:** `Dashboard.jsx`, `../api/client.js`
**Fix:** Use `Promise.allSettled` and render partial data, showing per-panel errors.
**Category:** async
**Example:**
```javascript
const [u, r, a, rep] = await Promise.allSettled([...]);
setUsers(u.status === "fulfilled" ? u.value : []);
```

---

### `u.roles.some(...)` throws if a user has no `roles` array
**Trigger:** `computeStats` assumes every user object has a `.roles` array. If the API returns a user with `roles: null` or omits the field, `u.roles.some` throws `TypeError: Cannot read properties of undefined`, crashing the whole `useMemo` and render.
**Affected Files:** `Dashboard.jsx`
**Fix:** Guard with `(u.roles ?? [])`.
**Category:** type-system
**Example:**
```javascript
value: users.filter((u) => (u.roles ?? []).some((x) => x.id === r.id)).length,
```

---

### `dotClass` / label lookups assume `action` is always a string
**Trigger:** `dotClass(e.action)` calls `action.includes(...)`. If `action` is `null`/`undefined`/numeric from a malformed audit row, `.includes` throws. Same risk for any non-string action.
**Affected Files:** `Dashboard.jsx`
**Fix:** Coerce/guard: `String(action ?? "")` before calling `.includes`.
**Category:** type-system
**Example:**
```javascript
function dotClass(action) {
  const a = String(action ?? "");
  if (a.includes("deactivated") || a.includes("deleted")) return "bad";
  ...
}
```

---

### Timezone bug: `sameDay` uses local calendar, `created_at` may be UTC
**Trigger:** `new Date(e.created_at)` parses an ISO string; `sameDay` compares local `getFullYear/Month/Date`. Events near midnight get bucketed into the wrong day depending on the viewer's timezone, and `fmtDay` labels are local-day weekdays. The 7-day window boundary is also local-midnight relative, so `events7d` counts can drift.
**Affected Files:** `Dashboard.jsx`
**Fix:** Decide on a canonical timezone (UTC or user-local) and normalize both the day buckets and the event timestamps consistently.
**Category:** domain
**Example:**
```javascript
// Event at 2024-01-01T23:30:00Z viewed in UTC-5 counts as Jan 1 local, not Jan 2
```

---

### DST makes `setDate(now.getDate() - i)` produce off-by-one days
**Trigger:** Iterating days via `d.setDate(now.getDate() - i)` across a daylight-saving transition can yield a duplicated or skipped calendar day because the arithmetic operates on wall-clock time. Combined with `findIndex(sameDay)`, an event could match zero buckets or the wrong one.
**Affected Files:** `Dashboard.jsx`
**Fix:** Build day keys from a normalized date (set to midnight) or use a date library; bucket by `toDateString()` in a `Map`.
**Category:** domain
**Example:**
```javascript
// On spring-forward day, day math can land on 23:00 the previous day
```

---

### `new Date(invalid)` silently yields `Invalid Date`, not an error
**Trigger:** If `created_at` is `null` or malformed, `new Date(...)` returns `Invalid Date`. `sameDay` comparisons all return false (event silently dropped from counts), and `timeAgo` returns `NaN...ago` / a nonsensical string with no visible failure.
**Affected Files:** `Dashboard.jsx`
**Fix:** Validate with `Number.isNaN(date.getTime())` and fall back to a placeholder.
**Category:** type-system
**Example:**
```javascript
function timeAgo(iso) {
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return "—";
  ...
}
```

---

### O(users × roles) filter recomputed on every relevant change
**Trigger:** `roleData` does `users.filter(u => u.roles.some(...))` inside a `roles.map`, giving O(R × U × rolesPerUser). For large tenants this runs on every dependency change of the memo (any of the four arrays changing).
**Affected Files:** `Dashboard.jsx`
**Fix:** Precompute a role→count map in a single pass over users.
**Category:** performance
**Example:**
```javascript
const counts = new Map();
users.forEach(u => (u.roles ?? []).forEach(x => counts.set(x.id, (counts.get(x.id) ?? 0) + 1)));
const roleData = roles.map(r => ({ label: r.name, value: counts.get(r.id) ?? 0, color: SERIES_BLUE }));
```

---

### `.sort()` mutates — `.slice()` guards it, but the pattern is fragile
**Trigger:** `report.slice().sort(...)` and `audit.slice().sort(...)` correctly copy first. If a future edit removes the `.slice()`, `.sort()` mutates the React state array in place, causing subtle "state changed without setState" bugs and skipped re-renders.
**Affected Files:** `Dashboard.jsx`
**Fix:** Keep the copy explicit (`[...report]`) and add a comment, or use a non-mutating helper like `toSorted()`.
**Category:** framework
**Example:**
```javascript
const activeUsers = [...report].sort((a, b) => b.action_count - a.action_count);
```

---

### Numeric-sort assumes `action_count` is a number
**Trigger:** `b.action_count - a.action_count` produces `NaN` if the field is a string (e.g. DB driver returns counts as strings). `NaN` comparisons make the sort order undefined/unstable.
**Affected Files:** `Dashboard.jsx`, backend report endpoint
**Fix:** Coerce with `Number(x.action_count)` before subtracting, or ensure the API serializes counts as numbers.
**Category:** type-system
**Example:**
```javascript
.sort((a, b) => Number(b.action_count) - Number(a.action_count))
```

---

### `key={e.id}` breaks if audit rows lack an `id`
**Trigger:** The feed uses `key={e.id}`. If audit events don't carry an `id` (or duplicates exist), React warns and mis-reconciles list items, causing visual glitches.
**Affected Files:** `Dashboard.jsx`
**Fix:** Ensure a stable unique key; fall back to a composite key.
**Category:** framework
**Example:**
```javascript
key={e.id ?? `${e.action}-${e.created_at}-${e.target_id}`}
```

---

### Static `now`/`Date.now()` — timestamps never refresh
**Trigger:** `computeStats` captures `now = new Date()` once per memo run, and `timeAgo` uses `Date.now()` only at render. The "X min ago" labels and the 7-day window go stale if the dashboard sits open; nothing re-renders on a timer.
**Affected Files:** `Dashboard.jsx`
**Fix:** Add a periodic tick (`setInterval` updating a state value) to force re-render, or accept staleness explicitly.
**Category:** domain
**Example:**
```javascript
useEffect(() => { const id = setInterval(() => setTick(t => t + 1), 60000); return () => clearInterval(id); }, []);
```

---

### Status buckets silently ignore unknown statuses
**Trigger:** `byStatus` counts every `u.status`, but `total` includes all users while `statusData`/`active`/`deactivated` only surface the three known constants. A user with an unexpected status (typo, new enum value) inflates `total` but appears in no chart segment, so donut segments won't sum to total.
**Affected Files:** `Dashboard.jsx`, `../constants.js`
**Fix:** Add an "Other" bucket or assert on unknown statuses.
**Category:** domain
**Example:**
```javascript
// total = 100, but Active+Invited+Deactivated = 97 → 3 users invisible
```