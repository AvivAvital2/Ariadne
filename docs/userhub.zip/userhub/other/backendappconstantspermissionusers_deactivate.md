---
id: 7dfcaa77-980d-5b54-83fb-08f2b6ee91e0
type: catalog
title: "backend.app.constants.Permission.USERS_DEACTIVATE"
created_at: 2026-07-30T15:09:15.959848+00:00
updated_at: 2026-07-30T17:48:08.776770+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.USERS_DEACTIVATE"
  signature: "USERS_DEACTIVATE = "users:deactivate""
  location: {'line_start': 36, 'line_end': 36, 'col_start': 4, 'col_end': 41}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "a0c563a8b68a4f819adde81afe0c2ec52865b3d151e67c4c20ffa8b569224a4b"
  description: "Defines the permission constant granting the ability to deactivate user accounts, represented by the string value `"users:deactivate"`."
---
# backend.app.constants.Permission.USERS_DEACTIVATE

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.USERS_DEACTIVATE in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:36-36 :: USERS_DEACTIVATE = "users:deactivate"

Description: Defines the permission constant granting the ability to deactivate user accounts, represented by the string value `"users:deactivate"`.

## Related Documents

- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.16)
- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 1.29)
- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.30)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 1.34)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 1.39)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 2.59)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 2.64)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 2.66)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 2.71)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 2.75)
