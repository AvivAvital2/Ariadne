---
id: 4440b2a0-7f13-5550-be5f-4e8be81b96d0
type: gotcha
title: "Security Gotchas"
created_at: 2026-07-30T17:24:45.927717+00:00
updated_at: 2026-07-30T17:24:45.927730+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  module_name: "backend.app.security"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Security Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

# Gotchas and Pitfalls: `backend.app.security`

### Header spoofing — authentication is trivially forged
**Trigger:** `X-Actor-Id` is trusted verbatim as identity. Any client can set this header to any user ID and impersonate them, including admins.
**Affected Files:** `backend/app/security.py` (both `current_actor` and `checker`)
**Fix:** This header should only ever be set by a trusted upstream (gateway/proxy) after real authentication, and the app must reject it from untrusted sources. Ideally replace with a signed token (JWT/session cookie) verified server-side.
**Category:** domain
**Example:**
```bash
# Impersonate user 1 (likely an admin) — no password, no token needed
curl -H "X-Actor-Id: 1" https://api/users/999/deactivate
```

---

### Missing header returns 422, not 401
**Trigger:** FastAPI's `Header(...)` marks the header required, so a *missing* header produces a `422 Unprocessable Entity` validation error before your code runs — not the `401` a caller might expect for "unauthenticated."
**Affected Files:** `backend/app/security.py`
**Fix:** If you want 401 for missing credentials, make the header optional (`Header(None)`) and raise `HTTPException(401)` yourself when it's absent.
**Category:** framework
**Example:**
```python
# Request with no X-Actor-Id header
# Expected by many: 401 unknown actor
# Actual: 422 {"detail":[{"loc":["header","X-Actor-Id"],"msg":"field required"}]}
```

---

### Non-integer header value also yields 422, silently
**Trigger:** `x_actor_id: int` triggers FastAPI coercion. A value like `X-Actor-Id: abc` fails validation with 422; `X-Actor-Id: 1.0` also fails. The endpoint code never sees these cases.
**Affected Files:** `backend/app/security.py`
**Fix:** Be aware that type coercion happens in the framework layer; document that the response for malformed headers is 422. Consider validating explicitly if you need custom error shapes.
**Category:** type-system
**Example:**
```bash
curl -H "X-Actor-Id: 007a" ...   # -> 422, not "unknown actor"
```

---

### Duplicated auth logic drifts between `current_actor` and `checker`
**Trigger:** The actor-resolution + 401 logic is copy-pasted in two places. A fix (e.g., changing 422→401, adding logging, handling disabled users) applied to one is easily forgotten in the other.
**Affected Files:** `backend/app/security.py`
**Fix:** Factor a shared helper (e.g., `_resolve_actor(x_actor_id, db)`) and have both call it.
**Category:** domain
**Example:**
```python
def _resolve_actor(x_actor_id: int, db: Session) -> User:
    actor = user_service.get_user(db, x_actor_id)
    if actor is None:
        raise HTTPException(401, "unknown actor")
    return actor
```

---

### No check that the actor account is active/enabled
**Trigger:** `get_user` returning a row means "authenticated." A deactivated/suspended user whose row still exists passes both `current_actor` and `checker` (subject only to permission strings).
**Affected Files:** `backend/app/security.py`, `app/services/users.py`
**Fix:** Check an `is_active`/`disabled` flag on the resolved user before admitting the request.
**Category:** domain
**Example:**
```python
if actor.disabled:
    raise HTTPException(403, "account disabled")
```

---

### `actor_has_permission` behavior on unknown permission strings is unverified
**Trigger:** `require_permission("users:deactivte")` (typo) compiles and runs fine. If `actor_has_permission` returns `False` for unknown strings, a legit action silently becomes forbidden; if it treats unknowns loosely, it could over-grant. Permission strings are stringly-typed with no validation.
**Affected Files:** `backend/app/security.py`, `app/services/users.py`
**Fix:** Define permissions as an enum/constant set and validate `permission` at dependency-build time (module import) so typos fail fast.
**Category:** type-system
**Example:**
```python
require_permission("uzers:deactivate")  # no error until every request 403s
```

---

### Dependency built at import time; permission string is captured by closure
**Trigger:** `require_permission(...)` must be called to *produce* the dependency. Passing the function itself (`Depends(require_permission)` instead of `Depends(require_permission("x"))`) silently injects the factory, not the checker — a subtle wiring bug.
**Affected Files:** `backend/app/security.py`, all routers using it
**Fix:** Always call it: `Depends(require_permission("users:deactivate"))`. Consider a naming convention or a type hint to catch misuse.
**Category:** framework
**Example:**
```python
# Wrong — checker never runs, actor never resolved
@router.post("/x", dependencies=[Depends(require_permission)])
# Right
@router.post("/x", dependencies=[Depends(require_permission("x:do"))])
```

---

### Two DB lookups when both dependencies apply to one endpoint
**Trigger:** An endpoint that both injects `current_actor` (e.g., to get the user object) and uses `require_permission` runs `get_user` twice against the DB for the same request.
**Affected Files:** `backend/app/security.py`
**Fix:** FastAPI caches dependencies by callable identity within a request, but these are two distinct callables so no caching occurs. Consolidate — have `require_permission` return the actor and reuse it, avoiding a second query.
**Category:** performance
**Example:**
```python
@router.post("/x")
def x(actor: User = Depends(current_actor),      # query 1
      _: User = Depends(require_permission("x"))): # query 2, same user
    ...
```

---

### Permission check runs on a detached/lazy ORM object
**Trigger:** `actor_has_permission(actor, permission)` may traverse relationships (e.g., `actor.roles`). If those are lazy-loaded, this happens within the request's DB session — fine here, but if the returned `User` is later used after the session closes, accessing relationships raises `DetachedInstanceError`.
**Affected Files:** `backend/app/security.py`, `app/services/users.py`, `app/database.py`
**Fix:** Eager-load required relationships in `get_user`, or ensure all attribute access happens before `get_db` tears down the session.
**Category:** framework
**Example:**
```python
# Later, after session closed:
actor.roles  # -> sqlalchemy.orm.exc.DetachedInstanceError
```

---

### Session lifecycle depends entirely on `get_db`'s generator hygiene
**Trigger:** These dependencies rely on `get_db` yielding a session and cleaning it up. If `get_db` doesn't close/rollback in a `finally`, an exception raised by `HTTPException` inside the checker could leak a connection.
**Affected Files:** `backend/app/database.py` (`get_db`), `backend/app/security.py`
**Fix:** Ensure `get_db` uses `try/finally` with `db.close()`. Note: raising `HTTPException` after the yield still runs the generator's cleanup — verify it does.
**Category:** async
**Example:**
```python
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()   # must exist, or 401/403 paths can leak
```

---

### Sync dependency on a session that may not be thread-safe
**Trigger:** These are `def` (sync) dependencies. FastAPI runs sync dependencies in a threadpool. A `Session` created per-request via `get_db` is fine, but sharing any `User` object or session across threads is not — SQLAlchemy `Session` is not thread-safe.
**Affected Files:** `backend/app/security.py`, `app/database.py`
**Fix:** Keep one session per request (as done) and never stash the returned `User`/`Session` in module-level or shared state.
**Category:** thread-safety
**Example:**
```python
_last_actor = None
def checker(...):
    global _last_actor
    _last_actor = actor  # DON'T — shared across threads/requests
```