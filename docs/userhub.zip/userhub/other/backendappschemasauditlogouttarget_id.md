---
id: 543481ae-f53e-5bf5-8a5b-d011540ee296
type: catalog
title: "backend.app.schemas.AuditLogOut.target_id"
created_at: 2026-07-30T15:09:16.676227+00:00
updated_at: 2026-07-30T17:48:08.842424+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.target_id"
  signature: "target_id: int | None"
  location: {'line_start': 92, 'line_end': 92, 'col_start': 4, 'col_end': 25}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "c68513eb33e3a15aa0ce14d3ddfccf70caebf70ef522b5c66a1225becb25e390"
  description: "Optional integer field on the `AuditLogOut` schema that identifies the ID of the entity targeted by the audited action, or `None` if not applicable."
---
# backend.app.schemas.AuditLogOut.target_id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.target_id in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:92-92 :: target_id: int | None

Description: Optional integer field on the `AuditLogOut` schema that identifies the ID of the entity targeted by the audited action, or `None` if not applicable.

## Related Documents

- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.19)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 1.23)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 1.32)
- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 1.36)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.58)
- [backend.app.services.users.target_id](347260a2-8d58-556f-89b7-d9cc05ee6faa.md) - Related (graph distance 1.63)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.53)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.58)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.61)
- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 2.62)
