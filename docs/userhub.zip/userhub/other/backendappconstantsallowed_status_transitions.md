---
id: 663456e9-6a70-51e7-8487-969396a3cc70
type: catalog
title: "backend.app.constants.ALLOWED_STATUS_TRANSITIONS"
created_at: 2026-07-30T15:09:16.001134+00:00
updated_at: 2026-07-30T17:19:02.475084+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.ALLOWED_STATUS_TRANSITIONS"
  signature: "ALLOWED_STATUS_TRANSITIONS: dict[str, set[str]] = {"
  location: {'line_start': 58, 'line_end': 62, 'col_start': 0, 'col_end': 1}
  parent_qualified_name: None
  sha_at_sync: "193a7ba5b619808584998a472544ad7487715bb6d63c86ccf0be69ea23a40ee0"
  description: "Defines the valid state machine transitions by mapping each status string to the set of statuses it is permitted to transition to."
---
# backend.app.constants.ALLOWED_STATUS_TRANSITIONS

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.ALLOWED_STATUS_TRANSITIONS [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:58-62 :: ALLOWED_STATUS_TRANSITIONS: dict[str, set[str]] = {

Description: Defines the valid state machine transitions by mapping each status string to the set of statuses it is permitted to transition to.