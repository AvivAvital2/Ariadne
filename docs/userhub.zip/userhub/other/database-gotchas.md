---
id: 6b4274ce-f26e-5ea8-ad2d-4947b83832af
type: gotcha
title: "Database Gotchas"
created_at: 2026-07-30T17:21:44.079717+00:00
updated_at: 2026-07-30T17:21:44.079731+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  module_name: "backend.app.database"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Database Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

# Gotchas and Pitfalls: `backend.app.database`

### SQLite `check_same_thread=False` disables a real safety guard

**Trigger:** Passing `check_same_thread: False` lets SQLite connections cross threads, but SQLite itself is not truly concurrent for writes. Under FastAPI's threadpool (sync endpoints) or shared sessions, concurrent writes can raise `database is locked` or cause interleaved transactions.
**Affected Files:** `backend/app/database.py`
**Fix:** The flag is *required* only because each connection must be usable from whatever threadpool thread serves the request — but each request must get its **own** session/connection (which `get_db` does). Never share a `Session` across threads. For write-heavy loads consider `PRAGMA journal_mode=WAL` and a busy timeout.
**Category:** thread-safety
**Example:**
```python
# BAD: sharing one session across threads/requests
shared = SessionLocal()  # module-level global
def handler(): shared.add(obj); shared.commit()  # race conditions / locked DB
# GOOD: one session per request via get_db()
```

### No connection pool sizing / default pool with SQLite is a `SingletonThreadPool` surprise

**Trigger:** With `sqlite:///` SQLAlchemy uses `QueuePool` by default when `check_same_thread=False` is set for a file DB, but for `:memory:` it silently switches to `SingletonThreadPool`, meaning every thread gets a *different* in-memory DB. Developers testing with `sqlite:///:memory:` see "table doesn't exist" errors.
**Affected Files:** `backend/app/database.py`
**Fix:** For in-memory testing use `poolclass=StaticPool` with `check_same_thread=False` so all threads share one connection.
**Category:** framework
**Example:**
```python
create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False},
              poolclass=StaticPool)  # otherwise each thread = empty DB
```

### `get_db` never commits — silent data loss

**Trigger:** `autocommit=False` and the dependency only calls `db.close()` in `finally`. Any endpoint that forgets to call `db.commit()` will have its changes rolled back on close, with no error.
**Affected Files:** `backend/app/database.py` + every route using `get_db`
**Fix:** Either commit explicitly in each endpoint, or wrap `get_db` to commit on success and rollback on exception.
**Category:** framework
**Example:**
```python
def endpoint(db=Depends(get_db)):
    db.add(user)      # looks saved...
    return user       # ...but never committed -> row disappears
```

### No rollback on exception leaves session in a broken/dirty state

**Trigger:** If an exception occurs mid-request, `get_db` only closes; it does not `rollback()`. With connection pooling, a connection with a pending failed transaction can be returned to the pool.
**Affected Files:** `backend/app/database.py`
**Fix:** Add explicit rollback in exception path.
**Category:** framework
**Example:**
```python
def get_db():
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
```

### Async endpoints + sync `Session` block the event loop

**Trigger:** `Session` and this engine are fully synchronous. If used inside an `async def` FastAPI route without threadpool offloading, DB calls block the event loop.
**Affected Files:** `backend/app/database.py`, async routes
**Fix:** Either use `def` (sync) endpoints so FastAPI runs them in a threadpool, or migrate to `create_async_engine` + `AsyncSession` with `await`.
**Category:** async
**Example:**
```python
async def route(db=Depends(get_db)):
    db.query(User).all()  # blocking call inside event loop -> stalls server
```

### Relative SQLite path depends on process CWD

**Trigger:** `sqlite:///./userhub.db` resolves relative to the current working directory, not the module location. Running from a different directory (tests, cron, Docker WORKDIR) silently creates/uses a *different* database file.
**Affected Files:** `backend/app/database.py`
**Fix:** Use an absolute path derived from the module or an env var.
**Category:** domain
**Example:**
```python
# started from /app -> /app/userhub.db
# started from /app/scripts -> /app/scripts/userhub.db (empty!)
```

### `autoflush=False` means queries won't see pending changes

**Trigger:** With autoflush disabled, objects added but not flushed are invisible to subsequent `query()` calls in the same session, and constraint violations surface later than expected.
**Affected Files:** `backend/app/database.py`
**Fix:** Call `db.flush()` explicitly when you need pending state queryable, or leave `autoflush=True` unless you have a specific reason.
**Category:** framework
**Example:**
```python
db.add(User(email="a@b.com"))
db.query(User).filter_by(email="a@b.com").first()  # returns None (not flushed)
```

### Module-level engine created at import time

**Trigger:** `engine` and `SessionLocal` are instantiated on import. Config-based URLs, test overrides, or environment-driven credentials must be set *before* import, and monkeypatching in tests is awkward.
**Affected Files:** `backend/app/database.py`
**Fix:** Wrap engine creation in a factory function or lazy accessor; use FastAPI dependency overrides for tests.
**Category:** framework
**Example:**
```python
import os; os.environ["DATABASE_URL"] = "..."  # too late — module already imported engine
```

### `Base` defined here but tables only created if metadata is imported

**Trigger:** `DeclarativeBase` alone doesn't create tables. If models aren't imported before `Base.metadata.create_all(engine)` runs, tables silently won't exist.
**Affected Files:** `backend/app/database.py`, model modules
**Fix:** Ensure all model modules are imported before `create_all`, or use migrations (Alembic).
**Category:** framework
**Example:**
```python
Base.metadata.create_all(engine)  # models not imported -> no tables, no error
```

### Foreign keys are OFF by default in SQLite

**Trigger:** SQLite does not enforce foreign key constraints unless `PRAGMA foreign_keys=ON` is issued per connection. ORM relationships appear to work but cascades/constraint checks silently don't fire.
**Affected Files:** `backend/app/database.py`
**Fix:** Register an event listener to enable FKs on each connection.
**Category:** domain
**Example:**
```python
from sqlalchemy import event
@event.listens_for(engine, "connect")
def _fk(conn, _): conn.execute("PRAGMA foreign_keys=ON")
```