---
id: 9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53
type: catalog
title: "backend.app.services.roles.create_role"
created_at: 2026-07-30T15:09:17.242875+00:00
updated_at: 2026-07-30T17:48:08.855397+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.roles.create_role"
  signature: "def create_role("
  location: {'line_start': 20, 'line_end': 33, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "ff9e559e46988db1209dcb9fb27c61562e7040574113e9249899ead116de8879"
  description: "Creates a new role record in the database from the provided role data, returning the newly persisted role instance."
---
# backend.app.services.roles.create_role

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

function backend.app.services.roles.create_role [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py:20-33 :: def create_role(

Description: Creates a new role record in the database from the provided role data, returning the newly persisted role instance.

## Related Documents

- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 1.22)
- [backend.app.services.roles.role](98eb86d0-4da5-5101-afd6-50e807b8bc0d.md) - Related (graph distance 1.39)
- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 1.44)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 1.51)
- [backend.app.services.roles.get_role](1ee43ae5-6edf-5b48-9b41-86136d1689ac.md) - Related (graph distance 1.58)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 2.78)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 2.88)
- [backend.app.routers.users.assign_roles](c95f5b82-4808-5a02-b583-176903208b03.md) - Related (graph distance 2.88)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 2.97)
- [backend.app.schemas.RoleCreate.name](36956015-e80e-5737-9b0b-189e09d3e3b5.md) - Related (graph distance 3.01)
