---
id: c0d4b4d7-e036-5f8a-bb67-5a84a7345374
type: catalog
title: "backend.app.seed.now"
created_at: 2026-07-30T15:09:16.253637+00:00
updated_at: 2026-07-30T17:48:08.781970+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.now"
  signature: "now = datetime.datetime.now(datetime.timezone.utc)"
  location: {'line_start': 90, 'line_end': 90, 'col_start': 4, 'col_end': 54}
  parent_qualified_name: None
  sha_at_sync: "72996573f306e112452a2c7b555f87333d24b4a44320426b33f3ffc9148c9ce5"
  description: "Stores the current UTC timestamp at module load/seed execution time, used as a reference point for seeding time-based data."
---
# backend.app.seed.now

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.now [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:90-90 :: now = datetime.datetime.now(datetime.timezone.utc)

Description: Stores the current UTC timestamp at module load/seed execution time, used as a reference point for seeding time-based data.

## Related Documents

- [backend.app.seed.ts](9e469310-a7d5-5b6e-80cb-23d58e340681.md) - Related (graph distance 1.45)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 1.64)
