---
id: d0dd4ccf-ac79-5c30-b62c-acf02af231df
type: catalog
title: "backend.app.models.Permission.roles"
created_at: 2026-07-30T15:09:15.725255+00:00
updated_at: 2026-07-30T17:48:08.770574+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Permission.roles"
  signature: "roles: Mapped[list[Role]] = relationship("
  location: {'line_start': 77, 'line_end': 79, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "backend.app.models.Permission"
  sha_at_sync: "09867e1c5c9b0b19545373617cabf23362ba902cf2aeae30b431615bcab6d3e1"
  description: "Defines a many-to-many relationship mapping the `Permission` model to its associated `Role` entities."
---
# backend.app.models.Permission.roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Permission.roles in backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:77-79 :: roles: Mapped[list[Role]] = relationship(

Description: Defines a many-to-many relationship mapping the `Permission` model to its associated `Role` entities.

## Related Documents

- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 1.15)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 1.31)
- [backend.app.models.Role.users](b9039759-eb64-5b55-b552-7022ea8b09f5.md) - Related (graph distance 1.48)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 1.50)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 1.52)
- [backend.app.models.role_permissions](2862ba3a-f04e-542f-b12e-006257f4a4d6.md) - Related (graph distance 1.58)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 2.72)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 2.75)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 2.87)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 3.00)
