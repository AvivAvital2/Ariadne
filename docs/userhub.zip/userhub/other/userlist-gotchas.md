---
id: 5ac6477c-2e82-554c-bbb6-d4da23238c41
type: gotcha
title: "Userlist Gotchas"
created_at: 2026-07-30T17:29:19.053995+00:00
updated_at: 2026-07-30T17:29:19.054010+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx
metadata:
  module_name: "frontend.src.components.UserList"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Userlist Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/UserList.jsx`

# Gotchas & Pitfalls: `UserList`

### Unhandled null/undefined `user.roles` crashes render
**Trigger:** Rendering a user whose `roles` field is `null` or `undefined` (e.g., API omits it, or a partial object returned by an action).
**Affected Files:** `UserList.jsx`
**Fix:** Guard with optional chaining / default: `(user.roles ?? []).map(...)`.
**Category:** type-system
**Example:**
```javascript
// If user.roles is undefined:
{user.roles.map((r) => r.name).join(", ") || "—"} // TypeError: Cannot read 'map' of undefined
// Safer:
{(user.roles ?? []).map((r) => r.name).join(", ") || "—"}
```

---

### Stale closure / no cleanup on unmount in `useEffect`
**Trigger:** Component unmounts before `load()`'s promise resolves; `setUsers`/`setError` fire on an unmounted component. Also `load` is called in effect but not listed in deps (works only because it's stable-ish, but ESLint will complain).
**Affected Files:** `UserList.jsx`
**Fix:** Use an `AbortController` or a mounted flag, and either memoize `load` with `useCallback` or inline it.
**Category:** async
**Example:**
```javascript
useEffect(() => {
  let alive = true;
  api.listUsers()
    .then((u) => alive && setUsers(u))
    .catch((e) => alive && setError(e.message));
  return () => { alive = false; };
}, []);
```

---

### Concurrent `runAction` calls / rapid clicks race
**Trigger:** User double-clicks Delete/Deactivate, or clicks multiple row actions quickly. Multiple `runAction` calls fire overlapping requests + `load()` calls; the last resolved `load()` wins, and there's no button disabling, so duplicate deletes hit the API.
**Affected Files:** `UserList.jsx`
**Fix:** Track a per-action pending state and disable buttons while in flight.
**Category:** async
**Example:**
```javascript
const [busy, setBusy] = useState(false);
const runAction = async (fn) => {
  if (busy) return;
  setBusy(true); setError(null);
  try { await fn(); await load(); }
  finally { setBusy(false); }
};
// <button disabled={busy} ...>
```

---

### `error` is never cleared on successful reload path from `load()`
**Trigger:** Initial `load()` (in `useEffect`) fails, setting `error`. A later successful `load()` (triggered by `onSaved`) does **not** clear the previous error because `load` only calls `.catch`, never resetting `error` to `null` on success.
**Affected Files:** `UserList.jsx`
**Fix:** Clear error at the start of `load` or on success.
**Category:** framework
**Example:**
```javascript
const load = () =>
  api.listUsers()
    .then((u) => { setUsers(u); setError(null); }) // clear stale error
    .catch((e) => setError(e.message));
```

---

### Client-side permission checks are UI-only, not security
**Trigger:** Relying on `canEdit`/`canDelete` to protect operations. Hiding buttons does not prevent a determined user from calling `api.deleteUser` directly.
**Affected Files:** `UserList.jsx`, `../auth/permissions.js`, backend API
**Fix:** Always enforce permissions server-side; treat these flags purely as UX.
**Category:** domain
**Example:**
```javascript
// A user without canDelete can still POST to the delete endpoint.
// Server must re-check the actor's permission.
```

---

### `editing` state uses a magic string mixed with objects
**Trigger:** `editing` can be `null`, the string `"new"`, or a user object. A truthy user object with no `id`, or a user literally named `"new"` won't happen here, but the overloaded type is error-prone — `editing === "new"` is the only distinguisher.
**Affected Files:** `UserList.jsx`, `UserForm.jsx`
**Fix:** Use a discriminated shape like `{ mode: "new" }` / `{ mode: "edit", user }`.
**Category:** type-system
**Example:**
```javascript
// Fragile:
user={editing === "new" ? null : editing}
// Clearer:
const [editing, setEditing] = useState(null); // { mode, user }
```

---

### Editing a stale `user` object after external changes
**Trigger:** `setEditing(user)` captures the row's user object at click time. If the list reloads (via another action) while the form is open, the form holds a stale snapshot — edits may be based on outdated data.
**Affected Files:** `UserList.jsx`, `UserForm.jsx`
**Fix:** Pass the user `id` and refetch fresh data inside `UserForm`, or re-derive from `users` by id.
**Category:** framework
**Example:**
```javascript
// editing holds the old object even after load() replaces users[]
setEditing(user); // snapshot; won't update if users refresh
```

---

### `key={user.id}` assumes `id` always exists and is unique
**Trigger:** If the API ever returns users without `id` (or duplicate ids), React key collisions cause incorrect DOM reconciliation (wrong rows edited/deleted).
**Affected Files:** `UserList.jsx`
**Fix:** Validate the invariant, or fail loudly; never fall back to array index.
**Category:** framework
**Example:**
```javascript
{users.map((user) => (<tr key={user.id}>...</tr>))}
// undefined id -> key={undefined} -> React warns, keys collide
```

---

### Avatar slice assumes username is a string
**Trigger:** `(user.username || "?").slice(0,2)` — safe for missing username, but if `username` is a non-string (number from API), `.slice` may behave unexpectedly / `.toUpperCase()` throws.
**Affected Files:** `UserList.jsx`
**Fix:** Coerce: `String(user.username || "?")`.
**Category:** type-system
**Example:**
```javascript
(123 || "?").slice(0, 2) // TypeError: (intermediate).slice is not a function
```

---

### No empty-state; `users.length` count can mislead during load
**Trigger:** Before the first `load()` resolves, `users` is `[]`, so UI shows "0 total" and an empty table — indistinguishable from an actual empty result or a failed load.
**Affected Files:** `UserList.jsx`
**Fix:** Add explicit loading state and empty-state messaging.
**Category:** framework
**Example:**
```javascript
const [loading, setLoading] = useState(true);
// show spinner vs. "No users" vs. table
```

---

### Full list refetch after every action (performance)
**Trigger:** Every deactivate/delete/save triggers a complete `api.listUsers()` reload. On large user tables this re-fetches and re-renders everything.
**Affected Files:** `UserList.jsx`
**Fix:** Apply optimistic local updates, or patch the single changed record instead of full reload.
**Category:** performance
**Example:**
```javascript
// Instead of await load() after delete:
setUsers((prev) => prev.filter((u) => u.id !== id));
```