---
id: ff39b9c9-94bc-5fcd-b0b0-a140c1201887
type: catalog
title: "backend.app.seed._seed_audit_history"
created_at: 2026-07-30T15:09:16.250732+00:00
updated_at: 2026-07-30T17:18:59.744625+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.seed._seed_audit_history"
  signature: "def _seed_audit_history(db: Session, *, actors: list[int], targets: list[int]) -> None:"
  location: {'line_start': 88, 'line_end': 125, 'col_start': 0, 'col_end': 9}
  parent_qualified_name: None
  sha_at_sync: "6d2cb984e244d54dcfaf03429f24703afb2d1d2e70286201e634f77221fe81a2"
  description: "Populates the database with sample audit history records by generating entries that link the provided actor and target IDs. It commits these seeded records to the given database session."
---
# backend.app.seed._seed_audit_history

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

function backend.app.seed._seed_audit_history [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:88-125 :: def _seed_audit_history(db: Session, *, actors: list[int], targets: list[int]) -> None:

Description: Populates the database with sample audit history records by generating entries that link the provided actor and target IDs. It commits these seeded records to the given database session.