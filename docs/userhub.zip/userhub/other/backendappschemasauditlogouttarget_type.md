---
id: 8b3433df-a2d7-5700-8e87-d5ef95fec9de
type: catalog
title: "backend.app.schemas.AuditLogOut.target_type"
created_at: 2026-07-30T15:09:16.675937+00:00
updated_at: 2026-07-30T17:48:08.841913+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.target_type"
  signature: "target_type: str"
  location: {'line_start': 91, 'line_end': 91, 'col_start': 4, 'col_end': 20}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "d0693c7549e3b87324d06fa29091640c2586ff5170c063e12b74b42217901085"
  description: "Specifies the type of entity (as a string) that an audit log entry refers to, serving as a field within the `AuditLogOut` schema."
---
# backend.app.schemas.AuditLogOut.target_type

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.target_type in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:91-91 :: target_type: str

Description: Specifies the type of entity (as a string) that an audit log entry refers to, serving as a field within the `AuditLogOut` schema.

## Related Documents

- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 1.26)
- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 1.36)
- [backend.app.schemas.AuditLogOut.action](bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d.md) - Related (graph distance 1.50)
- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.60)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 2.59)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 2.67)
- [backend.app.models.AuditLog.action](4e1645db-d364-5489-8771-5ec8b957913b.md) - Related (graph distance 2.82)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 2.92)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.95)
- [backend.app.services.users.target_id](347260a2-8d58-556f-89b7-d9cc05ee6faa.md) - Related (graph distance 2.98)
