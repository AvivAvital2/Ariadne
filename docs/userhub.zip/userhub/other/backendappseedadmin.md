---
id: 4041d0d9-ff75-570f-9dd0-77920e758db4
type: catalog
title: "backend.app.seed.admin"
created_at: 2026-07-30T15:09:16.251472+00:00
updated_at: 2026-07-30T17:48:08.781045+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.admin"
  signature: "admin = Role("
  location: {'line_start': 35, 'line_end': 39, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "d0fbb7d405c4cc6f487fd88918be9ff06d57196c6876f4fcc66dd4a5f536a352"
  description: "Defines a module-level `Role` instance representing the administrator role, used as seed data for populating the database."
---
# backend.app.seed.admin

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.admin [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:35-39 :: admin = Role(

Description: Defines a module-level `Role` instance representing the administrator role, used as seed data for populating the database.

## Related Documents

- [backend.app.seed.editor](6e2bd7b7-3ff8-58f4-9873-f0045a8b85d6.md) - Related (graph distance 1.29)
- [backend.app.seed.viewer](97dec330-b5ac-57ef-af60-8400a71d11da.md) - Related (graph distance 1.46)
- [backend.app.seed.root](18365c02-cf65-5a40-bfe4-a549d2319780.md) - Related (graph distance 1.52)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 1.59)
- [backend.app.seed.bob](1c3620a3-bfc3-5c36-b44e-d470e854d85d.md) - Related (graph distance 2.81)
- [backend.app.seed.alice](702ee9ad-e28b-5754-bd86-f639bd90e28c.md) - Related (graph distance 2.89)
- [backend.app.models.User](12309fd4-111e-542c-89a8-af5e3300ae89.md) - Related (graph distance 3.06)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 3.06)
