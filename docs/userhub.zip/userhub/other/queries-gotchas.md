---
id: 745f2ec6-a902-5244-aaa3-ac127f4e69cb
type: gotcha
title: "Queries Gotchas"
created_at: 2026-07-30T17:22:37.035822+00:00
updated_at: 2026-07-30T17:22:37.035836+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  module_name: "backend.app.reports.queries"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Queries Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`

# Gotchas and Pitfalls: `backend.app.reports.queries`

### Missing WHERE clause forces full-table scan
**Trigger:** The query has no filtering — it aggregates every row in `users` and `audit_log`. As data grows, this `LEFT JOIN` + `GROUP BY` over the entire `audit_log` becomes progressively slower.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Add parameterized filters (date range, status, or pagination). Ensure an index exists on `audit_log.actor_id` and `audit_log.created_at`.
**Category:** performance
**Example:**
```sql
-- Every call scans the whole audit_log
FROM users u
LEFT JOIN audit_log a ON a.actor_id = u.id
-- Better: WHERE a.created_at >= :since  (with index on actor_id, created_at)
```

### No LIMIT — unbounded result set
**Trigger:** `ORDER BY action_count DESC` returns *every* user. A "top activity report" almost always wants a small subset, but this returns the full user table into memory.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Add `LIMIT` (ideally parameterized) or make it explicit that all rows are intended.
**Category:** performance
**Example:**
```sql
ORDER BY action_count DESC
-- add: LIMIT :limit OFFSET :offset
```

### `COUNT(a.id)` is always 0, never NULL — silent semantic gotcha
**Trigger:** Because of the `LEFT JOIN`, users with no audit entries produce NULL `a.id` rows. `COUNT(a.id)` counts non-NULL values, so those users get `action_count = 0` (correct), **not** NULL. Developers sometimes write `COUNT(*)` here, which would count the NULL-padded join row as `1`, silently inflating counts for inactive users.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Keep `COUNT(a.id)` (count a column from the joined table), never `COUNT(*)` with a LEFT JOIN.
**Category:** framework
**Example:**
```sql
COUNT(a.id)  -- correct: 0 for users with no actions
-- COUNT(*)  -- WRONG: returns 1 for users with zero actions
```

### `MAX(a.created_at)` returns NULL for inactive users
**Trigger:** Users with no audit log rows get `last_action_at = NULL`. Consuming code that does `datetime` arithmetic, formatting, or sorting on this column will hit `None`/`null` unexpectedly.
**Affected Files:** `backend/app/reports/queries.py` and any consumer mapping the result row.
**Fix:** Handle NULL in the consumer, or `COALESCE(MAX(a.created_at), <sentinel>)` if a non-null value is required. Be explicit in the mapped type (`Optional[datetime]`).
**Category:** type-system
**Example:**
```python
row["last_action_at"]  # can be None -> attribute/format errors downstream
```

### Ambiguous ORDER BY tie-breaking → unstable pagination
**Trigger:** Multiple users can share the same `action_count`. `ORDER BY action_count DESC` has no secondary key, so ordering among ties is non-deterministic across executions. If `LIMIT/OFFSET` pagination is added later, rows can be skipped or duplicated between pages.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Add a deterministic tiebreaker like `ORDER BY action_count DESC, u.id ASC`.
**Category:** framework
**Example:**
```sql
ORDER BY action_count DESC, u.id  -- stable ordering
```

### Bypasses ORM → no soft-delete / row-level security applied
**Trigger:** The docstring explicitly notes this reads tables "without going through the ORM." Any global filters the ORM applies (soft-delete flags like `deleted_at IS NULL`, tenant scoping, RLS) are silently skipped here, so deleted/hidden users may appear in reports.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Manually replicate ORM-level filters (`WHERE u.deleted_at IS NULL`, tenant filter) in the raw SQL, and document the assumption.
**Category:** domain
**Example:**
```sql
FROM users u
-- ORM would add: WHERE u.deleted_at IS NULL AND u.tenant_id = :tenant
```

### String constant invites SQL injection if templated
**Trigger:** This is a raw string. If a future developer adds dynamic filters via f-strings/`.format()` rather than bound parameters (since there's no parameter infrastructure shown), it opens injection.
**Affected Files:** `backend/app/reports/queries.py` and callers.
**Fix:** Always use driver parameter binding (`:param` / `%s`), never string interpolation, when extending this query.
**Category:** framework
**Example:**
```python
# DANGEROUS if someone extends it like this:
sql = USER_ACTIVITY_SQL + f" WHERE u.status = '{status}'"
# Use bound params instead: WHERE u.status = :status
```

### `status` column exposed raw — enum/DB drift
**Trigger:** `u.status` is selected as-is. If `status` is a DB enum or free-text column while the app uses a Python `Enum`, mismatched values (new DB states, casing) won't raise — they flow through silently and may break enum coercion in the consumer.
**Affected Files:** `backend/app/reports/queries.py` and result-mapping code.
**Fix:** Validate/coerce `status` in the consumer with a fallback, or constrain values in the query.
**Category:** type-system
**Example:**
```python
Status(row["status"])  # ValueError if DB has an unmapped status string
```

### GROUP BY must list every non-aggregated column (dialect-dependent)
**Trigger:** The query groups by `u.id, u.username, u.status`. On strict engines (PostgreSQL) this is required; on lenient ones (older MySQL with `ONLY_FULL_GROUP_BY` off) omitting columns silently "works" but returns arbitrary values. Adding a selected non-aggregate column without updating GROUP BY will fail on Postgres but pass on lax MySQL — a portability trap.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Keep GROUP BY in sync with all non-aggregated SELECT columns; test against the production dialect.
**Category:** framework
**Example:**
```sql
SELECT u.email, COUNT(a.id) ...  -- must add u.email to GROUP BY or Postgres errors
```