---
id: d16fded0-b866-5b24-b3f4-c996ca1d98ea
type: catalog
title: "backend.app.models.User.updated_at"
created_at: 2026-07-30T15:09:15.721864+00:00
updated_at: 2026-07-30T17:48:08.767534+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.updated_at"
  signature: "updated_at: Mapped[datetime.datetime] = mapped_column("
  location: {'line_start': 45, 'line_end': 47, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "646c129a2edee2f85c15859ac2f1820d0de1e9d2dd95fd9100dfc10075884666"
  description: "Timestamp column tracking when the User record was last modified, automatically updated on each change."
---
# backend.app.models.User.updated_at

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.updated_at in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:45-47 :: updated_at: Mapped[datetime.datetime] = mapped_column(

Description: Timestamp column tracking when the User record was last modified, automatically updated on each change.

## Related Documents

- [backend.app.models.User.created_at](8ea6c38c-c021-5ac6-a555-1fd72c4a3136.md) - Related (graph distance 1.22)
- [backend.app.schemas.UserOut.updated_at](3acb81b3-77cb-588b-8b04-50eda470cb17.md) - Related (graph distance 1.23)
- [backend.app.models.AuditLog.created_at](f84a7924-6247-540c-bf88-6538484215df.md) - Related (graph distance 1.37)
- [backend.app.schemas.UserOut.created_at](535e53d2-ce6c-5494-889d-0018699cdf42.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserActivityRow.last_action_at](78bb4157-648a-5246-a4db-595d3c370f6d.md) - Related (graph distance 1.47)
- [backend.app.schemas.AuditLogOut.created_at](31c07d5e-1e35-57f6-95c2-d550675c0883.md) - Related (graph distance 2.57)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 2.87)
