---
id: 1e3bf7d8-fe9d-5783-8dae-740d91a77d77
type: gotcha
title: "Models Gotchas"
created_at: 2026-07-30T17:22:35.063830+00:00
updated_at: 2026-07-30T17:22:35.063843+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  module_name: "backend.app.models"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Models Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

# Gotchas and Pitfalls: `backend.app.models`

### Naive/aware datetime mismatch with `DateTime` column
**Trigger:** `_utcnow()` returns a timezone-*aware* datetime, but the columns are declared as `DateTime` (which defaults to `timezone=False`). SQLite has no native datetime type and stores these as ISO strings, silently dropping tz info. When read back, you get a *naive* datetime — so what you wrote and what you read differ.
**Affected Files:** `backend/app/models.py`
**Fix:** Use `DateTime(timezone=True)` and be aware SQLite still won't preserve tz — or standardize on naive UTC everywhere and store `datetime.datetime.utcnow()`. Comparing aware and naive datetimes raises `TypeError`.
**Category:** type-system
**Example:**
```python
u.created_at                 # aware on insert (in-session identity map)
# after commit + expire + reload:
db.refresh(u)
u.created_at.tzinfo          # None — naive! comparisons now break
u.created_at > _utcnow()     # TypeError: can't compare offset-naive and offset-aware
```

---

### `onupdate` only fires on ORM-tracked UPDATEs
**Trigger:** `updated_at` uses `onupdate=_utcnow`, but this only triggers when SQLAlchemy issues an UPDATE for that row via the ORM flush. Bulk updates (`Query.update()`, `Session.execute(update(...))`) bypass it, leaving `updated_at` stale.
**Affected Files:** `backend/app/models.py`
**Fix:** For bulk updates, set `updated_at` explicitly, or use a DB-level trigger. Don't assume `onupdate` is universal.
**Category:** framework
**Example:**
```python
db.execute(update(User).where(User.id == 1).values(status="active"))
# updated_at NOT changed — onupdate skipped for bulk update
```

---

### `created_at`/`updated_at` `default` uses Python callable, not DB default
**Trigger:** `default=_utcnow` is a client-side default evaluated by SQLAlchemy at flush time. Rows inserted outside the ORM (raw SQL, migrations, other services) get `NULL` — but the column is non-nullable by mapping (`Mapped[datetime.datetime]`), so those inserts fail or store NULL depending on the actual DDL.
**Affected Files:** `backend/app/models.py`
**Fix:** Add `server_default=func.now()` if inserts can happen outside the ORM.
**Category:** framework
**Example:**
```python
db.execute(text("INSERT INTO users (username, email) VALUES ('a','a@x')"))
# created_at is NULL — no client-side default applied
```

---

### `Mapped[str]` columns are NOT NULL but lack a DB default for empties
**Trigger:** `full_name`, `description`, `detail` use `default=""`. Like above this is a *Python-side* default. A raw insert omitting the column violates NOT NULL. Also, `Mapped[str]` (non-optional) implies `nullable=False` — an accidental `None` assignment passes type checking but fails at flush.
**Affected Files:** `backend/app/models.py`
**Fix:** Use `server_default=""` for defense, or make them `Mapped[str | None]` if NULL is semantically valid.
**Category:** type-system
**Example:**
```python
u = User(username="x", email="x@y", full_name=None)  # mypy OK-ish, IntegrityError at flush
```

---

### `status` and `action` are stringly-typed enums with no DB constraint
**Trigger:** Comments say these hold `UserStatus`/`Permission`/`AuditAction` enum values, but the columns are plain `String`. Any typo (`"actived"`) is silently accepted; no validation, no FK, no CHECK constraint.
**Affected Files:** `backend/app/models.py`
**Fix:** Use `Mapped[UserStatus]` with `SQLEnum`, or add a validator / CHECK constraint. Enforce enum coercion at the application boundary.
**Category:** domain
**Example:**
```python
u.status = "actve"   # typo accepted; queries filtering status=="active" silently miss this user
```

---

### Lazy-loaded relationships raise `DetachedInstanceError` outside session
**Trigger:** `roles`, `users`, `permissions` default to lazy loading. Accessing them after the session is closed (e.g., returning an ORM object from a request handler and serializing later) raises `DetachedInstanceError`.
**Affected Files:** `backend/app/models.py`
**Fix:** Use eager loading (`selectinload`) when you'll access relationships post-session, or convert to Pydantic/dicts inside the session scope.
**Category:** framework
**Example:**
```python
user = db.get(User, 1)
db.close()
user.roles   # DetachedInstanceError: lazy load can't proceed
```

---

### N+1 query explosion on relationship access
**Trigger:** Default lazy loading means iterating a list of users and touching `.roles` fires one query per user, and `.permissions` compounds it further.
**Affected Files:** `backend/app/models.py`
**Fix:** Use `selectinload(User.roles).selectinload(Role.permissions)` when loading collections.
**Category:** performance
**Example:**
```python
for u in db.scalars(select(User)):   # 1 query
    u.roles                          # +1 query each → N+1
```

---

### Association tables lack cascade — orphaned link rows / FK errors on delete
**Trigger:** `user_roles`/`role_permissions` are bare `Table`s. Deleting a `User` doesn't automatically clean `user_roles` rows unless SQLAlchemy handles it via the relationship, and SQLite by default does **not** enforce FKs (`PRAGMA foreign_keys=ON` is off unless set per-connection).
**Affected Files:** `backend/app/models.py`, `backend/app/database.py`
**Fix:** Enable `PRAGMA foreign_keys=ON` via a connection event; rely on relationship-managed deletes or add `ondelete="CASCADE"` to the FKs.
**Category:** framework
**Example:**
```python
db.delete(user)  # user_roles rows may linger; SQLite won't complain (FKs off)
```

---

### `actor_id` FK to `users.id` has no ON DELETE behavior
**Trigger:** `AuditLog.actor_id` references `users.id` but is nullable with no `ondelete`. Deleting a user who created audit entries either errors (if FKs enforced) or leaves dangling references (if not). Audit logs arguably should never be deleted anyway.
**Affected Files:** `backend/app/models.py`
**Fix:** Use `ondelete="SET NULL"` to preserve audit history while dropping the reference, and consider blocking hard-deletes of users referenced in audits.
**Category:** domain
**Example:**
```python
db.delete(user_who_did_actions)  # audit rows now reference a nonexistent user
```

---

### No `__init__` type safety — required columns can be omitted silently
**Trigger:** SQLAlchemy's declarative `__init__` accepts any subset of columns. `User()` with no username/email constructs fine; the failure only surfaces at flush as an `IntegrityError`, far from the construction site.
**Affected Files:** `backend/app/models.py`
**Fix:** Validate at construction or use a Pydantic schema layer before instantiating ORM objects.
**Category:** type-system
**Example:**
```python
u = User()          # no error
db.add(u); db.commit()  # IntegrityError: NOT NULL constraint failed: users.username
```

---

### `email` is unique but not indexed for lookup
**Trigger:** `username` has `index=True`, but `email` only has `unique=True`. On most backends unique implies an index, but relying on it is implicit; also case-sensitivity: `"A@x.com"` and `"a@x.com"` are treated as distinct, allowing duplicate accounts.
**Affected Files:** `backend/app/models.py`
**Fix:** Normalize email to lowercase before insert; add explicit `index=True` and a functional/lowercase unique index if case-insensitivity is required.
**Category:** domain
**Example:**
```python
User(email="Bob@x.com"); User(email="bob@x.com")  # both accepted — duplicate identity
```

---

### `_utcnow` module-level default is shared but evaluated per-row (fine) — watch mutable defaults elsewhere
**Trigger:** `default=_utcnow` passes the *callable*, so it's re-evaluated per insert (correct). The gotcha is the easy mistake of writing `default=_utcnow()` (calling it), which freezes a single timestamp at import time for all rows.
**Affected Files:** `backend/app/models.py`
**Fix:** Always pass the callable (`_utcnow`), never the call (`_utcnow()`), for time defaults. Verify in code review.
**Category:** framework
**Example:**
```python
default=_utcnow    # correct: per-row
default=_utcnow()  # BUG: same import-time value for every row forever
```