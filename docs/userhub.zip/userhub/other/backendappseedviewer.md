---
id: 97dec330-b5ac-57ef-af60-8400a71d11da
type: catalog
title: "backend.app.seed.viewer"
created_at: 2026-07-30T15:09:16.252163+00:00
updated_at: 2026-07-30T17:48:08.780814+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.viewer"
  signature: "viewer = Role("
  location: {'line_start': 50, 'line_end': 54, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "7fd2e1b3099a5fb31270c7a90fb1ee4e54c81a406529862cf1af16589a79eef3"
  description: "Defines a `viewer` Role instance, representing a seed/default role with view-only (read-only) permissions in the application."
---
# backend.app.seed.viewer

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.viewer [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:50-54 :: viewer = Role(

Description: Defines a `viewer` Role instance, representing a seed/default role with view-only (read-only) permissions in the application.

## Related Documents

- [backend.app.seed.editor](6e2bd7b7-3ff8-58f4-9873-f0045a8b85d6.md) - Related (graph distance 1.36)
- [backend.app.seed.admin](4041d0d9-ff75-570f-9dd0-77920e758db4.md) - Related (graph distance 1.46)
- [backend.app.seed.root](18365c02-cf65-5a40-bfe4-a549d2319780.md) - Related (graph distance 2.98)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 3.05)
