---
id: b05ab40c-349f-53b6-9b28-f21bb9690029
type: gotcha
title: "Constants Gotchas"
created_at: 2026-07-30T17:30:15.855303+00:00
updated_at: 2026-07-30T17:30:15.855318+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js
metadata:
  module_name: "frontend.src.constants"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/constants.js`

# Gotchas & Pitfalls: `frontend.src.constants`

### Mutable exported objects (no `Object.freeze`)
**Trigger:** These are plain exported objects, not frozen. Any importer can mutate them at runtime, and because ES module bindings share a single object instance, the mutation is global.
**Affected Files:** `frontend/src/constants.js` and every file that imports these objects.
**Fix:** Wrap each export in `Object.freeze(...)` (and consider `as const` if migrating to TS) so accidental writes throw in strict mode.
**Category:** type-system
**Example:**
```javascript
import { USER_STATUS } from "./constants";
USER_STATUS.ACTIVE = "enabled"; // silently succeeds, corrupts every consumer
// vs. export const USER_STATUS = Object.freeze({ ACTIVE: "active", ... });
```

---

### Silent drift from backend `app/constants.py`
**Trigger:** The values are duplicated by convention across the HTTP boundary with no shared schema or codegen. A backend rename (e.g. `"deactivated"` → `"disabled"`) compiles fine on both sides but silently breaks matching at runtime.
**Affected Files:** `frontend/src/constants.js`, `app/constants.py`, plus any status/permission comparison logic.
**Fix:** Generate one file from the other (OpenAPI schema, shared JSON, or a codegen step) or add a contract test that asserts both lists are identical.
**Category:** domain
**Example:**
```javascript
// backend renames status; frontend still checks "deactivated"
if (user.status === USER_STATUS.DEACTIVATED) { /* never true anymore */ }
```

---

### Undefined lookup for unknown audit actions
**Trigger:** `AUDIT_ACTION_LABELS[action]` returns `undefined` when the backend introduces a new `AuditAction` value the frontend hasn't been updated for. Rendering `undefined` shows blank cells rather than an obvious error.
**Affected Files:** `frontend/src/constants.js`, audit view components.
**Fix:** Always provide a fallback: `AUDIT_ACTION_LABELS[action] ?? action` (or a formatted default). Never assume the map is exhaustive.
**Category:** type-system
**Example:**
```javascript
// backend adds "user.email_changed"
const label = AUDIT_ACTION_LABELS[event.action]; // undefined → blank UI
```

---

### No reverse lookup / value-set validation
**Trigger:** Code often needs "is this a valid status/permission?" but there is no `Set` or helper. Developers tend to write ad-hoc string comparisons that don't catch typos.
**Affected Files:** `frontend/src/constants.js` and validation call sites.
**Fix:** Export derived sets, e.g. `export const USER_STATUSES = new Set(Object.values(USER_STATUS));` for O(1) membership checks.
**Category:** domain
**Example:**
```javascript
// typo goes undetected — no validation surface exists
if (status === "deactivate") { ... } // wrong; should be "deactivated"
```

---

### Permission-string typos are unchecked at call sites
**Trigger:** Permission checks frequently receive raw strings from the server or from other code. Comparing against `PERMISSIONS.USERS_DEACTIVATE` ("users:deactivate") vs a hand-typed "user:deactivate" (singular) fails silently — a security-relevant mismatch.
**Affected Files:** `frontend/src/constants.js`, auth/guard components.
**Fix:** Always compare against the constant, never literals; add a runtime assertion that any permission string in checks exists in `PERMISSIONS`.
**Category:** domain
**Example:**
```javascript
hasPermission("users:deactivate"); // works if literal matches exactly
hasPermission(PERMISSIONS.USERS_DEACTIVATE); // safer, refactor-proof
```

---

### Key/value confusion between the three maps
**Trigger:** `USER_STATUS` and `PERMISSIONS` map descriptive keys to wire values, while `AUDIT_ACTION_LABELS` maps wire values to display labels. The inverted direction is easy to mix up — iterating `Object.keys(AUDIT_ACTION_LABELS)` gives backend action strings, not labels.
**Affected Files:** `frontend/src/constants.js` and any code iterating these objects.
**Fix:** Document/name the direction clearly (e.g. `AUDIT_ACTION_LABELS_BY_ACTION`), and use `Object.entries` explicitly when building dropdowns.
**Category:** type-system
**Example:**
```javascript
Object.keys(AUDIT_ACTION_LABELS); // ["user.created", ...] not ["Created", ...]
```

---

### Iterating maps as ordered/exhaustive UI sources
**Trigger:** Building a status filter or permission checklist via `Object.values(...)` couples UI ordering and completeness to object literal order. Reordering keys silently reorders the UI, and any non-constant key (none today, but easy to add) leaks in.
**Affected Files:** `frontend/src/constants.js`, filter/checklist components.
**Fix:** Define explicit ordered arrays for UI rendering separate from the lookup maps; don't rely on insertion order semantics for display.
**Category:** framework
**Example:**
```javascript
// reordering DEACTIVATED above ACTIVE silently changes dropdown order
{Object.values(USER_STATUS).map(renderOption)}
```