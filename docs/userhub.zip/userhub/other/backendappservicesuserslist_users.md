---
id: d6058efb-c2b7-5713-8903-c4a425c1404e
type: catalog
title: "backend.app.services.users.list_users"
created_at: 2026-07-30T15:09:17.211066+00:00
updated_at: 2026-07-30T17:48:08.849977+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.list_users"
  signature: "def list_users(db: Session, *, status: str | None = None) -> list[User]:"
  location: {'line_start': 28, 'line_end': 32, 'col_start': 0, 'col_end': 46}
  parent_qualified_name: None
  sha_at_sync: "7a5c4452bb74d75a59c1080bbc7668b25f6c35eb9a91f7443bf698e8ef05c1e9"
  description: "Retrieves all users from the database, optionally filtering by the specified status, and returns them as a list of User objects."
---
# backend.app.services.users.list_users

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.list_users [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:28-32 :: def list_users(db: Session, *, status: str | None = None) -> list[User]:

Description: Retrieves all users from the database, optionally filtering by the specified status, and returns them as a list of User objects.

## Related Documents

- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 1.46)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 1.54)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 1.62)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 1.64)
- [backend.app.services.users.query](d9f0755a-497e-52a9-be2e-4103bced037f.md) - Related (graph distance 1.65)
- [backend.app.services.roles.list_permissions](c0635854-e157-5ed0-836c-3317d08ec451.md) - Related (graph distance 1.66)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 2.81)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 2.88)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 2.91)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 2.93)
