---
id: d8daa9ee-b439-5bf1-a68b-ba541890eeb8
type: catalog
title: "backend.app.schemas.CurrentUser.permissions"
created_at: 2026-07-30T15:09:16.674749+00:00
updated_at: 2026-07-30T17:48:08.840713+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.CurrentUser.permissions"
  signature: "permissions: list[str] = []"
  location: {'line_start': 83, 'line_end': 83, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "backend.app.schemas.CurrentUser"
  sha_at_sync: "c0cdc943443ec4903f286eb234e34523ffb2f0b4b254b5ea6fa07b2c71d0b45c"
  description: "Holds the list of permission identifiers granted to the current authenticated user, defaulting to an empty list."
---
# backend.app.schemas.CurrentUser.permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.CurrentUser.permissions in backend.app.schemas.CurrentUser [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:83-83 :: permissions: list[str] = []

Description: Holds the list of permission identifiers granted to the current authenticated user, defaulting to an empty list.

## Related Documents

- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.34)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 1.55)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.59)
- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 2.74)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.76)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 2.78)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 2.82)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 2.85)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 2.87)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 2.94)
