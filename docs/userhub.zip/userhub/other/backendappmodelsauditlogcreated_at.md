---
id: f84a7924-6247-540c-bf88-6538484215df
type: catalog
title: "backend.app.models.AuditLog.created_at"
created_at: 2026-07-30T15:09:15.727510+00:00
updated_at: 2026-07-30T17:48:08.772625+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.created_at"
  signature: "created_at: Mapped[datetime.datetime] = mapped_column("
  location: {'line_start': 92, 'line_end': 94, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "0ab13e5774a9c8269d5cb3349b5ca7fd487f7d1c64c05749c3e268fc82bcec46"
  description: "Defines a mapped SQLAlchemy column storing the timestamp when the audit log entry was created."
---
# backend.app.models.AuditLog.created_at

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.created_at in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:92-94 :: created_at: Mapped[datetime.datetime] = mapped_column(

Description: Defines a mapped SQLAlchemy column storing the timestamp when the audit log entry was created.

## Related Documents

- [backend.app.schemas.AuditLogOut.created_at](31c07d5e-1e35-57f6-95c2-d550675c0883.md) - Related (graph distance 1.20)
- [backend.app.models.User.created_at](8ea6c38c-c021-5ac6-a555-1fd72c4a3136.md) - Related (graph distance 1.25)
- [backend.app.models.User.updated_at](d16fded0-b866-5b24-b3f4-c996ca1d98ea.md) - Related (graph distance 1.37)
- [backend.app.schemas.UserOut.created_at](535e53d2-ce6c-5494-889d-0018699cdf42.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserOut.updated_at](3acb81b3-77cb-588b-8b04-50eda470cb17.md) - Related (graph distance 2.58)
- [backend.app.schemas.UserActivityRow.last_action_at](78bb4157-648a-5246-a4db-595d3c370f6d.md) - Related (graph distance 2.79)
- [backend.app.models._utcnow](5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458.md) - Related (graph distance 2.90)
