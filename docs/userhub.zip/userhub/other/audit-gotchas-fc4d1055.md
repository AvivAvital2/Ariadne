---
id: fc4d1055-d9fa-56da-ad60-d3795b314b94
type: gotcha
title: "Audit Gotchas"
created_at: 2026-07-30T17:23:12.723432+00:00
updated_at: 2026-07-30T17:23:12.723446+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py
metadata:
  module_name: "backend.app.routers.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/audit.py`

# Gotchas and Pitfalls: `backend.app.routers.audit`

### Unbounded/negative `limit` allows resource exhaustion
**Trigger:** A client passes `limit=999999999` or `limit=-1`. There's no validation via `Query(...)` constraints, so any integer is accepted and passed straight to the service layer.
**Affected Files:** `app/routers/audit.py`, `app/services/audit.py`
**Fix:** Constrain with FastAPI's `Query`: `limit: int = Query(100, ge=1, le=1000)`. Also decide how the service handles negative values (SQLAlchemy `.limit(-1)` behavior varies by dialect).
**Category:** performance
**Example:**
```python
# Current: no bounds
def list_audit(limit: int = 100, ...): ...

# GET /api/audit?limit=100000000  -> tries to load 100M rows

# Fixed:
from fastapi import Query
def list_audit(limit: int = Query(100, ge=1, le=1000), ...): ...
```

---

### `require_permission(...)` is evaluated at import time, not per-request
**Trigger:** `Depends(require_permission(Permission.AUDIT_READ.value))` calls `require_permission()` once when the module loads to build the dependency. If `require_permission` has side effects or relies on runtime state (e.g., a not-yet-configured permission registry), it captures stale state.
**Affected Files:** `app/routers/audit.py`, `app/security.py`
**Fix:** Ensure `require_permission` is a pure factory returning a dependency callable. Verify no config/DB access happens at factory-call time—only inside the returned callable.
**Category:** framework
**Example:**
```python
# require_permission() runs at module import.
# The returned callable must do the actual per-request check:
def require_permission(perm):
    def checker(user=Depends(get_current_user)):  # runs per request
        if perm not in user.permissions: raise HTTPException(403)
        return user
    return checker
```

---

### `.value` vs enum member mismatch
**Trigger:** Passing `Permission.AUDIT_READ.value` (a raw string like `"audit:read"`) instead of the enum member. If `require_permission` internally compares against enum members elsewhere, string-vs-enum comparisons silently fail (`Permission.AUDIT_READ != "audit:read"`).
**Affected Files:** `app/routers/audit.py`, `app/security.py`, `app/constants.py`
**Fix:** Standardize on one representation. Either pass the enum member everywhere or the `.value` everywhere. Consider a `StrEnum` so `Permission.AUDIT_READ == "audit:read"` holds.
**Category:** type-system
**Example:**
```python
class Permission(str, Enum):  # StrEnum-like: value comparisons work
    AUDIT_READ = "audit:read"

# Now .value and the member compare equal, avoiding silent mismatches.
```

---

### `action` filter is untyped free text — injection/typo silent failure
**Trigger:** `action` is an arbitrary `str | None`. A typo (`"lgin"` vs `"login"`) returns an empty list with a 200, not an error. If the service builds SQL via string formatting, it's also an injection vector.
**Affected Files:** `app/routers/audit.py`, `app/services/audit.py`
**Fix:** Validate `action` against a known set (enum/`Literal`) so bad values 422 instead of silently returning nothing. Ensure the service uses parameterized queries.
**Category:** domain
**Example:**
```python
from typing import Literal
action: Literal["login", "logout", "delete"] | None = None
# Typos now rejected with 422 rather than returning [] silently.
```

---

### `response_model=list[AuditLogOut]` triggers full re-validation/serialization
**Trigger:** For large `limit` values, FastAPI validates and serializes every row through Pydantic (`AuditLogOut`) on the way out. This is O(n) CPU on the response path and can dominate latency for big result sets.
**Affected Files:** `app/routers/audit.py`, `app/schemas.py`
**Fix:** Keep `limit` capped (see first gotcha). If `from_attributes`/ORM mode isn't configured on `AuditLogOut`, serialization may also fail or lazy-load attributes triggering N+1 queries.
**Category:** performance
**Example:**
```python
class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)  # required for ORM objects
# Without this, returning ORM rows raises or lazy-loads per attribute (N+1).
```

---

### Lazy-loaded ORM attributes after session close (DetachedInstanceError)
**Trigger:** `get_db` typically yields a session and closes it after the request. If `AuditLogOut` accesses a relationship (e.g., `actor.name`) that wasn't eagerly loaded, Pydantic serialization may access it after commit/expire, raising `DetachedInstanceError` or firing N+1 queries.
**Affected Files:** `app/routers/audit.py`, `app/services/audit.py`, `app/database.py`
**Fix:** Eager-load needed relationships in the service (`joinedload`/`selectinload`) or expunge/return DTOs before the session closes.
**Category:** framework
**Example:**
```python
# service:
return db.query(AuditLog).options(selectinload(AuditLog.actor)).limit(limit).all()
# Avoids serialization-time lazy loads after session teardown.
```

---

### Missing ordering makes "recent" non-deterministic
**Trigger:** The docstring says "recent audit entries," but ordering is delegated to the service. If the service omits `ORDER BY created_at DESC`, the DB returns rows in arbitrary/heap order, so `limit=100` may not be the newest 100.
**Affected Files:** `app/services/audit.py`
**Fix:** Explicitly order by timestamp (and a tiebreaker like `id`) before applying `.limit`.
**Category:** domain
**Example:**
```python
db.query(AuditLog).order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(limit)
```

---

### `actor` dependency result is unused — dead-looking but security-critical
**Trigger:** A developer refactoring may remove the seemingly-unused `actor: User = Depends(...)` parameter, silently disabling the permission check. Linters may flag it as unused.
**Affected Files:** `app/routers/audit.py`
**Fix:** Keep the dependency; add a comment or use `# noqa`. Better: audit-read access is exactly the kind of endpoint that should log *its own* access using `actor`, giving the variable a purpose.
**Category:** framework
**Example:**
```python
actor: User = Depends(require_permission(Permission.AUDIT_READ.value))
# Removing this line silently opens the endpoint to everyone.
```