---
id: 7ba7415b-c796-5982-b3c8-d8e9733dbdb3
type: catalog
title: "backend.app.schemas.RoleAssignment.role_ids"
created_at: 2026-07-30T15:09:16.669731+00:00
updated_at: 2026-07-30T17:48:08.795560+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleAssignment.role_ids"
  signature: "role_ids: list[int]"
  location: {'line_start': 57, 'line_end': 57, 'col_start': 4, 'col_end': 23}
  parent_qualified_name: "backend.app.schemas.RoleAssignment"
  sha_at_sync: "7c03eb63161f24ae84d2b78484c76a33f2d0dca3272df8ff242ecc41974add71"
  description: "Holds a list of integer role identifiers to be assigned in a `RoleAssignment` schema."
---
# backend.app.schemas.RoleAssignment.role_ids

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleAssignment.role_ids in backend.app.schemas.RoleAssignment [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:57-57 :: role_ids: list[int]

Description: Holds a list of integer role identifiers to be assigned in a `RoleAssignment` schema.

## Related Documents

- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 1.20)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 1.30)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.62)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 1.62)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 1.63)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 2.74)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 2.75)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.79)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 2.85)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 2.86)
