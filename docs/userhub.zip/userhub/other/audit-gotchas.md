---
id: 03a6ac61-3515-579f-bd22-aed5ba4bd92d
type: gotcha
title: "Audit Gotchas"
created_at: 2026-07-30T17:25:27.435167+00:00
updated_at: 2026-07-30T17:25:27.435182+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py
metadata:
  module_name: "backend.app.services.audit"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Audit Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/audit.py`

# Gotchas & Pitfalls: `backend.app.services.audit`

### `record` flushes but never commits
**Trigger:** Calling `record` and assuming the audit entry is durably persisted. `db.flush()` sends the INSERT to the DB but the surrounding transaction can still roll back.
**Affected Files:** `audit.py` (`record`)
**Fix:** Rely on the caller's transaction boundary intentionally. If the mutating operation rolls back, the audit entry rolls back too — which may be desired, but be aware audit rows are lost on any later exception in the same transaction. If you need audit entries to survive failures, use a separate session/transaction.
**Category:** framework
**Example:**
```python
audit.record(db, actor_id=1, action="user.delete", target_id=42)
# ... later in the same request/transaction:
raise ValueError("boom")   # rollback wipes the audit row too
```

### `action` typed as `str` defeats the `AuditAction` contract
**Trigger:** Docstring says `action` is an `AuditAction` value, but the signature accepts any `str`. Typos (`"user.delte"`) pass silently and the frontend maps them to nothing / a blank label.
**Affected Files:** `audit.py` (`record`, `list_entries`)
**Fix:** Type the parameter as the `AuditAction` enum (or `Literal[...]`) so mypy/IDE catch invalid values.
**Category:** type-system
**Example:**
```python
record(db, actor_id=1, action="usr.create", target_id=2)  # typo, no error
# list_entries(db, action="user.create") never matches it
```

### `flush()` triggers autoflush side effects / integrity errors mid-operation
**Trigger:** `db.flush()` forces pending SQL early. If the enclosing operation has other dirty objects, they get flushed too, potentially raising an `IntegrityError` originating from unrelated code but surfacing inside `record`.
**Affected Files:** `audit.py` (`record`)
**Fix:** Be aware that exceptions from `record` may not be caused by the audit row itself. Consider `db.add(entry)` without a flush unless the returned `entry.id` is actually needed.
**Category:** framework
**Example:**
```python
db.add(other_object_with_bad_fk)
audit.record(...)  # flush here raises IntegrityError about other_object
```

### `created_at` ordering assumes DB-generated timestamps
**Trigger:** `order_by(AuditLog.created_at.desc())` — if `created_at` is populated by a Python-side default at flush time rather than the DB, rows created within the same request can share identical timestamps, making ordering non-deterministic (and `limit` may drop arbitrary rows).
**Affected Files:** `audit.py` (`list_entries`), `app/models.py` (`AuditLog`)
**Fix:** Add a stable tiebreaker: `order_by(AuditLog.created_at.desc(), AuditLog.id.desc())`.
**Category:** domain
**Example:**
```python
# two entries recorded in one flush → same created_at
# limit=1 returns an unpredictable one of them
```

### `null` action filtering vs. querying for empty string
**Trigger:** `if action is not None` correctly distinguishes "no filter" from a filter. But callers passing `action=""` (empty string, e.g. from an unvalidated query param) get filtered on empty string rather than "all entries".
**Affected Files:** `audit.py` (`list_entries`)
**Fix:** Normalize falsy/blank inputs: `if action:` if empty means "no filter", or validate the param upstream.
**Category:** type-system
**Example:**
```python
list_entries(db, action="")  # filters WHERE action = '' → returns nothing
```

### Unbounded `limit` and no minimum guard
**Trigger:** `limit` is caller-controlled with no upper bound. A request passing `limit=1_000_000` (or negative) is passed straight to SQL. Negative limits behave DB-specifically (SQLite treats negative as "no limit").
**Affected Files:** `audit.py` (`list_entries`)
**Fix:** Clamp: `limit = max(1, min(limit, MAX_LIMIT))`.
**Category:** performance
**Example:**
```python
list_entries(db, limit=-1)   # SQLite → returns ENTIRE table
```

### `Session` is not thread-safe / not for concurrent use
**Trigger:** Sharing a single `db: Session` across threads or async tasks. SQLAlchemy `Session` is explicitly not thread-safe; `record` and `list_entries` inherit that.
**Affected Files:** `audit.py` (both functions)
**Fix:** Use one session per request/task (scoped_session or DI). Never pass the same `Session` into a threadpool from multiple audit calls concurrently.
**Category:** thread-safety
**Example:**
```python
# concurrent workers sharing one session
await asyncio.gather(*(run_in_thread(audit.record, db, ...) for _ in tasks))
# → corrupted session state / DetachedInstanceError
```

### Sync `Session` used from async request handlers
**Trigger:** These functions use the blocking `sqlalchemy.orm.Session`. Calling them directly inside an `async def` FastAPI route blocks the event loop during I/O.
**Affected Files:** `audit.py` (both functions)
**Fix:** Call from sync route handlers, wrap in `run_in_threadpool`, or migrate to `AsyncSession`.
**Category:** async
**Example:**
```python
@app.get("/audit")
async def get_audit(db=Depends(get_db)):
    return audit.list_entries(db)   # blocks event loop on the query
```

### `target_type` default silently mislabels non-user targets
**Trigger:** `target_type` defaults to `"user"`. Recording a role operation without explicitly passing `target_type="role"` records it as a user target, corrupting the frontend's action→label/entity mapping.
**Affected Files:** `audit.py` (`record`)
**Fix:** Make `target_type` required (no default), or validate it against a known set.
**Category:** domain
**Example:**
```python
record(db, actor_id=1, action="role.grant", target_id=7)  # target_type="user" 
```

### Returned `AuditLog` may have unloaded/None attributes before commit
**Trigger:** `record` returns `entry` after `flush()`. Server-side defaults (like `created_at` or auto-increment `id`) are populated after flush in most cases, but if any column uses a DB default not returned by RETURNING, accessing it may trigger an extra query or be `None`.
**Affected Files:** `audit.py` (`record`), `app/models.py`
**Fix:** If you need populated server-defaults immediately, `db.refresh(entry)` after flush.
**Category:** framework
**Example:**
```python
entry = record(...)
entry.created_at   # may be None until refresh/commit depending on model config
```