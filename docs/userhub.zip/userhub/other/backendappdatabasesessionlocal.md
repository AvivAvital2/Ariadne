---
id: 8b8fafba-48bd-565d-a261-fd009a8cb0a6
type: catalog
title: "backend.app.database.SessionLocal"
created_at: 2026-07-30T15:09:15.752492+00:00
updated_at: 2026-07-30T17:48:08.773315+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.database.SessionLocal"
  signature: "SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)"
  location: {'line_start': 15, 'line_end': 15, 'col_start': 0, 'col_end': 75}
  parent_qualified_name: None
  sha_at_sync: "4e877ba344f8ff0e8e166fd3fc22acc5d14266877154db1280a9ebf8b7b54139"
  description: "A configured SQLAlchemy session factory bound to the database engine, with autoflush and autocommit disabled, used to create new database session instances."
---
# backend.app.database.SessionLocal

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

variable backend.app.database.SessionLocal [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py:15-15 :: SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

Description: A configured SQLAlchemy session factory bound to the database engine, with autoflush and autocommit disabled, used to create new database session instances.

## Related Documents

- [backend.app.database.db](79b07bea-702c-59cb-bbea-2a7349e809e6.md) - Related (graph distance 1.29)
- [backend.app.main.db](bb5aec0e-efa8-5d81-9107-bf2af1df3260.md) - Related (graph distance 1.35)
- [backend.app.database.get_db](b1de7430-33d3-5af5-aa00-16c515f88a86.md) - Related (graph distance 2.84)
