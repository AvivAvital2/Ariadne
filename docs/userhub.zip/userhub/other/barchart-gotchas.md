---
id: 55a6c232-d8b6-5158-857a-cb17437a827d
type: gotcha
title: "Barchart Gotchas"
created_at: 2026-07-30T17:29:52.945651+00:00
updated_at: 2026-07-30T17:29:52.945665+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx
metadata:
  module_name: "frontend.src.components.charts.BarChart"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Barchart Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/charts/BarChart.jsx`

# BarChart Gotchas and Pitfalls

### `max ?? Math.max()` only guards null/undefined, not zero
**Trigger:** Passing `max={0}` to force a zero baseline (or receiving `0` from a computation) is a valid number, so `??` keeps it. Then every `d.value / 0` becomes `Infinity` or `NaN`.
**Affected Files:** `BarChart.jsx`
**Fix:** Guard the divisor explicitly: `const top = Math.max(1, max ?? Math.max(1, ...values))` or validate `max > 0`.
**Category:** type-system
**Example:**
```javascript
<BarChart max={0} data={[{label:'a', value:5}]} />
// width: `${(5 / 0) * 100}%` -> "Infinity%" -> bar renders full/broken
```

### `Math.max(1, ...data.map(...))` throws on huge arrays
**Trigger:** Spreading a large `data` array into `Math.max` exceeds the JS engine's argument-count limit (~65k–500k depending on engine), throwing `RangeError: Maximum call stack size exceeded`.
**Affected Files:** `BarChart.jsx`
**Fix:** Use `data.reduce((m, d) => Math.max(m, d.value), 1)` which avoids spreading.
**Category:** performance
**Example:**
```javascript
const data = Array.from({length: 200000}, (_,i) => ({label:`${i}`, value:i}));
// Math.max(1, ...data.map(d=>d.value)) -> RangeError
```

### Empty `data` array produces `Math.max(1)` = 1 silently
**Trigger:** With `data = []`, `Math.max(1)` returns `1` (no spread elements), so no crash but you render an empty chart with no indication. If `max` is also undefined and someone later divides, edge behavior is masked.
**Affected Files:** `BarChart.jsx`
**Fix:** Add an explicit empty-state render (`if (!data?.length) return <EmptyState/>`).
**Category:** type-system
**Example:**
```javascript
<BarChart data={[]} />  // renders <div className="hbars"></div>, blank
```

### Non-numeric or `NaN` values silently break layout
**Trigger:** `d.value` being a string, `null`, or `NaN` propagates into `Math.max` and the width template string. `NaN / top` yields `"NaN%"`, which CSS ignores, leaving zero-width bars with no error.
**Affected Files:** `BarChart.jsx`
**Fix:** Coerce/validate: `const v = Number(d.value) || 0;` and guard NaN before rendering.
**Category:** type-system
**Example:**
```javascript
<BarChart data={[{label:'x', value:'12'}]} />
// Math.max(1, '12') -> 12 (coerced), but width `${'12'/12*100}%` -> "100%" OK by luck
<BarChart data={[{label:'x', value:undefined}]} />
// width "NaN%" -> silently invisible bar
```

### Duplicate or missing `label` breaks React keys
**Trigger:** `key={d.label}` assumes labels are unique and defined. Duplicate labels cause React reconciliation bugs (wrong DOM reuse, lost focus/animation); `undefined` labels collapse all rows to `key={undefined}`.
**Affected Files:** `BarChart.jsx`
**Fix:** Use a stable unique id (`key={d.id}`) or fall back to index only if order is stable.
**Category:** framework
**Example:**
```javascript
<BarChart data={[{label:'A',value:1},{label:'A',value:2}]} />
// Two rows share key="A" -> React warning + state mismatch on updates
```

### Values exceeding `max` overflow the track
**Trigger:** When an explicit `max` is passed but a `d.value` is larger, `(value/max)*100` exceeds 100%, so `.hbar-fill` overflows its track (visual bug) unless CSS clamps with `overflow:hidden`.
**Affected Files:** `BarChart.jsx`, associated CSS
**Fix:** Clamp the width: `Math.min(100, (d.value / top) * 100)`.
**Category:** domain
**Example:**
```javascript
<BarChart max={10} data={[{label:'a', value:50}]} />
// width: "500%" -> fill spills out of track
```

### Negative values produce negative widths
**Trigger:** A negative `d.value` yields a negative percentage; CSS treats negative `width` as `0`, so negative magnitudes silently render as empty — misleading for diverging data.
**Affected Files:** `BarChart.jsx`
**Fix:** Decide semantics: `Math.abs`, clamp to 0, or support a diverging axis. Document that only non-negative magnitudes are supported.
**Category:** domain
**Example:**
```javascript
<BarChart data={[{label:'loss', value:-30}]} />
// width "-30%" -> browser renders 0, data appears missing
```

### Unsanitized `d.color` injected into inline style
**Trigger:** `background: d.color` trusts caller input. While React's inline style object prevents CSS-injection breaking out into JS, a malformed/undefined color silently falls back to transparent, making bars invisible with no warning.
**Affected Files:** `BarChart.jsx`
**Fix:** Provide a default (`background: d.color ?? 'var(--bar-default)'`) and validate color strings.
**Category:** framework
**Example:**
```javascript
<BarChart data={[{label:'a', value:5, color: undefined}]} />
// background:undefined -> transparent bar, "why is nothing showing?"
```

### Value label duplicated but not localized/formatted
**Trigger:** `{d.value}` and the `title` render raw numbers. Large numbers (`1234567.89`) show unformatted; the comment mentions "direct value labels" satisfying a contrast/relief rule, so removing them for design reasons silently violates an accessibility contract.
**Affected Files:** `BarChart.jsx`
**Fix:** Add a `format` prop (`Intl.NumberFormat`) and document that the value label is an a11y requirement, not decorative.
**Category:** domain
**Example:**
```javascript
<BarChart data={[{label:'rev', value:1234567.891}]} />
// renders "1234567.891" — no grouping, ugly, and label is a11y-load-bearing
```