---
id: 7caa85ab-7d0d-5a76-9e44-bdbceab2069d
type: catalog
title: "backend.alembic.versions.0001_initial.downgrade"
created_at: 2026-07-30T15:09:16.336545+00:00
updated_at: 2026-07-30T17:48:08.782410+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.alembic.versions.0001_initial.downgrade"
  signature: "def downgrade() -> None:"
  location: {'line_start': 79, 'line_end': 88, 'col_start': 0, 'col_end': 28}
  parent_qualified_name: None
  sha_at_sync: "6ac7a63af3a0637c833fb9ec5918dc70e73bbcae6c5cf6156369d9eba366f4a0"
  description: "Reverts the initial database migration by dropping the tables and schema objects created in the corresponding `upgrade` function."
---
# backend.alembic.versions.0001_initial.downgrade

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

function backend.alembic.versions.0001_initial.downgrade [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py:79-88 :: def downgrade() -> None:

Description: Reverts the initial database migration by dropping the tables and schema objects created in the corresponding `upgrade` function.

## Related Documents

- [backend.alembic.versions.0001_initial.upgrade](fcf102e4-3068-5d60-bf34-46f2bb03e75a.md) - Related (graph distance 1.35)
