---
id: 69c55859-fca2-50e0-b4a3-2de7afa1e5ba
type: gotcha
title: "Statcard Gotchas"
created_at: 2026-07-30T17:28:27.480816+00:00
updated_at: 2026-07-30T17:28:27.480828+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx
metadata:
  module_name: "frontend.src.components.StatCard"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Statcard Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/StatCard.jsx`

# Gotchas & Pitfalls: `StatCard`

### Falsy `value` renders nothing meaningful (0, empty string)
**Trigger:** Passing a legitimate `value` of `0`, `""`, or `false`. Unlike `hint` and `Icon`, `value` is rendered directly without a guard, so `0` will actually display — but if a caller expects `value={0 || fallback}` upstream, the `0` silently becomes the fallback. The subtler bug is inconsistency: `hint` uses `&&` guarding, but `value` doesn't, so an empty-string `value` renders an empty `.stat-value` div (a visual gap) with no fallback.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Explicitly handle nullish vs falsy. Use `value ?? "—"` to show a placeholder for null/undefined while preserving `0`.
**Category:** type-system
**Example:**
```jsx
// value={0} -> renders "0" (fine)
// value="" -> renders empty div (bad, silent gap)
// value={null} -> renders empty div (bad)
<div className="stat-value">{value ?? "—"}</div>
```

---

### `hint`/`Icon` short-circuit can leak falsy values into DOM
**Trigger:** `hint && <div>...` and `Icon && <Icon>`. If `hint` is `0` or `NaN` (e.g., a numeric hint), React renders the number `0`, not nothing. If `Icon` is `0` it also renders `0`.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Coerce to boolean or use ternary with `null`.
**Category:** framework
**Example:**
```jsx
{hint ? <div className="stat-hint">{hint}</div> : null}
// or
{Boolean(hint) && <div className="stat-hint">{hint}</div>}
```

---

### Unvalidated `tone` produces broken/missing CSS class
**Trigger:** `className={`tone-${tone}`}`. Any string passed as `tone` is interpolated directly. A typo (`tone="primry"`) or `undefined` (if someone passes `tone={null}` explicitly, defeating the default) yields `tone-undefined` / `tone-null` with no styling and no error.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Whitelist tones and fall back to default. Default parameter only applies to `undefined`, not `null`.
**Category:** type-system
**Example:**
```jsx
const TONES = ["primary", "success", "warning", "danger"];
const safeTone = TONES.includes(tone) ? tone : "primary";
// tone={null} bypasses the default "primary" -> "tone-null"
```

---

### Default parameter does NOT fire for `null`
**Trigger:** `tone = "primary"` only defaults when `tone` is `undefined`. A parent spreading props like `<StatCard {...data} />` where `data.tone === null` produces `tone-null`.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Normalize inside the body: `const t = tone ?? "primary";`
**Category:** type-system
**Example:**
```jsx
<StatCard tone={null} />   // -> "tone-null", NOT "tone-primary"
<StatCard />                // -> "tone-primary" (works)
```

---

### `icon: Icon` destructure requires a component, not an element
**Trigger:** `icon: Icon` then `<Icon size={20} />`. Callers must pass a component reference (`icon={Home}`), not a rendered element (`icon={<Home />}`). Passing an element throws "Element type is invalid" or ignores `size`.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Document that `icon` is a component type. Optionally support both by checking `React.isValidElement`.
**Category:** framework
**Example:**
```jsx
<StatCard icon={Home} />      // correct
<StatCard icon={<Home />} />  // wrong: size={20} silently ignored / error
```

---

### No `key`-safe / accessibility semantics
**Trigger:** Numeric values with no ARIA labeling; screen readers read value and label as disconnected divs. Also, a stat card is presentational only — no `role` or `aria-label`.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Add semantic grouping (`role="group"` + `aria-label={label}`) so assistive tech associates value with label.
**Category:** framework
**Example:**
```jsx
<div className="stat-card" role="group" aria-label={label}>
```

---

### Missing `PropTypes`/TypeScript = silent runtime failures
**Trigger:** No prop validation. A wrong `Icon` type or object `value` (`value={{x:1}}`) throws "Objects are not valid as a React child" only at render, with a stack trace far from the call site.
**Affected Files:** `frontend/src/components/StatCard.jsx`
**Fix:** Add PropTypes or migrate to TypeScript with an explicit `IconType` for `icon`.
**Category:** type-system
**Example:**
```jsx
<StatCard value={{count: 5}} />  // runtime crash, no compile warning
```

---

### `Icon` re-render churn if passed inline
**Trigger:** If a parent defines the icon component inline (`icon={() => <svg/>}`) on each render, React sees a new component type every render, unmounting/remounting the icon subtree.
**Affected Files:** callers of `StatCard`
**Fix:** Pass stable component references defined at module scope, not inline closures.
**Category:** performance
**Example:**
```jsx
// bad: new function identity each render -> remount
<StatCard icon={() => <MyIcon />} />
```