---
id: 9ed8286b-7e90-5043-bf34-7c16096cb903
type: catalog
title: "backend.app.models.AuditLog"
created_at: 2026-07-30T15:09:15.718836+00:00
updated_at: 2026-07-30T17:48:08.764957+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.models.AuditLog"
  signature: "class AuditLog(Base):"
  location: {'line_start': 82, 'line_end': 94, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "0aa45da1aabab5a9e7f7890a7cd89c02304eb60db4480f2e7342d7d836df8d32"
  description: "Defines a SQLAlchemy ORM model mapping to the audit log database table, recording tracked events and their associated metadata. It inherits from the declarative `Base` class to enable persistence of audit trail records."
---
# backend.app.models.AuditLog

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

class backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:82-94 :: class AuditLog(Base):

Description: Defines a SQLAlchemy ORM model mapping to the audit log database table, recording tracked events and their associated metadata. It inherits from the declarative `Base` class to enable persistence of audit trail records.

## Related Documents

- [backend.app.database.Base](4ef45cb4-630a-5586-a798-b2d40bf8da04.md) - Related (graph distance 1.55)
- [backend.app.schemas.AuditLogOut](6e6767f4-fae6-512e-a9bf-fdd8f6b39d44.md) - Related (graph distance 1.56)
- [backend.app.models.User](12309fd4-111e-542c-89a8-af5e3300ae89.md) - Related (graph distance 1.57)
- [backend.app.models.Permission](0e7843d6-44d3-5ac2-9d8c-ee08801cc3ed.md) - Related (graph distance 1.62)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 2.97)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.98)
