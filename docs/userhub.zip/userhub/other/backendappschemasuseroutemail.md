---
id: 04bde0ab-600e-504d-bc65-46149b42bea9
type: catalog
title: "backend.app.schemas.UserOut.email"
created_at: 2026-07-30T15:09:16.670762+00:00
updated_at: 2026-07-30T17:48:08.796593+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserOut.email"
  signature: "email: str"
  location: {'line_start': 64, 'line_end': 64, 'col_start': 4, 'col_end': 14}
  parent_qualified_name: "backend.app.schemas.UserOut"
  sha_at_sync: "073f2da50ead230d35475cc1f60c1154056d0d6cc56b8fa074cc638e6085c349"
  description: "Stores the user's email address as a string in the UserOut schema, exposing it as part of the API response for user data."
---
# backend.app.schemas.UserOut.email

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserOut.email in backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:64-64 :: email: str

Description: Stores the user's email address as a string in the UserOut schema, exposing it as part of the API response for user data.

## Related Documents

- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 1.18)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.31)
- [backend.app.models.User.email](16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 1.33)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.35)
- [backend.app.services.users.email](c9d9526a-dd04-57c7-b212-845716fc2b78.md) - Related (graph distance 1.55)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.51)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 2.54)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.54)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 2.60)
