---
id: 98bd86de-59e2-590f-8bf7-00b3bb963d8d
type: catalog
title: "backend.app.schemas.UserActivityRow.username"
created_at: 2026-07-30T15:09:16.677208+00:00
updated_at: 2026-07-30T17:48:08.843256+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserActivityRow.username"
  signature: "username: str"
  location: {'line_start': 101, 'line_end': 101, 'col_start': 4, 'col_end': 17}
  parent_qualified_name: "backend.app.schemas.UserActivityRow"
  sha_at_sync: "a3b20fa634e0641ba74db0d45453059c90e29c0cc808ed99ee785150a3a81b29"
  description: "Stores the username string identifying the user associated with an activity record in the `UserActivityRow` schema."
---
# backend.app.schemas.UserActivityRow.username

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserActivityRow.username in backend.app.schemas.UserActivityRow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:101-101 :: username: str

Description: Stores the username string identifying the user associated with an activity record in the `UserActivityRow` schema.

## Related Documents

- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 1.24)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.29)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.40)
- [backend.app.schemas.UserActivityRow.status](d4d26d18-4a50-59b3-b9ab-f5cec77e367f.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 1.57)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 2.56)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.60)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.62)
