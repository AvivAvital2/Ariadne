---
id: f900d87c-098e-5d9a-8267-09fb1eca95e0
type: catalog
title: "backend.app.security.require_permission"
created_at: 2026-07-30T15:09:15.795816+00:00
updated_at: 2026-07-30T17:19:17.794521+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.security.require_permission"
  signature: "def require_permission(permission: str):"
  location: {'line_start': 29, 'line_end': 46, 'col_start': 0, 'col_end': 18}
  parent_qualified_name: None
  sha_at_sync: "51c1bb9171d480d881547f677123c04441bd2fa62d0d12c509a846d65df9c148"
  description: "Creates a FastAPI dependency that verifies the current authenticated user has the specified permission, raising an authorization error if the permission is not granted."
---
# backend.app.security.require_permission

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/security.py`

function backend.app.security.require_permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/security.py:29-46 :: def require_permission(permission: str):

Description: Creates a FastAPI dependency that verifies the current authenticated user has the specified permission, raising an authorization error if the permission is not granted.