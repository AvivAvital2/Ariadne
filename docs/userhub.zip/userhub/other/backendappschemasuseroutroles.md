---
id: 771a5956-cd7a-5878-8970-0ceedd4b8172
type: catalog
title: "backend.app.schemas.UserOut.roles"
created_at: 2026-07-30T15:09:16.672926+00:00
updated_at: 2026-07-30T17:48:08.797132+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserOut.roles"
  signature: "roles: list[RoleBrief] = []"
  location: {'line_start': 67, 'line_end': 67, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "backend.app.schemas.UserOut"
  sha_at_sync: "05ab7ea51fe13c48461fedb1f3c59383cf9f59ae01bc7a406fbcffc662ff73f9"
  description: "Holds the list of roles assigned to a user in the `UserOut` schema, represented as `RoleBrief` objects and defaulting to an empty list."
---
# backend.app.schemas.UserOut.roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserOut.roles in backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:67-67 :: roles: list[RoleBrief] = []

Description: Holds the list of roles assigned to a user in the `UserOut` schema, represented as `RoleBrief` objects and defaulting to an empty list.

## Related Documents

- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 1.40)
- [backend.app.schemas.RoleOut.permissions](44b42e42-60cf-5ef6-be89-86e6313e68c9.md) - Related (graph distance 1.42)
- [backend.app.models.Permission.roles](d0dd4ccf-ac79-5c30-b62c-acf02af231df.md) - Related (graph distance 1.50)
- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 1.54)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 1.61)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 2.73)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 2.74)
- [backend.app.models.Role.users](b9039759-eb64-5b55-b552-7022ea8b09f5.md) - Related (graph distance 2.76)
- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 2.76)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 2.79)
