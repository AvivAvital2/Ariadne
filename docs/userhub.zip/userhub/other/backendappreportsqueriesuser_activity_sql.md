---
id: 2b8ff6bd-7e2e-516d-b78c-1d495af079c3
type: catalog
title: "backend.app.reports.queries.USER_ACTIVITY_SQL"
created_at: 2026-07-30T15:09:17.037333+00:00
updated_at: 2026-07-30T17:48:08.849187+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.reports.queries.USER_ACTIVITY_SQL"
  signature: "USER_ACTIVITY_SQL = """"
  location: {'line_start': 7, 'line_end': 18, 'col_start': 0, 'col_end': 3}
  parent_qualified_name: None
  sha_at_sync: "130677a7acc8bb1e4efae1500b9fc29087c08c7683e8e2adfd18e290bf44baba"
  description: "A SQL query string constant that retrieves user activity data for reporting purposes."
---
# backend.app.reports.queries.USER_ACTIVITY_SQL

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py`

variable backend.app.reports.queries.USER_ACTIVITY_SQL [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/reports/queries.py:7-18 :: USER_ACTIVITY_SQL = """

Description: A SQL query string constant that retrieves user activity data for reporting purposes.

## Related Documents

- [backend.app.routers.reports.rows](4b359aa5-d274-546c-91c8-7dedc3ea04e0.md) - Related (graph distance 1.51)
- [backend.app.routers.reports.user_activity](492fc0bf-e17c-5850-9da1-69030030a77d.md) - Related (graph distance 3.06)
