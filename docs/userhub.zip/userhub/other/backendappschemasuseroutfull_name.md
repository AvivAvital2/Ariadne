---
id: b1aed5f8-8902-5a9c-afdb-6648c8647216
type: catalog
title: "backend.app.schemas.UserOut.full_name"
created_at: 2026-07-30T15:09:16.672357+00:00
updated_at: 2026-07-30T17:48:08.796359+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserOut.full_name"
  signature: "full_name: str"
  location: {'line_start': 65, 'line_end': 65, 'col_start': 4, 'col_end': 18}
  parent_qualified_name: "backend.app.schemas.UserOut"
  sha_at_sync: "0f175f507eee486bc0cabd075997e6e9e8a59bbb5eb337bed00e0911bff553bc"
  description: "Stores the user's full name as a string field in the UserOut response schema, exposed when returning user data through the API."
---
# backend.app.schemas.UserOut.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserOut.full_name in backend.app.schemas.UserOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:65-65 :: full_name: str

Description: Stores the user's full name as a string field in the UserOut response schema, exposed when returning user data through the API.

## Related Documents

- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.18)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.27)
- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 1.31)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 1.33)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 1.35)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 1.42)
- [backend.app.services.users.full_name](068b4d0c-4d8a-544e-93e4-8e6677d000bf.md) - Related (graph distance 1.48)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.50)
- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 2.53)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.54)
