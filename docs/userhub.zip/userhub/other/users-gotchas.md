---
id: b44abf17-0783-546d-a207-f3b0209860e2
type: gotcha
title: "Users Gotchas"
created_at: 2026-07-30T17:24:07.097875+00:00
updated_at: 2026-07-30T17:24:07.097889+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  module_name: "backend.app.routers.users"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Users Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

# Gotchas and Pitfalls: `backend.app.routers.users`

### Sync endpoints block the event loop under load
**Trigger:** All endpoints are defined with `def` (not `async def`). FastAPI runs sync route handlers in a threadpool, but the SQLAlchemy `Session` from `get_db` is not thread-safe and each request gets its own thread from a bounded pool (default 40 workers).
**Affected Files:** `app/routers/users.py`, `app/database.py`
**Fix:** Keep sync handlers consistent with sync DB usage (which this does), but be aware that heavy load exhausts the threadpool. Do not share a `Session` across threads. If migrating to `async def`, you must also switch to an async session/engine — mixing is a common mistake.
**Category:** async
**Example:**
```python
# This is fine as-is, but adding `async def` while keeping sync Session breaks:
async def list_users(db: Session = Depends(get_db)):
    return user_service.list_users(db)  # blocks event loop — sync I/O in async ctx
```

---

### `status` query param shadows the built-in and accepts arbitrary strings
**Trigger:** `list_users(status: str | None = None)` takes a raw string with no validation. Any value ("active", "banana", "Active") passes straight to the service. Casing/typos silently return empty lists instead of errors.
**Affected Files:** `app/routers/users.py`, `app/services/users.py`
**Fix:** Use an `Enum` type for the query param so FastAPI validates it and returns 422 on bad input.
**Category:** type-system
**Example:**
```python
# GET /api/users?status=Actve  -> 200 [] (silent, looks like "no users")
# Fix:
from enum import Enum
class UserStatus(str, Enum): active = "active"; inactive = "inactive"
def list_users(status: UserStatus | None = None): ...
```

---

### `unused actor` params can be dropped accidentally, silently removing authz
**Trigger:** `actor` is only used for `actor_id` in mutating endpoints; in `list_users`/`get_user` it's never referenced. A linter or well-meaning cleanup could remove `actor: User = Depends(require_permission(...))`, which deletes the entire authorization check without any visible behavior change in tests that don't assert 403.
**Affected Files:** `app/routers/users.py`
**Fix:** Never remove the dependency even if `actor` is unused; mark with `# noqa`/underscore or use `dependencies=[Depends(require_permission(...))]` in the decorator for read-only routes so intent is explicit.
**Category:** framework
**Example:**
```python
# Reads authorize via a side-effecting dependency; the var being unused is a trap.
@router.get("/api/users", dependencies=[Depends(require_permission(Permission.USERS_READ.value))])
def list_users(db: Session = Depends(get_db)): ...
```

---

### Service-layer exceptions may leak as 500 instead of 404/409
**Trigger:** `update_user`, `set_user_status`, `assign_roles`, `delete_user`, `create_user` call service functions without checking for `None` or catching domain errors. Only `get_user` handles the missing-user case. Updating a nonexistent user, or creating a duplicate username, likely raises an `IntegrityError`/`AttributeError` surfacing as a raw 500.
**Affected Files:** `app/routers/users.py`, `app/services/users.py`
**Fix:** Ensure the service raises typed exceptions mapped to HTTP status via exception handlers, or check return values in each route as done in `get_user`.
**Category:** domain
**Example:**
```python
# PUT /api/users/99999 -> service returns None -> response_model=UserOut
# fails serializing None -> 500, not 404
user = user_service.update_user(...)
if user is None:
    raise HTTPException(404, "user not found")
```

---

### `response_model=UserOut` can silently leak or drop fields
**Trigger:** Endpoints return the ORM `User` object and rely on `UserOut` for serialization. If `UserOut` has `from_attributes`/`orm_mode` and lazy-loaded relationships (like roles), accessing them during serialization can trigger `DetachedInstanceError` after the session closes, or emit N+1 lazy queries.
**Affected Files:** `app/routers/users.py`, `app/schemas.py`, `app/models.py`
**Fix:** Eager-load relationships in the service (`joinedload`/`selectinload`) before returning, and ensure serialization happens before the session is torn down by `get_db`.
**Category:** framework
**Example:**
```python
# UserOut includes roles -> lazy load after db closes -> DetachedInstanceError
return db.query(User).options(selectinload(User.roles)).get(user_id)
```

---

### `create_user` on self / `delete_user` on self not guarded here
**Trigger:** `actor_id` is passed to the service, but the router does not prevent an actor from deactivating or deleting themselves, or reassigning their own roles to lock themselves out. This is a common business-rule omission left implicitly to the service.
**Affected Files:** `app/routers/users.py`, `app/services/users.py`
**Fix:** Confirm the service enforces self-protection rules; if not, add explicit checks. Don't assume the router's permission check covers this.
**Category:** domain
**Example:**
```python
# actor with USERS_DELETE deletes their own id -> orphaned/locked-out system
if user_id == actor.id:
    raise HTTPException(400, "cannot delete yourself")
```

---

### PUT semantics with optional fields silently null-out data
**Trigger:** `update_user` passes `payload.email` and `payload.full_name` directly. If `UserUpdate` fields are `Optional` and omitted in the request, they arrive as `None` and the service may overwrite existing values with `None` (PUT-as-replace confusion vs PATCH-as-merge).
**Affected Files:** `app/routers/users.py`, `app/services/users.py`, `app/schemas.py`
**Fix:** Distinguish "field omitted" from "explicitly null" using `payload.model_dump(exclude_unset=True)` and pass only set fields to the service.
**Category:** type-system
**Example:**
```python
# PUT {"full_name": "New"} with email omitted -> email set to None, data lost
data = payload.model_dump(exclude_unset=True)
user_service.update_user(db, user_id=user_id, **data)
```

---

### `.value` on Permission enum couples routes to string identity
**Trigger:** `require_permission(Permission.USERS_READ.value)` passes the raw string. If `require_permission` compares against enum members elsewhere, or the enum value is renamed, permissions silently mismatch (no type error) and every request 403s or, worse, authorizes incorrectly.
**Affected Files:** `app/routers/users.py`, `app/security.py`, `app/constants.py`
**Fix:** Pass the enum member itself and normalize inside `require_permission`, keeping a single source of truth for the string form.
**Category:** type-system
**Example:**
```python
# Rename enum value "users:read" -> "user:read" and grant tables still store old
# string -> universal 403 with no exception raised
require_permission(Permission.USERS_READ)  # let the dep resolve .value
```

---

### `delete_user` returns 204 but body may still be serialized
**Trigger:** Handler returns `None` with `status_code=204`. FastAPI 204 responses must have no body; if a global response wrapper/middleware adds content, clients or proxies may reject it.
**Affected Files:** `app/routers/users.py`
**Fix:** Ensure no `response_model` is set (correct here) and that middleware doesn't inject a body for 204 responses.
**Category:** framework
**Example:**
```python
# Adding response_model to a 204 route causes FastAPI/Starlette warnings + issues
@router.delete("/api/users/{user_id}", status_code=204)  # no response_model — correct
```