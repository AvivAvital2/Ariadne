---
id: e5fa7c92-313d-5a4f-8e1f-1dbc36f123b0
type: catalog
title: "backend.alembic.env.target_metadata"
created_at: 2026-07-30T15:09:16.526980+00:00
updated_at: 2026-07-30T17:18:44.980514+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.alembic.env.target_metadata"
  signature: "target_metadata = Base.metadata"
  location: {'line_start': 19, 'line_end': 19, 'col_start': 0, 'col_end': 31}
  parent_qualified_name: None
  sha_at_sync: "ffb4e7ce698056fa477999ab8b4e8bb3ae4ef3e36ee913d2575d0ab300a0b323"
  description: "Holds the SQLAlchemy metadata object from the declarative `Base`, providing Alembic with the target schema definitions used for autogenerating database migrations."
---
# backend.alembic.env.target_metadata

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

variable backend.alembic.env.target_metadata [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py:19-19 :: target_metadata = Base.metadata

Description: Holds the SQLAlchemy metadata object from the declarative `Base`, providing Alembic with the target schema definitions used for autogenerating database migrations.