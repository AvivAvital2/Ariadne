---
id: c892d5da-98e7-5903-bbec-fe540e16a8c8
type: catalog
title: "backend.app.models.User.full_name"
created_at: 2026-07-30T15:09:15.721026+00:00
updated_at: 2026-07-30T17:48:08.766267+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.full_name"
  signature: "full_name: Mapped[str] = mapped_column(String(255), default="")"
  location: {'line_start': 41, 'line_end': 41, 'col_start': 4, 'col_end': 67}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "5e2aa153efc4904e5440727e155788647ee65f593597533f5d3e2b92344a85c4"
  description: "A mapped SQLAlchemy column storing the user's full name as a string up to 255 characters, defaulting to an empty string."
---
# backend.app.models.User.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.full_name in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:41-41 :: full_name: Mapped[str] = mapped_column(String(255), default="")

Description: A mapped SQLAlchemy column storing the user's full name as a string up to 255 characters, defaulting to an empty string.

## Related Documents

- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.42)
- [backend.app.models.User.username](e6944542-0f4c-5b3c-854a-1b1143cba0f7.md) - Related (graph distance 1.43)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.46)
- [backend.app.models.User.email](16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8.md) - Related (graph distance 1.47)
- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 2.62)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.73)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.75)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.77)
- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 2.78)
