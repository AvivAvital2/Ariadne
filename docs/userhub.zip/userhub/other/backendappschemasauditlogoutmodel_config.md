---
id: 620f2e87-3d30-52f3-85c7-e7a7f98d0761
type: catalog
title: "backend.app.schemas.AuditLogOut.model_config"
created_at: 2026-07-30T15:09:16.674982+00:00
updated_at: 2026-07-30T17:48:08.841006+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.model_config"
  signature: "model_config = ConfigDict(from_attributes=True)"
  location: {'line_start': 87, 'line_end': 87, 'col_start': 4, 'col_end': 51}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "c68e00d245d4dbecf8ed44fb515545f6398d17fd04905803a46c6de1a0126eed"
  description: "Configures the `AuditLogOut` Pydantic model to populate its fields from object attributes (e.g., ORM instances) rather than requiring dictionary input, enabling ORM-to-schema serialization."
---
# backend.app.schemas.AuditLogOut.model_config

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.model_config in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:87-87 :: model_config = ConfigDict(from_attributes=True)

Description: Configures the `AuditLogOut` Pydantic model to populate its fields from object attributes (e.g., ORM instances) rather than requiring dictionary input, enabling ORM-to-schema serialization.

## Related Documents

- [backend.app.schemas.UserOut.model_config](2680e71b-89f1-5e50-bbdc-adce1ba75529.md) - Related (graph distance 1.12)
- [backend.app.schemas.RoleOut.model_config](855b8538-1f7f-53a3-af63-94b320e0e796.md) - Related (graph distance 1.13)
- [backend.app.schemas.PermissionOut.model_config](5f1f3c69-edd8-5b8d-b607-9c7b9d47feba.md) - Related (graph distance 1.14)
- [backend.app.schemas.RoleBrief.model_config](dc56a798-5157-5d98-8faf-c69a69f6bec0.md) - Related (graph distance 1.20)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.73)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 2.75)
