---
id: 86b6bbb8-5d01-5248-b215-0af6c335ce3d
type: catalog
title: "frontend.package.type"
created_at: 2026-07-30T15:09:15.305452+00:00
updated_at: 2026-07-30T17:48:08.759074+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.type"
  signature: ""type": "module""
  location: {'line_start': 5, 'line_end': 5, 'col_start': 2, 'col_end': 18}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "33d8d568e6d716984743aa9103edff35444bb9108a41ea5f9e28769f1085b1ce"
  description: "Specifies that the frontend package uses ECMAScript modules (ESM) rather than CommonJS, causing `.js` files to be interpreted as ES modules."
---
# frontend.package.type

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.type in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:5-5 :: "type": "module"

Description: Specifies that the frontend package uses ECMAScript modules (ESM) rather than CommonJS, causing `.js` files to be interpreted as ES modules.

## Related Documents

- [frontend.package.name](5cd9c91d-65aa-5c8e-8758-e05d8da0fb24.md) - Related (graph distance 1.50)
- [frontend.package.version](81db2b01-295a-5d17-8690-921565d0f57f.md) - Related (graph distance 1.52)
- [frontend.package.private](9984896f-c935-5cf4-a883-1ae0a7064a00.md) - Related (graph distance 1.57)
- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.59)
- [frontend.package.devDependencies](1ec843a6-aeda-53cd-9bdf-c1a78cd11d31.md) - Related (graph distance 2.82)
