---
id: 1815870f-caec-5c7b-b117-8d0481c84ff2
type: gotcha
title: "Main Gotchas"
created_at: 2026-07-30T17:30:31.322016+00:00
updated_at: 2026-07-30T17:30:31.322031+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx
metadata:
  module_name: "frontend.src.main"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Main Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/main.jsx`

# Gotchas & Pitfalls: `frontend.src.main`

### Silent null crash on missing root element
**Trigger:** `document.getElementById("root")` returns `null` if the DOM element with `id="root"` is absent from `index.html`, or if the script executes before the element is parsed. `createRoot(null)` throws a cryptic runtime error.
**Affected Files:** `frontend/src/main.jsx`, `index.html`
**Fix:** Guard the lookup and fail loudly with a clear message, or ensure the script tag uses `type="module"` (deferred) and is placed after the root div.
**Category:** type-system
**Example:**
```javascript
const container = document.getElementById("root");
if (!container) {
  throw new Error('Root element "#root" not found in index.html');
}
createRoot(container).render(<App />);
```

### StrictMode double-invokes effects and renders in development
**Trigger:** `React.StrictMode` intentionally mounts, unmounts, and remounts components (and double-runs effects/reducers/state initializers) in **development only**. Code with side effects in `useEffect` without cleanup, or non-idempotent initializers, will behave unexpectedly or appear to "run twice."
**Affected Files:** `frontend/src/main.jsx`, `App.jsx` and all descendant components
**Fix:** Make all effects idempotent and provide cleanup functions. Do not "fix" a double-render bug by removing StrictMode — fix the underlying side effect. Remember this behavior disappears in production builds, masking bugs during dev.
**Category:** framework
**Example:**
```javascript
// This fetch fires twice in dev under StrictMode:
useEffect(() => {
  fetch("/api/data").then(setData); // no cleanup -> race + double call
}, []);
// Fix: use AbortController cleanup
useEffect(() => {
  const ctrl = new AbortController();
  fetch("/api/data", { signal: ctrl.signal }).then(setData);
  return () => ctrl.abort();
}, []);
```

### createRoot called more than once on the same container
**Trigger:** Hot-module reload setups, or importing/executing `main.jsx` twice, can call `createRoot` on an already-rooted container. React warns: "You are calling ReactDOMClient.createRoot() on a container that has already been passed to createRoot() before."
**Affected Files:** `frontend/src/main.jsx`
**Fix:** Ensure this module is the single entry point and executes once. If HMR is involved, cache the root instance rather than recreating it.
**Category:** framework
**Example:**
```javascript
// Cache root across HMR reloads
const container = document.getElementById("root");
let root = window.__appRoot;
if (!root) {
  root = createRoot(container);
  window.__appRoot = root;
}
root.render(<App />);
```

### Missing error boundary — entire app blanks on any render error
**Trigger:** Any uncaught error thrown during render in `App` or its children unmounts the whole tree, leaving a blank white page. There is no fallback UI at the root.
**Affected Files:** `frontend/src/main.jsx`, `App.jsx`
**Fix:** Wrap `<App />` in a top-level `ErrorBoundary` component that renders a fallback and logs the error.
**Category:** framework
**Example:**
```javascript
createRoot(container).render(
  <React.StrictMode>
    <ErrorBoundary fallback={<GlobalErrorScreen />}>
      <App />
    </ErrorBoundary>
  </React.StrictMode>,
);
```

### CSS import order / side-effect import is not tree-shakeable
**Trigger:** `import "./styles.css"` is a side-effect import processed by the bundler. Import *order* affects cascade/specificity resolution when multiple CSS files are combined, and moving this import can silently change styling. It also cannot be removed by tree-shaking even if "unused."
**Affected Files:** `frontend/src/main.jsx`, `styles.css`
**Fix:** Keep global CSS imports at the top-level entry and document the ordering contract. Prefer CSS Modules/scoped styles for component-specific styling to avoid cascade coupling.
**Category:** framework
**Example:**
```javascript
// Order matters: later imports win on equal specificity
import "./reset.css";
import "./styles.css"; // must come after reset to override
```

### JSX extension coupling in the App import
**Trigger:** `import App from "./App.jsx"` hard-codes the `.jsx` extension. If the file is later renamed to `.tsx` (TypeScript migration) this import silently breaks the build. Some resolver configs also disallow explicit extensions.
**Affected Files:** `frontend/src/main.jsx`, `App.jsx`
**Fix:** Align extension usage with the project's resolver config; be consistent so migrations only touch one convention.
**Category:** framework
**Example:**
```javascript
// After TS migration this fails to resolve:
import App from "./App.jsx"; // App is now App.tsx
```

### No async boundary around initial render
**Trigger:** `render()` is synchronous, but with React 18 concurrent features, updates are batched and may be deferred. Assuming the DOM is fully painted immediately after `render()` (e.g., measuring layout, focusing elements) is unreliable.
**Affected Files:** `frontend/src/main.jsx`
**Fix:** Do post-mount DOM work inside effects (`useLayoutEffect` for synchronous measurement), never immediately after `createRoot().render()`.
**Category:** async
**Example:**
```javascript
createRoot(container).render(<App />);
container.querySelector(".widget").focus(); // may not exist yet — not painted
```