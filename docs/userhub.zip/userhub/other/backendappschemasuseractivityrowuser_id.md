---
id: 893555ae-b345-587c-af10-83ee9a374c74
type: catalog
title: "backend.app.schemas.UserActivityRow.user_id"
created_at: 2026-07-30T15:09:16.676978+00:00
updated_at: 2026-07-30T17:48:08.842728+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserActivityRow.user_id"
  signature: "user_id: int"
  location: {'line_start': 100, 'line_end': 100, 'col_start': 4, 'col_end': 16}
  parent_qualified_name: "backend.app.schemas.UserActivityRow"
  sha_at_sync: "ea85cbaf6f334461f346976fc305fc636250e6d52691581206eab870f49c7eb0"
  description: "Stores the unique integer identifier of the user associated with an activity record in the `UserActivityRow` schema."
---
# backend.app.schemas.UserActivityRow.user_id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserActivityRow.user_id in backend.app.schemas.UserActivityRow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:100-100 :: user_id: int

Description: Stores the unique integer identifier of the user associated with an activity record in the `UserActivityRow` schema.

## Related Documents

- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 1.31)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 1.36)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 1.40)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.41)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 1.47)
- [backend.app.schemas.UserActivityRow.action_count](89232c2e-e6ae-581f-aa4a-1f1bbc3e7bc4.md) - Related (graph distance 1.54)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 1.54)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.55)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 1.57)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.52)
