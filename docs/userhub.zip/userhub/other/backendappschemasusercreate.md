---
id: 595581c1-91ba-5d60-b01a-17433590d234
type: catalog
title: "backend.app.schemas.UserCreate"
created_at: 2026-07-30T15:09:16.661321+00:00
updated_at: 2026-07-30T17:48:08.785983+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.schemas.UserCreate"
  signature: "class UserCreate(BaseModel):"
  location: {'line_start': 35, 'line_end': 39, 'col_start': 0, 'col_end': 28}
  parent_qualified_name: None
  sha_at_sync: "18b45cd3032f372c3f16c9dd94910dfd415be3d5b0434b64886fcdecc7a14e54"
  description: "Pydantic model defining the request schema for creating a new user, validating the required fields for user registration input."
---
# backend.app.schemas.UserCreate

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

class backend.app.schemas.UserCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:35-39 :: class UserCreate(BaseModel):

Description: Pydantic model defining the request schema for creating a new user, validating the required fields for user registration input.

## Related Documents

- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 1.26)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.28)
- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserOut](8b3c89e5-20aa-5902-94ff-eb90214f8440.md) - Related (graph distance 1.46)
- [backend.app.schemas.CurrentUser](c9f0033d-65ba-5095-b1f7-46936148c59a.md) - Related (graph distance 1.54)
- [backend.app.models.User](12309fd4-111e-542c-89a8-af5e3300ae89.md) - Related (graph distance 1.60)
- [backend.app.schemas.RoleAssignment](30cb9e85-ca29-5996-a8f6-2ecb4fcdeffc.md) - Related (graph distance 2.62)
- [backend.app.schemas.RoleBrief](0fbc27ec-0bb2-53a5-b19c-788816566132.md) - Related (graph distance 2.64)
- [backend.app.schemas.RoleOut](c549e45c-7079-5453-85cd-ed7c8913bcc3.md) - Related (graph distance 2.64)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 2.79)
