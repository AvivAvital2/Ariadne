---
id: 89232c2e-e6ae-581f-aa4a-1f1bbc3e7bc4
type: catalog
title: "backend.app.schemas.UserActivityRow.action_count"
created_at: 2026-07-30T15:09:16.677704+00:00
updated_at: 2026-07-30T17:48:08.843814+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserActivityRow.action_count"
  signature: "action_count: int"
  location: {'line_start': 103, 'line_end': 103, 'col_start': 4, 'col_end': 21}
  parent_qualified_name: "backend.app.schemas.UserActivityRow"
  sha_at_sync: "a93eb5c87b67244fff2f9587f890b656222462bb6c7a25ff269b7f8349d3ddda"
  description: "Stores the total number of actions performed by a user, represented as an integer field in the `UserActivityRow` schema."
---
# backend.app.schemas.UserActivityRow.action_count

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserActivityRow.action_count in backend.app.schemas.UserActivityRow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:103-103 :: action_count: int

Description: Stores the total number of actions performed by a user, represented as an integer field in the `UserActivityRow` schema.

## Related Documents

- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.54)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 2.85)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.90)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 2.94)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 2.95)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 3.01)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 3.08)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 3.09)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 3.11)
