---
id: cb902cba-530a-505b-8327-9f0bcbfacc09
type: gotcha
title: "Routers Gotchas"
created_at: 2026-07-30T17:23:12.676197+00:00
updated_at: 2026-07-30T17:23:12.676210+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py
metadata:
  module_name: "backend.app.routers"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Routers Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/__init__.py`

# Gotchas & Pitfalls: `backend.app.routers`

## Analysis of Provided Source

The module contains only a docstring:

```python
"""HTTP routers, one module per resource."""
```

There is **no executable code** in the provided source. Consequently, no concrete gotchas (thread safety, type system, async boundaries, framework quirks, or performance traps) can be identified from the code itself.

However, I can flag structural/packaging concerns that the docstring's stated intent ("one module per resource") implies, since these are common pitfalls for router packages.

---

### Empty package `__init__.py` with no router aggregation
**Trigger:** The package docstring promises "one module per resource," but this `__init__.py` neither imports nor re-exports any routers. Developers often expect `from backend.app.routers import <resource_router>` to work, or expect a central `api_router` to be assembled here.
**Affected Files:** `backend/app/routers/__init__.py`
**Fix:** Explicitly aggregate routers to make the include order and public surface deterministic:
```python
# __init__.py
from fastapi import APIRouter
from . import users, orders  # noqa

api_router = APIRouter()
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(orders.router, prefix="/orders", tags=["orders"])
```
**Category:** framework
**Example:** Without aggregation, `app.include_router(...)` calls get scattered across `main.py`, and route registration order (which affects path matching precedence) becomes hard to reason about.

---

### Import-order / circular-import risk from wildcard aggregation
**Trigger:** When you *do* populate this `__init__.py` to import every resource module, importing the package triggers importing all routers eagerly. If any router module imports something back from the package (e.g. shared dependencies re-exported here), you get a circular import at startup.
**Affected Files:** `backend/app/routers/__init__.py` and every per-resource module it imports
**Fix:** Keep `__init__.py` thin—import modules, not their internals—and put shared deps in a separate `dependencies.py` rather than re-exporting through the package root.
**Category:** framework
**Example:**
```python
# routers/__init__.py re-exports get_db
from .deps import get_db
# routers/users.py
from backend.app.routers import get_db  # circular if __init__ imports users
```

---

### Route path collisions across "one module per resource"
**Trigger:** Independent per-resource modules can silently register overlapping paths (e.g. `/items/{id}` vs `/items/search`). FastAPI matches by registration order, so the file `include_router` sequence—determined here—decides which handler wins. This is invisible in individual modules.
**Affected Files:** `backend/app/routers/__init__.py` (aggregation point)
**Fix:** Give each router a distinct `prefix` and register literal paths before parameterized ones. Add a startup test that asserts no duplicate `(method, path)` pairs across `app.routes`.
**Category:** framework
**Example:**
```python
# /items/search shadowed by /items/{item_id} if the latter is included first
```

---

## Recommendation

To perform a meaningful gotcha analysis (thread safety, async/sync boundaries, polars/DuckDB usage, type-system silent nulls), **please provide the actual per-resource router modules** (e.g. `users.py`, `orders.py`). The current file is a placeholder docstring with no logic to evaluate.

Specific things I'd look for once real code is available:
- **async** — sync DB/DuckDB calls inside `async def` handlers blocking the event loop.
- **thread-safety** — shared DuckDB connections or module-level mutable state across concurrent requests.
- **type-system** — Pydantic response models silently coercing/dropping `None`, or `Optional` fields hiding missing data.
- **framework** — `Depends()` cached per-request vs per-app, background task exception swallowing.
- **performance** — building polars DataFrames per request without lazy evaluation or pushing filters into DuckDB.