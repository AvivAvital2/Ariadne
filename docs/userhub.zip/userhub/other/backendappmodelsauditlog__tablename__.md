---
id: f7701d3c-d768-59a6-a353-5dc7d0dc27df
type: catalog
title: "backend.app.models.AuditLog.__tablename__"
created_at: 2026-07-30T15:09:15.725526+00:00
updated_at: 2026-07-30T17:48:08.770334+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.__tablename__"
  signature: "__tablename__ = "audit_log""
  location: {'line_start': 83, 'line_end': 83, 'col_start': 4, 'col_end': 31}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "f31d180078e5378bdc2777c2c6188dae6987f742d64f9406d03c5de21ff1e4e2"
  description: "Specifies the database table name "audit_log" for the AuditLog SQLAlchemy model."
---
# backend.app.models.AuditLog.__tablename__

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.__tablename__ in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:83-83 :: __tablename__ = "audit_log"

Description: Specifies the database table name "audit_log" for the AuditLog SQLAlchemy model.

## Related Documents

- [backend.app.models.User.__tablename__](d2a6a7b3-ecb1-5671-9d6e-1dddc1d79573.md) - Related (graph distance 1.22)
- [backend.app.models.Role.__tablename__](37624afd-6108-5b4e-8e41-56008d592ced.md) - Related (graph distance 1.25)
- [backend.app.models.Permission.__tablename__](4c6f0324-6589-5069-938c-4b0eec16aea3.md) - Related (graph distance 1.26)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 2.85)
