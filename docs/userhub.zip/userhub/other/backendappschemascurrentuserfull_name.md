---
id: 0fd06547-0731-54f4-a98a-62ba04f082dd
type: catalog
title: "backend.app.schemas.CurrentUser.full_name"
created_at: 2026-07-30T15:09:16.674223+00:00
updated_at: 2026-07-30T17:48:08.840114+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.CurrentUser.full_name"
  signature: "full_name: str"
  location: {'line_start': 81, 'line_end': 81, 'col_start': 4, 'col_end': 18}
  parent_qualified_name: "backend.app.schemas.CurrentUser"
  sha_at_sync: "0f175f507eee486bc0cabd075997e6e9e8a59bbb5eb337bed00e0911bff553bc"
  description: "Stores the authenticated user's full name as a string within the CurrentUser schema."
---
# backend.app.schemas.CurrentUser.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.CurrentUser.full_name in backend.app.schemas.CurrentUser [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:81-81 :: full_name: str

Description: Stores the authenticated user's full name as a string within the CurrentUser schema.

## Related Documents

- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.18)
- [backend.app.schemas.UserCreate.full_name](e4c9ba1a-656b-5f27-917c-5fdbd42b1c11.md) - Related (graph distance 1.30)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 1.32)
- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 1.35)
- [backend.app.services.users.full_name](068b4d0c-4d8a-544e-93e4-8e6677d000bf.md) - Related (graph distance 1.40)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 1.41)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.52)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 2.54)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 2.56)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.59)
