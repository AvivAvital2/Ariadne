---
id: 1ec843a6-aeda-53cd-9bdf-c1a78cd11d31
type: catalog
title: "frontend.package.devDependencies"
created_at: 2026-07-30T15:09:15.306463+00:00
updated_at: 2026-07-30T17:48:08.759827+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/package.json
metadata:
  kind: "element"
  source_name: "userhub"
  language: "json"
  subtype: "json_key"
  qualified_name: "frontend.package.devDependencies"
  signature: ""devDependencies": {"
  location: {'line_start': 15, 'line_end': 18, 'col_start': 2, 'col_end': 3}
  parent_qualified_name: "frontend.package"
  sha_at_sync: "07c7c2ba87d10ab3e25890f89e4eec451201b86935a49807a600998d6fe85f16"
  description: "Specifies the frontend package's development-only dependencies, which are required for building and testing but excluded from production installs."
---
# frontend.package.devDependencies

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/package.json`

json_key frontend.package.devDependencies in frontend.package [json] /Users/spark/git/Ariadne.orig/userhub/frontend/package.json:15-18 :: "devDependencies": {

Description: Specifies the frontend package's development-only dependencies, which are required for building and testing but excluded from production installs.

## Related Documents

- [frontend.package.dependencies](5e65ee08-a4d0-5ff1-bad2-d1ae0ed88169.md) - Related (graph distance 1.23)
- [frontend.package.scripts](d97dd893-81dd-5cf9-8da9-574a2350ea83.md) - Related (graph distance 1.54)
- [frontend.package.private](9984896f-c935-5cf4-a883-1ae0a7064a00.md) - Related (graph distance 1.60)
