---
id: 59f3de3e-ff5f-57d8-9915-d4b267e18128
type: gotcha
title: "Styles Gotchas"
created_at: 2026-07-30T17:31:16.955982+00:00
updated_at: 2026-07-30T17:31:16.955996+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css
metadata:
  module_name: "frontend.src.styles"
  language: "css"
  provenance: "code-derived"
  source_name: "userhub"
---
# Styles Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/styles.css`

# CSS Gotchas & Pitfalls: `frontend.src.styles`

### Global element selectors leak into every component
**Trigger:** Bare selectors `input`, `label`, `table`, `th`, `td`, `fieldset`, `legend` style **every** matching element in the entire app, not just those in this design system. Any third-party widget, embedded form, or child component inherits these styles silently.
**Affected Files:** `frontend/src/styles` (this file), plus any component rendering `<input>`, `<table>`, `<label>`
**Fix:** Scope global element selectors under a root class (e.g. `.app input`) or use CSS Modules / scoped styles. At minimum, prefer class-based selectors.
**Category:** framework
**Example:**
```css
/* This hits a date-picker library's internal inputs too */
input { background: #fff; border: 1px solid var(--line); padding: 9px 11px; }
/* A radio input becomes 34px tall and mis-styled unexpectedly */
```

---

### `label { display: flex; flex-direction: column }` breaks inline labels
**Trigger:** The global `label` rule forces column layout. Any `<label>` not explicitly given `.checkbox` will stack its text and control vertically, which surprises developers expecting inline `<label><input></label>`.
**Affected Files:** `frontend/src/styles`
**Fix:** Only apply flex-column to a specific class (`.form-grid label`) rather than every `label`.
**Category:** framework
**Example:**
```html
<!-- Developer expects "Remember me [x]" inline; gets vertical stack -->
<label>Remember me <input type="checkbox"></label>
```

---

### `input[type="checkbox"]` override depends on source order
**Trigger:** `input { width: ... }` (implicitly) and `input[type="checkbox"] { width: auto }` rely on CSS specificity/order. The attribute selector `input[type="checkbox"]` (0,1,1) outweighs `input` (0,0,1), so it works — but any later rule targeting plain `input` with equal-or-higher specificity silently re-breaks checkbox width.
**Affected Files:** `frontend/src/styles`
**Fix:** Don't style the bare `input` element universally; scope width to text-like inputs (`input:not([type="checkbox"]):not([type="radio"])`).
**Category:** framework
**Example:**
```css
input { /* no explicit width, but padding 9px 11px still bloats checkboxes */ }
input[type="checkbox"] { width: auto; } /* only fixes width, not padding */
```

---

### Two sticky elements both pinned to `top: 0` overlap
**Trigger:** `.sidebar` uses `position: sticky; top: 0; height: 100vh` and `.topbar` also uses `position: sticky; top: 0; z-index: 5`. Because sidebar has no z-index (auto) and topbar has `z-index: 5`, stacking depends on DOM order and containing block. If they share a scroll container, one can overlap the other unexpectedly.
**Affected Files:** `frontend/src/styles`
**Fix:** Establish an explicit z-index scale; ensure sticky elements live in the intended scroll containers. Verify the sidebar is a flex sibling (not inside `.main`).
**Category:** framework
**Example:**
```css
.sidebar { position: sticky; top: 0; /* z-index: auto */ }
.topbar  { position: sticky; top: 0; z-index: 5; } /* may cover sidebar edge */
```

---

### `height: 100vh` sidebar clips on mobile browsers
**Trigger:** `.sidebar { height: 100vh }` — on mobile browsers `100vh` includes the area under the dynamic URL bar, so content (especially `.sidebar-footer`) is cut off or requires scroll.
**Affected Files:** `frontend/src/styles`
**Fix:** Use `min-height: 100dvh` (dynamic viewport) or `100svh`, and let content overflow scroll if needed.
**Category:** performance
**Example:**
```css
.sidebar { height: 100vh; } /* footer hidden under Safari's toolbar */
```

---

### Sidebar has no responsive collapse
**Trigger:** `@media (max-width: 980px)` only adjusts `.stat-row` and `.panel-grid`. The `flex: 0 0 240px` sidebar stays fixed-width on small screens, squeezing `.content` and causing horizontal overflow / cramped layout on phones.
**Affected Files:** `frontend/src/styles`
**Fix:** Add a mobile breakpoint that collapses or toggles the sidebar (drawer pattern).
**Category:** framework
**Example:**
```css
/* 240px sidebar on a 360px phone leaves 120px for content */
.sidebar { flex: 0 0 240px; }
```

---

### Hardcoded status hex colors diverge from CSS variables
**Trigger:** Badge/button text colors use literal hexes (`#0a7d0a`, `#a06c05`, `#b02f2f`, `#b5790a`) instead of the `--good`/`--warning`/`--critical` variables. Theming or a color change to the tokens silently leaves these text colors stale/mismatched.
**Affected Files:** `frontend/src/styles`
**Fix:** Derive darker text shades as separate tokens (e.g. `--good-ink`) and reference them, rather than sprinkling raw hexes.
**Category:** domain
**Example:**
```css
.badge.active { color: #0a7d0a; } /* --good is #0ca30c; changing --good won't update this */
```

---

### `.hbar-fill { min-width: 2px }` can exceed 100% track
**Trigger:** A bar whose computed width is `0%` still shows `min-width: 2px`. If many rows have tiny values, the 2px floor plus `border-radius` can visually misrepresent proportions; and a fill width of exactly `100%` combined with `min-width` inside an `overflow: hidden` track is fine, but width set via inline style near 100% plus min-width may clip.
**Affected Files:** `frontend/src/styles`
**Fix:** Document that fill width is set inline (JS); ensure JS clamps to `[0,100]%`. Consider min-width only when value > 0.
**Category:** domain
**Example:**
```css
.hbar-fill { min-width: 2px; } /* a "0" value still renders a visible sliver */
```

---

### `text-transform: capitalize` on badges mangles multi-word/acronym statuses
**Trigger:** `.badge { text-transform: capitalize }` capitalizes the first letter of **every word**. A status like `"deactivated by admin"` becomes `"Deactivated By Admin"`; an acronym `"api"` becomes `"Api"`.
**Affected Files:** `frontend/src/styles`
**Fix:** Capitalize in the data layer, or only capitalize when the source string is known single-word/lowercase.
**Category:** domain
**Example:**
```css
.badge { text-transform: capitalize; } /* "sso" -> "Sso", not "SSO" */
```

---

### `.chart-tooltip { transform: translateX(-50%) }` overflows chart edges
**Trigger:** Tooltip is centered on its `left` position via `translateX(-50%)` with `white-space: nowrap`. Near the left/right chart boundary the tooltip extends past the container and is clipped or causes horizontal scroll, since nothing constrains it.
**Affected Files:** `frontend/src/styles`
**Fix:** Clamp the tooltip position in JS, or add edge-aware `transform`/`max-width` logic.
**Category:** framework
**Example:**
```css
.chart-tooltip { transform: translateX(-50%); white-space: nowrap; }
/* Tooltip at x=0 renders half off-screen to the left */
```

---

### Fixed-width modal `width: 380px` ignores narrow viewports
**Trigger:** `.modal form { width: 380px }` with no max-width relative to viewport. On a 320px phone the modal overflows horizontally (only `max-height: 90vh` is responsive, not width).
**Affected Files:** `frontend/src/styles`
**Fix:** Use `width: min(380px, calc(100vw - 32px))`.
**Category:** framework
**Example:**
```css
.modal form { width: 380px; max-height: 90vh; } /* horizontal overflow on mobile */
```

---

### `.stat-row` hardcodes 4 columns; wrong count = broken grid
**Trigger:** `.stat-row { grid-template-columns: repeat(4, 1fr) }`. If the app renders 3 or 5 stat cards, the grid still forces 4 tracks — leaving a blank cell or wrapping the 5th to a lopsided second row.
**Affected Files:** `frontend/src/styles`
**Fix:** Use `repeat(auto-fit, minmax(200px, 1fr))` to adapt to card count.
**Category:** domain
**Example:**
```css
.stat-row { grid-template-columns: repeat(4, 1fr); }
/* 3 cards -> awkward empty fourth column */
```

---

### `border-collapse: collapse` + `tr:hover` background is invisible under sticky headers
**Trigger:** `tbody tr:hover { background: var(--page) }` uses the same color as `body`'s `--page`. On table rows over a white `.card`, hover is visible; but if a table sits directly on the page background, hover produces **no visible change**.
**Affected Files:** `frontend/src/styles`
**Fix:** Use a distinct hover token (e.g. a subtle tint) rather than reusing `--page`.
**Category:** domain
**Example:**
```css
tbody tr:hover { background: var(--page); } /* == body background: no feedback */
```

---

### `font-family: inherit` on inputs relies on ancestor cascade
**Trigger:** `.search input`, `input`, `.btn`, `.nav-item` all use `font-family: inherit`. If any of these are portaled (e.g. modal or dropdown rendered at `document.body` via React portal), they inherit the `body` font — usually fine — but if rendered outside the styled tree they may lose expected font/context.
**Affected Files:** `frontend/src/styles`
**Fix:** For portaled UI, set explicit font tokens rather than relying on `inherit`.
**Category:** framework
**Example:**
```css
.btn { font-family: inherit; } /* portal-rendered button inherits from body only */
```

---

### `rgba()` color values duplicate CSS-variable colors as literals
**Trigger:** Tint backgrounds like `rgba(42, 120, 214, 0.12)` manually re-encode `--primary` (#2a78d6). Changing `--primary` leaves all these tints out of sync silently.
**Affected Files:** `frontend/src/styles`
**Fix:** Use `color-mix(in srgb, var(--primary) 12%, transparent)` or store RGB channel triplets in variables.
**Category:** domain
**Example:**
```css
.stat-icon.tone-primary { background: rgba(42, 120, 214, 0.12); } /* magic numbers */
```

---

### `.feed-time { margin-left: auto }` collapses if a sibling also grows
**Trigger:** `.feed li` is `display: flex` with a `.dot` and text nodes. `.feed-time` pushes right via `margin-left: auto`. If `.feed-target` (no flex-grow) contains very long unbroken text, it won't shrink (no `min-width: 0`), forcing overflow and pushing the time off-row.
**Affected Files:** `frontend/src/styles`
**Fix:** Add `min-width: 0; overflow: hidden; text-overflow: ellipsis` to the growing text element.
**Category:** framework
**Example:**
```css
.feed li { display: flex; } /* long feed-target overflows, time gets pushed */
```

---

### No dark-mode / `prefers-color-scheme` handling despite "dark sidebar" tokens
**Trigger:** The `:root` defines a light theme with a dark sidebar, but there's no `@media (prefers-color-scheme: dark)`. Users with OS dark mode + browser auto-inversion (or forced-colors mode) may get a broken hybrid appearance.
**Affected Files:** `frontend/src/styles`
**Fix:** Explicitly declare `color-scheme: light` (or add real dark tokens) to opt out of surprise UA inversions.
**Category:** framework
**Example:**
```css
:root { /* no color-scheme declaration */ }
/* Native form controls may render dark on a light card */
```