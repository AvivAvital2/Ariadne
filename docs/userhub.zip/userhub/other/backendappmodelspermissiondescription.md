---
id: 9fe1ddb1-931e-52dc-bec1-aa8b5cdbe620
type: catalog
title: "backend.app.models.Permission.description"
created_at: 2026-07-30T15:09:15.724983+00:00
updated_at: 2026-07-30T17:48:08.770806+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Permission.description"
  signature: "description: Mapped[str] = mapped_column(String(255), default="")"
  location: {'line_start': 75, 'line_end': 75, 'col_start': 4, 'col_end': 69}
  parent_qualified_name: "backend.app.models.Permission"
  sha_at_sync: "46b8d9c4b929cc9a935b72950643944bcd89ef6db5dce1537dd182346b1552c7"
  description: "Defines an optional textual description of the permission, stored as a string column up to 255 characters that defaults to an empty string."
---
# backend.app.models.Permission.description

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Permission.description in backend.app.models.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:75-75 :: description: Mapped[str] = mapped_column(String(255), default="")

Description: Defines an optional textual description of the permission, stored as a string column up to 255 characters that defaults to an empty string.

## Related Documents

- [backend.app.models.Role.description](05e42cb4-46a0-51af-998b-59dfc35bf5ff.md) - Related (graph distance 1.13)
- [backend.app.schemas.PermissionOut.description](7e1baaaf-7dae-50ef-aef6-81cdb4043b19.md) - Related (graph distance 1.34)
- [backend.app.models.Permission.name](138bf8d6-bae5-5c03-82d7-251391d53d05.md) - Related (graph distance 1.43)
- [backend.app.models.AuditLog.detail](3be4829c-8290-58c1-823e-c6fbdaff14ff.md) - Related (graph distance 1.52)
- [backend.app.schemas.RoleOut.description](de00f3e4-a439-5e5f-a034-98d286d08613.md) - Related (graph distance 2.45)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 2.47)
- [backend.app.models.Role.name](ef90130c-d39b-5e06-9ecf-a4f40503ee2e.md) - Related (graph distance 2.49)
