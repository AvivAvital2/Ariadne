---
id: 9ba29e4a-068b-551e-a77b-051f1c6cb555
type: catalog
title: "backend.app.database.DATABASE_URL"
created_at: 2026-07-30T15:09:15.751896+00:00
updated_at: 2026-07-30T17:48:08.773533+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.database.DATABASE_URL"
  signature: "DATABASE_URL = "sqlite:///./userhub.db""
  location: {'line_start': 8, 'line_end': 8, 'col_start': 0, 'col_end': 39}
  parent_qualified_name: None
  sha_at_sync: "f27c0b93fb8cc48517387b8ed1c7ca058ebed522b4a73098db60333c67c1639b"
  description: "Defines the SQLAlchemy database connection string, configured to use a local SQLite database file named `userhub.db` in the current working directory."
---
# backend.app.database.DATABASE_URL

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

variable backend.app.database.DATABASE_URL [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py:8-8 :: DATABASE_URL = "sqlite:///./userhub.db"

Description: Defines the SQLAlchemy database connection string, configured to use a local SQLite database file named `userhub.db` in the current working directory.

## Related Documents

- [backend.alembic.env.url](d6bb5654-5a74-5e11-9bff-dc35e616fcd9.md) - Related (graph distance 1.59)
