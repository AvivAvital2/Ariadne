---
id: 2244228a-37fc-542b-9ef2-1b12f899fe7b
type: catalog
title: "backend.app.seed.perms"
created_at: 2026-07-30T15:09:16.251089+00:00
updated_at: 2026-07-30T17:18:57.817658+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.perms"
  signature: "perms = {"
  location: {'line_start': 28, 'line_end': 31, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "1e309fe2b09e9c2779a94745375f59025e36303650f13b5d924301dc5c8780cd"
  description: "A module-level dictionary that maps permission names or identifiers to their corresponding configuration values, used for seeding permission data into the application's database."
---
# backend.app.seed.perms

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.perms [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:28-31 :: perms = {

Description: A module-level dictionary that maps permission names or identifiers to their corresponding configuration values, used for seeding permission data into the application's database.