---
id: c5c40493-e924-5179-838b-07141ddd7ebc
type: catalog
title: "backend.app.services.users.update_user"
created_at: 2026-07-30T15:09:17.212382+00:00
updated_at: 2026-07-30T17:48:08.850556+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.users.update_user"
  signature: "def update_user("
  location: {'line_start': 80, 'line_end': 101, 'col_start': 0, 'col_end': 15}
  parent_qualified_name: None
  sha_at_sync: "1f8ead86faa83fe2003ae95c10d040f432b86adaca1b2e316e357708aba83e2b"
  description: "Updates an existing user's fields in the database with the provided data and persists the changes, returning the updated user record."
---
# backend.app.services.users.update_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py`

function backend.app.services.users.update_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/users.py:80-101 :: def update_user(

Description: Updates an existing user's fields in the database with the provided data and persists the changes, returning the updated user record.

## Related Documents

- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 1.18)
- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 1.44)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 1.52)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 1.53)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 1.60)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 1.61)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 1.64)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 2.60)
- [backend.app.schemas.UserStatusUpdate](48093c25-ffa4-5f39-a638-63bdbf8594f4.md) - Related (graph distance 2.76)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 2.82)
