---
id: 9c15dd32-36b8-5da7-8143-43f5af6c10ff
type: gotcha
title: "Constants Gotchas"
created_at: 2026-07-30T17:21:43.308257+00:00
updated_at: 2026-07-30T17:21:43.308270+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  module_name: "backend.app.constants"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Constants Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

# Gotchas and Pitfalls: `backend.app.constants`

### `str, Enum` members compare equal to raw strings — but not always as you expect
**Trigger:** Because `UserStatus` inherits from `str`, `UserStatus.ACTIVE == "active"` is `True`, but `UserStatus.ACTIVE is "active"` is `False`, and `json.dumps(UserStatus.ACTIVE)` behavior depends on Python version / serializer. Developers mix enum members and raw strings inconsistently.
**Affected Files:** `backend/app/constants.py`, any consumer comparing statuses
**Fix:** Standardize on `.value` at boundaries, or use `StrEnum` (3.11+) which makes `str()` behavior explicit. Never rely on `is`.
**Category:** type-system
**Example:**
```python
UserStatus.ACTIVE == "active"       # True
UserStatus.ACTIVE is "active"       # False
f"{UserStatus.ACTIVE}"              # "UserStatus.ACTIVE" on <3.11, "active" via .value only
# So logging/format strings silently produce different text across Python versions
```

### `ALLOWED_STATUS_TRANSITIONS` keyed by `.value` strings, not enum members
**Trigger:** The dict uses `.value` for keys/values. A caller who does `ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE]` (passing the enum, not the string) may work by accident (str subclass hashes equal) — until someone switches to `StrEnum` or a non-str enum, silently breaking lookups.
**Affected Files:** `backend/app/constants.py`, service layer performing transition checks
**Fix:** Be consistent — either key by enum members throughout or always coerce with `.value`. Document which is expected.
**Category:** type-system
**Example:**
```python
ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE]        # works today (str hash)
ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE.value]  # explicit, safe
# If constants ever change base class, first form KeyErrors
```

### Mutable module-level `set` values can be corrupted at runtime
**Trigger:** `ALLOWED_STATUS_TRANSITIONS` is a plain `dict[str, set[str]]` at module scope — shared, mutable, and not frozen. Any code that does `transitions.add(...)` or `|=` mutates global state seen by every request/thread.
**Affected Files:** `backend/app/constants.py`, all importers
**Fix:** Use `frozenset` values and expose an immutable mapping (e.g. `types.MappingProxyType`).
**Category:** thread-safety
**Example:**
```python
t = ALLOWED_STATUS_TRANSITIONS[UserStatus.ACTIVE.value]
t.add("hacked")   # mutates the shared global for ALL requests
```

### `ROLE_ASSIGNED` / `ROLE_REVOKED` values start with `user.`, not `role.`
**Trigger:** The member names say `ROLE_*` but the values are `"user.role_assigned"` / `"user.role_revoked"`. Anyone matching by prefix (`action.startswith("role.")` on the frontend or in filters) will miss these.
**Affected Files:** `backend/app/constants.py`, `frontend/src/constants.js`, audit filtering logic
**Fix:** Confirm the prefix convention deliberately; if filtering by domain prefix is used, align the values or document the exception.
**Category:** domain
**Example:**
```python
[a for a in actions if a.startswith("role.")]  # silently excludes role changes
```

### No enforced sync with `frontend/src/constants.js`
**Trigger:** The docstring states the contract is maintained "by convention" with no shared type. Renaming a value here (e.g. `"deactivated"` → `"disabled"`) compiles and passes backend tests but silently breaks the frontend permission-hiding and audit label mapping.
**Affected Files:** `backend/app/constants.py`, `frontend/src/constants.js`
**Fix:** Add a codegen step or contract test that diffs the two files, or emit the enum as JSON and consume it in the frontend build.
**Category:** domain
**Example:**
```python
DEACTIVATED = "disabled"   # backend tests green, frontend audit view shows blank labels
```

### Permission strings use `:` but audit actions use `.` — easy to cross-wire
**Trigger:** Two similar-looking constant families with different separators (`users:deactivate` vs `user.deactivated`). Copy-paste or memory leads to passing an audit action where a permission is expected; both are plain strings so no type error occurs.
**Affected Files:** `backend/app/constants.py`, `security.require_permission`, audit writers
**Fix:** Since all are `str` subclasses, type checkers won't catch mismatches. Consider distinct newtypes or runtime validation at the enforcement points.
**Category:** type-system
**Example:**
```python
require_permission(AuditAction.USER_DEACTIVATED)  # str, no error — silently never grants
```

### `Enum(str)` allows accidental membership via string, not construction
**Trigger:** `UserStatus("active")` works, but a typo `UserStatus("Active")` raises `ValueError` at runtime — often in a request path, producing a 500 instead of a clean 400 if not caught.
**Affected Files:** `backend/app/constants.py`, deserialization/validation layer
**Fix:** Wrap `UserStatus(value)` in explicit validation returning a domain error; don't let raw `ValueError` propagate to the transport layer.
**Category:** framework
**Example:**
```python
UserStatus("Active")   # ValueError: 'Active' is not a valid UserStatus
```

### Transition map has no self-transitions or terminal-state documentation
**Trigger:** There's no `ACTIVE -> ACTIVE` entry; a no-op re-activation of an already-active user will fail the transition check rather than being treated as idempotent. Also `INVITED` cannot return once left.
**Affected Files:** `backend/app/constants.py`, service transition logic
**Fix:** Decide idempotency semantics explicitly; handle "same status" before consulting the map, and document irreversibility of leaving `INVITED`.
**Category:** domain
**Example:**
```python
new in ALLOWED_STATUS_TRANSITIONS.get(current, set())
# current == new == "active" -> False -> spurious rejection
```