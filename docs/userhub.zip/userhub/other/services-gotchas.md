---
id: 679a52f6-9537-5f26-a3f5-4b5afdd93bb6
type: gotcha
title: "Services Gotchas"
created_at: 2026-07-30T17:24:52.019169+00:00
updated_at: 2026-07-30T17:24:52.019187+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py
metadata:
  module_name: "backend.app.services"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Services Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/__init__.py`

# Gotcha Analysis: `backend.app.services`

## Observation: Empty Module

The provided source file contains **only a docstring** and no actual implementation:

```python
"""Service layer: business logic between the routers and the ORM."""
```

There is no code to analyze for concrete gotchas. However, I can provide the following:

---

### Empty/Stub Module Masquerading as Implemented
**Trigger:** Importing from `backend.app.services` expecting service functions that don't exist yet. Any `from backend.app.services import X` will raise `ImportError`.
**Affected Files:** `backend/app/services/__init__.py` (or the module file shown)
**Fix:** Confirm this is intentionally a stub. If routers reference it, add explicit `NotImplementedError` guards or ensure the module isn't imported until populated.
**Category:** domain
**Example:**
```python
# router.py
from backend.app.services import create_user  # ImportError: cannot import name 'create_user'
```

---

### Docstring-Only Package Init Can Hide Namespace Issues
**Trigger:** If this is an `__init__.py`, an empty docstring-only file means submodules aren't re-exported, so callers must know exact submodule paths.
**Affected Files:** package `__init__.py`
**Fix:** Decide on an explicit export policy (`__all__`) once services exist, rather than relying on implicit imports.
**Category:** framework
**Example:**
```python
# Expected but fails:
from backend.app.services import user_service   # only works if __init__ imports it
```

---

## Recommendation

To perform a meaningful gotcha/pitfall analysis focused on the categories you listed (thread safety, silent nulls, async/sync boundaries, attrs/polars/DuckDB quirks, performance traps), please provide the **actual implementation** of the service layer.

Specifically, useful files would include:
- The concrete service functions/classes
- ORM session handling code (a common source of thread-safety and async gotchas)
- Any polars/DuckDB data-processing logic
- attrs-based DTOs or models

Once you share real code, I can deliver targeted gotchas with triggers, affected files, fixes, and examples.