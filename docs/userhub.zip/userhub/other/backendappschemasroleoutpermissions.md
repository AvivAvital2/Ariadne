---
id: 44b42e42-60cf-5ef6-be89-86e6313e68c9
type: catalog
title: "backend.app.schemas.RoleOut.permissions"
created_at: 2026-07-30T15:09:16.666607+00:00
updated_at: 2026-07-30T17:48:08.792116+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.RoleOut.permissions"
  signature: "permissions: list[PermissionOut] = []"
  location: {'line_start': 26, 'line_end': 26, 'col_start': 4, 'col_end': 41}
  parent_qualified_name: "backend.app.schemas.RoleOut"
  sha_at_sync: "fd928fd9bee558e3284272547876fcc246c38a8bcaac2de74a32cca500284b99"
  description: "Defines the list of permissions associated with a role in the RoleOut response schema, defaulting to an empty list."
---
# backend.app.schemas.RoleOut.permissions

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.RoleOut.permissions in backend.app.schemas.RoleOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:26-26 :: permissions: list[PermissionOut] = []

Description: Defines the list of permissions associated with a role in the RoleOut response schema, defaulting to an empty list.

## Related Documents

- [backend.app.schemas.CurrentUser.permissions](d8daa9ee-b439-5bf1-a68b-ba541890eeb8.md) - Related (graph distance 1.34)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 1.42)
- [backend.app.models.Role.permissions](dac812a4-c563-5117-b391-45770c7406de.md) - Related (graph distance 1.43)
- [backend.app.schemas.RoleCreate.permission_ids](f7f21a19-f263-5fc9-acb5-6dff889c6b92.md) - Related (graph distance 1.44)
- [backend.app.schemas.PermissionOut](33babfda-be6e-5c55-bab9-c54508201c03.md) - Related (graph distance 1.53)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.58)
- [backend.app.services.roles.role.permissions](9053615e-30bc-5b0b-8611-3bec0a634e66.md) - Related (graph distance 1.60)
- [backend.app.schemas.UserCreate.role_ids](8a9c8e56-45c0-5086-9767-491ef3cb6db1.md) - Related (graph distance 2.64)
- [backend.app.models.Permission.roles](d0dd4ccf-ac79-5c30-b62c-acf02af231df.md) - Related (graph distance 2.75)
- [backend.app.schemas.RoleAssignment.role_ids](7ba7415b-c796-5982-b3c8-d8e9733dbdb3.md) - Related (graph distance 2.75)
