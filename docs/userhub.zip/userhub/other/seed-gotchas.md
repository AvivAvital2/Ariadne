---
id: 7612caad-221b-5751-899d-f0750f3bdc61
type: gotcha
title: "Seed Gotchas"
created_at: 2026-07-30T17:24:54.071464+00:00
updated_at: 2026-07-30T17:24:54.071478+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  module_name: "backend.app.seed"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Seed Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

# Gotchas and Pitfalls: `backend.app.seed`

### Race condition on concurrent first-run seeding
**Trigger:** Two workers/processes start simultaneously and both pass the `db.query(Permission).count() > 0` check before either commits. Both then attempt to insert the same baseline data.
**Affected Files:** `app/seed.py`, `app/main.py` (lifespan invocation)
**Fix:** Wrap the check+insert in a transaction with a table lock, or rely on a unique constraint + catch `IntegrityError`, or use an advisory lock. In multi-worker deployments (gunicorn/uvicorn `--workers N`), the lifespan runs per-worker, making this very likely.
**Category:** thread-safety
**Example:**
```python
# Worker A: count() == 0 -> proceeds
# Worker B: count() == 0 -> proceeds (A hasn't committed yet)
# Both insert perms -> IntegrityError or duplicate rows
if db.query(Permission).count() > 0:  # not atomic with the writes below
    return False
```

### Emptiness check only inspects the Permission table
**Trigger:** A database that has users/roles/audit logs but zero permissions (e.g., permissions deleted, partial migration, or a failed prior seed that committed some tables). `seed_if_empty` will re-run and create duplicate roles/users.
**Affected Files:** `app/seed.py`
**Fix:** Check the specific invariant you care about, or make all inserts idempotent via unique constraints and upserts. The "empty" definition silently equates "no permissions" with "no data at all."
**Category:** domain
**Example:**
```python
# DB has root/alice/bob but permissions table was truncated
if db.query(Permission).count() > 0:  # False -> re-seeds users -> duplicate username
    return False
```

### Partial commit leaves DB in a seeded-but-broken state
**Trigger:** An exception between the flushes and the final `db.commit()` (e.g., in `_seed_audit_history`). Everything is rolled back only if the caller rolls back—but if the caller commits or the session autoflushes elsewhere, partial data may persist. More subtly, if seeding fails mid-way and the next run's `count()` sees committed permissions, it returns `False` and never completes the users/roles.
**Affected Files:** `app/seed.py`
**Fix:** Ensure the whole function runs in a single atomic transaction; on any failure, roll back fully. Consider `with db.begin():` semantics.
**Category:** framework
**Example:**
```python
db.flush()  # perms flushed to transaction
# ... if this raises, and caller commits perms separately, next run skips seeding
_seed_audit_history(...)  # raises
db.commit()  # never reached
```

### `datetime.replace(hour=...)` can shift dates across DST/edge cases only for naive times — but here silently ignores minute drift assumptions
**Trigger:** Using `.replace(hour=hour, ...)` on a UTC-aware datetime is safe from DST, but the code assumes `now - timedelta(days=n)` lands on a clean day boundary. Since `now` carries the current time-of-day, subtracting whole days then replacing the hour is intentional—but if run near midnight UTC, "days_ago=0" with `hour=13` may produce a **future** timestamp relative to `now`.
**Affected Files:** `app/seed.py`
**Fix:** Clamp timestamps to `min(ts, now)` or compute from a normalized `today_start`.
**Category:** domain
**Example:**
```python
# Server starts at 07:00 UTC; event (0, 13, ...) -> ts at 13:00 today = future
ts = (now - datetime.timedelta(days=0)).replace(hour=13, ...)  # ahead of now
```

### Modulo indexing silently masks index mismatches
**Trigger:** `actors[actor_idx % len(actors)]` and `targets[target_idx % len(targets)]` never raise `IndexError`. If someone adds an event with `actor_idx=5` expecting a specific actor, it wraps around to the wrong one with no error.
**Affected Files:** `app/seed.py`
**Fix:** Validate indices explicitly (`assert actor_idx < len(actors)`) or remove the modulo so out-of-range data fails loudly during development.
**Category:** domain
**Example:**
```python
targets = [alice.id, bob.id, root.id]  # len 3
# event with target_idx=2 -> root.id, but if list order changes silently wrong
targets[target_idx % len(targets)]  # never errors, just wraps
```

### `.value` string status vs Enum comparison mismatch
**Trigger:** The code stores `UserStatus.ACTIVE.value` (a string) into the DB, and `action.value` for audit actions. Elsewhere in the codebase, comparing model `.status` (string) directly to `UserStatus.ACTIVE` (enum) will silently be `False`.
**Affected Files:** `app/seed.py`, `app/models.py`, `app/constants.py`, any consumer of `User.status`
**Fix:** Use a SQLAlchemy `Enum` column type or a consistent convention. Document that stored values are strings, not enum members.
**Category:** type-system
**Example:**
```python
user.status == UserStatus.ACTIVE       # False! ("active" != <enum>)
user.status == UserStatus.ACTIVE.value # True
```

### Enum iteration order drives permission→role mapping
**Trigger:** `perms = {p.value: ... for p in Perm}` relies on all referenced permission values (e.g., `Perm.USERS_READ.value`) existing in the enum. If a `Perm` member is renamed or removed, the dict lookups like `perms[Perm.AUDIT_READ.value]` raise `KeyError` at seed time only—not caught by type checkers.
**Affected Files:** `app/seed.py`, `app/constants.py`
**Fix:** Add a test that seeds against the real enum, or build role permission lists programmatically from enum members.
**Category:** framework
**Example:**
```python
# Remove AUDIT_READ from Perm -> viewer role construction throws KeyError
perms[Perm.AUDIT_READ.value]  # KeyError, only at runtime
```

### Session flush without commit leaves IDs valid only within transaction
**Trigger:** `db.flush()` populates `root.id`, `alice.id`, etc., but these IDs are only guaranteed valid within the current transaction. If a rollback occurs after `_seed_audit_history` builds `AuditLog` rows referencing those ids, the FK targets vanish while the log objects (if committed elsewhere) become dangling.
**Affected Files:** `app/seed.py`
**Fix:** Keep everything in one transaction (already mostly the case) and never expose these IDs outside the function before commit.
**Category:** framework
**Example:**
```python
db.flush()  # alice.id = 2 (uncommitted)
_seed_audit_history(..., targets=[alice.id, ...])  # depends on uncommitted id
# rollback -> id 2 never persisted
```

### Return value `False` is ambiguous under failure
**Trigger:** Callers may treat `False` as "already seeded, all good." But `False` is also implicitly the state if an early exception short-circuits before return (function raises, not returns). Boolean return conflates "no-op" with success without signaling the concurrent-seed skip case.
**Affected Files:** `app/seed.py`, `app/main.py`
**Fix:** Return richer status or log explicitly; ensure callers handle exceptions distinctly from `False`.
**Category:** domain
**Example:**
```python
if seed_if_empty(db):
    log.info("seeded")
# else branch: was it already seeded, or did seeding silently fail? unclear
```

### Timezone-aware timestamps may be stored as naive
**Trigger:** `created_at=ts` is tz-aware UTC, but if the `AuditLog.created_at` column is `DateTime` without `timezone=True`, SQLAlchemy/DB may strip the tzinfo, storing naive values. Later comparisons with tz-aware `now()` raise `TypeError: can't compare offset-naive and offset-aware`.
**Affected Files:** `app/seed.py`, `app/models.py`
**Fix:** Use `DateTime(timezone=True)` consistently, or store all UTC-naive and compare with naive `utcnow()`.
**Category:** type-system
**Example:**
```python
created_at=ts  # tz-aware here
# Later: AuditLog.created_at (naive from DB) vs datetime.now(tz) -> TypeError
```