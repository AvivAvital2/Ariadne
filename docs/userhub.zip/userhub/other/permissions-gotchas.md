---
id: 8c1ffa6e-17af-520a-81ae-e706aaa5e9cb
type: gotcha
title: "Permissions Gotchas"
created_at: 2026-07-30T17:26:50.439217+00:00
updated_at: 2026-07-30T17:26:50.439231+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js
metadata:
  module_name: "frontend.src.auth.permissions"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Permissions Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/auth/permissions.js`

# Gotchas & Pitfalls: `frontend.src.auth.permissions`

### Client-side checks are cosmetic, not security
**Trigger:** Developer assumes `hasPermission` protects sensitive actions/data. It only gates UI. Anyone can call the API directly or mutate `actor` in devtools.
**Affected Files:** `frontend/src/auth/permissions.js` and every component that uses it to conditionally render/enable actions.
**Fix:** Treat this purely as a UX helper. Rely on backend `security.require_permission` for real enforcement. Never expose data the user shouldn't see just because the button is hidden.
**Category:** domain
**Example:**
```javascript
// UI hides button, but the endpoint is still reachable:
if (hasPermission(actor, "users:deactivate")) renderDeactivateButton();
// Attacker: fetch("/api/users/5/deactivate", {method:"POST"}) — must be blocked server-side.
```

---

### Silent `false` on undefined/loading actor
**Trigger:** `actor` is `null`/`undefined` before `GET /api/me` resolves. `actor?.permissions?.includes` short-circuits to `undefined`, `Boolean(undefined)` → `false`. UI flickers "no permission" during load, indistinguishable from a genuine denial.
**Affected Files:** `permissions.js`; any component rendering during auth loading.
**Fix:** Track loading state separately (`isLoading` vs `denied`). Don't render permission-gated UI until `actor` is loaded.
**Category:** async
**Example:**
```javascript
// During load actor === null:
hasPermission(null, "users:deactivate"); // false — looks like a denial, not "unknown"
```

---

### Typo'd permission literals fail silently
**Trigger:** `permission` is a raw string. A typo (`"user:deactivate"` vs `"users:deactivate"`) returns `false` with no error. No validation that the string is a real permission from `constants.js`.
**Affected Files:** `permissions.js`; all callers passing string literals; `constants.js`.
**Fix:** Always import constants (`PERMISSIONS.USERS_DEACTIVATE`) rather than inline strings. Optionally validate the argument against the known set in dev builds.
**Category:** type-system
**Example:**
```javascript
hasPermission(actor, "users:deactvate"); // typo → always false, no warning
```

---

### `includes` is exact-match, no wildcard/hierarchy support
**Trigger:** Developer expects `"users:*"` or a broad `"admin"` grant to imply `"users:deactivate"`. `Array.includes` does exact string equality only.
**Affected Files:** `permissions.js`; wherever hierarchical/wildcard permissions are assumed.
**Fix:** If the backend supports wildcards/roles, replicate that matching logic here (or expand permissions server-side into concrete literals before sending in `/api/me`).
**Category:** domain
**Example:**
```javascript
actor.permissions = ["users:*"];
hasPermission(actor, "users:deactivate"); // false — no wildcard expansion
```

---

### Non-array `permissions` throws instead of returning false
**Trigger:** If the API returns `permissions` as an object/string/`null` (schema drift, serialization bug), `.includes` behaves inconsistently. On a string it does substring matching (surprising true/false); on an object it throws (`.includes is not a function`).
**Affected Files:** `permissions.js`; API response shape from `/api/me`.
**Fix:** Guard the type: `Array.isArray(actor?.permissions) && actor.permissions.includes(permission)`.
**Category:** type-system
**Example:**
```javascript
hasPermission({ permissions: "users:deactivate:extra" }, "users:deactivate");
// true! String.includes does substring match — false positive.
hasPermission({ permissions: {} }, "x"); // TypeError: includes is not a function
```

---

### Case/whitespace sensitivity
**Trigger:** Permission comparison is exact and case-sensitive. `"Users:Deactivate"` or a trailing space won't match backend's canonical form.
**Affected Files:** `permissions.js`; `constants.js`.
**Fix:** Enforce a single canonical casing convention via constants; never hand-type literals.
**Category:** type-system
**Example:**
```javascript
actor.permissions = ["users:deactivate"];
hasPermission(actor, "Users:Deactivate"); // false
```

---

### Frontend/backend permission drift
**Trigger:** The literal here must exactly match `security.require_permission`. If backend renames a permission, this file silently keeps returning `false` (or worse, `true` for a now-nonexistent grant), and the mismatch only surfaces as confusing UX.
**Affected Files:** `permissions.js`, `constants.js`, backend `security.require_permission`.
**Fix:** Generate the permission constants from a single shared source (codegen from backend enum) rather than maintaining two hand-written lists.
**Category:** domain
**Example:**
```javascript
// Backend renamed to "users:disable", frontend still checks "users:deactivate"
hasPermission(actor, "users:deactivate"); // silently false forever
```

---

### `Boolean()` masks intent — no distinction between "no" and "unknown"
**Trigger:** The function collapses three states (has / doesn't have / can't determine) into a boolean. Callers can never react differently to "still loading" vs "explicitly denied."
**Affected Files:** `permissions.js` and all callers.
**Fix:** For loading-sensitive UI, check actor readiness before calling, or provide a companion helper that returns a tri-state.
**Category:** type-system
**Example:**
```javascript
const canDo = hasPermission(actorMaybeStillLoading, "x"); // false — but why?
```