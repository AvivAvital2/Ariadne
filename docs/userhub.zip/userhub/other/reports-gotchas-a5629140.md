---
id: a5629140-1196-58e6-bc67-8e89c1d1739e
type: gotcha
title: "Reports Gotchas"
created_at: 2026-07-30T17:23:19.504057+00:00
updated_at: 2026-07-30T17:23:19.504071+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  module_name: "backend.app.routers.reports"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Reports Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

# Gotchas & Pitfalls: `backend.app.routers.reports`

### Sync route blocks the event loop
**Trigger:** The endpoint is defined with `def` (not `async def`). FastAPI runs sync routes in a threadpool, but the raw SQL query is fully synchronous and blocking. Under load, a slow reporting query occupies a threadpool worker for its entire duration.
**Affected Files:** `backend/app/routers/reports.py`
**Fix:** Keep it sync (which is correct for blocking SQLAlchemy), but be aware the default Starlette threadpool is limited (~40 workers). Heavy reporting queries can starve the pool and block *all* sync routes. Consider a dedicated executor, timeouts, or moving reports to a read replica.
**Category:** async
**Example:**
```python
# A 30-second reporting query holds one of the limited threadpool slots.
# Enough concurrent report calls => all sync CRUD routes stall too.
def user_activity(...):  # runs in threadpool
    rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
```

---

### Raw SQL bypasses ORM identity map and defeats parametrization habits
**Trigger:** `text(USER_ACTIVITY_SQL)` runs a raw string. If `USER_ACTIVITY_SQL` is ever built with string interpolation (e.g. adding filters), it becomes an SQL injection vector. The current constant is static, but the pattern invites unsafe extension.
**Affected Files:** `backend/app/reports/queries.py`, `backend/app/routers/reports.py`
**Fix:** Always use bound parameters via `text(...).bindparams()` or `:param` placeholders passed to `db.execute(text(sql), {"param": value})`. Never f-string user input into the SQL.
**Category:** framework
**Example:**
```python
# DANGEROUS future change:
sql = f"{USER_ACTIVITY_SQL} WHERE u.name = '{name}'"  # injection
# Safe:
db.execute(text(USER_ACTIVITY_SQL + " WHERE u.name = :name"), {"name": name})
```

---

### Column-name/schema coupling is silent and fragile
**Trigger:** `UserActivityRow(**row)` splats the SQL result mapping directly into the Pydantic schema. Column aliases in `USER_ACTIVITY_SQL` must exactly match `UserActivityRow` field names. A renamed column or extra selected column breaks at runtime, not at import time.
**Affected Files:** `backend/app/reports/queries.py`, `backend/app/schemas.py`, `backend/app/routers/reports.py`
**Fix:** Pin the SQL column aliases to the schema, add a test that executes the query against a fixture DB, and consider `UserActivityRow.model_validate(dict(row))` with `model_config = ConfigDict(extra="forbid")` to catch drift early.
**Category:** type-system
**Example:**
```sql
-- if query returns "user_name" but schema has "username":
SELECT u.name AS user_name ...
-- => UserActivityRow(**row) raises "unexpected keyword argument 'user_name'"
-- or silently drops data if extra="ignore"
```

---

### Materializing `.all()` loads entire result set into memory
**Trigger:** `.mappings().all()` plus the list comprehension builds two full copies of the dataset (raw rows + Pydantic objects) in memory. Reporting queries over `audit_log` can return huge row counts.
**Affected Files:** `backend/app/routers/reports.py`
**Fix:** Add `LIMIT`/pagination to the query, or stream results with `.mappings()` iteration / `yield_per` for large sets. Constrain the report by a date range.
**Category:** performance
**Example:**
```python
rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()  # loads all
return [UserActivityRow(**row) for row in rows]  # doubles memory
```

---

### Type coercion surprises from DB-native types
**Trigger:** Raw SQL returns whatever DB driver types the columns produce (e.g. `Decimal` for counts/aggregates, `datetime` with/without tzinfo, `None` for outer-joined columns). Pydantic will coerce or reject these differently than the ORM-mapped path you're used to.
**Affected Files:** `backend/app/schemas.py`, `backend/app/reports/queries.py`
**Fix:** Explicitly `CAST` aggregates in SQL (e.g. `CAST(COUNT(*) AS INTEGER)`), declare `Optional[...]` fields for LEFT-JOINed columns, and normalize timezone handling. Test with real DB output, not mocks.
**Category:** type-system
**Example:**
```python
# COUNT(*) may arrive as Decimal or int depending on driver;
# a LEFT JOIN produces NULL -> None for a non-Optional field -> ValidationError
class UserActivityRow(BaseModel):
    login_count: int          # may receive Decimal
    last_seen: datetime | None # LEFT JOIN can yield None
```

---

### No result ordering guarantee
**Trigger:** Unless `USER_ACTIVITY_SQL` contains an explicit `ORDER BY`, row order is non-deterministic and may change between DB versions, query plans, or parallel scans. Consumers relying on order will break intermittently.
**Affected Files:** `backend/app/reports/queries.py`
**Fix:** Add a deterministic `ORDER BY` (e.g. by user id or activity timestamp) to the query.
**Category:** domain
**Example:**
```sql
SELECT ... FROM users u ...   -- no ORDER BY => arbitrary order
```

---

### Permission check uses `.value` string, easy to mismatch
**Trigger:** `require_permission(Permission.AUDIT_READ.value)` passes the raw string value. If `require_permission` elsewhere expects the enum member (or vice versa), the check silently passes/fails without a type error.
**Affected Files:** `backend/app/security.py`, `backend/app/constants.py`, `backend/app/routers/reports.py`
**Fix:** Standardize the contract—have `require_permission` accept the `Permission` enum directly and normalize internally, so callers can't pass mismatched forms.
**Category:** type-system
**Example:**
```python
require_permission(Permission.AUDIT_READ.value)  # str
# vs another router:
require_permission(Permission.USER_WRITE)        # enum -> inconsistent
```

---

### Session lifetime tied to `get_db`, but raw connection state matters
**Trigger:** Raw `db.execute` runs in the same session/transaction as ORM operations. If a prior ORM operation left the session in a pending/flushed-but-not-committed state, the raw read may see uncommitted data or trigger an unexpected autoflush.
**Affected Files:** `backend/app/database.py`, `backend/app/routers/reports.py`
**Fix:** For read-only reports, use a fresh read-only session or explicitly `db.rollback()`/set the query to a snapshot. Be aware autoflush fires before raw `text()` execution too.
**Category:** framework
**Example:**
```python
# autoflush is triggered even before a raw text() query;
# any pending ORM object gets flushed unexpectedly here:
rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()
```