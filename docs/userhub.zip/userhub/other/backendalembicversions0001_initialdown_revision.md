---
id: 9e3df79b-2696-5d0c-83e1-8a502a088447
type: catalog
title: "backend.alembic.versions.0001_initial.down_revision"
created_at: 2026-07-30T15:09:16.337253+00:00
updated_at: 2026-07-30T17:48:08.783067+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.alembic.versions.0001_initial.down_revision"
  signature: "down_revision = None"
  location: {'line_start': 16, 'line_end': 16, 'col_start': 0, 'col_end': 20}
  parent_qualified_name: None
  sha_at_sync: "bd64f020ddd1262fd9eec2d2d87a36ef75a5bab08bc30dcad1115e7caa621fd5"
  description: "Specifies that this Alembic migration is the initial revision by setting `down_revision` to `None`, indicating there is no prior migration to downgrade to."
---
# backend.alembic.versions.0001_initial.down_revision

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py`

variable backend.alembic.versions.0001_initial.down_revision [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/versions/0001_initial.py:16-16 :: down_revision = None

Description: Specifies that this Alembic migration is the initial revision by setting `down_revision` to `None`, indicating there is no prior migration to downgrade to.

## Related Documents

- [backend.alembic.versions.0001_initial.revision](1909d2a4-2d0b-54b8-85f7-b688437db8df.md) - Related (graph distance 1.24)
- [backend.alembic.versions.0001_initial.depends_on](80169ad5-6b3b-52ce-b584-2e3405782d63.md) - Related (graph distance 1.34)
