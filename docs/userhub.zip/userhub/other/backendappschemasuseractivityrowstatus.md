---
id: d4d26d18-4a50-59b3-b9ab-f5cec77e367f
type: catalog
title: "backend.app.schemas.UserActivityRow.status"
created_at: 2026-07-30T15:09:16.677465+00:00
updated_at: 2026-07-30T17:48:08.843515+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserActivityRow.status"
  signature: "status: str"
  location: {'line_start': 102, 'line_end': 102, 'col_start': 4, 'col_end': 15}
  parent_qualified_name: "backend.app.schemas.UserActivityRow"
  sha_at_sync: "bed15f609b322d0d3d2ca4fbb6c3099ab6f09b0316a16fae2ca20d17e13a8fd6"
  description: "Stores the status of a user activity record as a string, representing the current state or outcome of the activity within the `UserActivityRow` schema."
---
# backend.app.schemas.UserActivityRow.status

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserActivityRow.status in backend.app.schemas.UserActivityRow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:102-102 :: status: str

Description: Stores the status of a user activity record as a string, representing the current state or outcome of the activity within the `UserActivityRow` schema.

## Related Documents

- [backend.app.schemas.UserOut.status](dc52195a-34a2-57f5-939c-7b0f6c1d7223.md) - Related (graph distance 1.23)
- [backend.app.schemas.UserStatusUpdate.status](152b945e-c8fd-5056-8f43-2b0b883f5dc6.md) - Related (graph distance 1.23)
- [backend.app.schemas.CurrentUser.status](a9971f97-89c7-5dd4-9a5e-d41a8781627b.md) - Related (graph distance 1.25)
- [backend.app.schemas.UserActivityRow.username](98bd86de-59e2-590f-8bf7-00b3bb963d8d.md) - Related (graph distance 1.41)
- [backend.app.models.User.status](d889c49c-87ed-5f94-a9dd-4f102349b418.md) - Related (graph distance 1.43)
- [backend.app.schemas.UserActivityRow](8f481f9b-4fec-51be-a015-14ccd2d628c2.md) - Related (graph distance 1.61)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 2.65)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.65)
- [backend.app.constants.UserStatus](db33830c-c05a-542f-b06e-c6a56d283c7a.md) - Related (graph distance 2.66)
- [backend.app.services.users.status](5a607696-6955-5a5a-b93f-2291f001fe8d.md) - Related (graph distance 2.68)
