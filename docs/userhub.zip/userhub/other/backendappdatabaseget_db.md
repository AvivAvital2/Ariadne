---
id: b1de7430-33d3-5af5-aa00-16c515f88a86
type: catalog
title: "backend.app.database.get_db"
created_at: 2026-07-30T15:09:15.751250+00:00
updated_at: 2026-07-30T17:48:08.772349+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.database.get_db"
  signature: "def get_db() -> Iterator[Session]:"
  location: {'line_start': 22, 'line_end': 28, 'col_start': 0, 'col_end': 18}
  parent_qualified_name: None
  sha_at_sync: "48e50d6b4c2881f86a02be95cc2454d955cd539d1eecfea09fc00d38e6e50618"
  description: "Provides a database session as a generator dependency, yielding a SQLAlchemy `Session` and ensuring it is closed after use."
---
# backend.app.database.get_db

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/database.py`

function backend.app.database.get_db [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/database.py:22-28 :: def get_db() -> Iterator[Session]:

Description: Provides a database session as a generator dependency, yielding a SQLAlchemy `Session` and ensuring it is closed after use.

## Related Documents

- [backend.app.database.db](79b07bea-702c-59cb-bbea-2a7349e809e6.md) - Related (graph distance 1.55)
- [backend.app.main.db](bb5aec0e-efa8-5d81-9107-bf2af1df3260.md) - Related (graph distance 2.67)
- [backend.app.database.SessionLocal](8b8fafba-48bd-565d-a261-fd009a8cb0a6.md) - Related (graph distance 2.84)
