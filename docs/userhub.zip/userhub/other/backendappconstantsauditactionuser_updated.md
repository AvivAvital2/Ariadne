---
id: 6ed359da-8cd3-5cda-a86b-312ebbc9760e
type: catalog
title: "backend.app.constants.AuditAction.USER_UPDATED"
created_at: 2026-07-30T15:09:15.999056+00:00
updated_at: 2026-07-30T17:48:08.778045+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.AuditAction.USER_UPDATED"
  signature: "USER_UPDATED = "user.updated""
  location: {'line_start': 49, 'line_end': 49, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.AuditAction"
  sha_at_sync: "7946d29f548f85d7453c81f94e504ae6133799d06132fc7df829c4148c14345d"
  description: "Enum member of `AuditAction` representing an audit log event for when a user's information is modified, with the string value `"user.updated"`."
---
# backend.app.constants.AuditAction.USER_UPDATED

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.AuditAction.USER_UPDATED in backend.app.constants.AuditAction [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:49-49 :: USER_UPDATED = "user.updated"

Description: Enum member of `AuditAction` representing an audit log event for when a user's information is modified, with the string value `"user.updated"`.

## Related Documents

- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 1.22)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 1.22)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 1.26)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 1.30)
- [backend.app.constants.AuditAction.ROLE_ASSIGNED](acc30db8-b69c-5f6f-88d4-de745f572998.md) - Related (graph distance 1.46)
- [backend.app.constants.AuditAction.ROLE_REVOKED](941c3822-94ac-5358-a3bf-3f1ce80016d7.md) - Related (graph distance 1.46)
- [backend.app.constants.AuditAction](966803e2-fceb-5ae6-8492-3ddfcff173ef.md) - Related (graph distance 1.61)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.50)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 2.71)
- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 2.71)
