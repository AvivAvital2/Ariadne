---
id: fd160f21-b512-5c2a-a845-de7baab7ee29
type: catalog
title: "backend.app.constants.Permission.USERS_CREATE"
created_at: 2026-07-30T15:09:15.959149+00:00
updated_at: 2026-07-30T17:48:08.776528+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.Permission.USERS_CREATE"
  signature: "USERS_CREATE = "users:create""
  location: {'line_start': 34, 'line_end': 34, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.Permission"
  sha_at_sync: "7c83a492989ccc80201f9326ee39b6f26d0591226395f8cc0c1384073bcedb65"
  description: "Defines the permission string `"users:create"` that authorizes the creation of new user accounts within the application's access control system."
---
# backend.app.constants.Permission.USERS_CREATE

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.Permission.USERS_CREATE in backend.app.constants.Permission [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:34-34 :: USERS_CREATE = "users:create"

Description: Defines the permission string `"users:create"` that authorizes the creation of new user accounts within the application's access control system.

## Related Documents

- [backend.app.constants.Permission.USERS_DELETE](3b2b2394-420d-56e1-9e50-c1b720053ffc.md) - Related (graph distance 1.22)
- [backend.app.constants.Permission.USERS_READ](6c6f8a8c-4535-5145-b607-0a8152a816ed.md) - Related (graph distance 1.22)
- [backend.app.constants.Permission.USERS_EDIT](544cfbe1-b37c-5c95-a03e-945177198921.md) - Related (graph distance 1.22)
- [backend.app.constants.Permission.USERS_DEACTIVATE](7dfcaa77-980d-5b54-83fb-08f2b6ee91e0.md) - Related (graph distance 1.34)
- [backend.app.constants.AuditAction.USER_CREATED](b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4.md) - Related (graph distance 1.61)
- [backend.app.constants.Permission.AUDIT_READ](87179fb4-2b36-5589-a70b-0aa36e49e217.md) - Related (graph distance 2.57)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 2.72)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.73)
- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 2.83)
- [backend.app.constants.Permission](1fc5f016-d81b-5263-8c7c-ee091ce31d55.md) - Related (graph distance 2.85)
