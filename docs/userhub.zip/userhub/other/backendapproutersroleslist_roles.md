---
id: cfb4a684-a4d1-552d-950c-750cadabe210
type: catalog
title: "backend.app.routers.roles.list_roles"
created_at: 2026-07-30T15:09:16.758450+00:00
updated_at: 2026-07-30T17:48:08.846818+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.roles.list_roles"
  signature: "def list_roles("
  location: {'line_start': 17, 'line_end': 21, 'col_start': 0, 'col_end': 38}
  parent_qualified_name: None
  sha_at_sync: "7defcb2e47850b3096e359100c063f1a7a3ff8d48ad6e539dfbef3fb699d3cdd"
  description: "Retrieves and returns a list of all available roles from the backend."
---
# backend.app.routers.roles.list_roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py`

function backend.app.routers.roles.list_roles [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/roles.py:17-21 :: def list_roles(

Description: Retrieves and returns a list of all available roles from the backend.

## Related Documents

- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.23)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 1.35)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 1.50)
- [backend.app.routers.audit.list_audit](de42e7ba-8f21-5ff2-840f-f27e74b6f36a.md) - Related (graph distance 1.54)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 1.56)
- [backend.app.schemas.UserOut.roles](771a5956-cd7a-5878-8970-0ceedd4b8172.md) - Related (graph distance 1.61)
- [backend.app.routers.users.assign_roles](c95f5b82-4808-5a02-b583-176903208b03.md) - Related (graph distance 1.64)
- [backend.app.services.roles.list_permissions](c0635854-e157-5ed0-836c-3317d08ec451.md) - Related (graph distance 2.68)
- [backend.app.services.users.assign_roles](baa9a5d5-9ff6-5849-893d-84c97d2d0006.md) - Related (graph distance 2.73)
- [backend.app.services.roles.create_role](9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53.md) - Related (graph distance 2.78)
