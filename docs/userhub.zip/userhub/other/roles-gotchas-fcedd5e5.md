---
id: fcedd5e5-cb88-5b8e-b8e4-4ce12d1b26d2
type: gotcha
title: "Roles Gotchas"
created_at: 2026-07-30T17:25:39.807681+00:00
updated_at: 2026-07-30T17:25:39.807694+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  module_name: "backend.app.services.roles"
  language: "python"
  provenance: "code-derived"
  source_name: "userhub"
---
# Roles Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

# Gotchas and Pitfalls: `backend.app.services.roles`

### Silent permission drop when IDs don't exist
**Trigger:** Passing `permission_ids` that contain non-existent IDs
**Affected Files:** `roles.py` (`create_role`)
**Fix:** Validate that all requested IDs resolved before assigning; raise 400/422 if the fetched count doesn't match the requested count.
**Category:** domain
**Example:**
```python
# Requesting [1, 2, 999] where 999 doesn't exist
role.permissions = db.query(Permission).filter(Permission.id.in_([1,2,999])).all()
# Silently assigns only [1, 2] — no error, caller thinks all 3 were granted

# Fix:
perms = db.query(Permission).filter(Permission.id.in_(permission_ids)).all()
if len(perms) != len(set(permission_ids)):
    raise HTTPException(422, detail="unknown permission id(s)")
role.permissions = perms
```

---

### Race condition on duplicate name check
**Trigger:** Two concurrent `create_role` calls with the same `name`
**Affected Files:** `roles.py` (`create_role`)
**Fix:** The pre-check-then-insert pattern is not atomic. Rely on a unique DB constraint on `Role.name` and catch `IntegrityError` to return 409.
**Category:** thread-safety
**Example:**
```python
# Both requests pass this check before either commits:
if db.query(Role).filter(Role.name == name).first() is not None:
    raise HTTPException(409, ...)
# Result: two rows with same name, or an unhandled IntegrityError 500

# Fix:
try:
    db.add(role); db.commit()
except IntegrityError:
    db.rollback()
    raise HTTPException(409, detail="role already exists")
```

---

### HTTPException raised inside a service layer
**Trigger:** Calling these functions outside a FastAPI request context (jobs, CLI, tests)
**Affected Files:** `roles.py` (`get_role`, `create_role`)
**Fix:** Raise a domain-specific exception (e.g. `RoleNotFound`) and translate to HTTP at the router/handler boundary. Keeps service reusable.
**Category:** framework
**Example:**
```python
# In a background worker:
role = get_role(db, 5)  # raises HTTPException(404) → worker doesn't know what to do with it
```

---

### `db.get` vs `db.query` cache/identity map surprise
**Trigger:** Using `db.get(Role, role_id)` after the object was expired or modified elsewhere
**Affected Files:** `roles.py` (`get_role`)
**Fix:** `db.get()` returns from the identity map without hitting the DB if the object is already loaded — it can return stale in-session state. Use `db.query(...).get()` awareness or `db.refresh()` when freshness matters.
**Category:** framework
**Example:**
```python
role = db.get(Role, 1)   # may return already-loaded instance, not a fresh SELECT
```

---

### Non-int `role_id` bypasses 404 with a 500
**Trigger:** Passing a value that can't be coerced to the PK type
**Affected Files:** `roles.py` (`get_role`)
**Fix:** Ensure `role_id: int` is enforced at the API boundary (FastAPI path validation). If called internally with a str/None, `db.get` may raise instead of returning None → 500 rather than 404.
**Category:** type-system
**Example:**
```python
get_role(db, None)   # db.get(Role, None) → error, not a clean 404
```

---

### `permissions` collection replaced, not merged
**Trigger:** Expecting `create_role` semantics to reuse for updates
**Affected Files:** `roles.py` (`create_role`)
**Fix:** `role.permissions = [...]` fully replaces the relationship. Fine on create, but if copy-pasted into an update path it silently wipes existing permissions. Document intent.
**Category:** framework
**Example:**
```python
role.permissions = new_list  # discards any previously associated permissions
```

---

### Duplicate IDs inflate/skew validation
**Trigger:** `permission_ids=[1, 1, 2]`
**Affected Files:** `roles.py` (`create_role`)
**Fix:** `in_()` de-duplicates naturally, so the query returns [perm1, perm2]. Any length-based validation must use `set(permission_ids)` to compare, or a duplicate request looks like a "missing id" error.
**Category:** domain
**Example:**
```python
db.query(Permission).filter(Permission.id.in_([1,1,2])).all()  # len == 2, not 3
```

---

### N+1 / lazy load on `permissions` in list_roles
**Trigger:** Serializing `list_roles()` result including each role's permissions
**Affected Files:** `roles.py` (`list_roles`)
**Fix:** `list_roles` loads roles but not permissions. If the response schema serializes `role.permissions`, each role triggers a separate lazy-load query. Use `joinedload(Role.permissions)` / `selectinload`.
**Category:** performance
**Example:**
```python
roles = list_roles(db)
for r in roles:
    r.permissions  # one extra SELECT per role → N+1
```

---

### `db.commit()` inside service commits caller's unit of work
**Trigger:** Calling `create_role` as part of a larger transaction
**Affected Files:** `roles.py` (`create_role`)
**Fix:** The unconditional `commit()` finalizes any other pending changes in the same session, breaking atomicity if the caller intended a broader transaction. Consider `flush()` + let caller commit, or accept this coupling explicitly.
**Category:** framework
**Example:**
```python
# caller wanted role + audit_log in one tx
create_role(db, ...)      # commits here
db.add(audit_log); ...    # separate transaction — role persists even if this fails
```