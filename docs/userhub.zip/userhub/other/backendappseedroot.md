---
id: 18365c02-cf65-5a40-bfe4-a549d2319780
type: catalog
title: "backend.app.seed.root"
created_at: 2026-07-30T15:09:16.252531+00:00
updated_at: 2026-07-30T17:48:08.781305+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.seed.root"
  signature: "root = User("
  location: {'line_start': 58, 'line_end': 64, 'col_start': 4, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "ebc7f386d6f536cf97f3b7d4f4d928eea9768440575f1739c3989ed19ea79ec8"
  description: "Creates a `User` instance representing a root/administrator account, used for seeding the database with an initial privileged user."
---
# backend.app.seed.root

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py`

variable backend.app.seed.root [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/seed.py:58-64 :: root = User(

Description: Creates a `User` instance representing a root/administrator account, used for seeding the database with an initial privileged user.

## Related Documents

- [backend.app.seed.bob](1c3620a3-bfc3-5c36-b44e-d470e854d85d.md) - Related (graph distance 1.29)
- [backend.app.seed.alice](702ee9ad-e28b-5754-bd86-f639bd90e28c.md) - Related (graph distance 1.37)
- [backend.app.seed.admin](4041d0d9-ff75-570f-9dd0-77920e758db4.md) - Related (graph distance 1.52)
- [backend.app.seed.editor](6e2bd7b7-3ff8-58f4-9873-f0045a8b85d6.md) - Related (graph distance 2.80)
- [backend.app.seed.viewer](97dec330-b5ac-57ef-af60-8400a71d11da.md) - Related (graph distance 2.98)
- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 3.10)
