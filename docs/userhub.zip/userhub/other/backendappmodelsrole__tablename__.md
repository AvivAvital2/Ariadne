---
id: 37624afd-6108-5b4e-8e41-56008d592ced
type: catalog
title: "backend.app.models.Role.__tablename__"
created_at: 2026-07-30T15:09:15.722416+00:00
updated_at: 2026-07-30T17:48:08.768040+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.Role.__tablename__"
  signature: "__tablename__ = "roles""
  location: {'line_start': 55, 'line_end': 55, 'col_start': 4, 'col_end': 27}
  parent_qualified_name: "backend.app.models.Role"
  sha_at_sync: "c8eafe12e0f806524af1a4d217708910173d98e3e1a87de0b5e44741e4a02d02"
  description: "Specifies the database table name as "roles" for the `Role` SQLAlchemy model."
---
# backend.app.models.Role.__tablename__

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.Role.__tablename__ in backend.app.models.Role [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:55-55 :: __tablename__ = "roles"

Description: Specifies the database table name as "roles" for the `Role` SQLAlchemy model.

## Related Documents

- [backend.app.models.User.__tablename__](d2a6a7b3-ecb1-5671-9d6e-1dddc1d79573.md) - Related (graph distance 1.19)
- [backend.app.models.Permission.__tablename__](4c6f0324-6589-5069-938c-4b0eec16aea3.md) - Related (graph distance 1.21)
- [backend.app.models.AuditLog.__tablename__](f7701d3c-d768-59a6-a353-5dc7d0dc27df.md) - Related (graph distance 1.25)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 1.60)
- [backend.app.models.role_permissions](2862ba3a-f04e-542f-b12e-006257f4a4d6.md) - Related (graph distance 2.86)
- [backend.app.models.User.roles](1519edf1-a8cb-5c29-bd10-13f2b20957d8.md) - Related (graph distance 2.99)
