---
id: 25c70609-8c99-55e4-9d8f-49625d0d95d4
type: catalog
title: "backend.app.models.AuditLog.actor_id"
created_at: 2026-07-30T15:09:15.726079+00:00
updated_at: 2026-07-30T17:48:08.771354+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.actor_id"
  signature: "actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)"
  location: {'line_start': 86, 'line_end': 86, 'col_start': 4, 'col_end': 87}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "477c0180ff0a9c1e9692e93f3a80d56958d545789c12495b961526845172e679"
  description: "A nullable foreign key column referencing `users.id` that identifies the user who performed the audited action, allowing null for system-initiated or anonymous events."
---
# backend.app.models.AuditLog.actor_id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.actor_id in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:86-86 :: actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)

Description: A nullable foreign key column referencing `users.id` that identifies the user who performed the audited action, allowing null for system-initiated or anonymous events.

## Related Documents

- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 1.26)
- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.31)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 1.34)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 1.49)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.55)
- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 1.58)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 2.57)
- [backend.app.models.Permission.id](ffa6c22f-1114-51e8-b4d3-7542899f8270.md) - Related (graph distance 2.60)
- [backend.app.models.Role.id](46688c41-9a92-5650-b6b3-e8568937f320.md) - Related (graph distance 2.61)
- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 2.76)
