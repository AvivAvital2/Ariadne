---
id: 2a63bd28-2519-54a8-8017-ed2081df85d9
type: catalog
title: "backend.alembic.env.run_migrations_offline"
created_at: 2026-07-30T15:09:16.525802+00:00
updated_at: 2026-07-30T17:48:08.784040+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.alembic.env.run_migrations_offline"
  signature: "def run_migrations_offline() -> None:"
  location: {'line_start': 22, 'line_end': 31, 'col_start': 0, 'col_end': 32}
  parent_qualified_name: None
  sha_at_sync: "4cf695820d8867e804a231093526d7df3320969d1c3869b06a0dedbd6ead81c4"
  description: "Configures the Alembic migration context in offline mode using a database URL (rather than an active connection) and runs the pending migrations, emitting the resulting SQL statements to the script output."
---
# backend.alembic.env.run_migrations_offline

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py`

function backend.alembic.env.run_migrations_offline [python] /Users/spark/git/Ariadne.orig/userhub/backend/alembic/env.py:22-31 :: def run_migrations_offline() -> None:

Description: Configures the Alembic migration context in offline mode using a database URL (rather than an active connection) and runs the pending migrations, emitting the resulting SQL statements to the script output.

## Related Documents

- [backend.alembic.env.run_migrations_online](bfbf6b4e-59f6-5a80-927e-1a921025a64f.md) - Related (graph distance 1.33)
