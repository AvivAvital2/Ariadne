---
id: 16dc24ad-efa2-59a7-88bf-ca50f7fd9ee8
type: catalog
title: "backend.app.models.User.email"
created_at: 2026-07-30T15:09:15.720742+00:00
updated_at: 2026-07-30T17:48:08.766765+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.email"
  signature: "email: Mapped[str] = mapped_column(String(255), unique=True)"
  location: {'line_start': 40, 'line_end': 40, 'col_start': 4, 'col_end': 64}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "4a08ce628b7cf955fbfacc6767f8f3ae9da3242c1e0dda17a600f41745c35bee"
  description: "Stores the user's email address as a required string with a maximum length of 255 characters, enforced to be unique across all user records."
---
# backend.app.models.User.email

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.email in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:40-40 :: email: Mapped[str] = mapped_column(String(255), unique=True)

Description: Stores the user's email address as a required string with a maximum length of 255 characters, enforced to be unique across all user records.

## Related Documents

- [backend.app.schemas.UserCreate.email](6a7dc860-10ed-51d0-b9eb-238eb9016eb4.md) - Related (graph distance 1.31)
- [backend.app.schemas.UserOut.email](04bde0ab-600e-504d-bc65-46149b42bea9.md) - Related (graph distance 1.32)
- [backend.app.models.User.username](e6944542-0f4c-5b3c-854a-1b1143cba0f7.md) - Related (graph distance 1.35)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 1.43)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 1.47)
- [backend.app.services.users.email](c9d9526a-dd04-57c7-b212-845716fc2b78.md) - Related (graph distance 1.56)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.63)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 2.64)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 2.67)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.76)
