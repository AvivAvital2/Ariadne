---
id: 560f3447-cb6e-5c79-8253-b6bd964277c0
type: catalog
title: "backend.app.routers.users.list_users"
created_at: 2026-07-30T15:09:16.734968+00:00
updated_at: 2026-07-30T17:48:08.844611+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.list_users"
  signature: "def list_users("
  location: {'line_start': 41, 'line_end': 46, 'col_start': 0, 'col_end': 53}
  parent_qualified_name: None
  sha_at_sync: "4f788d3f7b8770ac6d99f6d7d333513194a9a0ffbf6c1a56efebf769ffda170a"
  description: "Retrieves and returns a list of all users. Serves as the handler for the corresponding GET endpoint in the users router."
---
# backend.app.routers.users.list_users

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.list_users [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:41-46 :: def list_users(

Description: Retrieves and returns a list of all users. Serves as the handler for the corresponding GET endpoint in the users router.

## Related Documents

- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 1.35)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 1.42)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.46)
- [backend.app.routers.audit.list_audit](de42e7ba-8f21-5ff2-840f-f27e74b6f36a.md) - Related (graph distance 1.54)
- [backend.app.services.roles.list_roles](9dc8357a-f10a-520b-b090-8ee4bed57339.md) - Related (graph distance 2.85)
- [backend.app.services.roles.list_permissions](c0635854-e157-5ed0-836c-3317d08ec451.md) - Related (graph distance 2.88)
- [backend.app.services.audit.list_entries](a3001b30-5dd3-5847-a88a-26a5c75b8379.md) - Related (graph distance 2.88)
- [backend.app.routers.roles.create_role](73d0d0f9-10a7-571b-aca1-a6f15696cba4.md) - Related (graph distance 2.91)
