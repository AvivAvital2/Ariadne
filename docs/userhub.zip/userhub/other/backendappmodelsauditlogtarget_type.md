---
id: f9d6986a-afe1-5e56-b423-9e16ae5a0f13
type: catalog
title: "backend.app.models.AuditLog.target_type"
created_at: 2026-07-30T15:09:15.726628+00:00
updated_at: 2026-07-30T17:48:08.771844+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.AuditLog.target_type"
  signature: "target_type: Mapped[str] = mapped_column(String(32), default="user")"
  location: {'line_start': 89, 'line_end': 89, 'col_start': 4, 'col_end': 72}
  parent_qualified_name: "backend.app.models.AuditLog"
  sha_at_sync: "5f99d5acb716258505dc851b76f409318b2d353b1c57b5242bdd6950ce3ea7a2"
  description: "Stores the type of entity that an audit log entry targets, limited to 32 characters and defaulting to "user"."
---
# backend.app.models.AuditLog.target_type

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.AuditLog.target_type in backend.app.models.AuditLog [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:89-89 :: target_type: Mapped[str] = mapped_column(String(32), default="user")

Description: Stores the type of entity that an audit log entry targets, limited to 32 characters and defaulting to "user".

## Related Documents

- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 1.26)
- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.45)
- [backend.app.models.AuditLog.action](4e1645db-d364-5489-8771-5ec8b957913b.md) - Related (graph distance 1.55)
- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 2.62)
- [backend.app.schemas.AuditLogOut.action](bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d.md) - Related (graph distance 2.76)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 2.76)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.79)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 2.91)
- [backend.app.services.users.target_id](347260a2-8d58-556f-89b7-d9cc05ee6faa.md) - Related (graph distance 2.97)
