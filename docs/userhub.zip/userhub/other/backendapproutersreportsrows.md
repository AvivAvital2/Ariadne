---
id: 4b359aa5-d274-546c-91c8-7dedc3ea04e0
type: catalog
title: "backend.app.routers.reports.rows"
created_at: 2026-07-30T15:09:16.803959+00:00
updated_at: 2026-07-30T17:48:08.848703+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.routers.reports.rows"
  signature: "rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()"
  location: {'line_start': 26, 'line_end': 26, 'col_start': 4, 'col_end': 63}
  parent_qualified_name: None
  sha_at_sync: "7fa4fb2539b0b7c42e733f55a21688eaa340a2fea297dc1fa9bb08638ea981a7"
  description: "Executes the `USER_ACTIVITY_SQL` query against the database and retrieves all resulting rows as a list of mapping objects (dictionary-like row accessors)."
---
# backend.app.routers.reports.rows

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py`

variable backend.app.routers.reports.rows [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/reports.py:26-26 :: rows = db.execute(text(USER_ACTIVITY_SQL)).mappings().all()

Description: Executes the `USER_ACTIVITY_SQL` query against the database and retrieves all resulting rows as a list of mapping objects (dictionary-like row accessors).

## Related Documents

- [backend.app.reports.queries.USER_ACTIVITY_SQL](2b8ff6bd-7e2e-516d-b78c-1d495af079c3.md) - Related (graph distance 1.51)
- [backend.app.routers.reports.user_activity](492fc0bf-e17c-5850-9da1-69030030a77d.md) - Related (graph distance 1.55)
