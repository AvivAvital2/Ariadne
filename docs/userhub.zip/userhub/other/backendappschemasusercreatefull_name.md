---
id: e4c9ba1a-656b-5f27-917c-5fdbd42b1c11
type: catalog
title: "backend.app.schemas.UserCreate.full_name"
created_at: 2026-07-30T15:09:16.668291+00:00
updated_at: 2026-07-30T17:48:08.793440+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.UserCreate.full_name"
  signature: "full_name: str = """
  location: {'line_start': 38, 'line_end': 38, 'col_start': 4, 'col_end': 23}
  parent_qualified_name: "backend.app.schemas.UserCreate"
  sha_at_sync: "4960ec86e8e38a19d0f6c798bf4f77e91700ad2561e0a1970f82334f050019f5"
  description: "Optional field on the `UserCreate` schema specifying the user's full name, defaulting to an empty string if not provided."
---
# backend.app.schemas.UserCreate.full_name

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.UserCreate.full_name in backend.app.schemas.UserCreate [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:38-38 :: full_name: str = ""

Description: Optional field on the `UserCreate` schema specifying the user's full name, defaulting to an empty string if not provided.

## Related Documents

- [backend.app.schemas.UserUpdate.full_name](d85e1f5d-085a-57bb-96c5-4027d7531232.md) - Related (graph distance 1.16)
- [backend.app.schemas.UserOut.full_name](b1aed5f8-8902-5a9c-afdb-6648c8647216.md) - Related (graph distance 1.27)
- [backend.app.schemas.CurrentUser.full_name](0fd06547-0731-54f4-a98a-62ba04f082dd.md) - Related (graph distance 1.30)
- [backend.app.schemas.UserCreate.username](9dd890a0-c2ff-5771-a45e-bd8921869fac.md) - Related (graph distance 1.42)
- [backend.app.models.User.full_name](c892d5da-98e7-5903-bbec-fe540e16a8c8.md) - Related (graph distance 1.46)
- [backend.app.schemas.RoleCreate.description](45ebc943-481b-5895-83f2-66c009ffa977.md) - Related (graph distance 1.51)
- [backend.app.services.users.full_name](068b4d0c-4d8a-544e-93e4-8e6677d000bf.md) - Related (graph distance 1.53)
- [backend.app.schemas.UserUpdate.email](e7c526b2-7877-56cd-8d0c-efb5fdb089ad.md) - Related (graph distance 2.53)
- [backend.app.schemas.UserOut.username](38568b7d-d3da-5366-bd15-856aa2554f94.md) - Related (graph distance 2.60)
- [backend.app.schemas.CurrentUser.username](21ef1ade-124a-5c3f-94e7-ac924ecb6a6f.md) - Related (graph distance 2.61)
