---
id: 9dc8357a-f10a-520b-b090-8ee4bed57339
type: catalog
title: "backend.app.services.roles.list_roles"
created_at: 2026-07-30T15:09:17.242080+00:00
updated_at: 2026-07-30T17:48:08.853903+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.services.roles.list_roles"
  signature: "def list_roles(db: Session) -> list[Role]:"
  location: {'line_start': 9, 'line_end': 10, 'col_start': 0, 'col_end': 51}
  parent_qualified_name: None
  sha_at_sync: "ee44fd65effcc779158c680d976079e3f48f5a45dd3c49efe86224dabb7a348c"
  description: "Retrieves and returns all Role records from the database using the provided SQLAlchemy session."
---
# backend.app.services.roles.list_roles

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py`

function backend.app.services.roles.list_roles [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/services/roles.py:9-10 :: def list_roles(db: Session) -> list[Role]:

Description: Retrieves and returns all Role records from the database using the provided SQLAlchemy session.

## Related Documents

- [backend.app.services.roles.list_permissions](c0635854-e157-5ed0-836c-3317d08ec451.md) - Related (graph distance 1.18)
- [backend.app.services.roles.get_role](1ee43ae5-6edf-5b48-9b41-86136d1689ac.md) - Related (graph distance 1.43)
- [backend.app.routers.roles.list_roles](cfb4a684-a4d1-552d-950c-750cadabe210.md) - Related (graph distance 1.50)
- [backend.app.services.users.list_users](d6058efb-c2b7-5713-8903-c4a425c1404e.md) - Related (graph distance 1.54)
- [backend.app.services.users.user.roles](42507445-1c87-5d2c-bdbb-9160decb1217.md) - Related (graph distance 1.66)
- [backend.app.routers.roles.list_permissions](d5754e3b-76b3-5ef8-a07e-49c372b236d4.md) - Related (graph distance 2.63)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 2.82)
- [backend.app.routers.users.list_users](560f3447-cb6e-5c79-8253-b6bd964277c0.md) - Related (graph distance 2.85)
- [backend.app.services.roles.create_role](9dcc1fa6-68db-57e5-8ece-9ea1a83f4c53.md) - Related (graph distance 3.01)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 3.03)
