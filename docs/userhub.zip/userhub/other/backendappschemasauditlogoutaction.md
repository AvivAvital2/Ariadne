---
id: bd2cf348-97b7-5e6f-b1cd-7d9cb0f05c8d
type: catalog
title: "backend.app.schemas.AuditLogOut.action"
created_at: 2026-07-30T15:09:16.675701+00:00
updated_at: 2026-07-30T17:48:08.842164+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.action"
  signature: "action: str"
  location: {'line_start': 90, 'line_end': 90, 'col_start': 4, 'col_end': 15}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "9548055322aa836cf28cd0d5870cdd65f2fdcdc7b3cbd87e2323efdb1758094b"
  description: "Defines the `action` field of the `AuditLogOut` schema as a required string, representing the type of operation recorded in the audit log entry."
---
# backend.app.schemas.AuditLogOut.action

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.action in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:90-90 :: action: str

Description: Defines the `action` field of the `AuditLogOut` schema as a required string, representing the type of operation recorded in the audit log entry.

## Related Documents

- [backend.app.models.AuditLog.action](4e1645db-d364-5489-8771-5ec8b957913b.md) - Related (graph distance 1.38)
- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 1.50)
- [backend.app.schemas.AuditLogOut.detail](a31c8116-37e1-5beb-bf8e-ea48591a1744.md) - Related (graph distance 1.51)
- [backend.app.models.AuditLog.target_type](f9d6986a-afe1-5e56-b423-9e16ae5a0f13.md) - Related (graph distance 2.76)
- [backend.app.models.AuditLog.detail](3be4829c-8290-58c1-823e-c6fbdaff14ff.md) - Related (graph distance 2.78)
