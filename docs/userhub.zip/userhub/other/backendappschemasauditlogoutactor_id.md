---
id: 2bcaefd9-f965-52a4-b70e-9d92117f01af
type: catalog
title: "backend.app.schemas.AuditLogOut.actor_id"
created_at: 2026-07-30T15:09:16.675462+00:00
updated_at: 2026-07-30T17:48:08.841309+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.actor_id"
  signature: "actor_id: int | None"
  location: {'line_start': 89, 'line_end': 89, 'col_start': 4, 'col_end': 24}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "6fd46d198e0cd2b9db021e2f5e2e3375a447e74482ddb6860a10febb1c0e5ffd"
  description: "Optional field on the `AuditLogOut` schema holding the ID of the user or entity that performed the audited action, or `None` if no actor is associated."
---
# backend.app.schemas.AuditLogOut.actor_id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.actor_id in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:89-89 :: actor_id: int | None

Description: Optional field on the `AuditLogOut` schema holding the ID of the user or entity that performed the audited action, or `None` if no actor is associated.

## Related Documents

- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 1.23)
- [backend.app.models.AuditLog.actor_id](25c70609-8c99-55e4-9d8f-49625d0d95d4.md) - Related (graph distance 1.26)
- [backend.app.schemas.AuditLogOut.id](f7dbcee7-16f0-5f20-be88-a5ac62069d49.md) - Related (graph distance 1.31)
- [backend.app.models.AuditLog.target_id](43d55f4b-0b92-51b9-87d9-3f8c481cb80c.md) - Related (graph distance 1.46)
- [backend.app.schemas.UserActivityRow.user_id](893555ae-b345-587c-af10-83ee9a374c74.md) - Related (graph distance 1.54)
- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 2.56)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 2.58)
- [backend.app.schemas.AuditLogOut.target_type](8b3433df-a2d7-5700-8e87-d5ef95fec9de.md) - Related (graph distance 2.59)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 2.60)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 2.63)
