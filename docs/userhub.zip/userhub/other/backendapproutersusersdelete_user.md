---
id: 10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50
type: catalog
title: "backend.app.routers.users.delete_user"
created_at: 2026-07-30T15:09:16.736764+00:00
updated_at: 2026-07-30T17:48:08.846277+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.delete_user"
  signature: "def delete_user("
  location: {'line_start': 123, 'line_end': 128, 'col_start': 0, 'col_end': 68}
  parent_qualified_name: None
  sha_at_sync: "d3bf3f7d1ea8c2decf561208941deb54ca6f8e5103721285e27cf03752b7e623"
  description: "Deletes a user identified by the provided user ID from the system, typically returning a confirmation response or raising an error if the user does not exist."
---
# backend.app.routers.users.delete_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.delete_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:123-128 :: def delete_user(

Description: Deletes a user identified by the provided user ID from the system, typically returning a confirmation response or raising an error if the user does not exist.

## Related Documents

- [backend.app.routers.users.update_user](853de4ce-fcb4-542c-879f-dbd6e3659b83.md) - Related (graph distance 1.34)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 1.36)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 1.39)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 1.53)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 1.56)
- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.60)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 1.62)
- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 2.76)
- [backend.app.services.users.get_user](61f64236-c76b-5f4d-b56e-273161cf20c2.md) - Related (graph distance 2.78)
- [backend.app.services.users.user](6337171a-1a3f-58cd-b7a5-403243f160b8.md) - Related (graph distance 2.79)
