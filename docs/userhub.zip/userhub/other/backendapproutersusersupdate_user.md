---
id: 853de4ce-fcb4-542c-879f-dbd6e3659b83
type: catalog
title: "backend.app.routers.users.update_user"
created_at: 2026-07-30T15:09:16.735904+00:00
updated_at: 2026-07-30T17:48:08.845470+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.routers.users.update_user"
  signature: "def update_user("
  location: {'line_start': 78, 'line_end': 90, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "e8c107b287b24e79adcf4c322ff1f24e00b8fee67952688c661fe8e742cdd5ad"
  description: "Updates an existing user's information based on the provided user ID and data, returning the modified user record."
---
# backend.app.routers.users.update_user

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py`

function backend.app.routers.users.update_user [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/routers/users.py:78-90 :: def update_user(

Description: Updates an existing user's information based on the provided user ID and data, returning the modified user record.

## Related Documents

- [backend.app.services.users.update_user](c5c40493-e924-5179-838b-07141ddd7ebc.md) - Related (graph distance 1.18)
- [backend.app.routers.users.delete_user](10b4e14d-169a-5f0d-b9a6-e9fa9db8ea50.md) - Related (graph distance 1.34)
- [backend.app.routers.users.get_user](a7c38ddb-340d-5877-a564-5b82c9551d5a.md) - Related (graph distance 1.42)
- [backend.app.routers.users.set_user_status](f0039981-57e6-54af-b99a-d32e1008d843.md) - Related (graph distance 1.46)
- [backend.app.routers.users.create_user](ec1d5c22-1443-5b53-b4de-19979e86393a.md) - Related (graph distance 1.50)
- [backend.app.services.users.create_user](f33dac0b-49f6-5f66-80ef-bdb495fd1dd0.md) - Related (graph distance 1.66)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 2.71)
- [backend.app.services.users.delete_user](5b5d80fb-054f-5873-9a99-b372617190c4.md) - Related (graph distance 2.73)
- [backend.app.routers.users.user](89b00fec-febb-59b7-a49b-0df19b779211.md) - Related (graph distance 2.77)
- [backend.app.services.users.set_status](8404cebc-c22c-5680-94d8-d4193032178f.md) - Related (graph distance 2.82)
