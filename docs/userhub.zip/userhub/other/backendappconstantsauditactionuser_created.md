---
id: b3b01c65-1e3c-5ccc-91c2-eb3e8b9608c4
type: catalog
title: "backend.app.constants.AuditAction.USER_CREATED"
created_at: 2026-07-30T15:09:15.961254+00:00
updated_at: 2026-07-30T17:48:08.777807+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.constants.AuditAction.USER_CREATED"
  signature: "USER_CREATED = "user.created""
  location: {'line_start': 48, 'line_end': 48, 'col_start': 4, 'col_end': 33}
  parent_qualified_name: "backend.app.constants.AuditAction"
  sha_at_sync: "82f8e8a0986cc24906f9fc76fe461522feb9f3942023c4954d5a8bd48481aaf3"
  description: "Enum member of `AuditAction` representing the audit event logged when a new user account is created, with the string value `"user.created"`."
---
# backend.app.constants.AuditAction.USER_CREATED

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py`

variable backend.app.constants.AuditAction.USER_CREATED in backend.app.constants.AuditAction [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/constants.py:48-48 :: USER_CREATED = "user.created"

Description: Enum member of `AuditAction` representing the audit event logged when a new user account is created, with the string value `"user.created"`.

## Related Documents

- [backend.app.constants.AuditAction.USER_UPDATED](6ed359da-8cd3-5cda-a86b-312ebbc9760e.md) - Related (graph distance 1.22)
- [backend.app.constants.AuditAction.USER_DELETED](da68919f-3944-5c27-a38d-283af40e2e66.md) - Related (graph distance 1.24)
- [backend.app.constants.AuditAction.USER_REACTIVATED](159448c1-c606-5607-afb6-43fbc9d266a7.md) - Related (graph distance 1.28)
- [backend.app.constants.AuditAction.USER_DEACTIVATED](c47726dd-d63a-5e8a-a7b1-80f7a31b045a.md) - Related (graph distance 1.33)
- [backend.app.constants.AuditAction.ROLE_ASSIGNED](acc30db8-b69c-5f6f-88d4-de745f572998.md) - Related (graph distance 1.42)
- [backend.app.constants.AuditAction](966803e2-fceb-5ae6-8492-3ddfcff173ef.md) - Related (graph distance 1.54)
- [backend.app.constants.Permission.USERS_CREATE](fd160f21-b512-5c2a-a845-de7baab7ee29.md) - Related (graph distance 1.61)
- [backend.app.constants.UserStatus.DEACTIVATED](124dca39-7e4c-56e8-a63a-5e12d7ea3d9d.md) - Related (graph distance 2.53)
- [backend.app.constants.AuditAction.ROLE_REVOKED](941c3822-94ac-5358-a3bf-3f1ce80016d7.md) - Related (graph distance 2.59)
- [backend.app.constants.UserStatus.ACTIVE](9a88757a-cd9b-5500-a873-81f082bce5d2.md) - Related (graph distance 2.73)
