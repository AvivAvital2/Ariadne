---
id: 5ef82d2f-c2ad-5d66-a6d9-555d6c1b0458
type: catalog
title: "backend.app.models._utcnow"
created_at: 2026-07-30T15:09:15.717568+00:00
updated_at: 2026-07-30T17:48:08.764173+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "function"
  qualified_name: "backend.app.models._utcnow"
  signature: "def _utcnow() -> datetime.datetime:"
  location: {'line_start': 15, 'line_end': 16, 'col_start': 0, 'col_end': 55}
  parent_qualified_name: None
  sha_at_sync: "12a4541ecfe5b1a057e1652ac140668dd5933769e4c47fce1e9128f8b3bab5ba"
  description: "Returns the current UTC date and time as a timezone-aware `datetime` object."
---
# backend.app.models._utcnow

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

function backend.app.models._utcnow [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:15-16 :: def _utcnow() -> datetime.datetime:

Description: Returns the current UTC date and time as a timezone-aware `datetime` object.

## Related Documents

- [backend.app.seed.now](c0d4b4d7-e036-5f8a-bb67-5a84a7345374.md) - Related (graph distance 1.64)
- [backend.app.models.User.created_at](8ea6c38c-c021-5ac6-a555-1fd72c4a3136.md) - Related (graph distance 1.65)
- [backend.app.models.User.updated_at](d16fded0-b866-5b24-b3f4-c996ca1d98ea.md) - Related (graph distance 2.87)
- [backend.app.models.AuditLog.created_at](f84a7924-6247-540c-bf88-6538484215df.md) - Related (graph distance 2.90)
- [backend.app.schemas.UserOut.created_at](535e53d2-ce6c-5494-889d-0018699cdf42.md) - Related (graph distance 2.92)
