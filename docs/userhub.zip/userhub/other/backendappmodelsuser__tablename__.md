---
id: d2a6a7b3-ecb1-5671-9d6e-1dddc1d79573
type: catalog
title: "backend.app.models.User.__tablename__"
created_at: 2026-07-30T15:09:15.719756+00:00
updated_at: 2026-07-30T17:48:08.765768+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.models.User.__tablename__"
  signature: "__tablename__ = "users""
  location: {'line_start': 36, 'line_end': 36, 'col_start': 4, 'col_end': 27}
  parent_qualified_name: "backend.app.models.User"
  sha_at_sync: "9672f0bdffe297240b3c3a0a0a12158e46de9fd6173e4a1ae0e820b0fa4fd106"
  description: "Specifies the database table name as "users" for the User model in SQLAlchemy's ORM mapping."
---
# backend.app.models.User.__tablename__

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

variable backend.app.models.User.__tablename__ in backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:36-36 :: __tablename__ = "users"

Description: Specifies the database table name as "users" for the User model in SQLAlchemy's ORM mapping.

## Related Documents

- [backend.app.models.Role.__tablename__](37624afd-6108-5b4e-8e41-56008d592ced.md) - Related (graph distance 1.19)
- [backend.app.models.Permission.__tablename__](4c6f0324-6589-5069-938c-4b0eec16aea3.md) - Related (graph distance 1.20)
- [backend.app.models.AuditLog.__tablename__](f7701d3c-d768-59a6-a353-5dc7d0dc27df.md) - Related (graph distance 1.22)
- [backend.app.models.user_roles](c32c0c8a-903a-515b-8379-90bbe5d9ef57.md) - Related (graph distance 2.79)
