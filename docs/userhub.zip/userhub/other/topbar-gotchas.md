---
id: 494aff6e-2daa-5007-a2cf-b93d7e34447d
type: gotcha
title: "Topbar Gotchas"
created_at: 2026-07-30T17:28:35.188982+00:00
updated_at: 2026-07-30T17:28:35.188996+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx
metadata:
  module_name: "frontend.src.components.Topbar"
  language: "javascript"
  provenance: "code-derived"
  source_name: "userhub"
---
# Topbar Gotchas

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/frontend/src/components/Topbar.jsx`

# Gotchas & Pitfalls: `frontend.src.components.Topbar`

### `initials()` breaks on non-string usernames
**Trigger:** `actor.username` is a number, `null`, or another non-string type. `.slice()` and `.toUpperCase()` are called assuming a string.
**Affected Files:** `Topbar.jsx`
**Fix:** Coerce to string or guard the type. The `|| "?"` only handles falsy values, not wrong types.
**Category:** type-system
**Example:**
```javascript
// actor = { username: 12345 }
initials(12345); // 12345.slice is not a function → TypeError
// A number like 0 also silently falls through to "?" because 0 is falsy
initials(0); // "?" — but 0 might be a valid ID cast to username elsewhere
```

### Empty-string username silently renders "?"
**Trigger:** `actor.username === ""` — an empty string is falsy, so `(name || "?")` yields `"?"`. This may mask a real data bug (user exists but has blank username).
**Affected Files:** `Topbar.jsx`
**Fix:** Distinguish "missing" from "empty" explicitly if that matters: `name && name.length ? ... : "?"`, or validate upstream.
**Category:** type-system
**Example:**
```javascript
initials(""); // "?" — no error, no signal that data is malformed
```

### Multi-byte / emoji usernames produce broken initials
**Trigger:** `.slice(0, 2)` operates on UTF-16 code units, not grapheme clusters. Usernames starting with emoji or surrogate-pair characters get split mid-character.
**Affected Files:** `Topbar.jsx`
**Fix:** Use `Array.from(name)` or `[...name]` to slice by code points, or use `Intl.Segmenter` for grapheme safety.
**Category:** type-system
**Example:**
```javascript
initials("👨‍👩‍👧"); // slices a broken half of the surrogate pair → mojibake "�"
```

### `actor` truthy but missing expected fields
**Trigger:** `actor && (...)` only checks that `actor` exists, not that it has `username`/`full_name`. An `actor = {}` passes the guard, then `actor.username` is `undefined` → renders `"?"` avatar with empty name span.
**Affected Files:** `Topbar.jsx`
**Fix:** Check the specific field you render: `actor?.username && (...)`, or provide sensible fallbacks for the `<span>`.
**Category:** type-system
**Example:**
```javascript
<Topbar actor={{}} />
// Renders: avatar "?", <span></span> (empty, no fallback text)
```

### Search input is uncontrolled with no handler
**Trigger:** The `<input>` has a placeholder and aria-label but no `value`/`onChange`/`onSubmit`. It looks functional but does nothing — a developer may assume search works.
**Affected Files:** `Topbar.jsx`
**Fix:** Wire up `onChange`/`onKeyDown` and pass a callback prop, or document that it's presentational-only.
**Category:** framework
**Example:**
```javascript
// User types, hits Enter → nothing happens; no search event fires
<input placeholder="Search…" aria-label="Search" />
```

### Notifications button is a dead control
**Trigger:** The bell `<button>` has no `onClick`. Accessible (has aria-label) but non-functional — misleading to keyboard/screen-reader users who expect action.
**Affected Files:** `Topbar.jsx`
**Fix:** Attach a handler or render it disabled/as decorative until implemented.
**Category:** framework
**Example:**
```javascript
<button className="icon-btn" aria-label="Notifications">
  {/* clicks silently ignored */}
</button>
```

### Missing `title` renders empty `<h1>`
**Trigger:** `title` prop is `undefined`. React renders an empty `<h1 className="topbar-title">` — no crash, but an empty heading harms accessibility and layout.
**Affected Files:** `Topbar.jsx`
**Fix:** Provide a default (`title = "Untitled"`) or conditionally render the heading.
**Category:** type-system
**Example:**
```javascript
<Topbar /> // <h1 class="topbar-title"></h1> — empty heading in DOM
```

### No PropTypes / TypeScript — silent shape drift
**Trigger:** Component contract (`title: string`, `actor: { username, full_name }`) is implicit. Callers passing wrong shapes fail only at render, deep in the tree.
**Affected Files:** `Topbar.jsx` and all callers
**Fix:** Add PropTypes or migrate to `.tsx` with a typed props interface.
**Category:** type-system
**Example:**
```javascript
<Topbar title={<Component/>} actor="admin" /> // no compile/prop warning
```

### Search icon color/size coupling assumption
**Trigger:** `IconSearch size={16}` and `IconBell size={18}` — if `Icons.jsx` ignores or misuses `size` (e.g., only sets width not height, or expects a string), icons render inconsistently. Behavior depends entirely on the un-shown `Icons.jsx` contract.
**Affected Files:** `Topbar.jsx`, `Icons.jsx`
**Fix:** Verify `Icons.jsx` applies `size` to both width and height and accepts a number; add defaults.
**Category:** framework
**Example:**
```javascript
// If Icons.jsx does <svg width={size}> only → non-square icons
```