---
id: 12309fd4-111e-542c-89a8-af5e3300ae89
type: catalog
title: "backend.app.models.User"
created_at: 2026-07-30T15:09:15.717971+00:00
updated_at: 2026-07-30T17:48:08.764412+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "class"
  qualified_name: "backend.app.models.User"
  signature: "class User(Base):"
  location: {'line_start': 35, 'line_end': 51, 'col_start': 0, 'col_end': 5}
  parent_qualified_name: None
  sha_at_sync: "64d4a86a16ba0ed7790a591df2df6b2bda9d1ecd3df4ad26e87fc7247f7c5cd7"
  description: "A SQLAlchemy ORM model representing a user record in the database, mapping to a database table via the declarative Base class. Defines the schema and columns for storing user data."
---
# backend.app.models.User

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/models.py`

class backend.app.models.User [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/models.py:35-51 :: class User(Base):

Description: A SQLAlchemy ORM model representing a user record in the database, mapping to a database table via the declarative Base class. Defines the schema and columns for storing user data.

## Related Documents

- [backend.app.models.Role](db038498-23ee-5448-a7da-7691293250b7.md) - Related (graph distance 1.47)
- [backend.app.models.Permission](0e7843d6-44d3-5ac2-9d8c-ee08801cc3ed.md) - Related (graph distance 1.56)
- [backend.app.models.AuditLog](9ed8286b-7e90-5043-bf34-7c16096cb903.md) - Related (graph distance 1.57)
- [backend.app.database.Base](4ef45cb4-630a-5586-a798-b2d40bf8da04.md) - Related (graph distance 1.57)
- [backend.app.schemas.UserCreate](595581c1-91ba-5d60-b01a-17433590d234.md) - Related (graph distance 1.60)
- [backend.app.schemas.RoleCreate](3b6b05a7-0d9b-5d08-8250-67eb9c6ed99a.md) - Related (graph distance 2.86)
- [backend.app.schemas.UserUpdate](04a09dcb-bb0d-5e21-a970-8ac4fab9c749.md) - Related (graph distance 2.88)
