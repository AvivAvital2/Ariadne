---
id: f7dbcee7-16f0-5f20-be88-a5ac62069d49
type: catalog
title: "backend.app.schemas.AuditLogOut.id"
created_at: 2026-07-30T15:09:16.675221+00:00
updated_at: 2026-07-30T17:48:08.797627+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.schemas.AuditLogOut.id"
  signature: "id: int"
  location: {'line_start': 88, 'line_end': 88, 'col_start': 4, 'col_end': 11}
  parent_qualified_name: "backend.app.schemas.AuditLogOut"
  sha_at_sync: "fa3ade80194044385719c8d9c727664fc73b21b0585020aa04e7b43bca70c957"
  description: "The unique integer identifier for an audit log entry in the `AuditLogOut` schema."
---
# backend.app.schemas.AuditLogOut.id

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py`

variable backend.app.schemas.AuditLogOut.id in backend.app.schemas.AuditLogOut [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/schemas.py:88-88 :: id: int

Description: The unique integer identifier for an audit log entry in the `AuditLogOut` schema.

## Related Documents

- [backend.app.models.AuditLog.id](b0501eb7-823a-5277-8ef4-9b9ccac8b468.md) - Related (graph distance 1.25)
- [backend.app.schemas.UserOut.id](4ef51978-13b5-5dea-95b8-5e162474ad27.md) - Related (graph distance 1.26)
- [backend.app.schemas.RoleOut.id](6b48667e-31f9-560e-a786-ec31f3d9f913.md) - Related (graph distance 1.29)
- [backend.app.schemas.AuditLogOut.actor_id](2bcaefd9-f965-52a4-b70e-9d92117f01af.md) - Related (graph distance 1.31)
- [backend.app.schemas.AuditLogOut.target_id](543481ae-f53e-5bf5-8a5b-d011540ee296.md) - Related (graph distance 1.32)
- [backend.app.schemas.PermissionOut.id](d9f8059d-fd8c-5758-995a-c3c99b796d30.md) - Related (graph distance 1.32)
- [backend.app.schemas.AuditLogOut](6e6767f4-fae6-512e-a9bf-fdd8f6b39d44.md) - Related (graph distance 1.59)
- [backend.app.schemas.RoleBrief.id](5cdbe3f2-d28f-5da1-9661-0d42e75263ea.md) - Related (graph distance 2.46)
- [backend.app.models.User.id](a9e80af3-a787-5195-aa23-b9ce8d253c41.md) - Related (graph distance 2.47)
- [backend.app.schemas.CurrentUser.id](11d99716-318b-5673-9da7-657d86a04b8c.md) - Related (graph distance 2.48)
