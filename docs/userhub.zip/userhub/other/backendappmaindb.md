---
id: bb5aec0e-efa8-5d81-9107-bf2af1df3260
type: catalog
title: "backend.app.main.db"
created_at: 2026-07-30T15:09:16.055208+00:00
updated_at: 2026-07-30T17:48:08.780353+00:00
source_files:
  - /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py
metadata:
  kind: "element"
  source_name: "userhub"
  language: "python"
  subtype: "variable"
  qualified_name: "backend.app.main.db"
  signature: "db = SessionLocal()"
  location: {'line_start': 27, 'line_end': 27, 'col_start': 4, 'col_end': 23}
  parent_qualified_name: None
  sha_at_sync: "bb6733efb785f2356fd52576080349dcea2d9fc5a3411224bcef7dc5b8b201bc"
  description: "Creates a database session instance from the `SessionLocal` factory for interacting with the database at module level."
---
# backend.app.main.db

**Related files:**
- `/Users/spark/git/Ariadne.orig/userhub/backend/app/main.py`

variable backend.app.main.db [python] /Users/spark/git/Ariadne.orig/userhub/backend/app/main.py:27-27 :: db = SessionLocal()

Description: Creates a database session instance from the `SessionLocal` factory for interacting with the database at module level.

## Related Documents

- [backend.app.database.db](79b07bea-702c-59cb-bbea-2a7349e809e6.md) - Related (graph distance 1.12)
- [backend.app.database.SessionLocal](8b8fafba-48bd-565d-a261-fd009a8cb0a6.md) - Related (graph distance 1.35)
- [backend.app.database.get_db](b1de7430-33d3-5af5-aa00-16c515f88a86.md) - Related (graph distance 2.67)
